# Ariv on the dashboard

*Design, 27 August 2026. To be built rather than decided tomorrow.*

## What Ariv is for

An investor looking at a portfolio has questions the dashboard cannot
anticipate. *Why are you telling me to switch this fund? What happens if I sell
the Thermax instead? Is my SIP enough?* Every one of those has an answer we
have already computed and no place to put it.

That is the whole opportunity, and it is unusually well suited to what we have
built: every number this platform produces already carries its reasoning in
prose. A competitor adding a chat interface has to generate explanations after
the fact. We have to retrieve ours.

**What Ariv is not** is a second opinion. It answers from what the platform
computed, in the platform's own words, or it declines. An assistant that
improvises around a recommendation engine is not an interface to that engine —
it is a different engine with worse discipline.

## Part one: the harness

### The rule

**Ariv answers from the grounding context or says it cannot.** The context is
assembled per question from computed values. Anything outside it is refused,
and the refusal is specific rather than generic.

### What it must refuse, and why

These are the engine's own refusals. Ariv inherits them; it does not get to
route around them because somebody phrased the question conversationally.

| Asked | Response |
|---|---|
| Will the market fall? Should I wait? | No forecasts. Base rates from history with the sample size, or nothing. |
| Give me a score out of ten | No composite. The count-based reading, which opens into what it counts. |
| Should I buy HDFC Bank? | Only if the engine produced a verdict on it. Otherwise: not computed. |
| What's a good fund right now? | Only from the screener's ranked output for a stated gap. Never freehand. |
| How much tax will I owe overall? | Capital gains on the holdings, yes. Income tax, no — not our computation. |
| Is this a good time to invest? | The market's position and what followed similar readings. Not a direction. |
| My friend says I should… | Not a question about this portfolio. |

**The test for a refusal:** would a compliance officer reading the transcript
recognise this as advice we are licensed to give, grounded in something we
computed? If not, decline.

### The refusal should be useful

*"I can't answer that"* is worse than nothing. Each refusal says what we do
have:

> I don't have a view on whether the market will fall — this platform doesn't
> forecast. What I can tell you is that it's 7% off its high, and that across
> the five years of history we hold, the twelve months after similar readings
> were positive about 87% of the time from 318 overlapping windows. That's what
> has happened, not what will.

### Detecting drift

Long conversations wander. Three guards:

**Scope check per turn.** The question is classified before anything is
assembled: about this portfolio, about the platform's method, or neither.
Only the first two proceed.

**No accumulating persona.** The system context is rebuilt each turn from the
portfolio and the engine output. Nothing carries forward except the last few
turns of conversation, which prevents a long session drifting into a character
the first turn never established.

**A turn limit with a graceful end.** After roughly twenty exchanges the
session offers to start fresh. Not a hard cut — a session that has wandered far
from a portfolio question is usually one where a person would be better served
by an adviser, and saying so is the right answer.

## Part two: the record

**Wider than Ariv, and this is the part that was scoped too narrowly.**

Under the licence this operates through, we are answerable for every
suggestion, analysis and answer put in front of an investor. An assistant's
reply is one kind of output among several — the decision engine's actions, the
findings, the guide, the buy plan and the holding verdicts are all advice, all
shown, and none of them was being kept.

### The gap

The platform computes on request and stores nothing. Asked what an investor was
told on a date last March, we could recompute from today's prices and get a
different answer — **which is worse than having no answer, because it looks
like one.**

That is not a gap in the assistant. It is a gap in the platform, and the
assistant made it visible.

### The ledger

`advice_ledger` (migration 019) holds every output, of every kind, with:

| Field | Answers |
|---|---|
| `shown_at`, `data_as_of` | When, and against what state of the world |
| `kind` | Which surface: decision, finding, guide, buy plan, verdict, Ariv |
| `said` | The rendered output, exactly as the investor saw it |
| `basis` | **The inputs that produced it** |
| `engine_version`, `ruleset_version`, `model` | By which reasoning |
| `surface`, `session_id`, `caller` | How it was delivered, and to whom |
| `outcome` | Whether it was acted on, where we can tell |
| `corrects` | Corrections append; they never overwrite |

**`basis` is the column that makes the table worth having.** A record showing
the conclusion without the reasoning answers the question nobody asks. The
question asked years later is always *on what basis* — and a portfolio changes,
so an answer correct in August reads as wrong in October unless the inputs are
preserved beside it.

### Chronology, enforced

Append-only, with a trigger that refuses `UPDATE` and `DELETE` outright. A
trigger is not a security boundary — somebody with the right grants can drop it
— but it stops the accidental overwrite that would otherwise never be noticed.

Corrections insert a new row pointing at the original. The history of a
correction is itself part of the record.

### Retention

**Five years minimum, seven preferred.** Nothing is deleted without compliance
sign-off, and pruning happens by export rather than by `DELETE`.

`ON DELETE RESTRICT` on the investor: a deleted investor must not take the
record of what they were told with them. Where a deletion request has to be
honoured, the identifying fields are redacted and the advice record stays,
which is the only way to satisfy both obligations at once.

### What must also be preserved

The record points at things that have to still exist when it is read:

- **The engine version and its thresholds.** `engine_version` is a label; the
  reasoning it names has to be retrievable. Git history covers this provided
  releases are tagged, which they are not yet.
- **The model.** Where a generated answer is involved, which model produced it
  and on what prompt version.
- **The reference data as of that date.** NAVs and prices we hold; sector
  medians and scheme ranks we compute on the fly and do not snapshot. Worth
  deciding whether `basis` should carry the computed values — it should, and
  the migration allows it.

## Part three: cost

**The lever is fewer tokens, not cheaper ones.**

### Most questions never reach a model

Perhaps seven in ten questions to a portfolio assistant have deterministic
answers we already compute:

- *What's my portfolio worth?* → the dashboard endpoint
- *How much tax if I sell everything?* → the tax service
- *What's my largest holding?* → the holdings view
- *What did my funds buy last month?* → the activity endpoint
- *How much am I paying in commission?* → the plans service
- *What should I do first?* → the decision engine's first action

These route to our own endpoints and return a templated answer. **No model, no
tokens, no latency, and no possibility of drift** — the answer is the
computation.

Classification of which route a question takes is itself a small model call or
a keyword match; where a match is confident, the deterministic path wins.

### Generated answers get a tight context

Only genuinely open questions generate — *"why did you rank this above that"*,
*"what happens if I do half of it"*, *"explain this in simpler terms"*.

Those get an assembled context of what the question needs rather than the whole
portfolio: the specific holding, the specific finding, the relevant method
note. A full portfolio dump is thousands of tokens and most of it is irrelevant
to any one question.

### Caching

The assembled portfolio summary is cached per session. Within a conversation
the portfolio does not change, so the same context is reused across turns
rather than rebuilt.

### On cheaper models

**A weaker model on financial advice under a licence is a false economy.** A
wrong answer costs more than the tokens saved — in remediation, in trust, and
potentially in a regulatory finding. The saving comes from routing questions
away from generation entirely, not from generating them worse.

If cost still needs reducing after the deterministic routing is in place, the
next lever is a shorter context, then a turn limit, then rate limiting per
investor. Model quality is the last thing to cut, not the first.

## What to build tomorrow

**The order matters — the audit trail comes first, because an assistant
running without one cannot be switched on at all.**

1. `advice_ledger` (migration 019) and the writer that every output goes
   through — not Ariv's alone
2. The router: question → deterministic endpoint or generation
3. The deterministic answers for the ten most likely questions
4. The grounding assembler for generated answers
5. The refusal set, inheriting the engine's
6. The dashboard panel

**Not tomorrow:** voice, multi-turn memory across sessions, proactive
questions. Each adds surface area to something that has to be defensible to a
regulator before it is clever.

## The measure of success

Not engagement. A person who asks one question, gets a grounded answer and
leaves satisfied has been served better than one who chats for twenty minutes.

The measure is: **did the answer come from something we computed, and can we
show that two years later.** Everything else follows from it.
