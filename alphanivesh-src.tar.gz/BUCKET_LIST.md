# The bucket list

*28 August 2026. Everything outstanding, with what it costs and why it is
where it is. Ordered by value against effort rather than by when it was
raised.*

---

## Part one: the AlphaLensMF pages we have not built

Four screens exist there and not here: Health Check, Stress & Risk, Benchmark &
Peers, Goals & Costs. Some of what they show we already have under different
names; the rest is genuinely missing.

### Already covered, differently

Worth knowing so we do not rebuild what exists: tax harvesting, the emergency
fund check, the insurance gap, concentration, fund overlap, cost drag on
regular plans, sector and market-cap breakdown, drawdown, and the category
allocation.

### Genuinely missing

| What | Effort | Note |
|---|---|---|
| **VaR and Expected Shortfall** — daily, monthly, annual, at 95% and 99% | medium | Real arithmetic over the return series we already hold. Self-contained. |
| **Historical scenario replay** — rate hike, currency, global recession, credit event, FII outflow, oil shock | medium | Six named shocks with a modelled impact. Ours would differ from theirs: they appear to apply fixed percentages by scenario, and doing it from each holding's actual beta to the relevant factor is better and harder. |
| **Cost drag compounded** — 5 to 25 years against a 0.3% index alternative | small | We compute the annual figure; compounding it is arithmetic. |
| **Step-up SIP projections** — flat against 5/10/15/20% annual increase | small | Needs a monthly amount, which we can read from the behaviour engine. |
| **Portfolio XIRR** | small, blocked | The computation is easy. Transaction coverage is 0% for our main test investor, and XIRR without the cashflows is not XIRR. Blocked on imports rather than on code. |
| **Monte Carlo projection fans** — 1, 3, 5, 10 year percentile bands | medium, blocked | Their endpoint has a return-series bug: `ORDER BY date_trunc('month', nav_date), nav_date DESC` walks backwards within each month, so the drift cancels and ₹24 lakh of contributions come back as ₹24.8 lakh. **Report before building on it.** |
| **Peer quartiles, information ratio, tracking-error forecast** | large | Needs the category-wide return distribution, which we do not hold. Either the data service grows an endpoint or we ingest it. |
| **Peer comparison by age band** | medium | "You against others aged 30-40". Needs a cohort we do not have; would have to be assembled or licensed. |
| **Goal achievement tracker** | medium, blocked | Six life goals with probability and gap. Nobody has set a goal, so it would render empty on every account we have. |

### What not to copy

**Their Health Score (25/100) and Risk Score (8.5/10).** Composites. We refused
these deliberately and it is on the methodology page. Their own screen makes
the argument for us: "Grade D (25/100)" tells somebody they are failing without
telling them which measure drove it, and a reader cannot take it apart.

Our count-based reading — what is urgent, what is leaking, what is worth doing
— says the same thing and opens into the thing it counts.

**Diversification Score 1.0/10** has the same problem in a sharper form: a
number that low reads as a catastrophe, and the underlying finding ("four funds
all equity, 81% in three") is clear, actionable, and does not need a score to
carry it.

---

## Part two: the competitor gaps still open

From `SCOPE_OF_WORK.md`, minus what has since been built.

| What | Effort | Note |
|---|---|---|
| **Family and household view** | medium | INDmoney, Kuvera and FundSageAI have it; PowerUp is building it. **Blocked on a decision, not on code:** who may see whose holdings. Three models are laid out in the scope document; explicit invitation is the only one that survives a separation. |
| **NPS** | small | The CAS parser already returns an `nps` section we handle. Nobody has one yet, so it is untestable rather than unbuilt. |
| **EPF** | large | An external integration. Often a salaried investor's largest holding and we cannot see it at all. |
| **Succession and nominee** | small | Appears in comparisons as real criteria. Pairs with the protection gap the engine already computes. |
| **International holdings** | large | Needs pricing the group's data service does not carry. Probably not ours to solve. |

**Done since that document:** liabilities, tax harvesting, export, sharing with
expiry, the PDF, and the advice ledger with its audit page.

---

## Part three: Ariv

| What | State |
|---|---|
| Router — deterministic, generated or refused | **built** |
| Ten deterministic answers, five refusals | **built** |
| The advice ledger it writes to | **built** |
| The panel on the dashboard | **not built** |
| Grounding assembler for generated answers | **not built** |
| The Anthropic account | **key valid, no credit** |

The deterministic half works today and costs nothing. Generated answers wait on
billing, which is a console visit rather than an engineering task.

---

## Part four: the monthly disclosure engine

The strongest idea on any of these lists and the one most blocked.

*"Three of your funds bought HDFC Bank this month, and with the 25% you hold
directly your exposure is now 31%"* — a material change in risk somebody made
no decision about, which nothing in the market tells them.

**Blocked on disclosure coverage.** Two funds in twelve have month-over-month
holdings; 3,775 of 4,844 schemes have a single date. That is an ingest problem
on alphaforge, and **one conversation with whoever owns that service is worth
more than anything we can write around it.**

Same root cause as the parked look-through and the 8,056% weights.

---

## Part five: the loose ends

| What | Effort |
|---|---|
| **Two unresolved holdings** — the iSIF AIF and Neetu's Axis entry, ₹12.4 lakh between them at values never repriced | small, needs a person to identify them |
| **Vernacular prose** — roughly 45 sentences still to key, then seven languages to commission | medium then external |
| **`funds-compare` and `funds-explore`** | medium |
| **Redemption handling** — partial exits still overstate cost basis | medium, needs full transaction history |
| **Goals** — nobody has set one, so every goal feature renders empty | needs a user, not code |

---

## What I would do, in order

**Tomorrow morning, because each is self-contained arithmetic over data we
already hold:**

1. **VaR and Expected Shortfall** — daily, monthly, annual
2. **Cost drag compounded** to 25 years
3. **Step-up SIP projections**

**Tomorrow afternoon:**

4. **Historical scenario replay**, computed from each holding's own behaviour
   rather than from a fixed percentage per scenario
5. **Ariv's panel**, which works today without credit

**Then, in order of what unblocks the most:**

6. The disclosure-coverage conversation with the data service owner
7. The montecarlo return-series bug, same conversation
8. Family view, once the permissions question is answered
9. Peer quartiles, if the category data can be had

**Not soon:** EPF, international holdings, age-band peer comparison. Each needs
something we do not control.

---

## The one thing worth protecting

Everything above is a feature. What makes this product different is not on the
list because it is already built: verdicts against a peer set rather than a
threshold, behaviour read from transactions, recommendations withheld with
their reasons, a stated methodology including the refusals, and the hierarchy
that puts an empty emergency fund above an interesting sector concentration.

Adding a Health Score of 25/100 to that would be trading the thing nobody else
has for the thing everybody has.
