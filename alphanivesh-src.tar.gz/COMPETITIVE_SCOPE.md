# What the market offers, and what we do not

*Scoped 27 August 2026, from current published feature sets. Vendor marketing
has been discounted where claims are unverifiable — several platforms advertise
prediction accuracy figures that nobody can check, and those are not treated as
benchmarks here.*

## Who we are actually against

Three kinds of product, and they compete differently.

**Execution-first brokers** — Groww, Zerodha Coin. Tracking exists to support
order placement. Analytics are shallow by design and their advantage is that
the money is already there.

**Aggregators** — INDmoney, Kuvera, Agni Folio. Breadth is the product: bank
balances, EPF, ESOPs, US equities, liabilities, family accounts, all in one
net-worth number. Analysis is thinner than the breadth suggests.

**Specialist analysers** — FundSageAI, MProfit, Value Research. Depth on one
asset class. XIRR, overlap, health scores, professional reporting.

We are a specialist analyser that wants to be trusted like an adviser, which is
a fourth position and needs the strengths of at least two of the three.

## What they have that we do not

Ordered by how often it appears and how much it costs us to lack it.

### 1. Family and household view
INDmoney, Kuvera and FundSageAI all group family members into one picture.
We hold several investors and have no way to say "the household holds this".
For anybody with a spouse, this is the difference between a useful number and
half of one — and it is one of the most-cited reasons people choose a platform.

**Effort:** moderate. The data model supports it; the aggregation and the
permission question do not exist.

### 2. Liabilities in the net-worth number
INDmoney shows loans with due dates counted against assets. We built the
`liabilities` table yesterday and nothing displays it. Net worth without debt
is not net worth, and the risk engine already treats its absence as a hole in
the middle of the capacity calculation.

**Effort:** small. Table exists, engine reads it, no page shows it.

### 3. EPF, NPS, ESOPs and bank balances
INDmoney links EPFO directly and tracks vesting schedules. For a salaried
investor the provident fund is often the largest single holding and we do not
see it at all. The CAS parser already returns an `nps` section we handle.

**Effort:** EPF and ESOP are new integrations. NPS is mostly plumbing.

### 4. Tax-loss and gain harvesting
Kuvera makes this a headline feature: sell up to ₹1.25 lakh of long-term gains
a year to use the exemption, or realise losses to offset. We compute the tax
and the exemption and stop short of suggesting the action.

**Effort:** small, and it slots directly into the FIX tier. This is the most
under-built thing on the list relative to how easy it is.

### 5. Export and portability
MProfit and others make clean export a selling point, and at least one
comparison names lock-in as a reason to avoid a platform. We have none.

**Effort:** small. It is also the right thing to do.

### 6. Succession and nominee information
"Ensures your family can access your wealth if something happens" appears in
comparisons as a real criterion. We hold nothing about nominees.

**Effort:** small to capture, and worth pairing with the protection gap the
engine already computes.

### 7. International holdings
INDmoney and Kuvera both carry US equities; Agni Folio does multi-currency.
Our gap analysis tells people they hold nothing outside one economy and then
cannot help them hold anything.

**Effort:** large. Probably not ours to solve — the group's data service would
need international pricing.

### 8. Conversational access
INDmoney exposes an MCP server so an assistant can answer questions against a
real portfolio. Chat-based analysis is becoming an expectation rather than a
differentiator.

**Effort:** moderate, and unusually well-suited to us: every number we produce
already carries its reasoning in prose, which is exactly what such an interface
needs and what most platforms have to generate after the fact.

## What we have that they do not

Worth being clear about, because it decides what to protect while closing gaps.

**Behaviour read from transactions.** Whether somebody kept investing through a
fall, where in a fund's range their purchases landed, whether their instalments
are automatic or chosen. No competitor reads this. It is the basis of the fund-
fit reading and of half the decision engine's tone.

**Verdicts against a peer set rather than a threshold.** A P/E of 63 is
expensive at a fixed band and average in capital goods. Every comparison
platform we found uses fixed bands.

**Recommendations withheld, with the reason.** "We considered telling you to
rebalance and decided not to, because you have two months of expenses saved."
Nobody else shows their refusals.

**A stated methodology, including the refusals.** No forecasts, no composite
score, no alpha where beta does not describe the holding. Competitors publish
scores without derivations.

**The hierarchy.** Protect before fix before optimise. Others rank findings by
size, which puts a sector concentration above an empty emergency fund.

**Vernacular.** Three languages of the actual analysis, seven more scoped. No
competitor found offers analysis in anything but English.

**And the engine as a service.** None of the aggregators expose their
reasoning to other products. Ours is a keyed endpoint with a contract.

## What to build, in order

**First, because they are cheap and visibly missing:**

1. Liabilities on the dashboard and in the net-worth figure
2. Tax harvesting as a FIX-tier action
3. Export — CSV and JSON of everything we hold on somebody

**Second, because they change who the product is for:**

4. Family and household view
5. NPS through the CAS parser, then EPF

**Third, because it is where the market is going:**

6. Conversational access, which our prose-first outputs suit unusually well

**Not now:** international holdings, ESOP vesting, bank linking. Each needs an
integration we do not control, and none is what makes somebody choose us.

## What not to copy

**Health scores out of a hundred.** Several competitors lead with one. We
decided against it and the reasoning stands: a composite needs weights nobody
can derive and cannot be taken apart by its reader.

**Prediction accuracy claims.** At least one platform advertises 85% accuracy
in forecasting client needs 12–18 months ahead. That is not a checkable claim
and making one would undo the methodology page.

**Regular plans by default.** Named in comparisons as the clearest sign a
platform works against its user. We detect them and say what they cost, which
is the opposite position and worth keeping.
