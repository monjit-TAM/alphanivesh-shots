# Two things on the data service

*For whoever owns alpha-data-service and the AMC disclosure pipeline.
29 August 2026.*

Two issues found while building against the service, both in the AMC
disclosure pipeline, and one withdrawn correction.

I had reported a third — a sort order in the montecarlo query — and I was
wrong about it. The entry is left in with the correction rather than deleted,
since the original observation that prompted it is still unexplained.

---

## 1. The montecarlo endpoint — withdrawn

**This one was my mistake and I am leaving the correction in rather than
deleting the entry.**

I read this as a reversed return series:

```sql
SELECT DISTINCT ON (date_trunc('month', nav_date)) ... 
ORDER BY date_trunc('month', nav_date), nav_date DESC
```

It is not. `DISTINCT ON` keeps the first row per group as ordered, so
`nav_date DESC` selects the **last** NAV in each month — the month-end figure
the code says it wants. One row per month, ascending. The query is correct and
the `DESC` is doing necessary work.

**What remains open** is the original observation that prompted this: an
earlier session saw ₹24 lakh of contributions project to ₹24.8 lakh, which is
not what this query would produce if the rest of the simulation is sound. That
symptom is real and the cause is not the sort order. Worth someone looking at
the simulation loop rather than the query, if it reproduces.

Apologies for the noise.

---

## 2. AMC holdings disclosures: most schemes have one filing date

**Urgency: high. This blocks the single best feature on our roadmap.**

```
4,844 schemes in mf_scheme_holdings
3,775 have exactly one as_of date
  997 have two or more dates with weights
   72 have two or more dates without weights
```

On real investor portfolios that works out to **one fund in six** having a
comparable previous month. We built the feature that uses it and it reports
coverage of 3% to 16%, which is not something we can put in front of anybody.

**What it blocks.** The strongest idea on our list: telling an investor that
three of their funds bought a company they already own directly, so their
exposure went from 25% to 31% without a decision on their part. No aggregator
in the Indian market shows this, because it needs both the direct holdings and
month-over-month fund disclosures. We have the first and one sixth of the
second.

**What would help, in order:**

1. **Backfill the historical filings.** AMFI and the AMC sites publish monthly
   portfolio disclosures going back years. If the ingest only ever stored the
   latest, the history exists and has not been kept.
2. **Keep every month going forward** rather than overwriting.
3. **Tell us what the ceiling is.** If some AMCs genuinely do not publish
   comparably, we would rather label the coverage honestly than keep hoping.

---

## 3. `weight_pct` is not a percentage for every AMC

**Urgency: medium. It has already made one feature unusable.**

The column holds different things depending on the fund house. For some it is
a percentage summing near 100. For others it is not, and the sums are
implausible:

- Scheme 100119 on one date: 251 holdings summing to **8,056**
- Some AMCs publish holdings with no percentage at all — the field is null and
  the composition cannot be derived

**Affects:** `/data/mf/portfolio-insights`, which we parked as unusable, and
anything else that assumes the column is a percentage.

**What would help.** Either normalise on ingest — derive the percentage from
market value over the fund's total where the published figure is unreliable —
or add a flag saying whether the column can be trusted for a given scheme and
date. The second is less work and would be enough: we can skip what we cannot
use, as long as we know which is which.

---

## Why these two together

They share a root: the AMC disclosure pipeline does not keep history and does
not normalise what it keeps. **Fixing them unlocks the look-through, the
monthly change engine, and honest fund composition** — three features, all
built or half-built on our side, all waiting on the same ingest.

Happy to go through any of it in detail, and happy to help with the backfill if
that is useful — the parsing is the hard part and we have done some of it.

---

## What we can offer back

We now compute several things from the same underlying data that may be worth
having on your side:

- **Peer quartiles from the category distribution** rather than a stored rank —
  `cat_rank` is populated for 1,995 of 4,485 rows, and computing from
  `roll3_median` covers 2,958
- **Block-bootstrap projections** with the drift anchored toward a long-run
  assumption, which avoids the trap of projecting a bull market forward
  indefinitely
- **A working note on that trap**, if it is useful: resampling five years of an
  exceptional run gave one real portfolio a 21% annual return sustained for a
  decade and a zero per cent chance of loss. Any projection built on a short
  window has this problem.


## The ETF chooser has no debt instruments

*Found 5 September 2026.*

`/data/etf/chooser?horizon=3y` returns four buckets — **broad**, **factor**,
**gold**, **intl** — and nothing debt-shaped. No bond fund, no gilt fund, no
liquid or overnight fund.

**What that breaks here.** Two pieces of advice can state a need and cannot
name anything to meet it:

- *"You hold nothing that rises when equities fall"* — we can say the gap
  exists and cannot say what fills it.
- *"Bring the mix back towards what you chose"* — on a portfolio five lakh
  under its bond target, we can size the gap and not name a fund.

Both currently tell the investor to place it themselves, with the reason.

**What would fix it.** A `debt` bucket in the chooser carrying a few liquid
bond, gilt and overnight funds with the same shape as the others — symbol,
name, turnover. Three or four is plenty; the point is naming something rather
than offering a range.

**Not urgent for equities**, which the chooser covers well. Urgent for anybody
whose advice is mostly "hold something that is not equity", which is most
people over fifty.
