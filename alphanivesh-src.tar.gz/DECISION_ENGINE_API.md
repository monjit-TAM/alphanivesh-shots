# The decision engine, as a service

*What a caller sends, what comes back, and why the boundary sits where it
does.*

## The problem this solves

Every product in the group answers a piece of "what should this person do".
The stocks product ranks shares. The MF product reads funds. The AIF product
reports institutional portfolios. None of them can answer the question the
investor actually has, because that question needs all of it at once: a
brilliant equity recommendation is the wrong advice for somebody with two
months of expenses in the bank and a credit card at 40%.

So the engine takes a complete picture and returns an ordered answer, and any
product can call it.

## Why it takes the picture rather than fetching it

The obvious design is an investor id and a shared database. It is the wrong
one for three reasons.

**The products do not share a database.** AlphaNivesh has
`v_current_holdings`, the MF product has portfolios, the stocks product has
broker positions. An engine reading one of them serves one of them.

**A caller often has more than a database does.** A broker knows the client's
income from their KYC. An RIA knows their goals from a conversation. Making
those parameters means they can be supplied; making them a database read means
they cannot.

**And a stateless engine can be tested.** A picture in, a decision out, no
hidden state — so the same picture always produces the same answer, and a
disagreement between two products is a difference in what they sent rather
than a mystery.

## What a caller sends

```json
POST /api/v1/decide
X-API-Key: ...

{
  "investor": {
    "age": 42,
    "dependants": 2,
    "monthly_income": 200000,
    "monthly_expenses": 90000,
    "emergency_fund_months": 2,
    "life_cover": 5000000,
    "investment_horizon_years": 15,
    "stated_style": "growth"
  },

  "holdings": [
    {"kind": "equity", "symbol": "THERMAX", "quantity": 200,
     "buy_price": 3641, "buy_date": "2024-03-10", "current_value": 793000},
    {"kind": "mutual_fund", "scheme_code": "102941", "units": 5641.926,
     "current_value": 1375670, "invested_value": 1275372,
     "first_bought": "2023-04-12"},
    {"kind": "fixed_deposit", "current_value": 500000,
     "rate_pct": 7.1, "matures_on": "2027-06-01"}
  ],

  "liabilities": [
    {"kind": "home_loan", "outstanding": 3400000, "rate_pct": 8.6,
     "monthly_emi": 32000},
    {"kind": "credit_card", "outstanding": 85000, "rate_pct": 42}
  ],

  "goals": [
    {"name": "Retirement", "target_amount": 50000000,
     "target_date": "2045-04-01", "priority": "essential",
     "monthly_contribution": 40000}
  ],

  "transactions": [
    {"date": "2025-08-01", "kind": "purchase", "amount": 10000,
     "scheme_code": "102941", "units": 44.2, "price": 226.05}
  ],

  "target_allocation": {"equity": 60, "mutual_fund": 30, "bond": 10}
}
```

**Only `holdings` is required.** Everything else improves the answer and its
absence is reported rather than assumed: an engine told nothing about debt
should say so, not proceed as though there is none.

## What comes back

```json
{
  "health": {
    "urgent": 1, "leaking": 3, "shape": 2,
    "working": ["The portfolio is ahead of what went into it."],
    "reading": "1 thing here needs attention before anything else matters.",
    "why_not_a_score": "..."
  },

  "risk": {
    "ceiling": 3, "name": "moderate", "binding": "tolerance",
    "capacity": {"band": 4, "reasons": [...]},
    "tolerance": {"band": 3, "evidence": [...]},
    "why": "Financially you could carry more than the record suggests..."
  },

  "by_tier": [
    {"tier": 1, "name": "Protect what you have",
     "why_this_tier": "These come first because they can undo everything else.",
     "actions": [
       {"what": "Clear the credit card at 42% before investing more.",
        "why": "₹85,000 at 42% is a guaranteed 42% cost...",
        "how": "Every spare rupee at the highest rate first.",
        "impact": "A certain 42% return, which no fund can promise.",
        "risk": "Money used to repay is money not invested.",
        "costs": "...", "worth": "...",
        "evidence": {"annual_saving": "35700", "basis": "interest_rate"},
        "source": "Your recorded liabilities.",
        "confidence": "firm",
        "guardrails": [{"name": "liquidity", "holds": true, "detail": "..."}]}
     ]}
  ],

  "withheld": [
    {"what": "Reduce the 63% in capital goods.", "tier": 3,
     "why_not": ["2 months of expenses set aside. Actions that reduce
                  available cash are held back until that is closer to six."]}
  ],

  "data_quality": {
    "known": [...], "missing": ["what you owe", "your goals"],
    "completeness_pct": 55, "confidence": "reasonable",
    "reading": "This rests on 5 of 9 things worth knowing about you."
  },

  "review_on": {"months": 3, "why": "...", "sooner_if": [...]}
}
```

### The parts worth understanding

**`by_tier` is the answer.** Protect, fix, optimise, invest, review — in that
order, always. A caller displaying them out of order is showing a different
answer from the one the engine gave.

**`withheld` is not an error list.** It is what was considered and not
suggested, with the reason. "We thought about telling you to rebalance and
decided not to, because you have two months of expenses saved" is more useful
than silence, and it is the audit trail when somebody asks why an obvious
recommendation is missing.

**`data_quality` should be shown.** Confidence in a recommendation is mostly
confidence in its inputs. A product that displays the actions and hides the
completeness is asking to be trusted on the strength of its tone.

**And "do nothing" is a real answer.** An empty `by_tier` with a health
reading saying nothing needs doing is the engine working, not failing.

## What the engine will not do

These are refusals rather than gaps, and a caller should not work around them.

**No forecasts.** Base rates from history, with the number of windows attached.
Never a direction.

**No composite score.** Health is a count that opens into the things counted.
A single number needs weights nobody can derive and cannot be taken apart by
the person reading it.

**No alpha where beta does not describe the holding.** Reported only above 50%
R-squared. Below that it is the residual of a model that does not fit, and
reads as skill.

**No recommendation that fails a guardrail.** Not shown with a warning —
withheld, with the reason in `withheld`.

**And no product recommendation before the need is established.** The order is
need first, then allocation, then product. A caller wanting only fund picks
should call the screener; this engine will decline to reach step ten without
steps one through nine.

## Errors

| Code | Meaning |
|---|---|
| 400 | `holdings` missing or empty |
| 401 | key missing or unknown |
| 422 | a holding is missing `kind` or `current_value` |
| 429 | rate limited |
| 500 | engine fault, with the reason in `detail` |

A picture that is thin but valid is not an error. It returns a decision with
`data_quality.confidence` set to `thin` and the missing pieces named.

## Where the inputs come from

| Input | Who has it |
|---|---|
| Holdings | Every product. Brokers from positions, AlphaNivesh from statements, the MF product from CAS |
| Transactions | AlphaNivesh and the MF product. Brokers have trades |
| Income, expenses, dependants | KYC for a broker, a conversation for an RIA, a form for AlphaNivesh |
| Liabilities | Rarely held anywhere. Usually has to be asked for |
| Goals | RIAs mostly. Worth asking |
| Target allocation | Whoever set one |

The engine's own reference data — fund NAVs, scheme ranks, sector medians,
benchmark history, stock verdicts — is fetched internally from the shared data
service and the rebalance engine. A caller does not supply it and should not
have to know it exists.

## Calling it

```python
import requests

decision = requests.post(
    "https://<host>/api/v1/decide",
    headers={"X-API-Key": key, "Content-Type": "application/json"},
    json={"holdings": holdings, "investor": profile, "goals": goals},
    timeout=30,
).json()

for tier in decision["by_tier"]:
    print(tier["name"])
    for action in tier["actions"]:
        print(" ", action["what"])
        print("   why:", action["why"])
```

Response time is four to twenty seconds depending on how many holdings need
pricing and whether the stock verdicts are cached. Set a thirty-second timeout.
