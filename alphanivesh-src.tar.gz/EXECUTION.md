# Execution: what is built and what comes next

*1 September 2026. Supersedes part two of NEXT_LEG.md, which was written
before the adviser-of-record question was answered.*

---

## The arrangement

AlphaVerse is a technology platform. Its own RIA registration is in progress.

Until it comes through, **the adviser of record on anything an investor acts
upon is the registered adviser whose relationship they are in** — in practice
a broker on the Kambala platform, using their licence, with our reasoning
behind it. We share the logic so they can answer for it, and we keep the logs.

**This holds only if the record says so at the time.** Reconstructing
attribution afterwards from whoever the investor happened to be with is the
kind of record-making that does not survive being asked about. That is why the
adviser is resolved and written when the advice is given, not looked up later.

**The exposure worth naming.** Where an investor signs into alphanivesh.com,
reads a recommendation, and acts on it with no registered adviser in the
relationship, "we are just technology" is a weak position — the logs would show
the advice came from us. Every investor who can act on what they see needs a
mandate recorded. The unattributed count is the measure of how far that is from
true, and it stands at 258 rows across two investors.

---

## Built

**`adviser` and `advisory_mandate`** — who is registered, between which dates,
and which investor is with them. One current mandate each, so "who advised
this" has one answer.

**`advice_ledger.adviser_id`** — every row carries it, resolved at write time
so a caller that forgets cannot quietly write an unattributed one.

**`advice_override`** — where the adviser changed, withheld or added to what
the engine produced. Both versions kept, a reason required, lapsing after a
week and the moment the underlying figures change.

**`advice_shown`** — what went in front of somebody on a date, so today can be
compared with yesterday.

**`professional` and `client_of`** — what somebody is registered as, the
certificate behind it, and whose clients they are. Rights computed from the
registration every time.

---

## The permission model

| | RIA | Research Analyst | MFD |
|---|---|---|---|
| Sees their clients | yes | yes | yes |
| Sees what the engine produced | yes | yes | yes, as information |
| Edits, suppresses, adds | **yes** | no | no |
| Is the adviser of record | **yes** | no | no |
| Transacts | yes | no | funds only |

**An MFD may not advise.** Distribution and advice are separate registrations
and this platform does not blur them. For an MFD's clients the engine's output
is information, and it is presented to them as information rather than as a
recommendation.

---

## What comes next, in order

### 1. The adviser's dashboard *(an evening)*

The client book exists as an endpoint and has no page. Everything below assumes
an adviser can see their clients, which they currently cannot.

Each client with: what they hold, what is outstanding, when they last looked,
and whether consent to see the portfolio is recorded. Consent first, because
seeing somebody's holdings without it is the problem that matters most.

### 2. The registration queue *(an hour)*

`/api/professional/waiting` lists what needs checking; admin has no tab. Until
it does, nobody can accept a certificate and no adviser can be activated.

### 3. Consent, per order *(the important one)*

Under an advisory licence, execution is the investor's decision. Not "they
agreed to the plan" — **this order, this quantity, this moment, recorded**, and
tied to the ledger row that advised it.

That evidence is the difference between an adviser with an execution partner
and unauthorised portfolio management. The chain then runs end to end: what was
advised, on what basis, under whose registration, what the adviser changed,
what the investor agreed to, what was placed, what came back.

**That is a stronger audit position than most licensed firms have**, and it
comes almost free because the ledger was built before the advice was.

### 4. One venue, end to end

**BSE StAR first.** The funds protocol is simpler than the equities one, most
of the advice is about funds, and a working single venue is worth more than two
half-built ones.

Then Kambala for equities. The SSO and the PlaceOrder authentication were
resolved on AlphaMarket in June — `Authorization: Bearer TOKEN`, no jKey in the
body. Reuse rather than rebuild.

### 5. Confirmations and reconciliation

An order comes back with a fill price and quantity, reconciled against the
instruction. Three outcomes: filled as instructed, filled differently, not
filled. The second needs saying loudly — a partial fill nobody notices leaves a
portfolio halfway through a rebalance.

---

## Open questions

**Do the 258 unattributed rows get back-filled?** My view is no: they were
given before any mandate existed, and attributing them to a firm that was not
advising at the time is exactly the after-the-fact record-making this design
avoids. Worth a word with Pradnya.

**What does Kambala require in an instruction payload, and what do they return?**
Not answerable from here.

**And who signs off a certificate?** The endpoint requires an admin. Whether
that should be one named person, and whether the check needs recording against
the AMFI or SEBI register rather than just the document, is a process question
rather than a code one.
