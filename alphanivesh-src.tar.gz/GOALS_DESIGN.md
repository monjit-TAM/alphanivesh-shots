# Goals

*Design, 11 September 2026. Written before the code, because the mistakes in
this module are the kind that get built in and cannot be taken out.*

---

## The problem with every goal calculator

They all do the same thing. Take a target, assume twelve per cent a year,
compound it, and draw a smooth curve arriving at ₹2.4 crore in 2045.

It is the most confident screen in wealthtech and the least honest. One assumed
rate, no distribution, no acknowledgement that the rate is a guess — and the
curve is smooth, which no portfolio has ever been.

**This platform refuses that everywhere else.** The projection declines when a
portfolio's recent run is too good to extrapolate from. The XIRR refuses below
six cashflows. The value chart refuses when the record carries one figure
forward for ten months. If the goal module says "you will have ₹2.4 crore", it
contradicts the rest of the product on its most visible screen, and a reader
who notices stops believing the rest.

**So: no forecast.** The question "will I get there" is answered with base
rates from what actually happened, not with a projection.

> You need ₹2.4 crore in eighteen years. You have ₹31 lakh earmarked and are
> adding ₹40,000 a month. Starting from every month since 2005, that
> combination reached the target in 71% of eighteen-year stretches. In the
> worst tenth it fell short by ₹38 lakh. The median finish was ₹2.9 crore.

Same question. Checkable answer. No fiction.

---

## What a goal is

**A decision, and a position.** They are different and are stored differently.

**The decision persists.** What the goal is, what it costs, when it is needed,
in which currency, which holdings are earmarked to it, and what is committed
monthly. A person chose these and they should not drift.

**The position recomputes, every time.** What those holdings are worth today,
how many years remain, what the base rates say now, where the rupee is. Never
stored, never cached.

That split is what makes the plan fluid without making it forgetful. When the
module says *"you were comfortable in March and you are tight now"*, it can
name the cause — the market fell, the rupee moved, or the contributions
stopped — rather than showing a different number and leaving somebody to guess
which.

---

## Earmarking

**A goal claims specific holdings, not a share of the portfolio.**

The lazy version is a percentage: retirement gets 60% of everything. It is
easier and it lies in two directions — it lets the same rupee fund three goals,
and it cannot tell somebody that the money for next year's school fees is in a
small-cap fund.

**So: rows.** A holding, a goal, and how much of it. A holding can be split
across goals; the sum across goals cannot exceed it, and the software enforces
that rather than trusting it.

**What earmarking buys us that nothing else does:**

*The mismatch test.* Money needed in eleven months sitting in equity is the
single most common real error in personal finance, and only earmarking can see
it. A percentage model cannot distinguish the fund that is for retirement from
the fund that is for the deposit.

*Honest competition.* Three goals wanting the same holding is visible
immediately rather than after a spreadsheet.

*Real progress.* "You have 43% of what this needs" means the earmarked
holdings are worth 43% of the target, not that some fraction of the portfolio
happens to equal it.

**Unearmarked holdings stay unearmarked.** Not silently swept into retirement.
"₹18 lakh is not assigned to anything" is a useful sentence and a common
situation.

---

## The base-rate engine

The heart of it. For a goal N years out, funded by a mix of assets:

**Replay, do not project.** Take every historical starting month for which N
years of data exist. For each: apply the actual returns of an equivalent mix,
add the monthly contribution as it would have been added, and see where it
finished. That gives a distribution of outcomes, all of which happened.

**What comes out:**

- How many of those stretches reached the target
- The worst, the tenth percentile, the median, the best
- The shortfall in the bad cases, in rupees
- How many stretches existed — thirty is thin, two hundred is not, and the
  number should be on the screen

**Where the data does not support it, refuse.** A goal eighteen years out needs
eighteen-year windows. If the data starts in 2005 there are about 250 monthly
starts, which is enough. For a thirty-year retirement there may be forty, and
the module should say the sample is thin rather than quietly computing on it.

**The mix matters and changes.** Somebody thirty-five today will not hold the
same mix at sixty. The replay should use the mix they hold now for the near
term, and where a glide path is agreed, the mix they intend later. Assuming
today's mix for thirty years is a modelling choice and should be stated as one.

---

## Currency

**A rupee plan for a dollar cost is a different problem**, and education abroad
is the common case.

**The goal is denominated in what it costs.** A US masters costs $120,000, not
₹1 crore. Stored in USD, with the rupee figure shown at today's rate and
marked as today's rate.

**The replay includes the exchange rate.** For each historical window, the
target in rupees is the foreign cost at the rate *at the end of that window*,
not today's. A person funding a dollar cost from rupee assets has two things
moving and the model must move both.

**Which changes the answer materially.** The rupee has lost ground against the
dollar over most long stretches. A plan that looks comfortable at today's rate
can fail at a rate the rupee has actually traded at, and showing that is the
whole point of modelling it.

**And it is said in words as well as modelled**, because a distribution does
not tell somebody *"your costs are in dollars and your savings are in rupees,
and the gap between them has widened in most decades"*.

---

## Goals competing

**Show everything. Rank nothing.**

The module's job is to make the conflict visible, not to resolve it. Whether
retirement matters more than a house is not a question a calculation can
answer, and a product that answers it is substituting its judgement for the
person's on the one question that is entirely theirs.

**What that means in practice:**

*Committed against spare.* If the monthly contributions across all goals exceed
what the person has spare, say so, with the number. Do not silently scale them
down.

*Earmarks against holdings.* If three goals claim the same fund, refuse the
third rather than over-allocating.

*And the trade, stated.* "Fully funding the house deposit leaves retirement
reaching its target in 41% of stretches instead of 71%." That is the sentence
somebody needs. It is not a recommendation; it is what the choice costs.

---

## Being fluid

The plan absorbs what happens rather than being redrawn.

**Every position figure is computed fresh.** Nothing about where you stand is
stored.

**What changed since last time is derived**, by comparing today's computation
against the last one recorded. Three causes, and they should be told apart:
the market moved, the plan changed, or the contributions did or did not arrive.

**The near ones get louder.** A goal eighteen years out barely reacts to a bad
quarter, and should not. A goal eleven months out reacts to everything, and the
module should say so — a shortfall at eleven months is a problem to solve now,
the same shortfall at eighteen years is noise.

**And the mismatch check runs every time.** Money needed inside three years
sitting in equity is worth saying on every visit until it is fixed or
acknowledged.

---

## What it must never do

**Promise a number.** Not "you will have ₹2.4 crore". Ever.

**Quietly assume a return.** If a rate is used anywhere, it is labelled and its
source given.

**Rank goals**, or nudge towards one.

**Hide the sample size.** A base rate from forty windows and one from four
hundred are different claims.

**Recommend an instrument.** That crosses into advice and belongs behind the
adviser tier, same as everything else that names something to buy.

---

## Build order

1. **Schema** — goals, earmarks, contributions, and the snapshot of each
   computation so change can be told.
2. **The earmark engine** — assign, split, enforce the sum, report what is
   unassigned.
3. **The base-rate replay** — historical windows for a given mix and horizon,
   with the sample size and the refusal when it is too thin.
4. **Currency** — foreign-denominated goals with the rate replayed.
5. **Competition** — committed against spare, earmarks against holdings, and
   the cost of each choice stated.
6. **The pages** — a goal, all goals, and the conflict view.
7. **Change over time** — what moved since last time and why.

Each is useful on its own, and each is honest without the ones after it.
