# Google sign-in: what to do

*Ten minutes in the Google Cloud Console, then two lines in `.env`. The code is
already built and waiting for the credentials.*

---

## 1. A project

console.cloud.google.com → the project dropdown at the top → **New Project**.

Call it **AlphaNivesh**. If AlphaVerse already has a Google Cloud project, use
that instead — one project can hold several sign-in clients.

---

## 2. The consent screen

**APIs & Services → OAuth consent screen.**

This is what somebody sees when they click "Continue with Google". It says who
is asking and what for, so it is worth filling in properly rather than
minimally.

- **User Type: External.** Internal only works for a Google Workspace domain
  and would lock out every ordinary investor.
- **App name:** AlphaNivesh
- **User support email:** hello@alphaverse.world
- **App logo:** optional, and worth adding — an unbranded consent screen asking
  for access to somebody's Google account looks like exactly what people are
  told to be suspicious of.
- **Application home page:** https://alphanivesh.com
- **Privacy policy** and **Terms of service:** required before Google will let
  you out of testing mode. If those pages do not exist yet, this is the point
  at which they need to.
- **Authorised domains:** `alphanivesh.com`
- **Developer contact:** your address

**Scopes:** add only `openid`, `email` and `profile`. Nothing else — asking for
more than sign-in needs triggers Google's verification review and makes the
consent screen alarming for no benefit.

**Test users:** while the app is in testing, only addresses listed here can
sign in. Add your own and Amit's. Publishing to production removes the limit
and may require Google's review depending on the scopes — with these three it
usually does not.

---

## 3. The credentials

**APIs & Services → Credentials → Create Credentials → OAuth client ID.**

- **Application type:** Web application
- **Name:** AlphaNivesh web

**Authorised JavaScript origins:**
```
https://alphanivesh.com
```

**Authorised redirect URIs** — this must match exactly, including the scheme
and every character of the path:
```
https://alphanivesh.com/api/account/google/callback
```

Google will reject the sign-in with `redirect_uri_mismatch` if this differs by
so much as a trailing slash. It is the single most common thing to get wrong.

Press Create. You get a **Client ID** ending in
`.apps.googleusercontent.com` and a **Client secret**.

---

## 4. On the server

```bash
cd /opt/alphawealth
cat >> .env << 'EOF'
GOOGLE_CLIENT_ID=<the client id>
GOOGLE_CLIENT_SECRET=<the client secret>
EOF
systemctl restart alphanivesh-api
```

Then check it took:

```bash
curl -sk https://127.0.0.1/api/account/providers -H "Host: alphanivesh.com"
```

`{"google": true}` means the button will appear on the sign-in page. Until
then it stays hidden, which is deliberate — a button that returns a 503 is
worse than no button.

---

## 5. Test it

Open **alphanivesh.com/signin.html** in a private window. "Continue with
Google" should be under the password form.

**What should happen:** Google's account chooser, then back to the dashboard
signed in.

**If it fails**, the sign-in page will show why rather than a stack trace. The
two common ones:

- **redirect_uri_mismatch** — the URI in the console does not exactly match
  `https://alphanivesh.com/api/account/google/callback`.
- **access_blocked** — the app is in testing and the address is not on the test
  user list.

---

## What the code already does

**Joins an existing account only when Google says the address is verified.**
Google reports unverified addresses honestly, and treating that as good enough
would let somebody who registers the same address at a careless provider walk
into an account here.

**Signs the state parameter and expires it in five minutes**, so a sign-in
cannot be started by one person and finished by another.

**Refuses to redirect anywhere but this site** after signing in, so the flow
cannot be turned into a way of sending people elsewhere with our name on it.

**Asks which account every time** rather than silently reusing whichever the
browser last used — somebody with two Google accounts gets to choose, and on a
shared machine the alternative signs them in as whoever was there before.

---

## One thing worth deciding

Somebody who signs up with Google has no password. If they later want to sign
in with one, there is no flow for it yet — they would have to use the
forgotten-password link, which works because the reset flow sets a password on
an account that has none.

That is a reasonable answer and it is not an obvious one from the interface.
Worth a line on the sign-in page if people start asking.
