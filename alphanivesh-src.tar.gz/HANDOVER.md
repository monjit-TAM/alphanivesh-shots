# AlphaNivesh — Handover

*Written 23 August, revised through 26 August. For whoever picks
this up next, including me. Read §1 and §9 if you read nothing else.*

---

## 1. What this is, in one page

**AlphaNivesh is live at https://alphanivesh.com.** A person can sign up, bring
in a consolidated account statement, add the holdings a statement never sees,
tell us about their circumstances, and get computed findings about what their
portfolio is doing — each one showing the arithmetic behind it.

The conviction behind it, from `VISION.md`: Indians can already see what they
own. Nobody tells them what it *means*. That is a comprehension problem, not an
information problem, and it is what this product exists to solve.

**Everything is real.** No stubs, no mock data on any live path. A real CAMS
statement has been through it end to end.

| | |
|---|---|
| **Live** | https://alphanivesh.com |
| **Code** | github.com/monjit-TAM/alphanivesh (private) |
| **Server** | `alphanivesh-core`, DigitalOcean BLR1, 64.227.180.75 |
| **SSH** | `ssh alphawealth` (alias on the Mac) |
| **Service** | `systemctl status alphanivesh-api` |
| **Database** | `alphawealth_db` on the same box, PostgreSQL 16 |

---

## 2. Getting oriented in five minutes

```bash
ssh alphawealth
cd /opt/alphawealth

systemctl status alphanivesh-api        # the API
git log --oneline                       # where the code is
ls migrations/                          # 001 to 007, applied in order

sudo -u postgres psql -d alphawealth_db -c "
SELECT i.display_name, count(*) positions,
       to_char(sum(v.current_value),'FM99,99,99,999') net_worth
FROM v_current_holdings v JOIN investors i ON i.id=v.investor_id
GROUP BY 1 ORDER BY sum(v.current_value) DESC;"
```

Five investors, largest ₹57.6 lakh. Four came from the AlphaLensMF migration,
one from a live statement upload.

**Deploying a change** is: edit locally, `scp` to `/tmp`, unpack into
`/opt/alphawealth`, `systemctl restart alphanivesh-api`. Static pages just need
copying into `/opt/alphawealth/web/`; nginx serves them with `no-cache` so a
browser will not hold yesterday's build.

---

## 3. The shape of it

```
/opt/alphawealth/
    api/
        main.py                 app, CORS, lifespan
        db.py                   pool, opened lazily
        routers/                HTTP only, no logic
            auth.py             register, login, logout, me
            wealth.py           net worth, allocation, holdings, returns, timeline
            findings.py         computed observations
            imports.py          four ways to bring a statement in
            manual.py           entering holdings, instrument search
            profile.py          circumstances and goals
            merge.py            folding two records that are one person
        services/               where the work happens
            wealth.py           consolidation and XIRR
            findings.py         thirteen findings, and the ranking
            profile.py          profile, goals, capability flags
            manual.py           manual entry, asset class forms, search
            statement_mapper.py CASParser output into canonical
            casparser.py        the parsing client
            auth.py             sessions and access scope
            merge.py            investor merge
    migrations/                 001..007
    web/                        static, no build step
    scripts_load_instruments.py    AMFI schemes, nightly
    scripts_dedupe_instruments.py  fold registrar naming differences
    .env                        CASParser key (not in git)
```

**Routers hold no logic.** They validate, call a service, return. Anything worth
testing lives in `services/`, which is why the services can be exercised without
starting the API — and how most of the testing in these two days was done.

---

## 4. The data model, and why it is like that

Seven migrations. The decisions worth understanding:

**`investors` is not `users`.** An investor is a person whose wealth we track;
a user is a login. An adviser's client may never sign in. PAN is stored as
`pan_hash` (SHA-256) plus `pan_last4`, never whole.

**`holding_snapshots` is append-only.** Point-in-time positions, never updated
in place. Current state is `v_current_holdings`, a view taking the latest per
(investor, instrument) with a source-precedence tie-break. This is what makes
"net worth on 31 March" answerable and what stops a re-import destroying
history.

**Accounts are keyed on `(investor, kind, number)` — not source.** A folio is
issued by the registrar, so the same folio arriving from a CAMS statement and a
KFintech one is one account. Getting this wrong double-counted everything;
migration 002 fixed it.

**Money is `numeric(20,6)`, dates are dates, timestamps carry zones.** All three
are things AlphaLensMF gets wrong — it stores money as `real`, which loses
precision above about a crore, and dates as text.

**`source_documents` keeps the raw payload**, deduplicated on a SHA-256 of the
content. Every number traces back to the document it came from, and a mapping
bug can be fixed and replayed without asking anyone to upload again.

---

## 5. What works, honestly assessed

### The dashboard

`/dash.html` is the product. `/app/` is the older card list, kept for comparison
and due to be retired.

The allocation band across the top is also the navigation: pressing a segment
filters the whole page to that asset class. Beneath it, cards claim different
widths so the grid reads as a composition rather than a stack, and the last card
in a row takes any columns the next one cannot fill.

**Headline** — invested, current, gain, and the yearly rate. Refuses to
annualise under two years, or where the rate comes out implausible, because both
mean the buying history is shorter than the gain it spans.

**How it has moved** — value at each month end, drawn as a line.

**Best and worst** — by percentage, so a small position that tripled is visible.

**Company size** — large, mid, small by the market's own definition: the largest
hundred, then the next hundred and fifty.

**How spread out** — twenty-three dots, seven filled. That is what "as spread out
as 7.4 holdings" means, drawn rather than described.

**Worth doing** — seventeen findings ranked by what is worth acting on. The one
that earns its place joins two facts nobody else puts together: a fund is 76% of
somebody's portfolio and has fallen 67.6% before, which is ₹72,465 and twenty
months of waiting.

**Against the market** — P/E, P/B, ROE and growth, each beside the cap-weighted
top hundred.

**How you invest** — value, growth or quantamental, explained plainly, with what
the holdings themselves suggest. Decides which verdict is marked as theirs, never
which are shown.

**Against simply buying the market** — the same cost in NIFTYBEES on the same day.
On real data: ₹33.98 lakh against ₹31.93 lakh, ahead by ₹2.05 lakh over five years.

**Where the risk is** — five axes, each carrying the figure that made it.

**If the market turned** — beta says a 20% fall costs ₹8.7 lakh; what the holdings
have each already done says ₹15.2 lakh. Both shown, because the gap is the point.

**Against the mix you set** — drift in points and in rupees to move.

**If you sold today** — tax split short and long, with positions near the
long-term boundary called out where the saving is material.

**How much it moves**, **what it pays you**, **industries**, then every holding.

### Inside a holding

A share shows what it costs, earns, owes and how it has grown — each figure
against its own sector — then three calls:

| Lens | Asks |
|---|---|
| Value | Are you paying a lot for what it earns and owns? |
| Growth | Is the business getting bigger, and how quickly? |
| Quantamental | Do the figures and the price behaviour agree? |

All three always shown. HAL reads buy on value and reduce on growth, and both
are correct — a tool showing one verdict is wrong for whichever investor it was
not built for.

A fund shows nine chapters, including what the manager actually bought and sold
between two disclosures.

### Bringing holdings in

| Route | State |
|---|---|
| Upload a statement | **Proven** — 5 folios, 360 transactions from a real CAMS file |
| A spreadsheet | **Proven** — eleven equity positions, priced live |
| Ask the registrar | Built, never exercised |
| Fetch from CDSL | Built, never exercised |
| Read a mailbox | Built, never exercised |
| Manual entry | Proven across ten asset classes |

### Where the data comes from

| | |
|---|---|
| Statements | CASParser |
| Fund NAVs | 122,610 daily prices held locally |
| Scheme master | 14,103 from AMFI |
| Company fundamentals | 2,329 companies |
| Benchmark | 1,317 NIFTYBEES closes back to April 2021 |
| Prices, fund research | **Alpha Data Service, `10.122.0.2:5004`, `X-API-Key`** |

### Not built

- **Vernacular.** Demonstrated on the homepage in five languages; no i18n layer.
  Everything since is written as text nodes with translation in mind.
- **A health score.** Deliberate: every input is already shown separately, and
  the composite would need weights nobody can derive.
- **Sector attribution past 41% of a portfolio.** Not our bug — five fund houses
  publish holdings without percentages and one sums to 8,169%.
- **Manager activity for most funds.** Needs two disclosures, which today means
  ICICI and Nippon.


## 5a. What the numbers rest on

Five bugs found on 25 August, all of which produced plausible figures from
broken inputs. Worth reading before trusting anything derived from a holding's
value or cost.

**Holdings were never matched to a scheme.** `resolve_instrument` tried the
ISIN, then the scheme code, then whether we already held the fund -- and
created a placeholder if all three missed. It never consulted the AMFI master,
so a statement giving neither identifier could not be matched however obvious
the answer. Fourteen of forty-nine fund holdings were in that state. Unmatched
means unpriced, so they showed whatever a statement said years ago: DSP Large
& Mid read as down 97%. Eleven now match; the rest are an AIF, a holding naming
neither plan nor option, and a parsing artefact.

**A trigram search with a LIMIT and no ORDER BY** returns a sample of the
matches rather than the best of them. Every ICICI lookup came back with forty
ICICI banking debt funds and never reached the fund being looked for. Two
services had it.

**The holdings view dropped folios.** `DISTINCT ON (investor_id, instrument_id)`
picks one row: somebody holding one fund across two folios saw only the larger,
and 1.48 lakh was absent from their net worth. Migration 002 had changed the
deduplication from per-account to per-investor to stop a fund appearing twice
in a list -- right for the list, wrong for the arithmetic. Migration 016 sums
them.

**Pricing wrote back at the wrong grain.** Snapshots are keyed on the account;
pricing read the view, which sums folios, and wrote against the single account
that row names. One folio got a current price and the other kept its statement
figure.

**A cost that could not have bought the units is not a cost.** A consolidated
statement reports what went into a scheme and not what came out, so a partly
redeemed folio carries the cost of everything ever bought against only the
units remaining. Nippon Arbitrage showed 604,320 against 2,519 units -- 240 a
unit, for a fund that has never traded above eleven -- and read as down 95%.
The redemptions are not in the transaction record, so the cost of the remaining
units cannot be computed. Those holdings are set aside from the gain, on both
sides, with the reason stated.

The pattern in all five: arithmetically correct output from incorrect input,
which is the class of error that survives review. Anything new that reads
`current_value` or `invested_value` should be checked against a portfolio with
partial redemptions and multiple folios before it is trusted.



## 5b. The recommendation engines elsewhere in the stack

Worth knowing before rebuilding anything here, because most of it has been
looked at and the conclusions are not obvious.

**stocks.alphamarket** — `generateValueAnalysis`, `generateGrowthAnalysis`,
`generateQuantamentalAnalysis` in `/var/www/alphalens-stocks/server/`. Each
starts at `score = 50` and adds fixed increments against fixed thresholds:
a P/E under 10 adds 25, over 50 subtracts 25, across every industry. The
quantamental one uses the investor's own profit-and-loss as its momentum
signal, so two people holding the same stock on the same day read differently
depending on when they bought.

`categorizeValuation` labels a P/E under 15 undervalued and over 40
overvalued, again across every sector. On a real portfolio that called Thermax
"Overvalued" at 63 when capital goods runs at 63, and HAL "Moderately
Expensive" at 37 when it is cheaper than its peers.

Not ported, deliberately. What AlphaNivesh does instead is compare every figure
to its own sector's median and report how many measures sit better or worse --
a count anybody can check rather than a score they have to trust.

**DYOR / testalpha** — `add_recommendation` and friends are advisor-authored:
a human writes the call, the system stores and distributes it. Not a computed
engine.

**market-scan-job.ts** on the Lightsail box — chart patterns across four
timeframes, 914 symbols, with entry, target and stoploss. Good at what it does
and a different problem: an hourly rising wedge with a 1.4% stoploss is a
trading signal, and this product's reader holds for years.

**thealphalens.com** — hosted at 13.205.245.225, which is none of the servers
we have access to, behind a repo the developer holds. Its dashboard routes
(structural metrics, concentration risk, volatility, health score, risk radar)
match what has been built here from computed data. **Whether its engine is
better than ours is the one open question**, and if it is, swapping is
contained: every verdict routes through `quantamental.verdicts()`.

**What is used rather than rebuilt:** the shared data service does the fund
ranking (`/data/mf/screener`, all weekly-stepped three-year windows, direct
plans), the fund research (`/data/mf/xray`, `activity`, `probability`), the
plan projection (`/data/mf/plan`) and every price. Those are good and calling
them is right.



## 5c. What was built on 25 August

**The guide** (`api/routers/guide.py`, rendered at the top of the dashboard).
Five movements: where you stand, what is wrong, what to do first and why that
first, the route to a goal, and what we could not see. The last is what keeps
it honest — any tool can produce a confident plan, and the difference is
whether it says what was missing when it made one.

**The advice page** (`/advice.html`, `api/routers/recommendations.py`). The
whole account: the good, the bad, the serious, what was missed, the actions in
order with what each costs and is worth, the holdings' verdicts, what the
portfolio does not have, what it would become, and the market. The actions and
the buy plan also appear inside the dashboard, so somebody looking at their
numbers sees what to do about them without leaving.

**The behavioural model** (`api/services/behaviour.py`). Whether money goes in
monthly or in lumps, whether it kept going when the market fell, where in each
fund's range the purchases landed, and how many separate decisions the
portfolio represents. What it cannot read — holding periods, whether losses are
cut — is stated rather than guessed, because the record holds one sale across
every investor.

The distinction that matters: a standing instruction cannot miss a fall, so
continuing through one means something different depending on whether it was
chosen or automatic. Praising both identically is flattery.

**Market base rates** (`api/services/market.py`). Where the market sits and
what followed readings like it, always with the number of windows attached.
Never a forecast. 318 overlapping windows from five years is five years of
history counted many times, and the caveat says so — 87% reads as a promise
otherwise.

**The rebalance engine** (`api/services/rebalance_engine.py`). Verdicts for
directly held shares now come from the AlphaMarket engine at
`stocks.alphamarket.co.in/api/v1/external/rebalance` — three pillars against
stated thresholds, with RSI, MACD, the 50/200 crossover, Supertrend and OBV
underneath. The same share reads the same here as in the broker report, which
is the point of not having a second opinion.

Our sector-relative measures stay as context beneath it. Their fundamental
pillar bands the P/E across every industry, which is how Thermax at 62 times
earnings reads as "very expensive" when its own sector trades at 63.

**The buy plan** (`api/services/buyplan.py`). The engine ranks and splits
evenly; on a real run that meant selling one listed financial services company
to buy eight micro-caps at six thousand rupees each, into a portfolio already
63% capital goods with nothing in banking. This adds the part a ranking cannot
know: a size mix with micro capped at one position, weight toward industries
the holder does not own, and positions large enough to matter.

**What is missing and what fills it** (`api/services/restructure.py`). Debt,
liquidity, gold, international, sector breadth — each with ranked options from
the shared screener and the reason each is on the list. Institutional plans,
bonus variants and thematic funds are excluded, and a fund whose worst
three-year stretch is strongly positive is flagged as untested rather than
reported as safe.

**Vernacular, partially** (`api/services/i18n.py`, `web/lang.js`,
`locales/*.json`). The mechanism works and three of ten languages are
translated — English, Hindi, Bengali, Marathi, 125 strings each. **Only the
chrome.** Every sentence with a figure in it is composed at runtime as an
f-string and is still English in every language. Roughly 120 such sentences
need turning into keyed templates with named placeholders before the remaining
seven languages are worth writing. No translation has been reviewed by a native
speaker and the interface says so.



## 5d. Translating generated prose

The mechanism: `api/services/i18n.py` holds catalogues in `locales/*.json`,
keyed. Services call `i18n.say("key", name=value)`. The language rides on a
context variable set by middleware per request, not passed as a parameter --
it is a property of the request rather than of the calculation.

**The rule that took two goes to find.** The noun phrase carries its own case
marking and the template supplies no postposition of its own.

    WRONG   template: "{share}% of your money is in {sector} मध्ये आहे"
            noun:     "भांडवली वस्तूंमध्ये"
            gives:    "भांडवली वस्तूंमध्ये मध्ये आहे"   -- "in" twice

    RIGHT   template: "तुमच्या पैशाचा {share}% {sector} आहे"
            noun:     "भांडवली वस्तूंमध्ये"

Hindi survives the wrong version because its postposition attaches
differently, which is exactly how the bug reaches production: it is written in
Hindi, checked in Hindi, and breaks in Bengali and Marathi where nobody is
looking.

**Every noun that arrives from the database needs a key too.** Sector names,
asset classes, the singular phrases in `_SINGULAR`. A sentence with one English
noun in it reads worse than the same sentence wholly in English, because the
reader can see the machine tried and stopped.

**What is converted:** all seventeen finding headlines, the sector and
concentration details, sector names, asset-class phrases. **What is not:** the
guide's five sections, the behavioural readings, the lens verdicts, the buy
plan reasons. Same mechanical shape, roughly seventy sentences.


## 5e. The fund-weight column that is not a percentage

Known since an earlier session and worth restating, because it surfaces
through more than one endpoint and each time looks like a new bug.

`mf_scheme_holdings.weight_pct` does not contain percentages for every AMC.
Scheme 100119 has 251 holdings on a single disclosure date summing to 8,056.
Five fund houses publish without percentages at all, and at least one publishes
something else in that column.

It surfaced first in sector attribution, where coverage sat at 41% of a
portfolio. It surfaced again through `/data/mf/portfolio-insights`, which
reported ICICI Bank at 81% of a portfolio and a total look-through of 784%.
The service's arithmetic is correct in both cases -- it filters to the latest
date and weights by fund size properly. The input is wrong.

Until it is fixed at the source, anything reading that column should check
whether the total is plausible and decline to display it otherwise. A
look-through that says something impossible is worse than one that says
nothing, because the reader cannot tell which of the other figures to trust.

## 5f. A LIKE pattern goes in the parameter

    WRONG   db.fetch_one("... WHERE name ILIKE '%Parag%' LIMIT 1")
    RIGHT   db.fetch_one("... WHERE name ILIKE %s LIMIT 1", ('%Parag%',))

psycopg reads % as a placeholder marker whether or not the query takes
parameters, so a literal pattern raises "only '%s', '%b', '%t' are allowed as
placeholders". Doubling it to %% works in a raw string and is the wrong habit:
the pattern belongs in the parameter, where it is also safe.

This has bitten three times, always in a throwaway diagnostic rather than in
the service code -- which is exactly where nobody thinks to be careful.


## 5g. What was built on 26 August

**The MF analysis migrated.** Fund behaviour (what a fund demands of whoever
holds it), the episodes holders sat through, what a monthly amount actually
became walking the published NAV path, the DNA factor percentiles, capital
gains computed lot by lot through the group's tax service, and the DNA board.

**Risk-adjusted ratios** (`api/services/ratios.py`). Sharpe, Sortino, alpha,
beta, up and down capture, tracking error and information ratio, from daily
prices against NIFTYBEES at a risk-free rate of 7% — the same rate
`analyzer.ts` uses, because the same fund reading differently in a broker
report and here is a reason to disbelieve both.

Works for shares as well as funds. `equity_prices` existed and was empty;
`scripts_load_equity_prices.py` fills it from the data service, 12,784 closes
across eleven symbols on first run.

**Alpha is reported only where beta describes the holding.** R-squared says how
much the market explains. Thermax is 6% explained and its alpha came out at 23%
a year: arithmetically correct and it would have been read as an edge. Parag
Parikh is 65% explained and its alpha is worth reading. Half is the threshold,
stated so somebody can argue with it.

**Whether somebody can hold what they own** (`api/services/fit.py`). What a
fund demands, against what the holder has actually sustained. Sandipdoshi chose
to keep buying through a fall, so SBI Midcap at 38/100 is a fund he can hold on
the record. Neetu's instalments ran through the same fall automatically —
the arrangement held, which is not the same as knowing she would have.

**The methodology page** (`/method.html` and folded into the dashboard). Where
every number comes from, what is estimated, and what the platform will not do.
That last section is the one to show an RIA.

**The holding card reads as a sequence** rather than an accumulation: what this
is, what it has done, what holding it involved, then the detail.


## 6. Traps

Things that cost hours and will again.

**CASParser's response has no envelope on success.** A failure returns
`{"status": "failed", "msg": ..., "data": {}}`. A success returns the statement
at the top level. Assuming an envelope in both cases rejected every good
response.

**The mutual fund path is `mutual_funds`, not `folios`**, with `folio_number`,
`units`, `value`, `cost`. The demat groups are `equities`, `corporate_bonds`,
`government_securities`, `demat_mutual_funds`, `aifs` — not the shorter names.
Six field-name assumptions were wrong; every one imported as a silent zero.

**Registrars prefix their own scheme codes.** `EFDG - Axis Large Cap Fund` and
`Axis Large Cap Fund` are the same fund. Instrument matching normalises the name
before comparing — and the normaliser deliberately requires a code prefix to
contain a digit or be short and fully upper case, because an earlier version
stripped "Axis" and would have merged Axis Large Cap with HDFC Large Cap.

**One rule, one place.** That near-miss happened because the rule existed twice:
once in Python, once translated into a Postgres regex. They diverged. The dedupe
script now calls the importer's own function.

**A transaction statement is not a holdings statement.** An NSDL `TXN` file has
six demat accounts all empty. The importer says so rather than failing silently.

**Term insurance has no surrender value**, so those policies sit at zero and
never reach `v_current_holdings`. The protection-gap finding reads insurance
attributes directly, or it could not see the cover it exists to check.

**Objects created by a migration are owned by `postgres`.** The app role cannot
read them until ownership is transferred. Every migration is followed by the
ownership loop — see §2 of the deploy steps in the master document.

---

## 7. Where to start

**1. `funds-compare` and `funds-explore`.** The last two pages from
AlphaLensMF. The screener endpoint is already wired; these are pages over it.

**2. Finish keying the generated prose.** Roughly forty-five sentences left —
the guide's other sections, the lens verdicts, the buy plan reasons, the market
readings. `VERNACULAR.md` has the method and the two traps. Freeze `en.json`
when it is complete.

**3. Then commission the seven remaining languages** against the frozen
catalogue. Worth a professional: ten sets of financial terminology in front of
investors under a broker's licence is ten chances for a fluent-sounding term to
mean something slightly different.

**4. The recommendation engine as designed.** `RECOMMENDATION_DESIGN.md`.
Horizon from the holding record, sectors from the rotation heatmap, candidates
from Alpha Ideas and filtered screeners rather than one ranking's top fifteen.

**5. Redemption handling.** Still set aside rather than solved. Needs
transaction statements covering full history.

**6. The look-through, when the source is fixed.** `weight_pct` is not a
percentage for every AMC — see 5e. Parked with a visible reason rather than
displaying 784%.

## 8. Standing decisions

- **Computed, not generated.** Every figure is arithmetic over the investor's
  holdings. Where a language model is used it is for expression, never to decide
  a number.
- **Estimates say so** and name the assumption. The commission drag is labelled
  an estimate because we hold category spreads rather than scheme-level expense
  ratios.
- **Silence is a valid answer.** A portfolio with nothing wrong returns no
  findings.
- **Bad data is quarantined, not trusted.** Holdings failing arithmetic checks
  are set aside with a reason.
- **XIRR declines to answer** when recorded purchases cover less than 80% of the
  cost basis of current holdings. A CAS covers a limited window; before this
  guard existed, one portfolio reported 239%.
- **404 rather than 403** on records a user may not see, so ids cannot be probed.
- **Sessions are server-side and revocable**, not JWTs. A wealth platform must be
  able to end a session immediately.

---

## 9. Open, and not yet done

**Credentials to rotate.** All three appeared in a build transcript:
- the CASParser API key (now in `/opt/alphawealth/.env`)
- a GitHub personal access token from an earlier session
- the password to a real CAS statement

**A production bug in another product.** Roughly five holdings in
`alphalensmf_db` are corrupt CAS parses — an entire statement row folded into a
scheme name, 27 billion units of a small-cap fund, one contributing a fictional
₹6.2 crore. If alphalensmf.com renders `current_value` directly, users are
seeing it. Independent of AlphaNivesh and worth somebody's attention.

**Before real users:**
- no email verification — anyone can register with any address
- no rate limit on sign-in
- no password reset
- the database password sits in `/root/.alphawealth_db_pw`
- the homepage's Hindi, Assamese, Tamil and Bengali strings are machine
  translations and need a native speaker, particularly the Assamese

**Honest about the homepage.** It makes five promises. Four are substantially
true. Vernacular is demonstrated but not built, and fund overlap is marked
*Next* rather than claimed — which is the honesty rule applied to our own
marketing, and worth keeping.

---

## 10. The lesson worth carrying

Every mapping bug in two days came from writing code against an assumed
contract. The demat structure was right only because a working implementation
was there to copy. Every guess about the mutual fund side was wrong, and one
probe of a real response corrected more than a day of careful reasoning would
have.

For anything crossing a boundary you do not control: **probe first, code
second.**

---

*Read alongside `VISION.md` (why this exists) and the master product document
(what is where). When they disagree with the code, the code is right and the
documents need updating.*
