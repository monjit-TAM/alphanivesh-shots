# AlphaWealth — Unified Multi-Asset WealthTech Platform
## Master Product & Engineering Document (Living Handoff)

> **Purpose of this document.** This is the single source of truth for the AlphaWealth build. It exists so that **any agent or engineer can pick up exactly where the previous one left off**, with zero loss of context, across a multi-week build. It is updated at the **end of every working day** (see §16, Daily Update Protocol).
>
> **Working name:** AlphaWealth (placeholder — final brand TBD by founders).
> **Owner:** Monjit (Co-Founder & CEO/InfoSec, Edhaz Markets Pvt. Ltd. / AlphaMarket).
> **Document status:** v0.3 — 22 Aug 2026. The platform is live at alphanivesh.com and has consolidated a real statement end to end. Companion documents: **AlphaNivesh_Vision.md** (what the product is for) and this one (how it is built). Where they disagree, the vision is the intent and this is the record.

---

## 0. How to Read This Document

- Sections marked **`✅ CONFIRMED`** are verified fact.
- Sections marked **`⚠ VERIFY`** contain a placeholder plus the **exact command** to confirm the fact. Run it, paste output, and the value gets filled in and promoted to `✅ CONFIRMED`.
- Sections marked **`🔷 DESIGN`** are proposed architecture/decisions — real engineering choices, open to founder revision, not yet built.
- Sections marked **`🔨 TO BUILD`** are net-new work items.
- **Never** delete history from this doc. When something changes, strike it and add the new version with a date, so the evolution is auditable.

---

## 1. How We Work (READ THIS FIRST — it governs every task)

This is the single most important operational section. Every agent must follow it.

1. **Command-paste loop.** The agent does **not** have direct shell access to the servers. The workflow is strictly:
   1. The agent writes a **copy-pasteable shell command** (or a patch file to download).
   2. The operator (Monjit) runs it on the server and **pastes the output back**.
   3. The agent reads the output and gives the **next** command.
   The agent must never assume a command succeeded — always wait for pasted output before proceeding.

2. **Patch-file delivery.** For code changes, the agent builds the file in its sandbox and shares it for download; the operator `scp`s it from his **Mac** (`monjitg@in-wks-20`; the `scp` alias runs **from** the Mac to the server), then applies it.

3. **Write code like a human, not like an AI.** This is a hard requirement (the platform will face VC technical diligence):
   - No giant monolithic dumps. Small, purposeful, commit-sized modules with clear single responsibilities.
   - Idiomatic, well-named, readably-structured code. Real architectural decisions, not boilerplate scaffolding.
   - Meaningful commits with meaningful messages. One logical change per commit.
   - No over-commenting the obvious; comment the *why*, not the *what*.
   - The founding team must be able to explain any file. If they can't, it was written wrong.

4. **Safety discipline (carried from the AlphaLab ops rules):**
   - Back up before every edit (`cp {path} {path}.bak.{tag}.{ts}`).
   - Edit source with **anchor-based Python/Node splicer scripts**: match a byte-exact anchor, abort on mismatch, validate (`ast.parse` / `node --check`), then write. Never blind-`sed` structural code.
   - Validate module imports **before** restarting a service. Clear `__pycache__` for edited modules first.
   - **Commit surgically — NEVER `git add .`** Stage only explicitly-named files. Run a secret/`.env`/`.apk` grep before every commit.
   - Test frontend changes in **incognito** (Cloudflare + long cache serve stale bundles).
   - Avoid `!` in bash (history expansion); prefer Python heredocs for edits.
   - Never restart a live trading/market service during Indian market hours (09:15–15:30 IST) without explicit clearance.

5. **Update this document at end of day.** See §16.

---

## 2. Product Vision & Thesis

**One line:** A comprehensive, all-asset-class WealthTech platform where any user — from a Super-HNI or family office down to a first-time investor in a Tier-2/3 town — can see, understand, and manage their **entire net worth across every asset class in one place**, with or without a professional in the loop.

**Who it serves (all personas, one platform, correct data isolation per persona):**
- **Retail / DIY investor** — self-serve, no advisor required.
- **RIA (Registered Investment Adviser)** — manages clients under a SEBI RIA licence.
- **MFD / IFA (Mutual Fund Distributor / Independent Financial Advisor)** — distribution-led.
- **Family Office** — multiple members/entities under one household, deep consolidation.
- **Super-HNI** — few users, deepest features, white-glove.

**Asset classes to consolidate (target):** Listed equity, Mutual Funds, ETFs, Bonds/Debt (incl. G-Secs), AIFs, Commodities/Gold (incl. digital gold), Fixed Deposits/RDs, Insurance (as an asset/where in CAS), Pension/NPS, and manual/self-reported (real estate, physical assets, unlisted).

**Execution:** Order execution / transaction rails will be handled by **Kambala Solutions** (integration to be designed later). AlphaWealth is the **intelligence, consolidation, advice, and management layer**; Kambala is the **execution layer**.

**Core differentiator (the honest edge):** We are not building from zero. We are **unifying three live, in-production products** plus a proprietary multi-asset research engine into one platform, with a data-ingestion capability (CASParser) already integrated. The moat is (a) the unified canonical holdings model across asset classes, (b) the research/analytics depth we already run, and (c) the RIA/MFD/IFA distribution wedge into Tier-2/3 India that the HNI-focused funded players ignore.

**Market context (from research, 2026):** The funded India wealthtech field clusters at the top of the market (Dezerv — expert portfolios for the wealthy; Centricity — assisted wealthtech for HNIs/family offices; INDmoney — broad free aggregation with an algorithmic, non-fiduciary advisory layer). Many remain sub-scale with losses outpacing revenue. **Regulatory note that shapes ingestion:** AMFI/SEBI restricted MF Central's direct API data-sharing to fintechs (Sept 2025). The durable automated route is the **Account Aggregator** framework (needs regulated-entity status); the fast, licence-light route is **CAS-statement parsing** (which we already use via CASParser). Our strategy: **CAS-first, AA-ready.**

---

## 3. What We Already Have (the assets to stitch together)

> This section is the heart of the "consolidate, don't rebuild" strategy. Each existing product contributes modules. Details marked `⚠ VERIFY` must be confirmed from the servers.

### 3.1 testalpha.in — "AlphaLab" (research workbench) `✅ CONFIRMED (see AlphaLab handoff doc)`
- **Role in AlphaWealth:** the **multi-asset research & analytics engine**.
- Hosts: stock research, MF research, ETF research, bond research, insurance research (a multi-asset research engine).
- Stock 360 (single-stock 360° intelligence: AlphaScore, Confluence, Smart Money, fundamental/technical narrations, server-rendered PDF/PNG reports).
- Screeners, trade scanners, algo signals, options analytics, portfolios, DCF, dividends, sector heatmaps, RRG.
- **Infra (confirmed):** AWS Lightsail, static IP `3.109.42.124`, prompt `ubuntu@ip-172-26-0-12`. FastAPI 0.135.0 backend (`testalpha.service`, port 8000, `/var/www/testalpha`), Next.js frontend (`testalpha-next.service`, port 3000, basePath `/new`), PostgreSQL db `alphaforge` (37 tables), Redis DB1, Playwright/Chromium for report rendering. Python venv `/opt/alphaforge-venv`.
- **API docs:** `testalpha.in/api/docs` (Swagger), `/api/redoc`, `/api/openapi.json`.
- **Full technical detail:** see the companion **AlphaLab Engineering Handbook** (already produced) and **SESSION_COMPACT.md**.

### 3.2 alphalensmf.com — MF analytics & CAS import `✅ CONFIRMED`
- **Role in AlphaWealth:** **mutual-fund analytics + CAS/holdings ingestion patterns**.
- **Runs on:** DO `alphaforge-prod`, pm2 process `alphalensmf`, **port 5002**, Node/TypeScript, dir `/var/www/alphalensmf`.
- **Database:** `alphalensmf_db` (15 tables, 13 MB), owner `alphalensmf_user`.
- **CASParser integration:** `/var/www/alphalensmf/server/routes.ts` — inbox connect/status/disconnect/cas, plus `/v4/generate`.
- **Schema shape (the gap AlphaWealth fills):** `portfolios` (one row per CAS *import*, with investor name/email/PAN denormalised onto it), `fund_holdings` (MF-only), `transactions` (MF-only), `users`, `cas_requests`, plus a basket/broker cluster.
- **Known data-quality issues (found 21 Aug):** money and units stored as `real` (float4 — precision loss above ~7 significant digits); dates stored as `text`; timestamps without timezone. ~5 holdings rows are corrupt CAS parses (see §4.3).

### 3.3 stocks.alphamarket.co.in — equity advisory & broker rails `✅ CONFIRMED`
- **Role in AlphaWealth:** **advisory marketplace, broker integrations, SEBI-compliant advice rails, CASParser (the fuller implementation)**.
- **Runs on:** DO `alphaforge-prod`. Related pm2 processes: `alphamarket` (5001), `alphalens-stocks` (5003), `alphalens-aif` (5005), `alphamarket-uat` (5010), `alpha-fundamentals` (5015).
- **Database:** `alphamarket_db` — **82 tables, 133 MB**, owner `alphamarket_user`. This is the most mature schema in the estate and is the basis for the AlphaWealth identity model (see §5.1).
- **CASParser integration:** `/var/www/alphalens-stocks/server/routes.ts` — the fuller implementation: inbox flows **plus** `/v4/smart/parse`, `/v4/cdsl/fetch`, `/v4/cdsl/fetch/{sessionId}/verify`, `/v4/cdsl/parse`.
- **Broker webhook signing rule (carried, critical):** never POST directly to broker URLs from Python (Node `JSON.stringify` key-ordering → silent HMAC mismatch). Use the app's own endpoints with a signed session cookie. Header: `X-AlphaMarket-Signature: sha256={hmac}`.

### 3.4 Cross-product summary table `✅ CONFIRMED 21 Aug`

| Product | Domain | Role | Host | Stack | Database | Port | CASParser |
|---|---|---|---|---|---|---|---|
| AlphaLab | testalpha.in | Research/analytics engine | AWS Lightsail 3.109.42.124 | FastAPI + Next.js | `alphaforge` (19 tbl) | 8000 / 3000 | no |
| AlphaMarket | alphamarket.co.in | Advisory + broker rails | DO 159.89.162.181 | Node/TS | `alphamarket_db` (82 tbl) | 5001 | via alphalens-stocks |
| AlphaLensMF | alphalensmf.com | MF analytics + CAS | DO 159.89.162.181 | Node/TS | `alphalensmf_db` (15 tbl) | 5002 | ✅ yes |
| AlphaLens Stocks | stocks.alphamarket.co.in | Equity portfolio analytics | DO 159.89.162.181 | Node/TS | (shares alphamarket_db) | 5003 | ✅ yes (fullest) |
| AlphaLens AIF | (aif) | Institutional AIF (Nippon) | DO 159.89.162.181 | Node/TS | `aif_db` (38 tbl) | 5005 | no |
| Alpha Fundamentals | data.alphamarket.co.in | Fundamentals service | DO 159.89.162.181 | Node | `alpha_fundamentals_db` (26 tbl, 1966 MB) | 5015 | no |
| DYOR | (dyor) | Retail research | DO 159.89.162.181 | Python | `dyor_db` (30 tbl) | 8000/8001 | no |
| **AlphaWealth** | *(new)* | **Canonical wealth core** | **DO 64.227.180.75** | **FastAPI (planned) + Postgres 16** | **`alphawealth_db`** | tbd | planned direct |

## 4. Data Sources & Feeds (what data we have, where it lives)

> This is a critical reference. Every data point a new agent needs about *where market/holdings data comes from* goes here. All source specifics are `⚠ VERIFY` until confirmed from the servers, because using the wrong feed is a known, repeated failure mode.

### 4.1 Market & instrument data feeds

| Feed | What it provides (per context) | Where used | Status |
|---|---|---|---|
| **TrueData** | Real-time + historical market data, XBRL fundamentals feed (used by Alpha Fundamentals) | testalpha research engines | `⚠ VERIFY` connection details, symbols covered, port |
| **Kite (Zerodha)** | Live quotes, intraday, MCX/commodity, dual-exchange (NSE/BSE) | testalpha, stocks.alphamarket | `⚠ VERIFY` — note: stale token issue historically (acct AIR640 → HTTP 400/fallback) |
| **Groww** | Quote/data fallback in approved chain | testalpha | `⚠ VERIFY` |
| **MF Data** | Mutual fund NAVs, scheme master, factsheets | alphalensmf, testalpha | `⚠ VERIFY` source (AMFI NAV? RTA? MF Central historical?) |
| **Alpha Fundamentals** | 696+ companies, 40+ ratios from TrueData XBRL (port 5015 per context) | testalpha | `⚠ VERIFY` port + coverage |
| **AlphaView** | Internal analytics/data view layer | testalpha (stock360 `alphaview` block) | `⚠ VERIFY` what it is exactly |
| **Data Services** | Internal `data_service.py` → `ds_ohlcv, ds_bulk_ohlcv, ds_bulk_quotes, ds_fundamentals, ds_quote, ds_search, ds_indices` | testalpha (primary data layer) | `✅ CONFIRMED` (function names). ⚠ underlying providers vary |
| **NSE bhavcopy** | EOD prices | testalpha | `⚠ VERIFY` |

> **Approved data-source chain (from AlphaLab context, confirm still current):** TrueData → Kite → Groww → Alpha Fundamentals → AlphaView → Data Services. **Yahoo Finance was explicitly banned** as a source in AlphaLab (a nightly job was caught using it and replaced). Confirm whether this ban is platform-wide for AlphaWealth.

**`⚠ VERIFY` — the data-source recon commands (run on testalpha):**
```bash
# What ds_* functions actually call underneath:
sudo sed -n '1,80p' /var/www/testalpha/services/data_service.py
# TrueData / Alpha Fundamentals service + ports:
sudo ss -ltnp | grep -E ':5015|:800[0-9]'
grep -rn "truedata\|TrueData\|alpha.fundamental\|5015" /var/www/testalpha --include=*.py | grep -vi test | head
```

### 4.2 Holdings / portfolio ingestion (the platform's lifeblood)

| Source | Provides | Route | Status |
|---|---|---|---|
| **CASParser** (`app.casparser.in`) | Parsed CAS PDFs from CDSL, NSDL, CAMS, KFintech → structured JSON. **9 asset classes**: equities, MFs, ETFs, bonds, G-Secs, AIFs, demat MFs, insurance, NPS. Gmail OAuth import, CDSL OTP fetch. | Already integrated in stocks.alphamarket + alphalensmf | `✅ CONFIRMED integrated` / `⚠ VERIFY` exact endpoints + key location |
| **Account Aggregator (future)** | Bank/FD/current-account + investment data via consented pull; durable, govt-backed | AA-ready design now, build later (needs regulated-entity status) | `🔨 TO BUILD (later phase)` |
| **Manual entry** | Long-tail assets not in CAS/AA (physical gold, real estate, unlisted, some FDs, some insurance) | Native forms | `🔨 TO BUILD` |
| **Broker/RTA direct** | Where a direct feed exists (via Kambala execution rails later) | Later | `🔨 TO BUILD (later)` |

**`⚠ VERIFY` — CASParser recon (run on stocks.alphamarket AND alphalensmf):**
```bash
grep -rn "casparser\|app.casparser.in\|CASPARSER" <app_dir> | grep -vi node_modules | head -20
# find the API key storage (do NOT print secrets into this doc — just confirm location):
grep -rln "CASPARSER_API_KEY\|casparser" <app_dir>/.env* 2>/dev/null
# find which endpoints of CASParser are called (parse, smart/parse, gmail, cdsl-otp):
grep -rn "/v[0-9]*/\|/smart/parse\|/gmail\|/cdsl" <app_dir> | grep -i cas | head
```

### 4.3 Data-quality findings (21 Aug 2026) `✅ CONFIRMED`

Discovered while importing AlphaLensMF into the canonical model. **These affect the live product, not just our import.**

1. **Corrupt CAS parses in production.** ~5 of 341 `fund_holdings` rows in `alphalensmf_db` are the result of a CAS parse that failed to split the statement's columns. Symptoms: an entire statement line inside `scheme_name`; 27,022,612,000 units of a small-cap fund against an investment of ₹20,026; a stated value 4.4 million times cost. One such row alone contributed a fictional ₹6.2 crore. **If alphalensmf.com renders `current_value` directly, users are being shown these numbers.** Worth a separate fix on the CAS parsing path.
2. **float4 for money.** `real` holds ~7 significant digits, so any value above roughly ₹1 crore loses precision, and the error compounds through XIRR/return maths.
3. **Dates as text.** Blocks interval arithmetic and point-in-time queries without casting. Formats seen in the data: `%Y-%m-%d`, `%d-%m-%Y`, `%d/%m/%Y`, `%d-%b-%Y`, `%Y/%m/%d`.
4. **Naive timestamps.** `timestamp without time zone` throughout, ambiguous for a platform that stores UTC and displays IST.

**How the canonical layer responds:** every holding is checked on import against arithmetic that must hold (does units × NAV reconcile with the stated value; is value a plausible multiple of cost), and rows that fail are quarantined with a specific reason rather than being allowed to become someone's net worth. A lesson worth keeping: validate against invariants, not against what data "usually looks like" — an early rule that rejected long scheme names produced false positives immediately, because AMCs legitimately prefix scheme codes and append qualifiers.


---

## 5. Target Architecture `🔷 DESIGN`

> Design principle stated honestly for diligence: **start as a modular monolith with clean domain seams, extract services only where load demands.** Microservices-first at this stage would be over-engineering and burn runway. The seams below are pre-drawn so extraction is cheap later.

### 5.1 The canonical domain model (THE SPINE — highest-value work)

The whole platform hinges on **one unified holdings model** that every asset class and every existing product maps into. Proposed core entities:

- **Investor** — a natural person or entity (PAN-anchored where possible).
- **Household** — a grouping of Investors (family office, family, HUF). One net-worth roll-up per household.
- **AdvisorOrg** — an RIA/MFD/IFA tenant. Has many Advisors, serves many Investors/Households.
- **Membership / Relationship** — links Advisor↔Investor (with role, permissions, mandate type: advisory vs. distribution vs. execution).
- **Account** — a source account (demat, folio, bank, NPS, insurance policy, manual bucket). Belongs to an Investor. Has a `source` (CASParser/CDSL, CASParser/CAMS, manual, AA, broker) and `asset_class_scope`.
- **Instrument** — the canonical security master across asset classes (ISIN-anchored where possible; scheme code for MF; symbol for equity; custom for manual). One row per real-world instrument, deduplicated across sources.
- **Holding** — a position: Investor × Instrument × Account, with quantity, avg cost, current value, as-of timestamp. **This is the unification point.**
- **Transaction** — buy/sell/dividend/SIP/switch/maturity/premium, normalized across asset classes.
- **AssetClass** — enum/table: EQUITY, MF, ETF, BOND, GSEC, AIF, GOLD, FD, INSURANCE, NPS, REAL_ESTATE, UNLISTED, CASH, OTHER.
- **Valuation** — time-series of holding/portfolio value (for net-worth-over-time, XIRR, drawdown).
- **CorporateAction / Event** — splits, bonuses, dividends, maturities.

**Key design decisions to lock:**
1. **ISIN as the primary instrument key** where it exists; scheme code (MF), symbol+exchange (equity), policy no. (insurance), custom UUID (manual) as typed fallbacks. A resolver maps every source's identifier → canonical Instrument.
2. **Holdings are append-only snapshots** (as-of dated), not mutable rows — so we can reconstruct net worth at any past date (alphalensmf already does "holdings-as-of time-travel reconstruction" — reuse that pattern).
3. **Money as integer minor units** (paise), never floats, in the canonical store.
4. **Every source keeps its raw payload** (raw CAS JSON, raw broker payload) in an immutable `source_document` table, with the canonical model derived from it — so we can re-derive if mapping logic improves, and so we have an audit trail.

### 5.1a What is actually built `✅ LIVE on alphawealth-core, 21 Aug 2026`

The canonical core exists and holds real data. Ten tables plus a view, in `alphawealth_db`:

| Table | Purpose |
|---|---|
| `investors` | A person or entity whose wealth we track. **Not** a login. PAN-anchored via `pan_hash` (SHA-256) + `pan_last4`; raw PAN is never stored. `legacy_ref` jsonb keeps the trail back to the source record. |
| `households`, `household_members` | Roll-up unit for families and family offices. `include_in_rollup` decides whether a member's assets count toward the household total. |
| `advisory_relationships` | Advisor ↔ investor, with `mandate_type` (advisory / distribution / execution_only / view_only) so the SEBI boundary is encoded in data, not just application logic. |
| `source_documents` | The immutable raw payload every canonical row derives from, deduplicated on `payload_sha256`. Gives an audit trail from any number on screen back to its source, and lets us re-derive when mapping logic improves. |
| `instruments` | Canonical security master across **all** asset classes. ISIN where it exists, else an asset-class-specific `native_code` (AMFI scheme code, policy number), else a synthetic id for manual assets. `kite_instrument_token` bridges to the existing exchange-traded master. |
| `accounts` | Where a holding sits: demat, MF folio, bank/FD, NPS, insurance, manual bucket. **This layer is what makes cross-source dedupe possible.** |
| `holding_snapshots` | Point-in-time positions, **append-only**. Current state is a view over the latest row. This is what makes "net worth on 31 March", real drawdown, and clean restatement possible. |
| `canonical_transactions` | Normalised across asset classes: an MF purchase, an equity buy, an FD opening and an insurance premium all share one shape. |
| `valuation_history` | Daily net worth per investor/household with a denormalised `by_asset_class` breakdown, so the allocation chart does not group over every holding on each page load. |
| `v_current_holdings` (view) | Latest snapshot per (investor, instrument), with a source-precedence tie-break: depository beats registrar beats manual. |

**Type decisions, fixing what the source systems get wrong:** money and quantities are `numeric(20,6)` (never float), dates are real `date`, timestamps are `timestamptz`, ids are UUIDs.

**Asset classes supported by the enum today:** equity, mutual_fund, etf, bond, gsec, aif, gold, fixed_deposit, insurance, nps, ppf_epf, real_estate, unlisted, cash, other.

### 5.1b First real load `✅ 21 Aug 2026`

AlphaLensMF imported into the canonical model:

| Metric | Result |
|---|---|
| Source portfolios | 102 |
| **Distinct investors resolved** | **13 created, 88 matched — i.e. 102 import records represent a handful of actual people** |
| Accounts (folios) | 46 |
| Instruments (schemes) | 75 |
| Holding snapshots | 324 |
| Transactions | 2,080 |
| Quarantined | 5 (corrupt CAS parses, see §4.3) |
| **Consolidated net worth across identified investors** | **₹95,36,178.98** |

The largest single case: one investor had **57 separate CAS imports** sitting as unrelated rows; they now resolve to one investor with one consolidated position set. That is the product thesis demonstrated on real data.

**Two bugs found and fixed during this load, both worth knowing about:**
1. *Cross-source double counting.* Accounts were originally keyed including the statement source, so the same folio arriving from a CAMS statement and a KFintech one became two accounts and the position counted twice. A folio is issued by the registrar, not by whoever printed the statement — migration 002 corrects the key and rebuilds the view to dedupe per (investor, instrument).
2. *Non-idempotent orphans.* Portfolios with neither PAN nor email created a fresh investor on every run. They now match on the originating portfolio id, verified stable across three consecutive runs.


### 5.2 The consolidation / aggregation service `🔨 TO BUILD`
Pulls each Investor's holdings from all sources into the canonical model, deduplicates across sources (the same MF folio seen via CAS *and* via a broker must not double-count), computes the unified net-worth view, asset allocation, XIRR, and time-series. This is the flagship backend service and the hardest-to-fake piece.

### 5.3 Multi-tenancy & persona model `🔷 DESIGN`
- **Row-level tenancy** keyed by `advisor_org_id` (nullable for pure-retail DIY users, who are their own tenant).
- **Persona = a view + permission set over the same canonical data**, not a separate codebase:
  - Retail: sees only own household.
  - RIA/MFD/IFA: sees own clients, scoped by mandate; distribution vs. advisory permissions differ (SEBI boundary).
  - Family office: household roll-up across multiple members/entities.
- **Data isolation** enforced at the query layer (every holdings query is tenant-scoped) + Postgres RLS as defense-in-depth.

### 5.4 Stack & scale `🔷 DESIGN`
- **Backend:** Python + **FastAPI** (matches your team + existing three products). Modular monolith: `core/` (domain model), `ingestion/` (CASParser, manual, AA-later), `consolidation/`, `research/` (wraps existing engines), `advisory/`, `tenancy/`, `ai/`, `audit/`.
- **Frontend:** **Next.js** (matches AlphaLab new frontend).
- **DB:** **PostgreSQL** as the canonical store (partition holdings/valuation by date; read replicas when read load demands). **Redis** for caching + job/session.
- **Async jobs:** a real queue (Celery/RQ/Dramatiq — decide in §17) for CAS imports, nightly valuation, consolidation — never inline in request path.
- **What scales to millions (build when needed, NOT now):** read replicas, table partitioning (holdings/valuation by month), a proper job queue with workers, CDN + edge cache for static, connection pooling (PgBouncer), and horizontal API workers behind a load balancer. **What does NOT need building yet:** service mesh, k8s, event-sourcing everywhere, multi-region. Note this explicitly so we don't over-build.
- **Servers:** `⚠ VERIFY` current capacities (see §6). Plan: unify onto adequately-sized infra; the current Lightsail box is a research/staging host, likely **not** the production home for a millions-user platform — capacity planning is a `🔨 TO BUILD` item.

---

## 5.2 What the platform does today `✅ LIVE 22 Aug 2026`

Running at **https://alphanivesh.com** on `alphawealth-core` (DO, 64.227.180.75), TLS via Let's Encrypt, API under systemd as `alphanivesh-api`.

### Accounts and access
- AlphaNivesh issues its own logins; nothing was carried over from AlphaLensMF or AlphaMarket. `users`, `sessions` (migration 003).
- Argon2id passwords. Sessions are **server-side and revocable**, not JWTs: a wealth platform has to be able to end a session immediately, and a signed token valid until expiry cannot do that. The cookie holds an opaque id; only its SHA-256 is stored.
- Every read is scoped by `visible_investor_ids`: an investor sees their own records, an adviser sees clients with a live mandate, an administrator sees everything. A new account correctly sees **nothing** rather than everything — the failure mode that would have been catastrophic.
- Cross-account access returns **404, not 403**, so investor ids cannot be probed.
- 27 tests cover this.

### Bringing holdings in (migrations 004, 005)
Four routes, all converging on one mapper so what lands in the canonical model does not depend on how it arrived:

| Route | State | Notes |
|---|---|---|
| File upload | **Proven with a real CAMS statement** | 5 folios → 5 holdings → 360 transactions |
| Ask the registrar | Built | `/v4/generate`, full history from 1990, 10-minute cooldown per PAN, generated password |
| CDSL fetch | Built | PAN + BO ID + DOB → OTP → verify; handles all three response shapes |
| Mailbox | Built | OAuth via CASParser; **30-day windows, six in parallel** — long windows fail and sequential takes 19s for a year |

`statement_imports` records every attempt including failures, with the provider's own message kept. Most support questions about a wealth product are a version of "where did my money go", and that table is how they get answered.

### Identity resolution — the hardest part, and the one that matters
The product's central claim is that scattered holdings become one person's wealth. That only works if two statements from the same person resolve to the same investor.

- **PAN when present**, stored as SHA-256 with the last four kept for display.
- **Masked PANs are rejected.** CAMS returns `AFXXXXXX8M` on some statements. Hashing that would produce a key that looks real and matches nothing.
- **Email when there is no PAN**, scoped to records the same user already owns — a family sharing an address must not be merged by an importer.
- **Merge** (`services/merge.py`) for records that have already split: moves everything to the survivor, folds duplicate accounts, keeps the stronger identifiers, records what was absorbed.

This was found the hard way. The first real upload created a *second* record for someone already in the system, because the statement carried no PAN — the exact fragmentation the platform exists to eliminate, produced by our own importer. Merging the two folded **5 duplicate folios** and produced one investor with 13 positions.

### Reading a statement
CASParser's shape, confirmed against a live document rather than assumed:

```
top level (no envelope): investor, meta, mutual_funds, demat_accounts, insurance, nps, summary
  mutual_funds[]:  amc, folio_number, registrar, schemes[], value
    schemes[]:     name, isin, units, nav, value, cost, gain, type, transactions[]
      transactions[]: date, type, units, nav, amount, balance, description
  demat_accounts[]: dp_id, client_id, holdings.equities[] (isin, units, name,
                    additional_info.stock_symbol, transactions[])
```

Three assumptions of mine were wrong before that probe: a `data` envelope that only exists on failures; `folios` rather than `mutual_funds`; and `close`/`valuation` rather than `units`/`value`. Nothing about the mutual fund side survived contact with a real statement.

Cost basis is **derived from purchase transactions** for demat holdings, where the depository states what you hold but not what you paid. For funds the registrar states `cost` directly. Where neither exists, cost stays null and the rest of the system knows not to report a return.

### What is computed
Four findings, each carrying the holdings, thresholds and arithmetic that produced it:

1. **Commission drag** — regular plans where a direct one exists. On real data: **₹39,424 a year, ₹25,31,141 over twenty years** compounded at 11%, with 14 holdings excluded because their plan type is unstated. Labelled an estimate, method named.
2. **Single-holding concentration** — fires at 15% of the portfolio, escalates at 25%.
3. **Top-five concentration** — fires at 60%.
4. **Idle cash** — liquid funds untouched beyond 120 days.

Plus **XIRR that declines to answer** when recorded purchases cover less than 80% of the cost basis of current holdings. A CAS covers a limited window, so an investor of ten years may arrive with one year of transactions; XIRR on that reported 239% before the guard was added.

### Not yet built
- **Fund overlap** — needs scheme constituent data, which is **not** in `alphalensmf_db` (checked). Whereabouts unknown.
- **Prioritised actions** — findings exist; ranking them into "two things worth doing" does not.
- **Vernacular** — demonstrated on the homepage, no i18n layer in the product.
- **Research engines** from AlphaLab are not connected to these holdings.


---

## 6. Servers & Infrastructure Inventory `✅ CONFIRMED 21 Aug`

| Server | Role | Public IP | Private IP | vCPU | RAM | Disk | OS |
|---|---|---|---|---|---|---|---|
| `alphaforge-prod` (DO, BLR1) | **Production** — all live products | 159.89.162.181 | 10.122.0.2 (VPC) | 4 | 7.8 GB (≈0.4 GB free, 4.8 GB cache) | 155 GB, 98 GB free | Ubuntu 22.04.5 |
| `alphawealth-core` (DO, BLR1) | **AlphaWealth build** | 64.227.180.75 | 10.122.0.3 (VPC), 10.47.0.6 | 4 | 8 GB | 160 GB | Ubuntu 24.04.4 |
| AlphaLab (AWS Lightsail) | Research/staging + DO fallback | 3.109.42.124 | — | — | — | 155 GB, 138 GB free | Ubuntu 22.04 |

**Fallback arrangement:** AWS Lightsail is the fallback for DO and vice versa. `⚠ VERIFY` how the fallback actually works (rsync? DB replication? manual?) — this matters for where the canonical database ultimately lives.

**Capacity note:** `alphaforge-prod` runs 14+ application processes plus Postgres, Redis, nginx and Docker on 4 vCPU / 7.8 GB with very little free memory. It is **not** a suitable home for the AlphaWealth consolidation workloads, which is why the canonical core sits on its own droplet (decision B in §5).

### 6.1 Access `✅ CONFIRMED`
SSH aliases are configured on the operator's Mac (`~/.ssh/config`), all key-based:
```
ssh testalpha     # AWS Lightsail  (user ubuntu, key testalpha_key)
ssh alphaprod     # DO production  (user root,  key id_ed25519)
ssh alphawealth   # DO AlphaWealth (user root,  key id_ed25519)
```
`scp file alphawealth:/tmp/` works the same way — this is the patch-delivery path.

### 6.2 AlphaWealth droplet layout `✅ CONFIRMED`
```
/opt/alphawealth/
    venv/                     python 3.12 + psycopg[binary]
    migrations/               001_canonical_core.sql, 002_fix_account_identity.sql
    importers/
        __init__.py
        alphalensmf.py        AlphaLensMF -> canonical importer
        load_seed.sh          loads a prod pg_dump into alphalensmf_staging
```
- PostgreSQL **16.15**, databases `alphawealth_db` (canonical) and `alphalensmf_staging` (a local copy of prod data for building against).
- Role `alphawealth_user`; password in `/root/.alphawealth_db_pw` (mode 600). **`🔨 TO DO`: move to a proper secrets arrangement before production.**
- ufw: 22/80/443 open; 5432 only from `10.122.0.0/20` and `10.47.0.0/16`.
- Node 20.20.2, nginx 1.24.0, fail2ban, timezone Asia/Kolkata.

## 7. APIs — What We Call & What We Must Build

### 7.1 External APIs we already call `⚠ VERIFY details`
- **CASParser** (`app.casparser.in`) — holdings ingestion (9 asset classes). Key console: `app.casparser.in/console/api-keys`. `✅ integrated` / `⚠ VERIFY endpoints`.
- **Kite / Zerodha** — market data + (via AlphaMarket) execution. `⚠ VERIFY`.
- **Upstox** (prod + UAT) — broker integration, basket publishing. `✅ (AlphaMarket)`.
- **Dreamstreet** — broker. `✅ (AlphaMarket)`.
- **TrueData** — market/fundamentals feed. `⚠ VERIFY`.
- **AMFI / RTA (CAMS, KFintech)** — MF NAV/master. `⚠ VERIFY`.
- **Kambala / Nextra** — execution (in progress). `🔨 TO BUILD/finish`.

### 7.2 Internal APIs we already expose (reuse) `⚠ VERIFY inventory`
- testalpha: `/api/stock360/{symbol}`, `/api/stock360/{symbol}/pdf`, `/api/narrate/*`, screeners, intraday-levels, alpha-ideas, etc. (see AlphaLab Swagger at `/api/docs`). `✅`.
- alphalensmf: MF analytics + CAS import endpoints. `⚠ VERIFY inventory` (pull its OpenAPI/route list).
- stocks.alphamarket: advisory, broker-call, webhook, basket endpoints. `⚠ VERIFY inventory`.

**`⚠ VERIFY` — inventory each product's routes:**
```bash
# testalpha (confirmed pattern): curl -s http://localhost:8000/api/openapi.json | python3 -c "import sys,json;[print(m.upper(),p) for p,v in json.load(sys.stdin)['paths'].items() for m in v]"
# repeat on alphalensmf + stocks.alphamarket (adjust port/openapi path)
```

### 7.3 New APIs we must build `🔨 TO BUILD`
- **Unified Investor/Household API** — CRUD + net-worth roll-up.
- **Consolidation API** — `GET /api/wealth/{investor_id}/networth`, `/allocation`, `/timeline`, `/xirr`.
- **Ingestion orchestration API** — trigger CAS import, poll status, map to canonical, dedupe.
- **Instrument-resolver API** — source identifier → canonical Instrument.
- **Tenancy/persona API** — advisor onboards client, scopes mandate, permissions.
- **AI advisory API** — see §9 (with full audit logging per SEBI).
- **Audit/trail API** — see §10.
- **Manual-asset API** — add/update self-reported holdings.

---

## 8. Feature Scope (what the product does)

### 8.1 Core (MVP) `🔨 TO BUILD (mostly assembly)`
- Unified onboarding (retail self-serve + advisor-onboards-client).
- Holdings import via CASParser (CDSL/NSDL/CAMS/KFintech; Gmail import; CDSL OTP).
- Manual asset entry for long-tail.
- **Unified net-worth dashboard** across all asset classes (the hero view).
- Asset allocation, XIRR/returns, net-worth-over-time, drawdown.
- Per-asset drill-down using existing research engines (Stock 360, MF analytics, etc.).
- Advisor console (client list, per-client consolidation, mandate-scoped actions).
- Household roll-up (family office).
- Regular wealth updates (scheduled digests / alerts).

### 8.2 Differentiators `🔨 TO BUILD`
- Cross-asset-class analytics (true consolidated allocation, overlap analysis, concentration risk across the *whole* net worth — not just one silo).
- "Start from zero" wealth-journey mode for first-time investors (goal-based, guided).
- AI copilot (see §9), with SEBI-grade auditability.
- Research depth (the existing multi-asset engines) surfaced inside the wealth view.
- Advisor tooling (SEBI-compliant advice rails already exist in AlphaMarket — reuse).

### 8.3 Execution (later, via Kambala) `🔨 TO BUILD (later)`
- Order placement, rebalancing, SIP mandates — routed to Kambala rails.

---

## 9. AI Layer `🔷 DESIGN + 🔨 TO BUILD`

> Two mandates run in parallel: (a) genuinely useful AI features; (b) **every AI interaction and output is captured, timestamped, and logged** — treat this as SEBI-mandated and non-negotiable (see §10).

**Candidate AI features (all must log per §10):**
- **Wealth copilot / Q&A** — "How exposed am I to banking?" / "What changed in my portfolio this month?" answered over the user's consolidated holdings.
- **Portfolio insights** — concentration, overlap, asset-allocation drift vs. target, tax-loss harvesting candidates, idle-cash detection.
- **Narrative reporting** — the Stock-360-style narration approach, extended to a whole-portfolio "state of your wealth" report.
- **Goal-based guidance** — for the zero-holdings first-timer: risk profiling → suggested allocation (advice-boundary-aware per persona/SEBI).
- **Smart alerts** — behaviour- and event-driven nudges.
- **Anomaly/behaviour patterns** — see §11.

**Design rules for the AI layer:**
- Every AI feature calls through a single `ai/` gateway module so logging/guardrails are centralized (never scattered per-feature).
- Advice-boundary enforcement per persona (a distributor persona must not emit RIA-style personalized advice — SEBI boundary encoded in the gateway).
- Model/provider abstraction (don't hardwire one LLM vendor).
- Deterministic disclaimers appended where required.

---

## 10. Audit, Logging & SEBI Compliance Trail `🔨 TO BUILD — treat as mandatory`

**Principle:** *Everything is logged, timestamped, immutable, and retained.* This is both a SEBI expectation (advice/records retention — AlphaMarket already runs 7-year retention) and the substrate for behaviour analytics (§11).

**What to capture:**
- **Every AI conversation & output** — prompt, context used, model, response, disclaimers shown, user, timestamp, persona, advice-boundary decision. Immutable store.
- **Every user action** — page views, clicks, imports, edits, report generations, advice viewed/accepted/ignored — with timestamp, session, device.
- **Every advice event** — what was recommended, by whom (human advisor or AI), the rationale, whether acted upon (reuse AlphaMarket's SEBI advice-logging + 7-yr retention pattern).
- **Every data-ingestion event** — source, raw payload reference, what was parsed, dedup decisions.
- **Every consent** — CAS consent, AA consent (later), data-sharing consents, with timestamp and scope.

**Design:**
- Append-only `audit_log` (never updated/deleted) + immutable `ai_interaction_log` + `source_document` (raw payloads).
- Timestamps in **UTC stored, IST displayed** (absolute format, e.g. "30 Jun 2026, 10:00 AM IST") — carry the AlphaLab timezone convention.
- Tamper-evidence: consider hash-chaining audit rows (each row includes hash of prior) for defensibility.
- Retention ≥ 7 years for advice/records; define retention per log type.
- PII handling: encrypt at rest, access-controlled, consent-scoped.

---

## 11. Behaviour Analytics & Personalization `🔷 DESIGN (built on §10 logs)`

Using the full activity + AI logs, build (later phase, once data accrues):
- **Behaviour patterns** — how each user researches, decides, hesitates, acts.
- **Predictability models** — likely next actions, churn/engagement signals, best-time-to-nudge.
- **Personalized guidance** — surface the right insight at the right moment based on observed behaviour.
- **Cohort/segment analytics** — for the business + for advisors managing many clients.
> This is a data-compounding moat: the logging we build in §10 is what makes §11 possible later. Build the logging rigorously now even though the analytics come later.

---

## 12. Security & Data Protection `🔷 DESIGN`
- Encryption at rest (PII, holdings) and in transit (TLS everywhere).
- Secrets never in code/git (a live lesson: a GitHub PAT was exposed in AlphaLab — rotate discipline is mandatory). Use env + a secrets manager.
- Per-tenant data isolation (query-scoped + Postgres RLS).
- Consent ledger for all data pulls (CAS/AA).
- Audit trail (§10) doubles as security forensics.
- DPDP Act (India data-protection) alignment + SEBI IS-audit readiness (needed anyway if AA route is taken).

---

## 13. User Guide (in-product help & navigation) `🔨 TO BUILD (grows with product)`

> A living guide section so end-users (including a first-time Tier-2/3 investor with no advisor) can self-navigate. Update as features ship.

- **Getting started (retail):** sign up → import holdings (upload CAS / Gmail import / OTP) → see your net worth → explore allocation → set goals.
- **Getting started (advisor):** onboard org → add clients → import each client's holdings → consolidated book view → per-client actions.
- **Getting started (family office):** create household → add members/entities → roll-up view.
- **Importing holdings:** how to get a CAS statement (CAMS/KFintech/CDSL/NSDL), the Gmail-import flow, the CDSL-OTP flow, manual entry for assets not in CAS.
- **Reading your dashboard:** net worth, asset allocation, returns/XIRR, timeline, concentration.
- **Using research:** Stock 360, MF analytics, etc., from within a holding.
- **Using the AI copilot:** what it can/can't do (advice boundaries per persona), that conversations are logged.
- **Glossary & FAQs.**

---

## 14. Open Questions / Decisions Needed `🔷`
1. Final brand name for the unified platform.
2. Where does production live? (New consolidated infra vs. current hosts — capacity planning needed.)
3. Do we pursue the **Account Aggregator** licence path (regulated-entity route) in parallel, or stay CAS-first for the foreseeable MVP?
4. One unified database vs. per-domain databases from day one? (Recommendation: one canonical Postgres for the wealth core; leave existing product DBs in place and ingest from them.)
5. Job-queue choice (Celery vs. RQ vs. Dramatiq).
6. Auth: unify the three products' auth into one identity provider, or federate? (Recommendation: one new identity service for AlphaWealth; existing products authenticate against it over time.)
7. LLM provider(s) for the AI layer + data-residency constraints.
8. Advice-boundary rules per persona — get these reviewed by compliance before the AI advisory ships.

---

## 15. Execution Plan (phased, no timelines per founder instruction) `🔷`

> Sequenced by dependency, not date. Each phase is "done when..." not "done by...".

**Phase A — Foundations & recon.** Complete the `⚠ VERIFY` recon across all three products + servers (§3, §4, §6). Produce the confirmed infrastructure + data-source + schema inventory. *Done when the cross-product tables in §3.4, §4, §6, §7 have zero `⚠ VERIFY` left.*

**Phase B — Canonical model & consolidation core.** Build the canonical domain model (§5.1) and the consolidation service (§5.2). Ingest one product's holdings into it end-to-end as the proof. *Done when a single investor's holdings from CAS land in the canonical store and produce a correct net-worth roll-up.*

**Phase C — Unified onboarding + dashboard (MVP hero).** Retail self-serve onboarding + CAS import + the unified net-worth dashboard. *Done when a real first user can sign up, import, and see their consolidated net worth.*

**Phase D — Advisor/persona layer.** Multi-tenancy, advisor console, mandate scoping, household roll-up. *Done when an RIA/MFD can onboard and manage a client book.*

**Phase E — Research integration + AI copilot + audit.** Surface existing research engines inside the wealth view; ship the AI copilot through the logged gateway (§9, §10). *Done when AI Q&A works over consolidated holdings with full audit trail.*

**Phase F — Manual assets, alerts/digests, polish.** Long-tail assets, scheduled wealth updates, guide.

**Phase G — Execution (Kambala) + AA + behaviour analytics.** Later-phase rails.

---

## 16. Daily Update Protocol (MANDATORY) `✅ PROCESS`

At the **end of every working day**, the agent updates this document:
1. Append a dated entry to §17 (Changelog) — what was built, what was decided, what was verified, what broke.
2. Promote any `⚠ VERIFY` items that got confirmed to `✅ CONFIRMED`, filling in the real values.
3. Update the relevant section(s) with new facts (never delete old — strike & replace with date).
4. Update §18 (Current State / Next Actions) so the next agent knows exactly where to start.
5. Regenerate the PDF/Word export of this doc for the founder.

---

## 17. Changelog (append-only)

- **22 Aug 2026 — v0.3 — Live, with a real statement consolidated end to end.**
  - Built authentication with per-user and per-mandate read scope (27 tests).
  - Built four import routes; **file upload proven with a real CAMS statement**.
  - Corrected the CASParser integration against a live response: no envelope on success, `mutual_funds` not `folios`, `units`/`value`/`cost` not `close`/`valuation`. Every assumption about the fund side was wrong.
  - **Identity resolution rebuilt.** The first real upload split one person into two records because CAMS masks the PAN. Added email fallback, masked-PAN rejection, and a merge that folded 5 duplicate folios.
  - Added the compounded projection to the commission finding.
  - alphanivesh.com live on HTTPS with the narrative homepage; upload, sign-in and dashboard all routed.
  - Wrote **AlphaNivesh_Vision.md** — the conviction behind the product, which is that people do not understand what they own rather than that they cannot see it.

- **21 Aug 2026 — v0.2 — Phase A recon complete; canonical core live with real data.**
  - Mapped both servers in full: DO `alphaforge-prod` runs 14+ processes and 7 databases (§3.4, §6); AWS Lightsail hosts AlphaLab.
  - Located the CASParser integration precisely: `/var/www/alphalensmf/server/routes.ts` and `/var/www/alphalens-stocks/server/routes.ts`, `api.casparser.in/v4/*`, key in `CASPARSER_API_KEY`. The stocks implementation is the fuller one (smart/parse + CDSL OTP flow).
  - **Revised the architecture decision** after seeing `alphamarket_db`: it already has a multi-asset `portfolio_holdings` table (ISIN, asset_class, insurance and FD fields, numeric money) and a mature identity/compliance model. AlphaWealth adopts its conventions rather than inventing a parallel universe, so the eventual convergence is a data copy rather than a translation.
  - Provisioned `alphawealth-core` (DO BLR1, 8 GB/4 vCPU, same VPC as prod), hardened it, set up SSH aliases.
  - **Built and applied the canonical schema** (migrations 001, 002) and the AlphaLensMF importer.
  - **Loaded real data:** 102 portfolios → 13 investors, ₹95.4 lakh consolidated. One investor's 57 separate CAS imports collapsed to one record.
  - **Found a production data-quality problem** (§4.3): ~5 corrupt CAS parses in `alphalensmf_db`, one contributing a fictional ₹6.2 crore. Quarantined here; needs a separate fix upstream.

- **30 Jun 2026 — v0.1 — Document created.** Initial master product document drafted from founder brief + competitive/regulatory research. Established: working model (§1), vision & personas (§2), the "consolidate three live products" strategy (§3), CAS-first / AA-ready ingestion decision (§4), canonical-model-as-spine architecture (§5), modular-monolith-on-FastAPI/Next.js/Postgres stack decision (§5.4), AI layer + mandatory SEBI-grade audit logging design (§9, §10), phased plan (§15). Populated all known-confirmed facts from the AlphaLab session; marked all cross-product/server/data-source specifics as `⚠ VERIFY` with recon commands attached. **No code written yet — design-first, by design.**

---

## 18. Current State / Where the Next Agent Starts `✅ 22 Aug 2026`

**Where we are.** The platform is live and works end to end: someone can sign up, upload a consolidated statement, and see their holdings consolidated with computed findings. A real CAMS statement has been through it.

**On the data now.** Five investors, largest ₹57.6 lakh, from the AlphaLensMF migration plus one live upload.

**Next, in the order I would take them**

1. **Ask for PAN at upload.** Optional field, explained plainly. Without it, statements that omit the PAN rely on email matching, which is weaker. This is the cheapest way to make consolidation reliable.
2. **Prioritised actions.** Rank findings by rupee impact and effort, return the top two with reasoning. Makes the homepage's fourth beat true; half a day.
3. **Fund overlap.** The strongest chapter on the homepage and still marked *Next*. Blocked on locating the scheme constituent data — it is not in `alphalensmf_db`.
4. **Connect the research engines.** Stock 360 and the fund research in AlphaLab are the reason to choose this product; they are not wired to these holdings.
5. **i18n.** Every user-facing string becomes content. A day, and worth doing properly rather than fast.

**Carrying forward, unresolved**

- **Credentials in the build transcript.** The CASParser API key, a GitHub PAT, and a CAS statement password. All three should be rotated.
- **Malformed rows in production `alphalensmf_db`.** Roughly five holdings are corrupt CAS parses, one contributing a fictional ₹6.2 crore. If that site renders `current_value`, users are seeing it. Independent of AlphaNivesh and worth someone's attention.
- **No email verification, no rate limit on sign-in, no password reset.** Acceptable while private; not for real users.
- **The DB password sits in `/root/.alphawealth_db_pw`.** Fine for a build, not for production.
- **The homepage's vernacular strings are my translations** and need a native speaker, particularly the Assamese.

**A lesson worth keeping.** Everything that broke on day two broke because I wrote code against an assumed contract. The demat mapping was right only because the production implementation was there to copy; every guess about the mutual fund side was wrong. One probe of a real response fixed more than a day of careful reasoning would have. When a shape can be checked, check it.

---

*End of master document v0.3. Keep it current (§16). Read alongside AlphaNivesh_Vision.md.*
