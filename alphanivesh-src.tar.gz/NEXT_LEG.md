# The next leg

*29 August 2026. What the product becomes once it stops describing and starts
accompanying.*

---

## What we have built, and what it does not do

Everything so far answers one question well: **what is true about this
portfolio today.** Holdings, risk, tax, peers, cost, what a bad day looks like,
what a shock would do, what to do first and why that first.

None of it accompanies anybody. It is a very good second opinion that has to be
asked for each time.

The next leg is the loop: **advise, help execute, see what happened, come back
about it.** Four pieces, and they only work as a set — advice that cannot be
executed is a suggestion, execution that is not read back is a black hole, and
a review with nothing to review is a newsletter.

**One thing worth naming before any of it.** The advice ledger already records
every recommendation with its basis and its date. That is the foundation for
all four pieces and nobody else in this market has it. What is missing is the
second half: coming back later, comparing what is held now against what was
said then, and closing the loop.

---

## Part one: advice that can be acted on

**The gap.** Advice says *reduce capital goods exposure*. An order says
*SELL 50 THERMAX at market*. Everything difficult lives in that translation.

### What has to be decided

**Which holding, and how much.** "Reduce capital goods from 63% to 40%" has
many valid answers across four holdings. The engine must choose, and the choice
has to account for tax cost per holding, which are long-term, exit loads on
funds, and what the sale leaves behind.

**Whole units.** 47.3 shares is not an order. Funds take rupee amounts, equities
take whole shares, and the rounding has to be shown rather than absorbed —
"₹1,30,064 of the ₹1,30,090 you would raise, leaving ₹26 that does not divide
into whole shares" is the honest form and we already write it in the buy plan.

**Sequencing.** Sell before buy where the proceeds fund the purchase, and say
so, because a plan whose steps are executed out of order fails in a way nobody
attributes to the plan.

**Price drift.** Advice computed at yesterday's close against an order placed at
today's open. Small usually, and not always — a stated tolerance, above which
the instruction is recomputed rather than sent.

### The output

An **instruction**: a list of orders, each with a venue, an instrument, a side,
a quantity, an estimated value, the tax it realises, and the recommendation it
came from. Reviewable line by line, modifiable, and rejectable in part.

### Effort
Medium. The hard parts are the trim-selection logic and lot-level tax, and both
are extensions of things already built.

---

## Part two: execution

**Venues:** Kambala for equities, BSE StAR for mutual funds, and whatever else
follows.

### The part that is not engineering

**Consent has to be per order and evidenced.** Under an advisory licence,
execution is the investor's decision. Not "they agreed to the plan" — *this*
order, *this* quantity, *this* moment, recorded. That evidence is the
difference between an adviser with an execution partner and unauthorised
portfolio management.

**Two questions to settle before any code:**

1. **Who is the adviser of record on an executed order** — us or the execution
   partner? It decides who holds the consent obligation and what each of us
   must retain.
2. **What does the partner require** in the instruction payload, and what do
   they return?

Worth putting to Pradnya alongside the Ariv retention question.

### What the ledger already gives us

The chain is nearly complete: what we advised, on what basis, by which engine
version. Add the consent record and the order reference against the same row
and it runs end to end — advised, consented, placed, filled, reconciled.

**That is a stronger audit position than most licensed firms have**, and it
comes almost free because the ledger was built first.

### Effort
Large, and mostly integration. One venue end to end is worth more than two
half-done — probably BSE StAR first, since the funds protocol is simpler than
the equities one and most of our advice is about funds.

### Prior art
AlphaMarket has Kambala SSO working and the PlaceOrder authentication resolved
from June — `Authorization: Bearer TOKEN`, no jKey. Reuse rather than rebuild.

---

## Part three: seeing what happened

**The half we already have the foundation for.**

### Confirmations

An executed order comes back with a fill price and quantity. Reconciled against
the instruction, three outcomes: filled as instructed, filled differently, not
filled. Each needs saying, and the second needs saying loudly — a partial fill
that nobody notices leaves a portfolio halfway through a rebalance.

### Re-import

The bigger source, and the one that works without any execution integration at
all. A new statement arrives and we compare what is held against what we
advised.

**Three things fall out of that comparison:**

**Did they act.** The regular plan became direct — they did it. The emergency
fund still is not there — they did not. Both are worth knowing and neither is
a judgement.

**What it produced.** *"Three months ago you switched HDFC Hybrid to direct.
That has saved ₹1,603 so far, and ₹6,412 a year from here."* **That is the
sentence nothing else in this market can write**, because nothing else
remembers what it told you.

**What it unlocked.** Guardrails that withheld actions now release. *"You built
the emergency fund, so the rebalance we held back is available."*

### Prompting the re-import

*"Your last statement was February. Six months of transactions we cannot see."*
That gap is what blocks XIRR on every investor we have, and asking at the right
moment works better than a permanent banner nobody reads.

### Effort
The re-import comparison is small and it is the highest value per hour on this
entire document. Confirmations wait on execution.

---

## Part four: coming back

### The cadence is theirs to choose

Ask once, store it, respect it: **monthly, quarterly, or only when something
matters.** The third should be the default. A quarterly review that arrives
when nothing has changed is a newsletter, and people unsubscribe from
newsletters.

### What earns a message

The rule from the earlier scope holds: **nothing goes out that would not be
worth an SMS from a person who knows their money.**

| Trigger | Why it earns one |
|---|---|
| A holding turns long-term | 20% becomes 12.5%. Predictable months ahead |
| February and March | The ₹1.25 lakh exemption does not carry forward |
| A SIP stopped | Our behavioural engine sees it. Nobody tells people |
| A threshold crossed by price alone | Nothing was bought; the risk changed |
| A fund's mandate or manager changed | The disclosures show it |
| Their funds bought what they already own | Concentration arriving without a decision |
| **Follow-up on something they did** | Three months after a switch: what it saved |
| A statement is due | The picture can be refreshed |

**Expect one a month per person, and treat that as the design.** Daily insight
feeds and streaks work for a quarter and then get muted, which is worse than
never having sent anything.

### Channels

**In-product** — the "while you were away" panel, already built.

**Email** — the substantial one. A quarterly review that reads like a person
wrote it, with the PDF attached.

**WhatsApp** — the one people actually read in India, and the one with the
tightest rules. Template approval, opt-in, and a narrow window for
free-form replies. Worth doing and worth doing carefully.

**Push, web and app** — for the time-sensitive few. A holding turning
long-term does not need a push. February does.

**Everything downloadable.** The PDF exists; every review should carry one.

### Effort
Cadence and in-product: small. Email: medium. WhatsApp: medium plus a
compliance process. Push: needs the app.

---

## Part five: widening what we can suggest

Every recommendation today ends in equity — a stock or an equity fund. That is
a limitation of the engine rather than a view about markets.

| What | Why | Effort |
|---|---|---|
| **ETFs** | Cheaper than funds for index exposure, and the honest answer for somebody who does not want to pick. The data service has an ETF chooser we do not use. | small |
| **Gold** | The one asset that reliably does not move with equity. Every portfolio we hold has none, and every one of them has "nothing that rises when equities fall" as a finding. | small |
| **Debt and liquid** | The emergency fund the engine keeps asking for has nowhere to go. We say build one and do not say where. | small |
| **NPS** | Tax-advantaged and we already parse it. | small |
| **REITs and InvITs** | Income and diversification, thin market. | medium |

**The gold and debt gaps are the sharpest.** The platform tells people they
have nothing defensive and then recommends more equity, which is incoherent.

---

## Order of work

**First, because they are cheap and unblock the rest:**

1. **The follow-up comparison** — did they act, what did it produce, what
   unlocked. Small, and the highest value on this page.
2. **Cadence preference** — ask once, store it, respect it.
3. **Re-import prompting** at the right moment.
4. **Gold, debt and ETFs in the INVEST tier** — fixes an incoherence.

**Then, because it is the biggest change and needs a decision first:**

5. **Advice to instruction** — orders with quantities, tax and sequencing.
6. **Consent capture** into the ledger.
7. **One venue end to end**, probably BSE StAR.
8. **Confirmations and reconciliation.**

**Then the channels:**

9. **Email review** with the PDF.
10. **WhatsApp**, with the template process started early since approval takes
    time.
11. **Push**, when there is an app.

---

## What this becomes

The product today is a very good second opinion. What is described here is
something else: **a thing that notices, tells you at the right moment, helps
you do it, checks whether it worked, and tells you what it was worth.**

Nobody in this market does the last part, because nobody keeps a record of what
they advised. We already do.

---

## The two questions blocking the biggest piece

1. **Who is the adviser of record on an executed order** — us or Kambala?
2. **What does BSE StAR require** in an instruction, and what does it return?

Neither is an engineering question and both gate everything in part two.
