# What the recommendation engine should be

*Written 25 August, from Monjit's description. Not built. The current
implementation is a stopgap and this is what replaces it.*

## Why the current one is not enough

Today a rebalance goes: the AlphaMarket engine ranks the NSE universe on its
composite score, returns fifteen candidates, and `buyplan.py` picks from them
against a size mix and the industries the holder is thin in.

That is better than taking the engine's top eight — which on a real run meant
selling a listed financial services company to buy eight micro-caps at six
thousand rupees each. But it is still choosing from whatever fifteen names a
single ranking produced, and on Monjit's portfolio those fifteen contained no
large caps at all. A selection layer cannot build a balanced portfolio out of
an unbalanced pool.

## What it should consider

**How long this person actually holds.** Everything else follows from it. A
recommendation for somebody whose average holding period is four months is a
different security from one for somebody who has held the same funds for six
years. Where the investor states a horizon, use it; where they do not, compute
it from the transaction record — which is what `behaviour.py` already reads,
though it currently reports the holding pattern rather than feeding it into
anything.

**Where the money is rotating.** The sector rotation heatmap already exists on
the AIF product and the data service carries the underlying figures. Sector
choice should start there rather than from a static list of what the portfolio
lacks: an industry somebody is thin in and which is also turning is a better
suggestion than one they are thin in and which is falling.

**Fundamentals and technicals together.** Stock360 composes both and is already
built. A candidate should clear both rather than rank well on a blend of them,
because a blend lets a strong technical score carry a weak balance sheet.

**Where the portfolio is actually thin.** Not just by industry — by company
size, by how much sits in one name, and by whether there is anything that does
not move with the equity market. `restructure.what_is_missing` computes this
and nothing feeds it into the buy side.

**Signals that already exist.** Alpha Ideas on testalpha generates calls, and
the screener endpoints on the data service can be filtered rather than sorted.
Both are better starting pools than one composite ranking.

## The shape it should take

    horizon          from stated preference, else from average holding period
        ↓
    sector view      rotation heatmap, not a static gap list
        ↓
    candidate pool   Alpha Ideas + filtered screeners, not one ranking's top 15
        ↓
    filter           Stock360 fundamentals AND technicals, both to clear
        ↓
    select           size mix, diversification gaps, position sizes that matter
        ↓
    explain          why this stock, for this person, at this horizon

The last step is the one that matters commercially. Every product in this
market can produce a list. What none of them does is explain why a particular
name suits a particular portfolio held by a particular person — and that
explanation is only possible because every step above it is a stated rule
rather than a score.

## What is already built and reusable

| Piece | Where | State |
|---|---|---|
| Holding pattern, nerve, placement | `behaviour.py` | Built, not feeding recommendations |
| What the portfolio lacks | `restructure.what_is_missing` | Built, not feeding the buy side |
| Size mix and sector weighting | `buyplan.py` | Built, working, pool-limited |
| Fund ranking | data service `/data/mf/screener` | Built, good |
| Stock verdicts | AlphaMarket rebalance engine | Built, three-pillar, documented |
| Sector rotation | AIF product, data service | Built, not wired here |
| Stock360 | testalpha | Built, not wired here |
| Alpha Ideas | testalpha | Built, not wired here |

Three of those need wiring rather than building, which is most of the work
already done.

## The constraint that does not move

Every recommendation must trace to a stated rule applied to figures somebody
can check. Not because it is a nicer way to build software, but because the
product goes in front of investors under a broker's licence, and an adviser
asked "why does your tool say buy" needs an answer better than "the model
scored it 78".
