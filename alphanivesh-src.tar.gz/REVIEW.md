# Where we stand

*Reviewed 29 August 2026, against the bucket list of the 28th and the
competitive scope of the 27th.*

---

## Built since the bucket list was written

Nine things in two days, all working on real data.

| What | State |
|---|---|
| **VaR and Expected Shortfall** | Daily, monthly, annual, at 95% and 99%, from the portfolio's own weighted return series. Monjit 2.6% daily, Sandipdoshi 1.3% — the concentration shows in the figure without anybody being told. |
| **Cost drag compounded** | 1.70% a year reads as ₹1.14 lakh and as ₹1.37 crore over twenty. Against an index fund at 0.3% rather than against zero. |
| **Step-up SIP** | Flat against 5/10/15/20%. Sandipdoshi's ₹24,000 a month flat is ₹2.37 crore; raised ten per cent it is ₹4.72 crore. Arithmetic verified to four significant figures against published tables. |
| **Scenario replay** | Six shocks computed from actual holdings. On the same 8% market fall a capital-goods portfolio loses twice what a staples one does; an IT-heavy portfolio gains when the rupee falls. |
| **Peer quartiles** | Computed from each category's own distribution rather than a stored rank. Sandipdoshi has 64% of his fund money in bottom-quartile funds. |
| **Commission meets quartile** | The connection neither card makes alone: ₹33.16 lakh in four funds that are both bottom-quartile and paying trail, costing ₹33,158 a year. |
| **XIRR** | Built, and it refuses on every investor we have — 8% and 40% of the money accounted for. The refusal is the feature: the first cut returned 792% a year. |
| **Monte Carlo** | Block-bootstrapped from our own returns rather than their broken endpoint. Drift anchored toward 12%, weighted by history length. Monjit refused outright at 53% observed. |
| **Manager activity** | Built, correct, and **not wired** — 3% to 16% coverage. |

Plus, from the day before: the advice ledger, audit page, admin area,
liabilities, tax harvesting, Ariv's router and answers, the PDF, export, and
sharing with expiry.

---

## Still open, and why

### Ready to build

**Ariv's panel.** The router and ten deterministic answers work today and cost
nothing. The panel is the last piece before it is usable, and generated answers
wait only on the Anthropic account having credit.

**Goals.** Every goal feature renders empty because nobody has set one. Not a
data problem — a usage one. Worth seeding a realistic goal to build against.

**Succession and nominee.** Small, on the competitor list, pairs with the
protection gap the engine already computes.

**NPS.** The CAS parser returns the section and we handle it. Untestable until
somebody has one.

### Blocked on a decision

**Family and household view.** INDmoney, Kuvera and FundSageAI have it; PowerUp
announced it. The code is straightforward and the permissions question is not:
who may see whose holdings. Three models were laid out in the scope document
and explicit invitation is the only one that survives a separation.

### Blocked upstream, and it is one conversation

Three features, one root cause: **the AMC disclosure pipeline on alphaforge.**

- **Manager activity** — 3,775 of 4,844 schemes have a single filing date, so
  month-over-month comparison covers a tenth of a portfolio
- **The look-through** — `weight_pct` is not a percentage for every AMC; one
  scheme's 251 holdings sum to 8,056
- **Their montecarlo endpoint** — `ORDER BY date_trunc('month', nav_date),
  nav_date DESC` walks backwards within each month, so drift cancels and ₹24
  lakh of contributions come back as ₹24.8 lakh

The first two need the ingest fixed. The third is a one-line query change. All
three are worth raising together.

### Genuinely large

**EPF.** An external integration, and often a salaried investor's largest
holding.

**International holdings.** Needs pricing the data service does not carry.

**Age-band peer comparison.** Needs a cohort we would have to assemble.

---

## Against the competition, now

Comparing to the scope of the 27th.

### What they have that we still do not

| | Who | Us |
|---|---|---|
| Family view | INDmoney, Kuvera, FundSageAI, PowerUp building | **missing** |
| EPF | INDmoney | missing |
| US equities | INDmoney, Kuvera | out of scope |
| Nominee and succession | named in comparisons | missing |
| Conversational access | INDmoney via MCP | half built |

### What we have that they do not

Longer than it was two days ago.

- **Recommendations withheld with their reasons.** Nobody else shows refusals.
- **Behaviour read from transactions** — whether somebody held through a fall,
  and whether that was a decision or a standing instruction.
- **The hierarchy** — protect before fix before optimise, so an empty emergency
  fund outranks an interesting sector concentration.
- **Verdicts against a peer set** rather than fixed thresholds.
- **An advice ledger** with the basis of every claim, retained seven years.
- **Scenario replay computed from actual holdings** rather than a constant per
  scenario. Theirs shows every user the same −29.54%.
- **Peer quartiles joined to commission** — the finding that needs both.
- **A projection that refuses** when the window is too good to project from.
- **XIRR that declines** rather than reporting 792%.
- **A stated methodology including the refusals.**
- **Vernacular** — three languages of the analysis itself.
- **The decision engine as a keyed service** other products can call.

### What they show that we deliberately will not

**Health scores.** PowerUp shows 25/100. AlphaLensMF shows a Risk Score of
8.5/10 and a Diversification Score of 1.0/10. Composites need weights nobody
can derive and cannot be taken apart by the reader. Our count-based reading
says the same and opens into what it counts.

**Forward quartile predictions.** Fund performance persistence is weak and well
documented as weak. A forward quartile is a forecast wearing an observation's
clothes.

**Smooth projection curves.** Nobody's money grows at a constant rate, and a
curve that says otherwise sets an expectation the first bad quarter destroys.

**And projections that inherit a bull market.** This is the sharpest one. Our
first Monte Carlo gave a real portfolio ₹19.3 crore in ten years with a zero
per cent chance of loss, because it resampled an exceptional five years. Every
competitor showing projection fans has this problem; none of them says so. We
anchor the drift and refuse where anchoring is not enough.

---

## What I would do next

1. **Ariv's panel** — works today, and it changes how the product is used
2. **The alphaforge conversation** — one meeting unblocks three features
3. **Family view**, once the permissions question is answered
4. **Goals**, with a seeded example to build against

**Not soon:** EPF, international, age cohorts. Each needs something outside our
control, and none is why somebody would choose this product.

---

## The thing worth protecting

Six times in two days a feature was built, tested on real data, and found to be
confidently wrong: 792% XIRR, ₹19.3 crore projections, 68,575% growth, a
concentration built on an unmatched holding, a driver naming an irrelevant
sector, and coverage reading 100% when it was 3%.

Every one was caught by looking at the output rather than the code. That
practice is worth more than any single feature on this list, because the
failure mode of a financial platform is not a crash — it is a number that looks
right.
