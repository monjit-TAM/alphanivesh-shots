# Scope of work

*Written 27 August 2026. Competitive positions from published material;
vendor accuracy claims are excluded where unverifiable.*

## Where we sit

Four kinds of competitor, and only one of them is really us.

**Execution brokers** — Groww, Zerodha Coin. Tracking supports order placement.

**Aggregators** — INDmoney, Kuvera, Agni Folio, Dezerv's Wealth Monitor.
Breadth is the product: bank, EPF, ESOPs, NPS, FDs, liabilities, family, US
equities in one net-worth figure. Dezerv's app tracks stocks, funds, bank
accounts, NPS and FDs, and they are explicit about moving toward serving "an
entire family's financial life".

**Managed money** — Dezerv proper. PMS and AIF from ₹50 lakh, discretionary,
with relationship managers. Not our market, but their app is free and it
competes for the same screen.

**Advice-first analysers** — PowerUp Money, and us.

### PowerUp is the comparison that matters

Founded 2024, SEBI RIA, zero-commission, research-led. Five lakh users and
₹65,000 crore tracked in eight months. Free portfolio review; **PowerUp Elite
at ₹999 a year**, which had 25,000 paying members within months of launch.

Their published roadmap is, almost line for line, our feature list:

| PowerUp's stated roadmap | What we call it | Our state |
|---|---|---|
| Regular to Direct, tax-efficient step-by-step switching | `plans.py` — switch, redirect, payback | **Built** |
| Power Allocation — goal- and risk-aligned across SIPs, lump sums and existing holdings | `buyplan.py` + `risk.py` ceiling | **Built, goal-blind** |
| Family Portfolios — household in one app | — | **Missing** |
| Funds rated in-form / on-track / off-form | Three lens verdicts + fund behaviour | **Built, differently** |

Two conclusions. **The market has validated what we built** — somebody raised
$12m to build our features and 25,000 people pay ₹999 a year for them. And
**we are not ahead for long**: family portfolios are on their roadmap and
absent from our product.

## Part one: the competitive gaps

Ordered by cost to lack, cheapest first.

### 1. Liabilities on the dashboard — *small*
Table built yesterday, nothing displays it. Net worth without debt is not net
worth. INDmoney and Dezerv both show it.

### 2. Tax harvesting as an action — *small*
Kuvera makes it a headline. We compute the ₹1.25 lakh exemption and the
long-term boundary and stop short of saying "realise this much this year".
Slots into the FIX tier. The largest gap on this list relative to effort.

### 3. Export — *small*
Named in comparisons as a reason to avoid a platform. We have none.

### 4. Family and household view — *moderate*
INDmoney, Kuvera, FundSageAI have it; PowerUp is building it. We hold several
investors with no way to combine them. Needs an aggregation and a permission
model — who may see whose holdings is not a detail.

### 5. NPS, then EPF — *NPS small, EPF an integration*
The CAS parser already returns an `nps` section we handle and no investor has
yet populated. EPF is often a salaried investor's largest holding and we cannot
see it at all.

### 6. Succession and nominee — *small*
Appears in comparisons as real criteria. Pairs with the protection gap the
engine already computes.

### 7. Conversational access — *moderate*
INDmoney exposes an MCP server. Chat is becoming an expectation. Unusually
suited to us: every number we produce already carries its reasoning in prose,
which is what such an interface needs and what others must generate after the
fact.

### 8. International holdings — *large, probably not ours*
Needs pricing the group's data service does not carry.

## Part two: the monthly disclosure engine

The most valuable thing on this list, and nobody else does it.

**The problem it solves.** Prices change daily, holdings change on import, and
the advice barely changes at all. A portfolio in good order produces the same
answer next week. That is honest and it is not a reason to return.

**What genuinely changes without the investor doing anything: the funds
themselves.** Every month, managers file what they hold. Two consecutive
disclosures say exactly what was bought, sold, added to and trimmed — and the
investor's risk changes without a single decision on their part.

### 2a. What changed in your funds
Per-fund activity between disclosures. `/data/mf/activity/{code}` exists and
the fund card uses it. What is missing is the portfolio-level roll-up and the
alert.

### 2b. What your funds did, together
Aggregated across everything held: *"Four of your six funds bought Reliance
this month."* Interesting rather than actionable, and it is the raw material
for 2c.

### 2c. Hidden concentration appearing — **the strongest idea here**
The example makes the case: somebody holds 25% in HDFC Bank directly. Last
month none of their funds held it. This month three of them bought it, and
their exposure is now 31% — a material change in risk they neither made nor
were told about.

No aggregator sees this because none of them look through funds to companies
on a month-over-month basis. It is a genuine early-warning signal and it is
computable from data we already ingest.

**One dependency, and it is real.** Earlier sessions found five AMCs publishing
holdings without percentages and at least one whose weights sum to 8,056%. The
look-through is parked for that reason. **Before building any of 2a–2c, count
how many funds our investors hold that have two consecutive clean disclosures.**
If it is most, this is the best thing on the list. If it is a third, build it
and label the coverage.

### 2d. What changed while you were away
The container for all of it. On return, before anything else: what moved, what
the funds did, what crossed a threshold, what needs deciding. Length scales
with absence — a day away is a line, three months is a briefing.

Better than a notification because it responds to their return rather than
interrupting their day.

### 2e. Change over every period
Yesterday, a week, a month, three, six, a year, three, five, and max.

**With one caution.** A period return is easy to compute in a way that
flatters: "up 12% over a year" is wrong if half the money arrived four months
ago. Either value-on-value at both dates, clearly labelled as growth, or a
proper money-weighted return where we hold the transactions. Never the first
called the second — the platform already refuses that elsewhere and this is the
same refusal.

## Part three: nudges, and what not to send

**The rule:** nothing goes out that would not be worth an SMS from a person who
knows their money. Everything below passes; anything that does not, does not
send.

| Trigger | Why it earns a message |
|---|---|
| A holding turns long-term | Tax drops 20% → 12.5%. Predictable months ahead |
| February and March | The ₹1.25 lakh exemption does not carry forward |
| A SIP stopped | Our behavioural engine sees it. Nobody tells people |
| A threshold crossed by price alone | Nothing was bought; the risk changed anyway |
| A fund's mandate or manager changed | Monthly disclosures show it |
| The concentration signal (2c) | Risk changed without a decision |
| A new statement is available | The picture can be refreshed |
| **Follow-up on something they did** | Three months after a switch: what it saved |

That last one is the loop nothing else has. Somebody switches to direct, and
later hears what it was worth. Somebody builds the emergency fund, and hears
that the guardrail released and the rebalance is now available.

**Expect one a month per user, and treat that as the design rather than the
shortfall.** Daily insight feeds, streaks, and a health score engineered to
wobble all work for a quarter and then get muted, which is worse than never
having sent anything.

## What deliberately stays out

**A health score out of a hundred.** Competitors lead with one. A composite
needs weights nobody can derive and cannot be taken apart by its reader. Our
count-based reading opens into what it counts.

**Prediction accuracy claims.** At least one platform advertises 85% accuracy
forecasting client needs 12–18 months ahead. Not checkable, and making one
would undo the methodology page.

**Regular plans by default.** Named in comparisons as the clearest sign a
platform works against its user.

## Tomorrow, in order

1. **Count the disclosure coverage.** One query. It decides whether part two
   is the headline feature or a labelled partial.
2. **Liabilities on the dashboard** — table exists, engine reads it, nothing
   shows it.
3. **Tax harvesting** into the FIX tier.
4. **Export.**

Then, depending on (1): either the monthly disclosure engine, or family view.
