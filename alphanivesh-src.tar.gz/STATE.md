# What is done and what is not

*1 September 2026, end of day. Replaces the version written on 31 August.*

---

## Done, and reachable

**The advisory loop.** Findings, the tiered decision engine, the alternatives
layer (three or four ways per finding, each with what it costs and when to pick
it), instruction sizing, the follow-up comparison, cadence, and the review —
which now writes itself, sends on the rhythm somebody chose, and shows in the
product for people who do not read email.

**The data model.** Assets, protection and liabilities as three separate
things. Cover is not counted as wealth.

**Beyond equity.** Gold, debt and liquid in the INVEST tier.

**Accounts.** Registration with verification, welcome, password reset, Google
sign-in, mail through SendGrid with every send logged — and a lock on who can
be written to, after a test run reached a real investor unannounced.

**Admin.** The ledger, the audit export, and the people module with the funnel
and where each account stands.

**The interface.** One side nav on every page, destinations answering one
question each, the snapshot page, a figure typeface, one colour system, an
allocation ring, a value-history chart that refuses where the record cannot
support one, and restrained motion.

**And the execution groundwork, built today:**

*Adviser of record.* Every ledger row carries which registered firm the advice
was given under, resolved when it is written rather than inferred afterwards.
258 rows predating this are unattributed and stay that way.

*The adviser's judgement.* An RIA can edit, hold back or add to what the engine
produced. Both versions are kept — a record showing only the final text would
say the engine recommended something it never did. Suppression is recorded
rather than erased. Overrides lapse after a week and stop applying the moment
the underlying figures change.

*Yesterday against today.* Nothing is stored and served; the engine runs
against each morning's prices. What carries over is the comparison — still
stands, says something different, or is not raised today.

*Registration and rights.* An RIA advises. An MFD may not — they distribute,
and SEBI treats the two as separate activities. Rights are computed from the
certificate on file every time, so a lapsed registration takes them away
without anybody having to remember. Nothing is granted on a claim: the
certificate is uploaded outside the web root and a person looks at it.

---

## Built and not reachable

**The client book.** `professionals.clients_of()` and `/api/professional/clients`
work; there is no page. An adviser cannot do anything with a book they cannot
see. *An evening.*

**The registration queue.** `/api/professional/waiting` lists what needs
checking; admin has no tab for it. *An hour.*

**Manager activity.** Built in June, never wired, because the AMC disclosures
give 3–16% coverage. Blocked on the data service.

---

## Not built

**Consent capture.** The last thing before an order can be placed: this order,
this quantity, this moment, recorded. The instruction layer produces the order
list; nothing captures agreement to it.

**Order placement.** Kambala for equities, BSE StAR for funds. One venue end to
end is worth more than two half-done, and StAR is the simpler protocol.

**Confirmations and reconciliation.** What came back, against what was
instructed.

**WhatsApp, push, goals, family view, succession.**

---

## Loose ends

**The SendGrid key** came through a chat window in plaintext on 31 August and
is still live. Oldest item on this list.

**Domain authentication** for `alphaverse.world`, so mail stops arriving in
spam.

**Sending as alphaverse.world for a product called AlphaNivesh** is fine for
testing and wrong for investors.

**The Google identity** is linked to an account with no holdings.

**Six unnamed empty portfolios** clutter the investor picker.

**The ULIP's ₹15 lakh** is recorded as cover and may be its fund value.

**No value history is drawable for anybody yet.** The snapshots are too sparse:
Monjit's longest stable stretch is ten months carrying one figure. The chart
says so rather than drawing a line, and it will start working as statements
accumulate.

---

## What I would do next

1. **The adviser's dashboard.** The client book as a page. Everything else in
   the execution work assumes an adviser can see their clients.
2. **The registration queue in admin**, so a certificate can actually be
   checked.
3. **Consent capture.** Then one venue end to end.
4. **Rotate the key.**

---

## One thing about how this went

Almost every data bug found this week came from the same assumption: that a
holding is a tradeable investment with a known cost. A term policy, a provident
fund, and gold entered without a price each broke something different — a sell
list, a concentration finding, a gain figure, a benchmark, a chart.

Worth carrying into the execution work, because that is where the assumption
stops being embarrassing and becomes expensive.
