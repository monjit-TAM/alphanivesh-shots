# Vernacular: what is done and what remains

*A standalone brief. Everything needed to finish this is here; nothing else in
the codebase needs reading first.*

## The state

Ten languages promised on the homepage. Three built: Hindi, Bengali, Marathi,
alongside English. Seven remain: Gujarati, Telugu, Tamil, Malayalam, Punjabi,
Assamese, Odia.

None of the three has been checked by a native speaker. The interface says so,
in the reader's own language, and that notice should stay until somebody
qualified has been through each catalogue.

## How it works

    locales/en.json          the source. Every string, keyed.
    locales/{hi,bn,mr}.json  the same keys, translated.
    api/services/i18n.py     lookup, fallback, completeness counting
    api/routers/language.py  GET /api/language, GET /api/language/{code}
    web/lang.js              the picker, the notice, applying strings

A service that wants to say something calls:

    from . import i18n
    i18n.say("find.sector_concentration.head", share="63", sector=sector)

The language rides on a context variable set by middleware in `api/main.py`
from `?lang=` or the `Accept-Language` header. It is not passed as a parameter,
because the language is a property of the request rather than of the
calculation, and threading it through every function that produces a sentence
would touch most of the service for no benefit.

Markup uses `data-t="key"` attributes, which `applyStrings()` fills. Rendered
headings in JavaScript use `T("key")`, which falls back to the English written
in the file so a first visit with no catalogue loaded reads correctly.

## The rule that matters

**The noun phrase carries its own case marking. The template supplies no
postposition.**

    WRONG   template "{share}% of your money is in {sector} मध्ये आहे"
            noun     "भांडवली वस्तूंमध्ये"
            gives    "भांडवली वस्तूंमध्ये मध्ये आहे"     -- "in" twice

    RIGHT   template "तुमच्या पैशाचा {share}% {sector} आहे"
            noun     "भांडवली वस्तूंमध्ये"

This bug appeared twice, both times in Marathi and Bengali and never in Hindi
— Hindi's postposition attaches differently, so a template written and checked
in Hindi passes and breaks elsewhere. It reads fluently to anybody who does not
speak the language it broke in.

Every noun arriving from the database needs its own key: sector names, asset
classes, the singular phrases in `findings._SINGULAR`. A sentence with one
English noun in it reads worse than the same sentence wholly in English,
because the reader can see the machine tried and stopped.

## What is converted

| Where | State |
|---|---|
| Navigation, buttons, card headings | done |
| Section headings on both pages | done |
| All seventeen finding headlines | done |
| Sector concentration and single-holding details | done |
| Sector names, asset classes, singular phrases | done |
| The guide's opening paragraph | done |
| Behavioural readings — style and nerve | done |
| The guide's other four sections | **not done** |
| Lens verdicts and their reasons | **not done** |
| Buy plan reasons and the size mix reading | **not done** |
| What is missing, and the options' reasons | **not done** |
| Market position and base rates | **not done** |
| Tax, redeployment, fund fit | **not done** |

Roughly forty-five sentences remain. Each needs: the f-string extracted, a key
added to `en.json`, the call site changed to `i18n.say`, and the sentence
written in each language.

## How to finish it

The keying and the translation are different jobs and should be split.

**The keying** needs the code: find each f-string, add its key, change the call
site, test that the placeholders fill. Mechanical, and the pattern is
established — copy any converted finding.

**The translation** needs a translator. Ten languages of financial terminology
in front of investors under a broker's licence is ten chances for a
fluent-sounding term to mean something slightly different — "capital gains tax"
understood as "profit tax" would pass a casual read and cost somebody money.
`en.json` is exactly the artifact a translator wants: keyed, complete, with the
placeholder convention documented above.

Recommended order: finish the keying so `en.json` is complete, then commission
all ten languages against a frozen list. Translating a moving target is how
catalogues drift out of sync.

## Open questions for a native reader

**Numerals.** Everything renders Latin digits — "23 निवेश" rather than "२३
निवेश". Indian financial documents often keep Latin digits even in vernacular
text, since statements and NAVs arrive that way, so this is probably right. It
is a choice rather than an oversight and worth confirming.

**Register.** The English is deliberately plain and slightly formal, avoiding
both jargon and false warmth. The three translations aim at the same register.
Whether they hit it is exactly what a native speaker should judge.

**"Quantamental."** Left transliterated in all three. There may be a better
answer.
