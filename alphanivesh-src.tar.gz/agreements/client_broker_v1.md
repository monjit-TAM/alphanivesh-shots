# Digital Client–Stock Broker–AlphaVerse Platform Agreement

The execution agreement, for orders routed to a broker. A fourth relationship: neither the broker nor AlphaVerse advises, and anybody wanting advice engages a registered adviser separately.

---

**DIGITAL CLIENT–STOCK BROKER–ALPHAVERSE PLATFORM AGREEMENT**

*Agreement Version: [SYSTEM GENERATED VERSION NUMBER]  |  Effective upon Electronic Acceptance*

# IMPORTANT INFORMATION

This is a legally binding electronic agreement between the Client, the SEBI-registered Stock Broker and AlphaVerse. The Client's identity and the Broker's particulars are captured and authenticated electronically during onboarding and form part of the electronic record of this Agreement.

No physical signature, handwritten name, handwritten date or physical execution is required where the electronic acceptance/signing mechanism used for this Agreement is legally valid.

The Broker provides broking, order-routing, execution and related services in accordance with its registration and Applicable Law. AlphaVerse is a technology provider. Neither party provides investment advice under this Agreement unless the Client separately enters into a lawful advisory arrangement with a suitably registered Investment Adviser.

# 1. PARTIES AND ELECTRONIC IDENTIFICATION

1.1 Client. The person completing the authenticated onboarding and electronic acceptance is the Client.

1.2 Broker. The stock broker associated with the Client's trading/demat relationship is the Broker. Its SEBI registration, exchange membership and other regulatory particulars shall be maintained electronically in the relevant profile.

1.3 AlphaVerse. AlphaVerse operates the technology platform used for information, workflow, consent and related services.

# 2. ELECTRONIC ACCEPTANCE

The Client's electronic acceptance constitutes execution and acceptance to the extent permitted by Applicable Law. AlphaVerse may retain the exact accepted text, Agreement version, timestamp, authentication method, IP/device/session information where captured, and a document hash/fingerprint.

Each revision shall carry a new version number and historical accepted versions shall remain preserved. The electronic record may be relied upon as evidence of acceptance, subject to Applicable Law.

# 3. NATURE OF THE BROKING RELATIONSHIP

The Broker acts as a stock broker and related service provider within the scope of its regulatory permissions. The Broker is not acting as an Investment Adviser under this Agreement.

The Broker shall not represent that execution services, order-routing functionality, market information or other broking services constitute personalised investment advice.

AlphaVerse is a technology provider and does not provide investment advice under this Agreement.

If the Client requires investment advice, the Client should independently engage a SEBI-registered Investment Adviser under a separate agreement.

# 4. BROKER SERVICES

Subject to Applicable Law and the Broker's applicable client documentation, the Broker may provide account opening, order placement/routing, execution, contract notes, statements, settlement-related services and other permitted broking services.

The Broker remains responsible for its own regulated broking activities. AlphaVerse does not become the Broker, exchange member, clearing member, depository participant or investment adviser merely by providing technology.

# 5. CLIENT ORDERS AND AUTHORITY

The Client retains control over whether and when to place an order, subject to the Broker's account terms and Applicable Law.

An electronic order or instruction submitted through an authenticated workflow may be treated as the Client's instruction where the applicable authentication and legal requirements are satisfied.

No Platform information shall itself be treated as an order. The Client must expressly initiate and confirm the relevant transaction/order through the designated workflow.

Where a consent or order-authorisation workflow has an expiry period, the expiry shall be enforced by the Platform. An expired consent shall not constitute continuing authority.

# 6. NO INVESTMENT ADVISORY DUTY

Nothing in this Agreement requires the Broker or AlphaVerse to assess whether a security or transaction is suitable for the Client as an Investment Adviser, unless separately required by Applicable Law or separately agreed under a lawful advisory arrangement.

Market information, analytics, screeners, alerts, historical data and similar information displayed through the Platform are informational unless expressly identified otherwise and lawfully provided in another regulated capacity.

The Client should obtain independent professional advice where the Client requires personalised investment advice.

# 7. CLIENT RESPONSIBILITIES

The Client shall provide accurate information, maintain required KYC and account details, safeguard credentials, review orders before submission, monitor account activity, comply with applicable trading rules and understand that securities transactions involve market risk.

# 8. MARKET DATA AND PLATFORM INFORMATION

Information may be delayed, incomplete or sourced from third parties. Displayed market prices are indicative/last observed values unless expressly identified otherwise and are not guaranteed execution prices.

AlphaVerse may refrain from displaying information where it cannot reliably compute or verify it. Historical information is not a forecast or guarantee.

# 9. FEES AND CHARGES

Brokerage, statutory levies, exchange charges, taxes, account charges and other permitted charges shall be disclosed in the Broker's applicable tariff sheet, account-opening documents or electronic disclosures.

AlphaVerse shall not charge the Client any direct fee unless expressly disclosed before or at the relevant payment/acceptance stage.

Commercial fees between AlphaVerse and the Broker shall be governed by a separate professional agreement and shall not create an advisory relationship with the Client.

# 10. CLIENT DATA AND PRIVACY

The Client authorises lawful processing of Client Data for account servicing, order processing, Platform operation, security, regulatory compliance, record keeping and other disclosed lawful purposes.

The Broker and AlphaVerse shall access only information permitted by Applicable Law and the relevant technology workflow. AlphaVerse shall not sell Client Data or share it for unrelated marketing purposes, subject to lawful disclosures and permitted processing.

# 11. DATA SECURITY

AlphaVerse and, within their respective responsibilities, the Broker shall maintain reasonable safeguards designed to protect Client information. No electronic system can be guaranteed completely secure.

# 12. RECORDS AND AUDIT TRAIL

The Platform may retain Client identity, Broker identity, order/consent records, information displayed, timestamps, Agreement version, electronic acceptance record, document fingerprint/hash and relevant technical metadata.

Records shall be retained for at least the period required by Applicable Law and, where AlphaVerse has adopted a longer contractual retention policy, for that longer period, subject to longer legal, regulatory or dispute-preservation requirements.

# 13. INTELLECTUAL PROPERTY

All intellectual property in AlphaVerse's software, Platform, algorithms, interfaces, trademarks and documentation remains with AlphaVerse or its licensors. Broker intellectual property remains with the Broker or its licensors.

# 14. CONFIDENTIALITY

Each Party shall protect confidential information received from another Party except where disclosure is required or permitted by law or necessary for lawful performance. These obligations survive termination.

# 15. GRIEVANCE REDRESSAL

Complaints concerning broking, orders, execution, account operations or Broker services shall first be addressed through the Broker's grievance mechanism.

Complaints concerning AlphaVerse's Platform functionality shall be addressed through AlphaVerse's grievance mechanism.

Where applicable, the Client may use the relevant exchange, SEBI SCORES and other prescribed grievance/ODR mechanisms. Nothing limits statutory remedies.

# 16. TERM AND TERMINATION

This Agreement commences upon electronic acceptance and continues until terminated. The Client or Broker may terminate in accordance with applicable client-account terms and Applicable Law.

AlphaVerse may suspend or terminate Platform access where the Broker relationship ends, continued provision becomes unlawful, there is material misuse or another lawful ground exists.

# 17. EFFECT OF TERMINATION

Termination does not invalidate completed transactions or legally required records. Pending instructions/orders shall be handled in accordance with Applicable Law and the Broker's applicable terms. Records required to be retained shall remain preserved.

# 18. CHANGES AND VERSION CONTROL

Material revisions shall receive a new Agreement version. Where required, the revised Agreement shall be presented for electronic acceptance. Historical accepted versions shall remain retrievable.

# 19. ELECTRONIC COMMUNICATION

The Client consents to electronic delivery of contractual notices, disclosures, statements, contract notes and other communications through the Platform, registered email, registered mobile number or other legally permissible electronic channels, subject to the Broker's statutory delivery obligations.

# 20. ELECTRONIC RECORDS AND EVIDENCE

Electronic records maintained in the ordinary course of the Platform or Broker systems may be used as evidence of acceptance, instructions, consents, communications, information displayed and Agreement version, subject to Applicable Law and the Client's right to challenge authenticity or integrity.

# 21. LIMITATION OF LIABILITY

Nothing excludes liability that cannot legally be excluded. AlphaVerse is not responsible merely because a security transaction results in a loss. The Broker remains responsible for its own regulated broking activities. Neither AlphaVerse nor the Broker guarantees investment returns or execution at a displayed market price.

# 22. FORCE MAJEURE

Neither AlphaVerse nor the Broker shall be liable for failure caused by circumstances beyond reasonable control, subject to Applicable Law.

# 23. GOVERNING LAW AND JURISDICTION

This Agreement is governed by Indian law. Subject to statutory, exchange and regulatory remedies, courts at [●] shall have jurisdiction.

# 24. SEVERABILITY

If any provision is invalid or unenforceable, the remaining provisions continue to the extent legally permissible.

# 25. ENTIRE AGREEMENT

This Agreement together with the Broker's applicable client documentation, disclosures and terms expressly incorporated electronically constitutes the agreement governing its subject matter. In case of inconsistency, mandatory regulatory/client-account terms shall prevail to the extent required by Applicable Law.

# 26. CLIENT DECLARATION AND ELECTRONIC ACCEPTANCE

I confirm that I have read and understood this Agreement and the disclosures presented to me. I understand that the Broker is providing broking and related services and is not acting as my Investment Adviser under this Agreement. I understand that AlphaVerse is a technology provider.

I understand that information, analytics and market data displayed through the Platform are not, merely by being displayed, personalised investment advice. I make my own investment decisions and understand that securities transactions involve risk.

I agree to this Agreement and consent to its electronic execution and to the creation and retention of an electronic record of my acceptance, including the Agreement version and document fingerprint/hash.

[ I AGREE AND ELECTRONICALLY SIGN ]

# ELECTRONIC EXECUTION RECORD

Agreement Version: System generated; Client Identity: authenticated account; Broker: broker relationship; Regulatory identifiers: broker profile; Acceptance Date/Time: system generated; Authentication Method: system generated; IP Address/Device/Session: where captured; Document Hash/Fingerprint: system generated; Acceptance Status: Accepted/Declined; Electronic Signature Record: system generated, where applicable.

# END OF AGREEMENT

No physical signature, handwritten name or manually entered date is required where the electronic execution method used is legally valid.
