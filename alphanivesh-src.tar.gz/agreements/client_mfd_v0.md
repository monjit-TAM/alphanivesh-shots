# Distribution Services Agreement

**Version 0 — NOT LEGALLY REVIEWED. NOT FOR USE WITH REAL CLIENTS.**

This file exists so the mechanism around it can be built and tested: the
version is recorded, the text is fingerprinted, and what somebody agreed to
can be produced years later. The operative terms are for Edhaz's counsel to
write, not for a language model to draft.

**Until this file is replaced, the agreement flow must stay switched off in
production.** `AGREEMENTS_LIVE` in the environment governs that, and it
defaults to off.

---

## What the real agreement needs to cover

Written down here so whoever drafts it has the list, and so the gaps are
visible rather than assumed.

**The parties.** The client, the registered adviser, and Edhaz as the platform
— with the relationship between the three stated. The advisory relationship is
between the client and the adviser; Edhaz provides the software. AlphaMarket's
existing agreement says this and the wording there is a reasonable starting
point, but it is written for a marketplace where strategies are sold, which is
not this arrangement.

**What the adviser is doing.** Using this platform's analysis with their own
clients, under their own registration, exercising their own judgement — and
free to change or withhold what the engine produces. The record keeps both
versions, and the client should know that.

**What the platform is not doing.** Not advising, not recommending, not
holding client funds or securities.

**Fees.** Who charges what, to whom, and how. The platform's fee and the
adviser's fee are different things and a client should be able to tell them
apart.

**Data.** What the adviser can see, what the platform retains, for how long,
and what happens to it when the relationship ends. Seven years for advice
records under SEBI retention.

**Ending it.** How either side stops, what happens to the advice already
given, and what the client keeps access to.

**Risk.** That advice is advice, that past figures are not forecasts, and that
the client decides.

**Grievance.** Where a complaint goes, and the SEBI SCORES route.

---

## What makes this one different

**This is not an advisory agreement and must not read like one.** A document
that reads like advice, signed with a distributor, is evidence that advice was
being given by somebody not registered to give it — which is worse than having
no agreement at all.

It should say plainly that the distributor does not advise, that what the
client sees from this platform is information rather than a recommendation,
and that the distributor is paid commission by the fund house rather than a
fee by the client.
