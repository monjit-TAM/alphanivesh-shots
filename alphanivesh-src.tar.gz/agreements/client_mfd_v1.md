# Digital Client–Mutual Fund Distributor–AlphaVerse Platform Agreement

The distribution agreement. Section 3 says plainly that the distributor is not an adviser and that information displayed is information — which is the separation the platform enforces in software, written down.

---

**DIGITAL CLIENT–MUTUAL FUND DISTRIBUTOR–ALPHAVERSE PLATFORM AGREEMENT**

*Agreement Version: [SYSTEM GENERATED VERSION NUMBER]  |  Effective upon Electronic Acceptance*

# IMPORTANT INFORMATION

This is a legally binding electronic agreement between the Client, the Distributor and AlphaVerse. The identity and particulars of the Client and the Distributor are captured and authenticated electronically during onboarding and form part of the electronic record of this Agreement.

No physical signature, handwritten name, handwritten date or physical execution is required where the electronic acceptance/signing mechanism used for this Agreement is legally valid.

AlphaVerse is a technology provider. The Distributor relationship described in this Agreement is a distribution/service relationship and is not an investment advisory relationship.

# 1. PARTIES AND ELECTRONIC IDENTIFICATION

1.1 Client. The person who completes the onboarding and electronic acceptance process shall be the Client. The Client's identity shall be established through the authentication mechanism used during onboarding.

1.2 Distributor. The distributor associated with the Client shall be the Distributor. Its regulatory/industry identifiers, including ARN or other applicable registration details, shall be maintained electronically in the Platform.

1.3 AlphaVerse. AlphaVerse is the technology provider operating the Platform.

# 2. ELECTRONIC ACCEPTANCE

The Client's electronic acceptance constitutes execution and acceptance of this Agreement to the extent permitted by Applicable Law. AlphaVerse may record the authenticated Client identity, Agreement version, exact accepted text, timestamp, authentication method, IP/device/session information where captured, and a cryptographic hash or document fingerprint.

Every version shall carry a unique version number. A later version shall not overwrite the historical version accepted by the Client. The electronic record may be relied upon as evidence of acceptance, subject to Applicable Law and the Client's right to challenge authenticity or integrity.

# 3. NATURE OF THE DISTRIBUTION RELATIONSHIP

The Distributor acts as a mutual fund distributor and/or investor service facilitator, subject to Applicable Law and its applicable registration/authorisation.

The Distributor is not acting as an Investment Adviser under this Agreement and shall not represent that it is providing personalised investment advice under this Agreement.

AlphaVerse does not provide investment advice under this Agreement.

Information displayed by the Platform is information only. It does not become personalised investment advice merely because it is displayed to the Client or made available through the Distributor workflow.

A Client seeking investment advice should independently engage a SEBI-registered Investment Adviser under a separate advisory arrangement.

# 4. ROLE OF ALPHAVERSE

AlphaVerse provides software, analytics, data presentation, dashboards, workflow, record-keeping, consent capture and related technology functionality.

AlphaVerse does not hold Client funds or securities, does not exercise investment discretion and does not place or execute an order merely because information is displayed through the Platform.

Where the Platform is unable to compute, verify or display an item reliably, it may state that the item is unavailable.

# 5. DISTRIBUTOR RESPONSIBILITIES

The Distributor shall maintain all registrations/authorisations required for its activities and comply with applicable SEBI, AMFI, AMC and other Applicable Law requirements.

The Distributor shall provide accurate scheme/product information, applicable disclosures and investor servicing as required. It shall not hold itself out as an Investment Adviser unless separately registered and acting under an appropriate advisory arrangement.

The Distributor shall promptly notify AlphaVerse and affected Clients where a regulatory event materially affects its ability to continue the relevant distribution services.

# 6. CLIENT RESPONSIBILITIES

The Client shall provide accurate and current information, review scheme documents and disclosures, make the final investment decision, provide separate consent for transactions where required, protect authentication credentials, and understand that mutual fund investments are subject to market risk.

# 7. TRANSACTION CONSENT

The Client makes the final decision for each transaction. No Platform information or prior consent constitutes a standing instruction.

Each transaction shall require separate consent through the applicable workflow. The Platform may record the scheme/security, transaction type, amount or units, date/time, information displayed, agreement version and consent status.

Unless the relevant workflow specifies otherwise, mutual fund transaction consent may expire after 24 hours. An expired consent shall not constitute continuing authority.

The Distributor shall not execute or cause execution of a transaction solely on the basis of stale, expired or implied consent.

# 8. REGULAR AND DIRECT PLANS; DISTRIBUTION REMUNERATION

The Client acknowledges that Regular and Direct Plans may have different expense structures and that distribution remuneration may be associated with Regular Plan distribution, subject to the applicable regulatory framework.

The Distributor may receive commission/remuneration from the relevant Asset Management Company or other permitted source in accordance with Applicable Law.

The Distributor shall disclose the nature of such remuneration and such other scheme-specific information as is required by Applicable Law. Commission may vary by scheme, plan, AMC and applicable arrangements.

The Distributor shall not make any prohibited rebate, pass-back or other payment to the Client.

# 9. FEES AND CHARGES

The Client shall not pay AlphaVerse any fee unless a direct AlphaVerse charge is expressly disclosed before or at the relevant acceptance/payment stage.

Any distributor charges payable by the Client shall be disclosed in accordance with Applicable Law.

The commercial arrangement between AlphaVerse and the Distributor shall be governed by a separate professional agreement and shall not convert the Distributor into an Investment Adviser.

# 10. CLIENT DATA AND PRIVACY

The Client authorises lawful processing of Client Data for Platform operation, investor servicing, record keeping, security, regulatory compliance and other disclosed lawful purposes.

The Distributor shall have access only to information made available to it through the Platform and necessary for its permitted services.

AlphaVerse shall not sell Client Data or share it with third parties for unrelated marketing purposes, subject to lawful disclosures and permitted processing.

# 11. DATA SECURITY

AlphaVerse shall maintain reasonable technical and organisational measures intended to protect Client Data. The Client acknowledges that no electronic system can be guaranteed completely secure.

# 12. PLATFORM INFORMATION AND RISK

Platform information may be incomplete, delayed or dependent on third-party data. Historical performance is not a forecast or guarantee. Prices, NAVs or other displayed values may not equal the actual transaction value or execution outcome.

Mutual fund investments are subject to market risks. The value of investments can rise or fall and capital may be at risk. The Client should read applicable scheme documents and obtain independent advice where required.

# 13. RECORDS AND AUDIT TRAIL

AlphaVerse may retain the Client identity, Distributor identity, information displayed, transaction-consent records, timestamps, Agreement version, electronic acceptance record, document fingerprint/hash, communications and relevant technical metadata.

Records shall be retained for at least the minimum period required by Applicable Law and, where AlphaVerse has adopted a longer contractual retention policy, for such longer period, subject to any longer statutory, regulatory, legal or dispute-preservation requirement.

A Client deletion request shall not require deletion of records which are legally required to be retained.

# 14. INTELLECTUAL PROPERTY

All intellectual property in AlphaVerse's Platform, software, algorithms, interfaces, trademarks and documentation remains with AlphaVerse or its licensors. The Client receives only a limited right to use the Platform while access is permitted.

# 15. CONFIDENTIALITY

Each Party shall protect confidential information received from another Party, except where disclosure is required or permitted by law or necessary for lawful performance of the Agreement. These obligations survive termination.

# 16. GRIEVANCE REDRESSAL

Complaints concerning distribution services should first be addressed to the Distributor. Complaints concerning Platform functionality should be addressed to AlphaVerse through its Platform grievance mechanism.

Where applicable, the Client may use SEBI's prescribed grievance mechanisms, including SCORES, and applicable Online Dispute Resolution mechanisms. Nothing limits statutory remedies.

# 17. TERM AND TERMINATION

The Agreement commences upon electronic acceptance and continues until terminated. The Client or Distributor may terminate in accordance with applicable notice requirements and Applicable Law.

AlphaVerse may suspend or terminate Platform access where the Distributor relationship ends, continued provision becomes unlawful, the Distributor's regulatory status is no longer valid, there is material misuse, or another lawful ground exists.

# 18. EFFECT OF TERMINATION

Termination does not invalidate completed transactions or legally required records. Unexecuted transaction consents shall lapse unless Applicable Law requires otherwise. Provisions intended to survive, including confidentiality, intellectual property, records, data retention, liability and dispute provisions, survive termination.

# 19. CHANGES AND VERSION CONTROL

Material revisions shall receive a new Agreement version. Where required, the revised Agreement shall be presented for electronic acceptance. The historical accepted version shall remain preserved and retrievable.

# 20. ELECTRONIC COMMUNICATION

The Client consents to receiving contractual notices, disclosures, statements and other communications electronically through the Platform, registered email, registered mobile number or other legally permissible electronic channels.

# 21. ELECTRONIC RECORDS AND EVIDENCE

Electronic records maintained in the ordinary course of the Platform may be used as evidence of acceptance, consent, communications, information displayed, transaction history and the applicable Agreement version, subject to Applicable Law and the Client's right to challenge authenticity or integrity.

# 22. LIMITATION OF LIABILITY

Nothing excludes liability that cannot legally be excluded. AlphaVerse is not responsible merely because an investment loses value. The Distributor remains responsible for its own distribution activities. AlphaVerse is not responsible for market movements, third-party data errors, AMC, exchange, registrar, broker, bank or other intermediary failures except to the extent legally attributable to AlphaVerse.

# 23. FORCE MAJEURE

Neither AlphaVerse nor the Distributor shall be liable for failure caused by circumstances beyond reasonable control, subject to Applicable Law.

# 24. GOVERNING LAW AND JURISDICTION

This Agreement is governed by Indian law. Subject to statutory and regulatory remedies, courts at [●] shall have jurisdiction.

# 25. SEVERABILITY

If any provision is invalid or unenforceable, the remaining provisions continue to the extent legally permissible.

# 26. ENTIRE AGREEMENT

This Agreement together with disclosures and terms electronically incorporated into it constitutes the agreement governing its subject matter.

# 27. CLIENT DECLARATION AND ELECTRONIC ACCEPTANCE

I confirm that I have read and understood this Agreement and the disclosures presented to me. I understand that the Distributor is acting as a distributor and not as my Investment Adviser under this Agreement, and that AlphaVerse is a technology provider.

I understand that information displayed through the Platform is not, merely by being displayed, personalised investment advice. I understand that I make my own investment decisions and that investments involve risk.

I agree to this Agreement and consent to its electronic execution and to the creation and retention of an electronic record of my acceptance, including the Agreement version and document fingerprint/hash.

[ I AGREE AND ELECTRONICALLY SIGN ]

# ELECTRONIC EXECUTION RECORD

Agreement Version: System generated; Client Identity: authenticated account; Distributor: distributor relationship; Registration/ARN: distributor profile; Acceptance Date/Time: system generated; Authentication Method: system generated; IP Address/Device/Session: where captured; Document Hash/Fingerprint: system generated; Acceptance Status: Accepted/Declined; Electronic Signature Record: system generated, where applicable.

# END OF AGREEMENT

No physical signature, handwritten name or manually entered date is required where the electronic execution method used is legally valid.
