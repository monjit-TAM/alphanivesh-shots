# Brief for counsel — Section 9 (Fees) of the Client–Adviser–AlphaVerse agreement

**From:** Edhaz Markets Private Limited (operating as AlphaVerse), Mumbai
**Re:** `client_ria_v1-draft.md`, §9 and §3.2, as drafted 22 September 2026
**Ask:** confirm the structure is lawful as drafted, or tell us what to change. We will not put this agreement in front of a client until you have.

---

## 1. What we are building, in plain terms

AlphaVerse is a software platform (a "software/digital provider" in the sense SEBI and AMFI use the term). It holds an investor's portfolio across asset classes, computes analytics — what the holdings are worth, how they have behaved, base rates from history, tax positions — and shows the investor **facts**. It does not recommend what to buy or sell.

Where an investor wants a **recommendation**, the platform routes it to a SEBI-registered Investment Adviser (RIA) associated with the platform. The RIA is the adviser of record, sees the platform's analytical output, and may accept, modify, suppress or replace it before it reaches the client. The RIA carries the advisory responsibility and the SEBI registration; the platform carries the technology.

Two charges arise:

1. **A Platform Fee**, charged by AlphaVerse, flat (₹1,000 or ₹2,000 a month depending on tier), for the technology and analytics. Not linked to assets, transactions or returns. Payable whether or not the client engages an adviser.
2. **An Advisory Fee**, set and charged by the RIA, within SEBI's fee limits. AlphaVerse takes no share of it.

The commercial wish is that **the client pays both in one place** — on the platform — and the Advisory Fee reaches the RIA. AlphaVerse does not want to hold client money, and §3.2 says it does not.

## 2. How §9 is drafted to achieve that

- §9.1–9.2: the Platform Fee is AlphaVerse's own, for technology only; paying it creates no advisory relationship with AlphaVerse.
- §9.3: the Advisory Fee is the RIA's — set, disclosed and owned by the RIA; AlphaVerse receives no part of it.
- §9.4: AlphaVerse *facilitates* collection but the fee **never enters an AlphaVerse account**. It moves by one of two routes:
  (a) **CeFCoM** — SEBI's centralised fee collection mechanism for IAs/RAs (operated through BSE), where the RIA has opted in; or
  (b) an **RBI-authorised payment aggregator's escrow/nodal account**, settling directly to the RIA's bank account within the aggregator's settlement period.
- §9.5–9.6: full per-payment records; fee disputes and refunds sit with the party that charged the fee.
- §9.7: anything AlphaVerse and the RIA agree between themselves is separate, is not a share of the Advisory Fee, and does not dilute the RIA's responsibility.
- §9.8: if the law comes to mandate one collection route, §9.4 collapses to it.
- §3.2 has been amended to cross-refer to §9.4 so the "does not hold the Client's money" statement remains true.

## 3. The questions we need answered

**Q1 — CeFCoM.** Our understanding is that SEBI's centralised fee collection mechanism (circular of September 2024, operational through BSE) is **optional** for IAs and RAs, not mandatory. Is that still the position? If it becomes mandatory, does §9.8 carry the agreement across without re-execution, or would we need a fresh acceptance from every client?

**Q2 — Payment-aggregator route (§9.4(b)).** If the client pays the Advisory Fee through an RBI-authorised payment aggregator whose escrow settles to the RIA, and AlphaVerse merely initiates/presents the payment:
   (i) does AlphaVerse itself need Payment Aggregator authorisation under RBI's PA/PG framework, or does using a licensed aggregator suffice?
   (ii) is there any sense in which AlphaVerse is "collecting" client money for SEBI purposes, such that §3.2 would be untrue?
   (iii) are there conditions on the escrow (e.g. the RIA must be the merchant of record; the client's payment instruction must name the RIA) that we should build into the product?

**Q3 — SEBI IA Regulations on fee receipt.** The IA Regulations require fees to be received through banking channels / traceable means. Does a payment via an aggregator escrow satisfy that for the RIA? Anything about the fee having to be paid "directly" to the IA that route (b) would fall foul of?

**Q4 — Fee sharing / referral.** §9.7 permits a separate AlphaVerse–RIA arrangement for platform use, expressly not calculated as a share of the Advisory Fee. Please confirm this does not amount to prohibited fee-sharing or referral consideration under the IA Regulations, and advise on what that separate arrangement may and may not be priced on (flat per-seat, per-client, etc.).

**Q5 — Platform Fee characterisation.** Is there any risk that a flat subscription for portfolio analytics is read as "investment advice" (or as a research-analyst service) requiring registration, given that no recommendations are made without an RIA? What wording, if any, would you want added to §9.2 or §22 to keep that line clear? (The product deliberately shows "do nothing" as a valid outcome and labels every recommendation as the RIA's.)

**Q6 — GST.** Two suppliers (AlphaVerse for the Platform Fee, the RIA for the Advisory Fee) invoicing the same client through one checkout: confirm each must issue its own tax invoice and that AlphaVerse must not invoice the Advisory Fee. Any place-of-supply or e-invoicing wrinkle for the aggregator route?

**Q7 — Fee limits.** The IA Regulations cap advisory fees (fixed-fee and AUA-based modes, with the amounts revised in 2024–25). Since the RIA sets the fee, is it enough that §9.3 and §9.8 bind them to the limits, or should the platform enforce the cap in software (we can)?

**Q8 — MFD and broker agreements.** The parallel `client_mfd_v1.md` and `client_broker_v1.md` are drafted on a distribution/execution basis (no advice; the MFD's remuneration is trail commission from the AMC, not a client fee). Please confirm nothing in the SDP structure above changes those, and whether a client who holds both an RIA and an MFD relationship through the platform needs any cross-disclosure.

## 4. What we will do in the software once you confirm

- Show the Platform Fee and the Advisory Fee as two separately labelled lines, with the payee named on each, before acceptance and on every invoice.
- Route the Advisory Fee via CeFCoM when the RIA's registration record on our platform says they have opted in; otherwise via the aggregator escrow, with the RIA as payee.
- Store, per payment: amount, date, adviser, route, settlement reference (§9.5) — this is already in the design of our advice ledger.
- Keep `AGREEMENTS_LIVE` off for this document until your written sign-off.

## 5. Facts you may need

- Entity: Edhaz Markets Private Limited, Bakers Field, A22, Shastri Nagar, Lokhandwala, Andheri West, Mumbai. Governing law and jurisdiction: Mumbai (§25).
- AlphaVerse is not currently SEBI-registered in any capacity (§22 addresses a future registration).
- The platform records every piece of advice shown, the RIA's edits to it, and the client's per-order consent, with timestamps and document hashes.
