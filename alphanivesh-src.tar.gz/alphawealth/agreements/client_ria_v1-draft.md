# Digital Client–Investment Adviser–AlphaVerse Technology Agreement

**Version v1 — counsel review. Section 9 is drafted to the SDP model and awaits
counsel's sign-off before `AGREEMENTS_LIVE` is turned on for this document.**

Jurisdiction is Mumbai (§25).

**What §9 now says, in one paragraph.** Two charges, kept apart. AlphaVerse
charges its own flat *Platform Fee* for technology, data and analysis — facts,
not advice. The Adviser sets and charges their own *Advisory Fee*, within
SEBI's limits, and AlphaVerse takes no share of it. AlphaVerse *facilitates
collection* of the Advisory Fee but never receives it into its own account:
the money moves through SEBI's centralised fee collection mechanism (CeFCoM)
where the Adviser has opted in, and otherwise through an RBI-authorised
payment aggregator's escrow, straight to the Adviser. That keeps §3.2 true
("AlphaVerse does not hold the Client's money") while giving the Client one
place to pay.

**Questions for counsel** are in `COUNSEL_BRIEF_fee_clause.md` beside this
file. Until they are answered this document stays off. The distributor and
broker agreements are complete and unaffected.

---

DIGITAL CLIENT–INVESTMENT ADVISER–ALPHAVERSE
TECHNOLOGY AGREEMENT
Agreement Version: [SYSTEM GENERATED VERSION NUMBER]

Effective upon Electronic Acceptance


## Important Information
This is a legally binding electronic agreement between: (1) the Client; (2) the SEBI-registered Investment Adviser
selected by the Client; and (3) AlphaVerse, as the technology service provider.

The identity and details of the Client and the Investment Adviser are captured and authenticated electronically
during the Client's onboarding and acceptance process and form part of the electronic record of this Agreement.

No physical signature, handwritten name, date or physical execution is required where the electronic acceptance
mechanism used for this Agreement is legally valid.

By completing the electronic acceptance process, the Client confirms that the Client has read, understood and
agreed to this Agreement.


## 1. PARTIES AND ELECTRONIC IDENTIFICATION
1.1 Client. The person who completes the onboarding and electronic acceptance process for this Agreement shall
be the “Client”. The Client's identity shall be established through the authentication mechanism used by
AlphaVerse and/or the Investment Adviser during onboarding.

1.2 Investment Adviser. The Investment Adviser associated with the Client through the AlphaVerse Platform shall
be the “Investment Adviser” or “Adviser”. The Adviser's identity, SEBI registration number and other regulatory
particulars shall be maintained electronically in the Client's account and/or relevant Adviser profile.

1.3 AlphaVerse. “AlphaVerse” means the AlphaVerse legal entity operating and providing the technology platform
to the Adviser and Client.


## 2. ELECTRONIC ACCEPTANCE
2.1 Digital execution. This Agreement is intended to be entered into electronically. The Client's electronic
acceptance shall constitute the Client's execution and acceptance of this Agreement to the extent permitted under
Applicable Law.

2.2 No physical signature required. No handwritten signature, physical signature page, handwritten date or
physical execution shall be required where the electronic acceptance mechanism satisfies Applicable Law.
2.3 Acceptance action. The Client may be required to review or access this Agreement, confirm that the Client has
read and understood it, provide the required electronic authentication, and click/select the designated acceptance
button or complete the prescribed electronic signing process.

2.4 Electronic record. Upon acceptance, AlphaVerse shall create an electronic record associating the Client with
this Agreement, the Agreement version, the exact text accepted, date and time of acceptance, authentication
method, relevant technical metadata, document fingerprint/hash and other information required to establish the
integrity and authenticity of the record.

2.5 Version control. Every version of this Agreement shall carry a unique version number. The version accepted by
the Client shall remain identifiable in the electronic record. A subsequent amendment shall not overwrite the
historical version accepted by the Client.

2.6 Document fingerprint. AlphaVerse may generate and retain a cryptographic hash, fingerprint or equivalent
electronic identifier of the Agreement accepted by the Client.
2.7 Evidence of acceptance. The electronic record maintained by AlphaVerse shall constitute evidence of the
Client's electronic acceptance, subject to Applicable Law and the rights of the Client to challenge the authenticity or
integrity of such record.


## 3. NATURE OF THE RELATIONSHIP
3.1 The investment advisory relationship is between the Client and the Investment Adviser.

3.2 AlphaVerse is a technology provider. AlphaVerse does not provide investment advice to the Client under this
Agreement and does not independently recommend securities or investment products to the Client. AlphaVerse
does not hold the Client's money or securities; where the Platform facilitates payment of the Adviser's fee it does
so only in the manner set out in Section 9.4, under which the fee does not pass through any account of AlphaVerse.

3.3 The Investment Adviser is responsible for the investment advice provided to the Client and shall independently
consider the Client's circumstances and exercise professional judgment.

3.4 The Platform may generate analytical outputs, calculations, insights or other information for use by the Adviser.
Such output does not automatically constitute Advice. The Adviser may accept, modify, reject, withhold or
independently provide Advice. The Platform shall, where technically supported, maintain a record of the original
output and the final Advice.


## 4. INVESTMENT ADVISER'S RESPONSIBILITIES
The Adviser shall: (a) maintain a valid SEBI registration as required by Applicable Law; (b) comply with Applicable
Law applicable to Investment Advisers; (c) undertake appropriate client risk profiling; (d) consider suitability before
providing Advice; (e) exercise independent professional judgment; (f) act in accordance with its regulatory
obligations; (g) disclose material conflicts of interest; (h) provide the Client with applicable fee and other
disclosures; and (i) notify the Client and AlphaVerse if the Adviser's registration ceases, is suspended, cancelled or
otherwise becomes unavailable for providing the relevant services.


## 5. CLIENT'S RESPONSIBILITIES
The Client agrees to: (a) provide accurate and complete information; (b) keep information reasonably current; (c)
inform the Adviser of material changes relevant to the advisory relationship; (d) review Advice before making an
investment decision; (e) make the final investment decision; (f) provide separate consent for each transaction; (g)
protect authentication credentials and access information; and (h) understand that investments are subject to
market risks.


## 6. NO DISCRETIONARY AUTHORITY
6.1 The Client retains complete authority over whether to undertake an investment transaction.

6.2 No Advice, Platform output or previous consent shall constitute a standing instruction to purchase, sell,
redeem, switch or otherwise transact in any security or investment product.

6.3 Each transaction shall require a separate Client consent. The consent may identify the investment/security,
quantity or amount, transaction type, relevant transaction information and date/time of consent.
6.4 Unless otherwise specified by the relevant workflow, consent relating to shares shall expire after 30 minutes
and consent relating to mutual funds shall expire after 24 hours. An expired consent shall not constitute continuing
authority.

6.5 Any unexecuted transaction consent shall lapse upon termination of the Client's relationship under this
Agreement, unless otherwise required by Applicable Law.


## 7. CLIENT DATA
7.1 The Client authorises the Adviser to access information reasonably required for providing investment advisory
services, including holdings, transactions, portfolio information, financial information, risk-profile information and
other information made available through the Platform.

7.2 The Adviser shall only have access to information made available through the Platform. AlphaVerse shall not
be required to provide information that its technology is designed to withhold.
7.3 Certain information generated by or provided through private Client interactions with Platform functionality may
not be accessible to the Adviser.

7.4 Client Data shall be used for providing the Platform, providing the agreed advisory services, maintaining
records, security and fraud prevention, regulatory compliance, service administration and other lawful purposes
disclosed to the Client.

7.5 AlphaVerse shall not sell Client Data or share it with third parties for unrelated marketing purposes.


## 8. DATA SECURITY
AlphaVerse shall maintain reasonable technical and organisational measures intended to protect Client Data. The
Client acknowledges that no electronic system can be guaranteed to be completely secure. The Client shall
immediately report suspected unauthorised access or misuse.


## 9. FEES

9.1 **Two separate charges.** Two distinct amounts may be payable by the Client in connection with this Agreement, and each shall be disclosed separately, in rupees, before acceptance:

(a) the **Platform Fee**, which is AlphaVerse's own charge for access to the Platform's technology, data, analytics and record-keeping. The Platform Fee is a fixed subscription amount, is not calculated by reference to the Client's assets, transactions or returns, and is payable to AlphaVerse whether or not the Client engages an Adviser; and

(b) the **Advisory Fee**, which is the Investment Adviser's charge for investment advice, is determined solely by the Adviser within the limits prescribed under the SEBI (Investment Advisers) Regulations, 2013 and circulars thereunder, and is payable to the Adviser.

9.2 **What the Platform Fee is for.** The Platform Fee is consideration for technology and information services only. It does not entitle the Client to investment advice, and payment of it does not create an advisory relationship with AlphaVerse. The Platform Fee, its amount, billing period, applicable taxes and the means of paying it shall be shown to the Client electronically before acceptance and before any change.

9.3 **The Advisory Fee is the Adviser's.** The Adviser shall disclose the Advisory Fee to the Client electronically through the Platform before or at the time of acceptance, stating the amount or rate, the basis of calculation, the period it covers, applicable taxes and the mode of payment. AlphaVerse does not set, negotiate, recommend, guarantee or share in the Advisory Fee, and receives no part of it.

9.4 **Collection of the Advisory Fee.** For the Client's convenience the Platform may present the Advisory Fee for payment alongside the Platform Fee. In doing so AlphaVerse acts only as a facilitator of collection on the Adviser's instruction and does not, at any time, receive the Advisory Fee into an account owned or controlled by AlphaVerse. The Advisory Fee shall move from the Client to the Adviser by one of the following means, as disclosed to the Client at the time of payment:

(a) where the Adviser participates in the centralised fee collection mechanism for investment advisers established under SEBI's directions (CeFCoM), through that mechanism; or

(b) otherwise, through an escrow or nodal arrangement maintained by a payment aggregator authorised by the Reserve Bank of India, under which the amount is settled directly to the Adviser's designated bank account within the settlement period applicable to that arrangement.

9.5 **Records and statements.** The Platform shall record, for each Advisory Fee payment, the amount, the date, the Adviser to whom it was paid, the collection route under 9.4 and the settlement reference, and shall make that record available to the Client under Section 15 and to the Adviser. Nothing in this Section relieves the Adviser of the Adviser's own obligations under Applicable Law in respect of fee disclosure, receipts and records.

9.6 **Refunds and disputes.** A dispute about the Advisory Fee is a matter between the Client and the Adviser under Section 16, and any refund of it is the Adviser's to make. A dispute about the Platform Fee is a matter between the Client and AlphaVerse. AlphaVerse shall assist either party with the records under 9.5.

9.7 **Arrangements between AlphaVerse and the Adviser.** Any consideration flowing between AlphaVerse and the Adviser for use of the Platform is governed by a separate agreement between them, shall not be funded from or calculated as a share of the Advisory Fee, and shall not alter the Adviser's responsibility to the Client under Section 4.

9.8 **Compliance.** All fees charged in connection with investment advisory services shall comply with the SEBI (Investment Advisers) Regulations, 2013 and applicable circulars, including any limits on the amount or basis of advisory fees and any requirement as to the manner of their collection. Where Applicable Law comes to require that advisory fees be collected only through a specified mechanism, 9.4 shall be read as requiring that mechanism.


## 10. PLATFORM INFORMATION
The Client acknowledges that information displayed through the Platform may be based on information available to
AlphaVerse; may be incomplete, delayed or subject to third-party data limitations; historical figures are not
forecasts or guarantees; displayed prices may represent the last observed price and may not be the actual price at
which an order is executed; and the Platform may state that a calculation or item is unavailable where it cannot
reliably compute or verify it.


## 11. INVESTMENT RISK
The Client understands and acknowledges that investment involves risk; the value of investments may rise or fall;
capital may be at risk; past performance is not indicative of future performance; no Advice guarantees a return;
market prices may change between Advice and transaction execution; and actual investment outcomes may differ
materially from historical or projected information.


## 12. INTELLECTUAL PROPERTY
All intellectual property rights in AlphaVerse's software, Platform, algorithms, interfaces, technology, trademarks,
documentation and related materials shall remain with AlphaVerse or its licensors. The Client receives only the
right to use the Platform during the period for which access is permitted.


## 13. CONFIDENTIALITY
Each Party shall maintain confidentiality of confidential information received from another Party, except where
disclosure is required by law, regulation, court order or otherwise permitted under this Agreement. These
obligations shall survive termination.


## 14. RECORD KEEPING AND AUDIT TRAIL
AlphaVerse may maintain an electronic audit trail containing, where applicable: Client identity; Adviser identity;
Advice record; original Platform output; changes made by the Adviser; final Advice; transaction consent;
information displayed to the Client; timestamp; Agreement version; electronic acceptance record; document
fingerprint/hash; and relevant technical metadata.

Records shall be retained for at least the minimum period required under Applicable Law and, where AlphaVerse
has adopted a longer contractual retention period, for such longer period, subject to any longer statutory,
regulatory, legal or dispute-preservation requirement.

Termination of this Agreement shall not require deletion of records that AlphaVerse or the Adviser is legally
required to retain.


## 15. CLIENT'S RIGHT TO INFORMATION
The Client may request information relating to the Client's relationship and records, subject to Applicable Law,
confidentiality obligations and legitimate restrictions applicable to third-party information. Where records are
required to be retained by law, such records shall not be deleted merely because the Client requests deletion.


## 16. GRIEVANCE REDRESSAL
16.1 A complaint concerning investment Advice shall first be addressed to the Investment Adviser.

16.2 A complaint concerning AlphaVerse's technology or Platform shall be addressed to AlphaVerse through the
grievance mechanism made available on the Platform.

16.3 Where applicable, the Client may approach SEBI's prescribed grievance redressal mechanism, including
SCORES, and the applicable Online Dispute Resolution mechanism. Nothing in this Agreement limits any statutory
right or remedy available to the Client.


## 17. TERM AND TERMINATION
This Agreement shall commence when electronically accepted by the Client and shall remain effective until
terminated.

The Client or Adviser may terminate the advisory relationship in accordance with the applicable notice
requirements and Applicable Law.

AlphaVerse may suspend or terminate Platform access where the underlying Adviser relationship ends, continued
provision becomes unlawful, the Adviser's regulatory status is no longer valid, the Client materially misuses the
Platform, or another lawful ground for suspension or termination exists.


## 18. EFFECT OF TERMINATION
Termination shall not invalidate Advice already provided; shall not require deletion of legally required records; shall
cause unexecuted Transaction Consents to lapse unless Applicable Law requires otherwise; and shall terminate
Platform access in accordance with the applicable Platform terms. Clauses relating to confidentiality, intellectual
property, records, data retention, liability, dispute resolution and other provisions intended to survive shall continue
after termination.


## 19. CHANGES TO THE AGREEMENT
Every material revision shall receive a new Agreement version number. Where required, the revised Agreement
shall be presented to the Client for electronic acceptance before becoming effective. The version previously
accepted by the Client shall remain preserved in the electronic record. The current version shall not silently
overwrite the historical version accepted by the Client.


## 20. ELECTRONIC COMMUNICATION
The Client consents to receiving contractual notices, disclosures, statements, communications and other
documents electronically through the Platform, registered email, registered mobile number, secure electronic
communication or another legally permissible electronic channel. The Client may be required to maintain current
contact information.


## 21. ELECTRONIC RECORDS AND EVIDENCE
The Parties agree that electronic records maintained in the ordinary course of the Platform's operation may be
used as evidence of acceptance, communications, consent, Advice, information displayed, Agreement version and

relevant transaction history, subject to Applicable Law and the Client's right to dispute the authenticity or integrity of
such record.


## 22. ALPHAVERSE'S REGULATORY STATUS
AlphaVerse is acting as a technology provider under this Agreement. Any application, proposed application or
future registration of AlphaVerse with SEBI shall not, by itself, alter the nature of the services provided under this
Agreement. Any change in the regulatory role of AlphaVerse shall be implemented only in accordance with
Applicable Law and, where required, an appropriate amended or replacement agreement.


## 23. LIMITATION OF LIABILITY
Nothing in this Agreement shall exclude liability which cannot lawfully be excluded.

AlphaVerse shall not be responsible merely because an investment made by the Client following Advice results in
a loss.

The Adviser shall remain responsible for Advice provided by the Adviser.

AlphaVerse shall not be responsible for market movements, third-party data errors, broker/exchange/AMC failures
or transaction execution outcomes except to the extent liability arises from matters for which AlphaVerse is legally
responsible.


## 24. FORCE MAJEURE
Neither AlphaVerse nor the Adviser shall be liable for failure caused by circumstances beyond reasonable control,
subject to Applicable Law.


## 25. GOVERNING LAW
This Agreement shall be governed by the laws of India. Subject to statutory and regulatory remedies available to
the Client, courts having jurisdiction over Mumbai shall have jurisdiction.


## 26. SEVERABILITY
If any provision of this Agreement becomes invalid or unenforceable, the remaining provisions shall continue to the
extent legally permissible.


## 27. ENTIRE AGREEMENT
This Agreement, together with the disclosures and terms electronically incorporated into it, constitutes the
agreement governing the subject matter between the Parties.


## 28. CLIENT DECLARATION AND ELECTRONIC ACCEPTANCE
Before electronically accepting this Agreement, the Client shall be presented with the following declaration:
“I confirm that I have read and understood this Agreement and the disclosures presented to me. I understand that
the Investment Adviser is responsible for investment advice provided to me and that AlphaVerse is a technology
provider. I understand that I make my own investment decisions and that each transaction requires my separate
consent. I understand that investments involve risk and that past performance does not guarantee future results.”

“I agree to this Agreement and consent to its electronic execution and to the creation and retention of an electronic
record of my acceptance, including the Agreement version and document fingerprint/hash.”

The Client shall then select: I AGREE AND ELECTRONICALLY SIGN or such equivalent electronic acceptance
mechanism as may be prescribed by AlphaVerse. Upon completion of the electronic signing/acceptance process,
the Platform shall associate the Client's authenticated identity with the accepted Agreement version.


## Electronic Execution Record
Agreement Version: System generated

Client Identity: Retrieved from authenticated Client account

Investment Adviser: Retrieved from Adviser relationship

SEBI Registration No.: Retrieved from Adviser profile

Acceptance Date/Time: System generated

Authentication Method: System generated

IP Address: System generated, where captured

Device/Session Information: System generated, where captured

Document Hash/Fingerprint: System generated

Acceptance Status: Accepted / Declined

Electronic Signature Record: System generated, where applicable

This electronic record shall be associated with the Client's account and retained in accordance with Applicable
Law.


## End Of Agreement
No physical signature, handwritten name or manually entered date is required where the electronic execution
method used is legally valid.
