"""AlphaWealth API.

A thin HTTP layer over the canonical wealth model. The calculations live in
services/, so these routers do little more than validate input, call a service
and hand back the result.

Run locally:
    uvicorn api.main:app --host 127.0.0.1 --port 8100 --reload
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import db
from .routers import (accounts, advisers, agreements, alpha, analysis, ariv, audit, auth, away, cadence, commission, consent, dashboard, decision, discipline, engine, findings, followup, fund, goals, guide, holdings_upload, imports, judgement, language, liabilities, lookthrough, manual, merge, methodology, mf_execution, people, placing, professionals, profile, realised, recommendations, referrals, regime, review, share, story, stress, watch, ways, wealth)

log = logging.getLogger("alphawealth")


@asynccontextmanager
async def lifespan(app: FastAPI):
    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=10)
    log.info("database pool ready")
    yield
    db.get_pool().close()


app = FastAPI(
    title="AlphaWealth API",
    version="0.1.0",
    description=(
        "Consolidated multi-asset wealth for an investor or household, "
        "assembled from every source we can reach: CAS statements from the "
        "depositories and registrars, broker feeds, and manual entries."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# The dashboard is served from a different origin during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://alphanivesh.com",
        "https://www.alphanivesh.com",
        "http://localhost:8100",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



@app.middleware("http")
async def _pick_language(request, call_next):
    """Set the language for the request before anything computes a sentence.

    Read from `?lang=` first and the Accept-Language header second: a choice
    the reader made beats a default their browser was shipped with.
    """
    from .services import i18n

    i18n.use(i18n.resolve(
        request.headers.get("accept-language"),
        request.query_params.get("lang")))
    return await call_next(request)


app.include_router(auth.router)
app.include_router(wealth.router)
app.include_router(findings.router)
app.include_router(imports.router)
app.include_router(merge.router)
app.include_router(profile.router)
app.include_router(manual.router)
app.include_router(analysis.router)
app.include_router(story.router)
app.include_router(fund.router)
app.include_router(dashboard.router)
app.include_router(guide.router)
app.include_router(language.router)
app.include_router(methodology.router)
app.include_router(decision.router)
app.include_router(engine.router)
app.include_router(audit.router)
app.include_router(liabilities.router)
app.include_router(away.router)
app.include_router(share.router)
app.include_router(ariv.router)
app.include_router(followup.router)
app.include_router(recommendations.router)
app.include_router(holdings_upload.router)


@app.get("/api/health", tags=["Meta"], summary="Liveness and database check")
def health() -> dict:
    row = db.fetch_one("SELECT count(*) AS investors FROM investors")
    return {"status": "ok", "investors": row["investors"] if row else 0}
app.include_router(accounts.router)
app.include_router(cadence.router)
app.include_router(review.router)
app.include_router(ways.router)
app.include_router(people.router)
app.include_router(advisers.router)
app.include_router(judgement.router)
app.include_router(professionals.router)
app.include_router(referrals.router)
app.include_router(agreements.router)
app.include_router(consent.router)
app.include_router(placing.router)
app.include_router(goals.router)
app.include_router(mf_execution.router)
app.include_router(alpha.router)
app.include_router(watch.router)
app.include_router(commission.router)
app.include_router(regime.router)
app.include_router(realised.router)
app.include_router(discipline.router)
app.include_router(stress.router)
app.include_router(lookthrough.router)
