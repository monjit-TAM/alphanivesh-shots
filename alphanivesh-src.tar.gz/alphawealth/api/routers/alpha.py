"""The alpha plan: target, gap, barriers, moves, alpha."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import alpha, auth, wealth
from .auth import current_user

router = APIRouter(prefix="/api/alpha", tags=["Alpha plan"])


@router.get("/{investor_id}", summary="One directional plan for this portfolio")
def plan(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return alpha.plan(investor_id)


@router.get("/{investor_id}/letter", summary="The plan, as the adviser would say it")
def letter(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return alpha.letter(investor_id)
