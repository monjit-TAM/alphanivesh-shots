"""The commission meter: what regular plans have cost, running."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, commission, wealth
from .auth import current_user

router = APIRouter(prefix="/api/commission", tags=["Commission meter"])


@router.get("/{investor_id}", summary="Commission paid to date, per regular-plan fund")
def meter(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return commission.for_investor(investor_id)
