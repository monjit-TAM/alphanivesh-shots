"""The discipline meter: what the investor's own hands cost."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, discipline, wealth
from .auth import current_user

router = APIRouter(prefix="/api/discipline", tags=["Discipline meter"])


@router.get("/{investor_id}", summary="Churn, activity and SIP continuity over the last year")
def meter(investor_id: str, months: int = 12, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return discipline.meter(investor_id, months=max(1, min(36, months)))
