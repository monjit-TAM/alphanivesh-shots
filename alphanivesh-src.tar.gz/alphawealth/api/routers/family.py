"""The family view: allowances that are per person, used across the household."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, family, wealth
from .auth import current_user

router = APIRouter(prefix="/api/family", tags=["Family"])


@router.get("/{investor_id}/harvest", summary="Each member's unused tax-free allowance, and the family total")
def harvest(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    # Members this user may not see are neither shown nor counted in the totals.
    return family.harvest(investor_id, may_see=lambda iid: auth.may_see(user, iid))
