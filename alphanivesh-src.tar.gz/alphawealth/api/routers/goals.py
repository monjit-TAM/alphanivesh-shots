"""Goals: what somebody is saving towards, and which money is doing it."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import auth, change, competition, earmarks, goals, replay, wealth
from .auth import current_user

router = APIRouter(prefix="/api/goals", tags=["Goals"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


def _their_goal(user: dict, goal_id: str) -> str:
    from .. import db
    row = db.fetch_one("SELECT investor_id FROM goal WHERE id = %s", (goal_id,))
    if not row:
        raise HTTPException(status_code=404, detail="No such goal.")
    _theirs(user, row["investor_id"])
    return row["investor_id"]


@router.get("/kinds", summary="The kinds of goal")
def kinds() -> dict:
    return {"kinds": [{"kind": k, "name": n} for k, n in goals.KINDS.items()]}


@router.get("/{investor_id}", summary="Every goal, and where the plan stands")
def all_for(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return goals.all_for(investor_id)


@router.post("/{investor_id}", summary="Add a goal")
def create(investor_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    try:
        return goals.create(investor_id, **payload)
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.get("/one/{goal_id}", summary="One goal")
def one(goal_id: str, user: dict = Depends(current_user)) -> dict:
    _their_goal(user, goal_id)
    found = goals.one(goal_id)
    if not found:
        raise HTTPException(status_code=404, detail="No such goal.")
    return found


@router.put("/one/{goal_id}/monthly", summary="What goes in each month")
def monthly(goal_id: str, payload: dict = Body(...),
            user: dict = Depends(current_user)) -> dict:
    _their_goal(user, goal_id)
    goals.commit(goal_id, payload.get("monthly") or 0,
                 payload.get("step_up_pct") or 0)
    return goals.one(goal_id) or {}


@router.post("/one/{goal_id}/earmark", summary="Assign a holding to this goal")
def assign(goal_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    investor_id = _their_goal(user, goal_id)
    try:
        return earmarks.assign(
            goal_id, investor_id,
            payload.get("instrument_id") or "",
            payload.get("share_pct") or 100)
    except ValueError as err:
        # The refusal says which goals already hold it and how much is left,
        # which is what somebody needs to decide what to do about it.
        raise HTTPException(status_code=409, detail=str(err))


@router.delete("/one/{goal_id}/earmark/{instrument_id}",
               summary="Take a holding off this goal")
def release(goal_id: str, instrument_id: str,
            user: dict = Depends(current_user)) -> dict:
    _their_goal(user, goal_id)
    if not earmarks.release(goal_id, instrument_id):
        raise HTTPException(status_code=404,
                            detail="That was not assigned to this goal.")
    return earmarks.holdings_for(goal_id)


@router.get("/one/{goal_id}/replay", summary="How this plan has actually gone")
def how_it_went(goal_id: str, user: dict = Depends(current_user)) -> dict:
    """Every historical stretch of this goal's length, replayed.

    Separate from the goal itself because it is much slower -- it fetches
    thirteen years of NAV for every fund earmarked -- and because a page
    showing what somebody holds should not wait on it.
    """
    _their_goal(user, goal_id)
    return replay.for_goal(goal_id)


@router.get("/one/{goal_id}/currency",
            summary="What the rupee has done over stretches this long")
def currency_view(goal_id: str, user: dict = Depends(current_user)) -> dict:
    """For a goal priced in another currency: the rupee cost today, and what
    the same bill would have been at the end of every historical stretch of
    the goal's length. Rupee goals get {"foreign": false}."""
    _their_goal(user, goal_id)
    goal = goals.one(goal_id)
    if not goal:
        raise HTTPException(404, "No such goal.")
    return goal.get("currency_view") or {"foreign": False}


@router.get("/one/{goal_id}/glide", summary="The glide path: the mix this goal can carry for its years left")
def glide_path(goal_id: str, user: dict = Depends(current_user)) -> dict:
    """A step path by years left, the earmarked mix against it, and one
    instruction: redirect the monthly, or (inside three years) move the excess."""
    _their_goal(user, goal_id)
    from ..services import glide
    return glide.for_goal(goal_id)


@router.get("/one/{goal_id}/since", summary="What moved since last time, and why")
def since(goal_id: str, user: dict = Depends(current_user)) -> dict:
    """Today against the last recorded look at this goal: the market moved,
    the plan changed, the contributions did, or the rupee did. Also records
    today's look (at most once a day). Slow, because it replays."""
    _their_goal(user, goal_id)
    goal = goals.one(goal_id)
    if not goal:
        raise HTTPException(404, "No such goal.")
    replayed = replay.for_goal(goal_id)
    out = change.since_last(goal_id, goal, replayed)
    out["history"] = change.history(goal_id)
    return out


@router.get("/{investor_id}/competition",
            summary="Where goals want the same rupees, and what each choice costs")
def competing(investor_id: str, user: dict = Depends(current_user)) -> dict:
    """Committed monthlies against spare, holdings claimed by more than one
    goal, and for each contest the other goal's odds if it lost. Ranks
    nothing; recomputed every call."""
    _theirs(user, investor_id)
    return competition.for_investor(investor_id)


@router.get("/{investor_id}/unassigned", summary="What is not doing a job")
def unassigned(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return earmarks.unassigned(investor_id)


@router.get("/{investor_id}/holding/{instrument_id}",
            summary="Who has a claim on this holding")
def claimed(investor_id: str, instrument_id: str,
            user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return earmarks.claimed_on(investor_id, instrument_id)
