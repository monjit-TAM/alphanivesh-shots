"""Look-through exposure per company, the fund overlap matrix, and IRR per holding."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, lookthrough, wealth, xirr
from .auth import current_user

router = APIRouter(prefix="/api/lookthrough", tags=["Look-through"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="What the money is actually in, company by company")
def exposure(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return lookthrough.for_investor(investor_id)


@router.get("/{investor_id}/irr", summary="Each holding's own money-weighted return")
def irr(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return xirr.per_holding(investor_id)
