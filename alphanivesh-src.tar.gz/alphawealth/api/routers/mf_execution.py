"""Mutual-fund execution: link an investor to the fund rail, place consented
orders on it, and read them back."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from ..services import auth, fp, mf_execution, wealth
from .auth import current_user

router = APIRouter(prefix="/api/mf", tags=["Fund execution"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/rail", summary="Whether the fund rail is configured, and which environment")
def rail(user: dict = Depends(current_user)) -> dict:
    return fp.status()


@router.get("/{investor_id}/link", summary="Is this investor set up on the fund rail")
def link_state(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    found = mf_execution.link_for(investor_id)
    if not found:
        return {"linked": False, "can_transact": False, "rail": fp.status()}
    return {"linked": True, **mf_execution._public(found), "rail": fp.status()}


@router.post("/{investor_id}/link", summary="Set this investor up on the fund rail")
def make_link(investor_id: str, payload: dict = Body(...),
              user: dict = Depends(current_user)) -> dict:
    """Body: {pan, account_number, ifsc, holder_name?}. PAN and bank details
    are passed to the rail and not stored here."""
    _theirs(user, investor_id)
    try:
        return mf_execution.link(
            investor_id, pan=payload.get("pan") or "",
            account_number=payload.get("account_number") or "",
            ifsc=payload.get("ifsc") or "", holder_name=payload.get("holder_name"))
    except fp.NotConfigured as err:
        raise HTTPException(status_code=503, detail=str(err))
    except (ValueError, fp.RailError) as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.post("/orders/{consent_id}", summary="Place a consented fund order on the rail")
def place(consent_id: str, request: Request, payload: dict = Body(default={}),
          user: dict = Depends(current_user)) -> dict:
    """The consent must be the caller's investor's, open and unexpired. It is
    spent before the rail is touched; see mf_execution.place."""
    owner = mf_execution.db.fetch_one(
        "SELECT investor_id FROM order_consent WHERE id = %s", (consent_id,))
    if not owner:
        raise HTTPException(status_code=404, detail="No such consent.")
    _theirs(user, owner["investor_id"])
    try:
        return mf_execution.place(
            consent_id,
            user_ip=request.client.host if request.client else None,
            return_url=payload.get("return_url"))
    except fp.NotConfigured as err:
        raise HTTPException(status_code=503, detail=str(err))
    except ValueError as err:
        raise HTTPException(status_code=409, detail=str(err))


@router.get("/orders/{order_id}", summary="One fund order, refreshed from the rail")
def order(order_id: str, refresh: bool = True, user: dict = Depends(current_user)) -> dict:
    try:
        found = mf_execution.one(order_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="No such order.")
    _theirs(user, found["investor_id"])
    return mf_execution.refresh(order_id) if refresh and found["open"] else found


@router.get("/{investor_id}/orders", summary="This investor's fund orders")
def orders(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return {"orders": mf_execution.for_investor(investor_id), "rail": fp.status()}
