"""Your next ₹10,000: where new money should go, across everything held."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from ..services import auth, nextmoney, wealth
from .auth import current_user

router = APIRouter(prefix="/api/next", tags=["Next money"])


@router.get("/{investor_id}", summary="Where this much new money should go")
def plan(investor_id: str, amount: float = Query(10000, ge=0), mode: str = Query("lump"),
         user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return nextmoney.plan(investor_id, amount, mode)
