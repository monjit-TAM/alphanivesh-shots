"""The Portfolio Manager's desk: every asset class reviewed, with what to do and how."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, pm, wealth
from .auth import current_user

router = APIRouter(prefix="/api/pm", tags=["Portfolio manager"])


@router.get("/{investor_id}", summary="The portfolio manager's review of every asset class, and the book of orders")
def desk(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return pm.desk(investor_id)
