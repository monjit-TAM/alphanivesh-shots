"""The realised alpha ledger: what each move earned against what it replaced."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, realised, wealth
from .auth import current_user

router = APIRouter(prefix="/api/realised", tags=["Realised alpha"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="The ledger: moves, marks, roll-ups")
def ledger(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return realised.ledger(investor_id)


@router.post("/{investor_id}/mark", summary="Open rows from placed orders and mark them today")
def mark(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    opened = realised.open_from_consents(investor_id)
    result = realised.mark(investor_id)
    return {"opened": opened, **result, "ledger": realised.ledger(investor_id)}
