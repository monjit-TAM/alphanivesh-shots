"""The regime panel: readings from the long record, and the permits they issue."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ..services import regime
from .auth import current_user

router = APIRouter(prefix="/api/regime", tags=["Regime panel"])


@router.get("", summary="What the market's record permits this week")
def panel(user: dict = Depends(current_user)) -> dict:
    return regime.panel()


@router.get("/history", summary="What the panel read and permitted, day by day")
def history(days: int = 90, user: dict = Depends(current_user)) -> list:
    return regime.history(max(1, min(365, days)))
