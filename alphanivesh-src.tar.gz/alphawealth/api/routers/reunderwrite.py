"""The yearly re-underwrite: holdings older than seven years, read again."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, reunderwrite, wealth
from .auth import current_user

router = APIRouter(prefix="/api/reunderwrite", tags=["Re-underwrite"])


@router.get("/{investor_id}", summary="Every holding older than seven years: would it be bought today?")
def yearly(investor_id: str, years: int = 7, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return reunderwrite.for_investor(investor_id, years=max(3, min(20, years)))
