"""Household stress: today's holdings through 2008, 2020, a rupee fall, a rate rise."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, stress, wealth
from .auth import current_user

router = APIRouter(prefix="/api/stress", tags=["Household stress"])


@router.get("/{investor_id}", summary="What the holdings would have lost, and how long back")
def household(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return stress.for_investor(investor_id)
