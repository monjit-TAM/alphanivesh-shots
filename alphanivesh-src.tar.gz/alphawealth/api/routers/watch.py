"""The daily watch: what crossed a line, and when it was last checked."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, watch, wealth
from .auth import current_user

router = APIRouter(prefix="/api/watch", tags=["Daily watch"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="What is open now, and when it was checked")
def digest(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return watch.digest(investor_id)


@router.post("/{investor_id}/run", summary="Run the check now (slow: reads every holding)")
def run(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return watch.run(investor_id)
