"""The alpha plan: where this portfolio should be, what stands in the way,
and the moves — in order — that take it there.

Everything else in the service diagnoses. This finishes the sentence. It
composes the pieces that already exist (the holdings, the findings, the
equity verdicts, the fund screener, the tax harvest, the market record) into
ONE directional plan a person can act on:

  1. TARGET   -- the mix this person should hold, from their age, horizon,
                 risk capacity and the timing of their goals. Stated rules.
  2. GAP      -- current vs target, bucket by bucket, in rupees.
  3. BARRIERS -- what is stopping the portfolio from earning what it could:
                 weak holdings, cost drag, concentration, cap tilt, idle
                 money, missing asset classes, unused tax room.
  4. MOVES    -- sell / switch / buy / deploy, in order, each with the amount,
                 the reason, the tax cost and the alpha it is worth.
  5. ALPHA    -- the identifiable gain per year, by source, and what the
                 portfolio becomes.

What "alpha" means here, so it is never oversold: return the person is
entitled to and not collecting. Cost alpha (expense they need not pay), tax
alpha (exemption they are not using), quality alpha (holdings the verdict
engine would exit, replaced by ones it would hold), allocation alpha (money in
the wrong bucket for its job), and deployment alpha (new money placed with
the base rate on its side). Each is sized from the person's own figures. None
is a forecast; the rupee figures are arithmetic, the odds are counted.

The direction is firm because the adviser of record owns it: the engine
drafts, the registered adviser may edit or suppress, the person consents per
order. That chain is what lets this page say "sell" rather than "consider".
"""

from __future__ import annotations

import logging
import re
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db
from . import findings as findings_service
from . import wealth

log = logging.getLogger("alphanivesh.alpha")

# --- target-mix rules (documented, deliberately simple) --------------------

EQUITY_FLOOR, EQUITY_CEILING = Decimal(30), Decimal(80)
CAPACITY_ADJ = {"low": Decimal(-15), "medium": Decimal(0), "high": Decimal(10)}
# A goal this close caps equity, whatever the age says.
SOON_GOAL_CAP = {3: Decimal(40), 7: Decimal(60)}
GOLD_SHARE = {"high": Decimal(10), "medium": Decimal(7), "low": Decimal(5)}
# Within equity: large / mid / small, by the appetite the rules arrive at.
CAP_MIX = {
    "growth":   (Decimal(55), Decimal(25), Decimal(20)),
    "balanced": (Decimal(65), Decimal(25), Decimal(10)),
    "careful":  (Decimal(80), Decimal(20), Decimal(0)),
}
# A bucket within this many points of target is left alone.
TOLERANCE_PTS = Decimal(5)
# Below this many rupees a move is not worth the paperwork.
SMALLEST_MOVE = Decimal(25_000)
# Expense gap between a regular and a direct plan, where we do not hold the
# exact figure. Conservative.
REGULAR_DIRECT_GAP = Decimal("0.0075")
LTCG_EXEMPTION = Decimal(125_000)
LTCG_RATE = Decimal("0.125")

STABLE = {"bond", "gsec", "fixed_deposit", "cash", "debt", "ppf", "ppf_epf", "nps", "liquid"}
# Not part of the investable mix: the targets are set over what can be moved.
# These are shown beside the mix, not inside it -- a term policy or a flat is
# not "under-weight equity".
OUTSIDE = {"insurance", "real_estate", "unlisted", "aif", "other"}
GOLD = {"gold", "sgb"}


def _d(v: Any) -> Decimal:
    if isinstance(v, Decimal):
        return v
    try:
        return Decimal(str(v)) if v is not None and v != "" else Decimal(0)
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    n = int(abs(_d(v)))
    if n >= 10_000_000:
        return f"₹{n / 10_000_000:.2f} crore"
    if n >= 100_000:
        return f"₹{n / 100_000:.1f} lakh"
    return f"₹{n:,}"


def _pct(v: Any) -> str:
    return f"{_d(v).quantize(Decimal('0.1'))}%"


def _pick(d: dict, *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(d, dict) and d.get(k) not in (None, ""):
            return d[k]
    return default


# ---------------------------------------------------------------------------
# 1. The target
# ---------------------------------------------------------------------------

def target_for(investor_id: str) -> dict:
    """The mix this person should hold, and the rules that produced it."""
    from . import profile as profile_service, risk, goals as goals_service

    who = profile_service.get_profile(investor_id) or {}
    age = who.get("age")
    rules: list[str] = []

    equity = Decimal(55)
    if age:
        equity = Decimal(max(EQUITY_FLOOR, min(EQUITY_CEILING, Decimal(100 - int(age)))))
        rules.append(f"Start from 100 minus age: {int(age)} → {equity:.0f}% equity.")
    else:
        rules.append("No date of birth on file: started from 55% equity.")

    band = None
    try:
        cap = risk.capacity(investor_id) or {}
        band = cap.get("band")
    except Exception as err:
        log.info("capacity unavailable for %s: %s", investor_id, err)
    if band in CAPACITY_ADJ:
        equity += CAPACITY_ADJ[band]
        rules.append(f"Risk capacity is {band}: {'+' if CAPACITY_ADJ[band] >= 0 else ''}{CAPACITY_ADJ[band]:.0f} points.")

    soonest_years = None
    try:
        for g in (goals_service.all_for(investor_id) or {}).get("goals", []):
            y = _d(g.get("years_left"))
            if y > 0 and _d(g.get("still_needed")) > 0:
                soonest_years = y if soonest_years is None else min(soonest_years, y)
    except Exception as err:
        log.info("goals unavailable for %s: %s", investor_id, err)
    if soonest_years is not None:
        for within, cap_pct in sorted(SOON_GOAL_CAP.items()):
            if soonest_years <= within and equity > cap_pct:
                equity = cap_pct
                rules.append(f"A goal is {soonest_years:.1f} years out and not yet funded: equity capped at {cap_pct:.0f}%.")
                break

    horizon = _d(who.get("horizon_years"))
    if horizon and horizon < 3 and equity > Decimal(40):
        equity = Decimal(40)
        rules.append(f"Stated horizon is {horizon:.0f} years: equity capped at 40%.")

    equity = max(EQUITY_FLOOR - 10, min(EQUITY_CEILING + 5, equity))
    appetite = "growth" if equity >= 65 else "balanced" if equity >= 45 else "careful"
    if age and int(age) >= 55 and appetite == "growth":
        appetite = "balanced"
        rules.append(f"At {int(age)}, small-cap weight is held to the balanced mix.")

    gold = GOLD_SHARE["high" if equity >= 65 else "medium" if equity >= 45 else "low"]
    expenses = _d(who.get("monthly_expenses"))
    net = wealth.net_worth(investor_id) or {}
    total = _d(_pick(net, "total_value", "total", "value", default=0))
    cash = Decimal(5)
    if expenses > 0 and total > 0:
        cash = max(Decimal(3), min(Decimal(15), (expenses * 6 / total * 100)))
        rules.append(f"Six months of expenses ({_money(expenses * 6)}) kept liquid: {cash:.0f}%.")
    debt = Decimal(100) - equity - gold - cash
    if debt < 0:
        debt, equity = Decimal(0), Decimal(100) - gold - cash

    large, mid, small = CAP_MIX[appetite]
    return {
        "equity_pct": equity.quantize(Decimal("1")),
        "debt_pct": debt.quantize(Decimal("1")),
        "gold_pct": gold, "cash_pct": cash.quantize(Decimal("1")),
        "within_equity": {"large_pct": large, "mid_pct": mid, "small_pct": small},
        "appetite": appetite, "age": age, "capacity_band": band,
        "soonest_goal_years": (str(soonest_years) if soonest_years is not None else None),
        "rules": rules,
        "principle": ("A target is a starting point the adviser and the person agree on, "
                      "not a law. It is stated so the gap to it can be stated."),
    }


# ---------------------------------------------------------------------------
# 2. Where the money is now
# ---------------------------------------------------------------------------

DEBT_WORDS = ("liquid", "overnight", "money market", "bond", "duration", "gilt", "credit risk",
              "banking and psu", "banking & psu", "floater", "floating", "debt", "income fund",
              "conservative hybrid", "fixed maturity", "arbitrage", "ultra short", "low duration")
GOLD_WORDS = ("gold", "silver")
HALF_WORDS = ("balanced advantage", "dynamic asset", "multi asset", "equity savings")


def bucket_of(h: dict) -> tuple[str, Decimal]:
    """Which bucket a holding belongs to, and what share of it (hybrids split)."""
    ac = (h.get("asset_class") or "").lower()
    if ac == "equity":
        return "equity", Decimal(1)
    if ac in GOLD:
        return "gold", Decimal(1)
    if ac in ("cash", "fixed_deposit", "liquid"):
        return "cash", Decimal(1)
    if ac in STABLE:
        return "debt", Decimal(1)
    if ac in OUTSIDE:
        return "outside", Decimal(1)
    if ac in ("mutual_fund", "etf"):
        text = ((h.get("category") or "") + " " + (h.get("instrument_name") or h.get("name") or "")).lower()
        if any(w in text for w in GOLD_WORDS):
            return "gold", Decimal(1)
        if "liquid" in text or "overnight" in text:
            return "cash", Decimal(1)
        if any(w in text for w in HALF_WORDS):
            return "equity", Decimal("0.5")
        if any(w in text for w in DEBT_WORDS):
            return "debt", Decimal(1)
        return "equity", Decimal(1)
    return "other", Decimal(1)


def current_mix(holdings: list[dict]) -> dict:
    outside = sum((_d(h.get("current_value")) for h in holdings if bucket_of(h)[0] == "outside"), Decimal(0))
    total = sum((_d(h.get("current_value")) for h in holdings), Decimal(0)) - outside
    sums = {"equity": Decimal(0), "debt": Decimal(0), "gold": Decimal(0), "cash": Decimal(0), "other": Decimal(0), "outside": Decimal(0)}
    caps = {"large": Decimal(0), "mid": Decimal(0), "small": Decimal(0), "flexi": Decimal(0), "other": Decimal(0)}
    for h in holdings:
        v = _d(h.get("current_value"))
        if v <= 0:
            continue
        b, share = bucket_of(h)
        sums[b] += v * share
        if b == "equity" and share < 1:
            sums["debt"] += v * (1 - share)
        if b == "equity":
            ev = v * share
            if (h.get("asset_class") or "") == "equity":
                seg = findings_service._cap_band_for(h)
                seg = {"large_cap": "large", "mid_cap": "mid", "small_cap": "small"}.get(seg, "other")
            else:
                seg = _cap_of(h)
            caps[seg if seg in caps else "other"] += ev
    equity = sums["equity"]

    def share(x: Decimal) -> Decimal:
        return (x / total * 100).quantize(Decimal("0.1")) if total else Decimal(0)

    within = {}
    for seg in ("large", "mid", "small"):
        within[f"{seg}_value"] = caps[seg]
        within[f"{seg}_pct"] = (caps[seg] / equity * 100).quantize(Decimal("0.1")) if equity else Decimal(0)
    within["flexi_value"] = caps["flexi"]
    within["flexi_pct"] = (caps["flexi"] / equity * 100).quantize(Decimal("0.1")) if equity else Decimal(0)
    within["unclassified_value"] = caps["other"]

    return {"total": total, "outside": outside, "equity": equity, "debt": sums["debt"], "gold": sums["gold"], "cash": sums["cash"],
            "other": sums["other"], "equity_pct": share(equity), "debt_pct": share(sums["debt"]),
            "gold_pct": share(sums["gold"]), "cash_pct": share(sums["cash"]), "other_pct": share(sums["other"]),
            "within_equity": within}


def gaps(target: dict, now: dict) -> list[dict]:
    """Bucket by bucket: how far from target, in rupees, and which way."""
    total = now["total"]
    out = []
    for bucket in ("equity", "debt", "gold", "cash"):
        t, c = _d(target[f"{bucket}_pct"]), _d(now[f"{bucket}_pct"])
        diff = c - t
        rupees = (diff / 100 * total).quantize(Decimal("1"))
        tol = Decimal(2) if bucket == "cash" else TOLERANCE_PTS
        out.append({"bucket": bucket, "target_pct": str(t), "current_pct": str(c),
                    "difference_pts": str(diff.quantize(Decimal("0.1"))),
                    "rupees": str(rupees),
                    "direction": ("over" if diff > tol else "under" if diff < -tol else "on target")})
    we, wt = now["within_equity"], target["within_equity"]
    eq = now["equity"]
    for seg in ("large", "mid", "small"):
        t, c = _d(wt[f"{seg}_pct"]), _d(we[f"{seg}_pct"])
        diff = c - t
        out.append({"bucket": f"equity:{seg}", "target_pct": str(t), "current_pct": str(c),
                    "difference_pts": str(diff.quantize(Decimal("0.1"))),
                    "rupees": str((diff / 100 * eq).quantize(Decimal("1"))),
                    "direction": ("over" if diff > TOLERANCE_PTS * 2 else "under" if diff < -TOLERANCE_PTS * 2 else "on target")})
    return out


# ---------------------------------------------------------------------------
# 3. Barriers and 4. moves
# ---------------------------------------------------------------------------

def _verdicts(investor_id: str) -> dict:
    """Per-holding verdicts and buy picks from the rebalance engine, if any."""
    from . import rebalance_engine
    try:
        got = rebalance_engine.for_investor(investor_id) or {}
    except Exception as err:
        log.info("verdicts unavailable: %s", err)
        return {}
    if not got.get("available"):
        return {}
    return got


def _fund_candidates(categories: list[str], limit: int = 3, **kw) -> list[dict]:
    from . import restructure
    try:
        return restructure.options_for("alpha", categories, limit=limit, **kw)
    except Exception as err:
        log.info("candidates unavailable for %s: %s", categories, err)
        return []


def _locked_elss(h: dict, cache: dict) -> bool:
    """An ELSS inside its three-year lock-in cannot be sold. First-seen is a
    floor on the holding date, so this errs toward "locked", which is the safe side."""
    name = (h.get("instrument_name") or h.get("name") or "").lower()
    if "elss" not in name and "tax saver" not in name:
        return False
    bought = cache.get(h.get("instrument_id"))
    if bought is None:
        row = db.fetch_one(
            """SELECT LEAST((SELECT min(s.as_of) FROM holding_snapshots s WHERE s.instrument_id = %s AND s.as_of > '1990-01-01'),
                            (SELECT min(t.txn_date) FROM canonical_transactions t WHERE t.instrument_id = %s)) AS bought""",
            (h.get("instrument_id"), h.get("instrument_id")))
        bought = (row or {}).get("bought") or False
        cache[h.get("instrument_id")] = bought
    if not bought:
        return True
    return (date.today() - bought).days < 3 * 365


def _clip(text: str, limit: int = 220) -> str:
    """Cut at the last full sentence inside the limit, not mid-word."""
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    head = text[:limit]
    cut = max(head.rfind(". "), head.rfind("; "))
    return (head[:cut + 1] if cut > 60 else head.rsplit(" ", 1)[0] + "…").strip()


def _is_regular(h: dict) -> bool:
    name = (h.get("instrument_name") or h.get("name") or "").lower()
    plan = str((h.get("attributes") or {}).get("plan") or "").lower()
    return "regular" in name or plan == "regular"


def _cap_of(h: dict) -> str:
    cat = (h.get("category") or "").lower()
    name = (h.get("instrument_name") or h.get("name") or "").lower()
    for word, seg in (("small", "small"), ("mid", "mid"), ("large", "large"), ("bluechip", "large"),
                      ("flexi", "flexi"), ("multi", "flexi"), ("index", "large"), ("nifty", "large")):
        if word in cat or word in name:
            return seg
    return "other"


# Years after which a position is "legacy": bought in a different market, and
# worth asking whether it still earns its place rather than assuming it does.
LEGACY_YEARS = 7
# A fund in the bottom half of its category on the rolling record has stopped
# doing what it was bought for.
FUND_CULL_RANK_PCT = Decimal(50)


def _first_bought(investor_id: str) -> dict[str, date]:
    rows = db.fetch_all(
        "SELECT instrument_id, min(txn_date) AS first FROM canonical_transactions "
        "WHERE investor_id = %s AND lower(txn_type) LIKE 'buy%%' GROUP BY instrument_id",
        (investor_id,)) or []
    return {r["instrument_id"]: r["first"] for r in rows if r.get("first")}


def _instrument_codes(ids: list[str]) -> dict[str, dict]:
    if not ids:
        return {}
    rows = db.fetch_all(
        "SELECT id, native_code, category FROM instruments WHERE id = ANY(%s)", (ids,)) or []
    return {r["id"]: r for r in rows}


def _fund_rank(native_code: str, category: str) -> Optional[dict]:
    """Where a held fund sits in its own category today, on the rolling record."""
    from . import dataservice
    if not native_code or not category:
        return None
    try:
        rows = dataservice.mf_screener(category=category, sort="cat_rank", limit=300, plan="")
    except Exception as err:
        log.info("screener unavailable for %s: %s", category, err)
        return None
    for r in rows:
        if str(r.get("scheme_code")) == str(native_code):
            return {"rank": r.get("cat_rank"), "of": r.get("cat_n"), "roll3_median": r.get("roll3_median"),
                    "roll3_worst": r.get("roll3_worst"), "roll3_pos_pct": r.get("roll3_pos_pct"),
                    "ret_1y": r.get("ret_1y"), "cagr_5y": r.get("cagr_5y")}
    return None


def _merge_per_holding(moves: list[dict]) -> list[dict]:
    """One instruction per holding. Several moves on the same instrument become
    one 'restructure' row that says how the whole position is split."""
    by: dict[str, list[dict]] = {}
    order: list[str] = []
    for m in moves:
        k = m.get("instrument_id") or f"_{id(m)}"
        if k not in by:
            by[k] = []; order.append(k)
        by[k].append(m)
    out = []
    for k in order:
        group = by[k]
        if len(group) == 1 or k.startswith("_"):
            out.extend(group); continue
        total = sum(_d(m["amount"]) for m in group)
        name = group[0]["what"]
        for prefix in ("Sell ", "Reduce ", "Move ", "Switch ", "Trim "):
            if name.startswith(prefix):
                name = name[len(prefix):]
        name = name.split(" by ₹")[0].split(" to its direct")[0].split(" into a ")[0].split(" to 15%")[0]
        if name.startswith("₹"):
            name = name.split(" from ", 1)[-1]
        parts = []
        for m in group:
            a = _money(m["amount"])
            if m["kind"] == "sell":
                parts.append(f"{a} out to the buys below")
            elif m.get("alpha_kind") == "cost":
                parts.append(f"{a} into the same fund's direct plan")
            elif m["kind"] == "switch":
                parts.append(f"{a} into a large/flexi-cap fund")
        merged = {"kind": "restructure", "what": f"Restructure {name}: " + "; ".join(parts),
                  "amount": str(total.quantize(Decimal("1"))),
                  "why": "One instruction for the whole position rather than three that fight each other.",
                  "alpha_basis": " + ".join(sorted({m["alpha_basis"].split(":")[0] for m in group})),
                  "instrument_id": group[0]["instrument_id"], "side": "sell",
                  "asset_class": group[0].get("asset_class"), "bucket": group[0].get("bucket"),
                  "parts": group}
        for m in group:
            if m.get("alpha_per_year"):
                merged["alpha_per_year"] = str(_d(merged.get("alpha_per_year")) + _d(m["alpha_per_year"]))
                merged["alpha_kind"] = m["alpha_kind"]
            if m.get("into") and "into" not in merged:
                merged["into"] = m["into"]
        out.append(merged)
    return out


def plan(investor_id: str) -> dict:
    """The whole thing. Slow (screener + verdict engine); cache at the caller."""
    from . import harvest, market

    everything = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    holdings = [h for h in everything if bucket_of(h)[0] != "outside"]
    outside = [h for h in everything if bucket_of(h)[0] == "outside"]
    if not holdings:
        return {"ready": False, "why": "No holdings yet. Bring in a statement and this becomes a plan."}

    target = target_for(investor_id)
    # The regime panel: readings from the long record and the small permits
    # they issue -- the pace of new money, and a tilt of a few points inside
    # the band, applied to buys only. Nothing here sells.
    regime_panel = {}
    try:
        from . import regime
        regime_panel = regime.panel() or {}
    except Exception as err:
        log.info("regime panel unavailable: %s", err)
    permits = {p["permit"]: p for p in (regime_panel.get("permits") or [])}
    equity_tilt = _d((permits.get("equity_tilt_pts") or {}).get("value"))
    now = current_mix(holdings)
    total = now["total"]
    gap_rows = gaps(target, now)
    by_bucket = {g["bucket"]: g for g in gap_rows}

    verdicts = _verdicts(investor_id)
    sells_by = {str(_pick(s, "symbol", "stock_name", "name", default="")).upper(): s
                for s in (verdicts.get("sell") or [])}
    picks = verdicts.get("buy") or []

    barriers: list[dict] = []
    moves: list[dict] = []
    alpha: dict[str, Decimal] = {"cost": Decimal(0), "tax": Decimal(0)}
    if not target.get("age"):
        barriers.append({"code": "missing_dob", "what": "Date of birth not on file", "size": "0",
                         "why": "The equity target below starts from 55%, an average. Your age would set it to you.",
                         "watch": True, "ask": "dob"})
    touched: dict[str, Decimal] = {}          # instrument_id -> rupees already leaving it

    from .rebalance import _sellable

    def left_in(h: dict) -> Decimal:
        """What can still leave this holding. Zero for anything locked -- EPF,
        PPF, NPS, a policy, an ELSS inside its lock-in: the plan can route new
        money around them, but it cannot sell them, and saying "reduce EPFO"
        is the kind of instruction that costs the rest of the page its credibility."""
        if not _sellable(h) or _locked_elss(h, first_bought_cache):
            return Decimal(0)
        return max(Decimal(0), _d(h.get("current_value")) - touched.get(h.get("instrument_id"), Decimal(0)))

    first_bought_cache: dict = {}

    # Lot-level tax rule: a sell of something in gain that turns long-term
    # within 45 days is dated, not dropped -- "hold N more days first".
    try:
        tax_pos = {p_["instrument_id"]: p_ for p_ in harvest.positions(investor_id)}
    except Exception as err:
        log.info("tax positions unavailable: %s", err)
        tax_pos = {}

    def wait_for_lt(h: dict) -> Optional[int]:
        p_ = tax_pos.get(h.get("instrument_id"))
        if not p_ or p_["long_term"] or _d(p_["gain"]) <= 0:
            return None
        days = int(p_["months_to_long_term"]) * 30
        return days if 0 < days <= 45 else None

    def move(kind: str, what: str, amount: Decimal, why: str, *, basis: str, h: Optional[dict] = None,
             into: Optional[list] = None, alpha_per_year: Optional[Decimal] = None,
             alpha_kind: Optional[str] = None, side: Optional[str] = None,
             asset_class: Optional[str] = None, bucket: Optional[str] = None) -> Decimal:
        if kind in ("sell", "switch", "buy") and amount < SMALLEST_MOVE:
            return Decimal(0)
        row = {"kind": kind, "what": what, "amount": str(amount.quantize(Decimal("1"))), "why": why,
               "alpha_basis": basis, "instrument_id": (h or {}).get("instrument_id"),
               "side": side or {"sell": "sell", "buy": "buy", "switch": "switch"}.get(kind),
               "asset_class": asset_class or (h or {}).get("asset_class"), "bucket": bucket}
        if into:
            row["into"] = into
        if kind == "sell" and h is not None:
            wait = wait_for_lt(h)
            if wait:
                row["wait_days"] = wait
                row["why"] = (f"{why} Hold it {wait} more days first: it turns long-term then and the tax on the gain "
                              f"drops from 20% to 12.5%.")
                row["what"] = f"{what} (after {wait} days)"
        if alpha_per_year is not None and alpha_kind:
            row["alpha_per_year"] = str(alpha_per_year.quantize(Decimal("1")))
            row["alpha_kind"] = alpha_kind
            alpha[alpha_kind] += alpha_per_year
        moves.append(row)
        if h is not None and kind in ("sell", "switch"):
            touched[h["instrument_id"]] = touched.get(h["instrument_id"], Decimal(0)) + amount
        return amount

    # ---------------- SELLS: raise money from what should not stay ----------------
    raised = Decimal(0)
    equity_sold = Decimal(0)

    # A. Weak holdings the verdict engine would exit (quality).
    exit_value = Decimal(0)
    for h in holdings:
        if (h.get("asset_class") or "") != "equity":
            continue
        s_ = sells_by.get(str(h.get("symbol") or h.get("isin") or "").upper())
        if not s_:
            continue
        v = left_in(h)
        reason = str(_pick(s_, "reason", "rationale", "verdict", "why", default="the engine's verdict is reduce"))
        barriers.append({"code": "weak_holding", "what": h.get("instrument_name"),
                         "size": str(v.quantize(Decimal("1"))), "why": f"Verdict: reduce. {_clip(reason)}"})
        got = move("sell", f"Sell {h.get('instrument_name')}", v,
                   f"The verdict engine reads this as reduce — {_clip(reason)}",
                   basis="quality: capital out of a holding the engine would exit", h=h, side="sell", bucket="equity")
        exit_value += got; raised += got; equity_sold += got

    we, wt = now["within_equity"], target["within_equity"]
    # A2. Legacy holdings: bought in a different market, and the verdict or the
    # record says they have done their job. The gain is real; the question is
    # whether it will be earned again, and the holding's own record answers it.
    first = _first_bought(investor_id)
    codes = _instrument_codes([h.get("instrument_id") for h in holdings if h.get("instrument_id")])
    today = date.today()
    for h in holdings:
        if left_in(h) < SMALLEST_MOVE:
            continue
        bought = first.get(h.get("instrument_id"))
        years = ((today - bought).days / 365.25) if bought else None
        b, _ = bucket_of(h)
        if b != "equity":
            continue
        v = left_in(h)
        gain = _d(h.get("gain")); invested = _d(h.get("invested_value"))
        if (h.get("asset_class") or "") == "mutual_fund":
            code = codes.get(h.get("instrument_id"), {})
            rank = _fund_rank(code.get("native_code"), code.get("category") or h.get("category") or "")
            if rank and rank.get("rank") and rank.get("of") and _d(rank["rank"]) / _d(rank["of"]) * 100 > FUND_CULL_RANK_PCT:
                age_note = f"held {years:.0f} years, " if years else ""
                barriers.append({"code": "fund_fallen", "what": h.get("instrument_name"),
                                 "size": str(v.quantize(Decimal("1"))),
                                 "why": (f"{age_note}ranked {rank['rank']} of {rank['of']} in its category on the rolling "
                                         f"three-year record. It did its job in the market it was bought for; it is not doing it now.")})
                seg_over = (_cap_of(h) == "small" and _d(we["small_pct"]) > _d(wt["small_pct"]) + TOLERANCE_PTS * 2)
                if seg_over:
                    better = _fund_candidates(["Large Cap", "Flexi Cap"], limit=3)
                    move("switch", f"Switch out of {h.get('instrument_name')} into a large/flexi-cap fund", v,
                         f"Ranked {rank['rank']} of {rank['of']} today, and small-cap is already above what your profile carries. "
                         f"The replacement goes where the target is short.",
                         basis="quality + allocation: out of a lagging fund, into the segment the profile can hold",
                         h=h, into=better, side="switch", bucket="equity")
                else:
                    better = _fund_candidates([code.get("category") or h.get("category") or "Flexi Cap"], limit=3)
                    move("switch", f"Switch out of {h.get('instrument_name')} into the top of its category", v,
                         f"Ranked {rank['rank']} of {rank['of']} today. Same category, a fund that is earning its place.",
                         basis="quality: capital from a fund in the bottom half of its category to one at the top",
                         h=h, into=better, side="switch", bucket="equity")
        elif years and years >= LEGACY_YEARS and gain > 0 and invested > 0 \
                and str(h.get("symbol") or "").upper() not in sells_by:
            # A share held a long time with a large gain and no verdict to sell
            # is flagged, not sold: the engine says hold, so the question is
            # posed and the tax cost of acting is made visible.
            share_of_total_gain = _d(h.get("gain")) / max(sum(_d(x.get("gain")) for x in holdings if _d(x.get("gain")) > 0), Decimal(1)) * 100
            if share_of_total_gain >= 25:
                # The "topped" test: three facts from its own record. All three
                # against it and the plan acts, tax priced; two and it is said.
                from . import topped
                try:
                    tt = topped.test(h, topped.index_twelve_month())
                except Exception as err:
                    log.info("topped test unavailable for %s: %s", h.get("symbol"), err)
                    tt = {"readable": False}
                if tt.get("readable") and tt["verdict"] == "topped":
                    barriers.append({"code": "legacy_topped", "what": h.get("instrument_name"),
                                     "size": str(v.quantize(Decimal("1"))),
                                     "why": f"Held {years:.0f} years; {share_of_total_gain:.0f}% of all your gains sit here. {tt['say']}"})
                    got = move("sell", f"Exit {h.get('instrument_name')} — it has topped", v,
                               f"{tt['say']} Proceeds go to the buckets that are short.",
                               basis="quality: capital out of a legacy holding whose own record has turned", h=h, side="sell", bucket="equity")
                    raised += got; equity_sold += got; exit_value += got
                else:
                    tail = (f" {tt['say']}" if tt.get("readable") else
                            " The verdict engine still reads it as hold — so the plan keeps it, but a position this large from one era is the first to trim if its reading changes.")
                    barriers.append({"code": "legacy_winner", "what": h.get("instrument_name"),
                                     "size": str(v.quantize(Decimal("1"))),
                                     "why": f"Held {years:.0f} years; {share_of_total_gain:.0f}% of all your gains sit here.{tail}",
                                     "watch": True})

    # B. Concentration: one share above 15%.
    top = max(holdings, key=lambda h: _d(h.get("current_value")))
    if total and (top.get("asset_class") or "") == "equity":
        share = _d(top["current_value"]) / total * 100
        if share >= 25 and left_in(top) > 0:
            excess = (_d(top["current_value"]) - total * Decimal("0.15"))
            excess = min(excess, left_in(top))
            barriers.append({"code": "concentration", "what": top.get("instrument_name"),
                             "size": str(excess.quantize(Decimal("1"))),
                             "why": f"{share:.0f}% of everything in one share. A bad year for it is a bad year for you."})
            got = move("sell", f"Trim {top.get('instrument_name')} to 15% of the portfolio", excess,
                       f"{share:.0f}% of the portfolio is one share; above 15% the risk is not paid for.",
                       basis="allocation: concentration risk carries no extra expected return", h=top, side="sell", bucket="equity")
            raised += got; equity_sold += got

    # C. Equity above target: trim the holdings with least reason to stay.
    target_eq = _d(target["equity_pct"]) / 100 * total
    over = now["equity"] - equity_sold - target_eq
    if over > SMALLEST_MOVE and by_bucket["equity"]["direction"] == "over":
        barriers.append({"code": "equity_over", "what": "Equity above target",
                         "size": str(over.quantize(Decimal("1"))),
                         "why": f"{_pct(now['equity_pct'])} in equity against {_pct(target['equity_pct'])} for your age, horizon and capacity. A bad year hits harder than it needs to."})
        pool = sorted([h for h in holdings if bucket_of(h)[0] == "equity" and left_in(h) > 0],
                      key=lambda h: (0 if _cap_of(h) == "small" else 1, -left_in(h)))
        for h in pool:
            if over <= SMALLEST_MOVE:
                break
            v = min(left_in(h), over)
            got = move("sell", f"Reduce {h.get('instrument_name')} by {_money(v)}", v,
                       "Equity is above the target for your profile; this is the holding with the least reason to stay.",
                       basis="allocation: equity brought to the weight the profile can hold", h=h, side="sell", bucket="equity")
            over -= got; raised += got; equity_sold += got

    # C2. Gold or debt above target: the excess is raised too, and goes where
    # the target is short. Gold especially — it is insurance, and insurance
    # bought in excess is capital that earns nothing while it waits.
    OVER_WHY = {
        "gold": "Gold is the part of the mix that holds when equity and the rupee both fall; beyond its target it is capital earning no income.",
        "debt": "Debt beyond its target is money earning less than the years you have would let it.",
    }
    for bucket in ("gold", "debt"):
        g = by_bucket.get(bucket) or {}
        over_b = _d(g.get("rupees")) if g.get("direction") == "over" else Decimal(0)
        if over_b <= SMALLEST_MOVE:
            continue
        barriers.append({"code": f"{bucket}_over", "what": f"{bucket.title()} above target",
                         "size": str(over_b.quantize(Decimal("1"))),
                         "why": f"{_pct(g['current_pct'])} against a {_pct(g['target_pct'])} target. {OVER_WHY[bucket]}"})
        pool = sorted([h for h in holdings if bucket_of(h)[0] == bucket and left_in(h) > 0],
                      key=lambda h: (0 if _is_regular(h) else 1, -left_in(h)))
        movable = sum(left_in(h) for h in pool)
        if movable < SMALLEST_MOVE:
            locked = [h.get("instrument_name") for h in holdings if bucket_of(h)[0] == bucket and left_in(h) <= 0]
            barriers[-1]["why"] += (f" It sits in {', '.join(str(n) for n in locked[:3])}, which cannot be sold, so the plan "
                                    f"does not try: the weight comes right as new money goes elsewhere.")
            barriers[-1]["watch"] = True
            continue
        for h in pool:
            if over_b <= SMALLEST_MOVE:
                break
            v = min(left_in(h), over_b)
            got = move("sell", f"Reduce {h.get('instrument_name')} by {_money(v)}", v,
                       f"{bucket.title()} is above the target for your profile; the excess goes where the mix is short.",
                       basis=f"allocation: {bucket} brought back to the weight the mix needs", h=h, side="sell", bucket=bucket)
            over_b -= got; raised += got

    # ---------------- SWITCHES: equity-internal, buckets unchanged ----------------
    # D. Cap tilt: small-cap beyond target moves to large/flexi.
    eq_after = now["equity"] - equity_sold
    small_now = sum(left_in(h) for h in holdings if bucket_of(h)[0] == "equity" and _cap_of(h) == "small")
    small_target = _d(wt["small_pct"]) / 100 * max(eq_after, Decimal(0))
    small_over = small_now - small_target
    into_core = _fund_candidates(["Large Cap", "Flexi Cap"], limit=3)
    if small_over > SMALLEST_MOVE and eq_after > 0 and (small_now / eq_after * 100 - _d(wt["small_pct"])) > TOLERANCE_PTS * 2:
        barriers.append({"code": "cap_tilt", "what": "Small-cap weight",
                         "size": str(small_over.quantize(Decimal("1"))),
                         "why": f"{_pct(we['small_pct'])} of equity is small-cap against a {_pct(wt['small_pct'])} target for your profile. Deeper falls, longer recoveries."})
        for h in sorted([h for h in holdings if bucket_of(h)[0] == "equity" and _cap_of(h) == "small"], key=lambda h: -left_in(h)):
            if small_over <= SMALLEST_MOVE:
                break
            v = min(left_in(h), small_over)
            got = move("switch", f"Move {_money(v)} from {h.get('instrument_name')} into a large/flexi-cap fund", v,
                       "Small-cap is above what your profile can carry through a fall; the core belongs in large and flexi cap.",
                       basis="allocation: equity in the segment the profile can hold", h=h, into=into_core, side="switch", bucket="equity")
            small_over -= got
    elif eq_after > 0 and (_d(wt["large_pct"]) - _d(we["large_pct"])) > TOLERANCE_PTS * 2:
        barriers.append({"code": "no_core", "what": "Large-cap core",
                         "size": str(((_d(wt["large_pct"]) - _d(we["large_pct"])) / 100 * eq_after).quantize(Decimal("1"))),
                         "why": f"Only {_pct(we['large_pct'])} of equity is large-cap against {_pct(wt['large_pct'])}. New equity money goes there first."})

    # E. Regular → direct, on whatever is staying in each fund.
    for h in holdings:
        if (h.get("asset_class") or "") != "mutual_fund" or not _is_regular(h):
            continue
        v = left_in(h)
        if v < SMALLEST_MOVE:
            continue
        move("switch", f"Switch {h.get('instrument_name')} to its direct plan", v,
             "Same fund, same manager, lower expense. The difference is yours every year.",
             basis="cost: expense ratio gap, compounding", h=h, side="switch",
             alpha_per_year=v * REGULAR_DIRECT_GAP, alpha_kind="cost", bucket=bucket_of(h)[0])
    regular_total = sum(_d(m["amount"]) for m in moves if m.get("alpha_kind") == "cost")
    if regular_total > 0:
        paid_so_far = ""
        try:
            from . import commission
            meter = commission.for_investor(investor_id)
            if _d(meter.get("paid_to_date")) > 0:
                paid_so_far = f" It has already taken about {_money(meter['paid_to_date'])} since we first saw these holdings."
        except Exception as err:
            log.info("commission meter unavailable: %s", err)
        barriers.insert(0, {"code": "cost_drag", "what": "Regular-plan funds",
                            "size": str(regular_total.quantize(Decimal("1"))),
                            "why": f"About {_money(alpha['cost'])} a year goes to distribution commission for no extra return.{paid_so_far}"})

    # ---------------- BUYS: fill the under-target buckets from what was raised ----------------
    idle = max(Decimal(0), now["cash"] - _d(target["cash_pct"]) / 100 * total)
    pot = raised + idle
    if idle > SMALLEST_MOVE:
        barriers.append({"code": "idle_money", "what": "Money doing nothing",
                         "size": str(idle.quantize(Decimal("1"))),
                         "why": f"{_money(idle)} sits beyond the six-month cushion, earning cash rates."})
    fills = {
        "cash": (_fund_candidates(["Liquid"], limit=2), "a liquid fund",
                 "Nothing to meet a bad month without selling at the wrong time."),
        "debt": (_fund_candidates(["Corporate Bond", "Short Duration"], limit=3), "short-duration / corporate bond funds",
                 "Nothing steady to rebalance from when equity falls, and nothing for money needed soon."),
        "gold": (_fund_candidates(["Gold", "Fund of Fund", "Other Scheme"], limit=2, name_must_have=("gold",)), "a gold fund or ETF",
                 "Nothing that tends to hold when equity and the rupee both fall."),
    }
    from_new_money = Decimal(0)
    for bucket in ("cash", "debt", "gold"):
        g = by_bucket[bucket]
        if g["direction"] != "under":
            continue
        need = abs(_d(g["rupees"]))
        into, label, why_matters = fills[bucket]
        barriers.append({"code": f"missing_{bucket}", "what": f"{bucket.title()} below target",
                         "size": str(need.quantize(Decimal("1"))),
                         "why": f"{_pct(g['current_pct'])} against a {_pct(g['target_pct'])} target. {why_matters}"})
        funded = min(need, pot)
        src = "from the sells above" if funded >= need else (f"{_money(funded)} from the sells above, the rest from new money" if funded > 0 else "from new money")
        if funded < need:
            from_new_money += need - funded
        move("buy", f"Put {_money(need)} into {label}", need,
             f"Brings {bucket} to its {_pct(g['target_pct'])} target, {src}.",
             basis="allocation: money in the bucket that does its job", into=into, side="buy",
             asset_class="mutual_fund", bucket=bucket)
        pot -= funded

    # Equity: what is left to reach target after the sells, bought in the core.
    # A positive tilt from the regime panel raises the buy target inside the
    # band; a negative one lowers it. Sells above never used the tilt.
    eq_need = (target_eq + equity_tilt / 100 * total) - (now["equity"] - equity_sold)
    if eq_need > SMALLEST_MOVE:
        if by_bucket["equity"]["direction"] == "under":
            barriers.append({"code": "equity_under", "what": "Equity below target",
                             "size": str(eq_need.quantize(Decimal("1"))),
                             "why": f"{_pct(now['equity_pct'])} in equity against {_pct(target['equity_pct'])}. Safer assets protect the amount; over the years left they may not protect what it buys."})
        # The core first. Where large-cap is short of its target, the equity
        # money goes to large/flexi funds until it is not; the engine's share
        # picks take only what is left, and only if something was sold to
        # make room for them. Buying small-cap picks while the same plan says
        # small-cap is over target would be two plans.
        large_now = sum(left_in(h) for h in holdings if bucket_of(h)[0] == "equity" and _cap_of(h) == "large") \
            + sum(_d(h.get("current_value")) for h in holdings if bucket_of(h)[0] == "equity"
                  and (h.get("asset_class") or "") == "equity" and findings_service._cap_band_for(h) == "large_cap" and left_in(h) > 0)
        core_short = max(Decimal(0), _d(wt["large_pct"]) / 100 * (target_eq + equity_tilt / 100 * total) - large_now)
        core_part = min(eq_need, core_short) if core_short > SMALLEST_MOVE else Decimal(0)
        picks_part = eq_need - core_part if (picks and exit_value > 0) else Decimal(0)
        if picks_part and picks_part < SMALLEST_MOVE:
            core_part, picks_part = eq_need, Decimal(0)
        if not picks_part:
            core_part = eq_need
        funded_total = min(eq_need, pot)
        if funded_total < eq_need:
            from_new_money += eq_need - funded_total
        src_all = ("from the sells above" if funded_total >= eq_need else
                   f"{_money(funded_total)} from the sells above, the rest from new money" if funded_total > 0 else "from new money")
        if core_part > SMALLEST_MOVE:
            move("buy", f"Put {_money(core_part)} into large and flexi-cap funds — the core", core_part,
                 f"Only {_pct(we['large_pct'])} of your equity is large-cap against {_pct(wt['large_pct'])}; the core is filled first, {src_all}.",
                 basis="allocation: equity brought to target in the core", into=into_core, side="buy",
                 asset_class="mutual_fund", bucket="equity")
        if picks_part > SMALLEST_MOVE:
            move("buy", f"Put {_money(picks_part)} into the engine's current picks", picks_part,
                 (f"Replaces what left in the sells with holdings the engine would hold: "
                  f"{', '.join(str(_pick(b, 'name', 'symbol', 'stock_name', default='')) for b in picks[:4])}."),
                 basis="quality: capital into holdings the verdict engine rates buy", into=picks[:5], side="buy",
                 asset_class="equity", bucket="equity")
        pot -= funded_total

    # Anything still unspent: deploy by the market's record.
    ctx = {}
    try:
        ctx = market.context() or {}
    except Exception:
        pass
    pace = permits.get("deployment") or {}
    if pot > SMALLEST_MOVE:
        if pace.get("value") == "at once":
            how = f"now, as a lump sum into the buckets above — {pace.get('why', '')}"
        else:
            how = f"in twelve monthly instalments from a liquid fund — {pace.get('why', 'the default pace: it costs little against lump sum on the record and it is the one people finish')}"
        move("deploy", f"Put the remaining {_money(pot)} to work {how.split(' — ')[0]}", pot, how,
             basis="deployment: pace set by the long record at readings like today's, not a view", side="buy")

    # ---------------- TAX ----------------
    try:
        chance = harvest.opportunity(investor_id)
    except Exception as err:
        chance = None
        log.info("harvest unavailable: %s", err)
    if chance and _d(chance.get("available_gain")) > 0:
        gain = min(_d(chance["available_gain"]), LTCG_EXEMPTION)
        saving = _d(chance.get("saving")) or (gain * LTCG_RATE)
        barriers.append({"code": "tax_room", "what": "Unused ₹1.25 lakh exemption",
                         "size": str(gain.quantize(Decimal("1"))),
                         "why": f"{_money(gain)} of long-term gain can be booked tax-free this year and bought back. Worth {_money(saving)} in tax."})
        move("harvest", f"Book {_money(gain)} of long-term gains before 31 March and buy back", gain,
             "Uses this year's exemption; next year's gain starts from a higher cost. Sells above may already do this.",
             basis="tax: exemption used that would otherwise lapse", side="sell",
             alpha_per_year=saving, alpha_kind="tax")

    moves = _merge_per_holding(moves)
    rank = {"sell": 1, "restructure": 1, "switch": 2, "buy": 3, "deploy": 4, "harvest": 5}
    bucket_rank = {"cash": 0, "debt": 1, "gold": 2, "equity": 3}
    moves.sort(key=lambda m: (rank.get(m["kind"], 9),
                              bucket_rank.get(m.get("bucket"), 5) if m["kind"] == "buy" else 0,
                              0 if "core" in str(m.get("what", "")) else 1,
                              -_d(m["amount"])))
    for i, m in enumerate(moves, 1):
        m["order"] = i

    identifiable = alpha["cost"] + alpha["tax"]
    after = _after(now, moves, target)
    reading = _reading(target, now, barriers, moves, identifiable, after, from_new_money)

    def plain(d: dict) -> dict:
        return {k: (str(v) if isinstance(v, Decimal) else v) for k, v in d.items()}

    return {
        "ready": True, "as_of": date.today().isoformat(),
        "target": plain({k: v for k, v in target.items() if k != "within_equity"}) | {"within_equity": plain(target["within_equity"])},
        "current": plain({k: v for k, v in now.items() if k != "within_equity"}) | {"within_equity": plain(now["within_equity"])},
        "gaps": gap_rows, "barriers": barriers, "moves": moves,
        "alpha": {
            "cost_per_year": str(alpha["cost"].quantize(Decimal("1"))),
            "tax_per_year": str(alpha["tax"].quantize(Decimal("1"))),
            "identifiable_per_year": str(identifiable.quantize(Decimal("1"))),
            "quality_capital": str(exit_value.quantize(Decimal("1"))),
            "allocation_moved": str(sum((_d(m["amount"]) for m in moves if "allocation" in m["alpha_basis"]), Decimal(0)).quantize(Decimal("1"))),
            "from_new_money": str(from_new_money.quantize(Decimal("1"))),
            "note": ("Cost and tax alpha are arithmetic on your own holdings. Quality and allocation alpha are not "
                     "promised in rupees: they are the capital moved from where the record is against you to where "
                     "it is for you. Deployment follows the market's record at readings like today's, not a view."),
        },
        "after": after, "market": ctx if ctx.get("readable") else None, "reading": reading,
        "regime": regime_panel if regime_panel.get("readable") else None,
        "outside_the_mix": {"value": str(sum((_d(h.get("current_value")) for h in outside), Decimal(0)).quantize(Decimal("1"))),
                            "holdings": [{"name": h.get("instrument_name"), "asset_class": h.get("asset_class"),
                                          "value": str(_d(h.get("current_value")).quantize(Decimal("1")))} for h in outside],
                            "note": "Insurance, property and unlisted holdings are not part of the mix the targets are set over; they are protection and commitments, not allocation."},
        "what_this_is": ("One plan: the mix you should hold, what is in the way, and the moves in order. "
                         "The adviser of record owns the advice; you agree to each order."),
    }


def _after(now: dict, moves: list[dict], target: dict) -> dict:
    """The mix after the moves: sells leave their bucket, buys enter theirs."""
    total = now["total"] or Decimal(1)
    # `float` is the money in motion -- what the sells raised, not yet placed.
    # `cash` is the liquid bucket as held. Buying a liquid fund moves money
    # from the float into the bucket; the two were one variable before, so a
    # liquid-fund buy netted to nothing and the page showed 0% liquid after a
    # move whose whole point was 5% liquid.
    b = {"equity": now["equity"], "debt": now["debt"], "gold": now["gold"], "cash": now["cash"]}
    float_ = Decimal(0)
    for m in moves:
        a = _d(m["amount"]); k = m.get("bucket")
        if m["kind"] == "sell" and k in b:
            b[k] -= a; float_ += a
        elif m["kind"] == "buy" and k in b:
            b[k] += a; float_ -= a
    if float_ < 0:
        # Buys beyond what the sells raised are new money: the portfolio grows by
        # that much, so the shares are of the larger total, not the old one.
        total = total - float_
        float_ = Decimal(0)
    b["cash"] += float_
    def s(x): return str((x / total * 100).quantize(Decimal("0.1")))
    return {"equity_pct": s(b["equity"]), "debt_pct": s(b["debt"]), "gold_pct": s(b["gold"]), "cash_pct": s(b["cash"]),
            "target_equity_pct": str(target["equity_pct"]), "target_debt_pct": str(target["debt_pct"])}


def _reading(target: dict, now: dict, barriers: list[dict], moves: list[dict],
             identifiable: Decimal, after: dict, from_new_money: Decimal = Decimal(0)) -> str:
    if not moves:
        return (f"Your mix is {_pct(now['equity_pct'])} equity against a {_pct(target['equity_pct'])} target, "
                f"and nothing in the holdings is working against you. The best move is to leave it alone "
                f"and keep adding.")
    first = moves[0]
    sells = [m for m in moves if m["kind"] == "sell"]
    buys = [m for m in moves if m["kind"] == "buy"]
    names = []
    for b in barriers:
        n = (b.get("what") or b["code"]).lower()
        if n not in names:
            names.append(n)
    parts = [f"You hold {_pct(now['equity_pct'])} equity; your age, horizon and capacity put the target at "
             f"{_pct(target['equity_pct'])}, with {_pct(target['debt_pct'])} in debt and {_pct(target['gold_pct'])} in gold."]
    if names:
        parts.append(f"{len(names)} thing{'s' if len(names) != 1 else ''} stand between this portfolio and what it could earn: "
                     + "; ".join(names[:5]) + ".")
    parts.append(f"Start with: {first['what'][0].lower() + first['what'][1:]}.")
    if sells:
        parts.append(f"Sell {_money(sum(_d(m['amount']) for m in sells))} across {len(sells)} holding{'s' if len(sells) != 1 else ''}")
        if buys:
            parts[-1] += f" and put {_money(sum(_d(m['amount']) for m in buys))} where the target is short"
        parts[-1] += "."
    elif buys:
        parts.append(f"Put {_money(sum(_d(m['amount']) for m in buys))} where the target is short.")
    if from_new_money > 0:
        parts.append(f"{_money(from_new_money)} of that has to come from new money; the rest is already in the portfolio.")
    if identifiable > 0:
        parts.append(f"{_money(identifiable)} a year of the gain is arithmetic — cost and tax you are paying and need not.")
    parts.append(f"Done, the mix is {after['equity_pct']}% equity, {after['debt_pct']}% debt, {after['gold_pct']}% gold.")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# The letter: the plan, said the way an adviser would say it
# ---------------------------------------------------------------------------

def letter(investor_id: str, plan_: Optional[dict] = None) -> dict:
    """The plan as a conversation: where you stand, what has stopped working,
    what I would do and in what order, what to expect, and what you tend to do
    when it falls. Every sentence is drawn from a computed figure; the voice is
    the adviser's, the numbers are the engine's."""
    from . import behaviour, market, profile as profile_service
    p = plan_ or plan(investor_id)
    if not p.get("ready"):
        return {"ready": False, "paragraphs": [p.get("why")]}

    who = profile_service.get_profile(investor_id) or {}
    name = (wealth.get_investor(investor_id) or {}).get("display_name") or "there"
    first = name.split()[0] if name else "there"
    if first.isupper() or first.islower():
        first = first.title()          # statements arrive in capitals; a letter does not shout
    t, c, a, al = p["target"], p["current"], p["after"], p["alpha"]
    barriers, moves = p["barriers"], p["moves"]
    paras: list[dict] = []

    # 1. Where you stand — plainly, with the one number that matters.
    opening = (f"{first}, here is where you stand. You hold {_money(c['total'])} across "
               f"{sum(1 for _ in [])}" if False else
               f"{first}, here is where you stand. You hold {_money(c['total'])}, of which "
               f"{_pct(c['equity_pct'])} is in equity")
    if _d(c["within_equity"]["small_pct"]) > 40:
        opening += f" — and {_pct(c['within_equity']['small_pct'])} of that equity is small-cap"
    goal_bit = f", with a goal {t['soonest_goal_years']} years out" if t.get('soonest_goal_years') else ""
    if t.get("age"):
        opening += (f". For someone aged {t['age']}{goal_bit}, the mix I would want you in is "
                    f"{_pct(t['equity_pct'])} equity, {_pct(t['debt_pct'])} debt, "
                    f"{_pct(t['gold_pct'])} gold, with {_pct(t['cash_pct'])} liquid. ")
    else:
        opening += (f". I do not have your date of birth, so I have started from a 55% equity mix{goal_bit} — "
                    f"{_pct(t['equity_pct'])} equity, {_pct(t['debt_pct'])} debt, {_pct(t['gold_pct'])} gold, "
                    f"with {_pct(t['cash_pct'])} liquid. Give me your date of birth on the profile page and the "
                    f"target, and everything below it, will be set to your age rather than to an average. ")
    gap = _d(c["equity_pct"]) - _d(t["equity_pct"])
    if gap > 10:
        opening += (f"You are carrying {gap:.0f} points more equity than that. That is not a crime — it is how most "
                    f"portfolios that grew through a good decade end up — but it means a bad year costs you about "
                    f"{_money(_d(c['total']) * gap / 100 * Decimal('0.35'))} more than it needs to, and you are at the age "
                    f"where recovering it takes time you would rather not spend.")
    elif gap < -10:
        opening += (f"You are {abs(gap):.0f} points lighter on equity than that. Safe is comfortable, but over the years "
                    f"you have, it is the one position that reliably loses to inflation.")
    else:
        opening += "Your overall split is close to right; the work is inside the buckets, not between them."
    paras.append({"head": "Where you stand", "text": opening})

    # 2. What has stopped working — the barriers, in the adviser's words.
    stopped = []
    for b in barriers:
        code = b["code"]
        if code == "weak_holding":
            stopped.append(f"{b['what']} ({_money(b['size'])}): the verdict engine reads it as reduce — {b['why'].split('. ', 1)[-1]}")
        elif code == "fund_fallen":
            stopped.append(f"{b['what']} ({_money(b['size'])}): {b['why']}")
        elif code == "legacy_winner":
            stopped.append(f"{b['what']}: {b['why']}")
        elif code == "concentration":
            stopped.append(f"{b['what']} is {b['why'][0].lower() + b['why'][1:]}")
        elif code == "cap_tilt":
            stopped.append(f"your equity is {b['why'][0].lower() + b['why'][1:]}")
        elif code == "cost_drag":
            stopped.append(f"{_money(b['size'])} sits in regular plans — {b['why'][0].lower() + b['why'][1:]}")
        elif code == "missing_debt":
            stopped.append("there is no debt at all, so when equity falls there is nothing to rebalance from and nothing earning while you wait")
        elif code == "idle_money":
            stopped.append(f"{_money(b['size'])} is sitting in cash beyond your cushion, earning cash rates")
        elif code == "tax_room":
            stopped.append(f"this year's ₹1.25 lakh tax-free allowance is unused — worth {b['why'].split('Worth ')[-1].rstrip('.')}")
    if stopped:
        text = ("What has stopped working, in order of how much it costs you: " +
                "; ".join(stopped[:6]) + ".")
        if any(b["code"] in ("fund_fallen", "legacy_winner", "weak_holding") for b in barriers):
            text += (" None of this is a judgement on the decisions you made at the time. A fund or a share bought for "
                     "the market of 2015 did its job in that market; the question I am asking of each one is whether it "
                     "is earning its place in this one, and the answer comes from its own record, not from a view.")
        paras.append({"head": "What has stopped working", "text": text})

    # 3. What I would do, in order.
    steps = []
    for m in moves:
        line = f"{m['order']}. {m['what']}"
        if m.get("into"):
            names = [str(_pick(x, "name", "symbol", default="")) for x in m["into"][:2] if _pick(x, "name", "symbol")]
            if names:
                line += f" — into {', '.join(names)}"
        if m.get("alpha_per_year"):
            line += f" (worth about {_money(m['alpha_per_year'])} a year)"
        steps.append(line)
    if steps:
        text = ("What I would do, in this order — sells first so the money exists, then the switches that cost "
                "nothing, then the buys: " + " ".join(steps) + ".")
        if _d(al.get("from_new_money")) > 0:
            text += f" {_money(al['from_new_money'])} of the buys has to come from new money; the rest is already yours."
        text += (f" When it is done you are at {a['equity_pct']}% equity, {a['debt_pct']}% debt, {a['gold_pct']}% gold — "
                 f"and {_money(al['identifiable_per_year'])} a year of cost and tax you were paying stops.")
        locked = [b for b in barriers if b.get("watch") and "cannot be sold" in str(b.get("why", ""))]
        if locked and abs(_d(a["equity_pct"]) - _d(t["equity_pct"])) > TOLERANCE_PTS:
            m_ = re.search(r"sits in (.+?), which", str(locked[0].get("why", "")))
            where = m_.group(1) if m_ else locked[0]["what"].lower()
            text += (f" That is short of the {_pct(t['equity_pct'])} equity target, and it will stay short for a while: "
                     f"the excess debt sits in {where}, which is locked, so the only way the weight comes right is new money "
                     f"going to equity rather than to it. The target is the direction; the moves above are what can be done today.")
        paras.append({"head": "What I would do", "text": text})

    # 4. The market, as a record — direction as a base rate, never a call.
    mk = p.get("market") or {}
    followed = (mk.get("followed") or {}) if mk else {}
    if followed.get("countable"):
        paras.append({"head": "The market you are doing this in", "text": (
            f"The index is {abs(_d(followed.get('today_off_peak_pct'))):.1f}% below its high. Across the {followed.get('windows')} "
            f"times it has been at a reading like this in the history we hold, the following twelve months were "
            f"positive {followed.get('positive_pct')}% of the time — median {followed.get('median_pct')}%, the unlucky "
            f"tenth {followed.get('unlucky_tenth_pct')}%. That is what the record says; it is not a forecast, and it "
            f"is why the equity buys above are placed "
            + ("in instalments rather than at once." if any(m['kind'] == 'deploy' and 'instal' in m['what'] for m in moves)
               else "now rather than waited on.")
        )})
    # The longer record, where we have it: what each reading has been followed by,
    # and the small permits that follow. A reading with no edge is said to have none.
    rg = p.get("regime") or {}
    if rg.get("readable"):
        bits = []
        for r in rg.get("readings") or []:
            lt = (r.get("replay") or {}).get("like_today")
            if lt:
                bits.append(f"{r['name'].rstrip('.')}: {r['value']}. {r['say']}")
        tilts = [x for x in rg.get("permits") or [] if x["permit"] in ("equity_tilt_pts", "gold_tilt_pts") and x.get("value")]
        src = rg.get("sources") or {}
        span = (src.get("index") or {}).get("from", "")[:4]
        text = (f"Over the longer record — a Nifty index fund since {span}, with gilt and gold funds beside it — "
                + " ".join(bits[:4]))
        edges = [r for r in rg.get("readings") or [] if (r.get("replay") or {}).get("edge_pct") is not None
                 and abs(_d(r["replay"]["edge_pct"])) >= 2]
        if tilts:
            text += " From that: " + " ".join(t["why"] for t in tilts)
        elif edges:
            text += (f" Edges of three or four points are real but small, and the one reading that would tilt the "
                     f"plan — equity against debt — has too few months like this one to count. So the targets stand "
                     f"as set, and what the record changes is only the pace: new money goes in over twelve months.")
        else:
            text += " None of those readings carries an edge, so the targets stand as set."
        paras.append({"head": "What the longer record says", "text": text})

    # 5. What you tend to do — behaviour, from their own record.
    try:
        nerve = behaviour.kept_going(investor_id) or {}
    except Exception:
        nerve = {}
    if nerve.get("reading"):
        paras.append({"head": "What you tend to do when it falls", "text": (
            nerve["reading"] + " I say this because the plan above only works if it survives the next fall, and "
            "the record of what you did in the last one is the best evidence of whether it will. If it says you "
            "stopped, the debt bucket is not a drag — it is what lets you keep buying when it matters.")})

    # 6. Close.
    paras.append({"head": "What to expect", "text": (
        "None of this promises a number. What it does is take the money out of the places where the record is "
        "against you — a fund in the bottom half of its category, a share the engine would exit, a plan paying "
        "commission for nothing, equity your horizon cannot carry — and put it where the record is for you. The "
        "cost and tax savings are arithmetic; the rest is odds, and the odds are now on your side. We review it "
        "every quarter, and the page will tell you what moved and why.")})

    return {"ready": True, "to": name, "paragraphs": paras, "plan": p}
