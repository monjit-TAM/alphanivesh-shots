"""What moved since last time, and why.

The plan absorbs what happens rather than being redrawn. Nothing about where a
goal stands is stored on the goal -- it is recomputed on every look -- but
each computation is kept in `goal_reading`, so that "you were comfortable in
March and you are tight now" can name the cause rather than just showing a
different number.

Three causes, told apart:

  the market moved     -- the earmarked holdings are worth more or less, with
                          no change to which holdings or how much of them
  the plan changed     -- earmarks were added or released, or the target, date
                          or currency was edited
  the contributions    -- the monthly was raised, cut, or stopped

and for a foreign goal a fourth, the rupee moved, which is the market moving
against the bill rather than the savings.

The near ones get louder. A goal eighteen years out barely reacts to a bad
quarter and should not; a goal eleven months out reacts to everything. The
same shortfall is a problem to solve now in one case and noise in the other,
and the reading says which.

A reading is recorded at most once a day per goal, on any look at it, so a
person who visits weekly gets a weekly record without anything scheduled.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.change")

# One reading a day is enough to tell a story from; more just repeats it.
AT_MOST_EVERY_HOURS = 20

# Under this many months out, every move matters. Over the second figure,
# a quarter's move is noise against the horizon.
NEAR_MONTHS = 24
FAR_MONTHS = 120

# A move smaller than this share of the target is not worth a sentence.
QUIET_BELOW_PCT = Decimal("0.5")


def _d(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    n = int(abs(_d(value)))
    if n >= 10_000_000:
        return f"₹{n / 10_000_000:.2f} crore"
    if n >= 100_000:
        return f"₹{n / 100_000:.1f} lakh"
    return f"₹{n:,}"


def _pct(value: Any) -> Optional[Decimal]:
    try:
        return Decimal(str(value)) if value is not None else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------

def record(goal_id: str, goal: dict, replayed: Optional[dict] = None,
           force: bool = False) -> Optional[str]:
    """Keep today's computation. Returns the reading id, or None if skipped.

    `goal` is goals.one(goal_id); `replayed` is replay.for_goal(goal_id) if the
    caller already has it (it is slow, so it is not fetched here just to be
    stored). Both are what was shown to the person, which is the point: the
    record is of what they saw.
    """
    if not force:
        recent = db.fetch_one(
            "SELECT id FROM goal_reading WHERE goal_id = %s "
            "AND read_at > now() - (%s * interval '1 hour') "
            "ORDER BY read_at DESC LIMIT 1",
            (goal_id, AT_MOST_EVERY_HOURS))
        if recent:
            return None

    fx = None
    cv = goal.get("currency_view") or {}
    if isinstance(cv.get("rate"), dict):
        fx = _d(cv["rate"].get("rate"))
    elif goal.get("fx_rate"):
        fx = _d(goal["fx_rate"])

    r = replayed or {}
    drawable = bool(r.get("drawable"))
    row = db.fetch_one(
        """
        INSERT INTO goal_reading
            (goal_id, earmarked_value, target_in_inr, fx_rate,
             reached_pct, windows, window_years, worst_shortfall,
             median_finish, refused_why)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """,
        (goal_id,
         _d(goal.get("worth")),
         _d(goal.get("target_in_inr")),
         fx,
         _pct(r.get("reached_pct")) if drawable else None,
         r.get("windows") if drawable else None,
         r.get("horizon_years") if drawable else None,
         _pct(r.get("worst_shortfall")) if drawable else None,
         _pct(r.get("median")) if drawable else None,
         None if drawable else (r.get("why") if r else None)))
    return row["id"] if row else None


# ---------------------------------------------------------------------------
# Reading the change
# ---------------------------------------------------------------------------

def _last_before_today(goal_id: str) -> Optional[dict]:
    """The most recent reading that is not from today, so today's look is
    compared against a genuinely earlier one."""
    return db.fetch_one(
        """
        SELECT * FROM goal_reading
        WHERE goal_id = %s AND read_at::date < current_date
        ORDER BY read_at DESC LIMIT 1
        """,
        (goal_id,))


def _plan_changes_since(goal_id: str, since: datetime) -> dict:
    """What the person changed since the last reading: earmarks in or out,
    the goal itself edited, the monthly changed."""
    added = db.fetch_all(
        "SELECT i.name FROM goal_earmark e JOIN instruments i ON i.id = e.instrument_id "
        "WHERE e.goal_id = %s AND e.assigned_at > %s AND e.removed_at IS NULL",
        (goal_id, since))
    removed = db.fetch_all(
        "SELECT i.name FROM goal_earmark e JOIN instruments i ON i.id = e.instrument_id "
        "WHERE e.goal_id = %s AND e.removed_at > %s",
        (goal_id, since))
    edited = db.fetch_one(
        "SELECT 1 AS ok FROM goal WHERE id = %s AND updated_at > %s "
        "AND updated_at > created_at + interval '1 minute'",
        (goal_id, since))
    contributions = db.fetch_all(
        "SELECT monthly, began_on, ended_on FROM goal_contribution "
        "WHERE goal_id = %s AND (began_on > %s::date OR ended_on > %s::date) "
        "ORDER BY began_on",
        (goal_id, since, since))
    then_monthly = db.fetch_one(
        "SELECT monthly FROM goal_contribution WHERE goal_id = %s "
        "AND began_on <= %s::date AND (ended_on IS NULL OR ended_on > %s::date) "
        "ORDER BY began_on DESC LIMIT 1",
        (goal_id, since, since))
    return {
        "earmarks_added": [r["name"] for r in added],
        "earmarks_removed": [r["name"] for r in removed],
        "goal_edited": bool(edited),
        "monthly_changed": bool(contributions),
        "monthly_then": _d(then_monthly["monthly"]) if then_monthly else Decimal(0),
    }


def since_last(goal_id: str, goal: dict, replayed: Optional[dict] = None) -> dict:
    """Today against the last recorded look, with the cause named.

    Also records today's reading (at most once a day), so the next visit has
    something to compare against. `goal` and `replayed` are what the page is
    already showing; nothing is recomputed here.
    """
    try:
        record(goal_id, goal, replayed)
    except Exception as err:                     # never let bookkeeping break the page
        log.warning("could not record reading for %s: %s", goal_id, err)

    last = _last_before_today(goal_id)
    months_left = int(goal.get("months_left") or 0)
    urgency = ("now" if months_left < NEAR_MONTHS
               else "later" if months_left > FAR_MONTHS else "soon")

    if not last:
        return {
            "comparable": False,
            "urgency": urgency,
            "reading": ("This is the first time we have looked at this goal, so "
                        "there is nothing yet to compare it with. From the next "
                        "visit on, this will say what moved and why."),
        }

    then_at: datetime = last["read_at"]
    days = (datetime.now(timezone.utc) - then_at.astimezone(timezone.utc)).days
    when = (f"{days} days ago" if days < 60 else
            f"{days // 30} months ago" if days < 365 else
            then_at.strftime("%B %Y"))

    worth_now, worth_then = _d(goal.get("worth")), _d(last["earmarked_value"])
    target_now, target_then = _d(goal.get("target_in_inr")), _d(last["target_in_inr"])
    target = target_now or Decimal(1)

    r = replayed or {}
    reached_now = _pct(r.get("reached_pct")) if r.get("drawable") else None
    reached_then = _pct(last["reached_pct"])

    plan = _plan_changes_since(goal_id, then_at)
    monthly_now = _d(goal.get("monthly"))
    monthly_then = plan["monthly_then"]

    d_worth = worth_now - worth_then
    d_target = target_now - target_then
    d_monthly = monthly_now - monthly_then

    # Which cause, in words. Several can be true; each gets its sentence.
    causes: list[dict] = []

    if plan["earmarks_added"] or plan["earmarks_removed"]:
        bits = []
        if plan["earmarks_added"]:
            bits.append(f"{', '.join(plan['earmarks_added'][:3])} "
                        f"{'was' if len(plan['earmarks_added']) == 1 else 'were'} assigned to it")
        if plan["earmarks_removed"]:
            bits.append(f"{', '.join(plan['earmarks_removed'][:3])} "
                        f"{'was' if len(plan['earmarks_removed']) == 1 else 'were'} taken off it")
        causes.append({"cause": "plan",
                       "reading": f"The plan changed: {' and '.join(bits)}."})
    elif abs(d_worth) / target * 100 >= QUIET_BELOW_PCT:
        causes.append({"cause": "market",
                       "reading": (f"The market moved: what is earmarked is "
                                   f"{_money(d_worth)} {'more' if d_worth > 0 else 'less'} "
                                   f"than {when}, with the same holdings behind it.")})

    if plan["goal_edited"]:
        causes.append({"cause": "plan",
                       "reading": "The goal itself was edited since then — its target, date or wording."})

    if abs(d_target) / target * 100 >= QUIET_BELOW_PCT and not plan["goal_edited"]:
        fx_now = _d((goal.get("currency_view") or {}).get("rate", {}).get("rate")
                    if isinstance((goal.get("currency_view") or {}).get("rate"), dict) else 0)
        fx_then = _d(last["fx_rate"])
        if fx_then and fx_now and fx_now != fx_then:
            causes.append({"cause": "rupee",
                           "reading": (f"The rupee moved: the same {goal.get('currency')} bill is "
                                       f"{_money(d_target)} {'more' if d_target > 0 else 'less'} in "
                                       f"rupees than {when} ({fx_then.quantize(Decimal('0.01'))} → "
                                       f"{fx_now.quantize(Decimal('0.01'))}).")})

    if plan["monthly_changed"] and d_monthly != 0:
        verb = ("stopped" if monthly_now == 0 else
                "started" if monthly_then == 0 else
                "was raised" if d_monthly > 0 else "was cut")
        causes.append({"cause": "contributions",
                       "reading": (f"The monthly {verb}"
                                   + (f", from {_money(monthly_then)} to {_money(monthly_now)}"
                                      if monthly_then and monthly_now else
                                      f" ({_money(monthly_then or monthly_now)} a month)")
                                   + ".")})

    # The verdict, in odds where we have them.
    odds = None
    if reached_now is not None and reached_then is not None:
        d = reached_now - reached_then
        if abs(d) >= Decimal("0.5"):
            odds = (f"It reached its target in {reached_now.quantize(Decimal('0.1'))}% of "
                    f"stretches, against {reached_then.quantize(Decimal('0.1'))}% {when} — "
                    f"{'better' if d > 0 else 'worse'} by {abs(d).quantize(Decimal('0.1'))} points.")
        else:
            odds = (f"Its odds are where they were {when}: about "
                    f"{reached_now.quantize(Decimal('0.1'))}% of stretches.")

    if not causes and odds is None:
        reading = f"Nothing worth reporting has moved since {when}."
    else:
        reading = " ".join([c["reading"] for c in causes] + ([odds] if odds else []))

    # Louder near, quieter far.
    if urgency == "now" and (d_worth < 0 or (reached_now is not None and reached_then is not None
                                             and reached_now < reached_then)):
        reading += (f" With {months_left} months left this is a problem to solve now, "
                    f"not a number to watch.")
    elif urgency == "later" and causes and all(c["cause"] in ("market", "rupee") for c in causes):
        reading += (f" At {months_left // 12} years out, a move like this is noise against "
                    f"the horizon; it would take several of them to mean anything.")

    return {
        "comparable": True,
        "since": then_at.isoformat(),
        "since_days": days,
        "urgency": urgency,
        "causes": [c["cause"] for c in causes],
        "worth_then": str(worth_then.quantize(Decimal("1"))),
        "worth_now": str(worth_now.quantize(Decimal("1"))),
        "target_then": str(target_then.quantize(Decimal("1"))),
        "target_now": str(target_now.quantize(Decimal("1"))),
        "monthly_then": str(monthly_then.quantize(Decimal("1"))),
        "monthly_now": str(monthly_now.quantize(Decimal("1"))),
        "reached_then": str(reached_then) if reached_then is not None else None,
        "reached_now": str(reached_now) if reached_now is not None else None,
        "reading": reading,
    }


def history(goal_id: str, limit: int = 60) -> list[dict]:
    """The recorded looks, newest first, for a small chart of where it stood."""
    rows = db.fetch_all(
        """
        SELECT read_at, earmarked_value, target_in_inr, fx_rate, reached_pct,
               windows, refused_why
        FROM goal_reading WHERE goal_id = %s
        ORDER BY read_at DESC LIMIT %s
        """,
        (goal_id, limit))
    return [{"read_at": r["read_at"].isoformat(),
             "worth": str(_d(r["earmarked_value"]).quantize(Decimal("1"))),
             "target_in_inr": str(_d(r["target_in_inr"]).quantize(Decimal("1"))),
             "fx_rate": str(r["fx_rate"]) if r["fx_rate"] is not None else None,
             "reached_pct": str(r["reached_pct"]) if r["reached_pct"] is not None else None,
             "windows": r["windows"], "refused_why": r["refused_why"]}
            for r in rows]
