"""The commission meter: what a regular plan has cost, to date, in rupees.

1 Finance's study put it in aggregate -- more than 80% of ten-year equity
schemes left regular-plan investors a quarter poorer -- but no app shows it
per holding, running. This does. For each regular-plan fund with a direct
twin, the same rupees are replayed through the direct NAV from the date we
first saw the holding, and the gap is what commission has taken so far.
Measured from the two NAV series, not estimated from a trail rate; the trail
rate is the fallback only when a series is missing, and it says so.

"First saw" is a floor, as everywhere else here: the holding may be older,
and the meter can only under-count.
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

_SERIES: dict[str, tuple[float, dict[date, Decimal]]] = {}
_SERIES_SECONDS = 600


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def _series(code: str) -> dict[date, Decimal]:
    """Daily NAV by date for a scheme code, memoised for ten minutes."""
    import time
    from . import dataservice
    hit = _SERIES.get(code)
    if hit and time.monotonic() - hit[0] < _SERIES_SECONDS:
        return hit[1]
    out: dict[date, Decimal] = {}
    try:
        rows = (dataservice.nav_history(code, days=0) or {}).get("data") or []
    except Exception as err:
        log.info("no NAV history for %s: %s", code, err)
        rows = []
    for r in rows:
        try:
            when = datetime.strptime(r["date"], "%d-%m-%Y").date()
        except (KeyError, ValueError):
            continue
        nav = _d(r.get("nav"))
        if nav > 0:
            out[when] = nav
    _SERIES[code] = (time.monotonic(), out)
    return out


def _nav_on(series: dict[date, Decimal], when: date) -> Optional[Decimal]:
    if not series:
        return None
    if when in series:
        return series[when]
    earlier = [d for d in series if d <= when]
    if not earlier:
        later = sorted(series)
        return series[later[0]] if later and (later[0] - when).days <= 10 else None
    return series[max(earlier)]


def for_investor(investor_id: str) -> dict:
    from . import plans
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value, v.invested_value,
               i.native_code, i.category,
               LEAST(
                 (SELECT min(h.as_of) FROM holding_snapshots h
                  WHERE h.instrument_id = v.instrument_id AND h.investor_id = v.investor_id AND h.as_of > '1990-01-01'),
                 (SELECT min(t.txn_date) FROM canonical_transactions t
                  WHERE t.instrument_id = v.instrument_id AND t.investor_id = v.investor_id
                    AND t.txn_type IN ('purchase', 'sip', 'switch_in'))
               ) AS bought
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund' AND v.current_value > 0
        ORDER BY v.current_value DESC
        """, (investor_id,))

    today = date.today()
    meters, total_paid, total_rate = [], Decimal(0), Decimal(0)
    for r in rows:
        if plans._plan_of(r["instrument_name"]) != "regular":
            continue
        twin = plans.find_direct_twin(r["instrument_name"], r["category"])
        value, invested = _d(r["current_value"]), _d(r["invested_value"])
        bought = r["bought"]
        years = max(Decimal("0.1"), Decimal((today - bought).days) / Decimal(365)) if bought else None
        trail = plans._trail_for(r["category"])

        paid = method = None
        if twin and bought and r["native_code"]:
            reg, direct = _series(r["native_code"]), _series(twin["native_code"])
            r0, r1 = _nav_on(reg, bought), _nav_on(reg, today)
            d0, d1 = _nav_on(direct, bought), _nav_on(direct, today)
            if r0 and r1 and d0 and d1 and invested > 0:
                in_direct = invested * d1 / d0
                in_regular = invested * r1 / r0
                paid = in_direct - in_regular
                method = "measured"
        if paid is None:
            if years is None:
                continue
            paid = value * trail / 100 * years
            method = "estimated"
        per_year = (paid / years) if years else value * trail / 100

        meters.append({
            "instrument_id": r["instrument_id"], "name": r["instrument_name"],
            "direct_name": twin["name"] if twin else None, "direct_code": twin["native_code"] if twin else None,
            "value": str(value.quantize(Decimal("1"))),
            "since": bought.isoformat() if bought else None,
            "years": str(years.quantize(Decimal("0.1"))) if years else None,
            "paid_to_date": str(paid.quantize(Decimal("1"))),
            "per_year": str(per_year.quantize(Decimal("1"))),
            "method": method,
            "say": (f"{_money(paid)} so far"
                    + (f" over {years:.1f} years" if years else "")
                    + (f" — the same rupees in the direct plan would be worth that much more today." if method == "measured"
                       else f" — estimated from a {trail}% trail, since one NAV series is missing.")),
        })
        total_paid += paid; total_rate += per_year

    small = [m for m in meters if _d(m["per_year"]) < 100]
    meters = [m for m in meters if _d(m["per_year"]) >= 100]
    return {
        "meters": meters, "count": len(meters), "small_count": len(small),
        "paid_to_date": str(total_paid.quantize(Decimal("1"))),
        "per_year": str(total_rate.quantize(Decimal("1"))),
        "reading": (f"{len(meters)} regular-plan fund{'s' if len(meters) != 1 else ''} have paid about {_money(total_paid)} "
                    f"in commission since we first saw them, and are paying about {_money(total_rate)} a year now. "
                    f"The direct plan is the same fund without it."
                    + (f" {len(small)} more are too small to matter (under ₹100 a year between them all)." if small else "")
                    if meters else
                    (f"{len(small)} regular-plan fund{'s' if len(small) != 1 else ''}, all too small to matter — under ₹100 a year of commission between them."
                     if small else "No regular-plan funds. Nothing is going to commission.")),
        "principle": ("Measured by replaying your rupees through the direct plan's NAV from the day we first saw the holding. "
                      "That date is a floor — the holding may be older — so the meter can only under-count."),
    }
