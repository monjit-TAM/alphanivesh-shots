"""Goals competing for the same money. Show everything, rank nothing.

Whether retirement matters more than a house is not a question a calculation
can answer, and a product that answers it has substituted its judgement for
the person's on the one question that is entirely theirs. So this module does
three things and refuses a fourth:

  1. Committed against spare -- if the monthlies across all goals exceed what
     the person has left after expenses and EMIs, say so, with the number.
     Nothing is scaled down silently.
  2. Earmarks against holdings -- which holdings are claimed by more than one
     goal, and which are fully claimed. (The database already refuses a claim
     past 100%; this makes the contest visible before that point.)
  3. The cost of each choice, stated -- "giving Retirement the whole of that
     fund takes it from 71% to 78% of stretches, and takes House from 64% to
     41%." A sentence, from the replay engine, for each contest. Not a
     recommendation: what the choice costs, in the other goal's odds.

It does not pick. Every figure is recomputed on every call; nothing here is
stored.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db
from . import earmarks, goals as goals_service, replay

log = logging.getLogger("alphanivesh.competition")

# Replays are the expensive part. Contests beyond this many are listed but not
# replayed, and the response says so rather than timing out.
MOST_TRADES_REPLAYED = 6


def _d(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    n = int(_d(value))
    if n >= 10_000_000:
        return f"₹{n / 10_000_000:.2f} crore"
    if n >= 100_000:
        return f"₹{n / 100_000:.1f} lakh"
    return f"₹{n:,}"


def _pct(text: Any) -> Optional[Decimal]:
    try:
        return Decimal(str(text))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 1. Committed against spare
# ---------------------------------------------------------------------------

def committed_against_spare(investor_id: str, all_goals: dict) -> dict:
    """Monthly commitments across goals, against what is actually spare.

    Spare = income - expenses - EMIs, from what the person has told us. Where
    income or expenses are missing, this says what it would need rather than
    guessing; a savings-capacity figure invented from nothing would be worse
    than none.
    """
    from . import profile as profile_service
    committed = _d(all_goals.get("committed_monthly"))

    who = profile_service.get_profile(investor_id) or {}
    income = _d(who.get("monthly_income"))
    expenses = _d(who.get("monthly_expenses"))

    emi = Decimal(0)
    try:
        from . import debts
        owed = debts.for_investor(investor_id) or {}
        emi = _d(owed.get("monthly_emi"))
    except Exception as err:            # debts module or table missing
        log.info("no debts for %s: %s", investor_id, err)

    out: dict = {
        "committed_monthly": str(committed.quantize(Decimal("1"))),
        "goals_committing": sum(1 for g in all_goals.get("goals", [])
                                if _d(g.get("monthly")) > 0),
        "monthly_income": str(income.quantize(Decimal("1"))) if income > 0 else None,
        "monthly_expenses": str(expenses.quantize(Decimal("1"))) if expenses > 0 else None,
        "monthly_emi": str(emi.quantize(Decimal("1"))) if emi > 0 else None,
    }

    if income <= 0 or expenses <= 0:
        out.update({
            "computable": False,
            "spare": None,
            "needs": [k for k, v in (("monthly_income", income),
                                     ("monthly_expenses", expenses)) if v <= 0],
            "reading": (
                f"{_money(committed)} a month is committed across your goals. "
                f"Whether that fits is a comparison against what you have spare "
                f"each month, and we do not have your "
                f"{'income and expenses' if income <= 0 and expenses <= 0 else 'income' if income <= 0 else 'expenses'} "
                f"to make it."),
        })
        return out

    spare = income - expenses - emi
    gap = committed - spare
    out.update({
        "computable": True,
        "spare": str(spare.quantize(Decimal("1"))),
        "gap": str(max(Decimal(0), gap).quantize(Decimal("1"))),
        "fits": gap <= 0,
        "share_of_spare_pct": (str((committed / spare * 100).quantize(Decimal("1")))
                               if spare > 0 else None),
    })

    if spare <= 0:
        out["reading"] = (
            f"After expenses{' and EMIs' if emi > 0 else ''} nothing is spare "
            f"each month on the figures you have given, yet {_money(committed)} "
            f"a month is committed to goals. One of those figures is out of "
            f"date, or the commitments are being met from something other than "
            f"income — either way it is worth knowing which.")
    elif gap <= 0:
        out["reading"] = (
            f"{_money(committed)} a month is committed across your goals, "
            f"against {_money(spare)} spare after expenses"
            f"{' and EMIs' if emi > 0 else ''}. It fits, with "
            f"{_money(-gap)} a month unallocated.")
    else:
        out["reading"] = (
            f"{_money(committed)} a month is committed across your goals, but "
            f"only {_money(spare)} is spare after expenses"
            f"{' and EMIs' if emi > 0 else ''}. That is {_money(gap)} a month "
            f"more than there is. Nothing here has been scaled down to make it "
            f"fit; which goal gives is yours to decide, and below is what each "
            f"choice would cost.")
    return out


# ---------------------------------------------------------------------------
# 2. Earmarks against holdings
# ---------------------------------------------------------------------------

def contested_holdings(investor_id: str) -> dict:
    """Holdings claimed by more than one goal, and those fully claimed."""
    rows = db.fetch_all(
        """
        SELECT e.instrument_id, v.instrument_name AS name, v.asset_class,
               v.current_value,
               e.goal_id, g.name AS goal_name, e.share_pct
        FROM goal_earmark e
        JOIN goal g ON g.id = e.goal_id AND g.abandoned_at IS NULL
        JOIN v_current_holdings v
          ON v.instrument_id = e.instrument_id AND v.investor_id = e.investor_id
        WHERE e.investor_id = %s AND e.removed_at IS NULL AND v.current_value > 0
        ORDER BY v.current_value DESC, e.share_pct DESC
        """,
        (investor_id,))

    by_holding: dict[str, dict] = {}
    for r in rows:
        h = by_holding.setdefault(r["instrument_id"], {
            "instrument_id": r["instrument_id"], "name": r["name"],
            "asset_class": r["asset_class"],
            "worth": _d(r["current_value"]), "claims": []})
        h["claims"].append({"goal_id": r["goal_id"], "goal_name": r["goal_name"],
                            "share_pct": _d(r["share_pct"])})

    contested, fully = [], []
    for h in by_holding.values():
        claimed = sum((c["share_pct"] for c in h["claims"]), Decimal(0))
        item = {
            "instrument_id": h["instrument_id"], "name": h["name"],
            "asset_class": h["asset_class"],
            "worth": str(h["worth"].quantize(Decimal("1"))),
            "claimed_pct": str(claimed.quantize(Decimal("0.1"))),
            "free_pct": str(max(Decimal(0), 100 - claimed).quantize(Decimal("0.1"))),
            "claims": [{**c, "share_pct": str(c["share_pct"].quantize(Decimal("0.1"))),
                        "worth": str((h["worth"] * c["share_pct"] / 100)
                                     .quantize(Decimal("1")))}
                       for c in h["claims"]],
        }
        if len(h["claims"]) > 1:
            contested.append(item)
        if claimed >= Decimal("99.9"):
            fully.append(item["name"])

    return {
        "contested": contested,
        "contested_count": len(contested),
        "fully_claimed": fully,
        "reading": (
            "No holding is claimed by more than one goal."
            if not contested else
            f"{len(contested)} holding{'s are' if len(contested) != 1 else ' is'} "
            f"shared between goals. That is allowed — the shares add up and "
            f"the database refuses a claim past the whole — but it means those "
            f"goals rise and fall together, and giving one more means giving "
            f"the other less."),
    }


# ---------------------------------------------------------------------------
# 3. The cost of each choice
# ---------------------------------------------------------------------------

def _reached(result: dict) -> Optional[Decimal]:
    if not result.get("drawable"):
        return None
    return _pct(result.get("reached_pct"))


def _holdings_giving(goal_id: str, instrument_id: str,
                     take_share_pct: Decimal, worth_whole: Decimal) -> list[dict]:
    """This goal's earmarked holdings, with one holding's share changed.

    `take_share_pct` is the share of `instrument_id` the goal would hold
    afterwards (0 to give it up entirely, 100 to take all of it).
    """
    held = earmarks.holdings_for(goal_id)["holdings"]
    out, seen = [], False
    for h in held:
        if h["instrument_id"] == instrument_id:
            seen = True
            worth = worth_whole * take_share_pct / 100
            if worth > 0:
                out.append({"instrument_id": h["instrument_id"], "name": h["name"],
                            "worth": str(worth)})
        else:
            out.append({"instrument_id": h["instrument_id"], "name": h["name"],
                        "worth": h["worth"]})
    if not seen and take_share_pct > 0:
        out.append({"instrument_id": instrument_id, "name": "",
                    "worth": str(worth_whole * take_share_pct / 100)})
    return out


def holding_trades(investor_id: str, contested: list[dict],
                   budget: int = MOST_TRADES_REPLAYED) -> list[dict]:
    """For each shared holding and each pair of claimants: what giving the
    whole of it to one would do to both goals' odds."""
    trades: list[dict] = []
    replayed = 0

    for h in contested:
        worth = _d(h["worth"])
        claims = h["claims"]
        for i, a in enumerate(claims):
            for b in claims[i + 1:]:
                if replayed >= budget:
                    trades.append({"holding": h["name"], "a": a["goal_name"],
                                   "b": b["goal_name"], "replayed": False,
                                   "why": "Not replayed: too many contests for one request."})
                    continue
                replayed += 1
                a_share, b_share = _d(a["share_pct"]), _d(b["share_pct"])
                both = a_share + b_share

                base_a = replay.for_goal(a["goal_id"])
                base_b = replay.for_goal(b["goal_id"])
                # A takes both shares; B gives up its share.
                a_takes = replay.for_goal(a["goal_id"],
                                          holdings=_holdings_giving(a["goal_id"], h["instrument_id"], both, worth))
                b_gives = replay.for_goal(b["goal_id"],
                                          holdings=_holdings_giving(b["goal_id"], h["instrument_id"], Decimal(0), worth))
                # And the reverse.
                b_takes = replay.for_goal(b["goal_id"],
                                          holdings=_holdings_giving(b["goal_id"], h["instrument_id"], both, worth))
                a_gives = replay.for_goal(a["goal_id"],
                                          holdings=_holdings_giving(a["goal_id"], h["instrument_id"], Decimal(0), worth))

                runs = {"base_a": base_a, "base_b": base_b,
                        "a_takes": a_takes, "b_gives": b_gives,
                        "b_takes": b_takes, "a_gives": a_gives}
                r = {k: _reached(v) for k, v in runs.items()}
                trade = {
                    "holding": h["name"], "instrument_id": h["instrument_id"],
                    "worth": h["worth"], "replayed": True,
                    "a": {"goal_id": a["goal_id"], "name": a["goal_name"],
                          "share_pct": a["share_pct"], "reached_now": _s(r["base_a"]),
                          "reached_if_takes_all": _s(r["a_takes"]),
                          "reached_if_gives_up": _s(r["a_gives"]),
                          "why_not": {k: _why(runs[k]) for k in ("base_a", "a_takes", "a_gives")
                                      if r[k] is None}},
                    "b": {"goal_id": b["goal_id"], "name": b["goal_name"],
                          "share_pct": b["share_pct"], "reached_now": _s(r["base_b"]),
                          "reached_if_takes_all": _s(r["b_takes"]),
                          "reached_if_gives_up": _s(r["b_gives"]),
                          "why_not": {k: _why(runs[k]) for k in ("base_b", "b_takes", "b_gives")
                                      if r[k] is None}},
                }
                trade["reading"] = _trade_reading(h["name"], a["goal_name"], b["goal_name"], r, runs)
                trades.append(trade)
    return trades


def _s(v: Optional[Decimal]) -> Optional[str]:
    return None if v is None else str(v.quantize(Decimal("0.1")))


def _why(result: dict) -> Optional[str]:
    """The replay's own reason for refusing, shortened to its first sentence."""
    if not result or result.get("drawable"):
        return None
    why = str(result.get("why") or "could not be replayed")
    return why.split(". ")[0].rstrip(".") + "."


def _side(name: str, now: Optional[Decimal], then: Optional[Decimal],
          then_run: dict, verb: str) -> str:
    """One goal's half of a trade: its odds now and after, or why not."""
    if now is None:
        return f"{name}'s odds cannot be put in stretches ({_why(then_run) or 'no replay'})"
    if then is None:
        why = _why(then_run) or "it could not be replayed"
        if "Nothing is earmarked" in why:
            return (f"{name} would be left with nothing earmarked, so there is no "
                    f"plan to replay — it would rest on the monthly alone")
        why = why.rstrip(".")
        return f"{name} {verb} cannot be put in odds: {why[0].lower() + why[1:]}"
    return f"{name} goes from {_s(now)}% to {_s(then)}% of stretches"


def _trade_reading(holding: str, a: str, b: str, r: dict, runs: dict) -> str:
    """Say each half that can be said; name why the rest cannot."""
    one = (f"Giving {a} the whole of {holding}: "
           f"{_side(a, r['base_a'], r['a_takes'], runs['a_takes'], 'taking it')}; "
           f"{_side(b, r['base_b'], r['b_gives'], runs['b_gives'], 'giving it up')}.")
    two = (f"The other way: "
           f"{_side(b, r['base_b'], r['b_takes'], runs['b_takes'], 'taking it')}; "
           f"{_side(a, r['base_a'], r['a_gives'], runs['a_gives'], 'giving it up')}.")
    return f"{one} {two} Neither is a recommendation; it is what the choice costs."


def contribution_trades(all_goals: dict, gap: Decimal,
                        budget: int = MOST_TRADES_REPLAYED) -> list[dict]:
    """Where the monthlies exceed spare by `gap`: for each goal, its odds now
    and if it alone absorbed the whole gap. Which one does is not for us."""
    out = []
    if gap <= 0:
        return out
    replayed = 0
    for g in all_goals.get("goals", []):
        monthly = _d(g.get("monthly"))
        if monthly <= 0:
            continue
        cut_to = max(Decimal(0), monthly - gap)
        if replayed >= budget:
            out.append({"goal_id": g["id"], "name": g["name"], "replayed": False})
            continue
        replayed += 1
        base = _reached(replay.for_goal(g["id"]))
        cut = _reached(replay.for_goal(g["id"], monthly_override=cut_to))
        item = {"goal_id": g["id"], "name": g["name"], "replayed": True,
                "monthly_now": str(monthly.quantize(Decimal("1"))),
                "monthly_if_absorbs_gap": str(cut_to.quantize(Decimal("1"))),
                "reached_now": _s(base), "reached_if_absorbs_gap": _s(cut)}
        if base is None or cut is None:
            item["reading"] = (f"If {g['name']} absorbed the whole {_money(gap)} "
                               f"shortfall its monthly would fall to {_money(cut_to)}. "
                               f"We cannot put that in odds for this goal.")
        else:
            item["reading"] = (f"If {g['name']} absorbed the whole {_money(gap)} "
                               f"shortfall, its monthly would fall from "
                               f"{_money(monthly)} to {_money(cut_to)} and it would "
                               f"reach its target in {_s(cut)}% of stretches instead "
                               f"of {_s(base)}%.")
        out.append(item)
    return out


# ---------------------------------------------------------------------------
# The view
# ---------------------------------------------------------------------------

def for_investor(investor_id: str) -> dict:
    all_goals = goals_service.all_for(investor_id)
    if not all_goals.get("goals"):
        return {"goals": 0,
                "reading": "There is nothing to compete: no goals are set yet."}

    spare = committed_against_spare(investor_id, all_goals)
    holdings = contested_holdings(investor_id)

    trades = holding_trades(investor_id, holdings["contested"])
    gap = _d(spare.get("gap")) if spare.get("computable") else Decimal(0)
    cuts = contribution_trades(all_goals, gap)

    conflicts = (0 if spare.get("fits", True) else 1) + holdings["contested_count"]
    return {
        "goals": all_goals["count"],
        "committed_against_spare": spare,
        "holdings": holdings,
        "holding_trades": trades,
        "contribution_trades": cuts,
        "conflicts": conflicts,
        "what_this_is": (
            "Where your goals want the same rupees, and what each choice would "
            "cost the other goal — in how often it reached its target across "
            "every stretch of history we hold. Nothing here is ranked or "
            "recommended. Which goal matters more is yours to decide; this "
            "shows the price of deciding."),
        "as_of": date.today().isoformat(),
    }
