"""What a goal priced in another currency has to contend with.

A house in Pune costs rupees. A degree in Boston costs dollars, and the
rupees it will take depend on where the rupee is on the day the fee is due --
a second thing that moves, on top of what the money earns. This module puts a
number on that second thing the same way replay.py puts a number on the
first: not with a forecast, but by looking at every stretch of history as
long as the goal and reporting what actually happened to the rupee across
them.

Two things it will not do. It will not extrapolate past the history we hold
(the reference-rate series starts in August 1998, so a twenty-five-year goal
is refused rather than guessed), and it will not present the middle outcome
as the answer: the worst stretch is reported alongside it, because the person
planning a dollar bill in 2034 wants to know what "the rupee had a bad decade"
would cost them.

The series is the RBI/FBIL daily fixing, via the data service. Month-ends
are used, for the same reason replay.py uses them.
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from . import dataservice

log = logging.getLogger("alphanivesh.currency")

# The same bar replay.py sets: fewer stretches than this and a percentage
# has the authority of a statistic without the substance.
FEWEST_WINDOWS = 12

# A fixing this many days old is still fine to quote, with the date shown.
# Older than this and the caller should say the rate may have moved.
STALE_AFTER_DAYS = 7


def _d(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    n = int(_d(value))
    if n >= 10_000_000:
        return f"₹{n / 10_000_000:.2f} crore"
    if n >= 100_000:
        return f"₹{n / 100_000:.1f} lakh"
    return f"₹{n:,}"


def is_foreign(currency: Optional[str]) -> bool:
    return (currency or "INR").strip().upper() != "INR"


# ---------------------------------------------------------------------------
# The series
# ---------------------------------------------------------------------------

def monthly_levels(currency: str) -> list[tuple[date, Decimal]]:
    """Month-end fixings, oldest first, as (first-of-month, rate).

    Keyed to the first of the month so it lines up with replay._mix_series,
    which does the same. The value is the last fixing in that month.
    """
    try:
        payload = dataservice.fx_history(currency, days=0)
    except Exception as err:
        log.warning("no fx history for %s: %s", currency, err)
        return []

    by_month: dict[tuple[int, int], tuple[date, Decimal]] = {}
    for row in payload.get("data") or []:           # newest first
        try:
            when = datetime.strptime(row["date"], "%Y-%m-%d").date()
            rate = _d(row["rate"])
        except (KeyError, ValueError):
            continue
        if rate <= 0:
            continue
        key = (when.year, when.month)
        if key not in by_month:                    # first seen = month end
            by_month[key] = (date(when.year, when.month, 1), rate)

    return sorted(by_month.values(), key=lambda pair: pair[0])


def today(currency: str) -> Optional[dict]:
    """The latest fixing, with its date and how old it is."""
    try:
        got = dataservice.fx_latest(currency)
    except Exception as err:
        log.warning("no fx rate for %s: %s", currency, err)
        return None
    rate = _d(got.get("rate"))
    if rate <= 0:
        return None
    stale = int(got.get("stale_days") or 0)
    return {
        "currency": currency.upper(),
        "rate": str(rate.quantize(Decimal("0.01"))),
        "as_of": got.get("as_of"),
        "stale_days": stale,
        "stale": stale > STALE_AFTER_DAYS,
        "source": got.get("source"),
    }


# ---------------------------------------------------------------------------
# What the rupee did over stretches this long
# ---------------------------------------------------------------------------

def drift(currency: str, years: float) -> dict:
    """Every stretch of `years` in the history: how much the rupee moved.

    Positive means the rupee weakened (more rupees per unit), which is the
    direction that costs a foreign goal more. Returned as annualised rates so
    a five-year stretch and a ten-year stretch read on the same scale.
    """
    horizon = max(1, int(round(years)))
    levels = monthly_levels(currency)
    have_years = len(levels) / 12

    if not levels:
        return {"drawable": False,
                "why": (f"We do not hold an exchange-rate history for "
                        f"{currency.upper()}, so we cannot say how the rupee "
                        f"has behaved against it.")}

    if have_years < horizon:
        return {
            "drawable": False,
            "horizon_years": horizon,
            "history_years": round(have_years, 1),
            "why": (f"This goal is {horizon} years out and the rupee's record "
                    f"against {currency.upper()} that we hold runs "
                    f"{have_years:.0f} years. Saying what a {horizon}-year "
                    f"stretch does would mean extrapolating, which this "
                    f"will not."),
        }

    steps = horizon * 12
    annual: list[Decimal] = []
    for start in range(0, len(levels) - steps):
        a, b = levels[start][1], levels[start + steps][1]
        if a <= 0 or b <= 0:
            continue
        # Annualised: (b/a)^(1/horizon) - 1, done in float for the root.
        annual.append(Decimal(str((float(b) / float(a)) ** (1.0 / horizon) - 1.0)))

    if len(annual) < FEWEST_WINDOWS:
        return {"drawable": False, "windows": len(annual), "horizon_years": horizon,
                "why": (f"Only {len(annual)} stretches of {horizon} years exist "
                        f"in the record, which is too few to call a rate.")}

    annual.sort()

    def at(fraction: float) -> Decimal:
        return annual[min(len(annual) - 1, max(0, int(len(annual) * fraction)))]

    weakened = sum(1 for a in annual if a > 0)
    pct = lambda x: str((x * 100).quantize(Decimal("0.1")))

    return {
        "drawable": True,
        "currency": currency.upper(),
        "horizon_years": horizon,
        "windows": len(annual),
        "history_years": round(have_years, 1),
        "from": levels[0][0].isoformat(),
        "to": levels[-1][0].isoformat(),
        # Annualised change in rupees-per-unit. "worst" for the goal is the
        # biggest weakening, so it is the top of the sorted list.
        "median_pct_a_year": pct(at(0.50)),
        "worst_pct_a_year": pct(annual[-1]),
        "ninetieth_pct_a_year": pct(at(0.90)),
        "best_pct_a_year": pct(annual[0]),
        "rupee_weakened_pct": str((Decimal(weakened) / len(annual) * 100)
                                  .quantize(Decimal("0.1"))),
        "thin": len(annual) < 40,
        "_annual": annual,          # for for_goal; stripped before returning
    }


# ---------------------------------------------------------------------------
# For a goal
# ---------------------------------------------------------------------------

def for_goal(target_amount: Any, currency: str, target_date: date) -> dict:
    """The rupee cost of a foreign target: today, and across history.

    `at_today` is the rupee figure at the latest fixing. `plan_for` is what the
    same target would have cost at the end of the median historical stretch,
    and `if_bad_stretch` at the end of the worst tenth -- both starting from
    today's rate, so they answer "what if the next N years go like those".
    """
    ccy = (currency or "INR").upper()
    target = _d(target_amount)
    if not is_foreign(ccy) or target <= 0:
        return {"foreign": False}

    years = max(1.0, (target_date - date.today()).days / 365.25)
    horizon = int(round(years))

    now = today(ccy)
    out: dict = {"foreign": True, "currency": ccy,
                 "target": str(target.quantize(Decimal("1"))), "horizon_years": horizon}

    if not now:
        out["rate"] = None
        out["why_no_rate"] = (f"We do not hold a rupee rate for {ccy}, so the "
                              f"target is shown in {ccy} only.")
        return out

    rate = _d(now["rate"])
    at_today = target * rate
    out.update({
        "rate": now,
        "at_today": str(at_today.quantize(Decimal("1"))),
    })

    moved = drift(ccy, years)
    if not moved.get("drawable"):
        out["history"] = {k: v for k, v in moved.items() if k != "_annual"}
        out["reading"] = (
            f"{ccy} {target:,.0f} is {_money(at_today)} at the "
            f"{now['as_of']} fixing. " + moved.get("why", ""))
        return out

    annual = moved.pop("_annual")
    median_a = annual[min(len(annual) - 1, int(len(annual) * 0.50))]
    ninety_a = annual[min(len(annual) - 1, int(len(annual) * 0.90))]
    worst_a = annual[-1]

    def grown(a: Decimal) -> Decimal:
        return at_today * Decimal(str((1.0 + float(a)) ** horizon))

    plan_for, bad, worst = grown(median_a), grown(ninety_a), grown(worst_a)

    out["history"] = moved
    out["plan_for"] = str(plan_for.quantize(Decimal("1")))
    out["if_bad_stretch"] = str(bad.quantize(Decimal("1")))
    out["if_worst_stretch"] = str(worst.quantize(Decimal("1")))
    out["extra_over_today"] = str(max(Decimal(0), plan_for - at_today)
                                  .quantize(Decimal("1")))

    thin = " That is a thin sample and worth treating as one." if moved["thin"] else ""
    weakened = moved["rupee_weakened_pct"]
    out["reading"] = (
        f"{ccy} {target:,.0f} is {_money(at_today)} at the {now['as_of']} fixing. "
        f"Across the {moved['windows']} stretches of {horizon} years since "
        f"{moved['from'][:4]}, the rupee weakened against {ccy} in {weakened}% "
        f"of them, by {moved['median_pct_a_year']}% a year in the middle one. "
        f"Had the next {horizon} years gone like that middle stretch, the same "
        f"{ccy} {target:,.0f} would need {_money(plan_for)}; like the worst "
        f"tenth, {_money(bad)}. The rupee figure to plan around is "
        f"{_money(plan_for)}, with {_money(bad)} as the number to be able to "
        f"survive — these are stretches that happened, not a forecast, and the "
        f"next one does not have to resemble any of them.{thin}")

    if now["stale"]:
        out["reading"] += (f" The fixing we hold is {now['stale_days']} days "
                           f"old; the rate may have moved since.")
    return out
