"""The discipline meter: what the investor's own hands cost, in rupees.

Vanguard puts behavioural coaching at about 150 basis points a year of an
adviser's value -- the largest single lever -- and no app in India measures
the behaviour it is meant to coach. This does, from the transaction record:

  churn        sells of holdings held under a year: exit load (~1% on funds)
               and short-term tax (20% on the gain) that patience would have
               avoided
  activity     how many trades a month, against how many the plan asked for
  sip          months in the last twelve with a purchase, and whether the
               purchases continued through the market's falls (behaviour.kept_going)
  timing       where the purchases landed against the index's year range
               (behaviour.where_they_bought)

Each is a fact with a rupee beside it where one can be counted, and a
sentence where it cannot. The meter is shown monthly; a bad month opens a
watch event so it is said once, not nagged.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

SELLING = ("sell", "sale", "switch_out", "redemption")
BUYING = ("buy", "sip", "switch_in", "purchase")
EXIT_LOAD = Decimal("0.01")
STCG = Decimal("0.20")
LTCG = Decimal("0.125")


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def _sells(investor_id: str, since: date) -> list[dict]:
    """Each sell with the first purchase date of what it sold, and an average cost."""
    return db.fetch_all(
        """
        SELECT t.txn_date, t.txn_type, t.amount, t.quantity, t.instrument_id,
               i.name AS instrument_name, i.asset_class,
               (SELECT min(b.txn_date) FROM canonical_transactions b
                 WHERE b.investor_id = t.investor_id AND b.instrument_id = t.instrument_id
                   AND b.txn_type = ANY(%s) AND b.txn_date <= t.txn_date) AS first_bought,
               (SELECT sum(b.amount) / nullif(sum(b.quantity), 0) FROM canonical_transactions b
                 WHERE b.investor_id = t.investor_id AND b.instrument_id = t.instrument_id
                   AND b.txn_type = ANY(%s) AND b.txn_date <= t.txn_date AND b.quantity > 0) AS avg_cost
        FROM canonical_transactions t
        JOIN instruments i ON i.id = t.instrument_id
        WHERE t.investor_id = %s AND t.txn_type = ANY(%s) AND t.txn_date >= %s AND t.amount > 0
        ORDER BY t.txn_date
        """, (list(BUYING), list(BUYING), investor_id, list(SELLING), since))


def _buy_months(investor_id: str, since: date) -> set[tuple[int, int]]:
    rows = db.fetch_all(
        "SELECT DISTINCT date_trunc('month', txn_date)::date AS m FROM canonical_transactions "
        "WHERE investor_id = %s AND txn_type = ANY(%s) AND txn_date >= %s AND amount > 0",
        (investor_id, list(BUYING), since))
    return {(r["m"].year, r["m"].month) for r in rows}


def _planned_sells(investor_id: str, since: date) -> int:
    row = db.fetch_one(
        "SELECT count(*) AS n FROM order_consent WHERE investor_id = %s AND side = 'sell' AND used_at >= %s",
        (investor_id, since))
    return int((row or {}).get("n") or 0)


def meter(investor_id: str, months: int = 12) -> dict:
    from . import behaviour
    today = date.today()
    since = today - timedelta(days=30 * months)
    sells = _sells(investor_id, since)

    churn_cost, churn_rows = Decimal(0), []
    for s in sells:
        held_days = (s["txn_date"] - s["first_bought"]).days if s["first_bought"] else None
        if held_days is None or held_days >= 365:
            continue
        amount = _d(s["amount"])
        gain = Decimal(0)
        if s.get("avg_cost") and s.get("quantity"):
            gain = amount - _d(s["avg_cost"]) * _d(s["quantity"])
        load = amount * EXIT_LOAD if (s.get("asset_class") or "") == "mutual_fund" else Decimal(0)
        extra_tax = max(Decimal(0), gain) * (STCG - LTCG)
        cost = load + extra_tax
        churn_cost += cost
        churn_rows.append({"on": s["txn_date"].isoformat(), "name": s["instrument_name"], "held_days": held_days,
                           "amount": str(amount.quantize(Decimal("1"))), "cost": str(cost.quantize(Decimal("1"))),
                           "say": (f"{s['instrument_name']} sold after {held_days} days"
                                   + (f": about {_money(load)} of exit load" if load else "")
                                   + (f"{' and ' if load else ': '}{_money(extra_tax)} more tax than waiting for a year" if extra_tax > 0 else "")
                                   + ".")})

    planned = _planned_sells(investor_id, since)
    unplanned = max(0, len(sells) - planned)
    per_month = Decimal(len(sells)) / Decimal(months)

    bm = _buy_months(investor_id, since)
    months_with_buys = len(bm)
    try:
        nerve = behaviour.kept_going(investor_id) or {}
    except Exception:
        nerve = {}
    try:
        placement = behaviour.where_they_bought(investor_id) or {}
    except Exception:
        placement = {}

    parts = []
    if not sells and not bm:
        return {
            "months": months, "since": since.isoformat(), "sales": 0, "planned_sales": 0, "unplanned_sales": 0,
            "sales_per_month": "0", "churn": {"count": 0, "cost": "0", "rows": []}, "months_with_purchases": 0,
            "nerve": None, "placement": None, "measurable": False,
            "reading": ("The statements we hold carry no dated transactions for this period, so there is nothing to measure yet. "
                        "A CAS with transactions, or a broker statement with the trades, is what this needs."),
            "principle": "Counted from your own transactions, when we have them.",
        }
    if churn_rows:
        parts.append(f"{len(churn_rows)} sale{'s' if len(churn_rows) != 1 else ''} of holdings under a year old cost about "
                     f"{_money(churn_cost)} in exit load and extra tax that waiting would have saved.")
    else:
        parts.append("Nothing sold under a year old: no churn cost." if sells else "No sales in the period.")
    if sells:
        parts.append(f"{len(sells)} sale{'s' if len(sells) != 1 else ''} in {months} months, {planned} of them from the plan"
                     + (f"; {unplanned} on your own account." if unplanned else "."))
    parts.append(f"Purchases in {months_with_buys} of the last {months} months."
                 + (" Every month: the habit is doing the work." if months_with_buys >= months - 1 else
                    " A gap of a few months is normal; a gap in a fall is the one that costs." if months_with_buys >= months // 2 else
                    " Irregular — the money that goes in late in a rally and not at all in a fall is the expensive kind."))
    if nerve.get("tested"):
        parts.append(f"Through the market's {nerve.get('hard_months')} hard months on record you kept buying in "
                     f"{nerve.get('months_invested_through')} of them" + (" — all of them." if nerve.get("held_nerve") else "."))

    return {
        "months": months, "since": since.isoformat(),
        "sales": len(sells), "planned_sales": planned, "unplanned_sales": unplanned,
        "sales_per_month": str(per_month.quantize(Decimal("0.1"))),
        "churn": {"count": len(churn_rows), "cost": str(churn_cost.quantize(Decimal("1"))), "rows": churn_rows[:8]},
        "months_with_purchases": months_with_buys,
        "nerve": nerve if nerve.get("tested") else None,
        "placement": placement if placement else None,
        "reading": " ".join(parts),
        "principle": ("Counted from your own transactions. The exit load is assumed at 1% on funds sold inside a year and "
                      "the tax difference at 7.5 points (20% short-term against 12.5% long-term) on the gain — both the usual "
                      "case, neither certain for every scheme. The point is the direction, not the last rupee."),
    }


def watch_event(investor_id: str) -> Optional[dict]:
    """A monthly watch event when the meter has something to say. None on a clean month."""
    m = meter(investor_id, months=3)
    if m.get("measurable") is False:
        return None
    cost = _d(m["churn"]["cost"])
    if cost < 2000 and m["unplanned_sales"] < 3:
        return None
    today = date.today()
    return {
        "kind": "discipline", "severity": "note",
        "fingerprint": f"discipline:{today.year}-{today.month:02d}",
        "what": (f"Churn cost about {_money(cost)} this quarter" if cost >= 2000 else
                 f"{m['unplanned_sales']} sales outside the plan this quarter"),
        "why": m["reading"], "size": cost, "detail": {"churn": m["churn"], "unplanned": m["unplanned_sales"]},
    }
