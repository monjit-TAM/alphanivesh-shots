"""Which holdings are doing which job.

A goal claims specific holdings, not a share of the portfolio.

**The lazy version is a percentage** — retirement gets 60% of everything. It is
easier, and it lies in two directions: it lets the same rupee fund three goals,
and it cannot tell somebody that the money for next year's school fees is in a
small-cap fund.

**So: rows.** A holding, a goal, and how much of it. The database refuses an
over-promise; this module does the arithmetic and the reading.

**The share is stored, the value is computed.** Somebody decided "half of this
fund is for the house" — that is the decision and it persists. What half of it
is worth today is a fact about today and is never stored.

**And what is unassigned stays unassigned.** Not silently swept into
retirement. "Eighteen lakh is not doing anything in particular" is a useful
sentence and a common situation.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.earmarks")

# How soon is soon.
#
# Money needed inside this many years has no business being in equity: the
# thing that makes shares worth holding is time to recover, and a deposit due
# in eleven months has none. Three years is the conventional line and it is
# conventional because it is roughly how long a bad equity year takes to come
# back -- not always, which is the point.
SOON_YEARS = 3

# What we treat as able to fall a long way and stay down.
VOLATILE = {"equity", "mutual_fund", "etf", "unlisted"}

# What is fine for money needed soon.
STEADY = {"cash", "fixed_deposit", "bond", "gsec", "liquid"}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("\u20B9" if not negative else "-\u20B9") + digits


# ---------------------------------------------------------------------------
# What a goal holds
# ---------------------------------------------------------------------------

def holdings_for(goal_id: str) -> dict:
    """What is earmarked to a goal, valued today.

    Every figure here is computed from today's prices. Nothing about what a
    goal is worth is stored, so this cannot go stale -- and when it changes,
    the reason is that the holdings changed rather than that a number was
    written down once.
    """
    rows = db.fetch_all(
        """
        SELECT e.id, e.instrument_id, e.share_pct,
               v.instrument_name, v.asset_class, v.symbol,
               v.current_value, v.quantity
        FROM goal_earmark e
        JOIN v_current_holdings v
          ON v.instrument_id = e.instrument_id
         AND v.investor_id = e.investor_id
        WHERE e.goal_id = %s AND e.removed_at IS NULL
          AND v.current_value > 0
        ORDER BY v.current_value * e.share_pct DESC
        """,
        (goal_id,))

    holdings, total = [], Decimal(0)
    for row in rows:
        share = _d(row["share_pct"]) / 100
        worth = _d(row["current_value"]) * share
        total += worth
        holdings.append({
            "earmark_id": row["id"],
            "instrument_id": row["instrument_id"],
            "name": row["instrument_name"],
            "symbol": row["symbol"],
            "asset_class": row["asset_class"],
            "share_pct": str(_d(row["share_pct"]).quantize(Decimal("0.1"))),
            "whole_holding": str(_d(row["current_value"]).quantize(Decimal("1"))),
            "worth": str(worth.quantize(Decimal("1"))),
            "all_of_it": _d(row["share_pct"]) >= Decimal("99.9"),
        })

    return {
        "holdings": holdings,
        "count": len(holdings),
        "worth": str(total.quantize(Decimal("1"))),
    }


def unassigned(investor_id: str) -> dict:
    """What is not doing any particular job.

    Reported rather than swept somewhere. A portfolio where most of the money
    is unassigned is not a broken portfolio -- it is the usual situation, and
    the module should say so plainly rather than implying a fault.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.asset_class,
               v.current_value,
               coalesce((SELECT sum(e.share_pct) FROM goal_earmark e
                          WHERE e.instrument_id = v.instrument_id
                            AND e.investor_id = v.investor_id
                            AND e.removed_at IS NULL), 0) AS claimed_pct
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,))

    loose, total_loose, total_all = [], Decimal(0), Decimal(0)
    for row in rows:
        whole = _d(row["current_value"])
        total_all += whole
        free_pct = Decimal(100) - _d(row["claimed_pct"])
        if free_pct <= Decimal("0.1"):
            continue
        free = whole * free_pct / 100
        total_loose += free
        loose.append({
            "instrument_id": row["instrument_id"],
            "name": row["instrument_name"],
            "asset_class": row["asset_class"],
            "free_pct": str(free_pct.quantize(Decimal("0.1"))),
            "worth": str(free.quantize(Decimal("1"))),
            "partly_claimed": free_pct < Decimal("99.9"),
        })

    share = (total_loose / total_all * 100) if total_all else Decimal(0)

    return {
        "holdings": loose,
        "count": len(loose),
        "worth": str(total_loose.quantize(Decimal("1"))),
        "share_pct": str(share.quantize(Decimal("0.1"))),
        "reading": (
            "Everything you hold is assigned to a goal."
            if not loose else
            f"{_money(total_loose)} — {share.quantize(Decimal('0.1'))}% of what "
            f"you hold — is not assigned to anything in particular. That is "
            f"not a fault; most portfolios look like this. It only matters if "
            f"one of your goals is short."),
    }


# ---------------------------------------------------------------------------
# Assigning
# ---------------------------------------------------------------------------

def assign(goal_id: str, investor_id: str, instrument_id: str,
           share_pct: Any) -> dict:
    """Put a share of a holding behind a goal.

    The database refuses an over-promise and this reports why in words
    somebody can act on -- which of their goals already has it, and how much
    is left.
    """
    share = _d(share_pct)
    if share <= 0 or share > 100:
        raise ValueError("A share has to be between 0 and 100 per cent.")

    # The holding has to be theirs, and the goal has to be theirs. The
    # over-promise trigger checks shares, not ownership, so without this an
    # earmark could point at a fund this person does not hold -- and then
    # silently value at nothing.
    owned = db.fetch_one(
        "SELECT 1 AS ok FROM v_current_holdings "
        "WHERE investor_id = %s AND instrument_id = %s AND current_value > 0",
        (investor_id, instrument_id))
    if not owned:
        raise ValueError("That is not one of this investor's current holdings.")
    goal_ok = db.fetch_one(
        "SELECT 1 AS ok FROM goal WHERE id = %s AND investor_id = %s "
        "AND abandoned_at IS NULL", (goal_id, investor_id))
    if not goal_ok:
        raise ValueError("No such goal for this investor.")

    already = claimed_on(investor_id, instrument_id)
    free = Decimal(100) - _d(already["claimed_pct"])

    if share > free + Decimal("0.001"):
        others = ", ".join(g["goal_name"] for g in already["goals"])
        raise ValueError(
            f"Only {free.quantize(Decimal('0.1'))}% of that holding is "
            f"unassigned — the rest is behind {others}. Either take less, or "
            f"free some of it from there first.")

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO goal_earmark
                (goal_id, investor_id, instrument_id, share_pct)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (goal_id, instrument_id)
            DO UPDATE SET share_pct = EXCLUDED.share_pct,
                          removed_at = NULL,
                          assigned_at = now()
            RETURNING id
            """,
            (goal_id, investor_id, instrument_id, share)).fetchone()

    return {"earmark_id": row["id"] if row else None,
            "goal": holdings_for(goal_id)}


def release(goal_id: str, instrument_id: str) -> bool:
    """Take a holding back off a goal.

    Marked rather than deleted. Somebody who assigned a fund to the house
    deposit in March and moved it to retirement in September has a history
    worth keeping, and the row is the only place it exists.
    """
    row = db.fetch_one(
        """
        UPDATE goal_earmark SET removed_at = now()
        WHERE goal_id = %s AND instrument_id = %s AND removed_at IS NULL
        RETURNING id
        """,
        (goal_id, instrument_id))
    return bool(row)


def claimed_on(investor_id: str, instrument_id: str) -> dict:
    """Who has a claim on this holding, and how much is left."""
    rows = db.fetch_all(
        """
        SELECT e.share_pct, g.id AS goal_id, g.name AS goal_name, g.kind
        FROM goal_earmark e
        JOIN goal g ON g.id = e.goal_id
        WHERE e.investor_id = %s AND e.instrument_id = %s
          AND e.removed_at IS NULL AND g.abandoned_at IS NULL
        ORDER BY e.share_pct DESC
        """,
        (investor_id, instrument_id))

    claimed = sum((_d(r["share_pct"]) for r in rows), Decimal(0))
    return {
        "goals": [{"goal_id": r["goal_id"], "goal_name": r["goal_name"],
                   "kind": r["kind"],
                   "share_pct": str(_d(r["share_pct"]).quantize(Decimal("0.1")))}
                  for r in rows],
        "claimed_pct": str(claimed.quantize(Decimal("0.1"))),
        "free_pct": str((Decimal(100) - claimed).quantize(Decimal("0.1"))),
    }


# ---------------------------------------------------------------------------
# The check only earmarking can make
# ---------------------------------------------------------------------------

def mismatch(goal_id: str) -> Optional[dict]:
    """Money needed soon, sitting in something that can fall a long way.

    **This is the reason earmarking is worth the extra work.** A percentage
    model cannot make this check: it cannot tell the fund that is for
    retirement from the fund that is for next year's deposit, because in that
    model they are the same money.

    It is the most common real error in personal finance and it is invisible
    without knowing which money is for what.
    """
    goal = db.fetch_one(
        "SELECT id, name, kind, target_date, target_amount, currency "
        "FROM goal WHERE id = %s AND abandoned_at IS NULL",
        (goal_id,))
    if not goal:
        return None

    years_left = (goal["target_date"] - date.today()).days / 365.25
    if years_left > SOON_YEARS:
        return None
    if years_left < 0:
        return None

    held = holdings_for(goal_id)
    at_risk, at_risk_value = [], Decimal(0)

    for holding in held["holdings"]:
        if holding["asset_class"] in VOLATILE:
            at_risk_value += _d(holding["worth"])
            at_risk.append(holding)

    if not at_risk:
        return None

    total = _d(held["worth"])
    share = (at_risk_value / total * 100) if total else Decimal(0)
    months = int(years_left * 12)

    return {
        "goal_id": goal_id,
        "goal_name": goal["name"],
        "months_left": months,
        "at_risk": at_risk,
        "at_risk_value": str(at_risk_value.quantize(Decimal("1"))),
        "share_pct": str(share.quantize(Decimal("0.1"))),
        "reading": (
            f"{_money(at_risk_value)} of the money for {goal['name']} is in "
            f"shares or equity funds, and you need it in "
            f"{months} month{'s' if months != 1 else ''}. Equities are worth "
            f"holding because they recover, and recovering takes years you do "
            f"not have here — the worst falls in Indian equity have taken "
            f"eighteen months to two years to come back, and some longer."),
        "what_it_means": (
            "This is not a prediction that it will fall. It is that if it "
            "does, there is no time to wait it out, and the money is needed "
            "on a date rather than eventually."),
    }


def mismatches(investor_id: str) -> list[dict]:
    """Every goal with money needed soon in something that can fall."""
    rows = db.fetch_all(
        """
        SELECT id FROM goal
        WHERE investor_id = %s AND abandoned_at IS NULL AND reached_at IS NULL
          -- Multiplied rather than interpolated: a bound parameter cannot sit
          -- inside an interval literal, and building the string by hand is
          -- how an injection gets in even when the value is our own constant.
          AND target_date <= current_date + (%s * interval '1 year')
        ORDER BY target_date
        """,
        (investor_id, SOON_YEARS))

    found = []
    for row in rows:
        one = mismatch(row["id"])
        if one:
            found.append(one)
    return found
