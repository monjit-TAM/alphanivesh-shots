"""The family: the tax-free allowance is per person, not per portfolio.

₹1.25 lakh of long-term equity gain is tax-free each year *per PAN*. A family
of four adults who each hold something has ₹5 lakh of allowance, worth
₹62,500 a year in tax -- and every app that offers harvesting at all (Kuvera,
alone in India) offers it one account at a time. This does it across the
household: each member's own unused allowance, what to book and buy back to
use it, and the total the family is leaving on the table.

Membership comes from the household a person belongs to; where none has been
set up, from the portfolios one login looks after. A member marked as not
counting toward the household (most often a minor) is shown and excluded:
a minor's gains are clubbed with a parent's income and carry no allowance
of their own.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from .. import db

log = logging.getLogger(__name__)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def members_of(investor_id: str) -> dict:
    hh = db.fetch_one(
        "SELECT hm.household_id FROM household_members hm WHERE hm.investor_id = %s LIMIT 1", (investor_id,))
    if hh:
        rows = db.fetch_all(
            """
            SELECT i.id, i.display_name, hm.include_in_rollup AS counts, i.pan_last4
            FROM household_members hm JOIN investors i ON i.id = hm.investor_id
            WHERE hm.household_id = %s ORDER BY i.display_name
            """, (hh["household_id"],))
        return {"source": "household", "household_id": hh["household_id"], "members": rows}
    owner = db.fetch_one("SELECT owner_user_id FROM investors WHERE id = %s", (investor_id,))
    if owner and owner.get("owner_user_id"):
        rows = db.fetch_all(
            "SELECT id, display_name, true AS counts, pan_last4 FROM investors WHERE owner_user_id = %s ORDER BY display_name",
            (owner["owner_user_id"],))
        return {"source": "login", "household_id": None, "members": rows}
    row = db.fetch_one("SELECT id, display_name, true AS counts, pan_last4 FROM investors WHERE id = %s", (investor_id,))
    return {"source": "self", "household_id": None, "members": [row] if row else []}


def harvest(investor_id: str, may_see=None) -> dict:
    """`may_see(investor_id) -> bool`: members the caller may not see are counted as
    hidden and contribute nothing to the figures shown."""
    from . import harvest as hv
    fam = members_of(investor_id)
    hidden = 0
    people, total_saving, total_gain, unused_pans = [], Decimal(0), Decimal(0), 0
    months_left = None
    for m in fam["members"]:
        if may_see is not None and not may_see(m["id"]):
            hidden += 1
            continue
        name = (m.get("display_name") or "—").split()[0].title()
        if not m.get("counts"):
            people.append({"investor_id": m["id"], "name": name, "counts": False,
                           "say": "Not counted: a minor's gains are clubbed with a parent's and carry no allowance of their own."})
            continue
        try:
            op = hv.opportunity(m["id"])
        except Exception as err:
            log.info("harvest failed for %s: %s", m["id"], err)
            op = None
        if not op:
            people.append({"investor_id": m["id"], "name": name, "counts": True, "worth_doing": False,
                           "say": "No long-term gain to book this year."})
            continue
        months_left = op.get("months_left", months_left)
        if not op.get("worth_doing"):
            people.append({"investor_id": m["id"], "name": name, "counts": True, "worth_doing": False,
                           "available_gain": op.get("available_gain"), "saving": op.get("saving"), "say": op.get("why")})
            continue
        unused_pans += 1
        total_saving += _d(op["saving"]); total_gain += _d(op["available_gain"])
        people.append({"investor_id": m["id"], "name": name, "counts": True, "worth_doing": True,
                       "available_gain": op["available_gain"], "saving": op["saving"], "plan": op.get("plan"),
                       "say": op.get("reading")})
    counted = sum(1 for p in people if p["counts"])
    hidden_note = (f" {hidden} more member{'s' if hidden != 1 else ''} of the household {'are' if hidden != 1 else 'is'} looked after by someone else and not shown." if hidden else "")
    who = "you" if counted == 1 else f"{counted} people"
    reading = ((("You still have" if counted == 1 else f"Across {who}, {unused_pans} still {'has' if unused_pans == 1 else 'have'}")
                + f" tax-free allowance to use this year: "
                f"{_money(total_gain)} of long-term gain can be booked and bought back, saving about {_money(total_saving)}"
                + (f" — {months_left} month{'s' if months_left != 1 else ''} until 31 March." if months_left is not None else ".")
                + " Each person's allowance is their own: it cannot be moved between you, and it does not carry forward.")
               if unused_pans else
               ((f"Across {counted} people, nobody has" if counted > 1 else "You have no") + " long-term gain worth booking this year." if counted else
                "Nobody in this family has a portfolio here yet.")) + hidden_note
    return {
        "source": fam["source"], "household_id": fam["household_id"], "people": people, "hidden_members": hidden,
        "pans_with_room": unused_pans, "total_gain": str(total_gain.quantize(Decimal("1"))),
        "total_saving": str(total_saving.quantize(Decimal("1"))), "months_left": months_left, "reading": reading,
        "caveat": ("Each figure assumes that person has realised no other long-term gain this year; a sale anywhere else "
                   "uses the same allowance and we cannot see it."),
    }
