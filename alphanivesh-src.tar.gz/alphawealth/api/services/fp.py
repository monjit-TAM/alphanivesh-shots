"""Fintech Primitives (Cybrilla) -- the mutual-fund order rail.

FP sits on BSE StAR / NSE NMF / the RTAs and exposes one API for investor
onboarding, KYC, folios, purchases, redemptions, switches and SIPs. We use it
as a rail: AlphaNivesh decides and records; FP carries the order to the AMC
under the associated RIA's or MFD's registration.

Everything FP-specific is in this file and nowhere else. Two tables at the
top -- PATHS and FIELDS -- hold every endpoint and field name we depend on,
because their documentation renders as a single page that truncates and the
names below were read from workflow examples rather than a schema. The first
thing to run against a fresh tenant is tools/fp_shapes.py, which prints the
real objects; if a name differs, it is changed here, once.

Credentials come from the environment and are never logged:
    FP_TENANT, FP_CLIENT_ID, FP_CLIENT_SECRET
    FP_ENV = sandbox (default) | production
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Optional

import httpx

log = logging.getLogger("alphanivesh.fp")

BASES = {
    "sandbox": "https://s.finprim.com",
    "production": "https://api.fintechprimitives.com",
}

ENV = os.environ.get("FP_ENV", "sandbox").strip().lower()
TENANT = os.environ.get("FP_TENANT", "").strip()
CLIENT_ID = os.environ.get("FP_CLIENT_ID", "").strip()
CLIENT_SECRET = os.environ.get("FP_CLIENT_SECRET", "").strip()
BASE = os.environ.get("FP_BASE", BASES.get(ENV, BASES["sandbox"]))

TIMEOUT = httpx.Timeout(30.0, connect=8.0)

# Every path we call. Edit here after tools/fp_shapes.py has printed the
# real ones for this tenant.
PATHS = {
    "token": "/v2/auth/{tenant}/token",
    "investor_profiles": "/v2/investor_profiles",
    "bank_accounts": "/v2/bank_accounts",
    "mf_investment_accounts": "/v2/mf_investment_accounts",
    "kyc_requests": "/v2/kyc_requests",
    "fund_scheme": "/api/oms/fund_schemes/{isin}",
    "mf_purchases": "/api/oms/mf_purchases",
    "mf_redemptions": "/api/oms/mf_redemptions",
    "mf_switches": "/api/oms/mf_switches",
    "mf_purchase_plans": "/api/oms/mf_purchase_plans",
    "payments": "/api/oms/payments",
}

# Field names on the wire, in one place for the same reason.
FIELDS = {
    "account": "mf_investment_account",      # on orders: the account id
    "scheme": "scheme",                       # ISIN
    "amount": "amount",
    "units": "units",
    "folio": "folio_number",
    "state": "state",
    "consent": "consent",                     # {"email":..., "isd":"91", "mobile":...}
    "user_ip": "user_ip",
    "server_ip": "server_ip",
    "initiated_by": "initiated_by",           # "investor" | "distributor" | "advisor"
    "initiated_via": "initiated_via",         # "web" | "mobile_app" | ...
    "euin": "euin",
    "switch_from": "switch_out_scheme",
    "switch_to": "switch_in_scheme",
    "payment_orders": "amc_order_ids",
    "payment_bank": "bank_account_id",
    "payment_method": "method",
}

# Order states as FP reports them, mapped to ours. Unknown states pass through
# untouched so the record shows what the rail actually said.
STATE_MAP = {
    "pending": "pending",          # created, not yet confirmed
    "confirmed": "confirmed",      # consent attached, awaiting submission
    "submitted": "submitted",      # sent to AMC/exchange
    "successful": "settled",
    "success": "settled",
    "failed": "failed",
    "cancelled": "cancelled",
    "reversed": "reversed",
}
OPEN_STATES = {"created", "pending", "confirmed", "submitted"}


class NotConfigured(Exception):
    """No FP credentials in the environment."""


class RailError(Exception):
    """FP could not do it. Carries what it said."""


def configured() -> bool:
    return bool(TENANT and CLIENT_ID and CLIENT_SECRET)


def status() -> dict:
    return {"venue": "fp", "environment": ENV, "base": BASE,
            "configured": configured(), "tenant": TENANT or None}


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

_token: dict = {"value": None, "expires": 0.0}
_lock = threading.Lock()


def _bearer() -> str:
    """A token, fetched or reused. Refreshed a minute before it lapses."""
    if not configured():
        raise NotConfigured("FP_TENANT / FP_CLIENT_ID / FP_CLIENT_SECRET are not set")
    with _lock:
        if _token["value"] and time.time() < _token["expires"] - 60:
            return _token["value"]
        url = BASE + PATHS["token"].format(tenant=TENANT)
        try:
            with httpx.Client(timeout=TIMEOUT) as c:
                r = c.post(url, data={"client_id": CLIENT_ID,
                                      "client_secret": CLIENT_SECRET,
                                      "grant_type": "client_credentials"},
                           headers={"accept": "application/json"})
        except httpx.HTTPError as err:
            raise RailError(f"could not reach FP for a token: {err}")
        if r.status_code >= 400:
            raise RailError(f"FP refused the credentials ({r.status_code})")
        body = r.json()
        _token["value"] = body["access_token"]
        _token["expires"] = time.time() + int(body.get("expires_in") or 1800)
        return _token["value"]


def _call(method: str, path: str, *, json: Optional[dict] = None,
          params: Optional[dict] = None) -> Any:
    headers = {"Authorization": f"Bearer {_bearer()}", "accept": "application/json"}
    try:
        with httpx.Client(base_url=BASE, timeout=TIMEOUT, headers=headers) as c:
            r = c.request(method, path, json=json, params=params)
    except httpx.HTTPError as err:
        raise RailError(f"could not reach FP: {err}")
    if r.status_code == 401:
        _token["value"] = None                      # force a fresh token next time
        raise RailError("FP rejected the token")
    if r.status_code >= 400:
        raise RailError(_detail(r) or f"FP returned {r.status_code}")
    try:
        return r.json()
    except ValueError:
        raise RailError("FP returned something unreadable")


def _detail(r: httpx.Response) -> Optional[str]:
    try:
        b = r.json()
    except ValueError:
        return r.text[:200] or None
    if isinstance(b, dict):
        err = b.get("error") or b
        if isinstance(err, dict):
            return err.get("message") or err.get("detail") or str(err)[:300]
        return str(err)[:300]
    return str(b)[:300]


# ---------------------------------------------------------------------------
# Investor side
# ---------------------------------------------------------------------------

def create_investor_profile(*, name: str, pan: str, date_of_birth: str,
                            email: str, mobile: str, **extra: Any) -> dict:
    """Once per investor. PAN is sent and not kept anywhere on our side."""
    body = {"name": name, "pan": pan.upper(), "date_of_birth": date_of_birth,
            "email": email, "mobile": mobile, **extra}
    return _call("POST", PATHS["investor_profiles"], json=body)


def create_bank_account(*, profile_ref: str, account_number: str, ifsc: str,
                        holder_name: str, account_type: str = "savings") -> dict:
    body = {"investor_profile": profile_ref, "account_number": account_number,
            "ifsc_code": ifsc.upper(), "account_holder_name": holder_name,
            "type": account_type}
    return _call("POST", PATHS["bank_accounts"], json=body)


def create_investment_account(*, profile_ref: str, holding_pattern: str = "single") -> dict:
    body = {"primary_investor_profile": profile_ref, "holding_pattern": holding_pattern}
    return _call("POST", PATHS["mf_investment_accounts"], json=body)


def kyc_status(profile_ref: str) -> dict:
    return _call("GET", PATHS["kyc_requests"], params={"investor_profile": profile_ref})


def fund_scheme(isin: str) -> dict:
    """What FP knows about a scheme: minimums, whether purchase is open, etc."""
    return _call("GET", PATHS["fund_scheme"].format(isin=isin))


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

def _consent_block(email: str, mobile: str) -> dict:
    digits = "".join(ch for ch in (mobile or "") if ch.isdigit())
    return {"email": email, "isd": "91", "mobile": digits[-10:]}


def create_purchase(*, account_ref: str, isin: str, amount: Any,
                    folio: Optional[str] = None, user_ip: Optional[str] = None,
                    initiated_by: str = "investor", initiated_via: str = "web",
                    euin: Optional[str] = None) -> dict:
    body = {FIELDS["account"]: account_ref, FIELDS["scheme"]: isin,
            FIELDS["amount"]: float(amount),
            FIELDS["initiated_by"]: initiated_by, FIELDS["initiated_via"]: initiated_via}
    if folio:
        body[FIELDS["folio"]] = folio
    if user_ip:
        body[FIELDS["user_ip"]] = user_ip
    if euin:
        body[FIELDS["euin"]] = euin
    return _call("POST", PATHS["mf_purchases"], json=body)


def create_redemption(*, account_ref: str, isin: str, amount: Any = None,
                      units: Any = None, folio: Optional[str] = None,
                      user_ip: Optional[str] = None,
                      initiated_by: str = "investor", initiated_via: str = "web") -> dict:
    if not amount and not units:
        raise ValueError("a redemption needs an amount or units")
    body = {FIELDS["account"]: account_ref, FIELDS["scheme"]: isin,
            FIELDS["initiated_by"]: initiated_by, FIELDS["initiated_via"]: initiated_via}
    if amount:
        body[FIELDS["amount"]] = float(amount)
    else:
        body[FIELDS["units"]] = float(units)
    if folio:
        body[FIELDS["folio"]] = folio
    if user_ip:
        body[FIELDS["user_ip"]] = user_ip
    return _call("POST", PATHS["mf_redemptions"], json=body)


def create_switch(*, account_ref: str, from_isin: str, to_isin: str,
                  amount: Any = None, units: Any = None, folio: Optional[str] = None,
                  user_ip: Optional[str] = None,
                  initiated_by: str = "investor", initiated_via: str = "web") -> dict:
    body = {FIELDS["account"]: account_ref, FIELDS["switch_from"]: from_isin,
            FIELDS["switch_to"]: to_isin,
            FIELDS["initiated_by"]: initiated_by, FIELDS["initiated_via"]: initiated_via}
    if amount:
        body[FIELDS["amount"]] = float(amount)
    elif units:
        body[FIELDS["units"]] = float(units)
    if folio:
        body[FIELDS["folio"]] = folio
    if user_ip:
        body[FIELDS["user_ip"]] = user_ip
    return _call("POST", PATHS["mf_switches"], json=body)


def create_sip(*, account_ref: str, isin: str, amount: Any, frequency: str = "monthly",
               installments: int = 0, start_date: Optional[str] = None,
               folio: Optional[str] = None, user_ip: Optional[str] = None) -> dict:
    body = {FIELDS["account"]: account_ref, FIELDS["scheme"]: isin,
            FIELDS["amount"]: float(amount), "frequency": frequency}
    if installments:
        body["number_of_installments"] = int(installments)
    if start_date:
        body["start_date"] = start_date
    if folio:
        body[FIELDS["folio"]] = folio
    if user_ip:
        body[FIELDS["user_ip"]] = user_ip
    return _call("POST", PATHS["mf_purchase_plans"], json=body)


def confirm(kind: str, order_ref: str, *, email: str, mobile: str) -> dict:
    """Attach the investor's consent. FP will not submit without it, and
    neither would we: the consent row on our side is claimed first."""
    path = f"{PATHS[_path_key(kind)]}/{order_ref}"
    body = {FIELDS["state"]: "confirmed",
            FIELDS["consent"]: _consent_block(email, mobile)}
    return _call("POST", path, json=body)


def pay(*, order_refs: list, bank_ref: str, method: str = "NETBANKING",
        return_url: Optional[str] = None) -> dict:
    """A payment for one or more purchases. FP answers with a URL the investor
    completes the payment at (netbanking/UPI) or with a mandate reference."""
    body = {FIELDS["payment_orders"]: order_refs, FIELDS["payment_bank"]: bank_ref,
            FIELDS["payment_method"]: method}
    if return_url:
        body["return_url"] = return_url
    return _call("POST", PATHS["payments"], json=body)


def fetch(kind: str, order_ref: str) -> dict:
    return _call("GET", f"{PATHS[_path_key(kind)]}/{order_ref}")


def _path_key(kind: str) -> str:
    return {"purchase": "mf_purchases", "redemption": "mf_redemptions",
            "switch": "mf_switches", "sip": "mf_purchase_plans"}[kind]


def our_state(fp_state: Optional[str]) -> str:
    return STATE_MAP.get((fp_state or "").lower(), (fp_state or "unknown").lower())
