"""The glide path: each goal de-risks on its own date, from new money first.

Betterment's Auto-Adjust and Vanguard's life-cycle model are the two things
Morningstar rewards above all else in this industry, and no Indian planner
has either: every goal found in the benchmark is a single expected return
and a date. This is the other half of the goals module. A goal's earmarked
money has a mix; the years left say what mix it can carry; the gap is closed
by pointing the goal's own monthly contribution at the short bucket first,
and only when that is not enough -- or the date is close -- by moving what
is already there.

The path is a step function of years left, deliberately coarse: a goal ten
years out can carry mostly equity; inside five years, less than half; inside
three, a quarter; in the last year, none. The steps are where the next
instruction will come from, and the page says when.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

# (years left at least, equity % of the goal's money). Checked top-down.
PATH = [(10, Decimal(70)), (7, Decimal(60)), (5, Decimal(45)), (3, Decimal(30)), (1, Decimal(15)), (0, Decimal(0))]
BAND = Decimal(10)            # inside this, nothing is said
MOVE_WHEN_UNDER_YEARS = 3     # closer than this, an over-weight is moved, not merely starved
SMALLEST = Decimal(10000)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 10000000:
        return f"₹{v / 10000000:.2f} crore"
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def equity_for(years_left: float) -> Decimal:
    for floor, pct in PATH:
        if years_left >= floor:
            return pct
    return Decimal(0)


def _next_step(years_left: float, target_date: date) -> Optional[dict]:
    """When the path next steps down, and to what."""
    now = equity_for(years_left)
    for floor, pct in PATH:
        if floor < years_left and pct < now:
            when = target_date - timedelta(days=int(floor * 365.25))
            return {"on": when.isoformat(), "equity_pct": str(pct), "years_left_then": floor}
    return None


def for_goal(goal_id: str) -> dict:
    from . import alpha, earmarks, goals, restructure
    g = goals.one(goal_id)
    if not g:
        return {"drawable": False, "why": "No such goal."}
    held = earmarks.holdings_for(goal_id)
    rows = held.get("holdings") or []
    worth = _d(held.get("worth"))
    years = float(g.get("years_left") or 0)
    target_eq = equity_for(years)
    td = date.fromisoformat(g["target_date"])

    # The earmarked mix, by the same classifier the plan uses.
    full = {h["instrument_id"]: h for h in db.fetch_all(
        "SELECT i.id AS instrument_id, i.name AS instrument_name, i.asset_class, i.category FROM instruments i WHERE i.id = ANY(%s)",
        ([r["instrument_id"] for r in rows],))} if rows else {}
    eq = Decimal(0); per = []
    for r in rows:
        meta = full.get(r["instrument_id"], {})
        b, share = alpha.bucket_of({**meta, "instrument_name": r.get("name")})
        v = _d(r["worth"])
        e = v * share if b == "equity" else Decimal(0)
        eq += e
        per.append({"instrument_id": r["instrument_id"], "name": r.get("name"), "bucket": b, "worth": str(v.quantize(Decimal("1"))),
                    "equity_part": str(e.quantize(Decimal("1")))})
    eq_pct = (eq / worth * 100) if worth > 0 else Decimal(0)
    gap = eq_pct - target_eq
    monthly = _d(g.get("monthly"))

    steps = [{"years_left": f, "equity_pct": str(p)} for f, p in PATH]
    nxt = _next_step(years, td)

    instruction = None; kind = "on path"
    if worth > 0 and abs(gap) > BAND:
        over_rupees = (gap / 100 * worth)
        if gap > 0:
            kind = "too much equity"
            if years < MOVE_WHEN_UNDER_YEARS or monthly <= 0 or (over_rupees / max(monthly, Decimal(1))) > 24:
                # Starving it would take years it does not have: move the excess.
                pool = sorted([p for p in per if p["bucket"] == "equity" and _d(p["equity_part"]) > 0], key=lambda p: -_d(p["equity_part"]))
                into = []
                try:
                    into = restructure.options_for("glide", ["Short Duration", "Corporate Bond"], limit=2)
                except Exception:
                    pass
                moves, left = [], over_rupees
                for p in pool:
                    if left < SMALLEST:
                        break
                    v = min(_d(p["equity_part"]), left)
                    moves.append({"instrument_id": p["instrument_id"], "name": p["name"], "amount": str(v.quantize(Decimal("1"))),
                                  "side": "sell", "into": into})
                    left -= v
                instruction = {"kind": "move", "amount": str(over_rupees.quantize(Decimal("1"))), "moves": moves,
                               "say": (f"{_money(over_rupees)} of this goal's equity moves to short-duration debt now. "
                                       f"{years:.1f} years is not long enough to let the contributions do it, and a bad year "
                                       f"this close to the date is the one this money cannot absorb. The tax on each sale is "
                                       f"shown before you agree.")}
            else:
                months_to_fix = (over_rupees / monthly)
                instruction = {"kind": "redirect", "amount": str(over_rupees.quantize(Decimal("1"))),
                               "say": (f"This goal holds {eq_pct:.0f}% equity against {target_eq:.0f}% for {years:.1f} years out. "
                                       f"Nothing is sold: the {_money(monthly)} a month goes to short-duration debt until the "
                                       f"weight is right — about {months_to_fix:.0f} months. New money first; a sale only if the "
                                       f"date gets closer than that.")}
        else:
            kind = "too little equity"
            under = abs(over_rupees)
            instruction = {"kind": "redirect", "amount": str(under.quantize(Decimal("1"))),
                           "say": (f"This goal holds {eq_pct:.0f}% equity against {target_eq:.0f}% for {years:.1f} years out — "
                                   f"safer than it needs to be, which over {years:.0f} years costs more than it protects. "
                                   f"The {_money(monthly)} a month goes to the equity core until the weight is right"
                                   + (f" — about {(under / monthly):.0f} months." if monthly > 0 else ". Set a monthly and the page will say how long."))}

    return {
        "drawable": True, "goal_id": goal_id, "name": g["name"], "years_left": years, "target_date": g["target_date"],
        "worth": str(worth.quantize(Decimal("1"))), "equity_pct": str(eq_pct.quantize(Decimal("0.1"))),
        "target_equity_pct": str(target_eq), "gap_pts": str(gap.quantize(Decimal("0.1"))), "band_pts": str(BAND),
        "state": kind, "instruction": instruction, "path": steps, "next_step": nxt, "holdings": per,
        "reading": (instruction["say"] if instruction else
                    (f"This goal holds {eq_pct:.0f}% equity against {target_eq:.0f}% for {years:.1f} years out — on its path. "
                     + (f"The next step down is {nxt['on']}, to {nxt['equity_pct']}% equity; the page will say so then." if nxt else
                        "It is in its last year: nothing here should be in equity, and nothing is."))
                    if worth > 0 else "Nothing is earmarked to this goal yet, so there is no mix to glide."),
        "principle": ("A step path by years left — 70% equity beyond ten years, down to none in the last year. "
                      "Closed from new money first: the goal's own monthly goes to the short bucket. Only inside three "
                      "years, or when the contributions could not do it in time, is anything moved."),
    }


def flags(investor_id: str) -> list[dict]:
    """Goals off their path, for the daily watch."""
    from . import goals
    out = []
    try:
        allg = goals.all_for(investor_id)
    except Exception:
        return out
    for g in allg.get("goals") or []:
        if g.get("reached"):
            continue
        try:
            r = for_goal(g["id"])
        except Exception as err:
            log.info("glide failed for %s: %s", g["id"], err)
            continue
        ins = r.get("instruction")
        if not ins:
            continue
        out.append({"kind": "glide", "severity": "act" if ins["kind"] == "move" else "note",
                    "fingerprint": f"glide:{g['id']}:{r['state'].replace(' ', '_')}",
                    "what": f"{g['name']}: {r['state']} for {r['years_left']:.1f} years out",
                    "why": ins["say"], "size": _d(ins["amount"]), "detail": {"goal_id": g["id"], "instruction": ins}})
    return out
