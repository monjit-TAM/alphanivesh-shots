"""Goals: what somebody is saving towards.

The decision persists; the position is computed every time.

What the goal is, what it costs, when it is needed, in which currency, which
holdings are earmarked to it and what is committed monthly — those are things
a person chose and they do not drift.

What those holdings are worth today, how many years remain, and where the
rupee is — those are facts about today, computed fresh and never stored.

That split is what lets the plan absorb what happens without being forgetful.
When it says "you were comfortable in March and you are tight now", it can name
the cause rather than showing a different number.

**No projection lives here.** Whether somebody will get there is answered by
the replay engine from what actually happened, not by compounding an assumed
rate. This module does the bookkeeping.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db
from . import earmarks

log = logging.getLogger("alphanivesh.goals")

KINDS = {
    "retirement": "Retirement",
    "home": "A home",
    "education": "Education",
    "wedding": "A wedding",
    "vehicle": "A vehicle",
    "emergency": "Money set aside",
    "travel": "Travel",
    "business": "A business",
    "growth": "Just growth",
    "other": "Something else",
}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("\u20B9" if not negative else "-\u20B9") + digits


def create(investor_id: str, **fields: Any) -> dict:
    kind = fields.get("kind") or "other"
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {', '.join(KINDS)}")

    name = (fields.get("name") or "").strip() or KINDS[kind]
    target = _d(fields.get("target_amount"))
    when = fields.get("target_date")

    if target <= 0:
        raise ValueError("How much will it need?")
    if not when:
        raise ValueError("When is it needed?")
    if str(when) <= str(date.today()):
        raise ValueError("That date has passed.")

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO goal (investor_id, kind, name, why, target_amount,
                              currency, target_date, tolerance_pct)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (investor_id, kind, name, fields.get("why"), target,
             (fields.get("currency") or "INR").upper(), when,
             _d(fields.get("tolerance_pct")))).fetchone()

    goal_id = row["id"]

    monthly = _d(fields.get("monthly"))
    if monthly > 0:
        commit(goal_id, monthly, fields.get("step_up_pct") or 0)

    return one(goal_id) or {}


def commit(goal_id: str, monthly: Any, step_up_pct: Any = 0) -> None:
    """What somebody is putting in each month.

    The previous commitment is ended rather than overwritten. Somebody who
    stopped contributing in March is a different situation from somebody who
    never started, and only the history tells them apart.
    """
    with db.connection() as conn:
        conn.execute(
            "UPDATE goal_contribution SET ended_on = current_date "
            "WHERE goal_id = %s AND ended_on IS NULL", (goal_id,))
        conn.execute(
            """
            INSERT INTO goal_contribution (goal_id, monthly, step_up_pct)
            VALUES (%s, %s, %s)
            """,
            (goal_id, _d(monthly), _d(step_up_pct)))


def one(goal_id: str) -> Optional[dict]:
    """A goal and where it stands, computed now."""
    row = db.fetch_one(
        """
        SELECT g.*,
               (SELECT monthly FROM goal_contribution c
                 WHERE c.goal_id = g.id AND c.ended_on IS NULL) AS monthly,
               (SELECT step_up_pct FROM goal_contribution c
                 WHERE c.goal_id = g.id AND c.ended_on IS NULL) AS step_up_pct
        FROM goal g WHERE g.id = %s
        """,
        (goal_id,))
    if not row:
        return None

    held = earmarks.holdings_for(goal_id)
    worth = _d(held["worth"])
    target = _d(row["target_amount"])

    years_left = (row["target_date"] - date.today()).days / 365.25
    months_left = max(0, int(years_left * 12))

    # In rupees, where the goal is in something else. Marked as today's rate
    # rather than presented as the cost, because it is not the cost -- it is
    # what the cost would be if the rate never moved again.
    target_inr, rate = _in_rupees(target, row["currency"])

    covered = (worth / target_inr * 100) if target_inr else Decimal(0)

    return {
        "id": row["id"],
        "kind": row["kind"],
        "kind_name": KINDS.get(row["kind"], row["kind"]),
        "name": row["name"],
        "why": row["why"],
        "target_amount": str(target.quantize(Decimal("1"))),
        "currency": row["currency"],
        "target_in_inr": str(target_inr.quantize(Decimal("1"))),
        "fx_rate": str(rate) if rate else None,
        "fx_note": (None if row["currency"] == "INR" else
                    f"{row['currency']} {target:,.0f} at the latest fixing. What it "
                    f"costs in rupees depends on where the rupee is when you "
                    f"need it, which is a second thing that can move."),
        # What the rupee has done over stretches this long, and the rupee
        # figure worth planning around. Only for goals in another currency.
        "currency_view": _currency_view(target, row["currency"], row["target_date"]),
        "target_date": row["target_date"].isoformat(),
        "months_left": months_left,
        "years_left": round(years_left, 1),
        "earmarked": held,
        "worth": str(worth.quantize(Decimal("1"))),
        "covered_pct": str(covered.quantize(Decimal("0.1"))),
        "still_needed": str(max(Decimal(0), target_inr - worth)
                            .quantize(Decimal("1"))),
        "monthly": str(_d(row["monthly"]).quantize(Decimal("1"))),
        "step_up_pct": str(_d(row["step_up_pct"]).quantize(Decimal("0.1"))),
        "tolerance_pct": str(_d(row["tolerance_pct"]).quantize(Decimal("0.1"))),
        "reached": bool(row["reached_at"]),
        "mismatch": earmarks.mismatch(goal_id),
        "reading": _reading(row["name"], worth, target_inr, months_left),
    }


def _currency_view(target: Decimal, currency: str, when: date) -> Optional[dict]:
    """currency.for_goal, guarded: a missing rate must not take the goal down."""
    if (currency or "INR").upper() == "INR":
        return None
    try:
        from . import currency as fx
        return fx.for_goal(target, currency, when)
    except Exception as err:
        log.warning("currency view failed for %s: %s", currency, err)
        return {"foreign": True, "currency": currency,
                "why_no_rate": "The exchange-rate service could not be reached."}


def _in_rupees(amount: Decimal, currency: str) -> tuple[Decimal, Optional[str]]:
    """A foreign cost at today's rate, and the rate.

    Today's rate is not a forecast and is not treated as one anywhere else in
    the module -- the replay uses the rate at the end of each historical
    window. This is only so somebody can see roughly what they are looking at.
    """
    if (currency or "INR").upper() == "INR":
        return amount, None

    try:
        from . import dataservice
        rate = _d(dataservice.fx_rate(currency, "INR"))
        if rate > 0:
            return amount * rate, str(rate.quantize(Decimal("0.01")))
    except Exception as err:
        log.warning("no rate for %s: %s", currency, err)

    return amount, None


def _reading(name: str, worth: Decimal, target: Decimal, months: int) -> str:
    if target <= 0:
        return ""

    covered = worth / target * 100
    short = target - worth

    when = (f"{months} month{'s' if months != 1 else ''}" if months < 24
            else f"{months // 12} years")

    if worth >= target:
        return (f"{name} is covered. {_money(worth)} is earmarked against "
                f"{_money(target)} needed in {when}.")

    return (f"{_money(worth)} is earmarked towards {name}, which is "
            f"{covered.quantize(Decimal('0.1'))}% of the {_money(target)} it "
            f"needs in {when}. {_money(short)} short as things stand — what "
            f"that becomes depends on what the money does between now and "
            f"then, which is a separate question.")


def all_for(investor_id: str) -> dict:
    """Every goal, and where the plan as a whole stands.

    Nothing is ranked. Whether retirement matters more than a house is not a
    question a calculation can answer, and a product that answers it has
    substituted its judgement for the person's on the one question that is
    entirely theirs.
    """
    rows = db.fetch_all(
        """
        SELECT id FROM goal
        WHERE investor_id = %s AND abandoned_at IS NULL
        ORDER BY target_date
        """,
        (investor_id,))

    goals = [one(r["id"]) for r in rows]
    goals = [g for g in goals if g]

    committed = sum((_d(g["monthly"]) for g in goals), Decimal(0))
    needed = sum((_d(g["still_needed"]) for g in goals), Decimal(0))
    earmarked = sum((_d(g["worth"]) for g in goals), Decimal(0))

    return {
        "goals": goals,
        "count": len(goals),
        "committed_monthly": str(committed.quantize(Decimal("1"))),
        "still_needed": str(needed.quantize(Decimal("1"))),
        "earmarked": str(earmarked.quantize(Decimal("1"))),
        "unassigned": earmarks.unassigned(investor_id),
        "mismatches": earmarks.mismatches(investor_id),
    }
