"""The moment before an order: what it costs, and what the record says.

Betterment shows the tax before any sale; Kuvera shows the short-term units
and the exit load before you transact; Zerodha's order-window nudges halved
penny-stock volume. Nobody in India does both at once, and nobody puts the
drawdown base rate in front of somebody who is selling into a fall. That is
the whole of the behavioural lever -- the one Vanguard values at 150 basis
points a year -- and it costs a few lines on the consent screen.

`for_orders` returns, per sell, the tax and load on the exact lots as we
know them, a "wait N days and save ₹X" alternative where one exists, and --
when the index is well below its high -- what has followed moments like this
one. It never blocks. It says, and the person decides.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

log = logging.getLogger(__name__)

STCG_RATE = Decimal(20)      # equity, listed, < 12 months
LTCG_RATE = Decimal("12.5")  # equity, listed, > 12 months, above the exemption
LTCG_EXEMPT = Decimal(125000)
DEBT_SLAB = Decimal(30)      # debt funds bought after Apr 2023: slab; assume top slab, say so
WAIT_WORTH = Decimal(1000)   # below this, "wait" is not worth saying
FALL_WORTH_MENTIONING = Decimal(-5)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def _one(order: dict, pos: Optional[dict], room_left: Decimal) -> tuple[dict, Decimal]:
    """Tax and load on one sell, and the exemption room it uses."""
    if not pos:
        return {"known": False,
                "why": "We do not hold a purchase date or cost for this holding, so the tax on selling it cannot be counted here."}, room_left

    value = _d(pos["value"])
    amount = _d(order.get("amount")) or value
    fraction = min(Decimal(1), amount / value) if value > 0 else Decimal(1)
    gain = _d(pos["gain"]) * fraction
    equity_like = pos["asset_class"] in ("equity", "etf") or (
        pos["asset_class"] == "mutual_fund" and not (pos.get("debt_like")))
    months = int(pos["months_held"])
    long_term = bool(pos["long_term"])
    to_lt = int(pos["months_to_long_term"])

    tax = Decimal(0); rate = None; uses_room = Decimal(0); basis = ""
    if gain <= 0:
        basis = f"Sold at a loss of {_money(abs(gain))}: no tax, and the loss offsets gains this year or carries forward for eight."
    elif not equity_like:
        rate = DEBT_SLAB
        tax = gain * rate / 100
        basis = f"Debt: {_money(gain)} of gain is taxed at your slab — about {_money(tax)} at the top slab."
    elif long_term:
        uses_room = min(gain, room_left)
        taxable = gain - uses_room
        rate = LTCG_RATE
        tax = taxable * rate / 100
        basis = (f"Long-term: {_money(gain)} of gain"
                 + (f", {_money(uses_room)} of it inside this year's tax-free allowance" if uses_room > 0 else "")
                 + (f", {_money(taxable)} taxed at 12.5% — {_money(tax)}." if taxable > 0 else " — no tax."))
    else:
        rate = STCG_RATE
        tax = gain * rate / 100
        basis = f"Short-term ({months} months): {_money(gain)} of gain taxed at 20% — {_money(tax)}."

    out = {"known": True, "held_months": months, "long_term": long_term, "gain": str(gain.quantize(Decimal("1"))),
           "rate_pct": str(rate) if rate is not None else None, "tax": str(tax.quantize(Decimal("1"))),
           "uses_exemption": str(uses_room.quantize(Decimal("1"))), "basis": basis}

    # The alternative: wait for the line.
    if equity_like and not long_term and gain > 0 and to_lt > 0:
        lt_tax = max(Decimal(0), gain - room_left) * LTCG_RATE / 100
        saving = tax - lt_tax
        if saving >= WAIT_WORTH:
            days = to_lt * 30
            out["wait"] = {"days": days, "saves": str(saving.quantize(Decimal("1"))),
                           "say": f"Waiting about {days} days makes this long-term and saves roughly {_money(saving)}."}

    # Exit load: we do not hold each scheme's schedule, so this is a flag, not a figure.
    if pos["asset_class"] == "mutual_fund" and months < 12:
        out["exit_load"] = {"likely": True,
                            "say": "Held under a year: most equity funds charge a 1% exit load on this — about "
                                   f"{_money(amount * Decimal('0.01'))} here. Check the scheme page."}
    return out, room_left - uses_room


def for_orders(investor_id: str, orders: list[dict]) -> dict:
    """The interception block for a consent screen."""
    from . import harvest, market

    sells = [o for o in orders if str(o.get("side") or "").lower() == "sell"]
    if not sells:
        return {"applies": False}

    try:
        positions = {p["instrument_id"]: p for p in harvest.positions(investor_id)}
    except Exception as err:
        log.info("positions unavailable: %s", err)
        positions = {}
    # Debt-like funds: the asset class says mutual_fund; the name says what it is.
    for p in positions.values():
        n = (p.get("name") or "").lower()
        p["debt_like"] = any(w in n for w in ("debt", "bond", "liquid", "gilt", "money market", "overnight",
                                                 "short duration", "corporate", "credit", "banking & psu", "floater"))

    room = LTCG_EXEMPT
    lines, total_tax, total_wait_saving = [], Decimal(0), Decimal(0)
    for o in sells:
        block, room = _one(o, positions.get(o.get("instrument_id")), room)
        block["instrument_id"] = o.get("instrument_id"); block["name"] = o.get("name")
        lines.append(block)
        total_tax += _d(block.get("tax"))
        total_wait_saving += _d((block.get("wait") or {}).get("saves"))

    moment = None
    try:
        ctx = market.context()
        if ctx.get("readable"):
            off = _d(ctx["position"]["off_peak_pct"])
            f = ctx.get("followed") or {}
            if off <= FALL_WORTH_MENTIONING and f.get("countable"):
                moment = {
                    "off_peak_pct": str(off), "windows": f["windows"], "positive_pct": f["positive_pct"],
                    "median_pct": f["median_pct"], "unlucky_tenth_pct": f["unlucky_tenth_pct"],
                    "say": (f"You are selling with the index {abs(off):.1f}% below its high. On the {f['windows']} days in our "
                            f"record when it sat about here, twelve months later it was higher {f['positive_pct']}% of the time "
                            f"(median {f['median_pct']}%, unlucky tenth {f['unlucky_tenth_pct']}%). If these sells are the plan's — "
                            f"a weak holding, a bucket over target — the moment does not change them. If they are because of the "
                            f"fall, the record says the fall is the reason not to."),
                }
    except Exception as err:
        log.info("market context unavailable: %s", err)

    reading = (f"Tax on these sells as we count it: {_money(total_tax)}."
               + (f" Waiting on the short-term ones would save about {_money(total_wait_saving)}." if total_wait_saving >= WAIT_WORTH else "")
               + " The figures assume you have realised no other gains this year; a sale elsewhere uses the same allowance.")
    return {"applies": True, "sells": lines, "total_tax": str(total_tax.quantize(Decimal("1"))),
            "wait_saves": str(total_wait_saving.quantize(Decimal("1"))), "moment": moment, "reading": reading,
            "what_this_is": "Said before you agree, not after. None of it stops the order; it is what it costs and what the record says."}
