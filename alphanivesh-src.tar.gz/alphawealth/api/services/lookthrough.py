"""Look-through: what the money is actually in, company by company.

Morningstar calls it Stock Intersection; Aladdin builds its whole risk model
on it. Somebody holding Reliance directly at 6% and four funds that each hold
it at 8% does not own 6% of Reliance -- they own something nearer 12%, and no
statement they receive will tell them. Every Indian app that shows "overlap"
shows either a category-based guess or one pair of funds; none adds the
direct holding and every fund's weight into one figure per company.

This does, from the disclosures we hold:

  exposure    per company: direct + through each fund (fund value x weight,
              normalised by what the disclosure covers), as rupees and as a
              share of the portfolio
  matrix      every pair of equity funds: the share of the smaller fund
              already held by the larger (min-weight overlap)
  verdict     the company exposures past a line, and the fund pairs past a
              line, each said once with what to do

Two guards learned the hard way in sector_exposure: pin each scheme to its
latest disclosure (several months on record multiply everything), and attach
at most one identity per constituent (ISIN first, then a cleaned name).
"""

from __future__ import annotations

import logging
import re
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

COMPANY_WATCH_PCT = Decimal(8)        # one company above this share of the investable portfolio is said
FUND_PAIR_WATCH_PCT = Decimal(40)     # a pair of funds this alike is said
MIN_WEIGHT = Decimal("0.5")           # constituents below this are noise
PAIR_MIN_DUPLICATED = Decimal(50000)  # a pair is said only if this many rupees are the same bet twice...
PAIR_MIN_DUPLICATED_PCT = Decimal(1)  # ...or 1% of the portfolio, whichever is larger
WEIGHT_SUM_MIN, WEIGHT_SUM_MAX = Decimal(70), Decimal(115)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 10000000:
        return f"₹{v / 10000000:.2f} crore"
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


# Lines in a disclosure that are not a company: cash, repo, current assets, debt,
# derivatives and catch-alls. They stay in each fund's weight total (they are
# part of the fund) but never appear as an exposure.
_NOT_A_COMPANY = re.compile(
    r"\b(treps|tri-?party|repo|reverse repo|cblo|cash|net current|current assets|receivables|payables|margin|"
    r"t-?bill|treasury bill|government of india|goi|state development|sdl|g-?sec|gilt|certificate of deposit|"
    r"commercial paper|debenture|ncd|bond|futures?|options?|others?|other equities|mutual fund units|"
    r"liquid fund|overnight fund|unclassified)\b", re.I)


def _is_company(isin: str, name: str) -> bool:
    isin = (isin or "").strip().upper()
    if isin.startswith("INE") or isin.startswith("US") or isin.startswith("IE"):
        # Indian equity ISINs carry a security-type code; anything that is not
        # an equity share (debt, CP, CD) is not a company exposure here.
        if isin.startswith("INE") and len(isin) == 12 and isin[7:9] not in ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"):
            return False
        return not _NOT_A_COMPANY.search(name or "")
    return not _NOT_A_COMPANY.search(name or "")


_SUFFIX = re.compile(r"\b(limited|ltd\.?|corporation|corp\.?|inc\.?|& co\.?|company)\b", re.I)


def _clean(name: str) -> str:
    n = _SUFFIX.sub("", name or "")
    return re.sub(r"[^a-z0-9]+", " ", n.lower()).strip()


def for_investor(investor_id: str) -> dict:
    from . import alpha, wealth
    everything = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    holdings = [h for h in everything if alpha.bucket_of(h)[0] != "outside"]
    total = sum(_d(h["current_value"]) for h in holdings)
    if total <= 0:
        return {"readable": False, "why": "Nothing held to look through yet."}

    # Directly held shares, keyed by ISIN where we have it.
    direct_rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.current_value, i.isin, i.symbol, i.name
        FROM v_current_holdings v JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'equity' AND v.current_value > 0
        """, (investor_id,))

    funds = [h for h in holdings if (h.get("asset_class") or "") in ("mutual_fund", "etf")
             and alpha.bucket_of(h)[0] == "equity"]
    fund_ids = [f["instrument_id"] for f in funds]
    cons = db.fetch_all(
        """
        WITH latest AS (
            SELECT scheme_code, max(as_of) AS as_of FROM scheme_constituents GROUP BY scheme_code
        )
        SELECT i.id AS instrument_id, c.scheme_code, c.as_of, c.isin, c.instrument_name, c.symbol, c.weight_pct
        FROM instruments i
        JOIN latest l ON l.scheme_code = i.native_code
        JOIN scheme_constituents c ON c.scheme_code = l.scheme_code AND c.as_of = l.as_of
        WHERE i.id = ANY(%s) AND c.weight_pct >= %s
        """, (fund_ids, MIN_WEIGHT)) if fund_ids else []

    by_fund: dict[str, dict[str, Decimal]] = {}
    as_of: dict[str, str] = {}
    names: dict[str, str] = {}
    for r in cons:
        key = (r["isin"] or "").strip().upper() or "N:" + _clean(r["instrument_name"])
        by_fund.setdefault(r["instrument_id"], {})
        by_fund[r["instrument_id"]][key] = by_fund[r["instrument_id"]].get(key, Decimal(0)) + _d(r["weight_pct"])
        as_of[r["instrument_id"]] = r["as_of"].isoformat()
        nm = (r["instrument_name"] or "").strip()
        if nm and (key not in names or len(nm) < len(names[key])):
            names[key] = nm

    # Drop disclosures whose weights do not add up; they would distort every share.
    usable = {}
    for fid, w in by_fund.items():
        s = sum(w.values())
        if WEIGHT_SUM_MIN <= s <= WEIGHT_SUM_MAX:
            usable[fid] = (w, s)

    exposure: dict[str, dict] = {}

    def add(key: str, name: str, rupees: Decimal, via: str, how: str) -> None:
        e = exposure.setdefault(key, {"key": key, "name": name, "direct": Decimal(0), "through": Decimal(0), "via": []})
        if how == "direct":
            e["direct"] += rupees
        else:
            e["through"] += rupees
        e["via"].append({"name": via, "rupees": rupees, "how": how})

    for r in direct_rows:
        key = (r["isin"] or "").strip().upper() or "N:" + _clean(r["name"])
        nm = names.get(key) or r["name"]
        names.setdefault(key, nm)
        add(key, nm, _d(r["current_value"]), r["name"], "direct")

    fund_value = {f["instrument_id"]: _d(f["current_value"]) * alpha.bucket_of(f)[1] for f in funds}
    fund_name = {f["instrument_id"]: f.get("instrument_name") for f in funds}
    company_key: dict[str, bool] = {}
    for r in cons:
        key = (r["isin"] or "").strip().upper() or "N:" + _clean(r["instrument_name"])
        company_key[key] = company_key.get(key, True) and _is_company(r["isin"], r["instrument_name"])
    for fid, (weights, wsum) in usable.items():
        v = fund_value.get(fid, Decimal(0))
        for key, w in weights.items():
            if not company_key.get(key, True):
                continue
            add(key, names.get(key, key), v * (w / wsum), fund_name.get(fid) or fid, "fund")

    rows = []
    for e in exposure.values():
        t = e["direct"] + e["through"]
        e["total"] = t
        e["pct"] = t / total * 100
        rows.append(e)
    rows.sort(key=lambda e: -e["total"])

    # The fund-pair matrix.
    pairs = []
    ids = list(usable)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            wa, sa = usable[a]; wb, sb = usable[b]
            shared = {k for k in set(wa) & set(wb) if company_key.get(k, True)}
            if not shared:
                continue
            ov = sum(min(wa[k] / sa * 100, wb[k] / sb * 100) for k in shared)
            top = sorted(shared, key=lambda k: -min(wa[k], wb[k]))[:4]
            smaller = min(fund_value.get(a, Decimal(0)), fund_value.get(b, Decimal(0)))
            dup = smaller * ov / 100
            pairs.append({"a": fund_name.get(a), "b": fund_name.get(b), "overlap_pct": round(float(ov), 1),
                          "shared": len(shared), "top_shared": [names.get(k, k) for k in top],
                          "duplicated": str(dup.quantize(Decimal("1"))), "smaller_value": str(smaller.quantize(Decimal("1"))),
                          "combined": str((fund_value.get(a, 0) + fund_value.get(b, 0)).quantize(Decimal("1")))})
    # Ranked by rupees duplicated, not by percentage: two funds 50% alike where
    # the smaller is ₹3,000 is not a finding; 30% alike at ₹5 lakh each is.
    pairs.sort(key=lambda p: -_d(p["duplicated"]))

    covered = sum(fund_value.get(f, Decimal(0)) for f in usable)
    uncovered = [fund_name.get(f["instrument_id"]) for f in funds if f["instrument_id"] not in usable]
    equity_total = sum(_d(r["current_value"]) for r in direct_rows) + sum(fund_value.values())
    seen_equity = sum(_d(r["current_value"]) for r in direct_rows) + covered

    heavy = [e for e in rows if e["pct"] >= COMPANY_WATCH_PCT]
    dup_floor = max(PAIR_MIN_DUPLICATED, total * PAIR_MIN_DUPLICATED_PCT / 100)
    twins = [p for p in pairs if p["overlap_pct"] >= float(FUND_PAIR_WATCH_PCT) and _d(p["duplicated"]) >= dup_floor]
    hidden = [e for e in rows[:15] if e["direct"] > 0 and e["through"] > e["direct"] * Decimal("0.25")]

    say = []
    if heavy:
        e = heavy[0]
        say.append(f"{e['name']} is {e['pct']:.1f}% of everything you hold — {_money(e['total'])}"
                   + (f", {_money(e['direct'])} directly and {_money(e['through'])} through {len([v for v in e['via'] if v['how'] == 'fund'])} funds"
                      if e["direct"] > 0 and e["through"] > 0 else "")
                   + ". One company at that size is a bet whether or not it was meant as one.")
    elif rows:
        say.append(f"The largest single company exposure is {rows[0]['name']} at {rows[0]['pct']:.1f}% — no one company dominates.")
    if hidden and not heavy:
        e = hidden[0]
        say.append(f"You hold {e['name']} directly ({_money(e['direct'])}), and your funds add another {_money(e['through'])} you may not have counted.")
    if twins:
        p = twins[0]
        say.append(f"{p['a']} and {p['b']} are {p['overlap_pct']:.0f}% the same portfolio — about {_money(p['duplicated'])} of your "
                   f"money is the same bet held twice ({', '.join(p['top_shared'][:3])} among {p['shared']} shared companies). "
                   f"Holding both spreads less than holding one and something different.")
    elif pairs:
        say.append(f"No pair of your funds duplicates enough money to matter; the most is {_money(pairs[0]['duplicated'])}, "
                   f"between {pairs[0]['a']} and {pairs[0]['b']}.")

    def out(e: dict) -> dict:
        via = sorted(e["via"], key=lambda v: -v["rupees"])
        return {"name": e["name"], "total": str(e["total"].quantize(Decimal("1"))), "pct": str(e["pct"].quantize(Decimal("0.01"))),
                "direct": str(e["direct"].quantize(Decimal("1"))), "through": str(e["through"].quantize(Decimal("1"))),
                "via": [{"name": v["name"], "rupees": str(v["rupees"].quantize(Decimal("1"))), "how": v["how"]} for v in via[:6]]}

    return {
        "readable": True,
        "total": str(total.quantize(Decimal("1"))),
        "companies": [out(e) for e in rows[:25]],
        "company_count": len(rows),
        "top10_pct": str(sum((e["pct"] for e in rows[:10]), Decimal(0)).quantize(Decimal("0.1"))),
        "pairs": pairs[:12],
        "heavy": [out(e) for e in heavy],
        "twins": twins,
        "coverage": {"equity_seen_pct": str((seen_equity / equity_total * 100).quantize(Decimal("0.1"))) if equity_total else "0",
                     "funds_read": len(usable), "funds_not_read": [u for u in uncovered if u],
                     "disclosures": sorted(set(as_of.values()))},
        "reading": " ".join(say) if say else "Not enough of the equity can be read through to say anything yet.",
        "principle": ("Each fund's value spread across its latest disclosed holdings by weight, added to the shares you hold "
                      "directly, company by company. Disclosures are monthly and a month or two old; a fund whose disclosure "
                      "does not add up is left out and named, rather than guessed."),
    }


def watch_events(investor_id: str) -> list[dict]:
    try:
        L = for_investor(investor_id)
    except Exception as err:
        log.info("lookthrough failed for %s: %s", investor_id, err)
        return []
    if not L.get("readable"):
        return []
    evs = []
    for e in L["heavy"][:2]:
        evs.append({"kind": "lookthrough", "severity": "note", "fingerprint": f"lookthrough:company:{_clean(e['name'])[:40]}",
                    "what": f"{e['name']} is {_d(e['pct']):.1f}% of everything you hold",
                    "why": (f"{_money(e['direct'])} directly and {_money(e['through'])} through your funds. "
                            f"New equity money is the cheapest way to dilute it — no sale, no tax — and a fund that does not hold it is the place for that money."),
                    "size": _d(e["total"]), "detail": e})
    for p in L["twins"][:1]:
        evs.append({"kind": "lookthrough", "severity": "note", "fingerprint": f"lookthrough:pair:{_clean(p['a'])[:20]}:{_clean(p['b'])[:20]}",
                    "what": f"Two funds {p['overlap_pct']:.0f}% the same",
                    "why": f"{p['a']} and {p['b']} share {p['shared']} companies at weight. One of them is doing the other's job.",
                    "size": _d(p["combined"]), "detail": p})
    return evs
