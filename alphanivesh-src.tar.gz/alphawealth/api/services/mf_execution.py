"""Placing mutual-fund orders: from a consent the person gave to an order the
rail carries, and the record of both.

The sequence is strict and the order of it is the point:

  1. The consent is claimed FIRST (consent.claim). It is marked used in the
     same statement that reads it, so a consent can become at most one order,
     and an expired or withdrawn one becomes none. No rail call happens before
     this succeeds.
  2. The order is created on the rail in its pending state.
  3. The person's consent is attached to it (FP's own confirmation step). What
     FP receives is the email and mobile the person gave us, which is what
     their KYC carries.
  4. For a purchase, a payment is raised and the person is sent to complete it
     -- the money moves from their bank to the AMC's collection account. It
     never touches ours (§3.2 of the agreement, and the law).
  5. The state is refreshed on demand, and the venue_order row is what the
     ledger, the dashboard and any dispute read.

If step 2 or 3 fails, the consent is already spent. That is deliberate: a
consent that could be retried against the rail is one that could be placed
twice. The person gives it again, from the screen, with the failure shown.

v1 places purchases and redemptions. A fund switch reaches us as a sell and a
buy (placing.py's one-instruction-per-holding), which is right for the
person's screen; whether a same-AMC pair should go as one mf_switch is a
refinement for after the sandbox has shown us its shapes.
"""

from __future__ import annotations

import json
import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db
from . import consent as consent_service
from . import fp

log = logging.getLogger("alphanivesh.mf_execution")


def _d(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value)) if value is not None else Decimal(0)


def _json(obj: Any) -> str:
    return json.dumps(obj, default=str)[:20000]


# ---------------------------------------------------------------------------
# The link: who this investor is on the rail
# ---------------------------------------------------------------------------

def link_for(investor_id: str) -> Optional[dict]:
    row = db.fetch_one("SELECT * FROM mf_link WHERE investor_id = %s", (investor_id,))
    return dict(row) if row else None


def link(investor_id: str, *, pan: str, account_number: str, ifsc: str,
         holder_name: Optional[str] = None) -> dict:
    """Create the investor on the rail, once. PAN and bank details are sent
    and not stored; only the rail's ids for them come back to us.

    Name, date of birth, email and mobile come from what we already hold. If
    any is missing this refuses rather than sending a half-profile that FP
    would reject in a less helpful way.
    """
    if not fp.configured():
        raise fp.NotConfigured("The fund rail is not configured on this server.")

    existing = link_for(investor_id)
    if existing and existing.get("account_ref"):
        return {"linked": True, "already": True, **_public(existing)}

    who = db.fetch_one(
        "SELECT display_name, email, phone, date_of_birth, pan_last4 "
        "FROM investors WHERE id = %s", (investor_id,))
    if not who:
        raise ValueError("No such investor.")
    missing = [k for k in ("display_name", "email", "phone", "date_of_birth") if not who[k]]
    if missing:
        raise ValueError("Before an investor can transact we need their "
                         + ", ".join(m.replace("_", " ") for m in missing) + ".")
    pan = (pan or "").strip().upper()
    if len(pan) != 10:
        raise ValueError("That does not look like a PAN.")
    if who["pan_last4"] and who["pan_last4"].upper() != pan[-4:]:
        raise ValueError("That PAN does not match the one on this investor's record.")

    profile = fp.create_investor_profile(
        name=who["display_name"], pan=pan,
        date_of_birth=who["date_of_birth"].isoformat(),
        email=who["email"], mobile=who["phone"])
    profile_ref = profile.get("id")

    bank = fp.create_bank_account(
        profile_ref=profile_ref, account_number=account_number, ifsc=ifsc,
        holder_name=holder_name or who["display_name"])
    account = fp.create_investment_account(profile_ref=profile_ref)

    kyc = None
    try:
        kyc = fp.kyc_status(profile_ref)
    except fp.RailError as err:
        log.info("kyc status not available yet for %s: %s", investor_id, err)

    db.fetch_one(
        """
        INSERT INTO mf_link (investor_id, venue, environment, profile_ref, bank_ref,
                             account_ref, kyc_state, meta)
        VALUES (%s, 'fp', %s, %s, %s, %s, %s, %s::jsonb)
        ON CONFLICT (investor_id) DO UPDATE SET
            profile_ref = EXCLUDED.profile_ref, bank_ref = EXCLUDED.bank_ref,
            account_ref = EXCLUDED.account_ref, kyc_state = EXCLUDED.kyc_state,
            meta = EXCLUDED.meta, updated_at = now()
        RETURNING investor_id
        """,
        (investor_id, fp.ENV, profile_ref, bank.get("id"), account.get("id"),
         _kyc_state(kyc), _json({"profile": profile, "bank": bank, "account": account,
                                 "kyc": kyc})))
    return {"linked": True, "already": False, **_public(link_for(investor_id) or {})}


def _kyc_state(kyc: Any) -> Optional[str]:
    if isinstance(kyc, dict):
        data = kyc.get("data") or kyc
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            return data.get("status") or data.get("state")
    return None


def _public(row: dict) -> dict:
    return {"investor_id": row.get("investor_id"), "venue": row.get("venue"),
            "environment": row.get("environment"), "kyc_state": row.get("kyc_state"),
            "linked_at": row["linked_at"].isoformat() if row.get("linked_at") else None,
            "can_transact": bool(row.get("account_ref"))}


# ---------------------------------------------------------------------------
# Placing
# ---------------------------------------------------------------------------

def place(consent_id: str, *, user_ip: Optional[str] = None,
          return_url: Optional[str] = None) -> dict:
    """One consent -> one rail order. See the module note for why the consent
    is spent before the rail is touched."""
    if not fp.configured():
        raise fp.NotConfigured("The fund rail is not configured on this server.")

    # Which order this is, from the consent row itself (never from the caller).
    row = db.fetch_one(
        "SELECT c.*, i.isin, i.asset_class::text AS asset_class "
        "FROM order_consent c LEFT JOIN instruments i ON i.id = c.instrument_id "
        "WHERE c.id = %s", (consent_id,))
    if not row:
        raise ValueError("No such consent.")
    if not row["isin"]:
        raise ValueError("That holding has no ISIN on record, so the fund rail "
                         "cannot identify it. Add the ISIN to the instrument first.")
    if row["asset_class"] and "fund" not in row["asset_class"]:
        raise ValueError("That is not a mutual fund; it goes through a broker, not this rail.")

    who = link_for(row["investor_id"])
    if not who or not who.get("account_ref"):
        raise ValueError("This investor is not linked to the fund rail yet.")
    person = db.fetch_one("SELECT email, phone FROM investors WHERE id = %s",
                          (row["investor_id"],))

    # 1. Spend the consent. The order id we mint is the order_ref it records.
    order_id = db.fetch_one("SELECT gen_random_uuid()::text AS id")["id"]
    claimed = consent_service.claim(consent_id, f"venue_order:{order_id}")
    if not claimed:
        raise ValueError("That consent has expired, been used, or been withdrawn. "
                         "Nothing was placed.")

    kind = "purchase" if row["side"] == "buy" else "redemption"
    amount = _d(row["amount"])
    units = _d(row["quantity"])
    db.fetch_one(
        """
        INSERT INTO venue_order (id, investor_id, consent_id, venue, environment, kind,
                                 instrument_id, isin, amount, units, state)
        VALUES (%s, %s, %s, 'fp', %s, %s, %s, %s, %s, %s, 'created') RETURNING id
        """,
        (order_id, row["investor_id"], consent_id, fp.ENV, kind, row["instrument_id"],
         row["isin"], amount if amount > 0 else None, units if units > 0 else None))

    # 2. Create on the rail.
    try:
        if kind == "purchase":
            if amount <= 0:
                raise ValueError("A fund purchase needs a rupee amount.")
            made = fp.create_purchase(account_ref=who["account_ref"], isin=row["isin"],
                                      amount=amount, user_ip=user_ip)
        else:
            made = fp.create_redemption(account_ref=who["account_ref"], isin=row["isin"],
                                        amount=amount if amount > 0 else None,
                                        units=units if units > 0 else None, user_ip=user_ip)
        external = made.get("id")
        _update(order_id, state=fp.our_state(made.get("state") or "pending"),
                external_ref=external, payload=made)

        # 3. Attach the person's consent.
        confirmed = fp.confirm(kind, external, email=person["email"], mobile=person["phone"])
        _update(order_id, state=fp.our_state(confirmed.get("state") or "confirmed"),
                payload=confirmed)

        # 4. Purchases need money to move. Redemptions do not.
        payment = None
        if kind == "purchase":
            payment = fp.pay(order_refs=[made.get("old_id") or external],
                             bank_ref=who["bank_ref"], return_url=return_url)
            _update(order_id, payment_ref=payment.get("id"), payload=payment)

    except (fp.RailError, ValueError) as err:
        _update(order_id, state="failed", error=str(err))
        raise ValueError(f"The order could not be placed: {err}. The consent you "
                         f"gave has been spent; to try again, give it again from "
                         f"the screen.")

    return {**one(order_id), "payment": _payment_public(payment)}


def _payment_public(payment: Optional[dict]) -> Optional[dict]:
    if not payment:
        return None
    return {"id": payment.get("id"), "status": payment.get("status") or payment.get("state"),
            "pay_at": payment.get("token_url") or payment.get("url") or payment.get("redirect_url"),
            "amount": payment.get("amount")}


def _update(order_id: str, **fields: Any) -> None:
    payload = fields.pop("payload", None)
    sets, vals = ["updated_at = now()"], []
    for k, v in fields.items():
        sets.append(f"{k} = %s"); vals.append(v)
    if payload is not None:
        sets.append("last_payload = %s::jsonb"); vals.append(_json(payload))
    if fields.get("state") in ("settled", "failed", "cancelled", "reversed"):
        sets.append("settled_at = now()")
    db.fetch_one(f"UPDATE venue_order SET {', '.join(sets)} WHERE id = %s RETURNING id",
                 tuple(vals + [order_id]))


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def one(order_id: str) -> dict:
    row = db.fetch_one(
        "SELECT v.*, i.name AS instrument_name FROM venue_order v "
        "LEFT JOIN instruments i ON i.id = v.instrument_id WHERE v.id = %s", (order_id,))
    if not row:
        raise ValueError("No such order.")
    return _row_public(dict(row))


def _row_public(r: dict) -> dict:
    return {
        "id": r["id"], "investor_id": r["investor_id"], "consent_id": r.get("consent_id"),
        "venue": r["venue"], "environment": r["environment"], "kind": r["kind"],
        "instrument_id": r.get("instrument_id"), "name": r.get("instrument_name"),
        "isin": r.get("isin"), "to_isin": r.get("to_isin"),
        "amount": str(r["amount"]) if r.get("amount") is not None else None,
        "units": str(r["units"]) if r.get("units") is not None else None,
        "external_ref": r.get("external_ref"), "state": r["state"],
        "open": r["state"] in fp.OPEN_STATES,
        "payment_ref": r.get("payment_ref"), "error": r.get("error"),
        "created_at": r["created_at"].isoformat(),
        "updated_at": r["updated_at"].isoformat(),
        "settled_at": r["settled_at"].isoformat() if r.get("settled_at") else None,
    }


def refresh(order_id: str) -> dict:
    """Ask the rail where the order is now."""
    row = db.fetch_one("SELECT kind, external_ref, state FROM venue_order WHERE id = %s",
                       (order_id,))
    if not row:
        raise ValueError("No such order.")
    if not row["external_ref"]:
        return one(order_id)
    try:
        got = fp.fetch(row["kind"], row["external_ref"])
    except fp.RailError as err:
        log.warning("refresh %s: %s", order_id, err)
        return {**one(order_id), "refresh_error": str(err)}
    _update(order_id, state=fp.our_state(got.get("state")), payload=got,
            error=(got.get("failure_reason") or got.get("error") or None))
    return one(order_id)


def for_investor(investor_id: str, limit: int = 50) -> list[dict]:
    rows = db.fetch_all(
        "SELECT v.*, i.name AS instrument_name FROM venue_order v "
        "LEFT JOIN instruments i ON i.id = v.instrument_id "
        "WHERE v.investor_id = %s ORDER BY v.created_at DESC LIMIT %s",
        (investor_id, limit))
    return [_row_public(dict(r)) for r in rows]
