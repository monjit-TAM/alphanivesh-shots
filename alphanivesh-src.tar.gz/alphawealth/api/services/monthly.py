"""The monthly letter: what the engine watched, what the plan earned, what is next.

The Alpha Clock promised it and nothing sent it. Once a month, for each
person who chose a monthly rhythm or has placed orders through the plan,
one short letter in the adviser's voice:

  what crossed a line this month, and what cleared
  what the plan's moves earned this month and this year, losers included
  what your own hands cost (churn), if anything
  where next month's money goes, if a monthly contribution is set
  the one line from the long record that matters this month

A month with nothing in it says so in one paragraph -- that is the letter,
not an absence of one. It never goes twice in a calendar month.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v); sign = "−" if v < 0 else ""; v = abs(v)
    if v >= 10000000:
        return f"{sign}₹{v / 10000000:.2f} crore"
    if v >= 100000:
        return f"{sign}₹{v / 100000:.1f} lakh"
    return f"{sign}₹{v:,.0f}"


def _month_bounds(on: date) -> tuple[date, date, str]:
    first_this = date(on.year, on.month, 1)
    last_prev = first_this - timedelta(days=1)
    first_prev = date(last_prev.year, last_prev.month, 1)
    return first_prev, first_this, first_prev.strftime("%B %Y")


def letter_for(investor_id: str, on: Optional[date] = None) -> dict:
    """The letter for the month just ended."""
    from . import discipline, goals, nextmoney, realised, regime, wealth
    on = on or date.today()
    start, end, label = _month_bounds(on)
    inv = wealth.get_investor(investor_id) or {}
    first = ((inv.get("display_name") or "there").split() or ["there"])[0]
    first = first.title() if (first.isupper() or first.islower()) else first

    sections: list[dict] = []

    # 1. The watch.
    opened = db.fetch_all(
        "SELECT kind, severity, what FROM watch_event WHERE investor_id = %s AND opened_at >= %s AND opened_at < %s ORDER BY opened_at",
        (investor_id, start, end))
    cleared = db.fetch_all(
        "SELECT what FROM watch_event WHERE investor_id = %s AND resolved_at >= %s AND resolved_at < %s",
        (investor_id, start, end))
    still = db.fetch_all(
        "SELECT what FROM watch_event WHERE investor_id = %s AND resolved_at IS NULL AND severity = 'act' ORDER BY opened_at",
        (investor_id,))
    if opened or cleared or still:
        acts = [o["what"] for o in opened if o["severity"] == "act"]
        text = (f"The daily check ran every trading day in {label}. "
                + (f"{len(opened)} thing{'s' if len(opened) != 1 else ''} crossed a line"
                   + (f", {len(acts)} worth acting on: " + "; ".join(acts[:3]) + "." if acts else ", none of them needing an order.")
                   if opened else "Nothing new crossed a line.")
                + (f" {len(cleared)} cleared — stopped being true, because you acted or the market moved." if cleared else "")
                + (f" Still open and worth acting on: " + "; ".join(s["what"] for s in still[:3]) + "." if still else ""))
    else:
        text = (f"The daily check ran every trading day in {label} and nothing crossed a line. "
                f"That is the most common month, and the right response to it is to leave things alone.")
    sections.append({"head": "What I watched", "text": text})

    # 2. The ledger.
    try:
        L = realised.ledger(investor_id)
    except Exception:
        L = {"count": 0}
    if L.get("count"):
        month_alpha = sum((_d(m["alpha"]) for m in L["moves"] if m.get("alpha") and start.isoformat() <= m["placed_on"] < end.isoformat()), Decimal(0))
        sections.append({"head": "What the plan earned", "text": (
            f"Across the {L['count']} move{'s' if L['count'] != 1 else ''} placed through the plan, {L['won']} are ahead of what "
            f"they replaced and {L['lost']} behind. Net this financial year: {_money(L['by_period']['this_year'])}; since the start: "
            f"{_money(L['by_period']['since_start'])}."
            + (f" Moves placed in {label} have earned {_money(month_alpha)} so far." if month_alpha else "")
            + " Each is marked against the path the money would have taken; the losers are counted with the winners.")})

    # 3. Your hands.
    try:
        D = discipline.meter(investor_id, months=1)
    except Exception:
        D = {}
    if D.get("measurable", True) and (_d((D.get("churn") or {}).get("cost")) > 0 or D.get("unplanned_sales")):
        sections.append({"head": "What your own hands cost", "text": D.get("reading", "")})

    # 4. Next month's money.
    try:
        committed = _d(goals.all_for(investor_id).get("committed_monthly"))
    except Exception:
        committed = Decimal(0)
    if committed >= 1000:
        try:
            N = nextmoney.plan(investor_id, committed, "monthly")
            if N.get("ready"):
                sections.append({"head": "Where next month's money goes", "text": N["reading"]})
        except Exception as err:
            log.info("next money failed for %s: %s", investor_id, err)

    # 5. The long record, one line.
    try:
        P = regime.panel()
        dp = next((p for p in P.get("permits") or [] if p["permit"] == "deployment"), {})
        held = [r for r in P.get("readings") or [] if (r.get("replay") or {}).get("stable") and abs(_d((r.get("replay") or {}).get("edge_pct"))) >= 2]
        line = (f"New money goes in {'at once' if dp.get('value') == 'at once' else 'over twelve monthly instalments'} this month. "
                + (f"Of the readings from the long record, {len(held)} carr{'y' if len(held) != 1 else 'ies'} an edge that held in both halves of the history; "
                   f"none of them moves the plan beyond the pace." if held else "No reading from the long record carries an edge that held out of sample."))
        sections.append({"head": "The market, from the long record", "text": line})
    except Exception:
        pass

    nothing = len(sections) <= 2 and not opened and not still and not L.get("count")
    subject = (f"{label}: " + (f"{len(still)} thing{'s' if len(still) != 1 else ''} to act on" if still else
                               "a quiet month" if nothing else "your monthly letter"))
    return {"investor_id": investor_id, "month": label, "to_name": first, "subject": f"AlphaNivesh — {subject}",
            "sections": sections, "quiet": nothing}


def as_html(L: dict) -> str:
    from . import mail
    body = f"<p>{L['to_name']},</p>"
    for s in L["sections"]:
        body += (f"<p style='margin:18px 0 4px;font-weight:700'>{s['head']}</p>"
                 f"<p style='margin:0;color:#33302C;line-height:1.6'>{s['text']}</p>")
    try:
        body += mail.button("Open your plan", "https://alphanivesh.com/alpha.html")
    except Exception:
        body += "<p><a href='https://alphanivesh.com/alpha.html'>Open your plan</a></p>"
    body += ("<p style='color:#8A8178;font-size:12px;margin-top:20px'>Base rates, not forecasts. The adviser of record owns "
             "the advice; nothing is placed without your agreement to each order. Prefer to hear quarterly or yearly instead? "
             "Choose how often on your profile page — urgent things still reach you either way.</p>")
    return mail.wrap(body, preheader=L["sections"][0]["text"][:120] if L["sections"] else "")


def as_text(L: dict) -> str:
    return f"{L['to_name']},\n\n" + "\n\n".join(f"{s['head'].upper()}\n{s['text']}" for s in L["sections"]) + \
           "\n\nOpen your plan: https://alphanivesh.com/alpha.html\n"


def sent_this_month(address: str, on: Optional[date] = None) -> bool:
    on = on or date.today()
    row = db.fetch_one(
        "SELECT 1 FROM mail_log WHERE lower(to_address) = lower(%s) AND kind = 'monthly_letter' AND sent "
        "AND at >= %s LIMIT 1", (address, date(on.year, on.month, 1)))
    return bool(row)


def who_gets_it() -> list[str]:
    rows = db.fetch_all(
        """
        SELECT DISTINCT i.id FROM investors i
        LEFT JOIN contact_preference c ON c.investor_id = i.id
        WHERE EXISTS (SELECT 1 FROM v_current_holdings v WHERE v.investor_id = i.id AND v.current_value > 0)
          AND (c.paused_until IS NULL OR c.paused_until < current_date)
          -- Everyone who has not chosen a slower rhythm (no preference row = never
          -- asked), plus anyone who has placed orders through the plan whatever
          -- they chose: they are owed the ledger report.
          AND (c.investor_id IS NULL OR c.cadence = 'monthly'
               OR EXISTS (SELECT 1 FROM order_consent o WHERE o.investor_id = i.id AND o.used_at IS NOT NULL))
        """)
    return [r["id"] for r in rows]
