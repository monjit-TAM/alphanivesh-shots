"""Your next ₹10,000: where new money should go, across everything held.

The benchmark's ninth gap: "a single 'what should my next ₹10,000 do?' engine
across all asset classes is absent." Every app answers it inside its own
shelf -- a fund app says which fund, a gold app says gold. This answers it
over the whole position, and it answers it the same way the plan does,
because it is the plan's own arithmetic applied to new money:

  1. The liquid cushion first, if it is short. Nothing else is safe without it.
  2. A goal off its glide path that the money can fix (soonest first): its
     short bucket gets the money it needs, and the money is earmarked to it.
  3. The buckets furthest under target, in proportion to how far under they
     are -- equity, debt, gold.
  4. Inside equity: the large/flexi core while it is short of its share;
     otherwise the segment furthest under its target.
  5. Nothing under target: the target mix itself, so the position stays put.

New money is the cheapest rebalancing there is -- no sale, no tax, no exit
load -- which is why the plan sends it to the gaps before it ever sells.
The regime panel sets the pace for a lump sum: at once only where the long
record says buying at once has beaten instalments; otherwise in twelve
monthly instalments from a liquid fund.
"""

from __future__ import annotations

import logging
from decimal import Decimal, ROUND_DOWN
from typing import Any, Optional

log = logging.getLogger(__name__)

STEP = Decimal(500)                 # amounts are rounded down to this
MIN_LINE = Decimal(1000)            # below this a line is folded into the largest one
STAGGER_ABOVE = Decimal(100000)     # a lump this size or more is staggered unless the regime says otherwise
CUSHION_SHARE = Decimal("0.5")      # at most this share of new money goes to an unbuilt cushion


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def _round(v: Decimal) -> Decimal:
    return (v / STEP).quantize(Decimal(1), rounding=ROUND_DOWN) * STEP


FILLS = {
    "cash":   (["Liquid"], "a liquid fund", {}),
    "debt":   (["Corporate Bond", "Short Duration"], "a short-duration or corporate bond fund", {}),
    "gold":   (["Gold", "Fund of Fund", "Other Scheme"], "a gold fund or ETF", {"name_must_have": ("gold",)}),
    "large":  (["Large Cap", "Flexi Cap"], "a large or flexi-cap fund — the core", {}),
    "mid":    (["Mid Cap", "Large & Mid Cap"], "a mid-cap fund", {}),
    "small":  (["Small Cap"], "a small-cap fund", {}),
}


def _candidates(key: str) -> list[dict]:
    from . import restructure
    cats, _, kw = FILLS[key]
    try:
        return restructure.options_for("next", cats, limit=2, **kw)
    except Exception as err:
        log.info("no candidates for %s: %s", key, err)
        return []


def plan(investor_id: str, amount: Any, mode: str = "lump") -> dict:
    from . import alpha, glide, goals, wealth
    amount = _d(amount)
    if amount < MIN_LINE:
        return {"ready": False, "why": f"Give an amount of at least {_money(MIN_LINE)}."}
    mode = "monthly" if mode == "monthly" else "lump"

    everything = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    holdings = [h for h in everything if alpha.bucket_of(h)[0] != "outside"]
    target = alpha.target_for(investor_id)
    now = alpha.current_mix(holdings) if holdings else None
    total = (now["total"] if now else Decimal(0))
    after_total = total + amount

    lines: list[dict] = []
    left = amount

    def take(key: str, rupees: Decimal, why: str, *, goal: Optional[dict] = None) -> None:
        nonlocal left
        rupees = min(left, rupees)
        if rupees <= 0:
            return
        bucket = key if key in ("cash", "debt", "gold") else "equity"
        lines.append({"key": key, "bucket": bucket, "amount": rupees, "label": FILLS[key][1], "why": why,
                      "goal": goal})
        left -= rupees

    # 1. The cushion.
    if now:
        cash_short = _d(target["cash_pct"]) / 100 * after_total - now["cash"]
        if cash_short > MIN_LINE:
            # Half the money, at most, until the cushion is built. All of it would
            # leave every other gap untouched for months; none of it would leave
            # the household one bad month from selling at the wrong time.
            part = min(cash_short, amount * CUSHION_SHARE)
            months = (cash_short / part) if part > 0 else 0
            take("cash", part, (f"Your liquid cushion is {_money(cash_short)} short of its {_d(target['cash_pct']):.0f}% target. "
                                f"Half of new money goes there until it is built"
                                + (f" — about {months:.0f} {'months' if mode == 'monthly' else 'contributions'} at this rate" if months > 1.05 else "")
                                + ". It is what lets everything else sit through a bad month."))

    # 2. Goals off their glide path that new money can fix.
    try:
        gl = sorted((g for g in (goals.all_for(investor_id).get("goals") or []) if not g.get("reached")),
                    key=lambda g: float(g.get("years_left") or 99))
    except Exception:
        gl = []
    for g in gl:
        if left < MIN_LINE:
            break
        try:
            r = glide.for_goal(g["id"])
        except Exception:
            continue
        ins = r.get("instruction") or {}
        if ins.get("kind") != "redirect":
            continue
        need = _d(ins.get("amount"))
        key = "debt" if r.get("state") == "too much equity" else "large"
        take(key, min(need, left / 2), (f"{g['name']} is {r['state']} for {float(r['years_left']):.1f} years out. "
                                        f"Money that goes here is earmarked to it, and moves its mix toward "
                                        f"{r['target_equity_pct']}% equity without selling anything."),
             goal={"id": g["id"], "name": g["name"]})

    # 3. Buckets under target, in proportion to how far under.
    if now and left >= MIN_LINE:
        shorts = {}
        for b in ("equity", "debt", "gold"):
            already = sum((l["amount"] for l in lines if l["bucket"] == b), Decimal(0))
            gap = _d(target[f"{b}_pct"]) / 100 * after_total - now[b] - already
            if gap > 0:
                shorts[b] = gap
        pool = left
        gap_total = sum(shorts.values(), Decimal(0))
        for b, gap in sorted(shorts.items(), key=lambda kv: -kv[1]):
            share = min(gap, pool * gap / gap_total) if gap_total > 0 else Decimal(0)
            if b == "equity":
                _equity(take, share, now, target, after_total, lines)
            else:
                pct = _d(target[f"{b}_pct"])
                take(b, share, f"{b.title()} is {now[f'{b}_pct']:.0f}% of the investable money against a {pct:.0f}% target. "
                               f"Filling it with new money costs nothing; filling it by selling would cost tax.")

    # 4/5. Whatever is left: the target mix itself.
    if left >= MIN_LINE:
        rest = left
        for b in ("equity", "debt", "gold"):
            share = rest * _d(target[f"{b}_pct"]) / (100 - _d(target["cash_pct"]))
            if b == "equity":
                _equity(take, share, now, target, after_total, lines, on_target=True)
            else:
                take(b, share, f"Everything is on target, so new money goes in the target's own proportions — "
                               f"{_d(target[f'{b}_pct']):.0f}% to {b}.")

    # Tidy: round, fold small lines into the largest, attach candidates.
    merged: dict[tuple, dict] = {}
    for l in lines:
        k = (l["key"], (l["goal"] or {}).get("id"))
        if k in merged:
            merged[k]["amount"] += l["amount"]
        else:
            merged[k] = dict(l)
    out = sorted(merged.values(), key=lambda l: -l["amount"])
    small = [l for l in out if l["amount"] < MIN_LINE]
    out = [l for l in out if l["amount"] >= MIN_LINE]
    if out and small:
        out[0]["amount"] += sum((l["amount"] for l in small), Decimal(0))
    for l in out:
        l["amount"] = _round(l["amount"])
    out = [l for l in out if l["amount"] > 0]
    spare = amount - sum((l["amount"] for l in out), Decimal(0))
    if out and spare > 0:
        out[0]["amount"] += spare
    for l in out:
        l["into"] = _candidates(l["key"])
        l["amount"] = str(l["amount"])

    # Pace, for a lump sum.
    pace = None
    if mode == "lump" and amount >= STAGGER_ABOVE and any(l["bucket"] == "equity" for l in out):
        try:
            from . import regime
            permits = {p["permit"]: p for p in (regime.panel().get("permits") or [])}
            dp = permits.get("deployment") or {}
        except Exception:
            dp = {}
        if dp.get("value") == "at once":
            pace = {"how": "at once", "why": dp.get("why")}
        else:
            eq = sum((_d(l["amount"]) for l in out if l["bucket"] == "equity"), Decimal(0))
            pace = {"how": "staggered",
                    "why": (f"The equity part ({_money(eq)}) goes into a liquid fund today and moves across in twelve "
                            f"monthly instalments of about {_money(eq / 12)}. "
                            + (dp.get("why") or "It costs little against lump sum on the record, and it is the one people finish."))}

    eq_after = (now["equity"] if now else 0) + sum((_d(l["amount"]) for l in out if l["bucket"] == "equity"), Decimal(0))
    reading = (f"{_money(amount)}{' a month' if mode == 'monthly' else ''}: "
               + "; ".join(f"{_money(l['amount'])} into {l['label']}" + (f" for {l['goal']['name']}" if l.get("goal") else "") for l in out)
               + ". "
               + (f"Afterwards equity is {eq_after / after_total * 100:.0f}% against a {_d(target['equity_pct']):.0f}% target. " if after_total else "")
               + "No sale, no tax: new money is the cheapest way to move the mix.")
    return {
        "ready": True, "amount": str(amount), "mode": mode, "lines": out, "pace": pace, "reading": reading,
        "target": {k: str(target[k]) for k in ("equity_pct", "debt_pct", "gold_pct", "cash_pct")},
        "principle": ("The plan's own arithmetic applied to new money: the cushion first, then a goal off its glide path, "
                      "then the buckets furthest under target, the large-cap core first inside equity. When nothing is "
                      "under target the money goes in the target's own proportions."),
    }


def _equity(take, share: Decimal, now: Optional[dict], target: dict, after_total: Decimal, lines: list, on_target: bool = False) -> None:
    """Equity money split by segment: the core while it is short, else the segment furthest under."""
    if share <= 0:
        return
    wt = target["within_equity"]
    if not now:
        take("large", share, "The core of the equity target goes in first.")
        return
    already_eq = sum((l["amount"] for l in lines if l["bucket"] == "equity"), Decimal(0))
    eq_after = now["equity"] + already_eq + share
    we = now["within_equity"]
    segs = {}
    for seg in ("large", "mid", "small"):
        have = _d(we.get(f"{seg}_value")) + sum((l["amount"] for l in lines if l["key"] == seg), Decimal(0))
        want = _d(wt[f"{seg}_pct"]) / 100 * eq_after
        if want > have:
            segs[seg] = want - have
    if not segs:
        take("large", share, "Equity segments are on target; the core takes it.")
        return
    gap_total = sum(segs.values(), Decimal(0))
    for seg, gap in sorted(segs.items(), key=lambda kv: -kv[1]):
        part = share * gap / gap_total
        if seg == "large":
            why = (f"Large-cap is {_d(we['large_pct']):.0f}% of your equity against {_d(wt['large_pct']):.0f}%. "
                   f"The core is filled first; it is what holds when the rest falls.")
        else:
            why = (f"{seg.title()}-cap is {_d(we[f'{seg}_pct']):.0f}% of your equity against {_d(wt[f'{seg}_pct']):.0f}%.")
        if on_target:
            why = "Everything is on target, so equity money keeps the segments where they are. " + why
        take(seg, part, why)
