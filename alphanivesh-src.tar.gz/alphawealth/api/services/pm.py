"""The Portfolio Manager's desk.

AlphaNivesh as a virtual portfolio manager: every asset class the client
holds is reviewed the way a fund manager reviews a book -- what it is doing,
whether each holding still earns its place, whether something better is
available after tax and cost, and exactly what to do and how. The client
keeps the final word on every order; that is what moves the manager's power
to them rather than replacing one manager with another.

The allocation brain is the alpha plan (target mix, barriers, moves). This
desk adds the security-level judgement, drawn from AlphaVerse's own research
so that one instrument reads the same in every product:

  shares          AlphaMarket's verdict engine; the topped test for legacy winners;
                  look-through concentration
  equity funds    AlphaLensMF fund DNA (what the fund actually owns, scored),
                  forward outlook (tailwinds and headwinds in the book), category
                  rank on the rolling record -- and an upgrade test: is there a
                  materially better fund in the same role, and does the
                  difference repay the tax of switching within three years?
  ETFs            the chooser's pick for the role, and the hidden cost: how far
                  the price strays from NAV
  debt            duration against when the money is needed; what is locked
  gold            weight against its job; SGBs held to maturity
  cash            the cushion
  protection      cover against need, judged against the IRDAI standard term
                  product; ULIPs and endowments read for surrender

Every action carries its "how": the route (your broker, the fund rail, the
insurer), the timing (now, after N days, in instalments), and the tax.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

UPGRADE_PAYBACK_YEARS = Decimal(3)     # an upgrade is worth saying only if the edge repays the tax this fast
UPGRADE_MIN_EDGE = Decimal("1.5")      # rolling 3-year median, percentage points a year
LTCG_EXEMPT = Decimal(125000)
CLUTTER_BELOW = Decimal(25000)         # a fund holding smaller than this does no job on its own
THEME_WATCH_PCT = Decimal(40)          # one sector above this share of directly held shares is a theme bet
STRETCH_PE, STRETCH_ROE = Decimal(80), Decimal(12)   # priced for perfection: very high P/E on modest returns
ROLE_WORDS = ("small", "mid", "large", "flexi", "multi", "value", "contra", "focused", "elss", "tax saver",
              "dividend yield", "index", "international", "global", "sectoral", "thematic", "hybrid", "balanced")


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v); sign = "−" if v < 0 else ""; v = abs(v)
    if v >= 10000000:
        return f"{sign}₹{v / 10000000:.2f} crore"
    if v >= 100000:
        return f"{sign}₹{v / 100000:.1f} lakh"
    return f"{sign}₹{v:,.0f}"


def _safe(fn, *a, default=None, **kw):
    try:
        return fn(*a, **kw)
    except Exception as err:
        log.info("%s failed: %s", getattr(fn, "__name__", fn), err)
        return default


ROUTES = {
    "equity": "through your own broker — a basket you confirm in your account",
    "etf": "through your own broker, with a limit price at or near NAV",
    "mutual_fund": "through the fund rail to the AMC, paid from your bank to the fund house",
    "insurance": "directly from the insurer — AlphaNivesh does not sell insurance",
}


# ---------------------------------------------------------------------------
# Equity funds: DNA, outlook, rank, and the upgrade test
# ---------------------------------------------------------------------------

def _outlook_tally(outlook: dict) -> dict:
    drivers = outlook.get("drivers") or []
    tail = [d for d in drivers if d.get("direction") == "tailwind"]
    head = [d for d in drivers if d.get("direction") == "headwind"]
    return {"tailwinds": len(tail), "headwinds": len(head),
            "lines": [f"{d.get('driver')}: {d.get('reading')} ({d.get('direction')})" for d in drivers[:5]]}


def _role(category: str, name: str = "") -> frozenset:
    text = f"{category} {name}".lower().replace("&", "and")
    words = {w for w in ROLE_WORDS if w in text}
    if "large and mid" in text:
        words = (words - {"large", "mid"}) | {"large and mid"}
    return frozenset(words)


def _same_role(a_cat: str, a_name: str, b_cat: str, b_name: str) -> bool:
    """An upgrade must do the same job: a small-cap fund is not upgraded to a large-and-midcap one."""
    ra, rb = _role(a_cat, a_name), _role(b_cat, b_name)
    return bool(ra) and ra == rb


def _tax_to_switch(h: dict, pos: Optional[dict]) -> Decimal:
    gain = _d(h.get("current_value")) - _d(h.get("invested_value"))
    if gain <= 0:
        return Decimal(0)
    if pos and not pos.get("long_term"):
        return gain * Decimal("0.20")
    return max(Decimal(0), gain - LTCG_EXEMPT) * Decimal("0.125")


def _fund_review(h: dict, code: Optional[str], category: str, plan_move: Optional[dict], pos: Optional[dict]) -> dict:
    from . import alpha, dataservice, restructure
    name = h.get("instrument_name")
    value = _d(h.get("current_value"))
    row = {"name": name, "value": str(value.quantize(Decimal("1"))), "kind": "fund"}
    if value < CLUTTER_BELOW and not plan_move:
        row.update({"verdict": "consolidate", "facts": [], "upgrade": None, "outlook": None, "how": ROUTES["mutual_fund"],
                    "why": (f"At {_money(value)} this holding is too small to do a job of its own. Redeem it and fold the money "
                            f"into the core fund the plan is buying" + (" (wait out the ELSS lock-in first)." if "elss" in (name or "").lower()
                                                                        or "tax saver" in (name or "").lower() else ".")
                            )})
        return row
    dna = _safe(dataservice.fund_dna, code, default={}) if code else {}
    outlook = _safe(dataservice.forward_outlook, code, default={}) if code else {}
    rank = _safe(alpha._fund_rank, code, category, default=None) if code else None
    tally = _outlook_tally(outlook) if outlook.get("covered") else None
    pos_pct = (_d(rank["rank"]) / _d(rank["of"]) * 100) if rank and rank.get("rank") and rank.get("of") else None

    facts = []
    if dna.get("style"):
        f = dna.get("factors") or {}
        facts.append(f"Owns: {dna['style']} (quality {f.get('quality')}/100, value {f.get('value')}/100; top ten {dna.get('concentration_top10_pct')}%).")
    if rank and pos_pct is not None:
        facts.append(f"Ranks {rank['rank']} of {rank['of']} in its category on the rolling three-year record.")
    if tally:
        facts.append(f"Its book has {tally['tailwinds']} tailwind{'s' if tally['tailwinds'] != 1 else ''} and "
                     f"{tally['headwinds']} headwind{'s' if tally['headwinds'] != 1 else ''} right now.")

    verdict, why, how = "keep", "Earning its place on its own record.", None
    if plan_move:
        verdict = {"sell": "exit", "switch": "switch"}.get(plan_move["kind"], plan_move["kind"])
        why = plan_move["why"]
        how = ROUTES["mutual_fund"]
    elif pos_pct is not None and pos_pct > 50:
        verdict, why = "switch", "In the bottom half of its category; the plan moves it to the top of the category."
        how = ROUTES["mutual_fund"]
    elif tally and tally["headwinds"] >= 2 and (pos_pct or 0) > 33:
        verdict, why = "watch", "Middle of its category with more headwinds than tailwinds in its book; it is read again each quarter."

    # The upgrade test: a materially better fund in the same role, worth the tax.
    upgrade = None
    if verdict in ("keep", "watch") and category and rank and rank.get("roll3_median") is not None:
        best = (_safe(restructure.options_for, "upgrade", [category], limit=1, default=[]) or [None])[0]
        if (best and best.get("code") and str(best["code"]) != str(code)
                and _same_role(category, name or "", best.get("category") or "", best.get("name") or "")):
            edge = _d(best.get("roll3_median")) - _d(rank.get("roll3_median"))
            tax = _tax_to_switch(h, pos)
            gain_a_year = value * edge / 100
            payback = (tax / gain_a_year) if gain_a_year > 0 else None
            if edge >= UPGRADE_MIN_EDGE and (payback is None or payback <= UPGRADE_PAYBACK_YEARS):
                bdna = _safe(dataservice.fund_dna, best["code"], default={})
                upgrade = {"to": best.get("name"), "code": best.get("code"), "edge_pts": str(edge.quantize(Decimal("0.1"))),
                           "tax": str(tax.quantize(Decimal("1"))),
                           "payback_years": str(payback.quantize(Decimal("0.1"))) if payback is not None else "0",
                           "to_style": bdna.get("style"),
                           "say": (f"{best.get('name')} has done {edge:.1f} points a year better over rolling three-year stretches "
                                   f"in the same category" + (f" ({bdna['style']})" if bdna.get("style") else "")
                                   + (f". Switching costs about {_money(tax)} in tax, repaid in {payback:.1f} years at that edge."
                                      if tax > 0 and payback is not None else ". Switching costs no tax.")
                                   + " An upgrade, not a rescue: the current fund is not broken.")}
                verdict, how = "upgrade", ROUTES["mutual_fund"]
                why = upgrade["say"]
    if verdict == "keep" and alpha._is_regular(h):
        verdict, why, how = "switch to direct", "Same fund without the commission; the plan's cost line has the rupees.", ROUTES["mutual_fund"]
    row.update({"verdict": verdict, "why": why, "facts": facts, "how": how, "upgrade": upgrade,
                "outlook": tally})
    return row


# ---------------------------------------------------------------------------
# The desk
# ---------------------------------------------------------------------------

def desk(investor_id: str) -> dict:
    from . import alpha, dataservice, harvest, lookthrough, protection, regime, stress, wealth
    p = alpha.plan(investor_id)
    if not p.get("ready"):
        return {"ready": False, "why": p.get("why")}
    everything = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    total = sum((_d(h["current_value"]) for h in everything), Decimal(0))
    moves_by = {}
    for m in p["moves"]:
        if m.get("instrument_id"):
            moves_by.setdefault(m["instrument_id"], m)
    codes = alpha._instrument_codes([h["instrument_id"] for h in everything])
    positions = {x["instrument_id"]: x for x in (_safe(harvest.positions, investor_id, default=[]) or [])}
    t, c = p["target"], p["current"]
    soonest = _soonest_goal_years(investor_id)

    classes: dict[str, dict] = {}

    def cls(code: str, name: str) -> dict:
        return classes.setdefault(code, {"code": code, "name": name, "value": Decimal(0), "holdings": [], "notes": [], "opportunities": []})

    sells, analysed = {}, {}
    try:
        from . import rebalance_engine
        eng = rebalance_engine.for_investor(investor_id) or {}
        for s_ in eng.get("sell") or []:
            sells[str(s_.get("symbol") or s_.get("stock_name") or "").upper()] = s_
        for a_ in eng.get("holdings") or []:
            analysed[str(a_.get("symbol") or a_.get("stock_name") or "").upper()] = a_
    except Exception:
        pass
    # Fundamentals for directly held shares: sector, valuation, quality.
    from . import analysis
    fund_rows = (_safe(analysis.equity_fundamentals, investor_id, default={}) or {}).get("holdings") or []
    fundamentals = {}
    for r_ in fund_rows:
        for key in (r_.get("symbol"), r_.get("isin")):
            if key:
                fundamentals[str(key).upper()] = r_

    for h in everything:
        b, _ = alpha.bucket_of(h)
        ac = (h.get("asset_class") or "")
        v = _d(h["current_value"])
        mv = moves_by.get(h["instrument_id"])
        meta = codes.get(h["instrument_id"]) or {}
        if b == "outside":
            continue  # protection is reviewed from the policies, below
        if ac == "equity":
            k = cls("shares", "Shares you hold directly")
            sym = str(h.get("symbol") or "").upper()
            if mv:
                verdict, why = ("exit" if "Exit" in mv["what"] or "Sell" in mv["what"] else "trim"), mv["why"]
            elif sym in sells:
                verdict, why = "exit", str(sells[sym].get("reason") or "The verdict engine reads it as reduce.")
            else:
                a_ = analysed.get(sym) or {}
                said = next((str(a_[x]) for x in ("reason", "rationale", "summary", "why") if a_.get(x)), "")
                verdict, why = "keep", (f"AlphaMarket's verdict engine reads it as hold — {said}" if said else
                                        "AlphaMarket's verdict engine reads it as hold.")
            f_ = fundamentals.get(sym) or fundamentals.get(str(h.get("isin") or "").upper()) or {}
            facts = []
            if f_.get("sector"):
                facts.append(f"{f_['sector']}" + (f" · {f_['market_cap_category']}" if f_.get("market_cap_category") else ""))
            if f_.get("pe_ttm") is not None:
                facts.append(f"P/E {_d(f_['pe_ttm']):.0f}" + (f", ROE {_d(f_['roe']):.0f}%" if f_.get("roe") is not None else "")
                             + (f", profit {_d(f_['pat_growth_yoy']):+.0f}% y/y" if f_.get("pat_growth_yoy") is not None else ""))
            if (verdict == "keep" and f_.get("pe_ttm") is not None and f_.get("roe") is not None
                    and _d(f_["pe_ttm"]) >= STRETCH_PE and _d(f_["roe"]) < STRETCH_ROE):
                verdict = "watch"
                why += (f" Kept, but on watch: at {_d(f_['pe_ttm']):.0f} times earnings for a {_d(f_['roe']):.0f}% return on equity "
                        f"it is priced for perfection — a disappointment costs it more than most. Do not add to it; the next "
                        f"verdict that turns makes it a sale.")
            k["holdings"].append({"name": h.get("instrument_name"), "value": str(v.quantize(Decimal("1"))), "kind": "share",
                                  "verdict": verdict, "why": why, "facts": [" · ".join(facts)] if facts else [],
                                  "sector": f_.get("sector"),
                                  "how": ROUTES["equity"] if verdict != "keep" else None,
                                  "wait_days": (mv or {}).get("wait_days")})
        elif b == "equity":
            k = cls("equity_funds", "Equity funds and ETFs")
            k["holdings"].append(_fund_review(h, meta.get("native_code"), meta.get("category") or h.get("category") or "",
                                              mv, positions.get(h["instrument_id"])))
        elif b == "debt":
            k = cls("debt", "Debt — the steady money")
            locked = not alpha_sellable(h)
            dur = stress._duration(h.get("instrument_name") or "", meta.get("category") or "")
            bond = _bond_terms(h.get("instrument_name") or "")
            if bond and not mv:
                yrs = bond["years_left"]
                verdict, why = "hold to maturity", (
                    f"A listed bond paying {bond['coupon']}% that matures on {bond['maturity']} — {yrs:.1f} years from now. "
                    f"Held to maturity the price moves in between do not matter; the risk is the issuer, so the question is "
                    f"how much of your money depends on one borrower, not what rates do.")
                k = cls("debt", "Debt — the steady money")
                k["holdings"].append({"name": h.get("instrument_name"), "value": str(v.quantize(Decimal("1"))), "kind": "bond",
                                      "verdict": verdict, "why": why, "how": None})
                k["value"] += v
                continue
            if locked:
                verdict, why = "keep (locked)", "Provident fund or similar: counted in the mix, never sold. New money routes around it."
            elif mv:
                verdict, why = mv["kind"], mv["why"]
            elif dur >= 5 and soonest is not None and soonest <= 3:
                verdict, why = "shorten", (f"About {dur:.0f} years of duration holding money needed within three years: a rate rise "
                                           f"marks it down just when it is wanted. Move it to short-duration.")
            else:
                verdict, why = "keep", f"Duration about {dur:.1f} years, suited to what it is for."
            k["holdings"].append({"name": h.get("instrument_name"), "value": str(v.quantize(Decimal("1"))), "kind": "debt",
                                  "verdict": verdict, "why": why, "how": None if verdict.startswith("keep") else ROUTES["mutual_fund"]})
        elif b == "gold":
            k = cls("gold", "Gold")
            name = (h.get("instrument_name") or "").lower()
            sgb = ac == "sgb" or "sovereign gold" in name or "sgb" in name
            if mv:
                verdict, why = "trim", mv["why"] + (" Sell the ETF or fund units first; Sovereign Gold Bonds are best held to maturity, where the gain is tax-free." if not sgb else "")
            else:
                verdict, why = "keep", ("Sovereign Gold Bond: held to maturity the gain is tax-free, and it pays 2.5% a year." if sgb
                                        else "Gold at or under its target weight does its job: it holds when equity and the rupee fall together.")
            k["holdings"].append({"name": h.get("instrument_name"), "value": str(v.quantize(Decimal("1"))), "kind": "gold",
                                  "verdict": verdict, "why": why, "how": _route(h, mv or {}) if verdict == "trim" else None})
        elif b == "cash":
            k = cls("cash", "Cash and liquid")
            k["holdings"].append({"name": h.get("instrument_name"), "value": str(v.quantize(Decimal("1"))), "kind": "cash",
                                  "verdict": "keep", "why": "The cushion.", "how": None})
        k["value"] += v

    # Class-level assessments, from the plan's own numbers.
    tgt = {"shares": None, "equity_funds": t["equity_pct"], "debt": t["debt_pct"], "gold": t["gold_pct"], "cash": t["cash_pct"]}
    for code, k in classes.items():
        k["share_pct"] = str((k["value"] / (_d(c["total"]) or 1) * 100).quantize(Decimal("0.1")))
        k["value"] = str(k["value"].quantize(Decimal("1")))
    if "shares" in classes or "equity_funds" in classes:
        eq_note = (f"Equity is {c['equity_pct']}% of what can be moved, against a {t['equity_pct']}% target "
                   f"({c['within_equity']['large_pct']}% large-cap against {t['within_equity']['large_pct']}%).")
        for k in ("shares", "equity_funds"):
            if k in classes:
                classes[k]["notes"].append(eq_note)
    if "shares" in classes:
        sh = classes["shares"]["holdings"]
        tot_sh = sum((_d(x["value"]) for x in sh), Decimal(0))
        by_sector: dict[str, Decimal] = {}
        for x in sh:
            if x.get("sector"):
                by_sector[x["sector"]] = by_sector.get(x["sector"], Decimal(0)) + _d(x["value"])
        if tot_sh > 0 and by_sector:
            top_sector, top_val = max(by_sector.items(), key=lambda kv: kv[1])
            pct = top_val / tot_sh * 100
            names = [x["name"] for x in sh if x.get("sector") == top_sector]
            if pct >= THEME_WATCH_PCT and len(names) >= 2:
                classes["shares"]["theme"] = top_sector
                classes["shares"]["notes"].append(
                    f"{pct:.0f}% of your directly held shares are one theme — {top_sector}: {', '.join(names[:5])}. "
                    f"Each may be fine on its own; together they rise and fall as one bet. New equity money goes to the "
                    f"diversified core rather than adding to it.")
    L = _safe(lookthrough.for_investor, investor_id, default={}) or {}
    if L.get("readable") and "shares" in classes:
        classes["shares"]["notes"].append(L["reading"])
    for b in ("debt", "gold", "cash"):
        if b in classes:
            classes[b]["notes"].append(f"{b.title()} is {c[f'{b}_pct']}% against a {t[f'{b}_pct']}% target.")

    # ETF routes for the roles the plan fills with new equity or gold money.
    chooser = _safe(dataservice.etf_chooser, default={}) or {}
    etf_routes = []
    for a in chooser.get("allocation") or []:
        pick = a.get("pick") or {}
        if not pick.get("symbol") or a.get("bucket") not in ("broad", "gold"):
            continue
        det = _safe(dataservice.etf_detail, pick["symbol"], default={}) or {}
        etf_routes.append({"role": a.get("bucket"), "symbol": pick["symbol"], "name": pick.get("name"),
                           "premium_avg": det.get("premium_avg_pct"), "premium_worst": det.get("premium_worst_pct"),
                           "say": (f"{pick['symbol']} ({pick.get('name')}): {pick.get('receipt', '')}. "
                                   + (f"It has traded {det['premium_avg_pct']}% over NAV on average and up to {det['premium_worst_pct']}% — "
                                      f"buy with a limit near NAV, never at market." if det.get("premium_avg_pct") is not None else ""))})
    if etf_routes and "equity_funds" in classes:
        classes["equity_funds"]["opportunities"].append({
            "kind": "etf_route",
            "say": "For new core money there is a cheaper route than a fund: " + " ".join(r["say"] for r in etf_routes if r["role"] == "broad"),
            "routes": etf_routes})

    # Protection.
    prot = _safe(protection.for_investor, investor_id, default={}) or {}
    pclass = {"code": "protection", "name": "Protection — life and health cover", "holdings": [], "notes": [], "opportunities": []}
    std = _safe(dataservice.insurance_standards, default={}) or {}
    saral = ((std.get("standard_products") or {}).get("saral_jeevan_bima") or {})
    gap = prot.get("gap") or {}
    if gap.get("life_short_by"):
        pclass["notes"].append(f"Life cover is short by {gap['life_short_reads']} against {_money(gap['against'])} needed.")
        pclass["opportunities"].append({"kind": "term_cover", "say": (
            f"Buy pure term cover for the shortfall — {gap['life_short_reads']}. "
            + (f"Judge any quote against {saral.get('name')}: {saral.get('why_it_matters')}" if saral else
               "Judge any quote against the IRDAI standard term product, where only price and claim record differ.")),
            "how": ROUTES["insurance"]})
    if gap.get("health_thin"):
        pclass["notes"].append(f"Health cover is below the {gap.get('health_floor_reads')} floor.")
    for pol in prot.get("policies") or []:
        if pol["kind"] in ("ulip", "endowment") and not (_d(pol.get("premium")) and _d(pol.get("surrender_value"))):
            pclass["holdings"].append({"name": f"{pol['label']} — {pol.get('insurer') or ''}".strip(" —"), "kind": "policy",
                                       "value": "0", "verdict": "needs its numbers",
                                       "why": (f"Cover of {pol.get('cover_reads')}. To say whether to keep or surrender it we need the "
                                               f"annual premium and today's surrender value — both are on the insurer's latest statement. "
                                               f"Add them on the profile page and this becomes a verdict."), "how": None})
            continue
        if pol["kind"] in ("ulip", "endowment"):
            pclass["holdings"].append({"name": f"{pol['label']} — {pol.get('insurer') or ''}".strip(" —"), "kind": "policy",
                                       "value": pol.get("surrender_value") or "0", "verdict": "read for surrender",
                                       "why": (f"Premium {_money(pol.get('premium'))} a year for cover of {pol.get('cover_reads')}. "
                                               f"Compare continuing with surrendering ({_money(pol.get('surrender_value'))} back), buying term "
                                               f"cover for the same amount, and investing the difference."),
                                       "how": ROUTES["insurance"]})
        else:
            pclass["holdings"].append({"name": f"{pol['label']} — {pol.get('insurer') or ''}".strip(" —"), "kind": "policy",
                                       "value": "0", "verdict": "keep", "why": f"Cover of {pol.get('cover_reads')}.", "how": None})
    if not prot.get("recorded"):
        pclass["notes"].append("No policies recorded yet. Add them on the profile page; cover is the first thing a portfolio manager checks.")

    pclass["value"] = str(sum((_d(hh.get("value")) for hh in pclass["holdings"]), Decimal(0)).quantize(Decimal("1")))

    order = ["shares", "equity_funds", "debt", "gold", "cash"]
    out_classes = [classes[k] for k in order if k in classes] + [pclass]

    # The book: the plan's moves plus the desk's upgrades and protection, each with its how.
    book = []
    by_id = {h["instrument_id"]: h for h in everything}
    for m in p["moves"]:
        route = (_route(by_id.get(m.get("instrument_id")), m) if m["kind"] != "harvest" else
                 "sell and buy back the same day wherever each holding sits — your broker for shares, the fund rail for funds")
        timing = ("before 31 March" if m["kind"] == "harvest" else
                  f"after {m['wait_days']} days" if m.get("wait_days") else
                  "in twelve monthly instalments" if m["kind"] == "deploy" and "instal" in m["what"] else "now")
        book.append({"what": m["what"], "amount": m["amount"], "why": m["why"], "how": route, "when": timing,
                     "basis": m.get("alpha_basis")})
    for k in out_classes:
        for hrow in k["holdings"]:
            if hrow.get("upgrade"):
                u = hrow["upgrade"]
                book.append({"what": f"Upgrade {hrow['name']} to {u['to']}", "amount": hrow["value"], "why": u["say"],
                             "how": ROUTES["mutual_fund"], "when": "now, or at the next long-term date if sooner",
                             "basis": "quality: a better fund in the same role, repaid within three years"})
        for o in k["opportunities"]:
            if o["kind"] == "term_cover":
                book.append({"what": "Buy term life cover", "amount": "0", "why": o["say"], "how": o["how"], "when": "now",
                             "basis": "protection: first, before any investing"})
    # The engine's share picks against the theme the shares already carry.
    theme = classes.get("shares", {}).get("theme")
    if theme:
        for b in book:
            if "engine's current picks" in b["what"]:
                m = next((mm for mm in p["moves"] if mm["what"] == b["what"]), {})
                syms = [str(x.get("symbol") or x.get("stock_name") or "").upper() for x in (m.get("into") or []) if isinstance(x, dict)]
                try:
                    rows = db.fetch_all("SELECT symbol, sector FROM company_fundamentals WHERE upper(symbol) = ANY(%s)", (syms,)) if syms else []
                except Exception as err:
                    log.info("pick sectors unavailable: %s", err)
                    rows = []
                same = [r["symbol"] for r in rows if r.get("sector") == theme]
                if same:
                    b["why"] += (f" Note: {', '.join(same)} {'are' if len(same) > 1 else 'is'} in {theme}, the theme your shares already "
                                 f"lean on — take the other picks, or put this money in the diversified core instead.")
    # Fund crumbs: one instruction to consolidate them.
    crumbs = [hh for kk in out_classes for hh in kk["holdings"] if hh.get("verdict") == "consolidate"]
    if crumbs:
        total_c = sum((_d(hh["value"]) for hh in crumbs), Decimal(0))
        elss = [hh["name"] for hh in crumbs if "elss" in (hh["name"] or "").lower() or "tax saver" in (hh["name"] or "").lower()]
        book.append({"what": f"Consolidate {len(crumbs)} small fund holdings ({_money(total_c)}) into the core fund",
                     "amount": str(total_c.quantize(Decimal("1"))),
                     "why": (f"{len(crumbs)} funds of a few thousand rupees each do no job and make every statement harder to read. "
                             f"Redeem them and add the money to the core fund the plan buys."
                             + (f" The ELSS units ({len(elss)}) can only go once their three-year lock-in ends." if elss else "")),
                     "how": ROUTES["mutual_fund"], "when": "now (ELSS when unlocked)",
                     "basis": "simplicity: fewer holdings, each with a job"})
    if any(o["kind"] == "term_cover" for o in pclass["opportunities"]):
        book.insert(0, book.pop(next(i for i, b in enumerate(book) if b["what"] == "Buy term life cover")))

    pace = next((x for x in (_safe(regime.panel, default={}) or {}).get("permits") or [] if x["permit"] == "deployment"), {})
    counts = {}
    for k in out_classes:
        for hrow in k["holdings"]:
            counts[hrow["verdict"]] = counts.get(hrow["verdict"], 0) + 1
    headline = (f"Reviewed {sum(counts.values())} holdings across {len(out_classes)} asset classes. "
                + ", ".join(f"{n} {v}" for v, n in sorted(counts.items(), key=lambda kv: -kv[1]))
                + f". {len(book)} instruction{'s' if len(book) != 1 else ''} in the book, in order.")
    return {
        "ready": True, "as_of": date.today().isoformat(), "headline": headline, "total": str(total.quantize(Decimal("1"))),
        "mandate": {"target": {k: str(t[k]) for k in ("equity_pct", "debt_pct", "gold_pct", "cash_pct")},
                    "current": {k: str(c[k]) for k in ("equity_pct", "debt_pct", "gold_pct", "cash_pct")},
                    "rules": t.get("rules") or []},
        "classes": out_classes,
        "book": book, "pace": {"how": pace.get("value"), "why": pace.get("why")},
        "letter": p.get("reading"),
        "principle": ("A portfolio manager's review, every asset class: what each holding is doing, whether it still earns its "
                      "place, whether something better is available after tax, and exactly what to do and how. The research is "
                      "AlphaVerse's own — AlphaMarket for shares, AlphaLensMF for funds, the ETF and insurance research for the "
                      "rest — so one instrument reads the same everywhere. You approve every order."),
    }


def _bond_terms(name: str) -> Optional[dict]:
    """Coupon and maturity from an exchange bond name like 'IIFLFL 9.60 240628' (DDMMYY)."""
    import re
    m_ = re.search(r"(\d{1,2}\.\d{1,2})\s+(\d{2})(\d{2})(\d{2})\s*$", name.strip())
    if not m_:
        return None
    try:
        mat = date(2000 + int(m_.group(4)), int(m_.group(3)), int(m_.group(2)))
    except ValueError:
        return None
    return {"coupon": m_.group(1), "maturity": mat.strftime("%-d %b %Y"), "years_left": max(0.0, (mat - date.today()).days / 365.25)}


def _route(h: Optional[dict], m: dict) -> str:
    """How an instruction is carried out, from what the holding actually is."""
    ac = ((h or {}).get("asset_class") or m.get("asset_class") or "").lower()
    name = ((h or {}).get("instrument_name") or "").lower()
    if ac == "equity":
        return ROUTES["equity"]
    if ac == "etf" or " etf" in name or "bees" in name:
        return ROUTES["etf"]
    if ac == "sgb" or "sovereign gold" in name:
        return "through your broker on the exchange (Sovereign Gold Bonds trade there), or held to maturity"
    if ac == "gold":
        return "where you hold it — physical gold through a bullion dealer or jeweller at the day's rate; digital gold on its own app"
    return ROUTES["mutual_fund"]


def alpha_sellable(h: dict) -> bool:
    from .rebalance import _sellable
    return _sellable(h)


def _soonest_goal_years(investor_id: str) -> Optional[float]:
    from . import goals
    try:
        gs = [g for g in (goals.all_for(investor_id).get("goals") or []) if not g.get("reached")]
        return min((float(g.get("years_left") or 99) for g in gs), default=None)
    except Exception:
        return None
