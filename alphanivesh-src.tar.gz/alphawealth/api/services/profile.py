"""What we know about the person, and what we cannot say without it.

Two halves. The first stores a profile and goals. The second is the more useful
one: it works out which parts of the analysis are unavailable because something
has not been filled in, and says so in terms of what the person is missing
rather than what the form is missing.

"Complete your profile" tells someone nothing. "We cannot tell you whether you
are on track for retirement because we do not know when you want to retire"
tells them exactly what filling it in buys, and lets them decide whether that
is worth two minutes.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal
from typing import Optional

from .. import db

# Roughly how long money needs to last after work stops. Used only to sanity
# check a retirement goal, never to tell anyone when to retire.
ASSUMED_RETIREMENT_AGE = 60


# ---------------------------------------------------------------------------
# Reading and writing
# ---------------------------------------------------------------------------


def get_profile(investor_id: str) -> Optional[dict]:
    row = db.fetch_one(
        """
        SELECT investor_id, date_of_birth, monthly_income, monthly_expenses,
               dependents, risk_appetite, horizon_years, emergency_fund, notes,
               updated_at
        FROM investor_profiles WHERE investor_id = %s
        """,
        (investor_id,),
    )
    if row and row["date_of_birth"]:
        row["age"] = _age_from(row["date_of_birth"])
    return row


def _age_from(dob: date) -> int:
    today = date.today()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


FIELDS = ("date_of_birth", "monthly_income", "monthly_expenses", "dependents",
          "risk_appetite", "horizon_years", "emergency_fund", "notes")


def save_profile(investor_id: str, values: dict) -> dict:
    """Create or update a profile.

    Only the fields actually supplied are written. Someone correcting their
    income should not have to re-enter everything else, and a partial update
    must not silently blank the rest.
    """
    supplied = {k: v for k, v in values.items() if k in FIELDS and v is not None}
    if not supplied:
        existing = get_profile(investor_id)
        if existing:
            return existing
        supplied = {}

    columns = ", ".join(["investor_id"] + list(supplied))
    placeholders = ", ".join(["%s"] * (len(supplied) + 1))
    updates = ", ".join(f"{k} = EXCLUDED.{k}" for k in supplied) or "updated_at = now()"

    db.fetch_one(
        f"""
        INSERT INTO investor_profiles ({columns}) VALUES ({placeholders})
        ON CONFLICT (investor_id) DO UPDATE SET {updates}
        RETURNING investor_id
        """,
        tuple([investor_id] + list(supplied.values())),
    )
    return get_profile(investor_id)


def list_goals(investor_id: str) -> list[dict]:
    """Live goals from the `goal` table (migration 031), in the shape the
    callers still read: id, kind, name, target_amount, target_date,
    current_amount, monthly_contribution, priority, is_achieved.

    current_amount is what is earmarked to the goal, valued at today's prices
    (the same sum earmarks.holdings_for uses). Goals with no earmark get 0 and
    findings then share the unearmarked portfolio between them."""
    return db.fetch_all(
        """
        SELECT g.id, g.kind, g.name, g.target_amount, g.target_date,
               COALESCE((SELECT SUM(v.current_value * e.share_pct / 100)
                           FROM goal_earmark e
                           JOIN v_current_holdings v
                             ON v.instrument_id = e.instrument_id
                            AND v.investor_id  = e.investor_id
                          WHERE e.goal_id = g.id AND e.removed_at IS NULL
                            AND v.current_value > 0), 0) AS current_amount,
               COALESCE(c.monthly, 0)             AS monthly_contribution,
               g.shown_order                      AS priority,
               (g.reached_at IS NOT NULL)         AS is_achieved
        FROM goal g
        LEFT JOIN goal_contribution c
               ON c.goal_id = g.id AND c.ended_on IS NULL
        WHERE g.investor_id = %s AND g.abandoned_at IS NULL
        ORDER BY (g.reached_at IS NOT NULL), g.shown_order, g.target_date
        """,
        (investor_id,),
    )


_GOAL_KINDS = ("retirement", "home", "education", "wedding", "vehicle",
               "emergency", "travel", "business", "growth", "other")


def _set_contribution(goal_id: str, monthly) -> None:
    db.fetch_one(
        "UPDATE goal_contribution SET ended_on = CURRENT_DATE "
        "WHERE goal_id = %s AND ended_on IS NULL RETURNING id",
        (goal_id,),
    )
    db.fetch_one(
        "INSERT INTO goal_contribution (goal_id, monthly) VALUES (%s, %s) RETURNING id",
        (goal_id, monthly),
    )


def save_goal(investor_id: str, goal: dict, goal_id: Optional[str] = None) -> dict:
    """Old-shape goal in, new tables out. current_amount is ignored: what is
    set aside for a goal is now an earmark on specific holdings."""
    cols: dict = {}
    if goal.get("kind") is not None:
        kind = str(goal["kind"]).lower()
        cols["kind"] = kind if kind in _GOAL_KINDS else "other"
    for k in ("name", "target_amount", "target_date"):
        if goal.get(k) is not None:
            cols[k] = goal[k]
    if goal.get("priority") is not None:
        cols["shown_order"] = int(goal["priority"])
    if goal.get("is_achieved") is not None:
        cols["reached_at"] = "now()" if goal["is_achieved"] else None

    if goal_id:
        if cols:
            sets, vals = [], []
            for k, v in cols.items():
                if k == "reached_at":
                    sets.append("reached_at = " + ("now()" if v else "NULL"))
                else:
                    sets.append(f"{k} = %s"); vals.append(v)
            sets.append("updated_at = now()")
            row = db.fetch_one(
                f"UPDATE goal SET {', '.join(sets)} WHERE id = %s AND investor_id = %s RETURNING id",
                tuple(vals + [goal_id, investor_id]),
            )
        else:
            row = db.fetch_one("SELECT id FROM goal WHERE id = %s AND investor_id = %s",
                               (goal_id, investor_id))
        if row is None:
            raise ValueError("No such goal.")
        if goal.get("monthly_contribution") is not None:
            _set_contribution(goal_id, goal["monthly_contribution"])
        return row

    cols.setdefault("kind", "other")
    cols.setdefault("name", "Untitled goal")
    if not cols.get("target_amount") or not cols.get("target_date"):
        raise ValueError("A goal needs a target amount and a target date.")
    cols.pop("reached_at", None)
    columns = ", ".join(["investor_id"] + list(cols))
    placeholders = ", ".join(["%s"] * (len(cols) + 1))
    row = db.fetch_one(
        f"INSERT INTO goal ({columns}) VALUES ({placeholders}) RETURNING id",
        tuple([investor_id] + list(cols.values())),
    )
    if goal.get("monthly_contribution"):
        _set_contribution(row["id"], goal["monthly_contribution"])
    return row


def delete_goal(investor_id: str, goal_id: str) -> bool:
    """Abandon rather than erase: earmarks and readings stay for the record."""
    row = db.fetch_one(
        "UPDATE goal SET abandoned_at = now(), abandoned_why = 'removed from profile', "
        "updated_at = now() WHERE id = %s AND investor_id = %s AND abandoned_at IS NULL RETURNING id",
        (goal_id, investor_id),
    )
    return row is not None


# ---------------------------------------------------------------------------
# What we cannot tell them, and why
# ---------------------------------------------------------------------------


@dataclass
class Capability:
    """One thing the platform could say, and whether it can say it yet."""
    key: str
    what_you_get: str        # what the person gets, not what the feature is called
    available: bool
    needs: list[str]         # field names, for the interface to highlight
    needs_plain: str         # the same thing said in words

    def as_dict(self) -> dict:
        return asdict(self)


# Each entry is a real analysis and the inputs it genuinely requires. The
# wording is deliberately about the answer rather than the calculation: nobody
# wants "goal alignment analysis", they want to know whether they will have
# enough.
CAPABILITIES = (
    {
        "key": "asset_allocation_fit",
        "what_you_get": "Whether your split between equity and safer assets suits your age",
        "needs": ["date_of_birth"],
        "needs_plain": "your date of birth",
    },
    {
        "key": "risk_fit",
        "what_you_get": "Whether what you hold matches the risk you said you wanted",
        "needs": ["risk_appetite"],
        "needs_plain": "how much risk you are comfortable with",
    },
    {
        "key": "savings_capacity",
        "what_you_get": "How much of what you have spare is actually going in",
        "needs": ["monthly_income", "monthly_expenses"],
        "needs_plain": "your monthly income and expenses",
    },
    {
        "key": "emergency_cover",
        "what_you_get": "Whether you have enough set aside for a bad month",
        "needs": ["monthly_expenses", "emergency_fund"],
        "needs_plain": "your monthly expenses and what you keep aside",
    },
    {
        "key": "goal_shortfall",
        "what_you_get": "Whether you are on track for what you are saving towards, and what it would take",
        "needs": ["goals"],
        "needs_plain": "at least one goal, with an amount and a date",
    },
    {
        "key": "protection_gap",
        "what_you_get": "Whether your life cover is enough for the people who depend on you",
        "needs": ["dependents", "monthly_income"],
        "needs_plain": "how many people depend on you, and your income",
    },
    {
        "key": "horizon_fit",
        "what_you_get": "Whether what you hold suits how long you can leave it alone",
        "needs": ["horizon_years"],
        "needs_plain": "how long you can stay invested",
    },
)


def capabilities(investor_id: str) -> dict:
    """What the analysis can and cannot currently say, and what would unlock it.

    Returned to the interface so that missing information appears as a specific
    absence next to the thing it affects, rather than as a nag to complete a
    form. Someone who does not want to say what they earn should still see
    everything else working.
    """
    profile = get_profile(investor_id) or {}
    goals = list_goals(investor_id)
    has_dated_goal = any(g["target_amount"] and g["target_date"] for g in goals)

    def present(field: str) -> bool:
        if field == "goals":
            return has_dated_goal
        return profile.get(field) is not None

    results: list[Capability] = []
    for spec in CAPABILITIES:
        missing = [f for f in spec["needs"] if not present(f)]
        results.append(Capability(
            key=spec["key"],
            what_you_get=spec["what_you_get"],
            available=not missing,
            needs=missing,
            needs_plain=spec["needs_plain"],
        ))

    available = [c for c in results if c.available]
    blocked = [c for c in results if not c.available]

    # Which single field would unlock the most. Worth knowing, because asking
    # for one thing is a reasonable request and asking for eight is a form.
    counts: dict[str, int] = {}
    for capability in blocked:
        for field in capability.needs:
            counts[field] = counts.get(field, 0) + 1
    most_useful = max(counts, key=counts.get) if counts else None

    return {
        "investor_id": investor_id,
        "profile": profile or None,
        "goals": goals,
        "available": [c.as_dict() for c in available],
        "blocked": [c.as_dict() for c in blocked],
        "completeness_pct": round(len(available) / len(results) * 100) if results else 0,
        "most_useful_next": most_useful,
        "summary": _summarise(len(available), len(results), blocked),
    }


def _summarise(available: int, total: int, blocked: list[Capability]) -> str:
    if available == total:
        return "We have everything we need to analyse this properly."
    if available == 0:
        return ("We can show you what you hold, but not whether it suits you. "
                "A few details about your circumstances would change that.")
    first = blocked[0].what_you_get.lower()
    remaining = len(blocked) - 1
    if remaining:
        return (f"We cannot yet tell you {first}, or {remaining} other "
                f"thing{'s' if remaining != 1 else ''}.")
    return f"We cannot yet tell you {first}."


# ---------------------------------------------------------------------------
# What the portfolio was meant to look like
# ---------------------------------------------------------------------------


def get_targets(investor_id: str) -> list[dict]:
    return db.fetch_all(
        """
        SELECT asset_class, target_pct, tolerance_pct, set_at, note
        FROM target_allocations WHERE investor_id = %s
        ORDER BY target_pct DESC
        """,
        (investor_id,),
    )


def set_targets(investor_id: str, targets: dict[str, float],
                tolerance: float = 5.0) -> list[dict]:
    """Record what the mix is meant to be.

    Refuses a set that does not add up. A target of 60% equity and 30% debt
    leaves a tenth of the money unaccounted for, and drift measured against it
    would be wrong by that much without ever saying so.
    """
    clean = {k: Decimal(str(v)) for k, v in targets.items() if Decimal(str(v)) > 0}
    if not clean:
        with db.connection() as conn:
            conn.execute("DELETE FROM target_allocations WHERE investor_id = %s",
                         (investor_id,))
        return []

    total = sum(clean.values())
    if abs(total - 100) > Decimal("0.5"):
        raise ValueError(
            f"Those add up to {total:.0f}%. A target mix has to account for all "
            f"of the money, or the drift measured against it is wrong by the "
            f"difference."
        )

    with db.connection() as conn:
        with conn.transaction():
            conn.execute("DELETE FROM target_allocations WHERE investor_id = %s",
                         (investor_id,))
            for asset_class, pct in clean.items():
                conn.execute(
                    """
                    INSERT INTO target_allocations
                        (investor_id, asset_class, target_pct, tolerance_pct)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (investor_id, asset_class, pct, Decimal(str(tolerance))),
                )
    return get_targets(investor_id)


def drift(investor_id: str) -> Optional[dict]:
    """How far the portfolio has moved from what was intended.

    Markets do the drifting. A portfolio set at 60/40 and left alone becomes
    70/30 after a good year for equities, and the person who chose 60/40 now
    holds something they did not choose -- which is the whole argument for
    rebalancing, and it cannot be made without knowing what they chose.

    Returns the gap in both directions and what it would take in rupees to
    close, because "you are 12 points over" is abstract and "sell ₹4.1 lakh of
    shares" is a decision.
    """
    targets = get_targets(investor_id)
    if not targets:
        return None

    from . import wealth

    from .rebalance import investable

    # Drift is measured across what an allocation decision can actually move.
    #
    # A target of 60% equity, 30% funds and 10% bonds implicitly says
    # everything else should be zero. On a real portfolio that produced
    # "reduce insurance from 78% to 0%" and "reduce provident fund to 0%",
    # which are instructions to cancel a family's cover and raid a retirement
    # account. Neither is an allocation question.
    everything = wealth.allocation(investor_id)
    holdings = [a for a in everything if investable(a)]
    set_aside = [a for a in everything if not investable(a)]

    total = sum(Decimal(str(a["value"])) for a in holdings)
    if total <= 0:
        return None

    held = {a["asset_class"]: Decimal(str(a["value"])) for a in holdings}
    lines = []
    worst = Decimal(0)

    # Everything with a target, plus anything investable held that has none --
    # money in a class the plan never mentioned is drift too, provided it is
    # money somebody could move.
    planned = {t["asset_class"] for t in targets}
    classes = {c for c in (planned | set(held))
               if investable({"asset_class": c})}
    by_target = {t["asset_class"]: t for t in targets}

    for asset_class in classes:
        target = by_target.get(asset_class)
        target_pct = Decimal(str(target["target_pct"])) if target else Decimal(0)
        tolerance = Decimal(str(target["tolerance_pct"])) if target else Decimal(5)
        value = held.get(asset_class, Decimal(0))
        actual_pct = (value / total * 100).quantize(Decimal('0.1'))
        gap = actual_pct - target_pct

        # A class held but never mentioned in the plan is not a target of
        # zero.
        #
        # Gold was added to a portfolio whose target mix predated it, and the
        # absence read as "you chose to hold none" -- producing "gold is 37%
        # against the 0% you set, sell all of it" while another part of the
        # engine recommended holding gold. Both reasoned correctly from
        # different premises, and one premise was invented.
        never_planned = target is None and value > 0

        lines.append({
            "asset_class": asset_class,
            "target_pct": str(target_pct) if target else None,
            "actual_pct": str(actual_pct.quantize(Decimal("0.1"))),
            "gap_pct": str(gap.quantize(Decimal("0.1"))),
            "value": str(value.quantize(Decimal("1"))),
            "target_value": (str((total * target_pct / 100).quantize(Decimal("1")))
                             if target else None),
            "to_move": (str((total * gap / 100).quantize(Decimal("1")))
                        if target else None),
            "beyond_tolerance": (abs(gap) > tolerance) if target else False,
            "never_planned": never_planned,
            "note": ("You hold this and your target mix does not mention it. "
                     "That is not the same as having chosen to hold none — it "
                     "usually means the plan was set before this was here. "
                     "Worth adding a target rather than reading the gap as "
                     "drift." if never_planned else None),
        })
        if target:
            worst = max(worst, abs(gap))

    lines.sort(key=lambda line: -abs(Decimal(line["gap_pct"])))
    out_of_line = [line for line in lines if line["beyond_tolerance"]]

    unplanned = [line["asset_class"] for line in lines
                 if line.get("never_planned")]

    return {
        "lines": lines,
        "held_but_unplanned": unplanned,
        "out_of_line": len(out_of_line),
        "worst_gap_pct": str(worst.quantize(Decimal("0.1"))),
        "set_at": targets[0]["set_at"].date().isoformat() if targets else None,
        "in_line": not out_of_line,
        "method": ("Against the mix you set. Small drifts are left alone: "
                   "rebalancing on every move costs more in tax and brokerage "
                   "than the drift costs in risk."),
    }
