"""The realised alpha ledger: what each move earned against what it replaced.

The plan's alpha page promises cost and tax in rupees and says the rest is
"capital moved from where the record is against you to where it is for you".
This is where the rest gets measured. Every claimed consent becomes a row
with both starting prices; a monthly mark re-prices both paths; the page
shows the sum by month, quarter, year and since the start -- as it is,
including the moves that lost.

A move that lost is the most important row on the page. A ledger that only
showed the winners would be marketing, and PaRRVA exists because the
industry did exactly that.
"""

from __future__ import annotations

import json
import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

LIQUID_RATE = Decimal("0.065")       # the counterfactual for money with no other home
_NAV_MEMO: dict[str, dict[date, Decimal]] = {}


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    sign = "-" if v < 0 else ""
    v = abs(v)
    if v >= 10000000:
        return f"{sign}₹{v / 10000000:.2f} crore"
    if v >= 100000:
        return f"{sign}₹{v / 100000:.1f} lakh"
    return f"{sign}₹{v:,.0f}"


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------

def _nav_series(code: str) -> dict[date, Decimal]:
    from . import commission
    return commission._series(code)


def _price_on(symbol: Optional[str], code: Optional[str], when: date) -> Optional[Decimal]:
    """A fund's NAV or a share's close, on or just before a date."""
    from . import commission, dataservice
    if code:
        return commission._nav_on(_nav_series(code), when)
    if symbol:
        if when >= date.today() - timedelta(days=3):
            try:
                q = dataservice.quote(symbol) or {}
                p = _d(q.get("price"))
                if p > 0:
                    return p
            except Exception:
                pass
        try:
            bars = (dataservice.ohlcv(symbol, period="2y") or {}).get("data") or []
        except Exception:
            return None
        pts = [(str(b.get("date"))[:10], _d(b.get("close"))) for b in bars if _d(b.get("close")) > 0]
        before = [p for p in pts if p[0] <= when.isoformat()]
        return before[-1][1] if before else None
    return None


def _code_of(instrument_id: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    if not instrument_id:
        return None, None
    row = db.fetch_one("SELECT symbol, native_code, asset_class FROM instruments WHERE id = %s", (instrument_id,))
    if not row:
        return None, None
    return (row.get("symbol") or None), (row.get("native_code") if row.get("asset_class") == "mutual_fund" else None)


# ---------------------------------------------------------------------------
# Opening rows from claimed consents
# ---------------------------------------------------------------------------

def open_from_consents(investor_id: str) -> int:
    """Every claimed consent not yet in the ledger becomes a row. Returns how many."""
    rows = db.fetch_all(
        """
        SELECT c.id, c.instrument_id, c.symbol, c.name, c.side, c.amount, c.price_shown, c.est_tax, c.shown, c.used_at
        FROM order_consent c
        LEFT JOIN alpha_realised r ON r.consent_id = c.id
        WHERE c.investor_id = %s AND c.used_at IS NOT NULL AND c.withdrawn_at IS NULL AND r.id IS NULL
        ORDER BY c.used_at
        """, (investor_id,))
    made = 0
    for c in rows:
        shown = c["shown"] if isinstance(c["shown"], dict) else json.loads(c["shown"] or "{}")
        basket = shown.get("orders") or []
        mine = next((o for o in basket if o.get("instrument_id") == c["instrument_id"] and o.get("side") == c["side"]), {})
        basis = str(mine.get("basis") or mine.get("alpha_basis") or mine.get("note") or "")
        placed = c["used_at"].date()
        amount = _d(c["amount"])
        if amount <= 0:
            continue

        from_symbol, from_code = _code_of(c["instrument_id"])
        kind, to_symbol, to_code, fixed = "buy", None, None, None
        if c["side"] == "sell":
            # A buy in the same basket is the replacement; the first one, pro-rata is v2.
            buys = [o for o in basket if o.get("side") == "buy"]
            if "cost" in basis or "direct plan" in str(mine.get("note") or "").lower():
                kind = "cost"
            elif buys:
                kind = "switch"
                b = buys[0]
                to_symbol = (b.get("symbol") or None)
                to_code = b.get("code") or (b.get("symbol") if str(b.get("symbol") or "").isdigit() else None)
                if not to_code and b.get("instrument_id"):
                    to_symbol, to_code = _code_of(b["instrument_id"])
            else:
                kind = "sell"
            if "harvest" in basis.lower() or "book " in basis.lower() and "gain" in basis.lower():
                kind, fixed = "tax", abs(_d(c["est_tax"]))
        else:
            # A buy funded by sells in the same basket is the switch's "to" and
            # is already counted there; it is filed closed so it is never marked
            # twice. A buy with no sell beside it is new money, against liquid.
            funded_by_sells = any(o.get("side") == "sell" for o in basket)
            to_symbol, to_code = from_symbol, from_code
            if not to_symbol and not to_code:
                sym = str(c["symbol"] or mine.get("code") or "")
                to_code, to_symbol = (sym, None) if sym.isdigit() else (None, sym or None)
            from_symbol = from_code = None
            if funded_by_sells:
                with db.connection() as conn:
                    conn.execute(
                        """
                        INSERT INTO alpha_realised (investor_id, consent_id, kind, basis, placed_on, amount, to_symbol, to_code, closed_at)
                        VALUES (%s, %s, 'buy', %s, %s, %s, %s, %s, now()) ON CONFLICT (consent_id) DO NOTHING
                        """, (investor_id, c["id"], "funded by sells in the same basket; counted in the switch", placed, amount, to_symbol, to_code))
                continue

        from_start = _price_on(from_symbol, from_code, placed) if (from_symbol or from_code) else None
        to_start = _price_on(to_symbol, to_code, placed) if (to_symbol or to_code) else None
        if kind == "cost" and from_code:
            from . import plans
            twin = plans.find_direct_twin(c["name"] or "", None)
            if twin:
                to_code = twin["native_code"]; to_start = _price_on(None, to_code, placed)

        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO alpha_realised (investor_id, consent_id, kind, basis, placed_on, amount,
                    from_instrument, from_symbol, from_code, from_start, to_symbol, to_code, to_start, fixed_alpha)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (consent_id) DO NOTHING
                """, (investor_id, c["id"], kind, basis[:200], placed, amount,
                      c["instrument_id"], from_symbol, from_code, from_start, to_symbol, to_code, to_start, fixed))
        made += 1
    return made


# ---------------------------------------------------------------------------
# Marking
# ---------------------------------------------------------------------------

def _liquid(amount: Decimal, since: date, until: date) -> Decimal:
    days = max(0, (until - since).days)
    return amount * (1 + LIQUID_RATE * Decimal(days) / Decimal(365))


def mark(investor_id: str, on: Optional[date] = None) -> dict:
    on = on or date.today()
    rows = db.fetch_all(
        "SELECT * FROM alpha_realised WHERE investor_id = %s AND closed_at IS NULL", (investor_id,))
    marked = skipped = 0
    for r in rows:
        amount, placed = _d(r["amount"]), r["placed_on"]
        if r["kind"] == "tax":
            fv, tv, alpha, note = None, None, _d(r["fixed_alpha"]), "tax saved on the day; fixed"
        else:
            from_now = _price_on(r["from_symbol"], r["from_code"], on) if (r["from_symbol"] or r["from_code"]) else None
            to_now = _price_on(r["to_symbol"], r["to_code"], on) if (r["to_symbol"] or r["to_code"]) else None
            fs, ts = _d(r["from_start"]), _d(r["to_start"])
            if r["kind"] in ("switch", "cost"):
                if not (from_now and to_now and fs > 0 and ts > 0):
                    skipped += 1; continue
                fv, tv = amount * from_now / fs, amount * to_now / ts
                note = "where it went, against where it would have stayed"
            elif r["kind"] == "sell":
                if not (from_now and fs > 0):
                    skipped += 1; continue
                fv, tv = amount * from_now / fs, _liquid(amount, placed, on)
                note = "cash at a liquid rate, against the holding it left"
            else:  # buy from new money
                if not (to_now and ts > 0):
                    skipped += 1; continue
                fv, tv = _liquid(amount, placed, on), amount * to_now / ts
                note = "where it went, against a liquid rate"
            alpha = tv - fv
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO alpha_mark (realised_id, marked_on, from_value, to_value, alpha, note)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (realised_id, marked_on) DO UPDATE SET from_value = EXCLUDED.from_value,
                    to_value = EXCLUDED.to_value, alpha = EXCLUDED.alpha, note = EXCLUDED.note
                """, (r["id"], on, fv, tv, alpha.quantize(Decimal("1")), note))
        marked += 1
    return {"marked": marked, "skipped": skipped, "on": on.isoformat()}


# ---------------------------------------------------------------------------
# The page
# ---------------------------------------------------------------------------

def ledger(investor_id: str) -> dict:
    rows = db.fetch_all(
        """
        SELECT r.id, r.kind, r.basis, r.placed_on, r.amount, r.from_symbol, r.from_code, r.to_symbol, r.to_code, r.fixed_alpha,
               c.name AS from_name,
               (SELECT alpha FROM alpha_mark m WHERE m.realised_id = r.id ORDER BY marked_on DESC LIMIT 1) AS alpha_now,
               (SELECT marked_on FROM alpha_mark m WHERE m.realised_id = r.id ORDER BY marked_on DESC LIMIT 1) AS marked_on,
               (SELECT note FROM alpha_mark m WHERE m.realised_id = r.id ORDER BY marked_on DESC LIMIT 1) AS note
        FROM alpha_realised r LEFT JOIN order_consent c ON c.id = r.consent_id
        WHERE r.investor_id = %s
          AND (r.closed_at IS NULL OR EXISTS (SELECT 1 FROM alpha_mark m WHERE m.realised_id = r.id))
        ORDER BY r.placed_on DESC
        """, (investor_id,))
    today = date.today()
    periods = {"this_month": date(today.year, today.month, 1),
               "this_quarter": date(today.year, 3 * ((today.month - 1) // 3) + 1, 1),
               "this_year": date(today.year if today.month > 3 else today.year - 1, 4, 1),
               "since_start": date(1900, 1, 1)}
    by_period = {k: Decimal(0) for k in periods}
    by_kind: dict[str, Decimal] = {}
    moves = []
    for r in rows:
        a = _d(r["alpha_now"]) if r["alpha_now"] is not None else None
        if a is not None:
            for k, start in periods.items():
                if r["placed_on"] >= start:
                    by_period[k] += a
            by_kind[r["kind"]] = by_kind.get(r["kind"], Decimal(0)) + a
        moves.append({"id": str(r["id"]), "kind": r["kind"], "basis": r["basis"], "placed_on": r["placed_on"].isoformat(),
                      "amount": str(_d(r["amount"]).quantize(Decimal("1"))), "from": r["from_name"] or r["from_symbol"] or r["from_code"],
                      "to": r["to_symbol"] or r["to_code"], "alpha": str(a.quantize(Decimal("1"))) if a is not None else None,
                      "marked_on": r["marked_on"].isoformat() if r["marked_on"] else None, "note": r["note"]})
    won = sum(1 for m in moves if m["alpha"] and _d(m["alpha"]) > 0)
    lost = sum(1 for m in moves if m["alpha"] and _d(m["alpha"]) < 0)
    return {
        "moves": moves, "count": len(moves), "won": won, "lost": lost,
        "by_period": {k: str(v.quantize(Decimal("1"))) for k, v in by_period.items()},
        "by_kind": {k: str(v.quantize(Decimal("1"))) for k, v in by_kind.items()},
        "reading": (f"{len(moves)} move{'s' if len(moves) != 1 else ''} placed through the plan; {won} ahead of what they replaced, "
                    f"{lost} behind. Net since the start: {_money(by_period['since_start'])}; this year {_money(by_period['this_year'])}."
                    if moves else "Nothing placed through the plan yet. The first move you agree to starts this ledger."),
        "principle": ("Every move is marked monthly against the path the money would have taken — the holding it left, or a "
                      "liquid rate where there was none. Losers are shown with the winners; a ledger that hid them would be "
                      "marketing. Cost and tax rows are arithmetic; the rest is the market, and it is reported as it is."),
    }
