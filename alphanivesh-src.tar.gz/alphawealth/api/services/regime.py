"""The regime panel: what the market's own record permits this week.

The benchmark of the industry is unambiguous about timing. The one large-scale
live test of rules-based risk timing in retail advice (Scalable Capital's
value-at-risk strategies) lost ~70 points to the index over seven years and
was closed. StashAway's regime model survives but shifts regime every three
to seven years and has no independent audit. The leaders -- Vanguard,
Betterment, Wealthfront -- do not time at all. The one directional input with
a documented, monotonic relationship to forward returns in India is
valuation: Nifty P/E bands against three- and five-year returns.

So this panel does not forecast and does not switch. It reads four things
from long records -- the index's drawdown, its trend, equity against debt,
gold against equity, and the rupee -- and for each it states what followed
readings like today's across every month in the history we hold: how many
windows, how often positive, the median, the unlucky tenth. From that it
issues *permits*, which are small and bounded: the pace at which new money
goes in (at once, or over twelve months), and a tilt of a few points inside
the target band. A rule whose own replay does not beat doing nothing is
shown, and shown as "no edge" -- and it issues no permit.

The series are the longest fund NAVs we hold as proxies: a Nifty 50 index
fund (since the late 1990s), a gilt fund, a gold fund, and the RBI/FBIL
rupee fixing since 1998. Proxies, and said so.
"""

from __future__ import annotations

import logging
import statistics
import time
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

MIN_WINDOWS = 36                     # fewer than this and a base rate is a coincidence
HALF_MIN_WINDOWS = 12                # each half of the shadow test needs at least this many like-today months
HALF_EDGE_MIN = 1.0                  # and an edge at least this big, same sign as the whole
TILT_PTS = Decimal(5)                # the most any permit moves a bucket, inside the band
MEMO_SECONDS = 3600
_MEMO: dict[str, tuple[float, Any]] = {}

# Longest-history proxies, by name pattern, most-preferred first. Resolved
# against searchable_instruments at runtime and the one with the earliest NAV
# wins, so a reload of the master cannot silently swap in a younger series.
PROXIES = {
    "index": ["Nifty 50 Index Fund Regular Growth", "Nifty Index Fund Growth", "Index Fund Nifty Plan Growth", "Nifty 50 Index Growth"],
    "gilt":  ["Gilt Fund Regular Growth", "Government Securities Fund Growth", "Gilt Securities Fund Growth"],
    "gold":  ["Gold ETF", "Gold BeES", "Gold Fund Regular Growth", "Gold Exchange Traded"],
}


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _memo(key: str, make):
    hit = _MEMO.get(key)
    if hit and time.monotonic() - hit[0] < MEMO_SECONDS:
        return hit[1]
    val = make()
    _MEMO[key] = (time.monotonic(), val)
    return val


# ---------------------------------------------------------------------------
# Series
# ---------------------------------------------------------------------------

def _monthly_from_navs(rows: list[dict]) -> list[tuple[date, float]]:
    by_month: dict[tuple[int, int], tuple[date, float]] = {}
    for r in rows:                                   # newest first
        try:
            when = datetime.strptime(r["date"], "%d-%m-%Y").date()
            nav = float(r.get("nav") or 0)
        except (KeyError, ValueError, TypeError):
            continue
        if nav <= 0:
            continue
        key = (when.year, when.month)
        if key not in by_month:
            by_month[key] = (date(when.year, when.month, 1), nav)
    return sorted(by_month.values(), key=lambda p: p[0])


def _resolve(kind: str) -> Optional[dict]:
    """The scheme code for a proxy: the matching fund with the oldest history."""
    from . import dataservice
    best = None
    for pattern in PROXIES[kind]:
        rows = db.fetch_all(
            """
            SELECT name, native_code FROM searchable_instruments
            WHERE asset_class = 'mutual_fund' AND native_code IS NOT NULL AND search_text %% %s
            ORDER BY similarity(search_text, %s) DESC LIMIT 6
            """, (pattern, pattern)) or []
        for r in rows:
            n = r["name"].lower()
            if kind == "index" and not ("nifty" in n and "index" in n and "next" not in n and "junior" not in n and "equal" not in n):
                continue
            if kind == "gilt" and "gilt" not in n and "government" not in n:
                continue
            if kind == "gold" and "gold" not in n:
                continue
            if "idcw" in n or "dividend" in n:
                continue
            try:
                series = _monthly_from_navs((dataservice.nav_history(r["native_code"], days=0) or {}).get("data") or [])
            except Exception:
                continue
            if len(series) < 60:
                continue
            if best is None or series[0][0] < best["series"][0][0]:
                best = {"name": r["name"], "code": r["native_code"], "series": series}
    return best


def _series(kind: str) -> Optional[dict]:
    return _memo(f"series:{kind}", lambda: _resolve(kind))


def _fx_monthly() -> list[tuple[date, float]]:
    from . import currency
    try:
        return [(d, float(v)) for d, v in currency.monthly_levels("USD")]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Replay: the forward twelve months after months that looked like this one
# ---------------------------------------------------------------------------

SEAM = 0.40                          # a month-on-month NAV move this large is a unit change, not a market move


def _seams(series: list[tuple[date, float]]) -> set[int]:
    """Indices where the series steps for a corporate action rather than a move."""
    out = set()
    for i in range(1, len(series)):
        a, b = series[i - 1][1], series[i][1]
        if a > 0 and abs(b / a - 1) > SEAM:
            out.add(i)
    return out


def _forward(series: list[tuple[date, float]], months: int = 12) -> list[tuple[int, float]]:
    """(index, forward return %) for every month that has `months` ahead of it.

    A window that spans a seam is left out: the gold ETF's NAV fell 99% in
    one month when its unit changed, and counting that as an outcome made the
    unlucky tenth read -99%."""
    seams = _seams(series)
    out = []
    for i in range(len(series) - months):
        if any(j in seams for j in range(i + 1, i + months + 1)):
            continue
        a, b = series[i][1], series[i + months][1]
        if a > 0:
            out.append((i, (b / a - 1) * 100))
    return out


def _summarise(values: list[float]) -> Optional[dict]:
    if len(values) < MIN_WINDOWS:
        return None
    s = sorted(values)
    tenth = s[max(0, int(len(s) * 0.1) - 1)]
    return {"windows": len(values), "positive_pct": round(sum(1 for v in values if v > 0) / len(values) * 100, 1),
            "median_pct": round(statistics.median(values), 1), "unlucky_tenth_pct": round(tenth, 1),
            "worst_pct": round(s[0], 1), "best_pct": round(s[-1], 1)}


def _state_replay(series: list[tuple[date, float]], state_of, today_state: str, months: int = 12) -> dict:
    """Forward returns conditional on the state each month was in, vs all months."""
    fwd = _forward(series, months)
    by_state: dict[str, list[float]] = {}
    for i, r in fwd:
        by_state.setdefault(state_of(i), []).append(r)
    everything = _summarise([r for _, r in fwd])
    like_today = _summarise(by_state.get(today_state, []))
    edge = (round(like_today["median_pct"] - everything["median_pct"], 1) if like_today and everything else None)

    # The shadow test. An edge found across the whole record is found in-sample;
    # the question is whether it was there in each half on its own. Split the
    # windows at the midpoint of the record and compute the edge in each. A rule
    # is live only if both halves agree in sign and each clears HALF_EDGE_MIN.
    halves = []
    if fwd:
        mid = fwd[len(fwd) // 2][0]
        for part in ([(i, r) for i, r in fwd if i < mid], [(i, r) for i, r in fwd if i >= mid]):
            vals = [r for _, r in part]
            like = [r for i, r in part if state_of(i) == today_state]
            if len(like) >= HALF_MIN_WINDOWS and len(vals) >= HALF_MIN_WINDOWS:
                e = statistics.median(like) - statistics.median(vals)
                halves.append({"from": series[part[0][0]][0].isoformat(), "to": series[part[-1][0]][0].isoformat(),
                               "windows": len(like), "edge_pct": round(e, 1)})
            else:
                halves.append({"from": series[part[0][0]][0].isoformat() if part else None,
                               "to": series[part[-1][0]][0].isoformat() if part else None,
                               "windows": len(like), "edge_pct": None})
    stable = (edge is not None and len(halves) == 2 and all(h["edge_pct"] is not None for h in halves)
              and all((h["edge_pct"] > 0) == (edge > 0) and abs(h["edge_pct"]) >= HALF_EDGE_MIN for h in halves))
    return {"state": today_state, "like_today": like_today, "all_months": everything,
            "edge_pct": edge, "halves": halves, "stable": stable}


# ---------------------------------------------------------------------------
# The readings
# ---------------------------------------------------------------------------

def _drawdown_reading(idx: list[tuple[date, float]]) -> dict:
    levels = [v for _, v in idx]
    seams = _seams(idx)
    peaks = []
    p = 0.0
    for i, v in enumerate(levels):
        if i in seams:
            p = 0.0
        p = max(p, v); peaks.append(p)
    off = [(levels[i] / peaks[i] - 1) * 100 for i in range(len(levels))]

    def band(x: float) -> str:
        return "at high" if x > -3 else "3–10% off" if x > -10 else "10–20% off" if x > -20 else "20%+ off"
    today = band(off[-1])
    rep = _state_replay(idx, lambda i: band(off[i]), today)
    return {"code": "drawdown", "name": "Where the index sits against its high",
            "value": f"{off[-1]:.1f}% from its high", "state": today, "replay": rep,
            "say": _say(f"the index was {today}", rep)}


def _trend_reading(idx: list[tuple[date, float]]) -> dict:
    """Price against its ten-month average -- the classic trend rule, replayed honestly.

    Shown with what it would have done: the share of months it was 'above', and
    the forward return in each state. If being below the average has not
    predicted worse returns in our record, the panel says so and no permit
    follows from it."""
    levels = [v for _, v in idx]

    def state(i: int) -> str:
        if i < 10:
            return "unknown"
        avg = sum(levels[i - 10:i]) / 10
        return "above trend" if levels[i] >= avg else "below trend"
    today = state(len(levels) - 1)
    rep = _state_replay(idx, state, today)
    return {"code": "trend", "name": "The index against its ten-month average",
            "value": today, "state": today, "replay": rep, "say": _say(f"the index was {today}", rep)}


def _relative_reading(a: list[tuple[date, float]], b: list[tuple[date, float]], *, code: str, name: str,
                      a_label: str, b_label: str, months: int = 36) -> Optional[dict]:
    """Which of two assets has been winning over `months`, and what followed for the first."""
    bm = {d: v for d, v in b}
    paired = [(d, v, bm[d]) for d, v in a if d in bm]
    if len(paired) < months + MIN_WINDOWS:
        return None
    series_a = [(d, v) for d, v, _ in paired]
    seams_a = _seams([(d, v) for d, v, _ in paired]); seams_b = _seams([(d, w) for d, _, w in paired])
    rel = []
    for i in range(len(paired)):
        if i < months or any(j in seams_a or j in seams_b for j in range(i - months + 1, i + 1)):
            rel.append(None); continue
        ra = paired[i][1] / paired[i - months][1] - 1
        rb = paired[i][2] / paired[i - months][2] - 1
        rel.append(ra - rb)

    def state(i: int) -> str:
        r = rel[i]
        if r is None:
            return "unknown"
        return f"{a_label} ahead" if r > 0.05 else f"{b_label} ahead" if r < -0.05 else "level"
    today = state(len(paired) - 1)
    rep = _state_replay(series_a, state, today)
    gap = rel[-1]
    return {"code": code, "name": name,
            "value": (f"{a_label} {'+' if gap >= 0 else ''}{gap * 100:.0f} pts vs {b_label} over {months // 12} year{'s' if months > 12 else ''}" if gap is not None else "unreadable"),
            "state": today, "replay": rep,
            "say": _say((f"{today.split(' ahead')[0]} was ahead of {b_label if today.startswith(a_label) else a_label} over {months // 12} year{'s' if months > 12 else ''}"
                         if "ahead" in today else f"{a_label} and {b_label} were level over {months // 12} year{'s' if months > 12 else ''}"), rep)}


def _rupee_reading(fx: list[tuple[date, float]], idx: list[tuple[date, float]]) -> Optional[dict]:
    if len(fx) < 24 + MIN_WINDOWS or not idx:
        return None
    im = {d: v for d, v in idx}
    paired = [(d, r, im[d]) for d, r in fx if d in im]
    if len(paired) < 24 + MIN_WINDOWS:
        return None
    move = [None] * 12 + [(paired[i][1] / paired[i - 12][1] - 1) * 100 for i in range(12, len(paired))]

    def state(i: int) -> str:
        m = move[i]
        return "unknown" if m is None else "rupee falling fast" if m > 6 else "rupee steady" if m > -2 else "rupee strengthening"
    today = state(len(paired) - 1)
    rep = _state_replay([(d, v) for d, _, v in paired], state, today)
    return {"code": "rupee", "name": "The rupee against the dollar, twelve months",
            "value": f"{move[-1]:+.1f}% ({'weaker' if move[-1] > 0 else 'stronger'} rupee)", "state": today, "replay": rep,
            "say": _say({"rupee falling fast": "the rupee was falling fast", "rupee steady": "the rupee was steady",
                         "rupee strengthening": "the rupee was strengthening"}.get(today, today), rep)}


def _say(phrase: str, rep: dict) -> str:
    """`phrase` completes "In the N months when ..."."""
    lt, al = rep.get("like_today"), rep.get("all_months")
    if not lt:
        return f"Too few months in the record looked like this one ({phrase}) to count a base rate from."
    edge = rep.get("edge_pct")
    return (f"In the {lt['windows']} months when {phrase}, the following twelve months were positive "
            f"{lt['positive_pct']}% of the time, median {lt['median_pct']:+.1f}%, unlucky tenth {lt['unlucky_tenth_pct']:+.1f}%"
            + (f" — against {al['median_pct']:+.1f}% median across all {al['windows']} months" if al else "")
            + (f"; an edge of {edge:+.1f} points" if edge is not None and abs(edge) >= 2 else "; no real edge either way.")
            + (("" if not (edge is not None and abs(edge) >= 2) else
                (" — and it held in both halves of the record, so it may speak." if rep.get("stable") else
                 " — but it did not hold in both halves of the record on its own, so it is shown and not acted on."))))


# ---------------------------------------------------------------------------
# Permits
# ---------------------------------------------------------------------------

def _gated(readings: list[dict], live: bool) -> list[dict]:
    """Readings as the permits see them. Live: an edge that failed the shadow
    test is treated as no edge. Shadow: every edge counts, to show what the
    rule would have done if it were allowed to speak."""
    out = []
    for r in readings:
        if not r:
            continue
        if live and not (r.get("replay") or {}).get("stable"):
            r = {**r, "replay": {**(r.get("replay") or {}), "edge_pct": 0}}
        out.append(r)
    return out


def _permits(readings: list[dict], valuation: Optional[dict]) -> list[dict]:
    """Small, bounded, and only where the replay says there is an edge."""
    by = {r["code"]: r for r in readings if r}
    out = []

    # Deployment pace: from drawdown (and valuation where we have it).
    dd = by.get("drawdown")
    pace, why = "staggered", "Twelve monthly instalments is the default: it costs about half a point a year against lump sum on the record, and it is the one that people actually finish."
    if dd and dd["replay"].get("like_today"):
        lt = dd["replay"]["like_today"]
        edge = dd["replay"].get("edge_pct") or 0
        if dd["state"] in ("10–20% off", "20%+ off") and lt["positive_pct"] >= 70 and edge >= 2:
            pace, why = "at once", (f"The index is {dd['value']}. {dd['say']} That is the one reading in the record where buying "
                                    f"at once has beaten instalments, so new money goes in now.")
        elif dd["state"] == "at high" and edge <= -2:
            pace, why = "staggered", f"The index is at its high. {dd['say']} Instalments, over twelve months."
    out.append({"permit": "deployment", "value": pace, "why": why, "basis": "drawdown replay"})

    # Equity tilt inside the band: only from equity-vs-debt, only with an edge.
    rel = by.get("equity_vs_debt")
    tilt, why = 0, "No tilt. The equity target stands as the plan sets it."
    if rel and rel["replay"].get("like_today"):
        edge = rel["replay"].get("edge_pct") or 0
        if rel["state"].startswith("debt ahead") and edge >= 3:
            tilt, why = int(TILT_PTS), (f"{rel['value']}. {rel['say']} Equity may run to the top of its band — "
                                        f"{TILT_PTS} points over target, no more — from new money, not from selling debt.")
        elif rel["state"].startswith("equity ahead") and edge <= -3:
            tilt, why = -int(TILT_PTS), (f"{rel['value']}. {rel['say']} Equity sits at the bottom of its band — "
                                         f"{TILT_PTS} points under — by directing new money to debt, not by selling.")
    out.append({"permit": "equity_tilt_pts", "value": tilt, "why": why, "basis": "equity-vs-debt replay"})

    # Gold tilt: same discipline.
    g = by.get("gold_vs_equity")
    gtilt, why = 0, "Gold stays at its target weight."
    if g and g["replay"].get("like_today"):
        edge = g["replay"].get("edge_pct") or 0
        if g["state"].startswith("equity ahead") and edge <= -3:
            gtilt, why = 2, f"{g['value']}. {g['say']} Gold may run two points over target, from new money."
    out.append({"permit": "gold_tilt_pts", "value": gtilt, "why": why, "basis": "gold-vs-equity replay"})

    # Trend: informational unless the replay shows an edge, and even then only pace.
    tr = by.get("trend")
    if tr and tr["replay"].get("like_today") and (tr["replay"].get("edge_pct") or 0) <= -3 and tr["state"] == "below trend":
        out.append({"permit": "note", "value": "below trend",
                    "why": f"{tr['say']} It does not change the plan; it says the instalments are the right pace.",
                    "basis": "trend replay"})

    if valuation and valuation.get("pe"):
        pe = float(valuation["pe"])
        band = ("12–15" if pe < 15 else "15–18" if pe < 18 else "18–21" if pe < 21 else "21–24" if pe < 24 else "24–27" if pe < 27 else "27+")
        ext = {"12–15": (38.7, 29.2), "15–18": (23.0, 18.4), "18–21": (16.7, 14.9), "21–24": (12.8, 11.2), "24–27": (8.5, 8.1), "27+": (5.6, 5.8)}[band]
        out.append({"permit": "valuation", "value": f"P/E {pe:.1f} ({band})",
                    "why": (f"The hundred largest companies trade at {pe:.1f} times earnings. We hold no history of this figure; the published "
                            f"record (Nifty 1999–2018) puts three-year returns after a {band} reading at about {ext[0]}% a year and five-year at {ext[1]}%, "
                            f"falling monotonically with the band. External, not our replay — shown, not acted on."),
                    "basis": "external: Nifty P/E bands 1999–2018"})
    return out


# ---------------------------------------------------------------------------
# The panel
# ---------------------------------------------------------------------------

def _log(as_of: date, readings: list[dict], permits: list[dict], shadow: list[dict]) -> None:
    """One row per day: what the panel read, what it permitted, what ran in
    shadow. Makes every permit reproducible, and is the record a rule's shadow
    run is judged on before it is promoted."""
    import json
    try:
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO regime_log (logged_on, data_as_of, readings, permits, shadow)
                VALUES (current_date, %s, %s::jsonb, %s::jsonb, %s::jsonb)
                ON CONFLICT (logged_on) DO UPDATE SET data_as_of = EXCLUDED.data_as_of, readings = EXCLUDED.readings,
                    permits = EXCLUDED.permits, shadow = EXCLUDED.shadow
                """,
                (as_of, json.dumps([{"code": r["code"], "value": r["value"], "state": r["state"],
                                     "edge_pct": (r.get("replay") or {}).get("edge_pct"),
                                     "stable": (r.get("replay") or {}).get("stable"),
                                     "halves": (r.get("replay") or {}).get("halves")} for r in readings], default=str),
                 json.dumps(permits, default=str), json.dumps(shadow, default=str)))
    except Exception as err:
        log.info("regime log not written: %s", err)


def history(days: int = 90) -> list[dict]:
    rows = db.fetch_all("SELECT logged_on, data_as_of, permits, shadow FROM regime_log ORDER BY logged_on DESC LIMIT %s", (days,))
    return [{"on": r["logged_on"].isoformat(), "data_as_of": r["data_as_of"].isoformat() if r["data_as_of"] else None,
             "permits": r["permits"], "shadow": r["shadow"]} for r in rows]


def panel() -> dict:
    return _memo("panel", _build)


def _build() -> dict:
    from . import market
    idx = _series("index")
    if not idx:
        return {"readable": False, "why": "No long index proxy could be found in the scheme master. The panel needs a Nifty index fund with a NAV history."}
    index = idx["series"]
    gilt, gold = _series("gilt"), _series("gold")
    fx = _fx_monthly()

    readings = [_drawdown_reading(index), _trend_reading(index)]
    if gilt:
        readings.append(_relative_reading(index, gilt["series"], code="equity_vs_debt", name="Equity against debt, three years",
                                          a_label="equity", b_label="debt"))
    if gold:
        readings.append(_relative_reading(gold["series"], index, code="gold_vs_equity", name="Gold against equity, one year",
                                          a_label="gold", b_label="equity", months=12))
    readings.append(_rupee_reading(fx, index))
    readings = [r for r in readings if r]

    try:
        val = market.valuation()
    except Exception:
        val = None

    live_permits = _permits(_gated(readings, live=True), val)
    would = _permits(_gated(readings, live=False), val)
    live_by = {p["permit"]: p for p in live_permits}
    shadow = [{"permit": p["permit"], "would_be": p["value"], "is": (live_by.get(p["permit"]) or {}).get("value"),
               "why": ("This rule's edge did not hold in both halves of the record on its own, so it runs in shadow: "
                       "what it would have done is logged daily, and it is allowed to speak only once it passes.")}
              for p in would if p["permit"] in ("deployment", "equity_tilt_pts", "gold_tilt_pts")
              and (live_by.get(p["permit"]) or {}).get("value") != p["value"]]
    _log(index[-1][0], readings, live_permits, shadow)

    return {
        "readable": True,
        "as_of": index[-1][0].isoformat(),
        "sources": {k: {"name": s["name"], "code": s["code"], "from": s["series"][0][0].isoformat(), "months": len(s["series"])}
                    for k, s in (("index", idx), ("gilt", gilt), ("gold", gold)) if s},
        "readings": readings,
        "permits": live_permits,
        "shadow": shadow,
        "principle": ("Nothing here is a forecast. Each reading states what followed months like this one across the whole "
                      "record we hold, with the sample size; a reading with no edge issues no permit, and an edge must hold in "
                      "each half of the record on its own before it may speak — otherwise it runs in shadow, logged, until it does. The permits are small on "
                      "purpose — the pace of new money and a few points inside the band — because that is all the record supports, "
                      "and the one live test of bigger timing bets in retail advice was shut after losing to the index."),
    }
