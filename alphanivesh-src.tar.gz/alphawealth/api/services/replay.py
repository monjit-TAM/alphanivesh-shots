"""Will I get there?

Answered from what happened, not from what might.

**Every goal calculator does the same thing.** Assume twelve per cent a year,
compound it, draw a smooth curve arriving at ₹2.4 crore in 2045. One assumed
rate, no distribution, no acknowledgement that the rate is a guess — and the
curve is smooth, which no portfolio has ever been.

This replays instead. For a goal N years out funded by a particular mix: take
every historical month for which N years of data exist, run that mix and those
contributions through what actually happened, and see where each one finished.
That gives a distribution of outcomes, all of which occurred.

> Starting from every month since 2013, that combination reached the target in
> 71% of five-year stretches. In the worst tenth it fell short by ₹38 lakh. The
> median finish was ₹2.9 crore. There were 104 such stretches.

**Where the data will not support the question, it refuses.** Thirteen years of
NAV history gives honest windows up to about ten years and nothing beyond. A
twenty-year retirement goal cannot be answered with twenty-year windows and the
module says so rather than quietly extrapolating — which is the same refusal
the XIRR makes below six cashflows and the projection makes on an exceptional
run.

**And the sample size is always on the screen.** A base rate from forty windows
and one from four hundred are different claims, and a reader is entitled to
know which they are being given.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.replay")

# The fewest windows worth calling a base rate.
#
# Twelve is thin and stated as thin; below it the spread is more about which
# months happened to be in the sample than about the strategy, and quoting a
# percentage from it would give a number the authority of a statistic without
# the substance of one.
FEWEST_WINDOWS = 12

# How much history each horizon needs before the question can be asked at all.
NEED_YEARS_FOR = {1: 3, 3: 5, 5: 7, 7: 9, 10: 12}


def _d(value: Any) -> Decimal:
    try:
        return Decimal(str(value)) if value is not None else Decimal(0)
    except (InvalidOperation, ValueError):
        return Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("\u20B9" if not negative else "-\u20B9") + digits


# ---------------------------------------------------------------------------
# The series a mix of holdings would have followed
# ---------------------------------------------------------------------------

# A short memo, because the competition view replays several goals and their
# what-ifs in one request and the same fund's series should be fetched once.
_SERIES_MEMO: dict[str, tuple[float, list]] = {}
_SERIES_MEMO_SECONDS = 600


def _monthly_series(code: str) -> list[tuple[date, Decimal]]:
    """A fund's month-end NAVs, oldest first (memoised for ten minutes).

    Month ends rather than every day: a replay stepping daily over thirteen
    years and a hundred starting points is a lot of arithmetic for a question
    whose answer does not change, and monthly is how contributions actually
    arrive.
    """
    from . import dataservice
    import time

    hit = _SERIES_MEMO.get(code)
    if hit and time.monotonic() - hit[0] < _SERIES_MEMO_SECONDS:
        return hit[1]

    try:
        payload = dataservice.nav_history(code, days=0)
    except Exception as err:
        log.warning("no history for %s: %s", code, err)
        return []

    rows = payload.get("data") or []
    if not rows:
        return []

    by_month: dict[str, tuple[date, Decimal]] = {}
    for row in rows:
        try:
            when = datetime.strptime(row["date"], "%d-%m-%Y").date()
        except (ValueError, KeyError):
            continue
        nav = _d(row.get("nav"))
        if nav <= 0:
            continue
        key = f"{when.year}-{when.month:02d}"
        # The rows come newest first, so the first one seen in a month is its
        # latest date -- which is the month end we want.
        if key not in by_month:
            by_month[key] = (when, nav)

    out = sorted(by_month.values(), key=lambda pair: pair[0])
    _SERIES_MEMO[code] = (time.monotonic(), out)
    return out


def _mix_series(mix: list[dict]) -> tuple[list[date], list[Decimal]]:
    """One series for a weighted mix of funds.

    Rebased so each fund starts at 1 and weighted by its share, which gives
    the return of the combination rather than of any one holding. Where the
    funds start at different dates the series begins at the latest of them --
    a mix cannot be replayed over a period when part of it did not exist.
    """
    series = []
    for holding in mix:
        code = holding.get("code")
        weight = _d(holding.get("weight"))
        if not code or weight <= 0:
            continue
        points = _monthly_series(code)
        if len(points) < 24:
            log.info("skipping %s: only %d months", code, len(points))
            continue
        series.append((weight, points))

    if not series:
        return [], []

    # The common stretch.
    starts = [points[0][0] for _, points in series]
    ends = [points[-1][0] for _, points in series]
    from_date, to_date = max(starts), min(ends)

    months: list[date] = []
    values: list[Decimal] = []

    total_weight = sum((weight for weight, _ in series), Decimal(0))
    if total_weight <= 0:
        return [], []

    # Every month present in all of them.
    common = None
    for _, points in series:
        keys = {(when.year, when.month) for when, _ in points
                if from_date <= when <= to_date}
        common = keys if common is None else (common & keys)

    for year, month in sorted(common or []):
        level = Decimal(0)
        for weight, points in series:
            first = next((nav for when, nav in points if when >= from_date), None)
            here = next((nav for when, nav in points
                         if when.year == year and when.month == month), None)
            if not first or not here or first <= 0:
                level = Decimal(0)
                break
            level += (here / first) * (weight / total_weight)
        if level > 0:
            months.append(date(year, month, 1))
            values.append(level)

    return months, values


# ---------------------------------------------------------------------------
# The replay
# ---------------------------------------------------------------------------

def how_it_went(mix: list[dict], *, years: float, starting_with: Any,
                monthly: Any, step_up_pct: Any = 0,
                target: Any = 0, fx: Optional[dict] = None) -> dict:
    """Run this plan through every stretch of history that is long enough.

    `mix` is a list of {code, weight}. `years` is the horizon. The rest is what
    somebody has and what they are adding.

    `fx`, for a goal priced in another currency: {"levels": {(year, month):
    rupees-per-unit}, "currency": "USD"}. `target` is then the rupee cost at
    today's rate, and in each historical stretch it is moved by what the rupee
    did across that same stretch -- so a plan is judged against the dollar
    bill it would actually have faced, not against today's rupee figure.

    Returns the distribution, the sample size, and a refusal where the history
    cannot carry the question.
    """
    horizon = int(round(years))
    starting = _d(starting_with)
    contribution = _d(monthly)
    step_up = _d(step_up_pct)
    goal = _d(target)

    months, levels = _mix_series(mix)

    if not levels:
        return {"drawable": False,
                "why": ("We do not hold enough history for what this money is "
                        "in to say how it has behaved. That is about our "
                        "records rather than about the holdings.")}

    have_years = len(levels) / 12
    need = NEED_YEARS_FOR.get(horizon, horizon + 2)

    if have_years < horizon:
        return {
            "drawable": False,
            "horizon_years": horizon,
            "history_years": round(have_years, 1),
            "why": (f"This goal is {horizon} years out and we hold "
                    f"{have_years:.0f} years of history for what the money is "
                    f"in. Answering it would mean extrapolating past what we "
                    f"can actually see, which is the thing every projection "
                    f"does and this one will not."),
            "what_would_help": _what_would_help(horizon, have_years),
        }

    steps = horizon * 12
    finishes: list[Decimal] = []
    # The rupee cost of the goal at the end of each stretch. Equal to `goal`
    # everywhere unless the goal is in another currency.
    goals_at_end: list[Decimal] = []
    fx_levels = (fx or {}).get("levels") or {}
    fx_windows = 0

    for start in range(0, len(levels) - steps):
        pot = starting
        putting_in = contribution

        goal_here = goal
        if goal > 0 and fx_levels:
            a = fx_levels.get((months[start].year, months[start].month))
            b = fx_levels.get((months[start + steps].year, months[start + steps].month))
            if a and b and a > 0:
                goal_here = goal * (b / a)
                fx_windows += 1

        for step in range(steps):
            here = levels[start + step]
            nxt = levels[start + step + 1]
            if here <= 0:
                pot = Decimal(0)
                break
            pot = pot * (nxt / here) + putting_in
            # The step-up applies on the anniversary, which is how somebody
            # who says "I will raise it ten per cent a year" actually does it.
            if step and step % 12 == 0 and step_up > 0:
                putting_in = putting_in * (1 + step_up / 100)

        finishes.append(pot)
        goals_at_end.append(goal_here)

    if len(finishes) < FEWEST_WINDOWS:
        return {
            "drawable": False,
            "windows": len(finishes),
            "why": (f"There are only {len(finishes)} stretches of "
                    f"{horizon} years in the history we hold, which is too few "
                    f"to call a rate. A percentage from that few would have "
                    f"the authority of a statistic without the substance."),
            "what_would_help": _what_would_help(horizon, have_years),
        }

    # Judged stretch by stretch before sorting, because with a moving goal
    # the finish and the bill belong to the same stretch.
    reached = [f for f, g in zip(finishes, goals_at_end) if goal <= 0 or f >= g]
    shortfalls = sorted(max(Decimal(0), g - f) for f, g in zip(finishes, goals_at_end))
    finishes.sort()

    def at(fraction: float) -> Decimal:
        return finishes[min(len(finishes) - 1,
                            max(0, int(len(finishes) * fraction)))]

    worst, tenth, median, best = (finishes[0], at(0.10), at(0.50),
                                  finishes[-1])
    reached_pct = (Decimal(len(reached)) / len(finishes) * 100)

    return {
        "drawable": True,
        "horizon_years": horizon,
        "windows": len(finishes),
        "history_years": round(have_years, 1),
        "from": months[0].isoformat() if months else None,
        "to": months[-1].isoformat() if months else None,

        "reached_pct": str(reached_pct.quantize(Decimal("0.1"))),
        "reached": len(reached),

        "worst": str(worst.quantize(Decimal("1"))),
        "tenth": str(tenth.quantize(Decimal("1"))),
        "median": str(median.quantize(Decimal("1"))),
        "best": str(best.quantize(Decimal("1"))),

        "worst_shortfall": (str(shortfalls[-1].quantize(Decimal("1"))) if goal else None),
        "tenth_shortfall": (str(shortfalls[min(len(shortfalls) - 1,
                                               int(len(shortfalls) * 0.90))]
                                .quantize(Decimal("1"))) if goal else None),
        "goal_moved_with": ((fx or {}).get("currency") if fx_windows else None),
        "goal_at_end_median": (str(sorted(goals_at_end)[len(goals_at_end) // 2]
                                   .quantize(Decimal("1"))) if fx_windows else None),

        "thin": len(finishes) < 40,
        "reading": _reading(reached_pct, len(finishes), horizon, goal,
                            worst, tenth, median,
                            short_at_tenth=(shortfalls[min(len(shortfalls) - 1,
                                                           int(len(shortfalls) * 0.90))]
                                            if goal else Decimal(0))),
        "what_this_is": (
            f"Every {horizon}-year stretch in the history we hold, run with "
            f"the money you have and what you are adding. These are outcomes "
            f"that happened, not a forecast — and the future does not have to "
            f"resemble any of them."),
    }


def _what_would_help(horizon: int, have: float) -> str:
    return (f"A shorter horizon can be answered today: we hold "
            f"{have:.0f} years, so anything up to about {max(1, int(have) - 2)} "
            f"years has enough stretches behind it. For {horizon} years we "
            f"would need a longer index series than the fund data goes back.")


def _reading(reached_pct: Decimal, windows: int, horizon: int,
             goal: Decimal, worst: Decimal, tenth: Decimal,
             median: Decimal, short_at_tenth: Optional[Decimal] = None) -> str:
    thin = " That is a thin sample and worth treating as one." if windows < 40 else ""

    if goal <= 0:
        return (f"Across {windows} stretches of {horizon} years, the middle "
                f"outcome was {_money(median)}. The worst was {_money(worst)} "
                f"and the best rather more.{thin}")

    if short_at_tenth is None:
        short_at_tenth = max(Decimal(0), goal - tenth)

    if reached_pct >= 99:
        # Where even the worst stretch cleared the target, say by how much
        # rather than "came close" -- which was the wording and was wrong by
        # eight lakh in the direction that flatters us.
        over = worst - goal
        return (f"This reached the target in every one of the {windows} "
                f"stretches of {horizon} years we can look at. The worst of "
                f"them still finished {_money(over)} above it — which is worth "
                f"reading as the plan being comfortable rather than as a "
                f"promise, because the future does not have to resemble any of "
                f"those stretches.{thin}")

    if reached_pct >= 90:
        return (f"This reached the target in {reached_pct.quantize(Decimal('0.1'))}% "
                f"of the {windows} stretches of {horizon} years we can look at. "
                f"The worst finished {_money(worst)} against the "
                f"{_money(goal)} needed.{thin}")

    if reached_pct >= 60:
        return (f"This reached the target in {reached_pct.quantize(Decimal('0.1'))}% "
                f"of {windows} stretches of {horizon} years. In the worst tenth "
                f"it finished {_money(short_at_tenth)} short — which is the "
                f"number worth planning around rather than the middle one.{thin}")

    if reached_pct >= 25:
        return (f"This reached the target in only "
                f"{reached_pct.quantize(Decimal('0.1'))}% of {windows} stretches. "
                f"More often than not it did not get there, and in the worst "
                f"tenth it was {_money(short_at_tenth)} short. Either the "
                f"target, the date or the monthly amount has to move.{thin}")

    return (f"This reached the target in {reached_pct.quantize(Decimal('0.1'))}% "
            f"of {windows} stretches — almost never. The plan as it stands does "
            f"not get there on any history we can see, and no rate of return "
            f"worth assuming would change that.{thin}")


# ---------------------------------------------------------------------------
# For a goal
# ---------------------------------------------------------------------------

def for_goal(goal_id: str, *, holdings: Optional[list[dict]] = None,
             monthly_override: Any = None) -> dict:
    """Replay what is earmarked to a goal against its own horizon.

    `holdings` replaces what is actually earmarked (a list of
    {instrument_id, name, worth}) and `monthly_override` replaces the
    committed contribution -- for the competition view, which asks what a
    goal's odds would be if it had a different share of a holding or a smaller
    monthly. Neither is stored; the answer is to a question, not a change.
    """
    from . import earmarks, currency

    goal = db.fetch_one(
        "SELECT * FROM goal WHERE id = %s AND abandoned_at IS NULL",
        (goal_id,))
    if not goal:
        return {"drawable": False, "why": "No such goal."}

    if holdings is None:
        held = earmarks.holdings_for(goal_id)
    else:
        total = sum((_d(h.get("worth")) for h in holdings), Decimal(0))
        held = {"holdings": [h for h in holdings if _d(h.get("worth")) > 0],
                "count": len(holdings), "worth": str(total)}
    if not held["holdings"]:
        return {"drawable": False,
                "why": ("Nothing is earmarked to this goal yet, so there is no "
                        "mix to replay. Assign some holdings to it first.")}

    # Only funds can be replayed: a fund has a NAV series and a single share
    # does not, through this data service. Said plainly rather than silently
    # dropping them.
    mix, skipped = [], []
    total = _d(held["worth"])

    for holding in held["holdings"]:
        code = _scheme_code(holding["instrument_id"])
        if not code:
            skipped.append(holding["name"])
            continue
        mix.append({"code": code,
                    "weight": _d(holding["worth"]) / total if total else 0})

    if not mix:
        # Two different reasons and they need different sentences: a portfolio
        # of shares cannot be replayed through fund data, and a fund we cannot
        # match to a scheme code is our record-keeping rather than their
        # holding.
        return {
            "drawable": False,
            "why": _why_nothing_to_replay(held["holdings"]),
            "skipped": skipped,
        }

    years = (goal["target_date"] - date.today()).days / 365.25
    monthly = db.fetch_one(
        "SELECT monthly, step_up_pct FROM goal_contribution "
        "WHERE goal_id = %s AND ended_on IS NULL", (goal_id,)) or {}
    if monthly_override is not None:
        monthly = {"monthly": monthly_override,
                   "step_up_pct": monthly.get("step_up_pct") or 0}

    # A goal in another currency is replayed against its rupee cost, moved by
    # what the rupee did in each stretch. Without a rate we still replay the
    # money, but against no target -- a distribution rather than a verdict.
    target_inr, fx, fx_note = goal["target_amount"], None, None
    if currency.is_foreign(goal["currency"]):
        now = currency.today(goal["currency"])
        if now:
            target_inr = _d(goal["target_amount"]) * _d(now["rate"])
            fx = {"currency": goal["currency"].upper(),
                  "levels": {(d.year, d.month): r
                             for d, r in currency.monthly_levels(goal["currency"])}}
            fx_note = (f"The target is {goal['currency']} "
                       f"{_d(goal['target_amount']):,.0f}: {_money(target_inr)} at "
                       f"the {now['as_of']} fixing. In each stretch below it is "
                       f"moved by what the rupee did over that same stretch, so "
                       f"'reached' means reached the bill as it would have been.")
        else:
            target_inr = 0
            fx_note = (f"The target is in {goal['currency']} and we hold no rupee "
                       f"rate for it, so this shows what the money did without "
                       f"judging it against the target.")

    result = how_it_went(
        mix,
        years=max(1, years),
        starting_with=held["worth"],
        monthly=monthly.get("monthly") or 0,
        step_up_pct=monthly.get("step_up_pct") or 0,
        target=target_inr,
        fx=fx)
    if fx_note:
        result["currency_note"] = fx_note

    if skipped:
        result["skipped"] = skipped
        result["on_skipped"] = (
            f"{len(skipped)} of the earmarked holdings are shares and are not "
            f"in this — we hold the day-by-day record for funds. The figures "
            f"above describe the rest.")

    return result


def _why_nothing_to_replay(holdings: list[dict]) -> str:
    kinds = {h.get("asset_class") for h in holdings}
    funds = kinds & {"mutual_fund", "etf"}

    if not funds:
        return ("What is earmarked here is shares rather than funds, and the "
                "day-by-day record we hold is for funds. The holdings are "
                "fine; we cannot replay them.")

    return ("These are funds, and we could not match them to the scheme codes "
            "the historical record is kept under. That is our record-keeping "
            "rather than anything about what you hold.")


def _scheme_code(instrument_id: str) -> Optional[str]:
    """The AMFI code for an instrument, where it is a fund.

    `native_code`, not `symbol`. Symbol is empty on most funds here and the
    code that appears at the front of the display name is the AMC's own, not
    AMFI's -- so reading it from there produced "these are shares" about three
    mutual funds, which is the kind of confident wrong statement this product
    exists not to make.
    """
    row = db.fetch_one(
        "SELECT native_code, asset_class, nav_earliest FROM instruments "
        "WHERE id = %s",
        (instrument_id,))
    if not row or row["asset_class"] not in ("mutual_fund", "etf"):
        return None
    code = (row["native_code"] or "").strip()
    return code if code.isdigit() else None
