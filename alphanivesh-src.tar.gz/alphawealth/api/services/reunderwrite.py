"""The yearly re-underwrite: every holding older than seven years, read again.

A share bought in 2015 for the market of 2015, a fund chosen when its
manager and mandate were different -- the question each year is not whether
it was a good decision then, but whether it would be bought today. One line
per holding, from its own record:

  shares   the topped test (distance from its high, relative strength,
           earnings) -- earning its place / tiring / topped -- and the tax
           to exit
  funds    where it ranks in its category today on the rolling three-year
           record, and whether a direct plan of it exists

Nothing here is an order. The plan acts on what is topped or in the bottom
half; this is the annual reading that says why everything else stays.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any

log = logging.getLogger(__name__)

LEGACY_YEARS = 7
LTCG_RATE = Decimal("12.5")
LTCG_EXEMPT = Decimal(125000)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def for_investor(investor_id: str, years: int = LEGACY_YEARS) -> dict:
    from . import alpha, plans, topped, wealth
    holdings = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    first = alpha._first_bought(investor_id)
    codes = alpha._instrument_codes([h["instrument_id"] for h in holdings])
    idx12 = topped.index_twelve_month()
    today = date.today()
    rows, young, skipped = [], 0, 0
    for h in holdings:
        b = alpha.bucket_of(h)[0]
        if b not in ("equity",):
            continue
        bought = first.get(h["instrument_id"])
        if not bought:
            skipped += 1
            continue
        held = (today - bought).days / 365.25
        if held < years:
            young += 1
            continue
        value, gain = _d(h["current_value"]), _d(h.get("gain") or (_d(h["current_value"]) - _d(h.get("invested_value"))))
        tax = max(Decimal(0), gain - LTCG_EXEMPT) * LTCG_RATE / 100 if gain > 0 else Decimal(0)
        row = {"name": h.get("instrument_name"), "held_years": round(held, 1), "since": bought.isoformat(),
               "value": str(value.quantize(Decimal("1"))), "gain": str(gain.quantize(Decimal("1"))),
               "tax_to_exit": str(tax.quantize(Decimal("1")))}
        if (h.get("asset_class") or "") == "equity":
            try:
                t = topped.test(h, idx12)
            except Exception as err:
                t = {"readable": False, "why": str(err)}
            row.update({"kind": "share", "verdict": t.get("verdict") if t.get("readable") else "unreadable",
                        "say": t.get("say") if t.get("readable") else (t.get("why") or "Its record is not readable here.")})
        else:
            c = codes.get(h["instrument_id"]) or {}
            rank = alpha._fund_rank(c.get("native_code"), c.get("category") or h.get("category") or "")
            regular = alpha._is_regular(h)
            twin = plans.find_direct_twin(h.get("instrument_name") or "", c.get("category")) if regular else None
            if rank and rank.get("rank") and rank.get("of"):
                pos = _d(rank["rank"]) / _d(rank["of"]) * 100
                verdict = "earning its place" if pos <= 50 else "fallen"
                say = (f"Ranked {rank['rank']} of {rank['of']} in its category on the rolling three-year record — "
                       + ("in the top half; it stays." if pos <= 50 else
                          "in the bottom half. The plan switches it to the top of its category."))
            else:
                verdict, say = "unreadable", "Its category rank is not readable here."
            if regular:
                say += (f" Still in the regular plan; {'the direct plan is ' + twin['name'] + '.' if twin else 'switch to direct.'}")
            row.update({"kind": "fund", "verdict": verdict, "say": say})
        rows.append(row)

    order = {"topped": 0, "fallen": 1, "tiring": 2, "unreadable": 3, "earning its place": 4}
    rows.sort(key=lambda r: (order.get(r["verdict"], 5), -_d(r["value"])))
    act = [r for r in rows if r["verdict"] in ("topped", "fallen")]
    tiring = [r for r in rows if r["verdict"] == "tiring"]
    earning = [r for r in rows if r["verdict"] == "earning its place"]
    if rows:
        parts = [f"{len(rows)} holding{'s' if len(rows) != 1 else ''} older than {years} years."]
        if act:
            parts.append(f"{len(act)} {'have' if len(act) != 1 else 'has'} stopped earning {'their' if len(act) != 1 else 'its'} place "
                         f"({', '.join(r['name'] for r in act[:3])}); the plan acts on {'them' if len(act) != 1 else 'it'}.")
        if tiring:
            parts.append(f"{len(tiring)} {'are' if len(tiring) != 1 else 'is'} tiring ({', '.join(r['name'] for r in tiring[:3])}): "
                         f"not a sell, but the next reading that turns makes it one.")
        if earning:
            parts.append(f"{len(earning)} still earn{'s' if len(earning) == 1 else ''} {'their' if len(earning) != 1 else 'its'} place and stay{'s' if len(earning) == 1 else ''}.")
        reading = " ".join(parts)
    else:
        reading = (f"Nothing held is older than {years} years, as far as our records go"
                   + (f"; {skipped} holding{'s' if skipped != 1 else ''} carry no date at all." if skipped else "."))
    return {"years": years, "rows": rows, "to_act": len(act), "younger": young, "undated": skipped, "reading": reading,
            "principle": ("Once a year, every holding older than seven years is read again from its own record: would it be "
                          "bought today? Dates are the earliest we have seen it, which can only make a holding look younger "
                          "than it is.")}
