"""Household stress: what the actual holdings did, or would do, in a bad stretch.

Aladdin re-prices a household's holdings through 2008; Empower replays the
dot-com and 2008 drawdowns against a plan. Retail India has nothing of the
kind, and the question it answers is the one people ask in the fall itself:
"how much of my money goes, and how long until it comes back?"

Two kinds of stress, said apart:

  replayed    2008 (the top of January 2008 to the trough of March 2009) and
              2020 (February to March) -- each holding re-priced by its own
              NAV where it existed then, otherwise by the proxy for its
              bucket (the oldest Nifty index fund, gilt fund, gold fund).
              Recovery is counted from the proxy: months until the pre-fall
              level was seen again.
  hypothetical  the rupee -15% and rates +200 basis points -- not history,
              arithmetic: a rupee fall lifts gold and foreign-currency bills
              and leaves rupee equity roughly where it was; a rate rise costs
              a debt fund its duration times the rise.

Every figure is of the holdings as they are now, in today's rupees. None of
it says it will happen; it says what it would cost if it did, which is the
number that decides whether the debt bucket is big enough.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

log = logging.getLogger(__name__)

EPISODES = [
    # Month keys hold that month's last NAV, so "2007-12" is the end of December 2007 -- the top -- and
    # "2009-02" the end of February 2009, the bottom. Keyed any later and the fall is understated.
    {"code": "2008", "name": "2008–09: the global financial crisis", "start": date(2007, 12, 1), "end": date(2009, 2, 1),
     "say": "The index lost more than half from its January 2008 high to March 2009 and took about two years to see the high again."},
    {"code": "2020", "name": "2020: the Covid crash", "start": date(2020, 1, 1), "end": date(2020, 3, 1),
     "say": "A third of the index gone in five weeks, and back above the high by November — the fastest fall and recovery on the record."},
]
DURATION_BY_WORD = (("liquid", 0.1), ("overnight", 0.0), ("ultra short", 0.4), ("low duration", 0.8), ("money market", 0.5),
                    ("short duration", 2.2), ("corporate bond", 2.8), ("banking", 3.0), ("credit", 2.5), ("floater", 0.5),
                    ("gilt", 7.0), ("long duration", 9.0), ("dynamic", 5.0), ("medium", 4.0), ("income", 4.0))
RATE_SHOCK = Decimal("0.02")
RUPEE_SHOCK = Decimal("-0.15")


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v); sign = "-" if v < 0 else ""; v = abs(v)
    if v >= 10000000:
        return f"{sign}₹{v / 10000000:.2f} crore"
    if v >= 100000:
        return f"{sign}₹{v / 100000:.1f} lakh"
    return f"{sign}₹{v:,.0f}"


def _move(series: list[tuple[date, float]], start: date, end: date) -> Optional[float]:
    by = {d: v for d, v in series}
    if start not in by or end not in by:
        return None
    return by[end] / by[start] - 1


def _recovery_months(series: list[tuple[date, float]], start: date) -> Optional[int]:
    by = {d: v for d, v in series}
    if start not in by:
        return None
    level = by[start]
    for d, v in series:
        if d > start and v >= level:
            return (d.year - start.year) * 12 + (d.month - start.month)
    return None


def _fund_monthly(code: str) -> list[tuple[date, float]]:
    from . import regime
    from . import dataservice
    try:
        rows = (dataservice.nav_history(code, days=0) or {}).get("data") or []
    except Exception:
        return []
    return regime._monthly_from_navs(rows)


def _duration(name: str, category: str) -> float:
    text = f"{category} {name}".lower()
    for word, dur in DURATION_BY_WORD:
        if word in text:
            return dur
    return 3.0


def _reading(worst: Optional[dict], total: Decimal, debt_cash: Decimal) -> str:
    if not worst:
        return "Not enough history on the proxies to replay a crisis."
    loss = _d(worst["loss"])
    if loss >= 0:
        return (f"Neither replayed crisis costs these holdings money as they stand, because so little of it is in equity. "
                f"That is safety, and it has a price of its own over the years you have.")
    enough = debt_cash >= abs(loss)
    return (f"In a {worst['code']} again, about {_money(abs(loss))} of today's {_money(total)} goes — "
            f"{abs(_d(worst['loss_pct'])):.0f}% — and it is the {_money(debt_cash)} of debt and cash that decides whether you can sit "
            f"through it and buy, or have to sell at the bottom. "
            + ("That is enough." if enough else "That is less than the fall; the plan's debt target is why."))


def for_investor(investor_id: str) -> dict:
    from . import alpha, regime, wealth
    from .. import db
    holdings = [h for h in wealth.holdings(investor_id) if _d(h.get("current_value")) > 0]
    holdings = [h for h in holdings if alpha.bucket_of(h)[0] != "outside"]
    if not holdings:
        return {"drawable": False, "why": "No holdings to stress yet."}
    total = sum(_d(h["current_value"]) for h in holdings)
    codes = {r["id"]: r for r in db.fetch_all(
        "SELECT id, native_code, category FROM instruments WHERE id = ANY(%s)", ([h["instrument_id"] for h in holdings],))}
    proxies = {k: (regime._series(k) or {}).get("series") or [] for k in ("index", "gilt", "gold")}
    proxy_for = {"equity": "index", "debt": "gilt", "gold": "gold", "cash": None}

    # Foreign-currency goal bills, for the rupee shock.
    foreign_bills = db.fetch_all(
        "SELECT name, currency, target_amount FROM goal WHERE investor_id = %s AND abandoned_at IS NULL AND currency <> 'INR'",
        (investor_id,)) or []

    episodes = []
    for ep in EPISODES:
        loss, by_bucket, rows, own = Decimal(0), {}, [], 0
        for h in holdings:
            b, share = alpha.bucket_of(h)
            v = _d(h["current_value"])
            move = None; source = "proxy"
            code = (codes.get(h["instrument_id"]) or {}).get("native_code")
            if (h.get("asset_class") or "") == "mutual_fund" and code:
                m = _move(_fund_monthly(code), ep["start"], ep["end"])
                if m is not None:
                    move, source = m, "its own NAV"; own += 1
            if move is None:
                if b == "cash":
                    move = 0.0
                else:
                    pk = proxy_for.get(b)
                    move = _move(proxies.get(pk) or [], ep["start"], ep["end"]) if pk else None
                    if move is not None and b == "equity" and share < 1:
                        move = move * float(share)
            if move is None:
                continue
            delta = v * Decimal(str(move))
            loss += delta
            by_bucket[b] = by_bucket.get(b, Decimal(0)) + delta
            rows.append({"name": h.get("instrument_name"), "bucket": b, "value": str(v.quantize(Decimal("1"))),
                         "move_pct": round(move * 100, 1), "rupees": str(delta.quantize(Decimal("1"))), "source": source})
        rows.sort(key=lambda r: _d(r["rupees"]))
        rec = _recovery_months(proxies["index"], ep["start"])
        episodes.append({
            "code": ep["code"], "name": ep["name"], "context": ep["say"],
            "loss": str(loss.quantize(Decimal("1"))), "loss_pct": str((loss / total * 100).quantize(Decimal("0.1"))) if total else "0",
            "by_bucket": {k: str(v.quantize(Decimal("1"))) for k, v in by_bucket.items()},
            "worst": rows[:5], "repriced_by_own_nav": own, "recovery_months_index": rec,
            "say": (f"Your holdings as they stand would have {'lost' if loss < 0 else 'gained'} about {_money(abs(loss))} ({abs(loss / total * 100):.0f}%) — "
                    + (f"{_money(abs(by_bucket.get('equity', 0)))} of it in equity" if by_bucket.get("equity") else "")
                    + (f", with debt {'adding' if by_bucket.get('debt', 0) > 0 else 'losing'} {_money(abs(by_bucket.get('debt', 0)))}" if by_bucket.get("debt") else "")
                    + (f" and gold {'adding' if by_bucket.get('gold', 0) > 0 else 'losing'} {_money(abs(by_bucket.get('gold', 0)))}" if by_bucket.get("gold") else "")
                    + f". The index took {rec} months to see its old high again." if rec else "."),
        })

    # Hypotheticals.
    gold = sum(_d(h["current_value"]) for h in holdings if alpha.bucket_of(h)[0] == "gold")
    intl = sum(_d(h["current_value"]) for h in holdings if any(w in (h.get("instrument_name") or "").lower()
                                                               for w in ("international", "us equity", "nasdaq", "s&p", "global", "overseas")))
    rupee_gain = (gold + intl) * abs(RUPEE_SHOCK)
    bills = []
    for g in foreign_bills:
        bills.append({"name": g["name"], "currency": g["currency"], "costs_more_pct": str(abs(RUPEE_SHOCK * 100))})
    debt_loss, debt_rows = Decimal(0), []
    for h in holdings:
        if alpha.bucket_of(h)[0] != "debt" or (h.get("asset_class") or "") != "mutual_fund":
            continue
        dur = _duration(h.get("instrument_name") or "", (codes.get(h["instrument_id"]) or {}).get("category") or "")
        d = -_d(h["current_value"]) * Decimal(str(dur)) * RATE_SHOCK
        debt_loss += d
        debt_rows.append({"name": h.get("instrument_name"), "duration_years": dur, "rupees": str(d.quantize(Decimal("1")))})
    debt_rows.sort(key=lambda r: _d(r["rupees"]))
    hypotheticals = [
        {"code": "rupee", "name": "The rupee falls 15%",
         "effect": str(rupee_gain.quantize(Decimal("1"))),
         "say": (f"Gold and foreign holdings gain about {_money(rupee_gain)} in rupee terms; rupee equity and debt are roughly unchanged on the day. "
                 + (f"The bills in another currency — {', '.join(b['name'] for b in bills)} — cost 15% more in rupees." if bills else
                    "You have no bills in another currency, so nothing you are saving for gets dearer.")),
         "bills": bills},
        {"code": "rates", "name": "Interest rates rise 2 points",
         "effect": str(debt_loss.quantize(Decimal("1"))),
         "say": (f"Debt funds mark down by their duration: about {_money(abs(debt_loss))} across them, most of it in the longer ones. "
                 f"It is a mark, not a loss — the income catches up over the duration — but it is why money needed soon sits in the short ones."
                 if debt_rows else "No debt funds to mark down. EPF, PPF and deposits do not re-price."),
         "rows": debt_rows[:5]},
    ]

    debt_cash = sum(_d(h["current_value"]) for h in holdings if alpha.bucket_of(h)[0] in ("debt", "cash"))
    worst = min(episodes, key=lambda e: _d(e["loss"])) if episodes else None
    return {
        "drawable": True, "as_of": date.today().isoformat(), "total": str(total.quantize(Decimal("1"))),
        "episodes": episodes, "hypotheticals": hypotheticals,
        "proxies": {k: {"name": (regime._series(k) or {}).get("name"), "from": s[0][0].isoformat() if s else None} for k, s in proxies.items() if s},
        "reading": _reading(worst, total, debt_cash),
        "principle": ("Today's holdings re-priced by what each did — its own NAV where it existed then, the oldest index, gilt or gold "
                      "fund where it did not. Not a forecast of the next fall; the cost of the last ones, at today's size."),
    }
