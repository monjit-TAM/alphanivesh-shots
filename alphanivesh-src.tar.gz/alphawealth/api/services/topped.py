"""Has a long-held winner topped? Three facts, and a verdict only when they agree.

The question the plan was flagging but not answering: a share bought ten years
ago, sitting on most of the portfolio's gain, that the verdict engine still
reads as hold. Holding it is not wrong; holding it *because of the gain* is,
and the difference is whether its own record has turned. Three readings:

  1. Distance from its own high, and how long it has sat below it.
  2. Relative strength: its twelve-month move against the index's.
  3. Earnings: the latest year-on-year profit and revenue growth.

"Topped" means all three point the same way: well below its high for more
than a year, lagging the index by a wide margin, and earnings shrinking. Two
of three is "tiring" and is said, not acted on. One or none is "still
earning its place". The tax on acting is priced beside the verdict, because
a legacy winner is exactly where the tax is largest and a free-sounding
"trim" is not free.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

log = logging.getLogger(__name__)

BELOW_HIGH_PTS = Decimal(-20)     # this far below its high counts as "well below"
BELOW_FOR_MONTHS = 12
LAG_PTS = Decimal(-15)            # twelve-month move this far behind the index
LTCG_RATE = Decimal("12.5")
LTCG_EXEMPT = Decimal(125000)


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 10000000:
        return f"₹{v / 10000000:.2f} crore"
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


def _twelve_month_move(symbol: str) -> Optional[Decimal]:
    from . import dataservice
    try:
        bars = (dataservice.ohlcv(symbol, period="1y") or {}).get("data") or []
    except Exception:
        return None
    closes = [_d(b.get("close")) for b in bars if _d(b.get("close")) > 0]
    if len(closes) < 200:
        return None
    # Guard the unadjusted record: a step of a third in a day is a corporate action, not a move.
    for a, b in zip(closes, closes[1:]):
        if a > 0 and abs((b - a) / a) > Decimal("0.33"):
            return None
    return (closes[-1] / closes[0] - 1) * 100


def _high_reading(symbol: str) -> Optional[dict]:
    from . import navs
    try:
        dd = navs.equity_drawdown(symbol, period="5y")
    except Exception:
        return None
    if not dd or dd.get("stopped_at_corporate_action"):
        return None
    latest, peak_date = _d(dd.get("latest")), dd.get("fell_from")
    # equity_drawdown gives the worst fall; what we want is distance from the 5y high today.
    try:
        from . import dataservice
        bars = (dataservice.ohlcv(symbol, period="5y") or {}).get("data") or []
    except Exception:
        return None
    pts = []
    for b in bars:
        c = _d(b.get("close"))
        if c > 0 and b.get("date"):
            pts.append((str(b["date"])[:10], c))
    if len(pts) < 250:
        return None
    high = max(pts, key=lambda p: p[1])
    off = (pts[-1][1] / high[1] - 1) * 100
    try:
        months_below = (date.fromisoformat(pts[-1][0]) - date.fromisoformat(high[0])).days // 30
    except ValueError:
        months_below = None
    return {"off_high_pct": off, "high_on": high[0], "months_below": months_below}


def _earnings(symbol: str) -> Optional[dict]:
    from . import dataservice
    try:
        f = dataservice.fundamentals(symbol) or {}
    except Exception:
        return None
    data = f.get("data") if isinstance(f.get("data"), dict) else f
    pat = data.get("pat_growth_yoy"); rev = data.get("revenue_growth_yoy")
    if pat is None and rev is None:
        return None
    return {"pat_growth_yoy": _d(pat) if pat is not None else None, "revenue_growth_yoy": _d(rev) if rev is not None else None}


def test(holding: dict, index_twelve_month: Optional[Decimal]) -> dict:
    """The three readings and the verdict for one directly held share."""
    symbol = str(holding.get("symbol") or "").upper()
    if not symbol:
        return {"readable": False, "why": "No symbol on the holding."}
    high = _high_reading(symbol)
    move = _twelve_month_move(symbol)
    earn = _earnings(symbol)

    signs: list[tuple[str, bool, str]] = []
    if high:
        below = high["off_high_pct"] <= BELOW_HIGH_PTS and (high["months_below"] or 0) >= BELOW_FOR_MONTHS
        signs.append(("high", below,
                      f"{abs(high['off_high_pct']):.0f}% below its five-year high of {high['high_on'][:7]}"
                      + (f", {high['months_below']} months ago" if high.get("months_below") is not None else "")))
    if move is not None and index_twelve_month is not None:
        lag = move - index_twelve_month
        signs.append(("relative", lag <= LAG_PTS,
                      f"{move:+.0f}% over twelve months against the index's {index_twelve_month:+.0f}% ({lag:+.0f} points)"))
    if earn:
        shrinking = (earn.get("pat_growth_yoy") is not None and earn["pat_growth_yoy"] < 0) or \
                    (earn.get("revenue_growth_yoy") is not None and earn["revenue_growth_yoy"] < 0 and earn.get("pat_growth_yoy") is None)
        bits = []
        if earn.get("pat_growth_yoy") is not None:
            bits.append(f"profit {earn['pat_growth_yoy']:+.0f}% year on year")
        if earn.get("revenue_growth_yoy") is not None:
            bits.append(f"revenue {earn['revenue_growth_yoy']:+.0f}%")
        signs.append(("earnings", shrinking, ", ".join(bits)))

    if len(signs) < 2:
        return {"readable": False, "why": "Not enough of its record is readable to test it.", "signs": [s[2] for s in signs]}
    against = sum(1 for _, bad, _ in signs if bad)
    verdict = "topped" if against == len(signs) and against >= 2 else "tiring" if against >= 2 else "earning its place"

    gain = _d(holding.get("gain")); value = _d(holding.get("current_value"))
    tax = max(Decimal(0), gain - LTCG_EXEMPT) * LTCG_RATE / 100 if gain > 0 else Decimal(0)
    return {
        "readable": True, "verdict": verdict, "against": against, "of": len(signs),
        "signs": [{"what": k, "against": bad, "say": say} for k, bad, say in signs],
        "tax_to_exit": str(tax.quantize(Decimal("1"))),
        "say": (f"{verdict.capitalize()}: " + "; ".join(s[2] for s in signs) + ". "
                + ({"topped": f"All three point the same way. The gain is real and already yours; the question is whether it will be earned again, and the record says not. Exiting costs about {_money(tax)} in tax on {_money(gain)} of gain — a price worth paying once, not a reason to hold.",
                    "tiring": "Two of three point the same way. Not a sell; the next reading that turns makes it one, and the plan will say so.",
                    "earning its place": "Its own record has not turned. It stays, and the size is watched."}[verdict])),
    }


def index_twelve_month() -> Optional[Decimal]:
    from . import market
    try:
        pos = market.where_we_are() or {}
        v = (pos.get("moves") or {}).get("twelve_months")
        return _d(v) if v is not None else None
    except Exception:
        return None
