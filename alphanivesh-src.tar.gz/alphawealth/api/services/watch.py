"""The daily watch.

Watch every day, act rarely, explain always. That is what the best of the
industry actually does once the marketing is stripped off: Wealthfront checks
every taxable account every day and harvests only when the benefit clears the
cost; Betterment and Vanguard check drift daily and trade only past a band;
Schwab re-flags every goal every day. None of them trade hourly. None of them
promise a number. They watch, and they act when something crosses a line.

This module is the watching. Once a day, after the close, for each investor:

  drift      a bucket beyond its band (alpha.gaps)            → act
  ltcg_room  tax-free allowance unused, year ending            → act (Jan–Mar) / note
  ltcg_soon  a lot turning long-term within 45 days, in gain   → watch (do not sell it yet)
  loss_book  realisable losses that would offset gains         → note
  verdict    a held share's verdict crossed to sell            → act
  market     the index crossed -10% / -20% from its high       → note (a letter, not an order)
  goal       a goal's odds fell below the line                 → note
  idle       money beyond the cushion earning cash rates       → note

Each is a `watch_event` with a fingerprint. A condition that was already
open is touched (`last_seen_at`), not re-opened; one that no longer holds is
resolved. So the digest can say "still there since Tuesday" and never says
the same thing twice. Most days the honest digest is: checked, nothing
crossed a line -- and the page says that, with the time.
"""

from __future__ import annotations

import json
import logging
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger(__name__)

SOON_DAYS = 45                 # a lot this close to long-term is flagged "do not sell yet"
MARKET_LEVELS = (Decimal(-10), Decimal(-20))
GOAL_AT_RISK = Decimal(50)     # replay reached% below this → at risk
GOAL_OFF = Decimal(25)         # below this → off target
SMALLEST = Decimal(25000)      # below this a drift is noise

SEVERITY_ORDER = {"act": 0, "note": 1, "watch": 2}


def _d(v: Any) -> Decimal:
    try:
        return Decimal(str(v if v is not None else 0))
    except Exception:
        return Decimal(0)


def _money(v: Any) -> str:
    v = _d(v)
    if abs(v) >= 10000000:
        return f"₹{v / 10000000:.2f} crore"
    if abs(v) >= 100000:
        return f"₹{v / 100000:.1f} lakh"
    return f"₹{v:,.0f}"


# ---------------------------------------------------------------------------
# Finding the conditions
# ---------------------------------------------------------------------------

def _drift(investor_id: str) -> list[dict]:
    from . import alpha, wealth
    holdings = [h for h in wealth.holdings(investor_id)
                if _d(h.get("current_value")) > 0 and alpha.bucket_of(h)[0] != "outside"]
    if not holdings:
        return []
    target = alpha.target_for(investor_id)
    now = alpha.current_mix(holdings)
    out = []
    for g in alpha.gaps(target, now):
        if g["direction"] == "on target":
            continue
        rupees = abs(_d(g["rupees"]))
        if rupees < SMALLEST:
            continue
        bucket = g["bucket"]
        label = bucket.replace("equity:", "") + ("-cap equity" if ":" in bucket else "")
        out.append({
            "kind": "drift", "severity": "act" if ":" not in bucket else "note",
            "fingerprint": f"drift:{bucket}:{g['direction']}",
            "what": f"{label.title()} is {g['direction']} target",
            "why": (f"{_d(g['current_pct']):.1f}% against {_d(g['target_pct']):.1f}%, "
                    f"{_money(rupees)} {'too much' if g['direction'] == 'over' else 'short'}. "
                    + ("New money and SIPs go here first; a sale only if that is not enough and the tax is small."
                       if g["direction"] == "under" else
                       "The excess goes where the mix is short, from the lots with the least tax to pay.")),
            "size": rupees, "detail": g,
        })
    return out


def _tax(investor_id: str) -> list[dict]:
    from . import harvest
    out = []
    today = date.today()
    try:
        chance = harvest.opportunity(investor_id)
    except Exception as err:
        log.info("harvest unavailable for %s: %s", investor_id, err)
        chance = None
    if chance and chance.get("worth_doing"):
        months_left = int(chance.get("months_left") or 0)
        out.append({
            "kind": "ltcg_room", "severity": "act" if months_left <= 3 else "note",
            "fingerprint": f"ltcg_room:{today.year if today.month > 3 else today.year - 1}",
            "what": f"{_money(chance['available_gain'])} of tax-free gain unused this year",
            "why": (f"Worth {_money(chance['saving'])} in tax. Sell and buy back the same holding; "
                    f"the cost base resets and the gain stops being taxable later. "
                    f"{months_left} month{'s' if months_left != 1 else ''} to 31 March."),
            "size": _d(chance["saving"]), "detail": {"plan": chance.get("plan")},
        })

    try:
        held = harvest.positions(investor_id)
    except Exception:
        held = []
    for h in held:
        if h["long_term"] or h["gain"] <= 0:
            continue
        days = int(h["months_to_long_term"]) * 30
        if 0 < days <= SOON_DAYS:
            saving = h["gain"] * Decimal("0.075")   # 20% short vs 12.5% long on equity
            out.append({
                "kind": "ltcg_soon", "severity": "watch", "instrument_id": h["instrument_id"],
                "fingerprint": f"ltcg_soon:{h['instrument_id']}",
                "what": f"{h['name']} turns long-term in about {days} days",
                "why": (f"{_money(h['gain'])} of gain is short-term today, taxed at 20%; after the line it is 12.5%. "
                        f"Selling now costs about {_money(saving)} more than waiting."),
                "size": saving, "detail": {"days": days, "gain": str(h["gain"])},
            })

    try:
        under = harvest.losses(investor_id)
    except Exception:
        under = None
    if under and _d(under.get("saving")) >= 2000:
        out.append({
            "kind": "loss_book", "severity": "note",
            "fingerprint": "loss_book",
            "what": f"{_money(under.get('total_loss'))} of losses could be realised against gains",
            "why": (under.get("reading") or "Realising a loss is the only way to get anything back from it; it offsets gains this year or carries forward eight."),
            "size": _d(under.get("saving")), "detail": {"holdings": under.get("holdings"), "offsettable": under.get("offsettable")},
        })
    return out


def _verdicts(investor_id: str) -> list[dict]:
    """Verdict *changes*: the engine's reading today against what it said last run."""
    from . import rebalance_engine
    try:
        got = rebalance_engine.for_investor(investor_id) or {}
    except Exception as err:
        log.info("verdicts unavailable for %s: %s", investor_id, err)
        return []
    if not got.get("available"):
        return []

    def pick(row: dict, *keys: str) -> str:
        for k in keys:
            if row.get(k):
                return str(row[k])
        return ""

    sells = {pick(s, "symbol", "stock_name", "name").upper(): s for s in (got.get("sell") or [])}
    held = {pick(h, "symbol", "stock_name", "name").upper(): h for h in (got.get("holdings") or [])}
    memo = {r["symbol"]: r for r in db.fetch_all(
        "SELECT symbol, verdict FROM verdict_memo WHERE investor_id = %s", (investor_id,))}

    out = []
    today = {}
    for sym in set(held) | set(sells):
        if not sym:
            continue
        verdict = "sell" if sym in sells else "hold"
        today[sym] = verdict
        before = (memo.get(sym) or {}).get("verdict")
        if verdict == "sell" and before != "sell":
            s = sells[sym]
            reason = pick(s, "reason", "rationale", "why", "verdict")[:220]
            out.append({
                "kind": "verdict", "severity": "act",
                "fingerprint": f"verdict:sell:{sym}",
                "what": f"{pick(s, 'name', 'stock_name', 'symbol')} crossed to sell",
                "why": (f"{'It read hold until today. ' if before else ''}{reason}").strip(),
                "size": _d(pick(s, "current_value", "value", "amount")),
                "detail": {"symbol": sym, "before": before or "unseen"},
            })

    with db.connection() as conn:
        for sym, verdict in today.items():
            conn.execute(
                """
                INSERT INTO verdict_memo (investor_id, symbol, verdict, as_of)
                VALUES (%s, %s, %s, now())
                ON CONFLICT (investor_id, symbol) DO UPDATE
                    SET verdict = EXCLUDED.verdict, as_of = now()
                """, (investor_id, sym, verdict))
    return out


def _market(investor_id: str, last_off_peak: Optional[Decimal], off_now: Optional[Decimal] = None) -> tuple[list[dict], Optional[Decimal]]:
    from . import market
    try:
        ctx = market.context()
    except Exception:
        return [], last_off_peak
    if not ctx.get("readable"):
        return [], last_off_peak
    off = off_now if off_now is not None else _d(ctx["position"]["off_peak_pct"])
    out = []
    for level in MARKET_LEVELS:
        crossed_down = off <= level and (last_off_peak is None or last_off_peak > level)
        if crossed_down:
            f = ctx.get("followed") or {}
            base = (f" Across {f['windows']} such days in our record, twelve months later was positive "
                    f"{f['positive_pct']}% of the time, median {f['median_pct']}%, unlucky tenth {f['unlucky_tenth_pct']}%."
                    if f.get("countable") else "")
            out.append({
                "kind": "market", "severity": "note",
                "fingerprint": f"market:{int(level)}",
                "what": f"The index is {abs(off):.1f}% below its high",
                "why": (f"It crossed {abs(int(level))}% below the high. This is not an instruction to sell; it is the "
                        f"moment people do, and the record says that is usually the wrong moment.{base} "
                        f"If you hold debt above target, this is where it is spent."),
                "size": None, "detail": {"off_peak_pct": str(off), "followed": f},
            })
    return out, off


def _goals(investor_id: str) -> list[dict]:
    from . import goals, replay
    try:
        allg = goals.all_for(investor_id)
    except Exception:
        return []
    out = []
    for g in (allg.get("goals") or []):
        if g.get("reached"):
            continue
        try:
            r = replay.for_goal(g["id"])
        except Exception:
            continue
        if not r.get("drawable"):
            continue
        odds = _d(r.get("reached_pct"))
        flag = "off" if odds < GOAL_OFF else "at_risk" if odds < GOAL_AT_RISK else "on"
        if flag == "on":
            continue
        out.append({
            "kind": "goal", "severity": "note" if flag == "at_risk" else "act",
            "fingerprint": f"goal:{g['id']}:{flag}",
            "what": f"{g['name']}: {'off target' if flag == 'off' else 'at risk'} ({odds:.0f}% of history reaches it)",
            "why": (f"{_money(g['worth'])} earmarked against {_money(g['target_in_inr'])} in {g['years_left']} years; "
                    f"{r['windows']} stretches replayed, worst finish {_money(r['worst'])}. "
                    f"What helps most: more monthly, more time, or less equity for money needed soon — the goal page shows what each is worth."),
            "size": _d(g.get("still_needed")), "detail": {"goal_id": g["id"], "reached_pct": str(odds), "flag": flag},
        })
    return out


def _lookthrough(investor_id: str) -> list[dict]:
    from . import lookthrough
    return lookthrough.watch_events(investor_id)


def _glide(investor_id: str) -> list[dict]:
    from . import glide
    return glide.flags(investor_id)


def _discipline(investor_id: str) -> list[dict]:
    from . import discipline
    ev = discipline.watch_event(investor_id)
    return [ev] if ev else []


# ---------------------------------------------------------------------------
# The run
# ---------------------------------------------------------------------------

HOURLY_KINDS = ("verdict", "market")


def _live_off_peak() -> Optional[Decimal]:
    """The index's distance from its high right now, from a live quote against
    the stored record's peak. None when the quote is not live (market shut,
    or the source fell back to yesterday's close) -- an hourly pass on a stale
    price would only repeat the daily one."""
    from . import dataservice, market
    try:
        q = dataservice.quote(market.BENCHMARK) or {}
        if not dataservice.is_live(q):
            return None
        price = _d(q.get("price"))
        closes = [c for _, c in market._series()]
        peak = max(closes + [price]) if closes else None
        return ((price - peak) / peak * 100) if peak and price > 0 else None
    except Exception as err:
        log.info("live index unavailable: %s", err)
        return None


def run(investor_id: str, hourly: bool = False) -> dict:
    """One pass for one investor. Opens, touches and resolves events; returns the digest.

    `hourly`: the light intraday pass -- verdict crossings and the index against
    its high on a live quote, nothing else. It only opens and resolves its own
    kinds, so it cannot close the daily drift, tax or goal events it did not
    look at."""
    last = db.fetch_one("SELECT market_off_peak FROM watch_run WHERE investor_id = %s", (investor_id,))
    last_off = _d(last["market_off_peak"]) if last and last.get("market_off_peak") is not None else None

    found: list[dict] = []
    finders = (_verdicts,) if hourly else (_drift, _tax, _verdicts, _goals, _discipline, _glide, _lookthrough)
    for finder in finders:
        try:
            found.extend(finder(investor_id))
        except Exception as err:
            log.warning("watch %s failed for %s: %s", finder.__name__, investor_id, err)
    if hourly:
        live = _live_off_peak()
        market_events, off = (_market(investor_id, last_off, off_now=live) if live is not None else ([], last_off))
    else:
        market_events, off = _market(investor_id, last_off)
    found.extend(market_events)

    seen = {e["fingerprint"] for e in found}
    opened = 0
    with db.connection() as conn:
        for e in found:
            row = conn.execute(
                """
                INSERT INTO watch_event (investor_id, kind, severity, instrument_id, fingerprint, what, why, size, detail)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (investor_id, fingerprint) WHERE resolved_at IS NULL
                DO UPDATE SET last_seen_at = now(), what = EXCLUDED.what, why = EXCLUDED.why,
                              size = EXCLUDED.size, detail = EXCLUDED.detail, severity = EXCLUDED.severity
                RETURNING (xmax = 0) AS inserted
                """,
                (investor_id, e["kind"], e["severity"], e.get("instrument_id"), e["fingerprint"],
                 e["what"], e["why"], e.get("size"), json.dumps(e.get("detail") or {}, default=str)),
            ).fetchone()
            if row and row.get("inserted"):
                opened += 1
        # Market crossings are moments, not states: resolve them after a day so the next crossing can open fresh.
        resolved = conn.execute(
            """
            UPDATE watch_event SET resolved_at = now()
            WHERE investor_id = %s AND resolved_at IS NULL
              AND (fingerprint <> ALL(%s) OR (kind = 'market' AND opened_at < now() - interval '1 day'))
              AND (%s = false OR kind = ANY(%s))
            RETURNING id
            """, (investor_id, list(seen), hourly, list(HOURLY_KINDS))).fetchall()
        open_now = conn.execute(
            "SELECT count(*) AS n FROM watch_event WHERE investor_id = %s AND resolved_at IS NULL",
            (investor_id,)).fetchone()["n"]
        conn.execute(
            """
            INSERT INTO watch_run (investor_id, ran_at, opened, resolved, open_now, market_off_peak)
            VALUES (%s, now(), %s, %s, %s, %s)
            ON CONFLICT (investor_id) DO UPDATE SET ran_at = now(), opened = EXCLUDED.opened,
                resolved = EXCLUDED.resolved, open_now = EXCLUDED.open_now, market_off_peak = EXCLUDED.market_off_peak
            """, (investor_id, opened, len(resolved), open_now, off))

    return digest(investor_id)


def digest(investor_id: str) -> dict:
    """What is open now, worst first, and when it was last checked."""
    run_row = db.fetch_one("SELECT ran_at, opened, resolved, open_now, market_off_peak FROM watch_run WHERE investor_id = %s",
                           (investor_id,))
    rows = db.fetch_all(
        """
        SELECT id, kind, severity, instrument_id, fingerprint, what, why, size, detail, opened_at, last_seen_at, told_at
        FROM watch_event WHERE investor_id = %s AND resolved_at IS NULL
        ORDER BY opened_at DESC
        """, (investor_id,))
    events = sorted(rows, key=lambda r: (SEVERITY_ORDER.get(r["severity"], 9), -_d(r["size"] or 0)))
    for e in events:
        e["size"] = str(e["size"]) if e["size"] is not None else None
        e["opened_at"] = e["opened_at"].isoformat()
        e["last_seen_at"] = e["last_seen_at"].isoformat()
        e["told_at"] = e["told_at"].isoformat() if e["told_at"] else None
        e["new"] = e["told_at"] is None
    acts = [e for e in events if e["severity"] == "act"]
    recent = db.fetch_all(
        """
        SELECT what, resolved_at FROM watch_event WHERE investor_id = %s AND resolved_at > now() - interval '7 days'
        ORDER BY resolved_at DESC LIMIT 5
        """, (investor_id,))
    checked = run_row["ran_at"].isoformat() if run_row else None
    if not run_row:
        reading = "Not checked yet. The first pass runs after the next close."
    elif not events:
        reading = "Checked; nothing crossed a line. The right move is to leave it alone."
    else:
        reading = (f"{len(acts)} thing{'s' if len(acts) != 1 else ''} to act on"
                   + (f", {len(events) - len(acts)} to know about" if len(events) > len(acts) else "")
                   + ". " + (acts[0]["what"] if acts else events[0]["what"]) + ".")
    return {
        "checked_at": checked,
        "events": events,
        "to_act": len(acts),
        "to_know": len(events) - len(acts),
        "cleared_this_week": [{"what": r["what"], "on": r["resolved_at"].date().isoformat()} for r in recent],
        "reading": reading,
        "principle": ("Checked every day after the close. Something appears here only when it crosses a line — "
                      "a band, a tax date, a verdict, a drawdown level — and it leaves when it stops being true. "
                      "Most days there is nothing, and that is the answer."),
    }


def mark_told(investor_id: str, ids: list[str]) -> None:
    if not ids:
        return
    with db.connection() as conn:
        conn.execute("UPDATE watch_event SET told_at = now() WHERE investor_id = %s AND id = ANY(%s::uuid[])",
                     (investor_id, ids))


def as_html(name: str, d: dict) -> str:
    rows = ""
    for e in d["events"]:
        size = f" <span style='color:#8A6520'>· {_money(e['size'])}</span>" if e.get("size") else ""
        rows += f"<p style='margin:0 0 12px'><b>{e['what']}</b>{size}<br><span style='color:#444'>{e['why']}</span></p>"
    return (f"<p>{name}, the daily check ran at {d['checked_at'][:16].replace('T', ' ')}.</p>"
            f"<p>{d['reading']}</p>{rows}"
            f"<p style='color:#666;font-size:13px'>{d['principle']}</p>")


def everybody() -> list[str]:
    return [r["id"] for r in db.fetch_all("SELECT id FROM investors ORDER BY id")]
