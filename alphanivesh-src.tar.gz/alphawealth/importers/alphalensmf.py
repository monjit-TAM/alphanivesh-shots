"""
Import AlphaLensMF portfolios into the canonical wealth model.

AlphaLensMF stores one `portfolios` row per CAS import, with the investor's
name, email and PAN denormalised onto it. That means the same person importing
twice appears as two unrelated rows. The whole point of this importer is to
collapse those into one canonical investor, then hang their folios, schemes,
holdings and transactions off it in a shape that also has room for equities,
bonds, FDs and everything else we do not hold in AlphaLensMF today.

Run it against a staging copy of the AlphaLensMF tables (see load_seed.sh) so
we never read from the production database during market hours.

    python -m importers.alphalensmf --source-dsn ... --target-dsn ... [--dry-run]

The importer is idempotent: running it twice produces the same canonical state,
because every insert is keyed on a natural key and upserted.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Iterable, Iterator, Optional

import psycopg
from psycopg.rows import dict_row

log = logging.getLogger("alphalensmf_import")

# AlphaLensMF records how a portfolio arrived in `portfolios.source_type`.
# The values we have seen in the data map onto canonical sources like this;
# anything unrecognised is imported as a manual entry so it is never silently
# dropped, and shows up in the summary for a human to look at.
SOURCE_TYPE_MAP = {
    "cas": "casparser_cams",
    "cas_upload": "casparser_cams",
    "cams": "casparser_cams",
    "kfintech": "casparser_kfintech",
    "cdsl": "casparser_cdsl",
    "nsdl": "casparser_nsdl",
    "inbox": "casparser_cams",
    "gmail": "casparser_cams",
    "manual": "manual",
    "demo": "manual",
}

# AlphaLensMF stores dates as free text and the CAS providers are not
# consistent about format. These are the formats actually present in the data.
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%b-%Y", "%Y/%m/%d")


class ImportAborted(RuntimeError):
    """Raised when the source data is not in the shape we expect."""


@dataclass
class Stats:
    """Counts we print at the end so a human can sanity-check the run."""

    investors_created: int = 0
    investors_matched: int = 0
    accounts: int = 0
    instruments: int = 0
    holdings: int = 0
    transactions: int = 0
    source_documents: int = 0
    quarantined: int = 0
    skipped: list[str] = field(default_factory=list)

    def report(self) -> str:
        lines = [
            "",
            "Import summary",
            "--------------",
            f"  investors   {self.investors_created} created, {self.investors_matched} matched to existing",
            f"  accounts    {self.accounts}",
            f"  instruments {self.instruments}",
            f"  holdings    {self.holdings}",
            f"  transactions{self.transactions:>5}",
            f"  documents   {self.source_documents}",
            f"  quarantined {self.quarantined} holdings failed plausibility checks",
        ]
        if self.skipped:
            lines.append(f"  skipped     {len(self.skipped)}")
            for note in self.skipped[:10]:
                lines.append(f"      - {note}")
            if len(self.skipped) > 10:
                lines.append(f"      ... and {len(self.skipped) - 10} more")
        return "\n".join(lines)


# --------------------------------------------------------------------------
# Small parsing helpers.
#
# Everything coming out of AlphaLensMF is text or float4, and both lose
# information. We convert once, here, and let the rest of the importer assume
# it is working with proper dates and Decimals.
# --------------------------------------------------------------------------


def parse_date(value) -> Optional[date]:
    if value in (None, "", "-"):
        return None
    if isinstance(value, date):
        return value
    if isinstance(value, datetime):
        return value.date()
    text = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    log.debug("unparseable date %r", value)
    return None


def to_decimal(value) -> Optional[Decimal]:
    """float4 -> Decimal, without carrying the float's noise into our books.

    AlphaLensMF stores money in `real`, so a value that was 1234567.89 on the
    way in reads back as 1234567.875. Rounding at six places is enough to hold
    unit counts precisely and drops the float artefact.
    """
    if value is None or value == "":
        return None
    try:
        return Decimal(str(value)).quantize(Decimal("0.000001"))
    except (InvalidOperation, ValueError):
        log.debug("unparseable number %r", value)
        return None


def hash_pan(pan: str) -> str:
    return hashlib.sha256(pan.strip().upper().encode()).hexdigest()


def normalise_email(email) -> Optional[str]:
    if not email:
        return None
    cleaned = str(email).strip().lower()
    return cleaned or None


def canonical_source(source_type) -> str:
    key = (source_type or "").strip().lower()
    return SOURCE_TYPE_MAP.get(key, "manual")



def display_name_for(portfolio: dict, email: Optional[str]) -> str:
    """Work out what to call this investor.

    Roughly half the AlphaLensMF portfolios carry `investor_name`; the rest
    leave it blank. `portfolios.name` is not a substitute -- it is a label like
    "Portfolio Analysis" that the app assigns. Where we have nothing but an
    email we use its local part, which at least gives a human something
    recognisable to click on until the record is claimed.
    """
    explicit = (portfolio.get("investor_name") or "").strip()
    if explicit:
        return explicit
    if email and "@" in email:
        local = email.split("@", 1)[0]
        cleaned = local.replace(".", " ").replace("_", " ").strip()
        if cleaned:
            return cleaned.title()
    return "Unnamed investor"


# Bounds for the plausibility check below. These are deliberately loose: the
# aim is to catch rows where the CAS parse has clearly gone wrong, not to
# second-guess a genuinely large holding.
MAX_PLAUSIBLE_UNITS = Decimal("100000000")      # 10 crore units
MAX_PLAUSIBLE_VALUE = Decimal("100000000000")   # 1,000 crore in one scheme
MAX_PLAUSIBLE_MULTIPLE = Decimal("100")         # 100x on cost


def holding_problems(row: dict) -> list[str]:
    """Return the reasons this holding looks like bad source data.

    Some AlphaLensMF rows were written by a CAS parse that failed to split the
    statement's columns: the whole table row ends up inside `scheme_name` and
    unrelated numbers land in the numeric fields. One such row claims 27 billion
    units of a small cap fund against an investment of twenty thousand rupees.
    Importing that would put a fictional several-hundred-crore position at the
    top of someone's net worth, so we quarantine rather than trust it.

    We return every reason rather than the first, because when a human reviews
    the quarantine list the full picture is what tells them what went wrong
    upstream.
    """
    problems: list[str] = []

    units = to_decimal(row.get("total_units"))
    nav = to_decimal(row.get("current_nav"))
    value = to_decimal(row.get("current_value"))
    invested = to_decimal(row.get("invested_amount"))

    # A fully redeemed folio still appears on the statement with nil units and
    # no NAV. That is a real, importable holding worth keeping: it is part of
    # the investor's history even though it contributes nothing to net worth.
    if (units or Decimal(0)) == 0 and (value or Decimal(0)) == 0:
        return []

    # We used to reject long scheme names on the theory that they were unparsed
    # statement rows. They are not: AMCs prefix their own scheme codes and
    # append qualifiers, so "B92-Aditya Birla Sun Life Large Cap Fund-Growth-
    # Regular Plan(formerly known as ...)" is an ordinary fund. The genuinely
    # broken rows always fail one of the numeric checks below as well, so the
    # name is left alone.

    if units is not None and units > MAX_PLAUSIBLE_UNITS:
        problems.append(f"implausible unit count {units:,.2f}")

    if value is not None and value > MAX_PLAUSIBLE_VALUE:
        problems.append(f"implausible value {value:,.2f}")

    if invested and invested > 0 and value and value / invested > MAX_PLAUSIBLE_MULTIPLE:
        problems.append(
            f"value is {value / invested:,.0f}x cost ({value:,.2f} against {invested:,.2f})"
        )

    # The strongest signal: units x NAV should land near the stated value. We
    # allow a wide 5% band because NAV and value are often as of different days.
    if units and nav and value and value > 0:
        implied = units * nav
        if implied > 0:
            drift = abs(implied - value) / value
            if drift > Decimal("0.05"):
                problems.append(
                    f"units x NAV = {implied:,.2f} does not reconcile with stated value {value:,.2f}"
                )

    return problems


# --------------------------------------------------------------------------
# Investor resolution
#
# This is the part that actually creates value: turning 102 import records
# belonging to maybe 60 people into 60 investors. PAN is the strong key and
# 91% of rows have one. Email carries the rest. A handful will have neither and
# we still import them, tagged, rather than losing the holdings.
# --------------------------------------------------------------------------


class InvestorResolver:
    def __init__(self, conn: psycopg.Connection, stats: Stats):
        self.conn = conn
        self.stats = stats
        # Cache within a run so 102 portfolios do not become 102 lookups.
        self._by_pan: dict[str, str] = {}
        self._by_email: dict[str, str] = {}

    def resolve(self, portfolio: dict) -> str:
        pan = (portfolio.get("pan") or "").strip()
        email = normalise_email(portfolio.get("email"))
        name = display_name_for(portfolio, email)

        if pan:
            return self._by_pan_key(pan, name, email, portfolio)
        if email:
            return self._by_email_key(email, name, portfolio)
        return self._create(name, None, None, portfolio, note="no pan or email")

    def _by_pan_key(self, pan: str, name: str, email: Optional[str], portfolio: dict) -> str:
        pan_hash = hash_pan(pan)
        if pan_hash in self._by_pan:
            self.stats.investors_matched += 1
            return self._by_pan[pan_hash]

        row = self.conn.execute(
            "SELECT id FROM investors WHERE pan_hash = %s", (pan_hash,)
        ).fetchone()
        if row:
            self.stats.investors_matched += 1
            self._by_pan[pan_hash] = row["id"]
            return row["id"]

        investor_id = self._insert(
            display_name=name,
            pan_hash=pan_hash,
            pan_last4=pan.strip().upper()[-4:],
            email=email,
            portfolio=portfolio,
        )
        self._by_pan[pan_hash] = investor_id
        if email:
            self._by_email[email] = investor_id
        return investor_id

    def _by_email_key(self, email: str, name: str, portfolio: dict) -> str:
        if email in self._by_email:
            self.stats.investors_matched += 1
            return self._by_email[email]

        # Only match an existing PAN-less investor on email. If someone already
        # has a PAN on file we do not want an email collision to merge two
        # different people; that decision belongs to a human.
        row = self.conn.execute(
            "SELECT id FROM investors WHERE lower(email) = %s AND pan_hash IS NULL",
            (email,),
        ).fetchone()
        if row:
            self.stats.investors_matched += 1
            self._by_email[email] = row["id"]
            return row["id"]

        investor_id = self._insert(
            display_name=name, pan_hash=None, pan_last4=None, email=email, portfolio=portfolio
        )
        self._by_email[email] = investor_id
        return investor_id

    def _create(self, name, pan_hash, pan_last4, portfolio, note: str) -> str:
        """Last resort: an investor we cannot identify by PAN or email.

        We still import them -- losing the holdings would be worse -- but we
        match on the originating portfolio id so that re-running the importer
        finds the same investor instead of minting a new orphan every time.
        These are flagged in the run summary so someone can merge them into a
        real investor once we know who they are.
        """
        portfolio_id = portfolio.get("id")
        existing = self.conn.execute(
            """
            SELECT id FROM investors
            WHERE pan_hash IS NULL
              AND email IS NULL
              AND legacy_ref->>'system' = 'alphalensmf'
              AND legacy_ref->>'portfolio_id' = %s
            """,
            (str(portfolio_id),),
        ).fetchone()
        if existing:
            self.stats.investors_matched += 1
            return existing["id"]

        self.stats.skipped.append(
            f"portfolio {portfolio_id} ({name}): {note}, imported unlinked"
        )
        return self._insert(name, pan_hash, pan_last4, None, portfolio)

    def _insert(self, display_name, pan_hash, pan_last4, email, portfolio) -> str:
        # legacy_ref keeps the trail back to the row this investor came from,
        # which we need while AlphaLensMF and AlphaWealth run side by side.
        legacy = {
            "system": "alphalensmf",
            "portfolio_id": portfolio.get("id"),
            "user_id": portfolio.get("user_id"),
        }
        row = self.conn.execute(
            """
            INSERT INTO investors (display_name, pan_hash, pan_last4, email, legacy_ref)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
            """,
            (display_name, pan_hash, pan_last4, email, json.dumps(legacy)),
        ).fetchone()
        self.stats.investors_created += 1
        return row["id"]


# --------------------------------------------------------------------------
# Instrument and account resolution
# --------------------------------------------------------------------------


class InstrumentResolver:
    """Maps an AlphaLensMF scheme onto a canonical instrument.

    AlphaLensMF has no ISIN, so the AMFI scheme code is our key. Where even
    that is missing we fall back to the scheme name, which is not ideal but is
    stable enough within one AMC and keeps the holding importable.
    """

    def __init__(self, conn: psycopg.Connection, stats: Stats):
        self.conn = conn
        self.stats = stats
        self._cache: dict[str, str] = {}

    def resolve(self, row: dict) -> str:
        scheme_code = (row.get("scheme_code") or "").strip()
        scheme_name = (row.get("scheme_name") or "").strip()
        native_code = scheme_code or f"name:{scheme_name.lower()}"

        if native_code in self._cache:
            return self._cache[native_code]

        found = self.conn.execute(
            "SELECT id FROM instruments WHERE asset_class = 'mutual_fund' AND native_code = %s",
            (native_code,),
        ).fetchone()
        if found:
            self._cache[native_code] = found["id"]
            return found["id"]

        created = self.conn.execute(
            """
            INSERT INTO instruments
                (asset_class, native_code, name, issuer, category, sub_category, attributes)
            VALUES ('mutual_fund', %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (
                native_code,
                scheme_name or native_code,
                row.get("amc_name"),
                row.get("category"),
                row.get("sub_category"),
                json.dumps({"imported_from": "alphalensmf"}),
            ),
        ).fetchone()
        self.stats.instruments += 1
        self._cache[native_code] = created["id"]
        return created["id"]


class AccountResolver:
    """One account per (investor, folio).

    The folio is how the registrar identifies the holding, which makes it the
    right grain: two schemes in the same folio share an account, the same
    scheme in two folios does not get merged, and the same folio reported by
    two different statement providers resolves to one account rather than two.
    """

    def __init__(self, conn: psycopg.Connection, stats: Stats):
        self.conn = conn
        self.stats = stats
        self._cache: dict[tuple[str, str], str] = {}

    def resolve(self, investor_id: str, folio: Optional[str], source: str, amc: Optional[str]) -> str:
        folio_key = (folio or "").strip() or "unspecified"
        cache_key = (investor_id, folio_key)
        if cache_key in self._cache:
            return self._cache[cache_key]

        # Deliberately not filtered by source: the registrar issues the folio,
        # so the same folio seen in a CAMS statement and a KFintech one is one
        # account. Source is recorded per snapshot instead.
        found = self.conn.execute(
            """
            SELECT id FROM accounts
            WHERE investor_id = %s AND account_kind = 'mf_folio'
              AND coalesce(account_number, '') = %s
            """,
            (investor_id, folio_key),
        ).fetchone()
        if found:
            self._cache[cache_key] = found["id"]
            return found["id"]

        created = self.conn.execute(
            """
            INSERT INTO accounts
                (investor_id, source, account_kind, account_number, account_label, institution)
            VALUES (%s, %s, 'mf_folio', %s, %s, %s)
            RETURNING id
            """,
            (investor_id, source, folio_key, f"Folio {folio_key}", amc),
        ).fetchone()
        self.stats.accounts += 1
        self._cache[cache_key] = created["id"]
        return created["id"]


# --------------------------------------------------------------------------
# The import itself
# --------------------------------------------------------------------------


def fetch_portfolios(source: psycopg.Connection) -> list[dict]:
    return source.execute(
        """
        SELECT id, name, user_id, is_demo, investor_name, email, pan,
               source_type, uploaded_at
        FROM portfolios
        ORDER BY id
        """
    ).fetchall()


def fetch_holdings(source: psycopg.Connection, portfolio_id: int) -> list[dict]:
    return source.execute(
        "SELECT * FROM fund_holdings WHERE portfolio_id = %s", (portfolio_id,)
    ).fetchall()


def fetch_transactions(source: psycopg.Connection, portfolio_id: int) -> list[dict]:
    return source.execute(
        "SELECT * FROM transactions WHERE portfolio_id = %s ORDER BY id", (portfolio_id,)
    ).fetchall()


def record_source_document(
    target: psycopg.Connection, investor_id: str, portfolio: dict, source: str
) -> str:
    """Keep a record of the import itself.

    We do not have the original CAS payload for these legacy rows, so what we
    store is the portfolio row that stood in for it. When we import from
    CASParser directly this is where the raw response will live.
    """
    payload = {
        "system": "alphalensmf",
        "portfolio": {k: (v.isoformat() if isinstance(v, (date, datetime)) else v)
                      for k, v in portfolio.items()},
    }
    body = json.dumps(payload, sort_keys=True)
    digest = hashlib.sha256(body.encode()).hexdigest()

    existing = target.execute(
        "SELECT id FROM source_documents WHERE payload_sha256 = %s", (digest,)
    ).fetchone()
    if existing:
        return existing["id"]

    uploaded = portfolio.get("uploaded_at")
    row = target.execute(
        """
        INSERT INTO source_documents
            (investor_id, source, provider_ref, payload, payload_sha256,
             received_at, processed_at, status)
        VALUES (%s, %s, %s, %s, %s, coalesce(%s, now()), now(), 'parsed')
        RETURNING id
        """,
        (investor_id, source, f"alphalensmf:portfolio:{portfolio['id']}",
         body, digest, uploaded),
    ).fetchone()
    return row["id"]


def import_holdings(
    target: psycopg.Connection,
    source_rows: list[dict],
    investor_id: str,
    source: str,
    document_id: str,
    instruments: InstrumentResolver,
    accounts: AccountResolver,
    stats: Stats,
    fallback_as_of: date,
) -> None:
    for row in source_rows:
        problems = holding_problems(row)
        if problems:
            stats.quarantined += 1
            stats.skipped.append(
                f"holding {row.get('id')} ({(row.get('scheme_name') or '')[:40]}): "
                + "; ".join(problems)
            )
            continue

        instrument_id = instruments.resolve(row)
        account_id = accounts.resolve(
            investor_id, row.get("folio_number"), source, row.get("amc_name")
        )
        as_of = parse_date(row.get("latest_nav_date")) or fallback_as_of

        # The three return figures AlphaLensMF precomputed are kept on the
        # snapshot rather than recomputed here. We will recompute them from
        # transactions in the consolidation service, but keeping the source's
        # own numbers lets us reconcile the two and spot mapping errors.
        attributes = {
            "source_absolute_return": float(row["absolute_return"]) if row.get("absolute_return") is not None else None,
            "source_xirr": float(row["xirr"]) if row.get("xirr") is not None else None,
            "source_cagr": float(row["cagr"]) if row.get("cagr") is not None else None,
            "first_investment_date": (parse_date(row.get("first_investment_date")) or "").__str__() or None,
            "last_transaction_date": (parse_date(row.get("last_transaction_date")) or "").__str__() or None,
        }

        target.execute(
            """
            INSERT INTO holding_snapshots
                (investor_id, account_id, instrument_id, as_of, source,
                 source_document_id, quantity, price, current_value,
                 invested_value, attributes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (account_id, instrument_id, as_of, source)
            DO UPDATE SET
                quantity       = EXCLUDED.quantity,
                price          = EXCLUDED.price,
                current_value  = EXCLUDED.current_value,
                invested_value = EXCLUDED.invested_value,
                attributes     = EXCLUDED.attributes
            """,
            (
                investor_id, account_id, instrument_id, as_of, source, document_id,
                to_decimal(row.get("total_units")) or Decimal(0),
                to_decimal(row.get("current_nav")),
                to_decimal(row.get("current_value")),
                to_decimal(row.get("invested_amount")),
                json.dumps(attributes),
            ),
        )
        stats.holdings += 1


def import_transactions(
    target: psycopg.Connection,
    source_rows: list[dict],
    investor_id: str,
    source: str,
    document_id: str,
    instruments: InstrumentResolver,
    accounts: AccountResolver,
    stats: Stats,
) -> None:
    for row in source_rows:
        txn_date = parse_date(row.get("transaction_date"))
        if txn_date is None:
            stats.skipped.append(
                f"transaction {row.get('id')}: unparseable date {row.get('transaction_date')!r}"
            )
            continue

        instrument_id = instruments.resolve(row)
        account_id = accounts.resolve(
            investor_id, row.get("folio_number"), source, row.get("amc_name")
        )

        target.execute(
            """
            INSERT INTO canonical_transactions
                (investor_id, account_id, instrument_id, txn_type, txn_date,
                 quantity, price, amount, source, source_document_id,
                 external_ref, attributes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (account_id, external_ref) WHERE external_ref IS NOT NULL
            DO NOTHING
            """,
            (
                investor_id, account_id, instrument_id,
                (row.get("transaction_type") or "unknown").strip().lower(),
                txn_date,
                to_decimal(row.get("units")),
                to_decimal(row.get("nav")),
                to_decimal(row.get("amount")) or Decimal(0),
                source, document_id,
                f"alphalensmf:txn:{row['id']}",
                json.dumps({"balance": float(row["balance"]) if row.get("balance") is not None else None}),
            ),
        )
        stats.transactions += 1


def run(source_dsn: str, target_dsn: str, include_demo: bool, dry_run: bool) -> Stats:
    stats = Stats()

    with psycopg.connect(source_dsn, row_factory=dict_row) as source, \
         psycopg.connect(target_dsn, row_factory=dict_row) as target:

        portfolios = fetch_portfolios(source)
        if not portfolios:
            raise ImportAborted("no portfolios found in the source database")

        log.info("found %d portfolios to import", len(portfolios))

        for portfolio in portfolios:
            if portfolio.get("is_demo") and not include_demo:
                stats.skipped.append(f"portfolio {portfolio['id']}: demo data, skipped")
                continue

            investors = InvestorResolver(target, stats)
            instruments = InstrumentResolver(target, stats)
            accounts = AccountResolver(target, stats)

            investor_id = investors.resolve(portfolio)
            canonical_src = canonical_source(portfolio.get("source_type"))
            document_id = record_source_document(target, investor_id, portfolio, canonical_src)
            stats.source_documents += 1

            uploaded = portfolio.get("uploaded_at")
            fallback_as_of = uploaded.date() if isinstance(uploaded, datetime) else date.today()

            import_holdings(
                target, fetch_holdings(source, portfolio["id"]), investor_id,
                canonical_src, document_id, instruments, accounts, stats, fallback_as_of,
            )
            import_transactions(
                target, fetch_transactions(source, portfolio["id"]), investor_id,
                canonical_src, document_id, instruments, accounts, stats,
            )

        if dry_run:
            log.warning("dry run: rolling back")
            target.rollback()
        else:
            target.commit()

    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dsn", required=True,
                        help="DSN of the database holding the AlphaLensMF tables")
    parser.add_argument("--target-dsn", required=True, help="DSN of alphawealth_db")
    parser.add_argument("--include-demo", action="store_true",
                        help="import portfolios flagged is_demo (off by default)")
    parser.add_argument("--dry-run", action="store_true",
                        help="do all the work, then roll back")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(message)s",
    )

    stats = run(args.source_dsn, args.target_dsn, args.include_demo, args.dry_run)
    print(stats.report())
    if args.dry_run:
        print("\n(dry run - nothing was written)")


if __name__ == "__main__":
    main()
