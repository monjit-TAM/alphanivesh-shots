#!/usr/bin/env bash
#
# Load a pg_dump of the AlphaLensMF tables into a staging database on this box,
# so the importer can read real data without touching production.
#
#   ./load_seed.sh /tmp/alphalensmf_seed.sql
#
# The dump is data-only, so we recreate the source tables first. They mirror
# AlphaLensMF's live schema exactly, float4 columns and text dates included --
# we want the importer exercised against the real thing, quirks and all.

set -euo pipefail
SEED="${1:?usage: load_seed.sh <dump.sql>}"
DB=alphalensmf_staging

sudo -u postgres psql -c "DROP DATABASE IF EXISTS ${DB};"
sudo -u postgres psql -c "CREATE DATABASE ${DB};"

sudo -u postgres psql -q -d "${DB}" <<'SQL'
CREATE TABLE users (
  id varchar PRIMARY KEY, email varchar, password varchar, first_name varchar,
  last_name varchar, profile_image_url varchar, is_admin boolean DEFAULT false,
  created_at timestamp DEFAULT now(), updated_at timestamp DEFAULT now());

CREATE TABLE portfolios (
  id serial PRIMARY KEY, name text NOT NULL, user_id varchar,
  is_demo boolean DEFAULT false, investor_name text, email text, pan text,
  source_type text NOT NULL, uploaded_at timestamp DEFAULT now());

CREATE TABLE fund_holdings (
  id serial PRIMARY KEY, portfolio_id integer NOT NULL, scheme_name text NOT NULL,
  scheme_code text, amc_name text, category text, sub_category text,
  folio_number text, total_units real NOT NULL, current_nav real,
  current_value real, invested_amount real NOT NULL, absolute_return real,
  xirr real, cagr real, latest_nav_date text, first_investment_date text,
  last_transaction_date text);

CREATE TABLE transactions (
  id serial PRIMARY KEY, portfolio_id integer NOT NULL, folio_number text,
  scheme_name text NOT NULL, scheme_code text, amc_name text, category text,
  sub_category text, transaction_type text NOT NULL, transaction_date text NOT NULL,
  amount real NOT NULL, units real, nav real, balance real);

CREATE TABLE cas_requests (
  id serial PRIMARY KEY, user_id varchar, pan_hash text NOT NULL, pan_last4 text,
  email text NOT NULL, provider text NOT NULL DEFAULT 'kfintech',
  status text NOT NULL DEFAULT 'requested', message text,
  requested_at timestamp DEFAULT now(), fulfilled_at timestamp);
SQL

sudo -u postgres psql -q -d "${DB}" -f "${SEED}"

echo "loaded into ${DB}:"
sudo -u postgres psql -tA -d "${DB}" -c \
  "SELECT 'portfolios='||(SELECT count(*) FROM portfolios)
        ||' holdings='||(SELECT count(*) FROM fund_holdings)
        ||' transactions='||(SELECT count(*) FROM transactions)
        ||' users='||(SELECT count(*) FROM users);"
