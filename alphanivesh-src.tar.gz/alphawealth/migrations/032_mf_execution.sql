-- Mutual-fund execution through an external order rail (v1: Fintech Primitives).
--
-- Two things are kept, and one thing deliberately is not.
--
-- `mf_link` is the investor's identity on the rail: the ids FP gave back when
-- we created their investor profile, bank account and investment account.
-- Created once, reused for every order.
--
-- `venue_order` is every order we sent, with the rail's id for it and the last
-- state we saw. One row per order_consent claimed, so the consent, the order
-- and the ledger row can be put side by side.
--
-- Not kept: the PAN. FP needs it to create the profile and it is sent once,
-- from the request, and forgotten. `investors` holds only pan_hash/pan_last4
-- and that stays true.

BEGIN;

CREATE TABLE IF NOT EXISTS mf_link (
    investor_id          text PRIMARY KEY REFERENCES investors(id) ON DELETE RESTRICT,
    venue                text NOT NULL DEFAULT 'fp',
    environment          text NOT NULL DEFAULT 'sandbox'
                             CHECK (environment IN ('sandbox', 'production')),

    -- What the rail calls this person.
    profile_ref          text,          -- FP investor_profile id
    bank_ref             text,          -- FP bank_account id
    account_ref          text,          -- FP mf_investment_account id
    kyc_state            text,          -- as last reported by the rail

    -- Anything else the rail returned that we may need later, verbatim.
    meta                 jsonb NOT NULL DEFAULT '{}'::jsonb,

    linked_at            timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS venue_order (
    id                   text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id          text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    consent_id           text REFERENCES order_consent(id),
    venue                text NOT NULL DEFAULT 'fp',
    environment          text NOT NULL DEFAULT 'sandbox',

    -- What was asked for, in our terms.
    kind                 text NOT NULL CHECK (kind IN ('purchase', 'redemption', 'switch', 'sip')),
    instrument_id        text REFERENCES instruments(id),
    isin                 text,
    to_isin              text,          -- switches only
    amount               numeric(20,2),
    units                numeric(20,4),

    -- What the rail said.
    external_ref         text,          -- FP order id
    state                text NOT NULL DEFAULT 'created',
    payment_ref          text,
    error                text,
    last_payload         jsonb,

    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now(),
    settled_at           timestamptz
);

CREATE INDEX IF NOT EXISTS venue_order_investor_idx ON venue_order (investor_id, created_at DESC);
CREATE INDEX IF NOT EXISTS venue_order_open_idx ON venue_order (state) WHERE settled_at IS NULL;

COMMIT;
