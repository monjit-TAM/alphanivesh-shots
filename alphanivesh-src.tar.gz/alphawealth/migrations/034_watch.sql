-- 034_watch.sql
--
-- The daily watch: what the engine noticed, and whether it has been said.
--
-- The principle, from the benchmark of what the best platforms do: watch
-- every day, act rarely, explain always. This table is the "watch" half. A
-- job runs after the close and writes one row per thing that crossed a line
-- -- a bucket beyond its band, a lot about to turn long-term, a verdict that
-- changed, the index through a drawdown level, a goal whose odds fell. A row
-- is opened once (by fingerprint) and closed when the condition no longer
-- holds, so the digest can say "still there" without saying it twice.
--
-- `verdict_memo` is what makes verdict *changes* visible: the engine's
-- reading is re-stated every run; only the crossing is an event.

BEGIN;

CREATE TABLE IF NOT EXISTS watch_event (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    kind            text NOT NULL,          -- drift | ltcg_room | ltcg_soon | loss_book | verdict | market | goal
    severity        text NOT NULL CHECK (severity IN ('act', 'note', 'watch')),
    instrument_id   text,
    fingerprint     text NOT NULL,          -- kind + subject; one open row per fingerprint
    what            text NOT NULL,
    why             text NOT NULL,
    size            numeric(18,2),
    detail          jsonb NOT NULL DEFAULT '{}'::jsonb,
    opened_at       timestamptz NOT NULL DEFAULT now(),
    last_seen_at    timestamptz NOT NULL DEFAULT now(),
    resolved_at     timestamptz,
    told_at         timestamptz             -- when a digest carrying it went out
);

CREATE UNIQUE INDEX IF NOT EXISTS watch_event_open_idx
    ON watch_event (investor_id, fingerprint) WHERE resolved_at IS NULL;
CREATE INDEX IF NOT EXISTS watch_event_investor_idx ON watch_event (investor_id, opened_at DESC);

CREATE TABLE IF NOT EXISTS verdict_memo (
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    symbol          text NOT NULL,
    verdict         text NOT NULL,          -- sell | hold
    reason          text,
    as_of           timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (investor_id, symbol)
);

CREATE TABLE IF NOT EXISTS watch_run (
    investor_id     text PRIMARY KEY REFERENCES investors(id) ON DELETE CASCADE,
    ran_at          timestamptz NOT NULL DEFAULT now(),
    opened          int NOT NULL DEFAULT 0,
    resolved        int NOT NULL DEFAULT 0,
    open_now        int NOT NULL DEFAULT 0,
    market_off_peak numeric(8,2),           -- the index's distance from its high at the run, for crossings
    note            text
);

GRANT SELECT, INSERT, UPDATE, DELETE ON watch_event, verdict_memo, watch_run TO alphawealth_user;

COMMIT;
