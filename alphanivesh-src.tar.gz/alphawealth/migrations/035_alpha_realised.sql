-- 035_alpha_realised.sql
--
-- The realised alpha ledger: what each move actually earned, against what it
-- replaced.
--
-- The plan promises nothing in rupees except cost and tax, and says so. This
-- table is where the rest gets measured instead of asserted. Every placed
-- order (a claimed consent) becomes a row with its starting prices; a monthly
-- mark re-prices both paths -- the money where it went, and the money where it
-- would have stayed -- and writes the difference. The roll-ups by month,
-- quarter and year are sums of those rows and nothing else.
--
-- Counterfactuals, by kind:
--   switch   sold X, bought Y in the same basket: Y's path minus X's path
--   sell     sold X, nothing bought: a liquid-fund rate minus X's path
--   buy      bought Y from new money: Y's path minus a liquid-fund rate
--   cost     regular -> direct of the same fund: direct NAV path minus regular
--   tax      a harvest: the tax saved, fixed on the day

BEGIN;

CREATE TABLE IF NOT EXISTS alpha_realised (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    consent_id      text UNIQUE REFERENCES order_consent(id),
    kind            text NOT NULL CHECK (kind IN ('switch', 'sell', 'buy', 'cost', 'tax')),
    basis           text,                       -- the move's alpha_basis, verbatim
    placed_on       date NOT NULL,
    amount          numeric(20,2) NOT NULL,

    -- The path the money left (sold), and the path it took (bought).
    from_instrument text,                       -- instruments.id
    from_symbol     text,
    from_code       text,                       -- AMFI code where a fund
    from_start      numeric(20,4),              -- price/NAV on placed_on
    to_symbol       text,
    to_code         text,
    to_start        numeric(20,4),

    fixed_alpha     numeric(20,2),              -- tax rows: saved once, on the day
    closed_at       timestamptz,                -- when the comparison stops (e.g. the replacement was sold)
    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS alpha_mark (
    realised_id     uuid NOT NULL REFERENCES alpha_realised(id) ON DELETE CASCADE,
    marked_on       date NOT NULL,
    from_value      numeric(20,2),              -- the money, had it stayed
    to_value        numeric(20,2),              -- the money, where it went
    alpha           numeric(20,2) NOT NULL,     -- to minus from (cumulative since placed)
    note            text,
    PRIMARY KEY (realised_id, marked_on)
);

CREATE INDEX IF NOT EXISTS alpha_realised_investor_idx ON alpha_realised (investor_id, placed_on);

GRANT SELECT, INSERT, UPDATE, DELETE ON alpha_realised, alpha_mark TO alphawealth_user;

COMMIT;
