-- 036_regime_log.sql
--
-- The regime panel's daily record: what it read, what it permitted, and what
-- ran in shadow. Two jobs. It makes every permit reproducible -- the readings
-- and the edges that justified it on that day are stored, not recomputed --
-- which is what SEBI's AI/ML consultation (June 2025) asks of a model-driven
-- recommendation: traceable, repeatable, auditable. And it is the shadow
-- record a rule is judged on before it is allowed to speak: an edge that holds
-- in-sample but not in each half of the record runs here, silently, until it
-- does.

BEGIN;

CREATE TABLE IF NOT EXISTS regime_log (
    logged_on   date PRIMARY KEY,
    data_as_of  date,
    readings    jsonb NOT NULL,
    permits     jsonb NOT NULL,
    shadow      jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at  timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON regime_log TO alphawealth_user;

COMMIT;
