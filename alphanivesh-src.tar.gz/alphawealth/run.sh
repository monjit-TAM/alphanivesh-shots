#!/bin/bash
# Run anything in the app's environment. The service loads .env through
# systemd; an ad-hoc python run does not, and every key silently falls back to
# whatever default is compiled in -- which looks like a missing key rather than
# a missing environment.
cd /opt/alphawealth
set -a; . ./.env; set +a
export ALPHAWEALTH_DB_PASSWORD_FILE=/root/.alphawealth_db_pw
exec ./venv/bin/python "$@"
