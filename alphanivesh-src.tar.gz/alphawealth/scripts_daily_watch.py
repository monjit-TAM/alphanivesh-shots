"""The daily watch, for everybody.

Run from cron once a day after the close. For each investor it opens, touches
and resolves watch events, then -- with --send -- mails a digest to anybody
with something *new* to act on. Nothing goes out for a quiet day; the page
carries "checked, nothing crossed a line" and that is the message.

    ./run.sh scripts_daily_watch.py            # run the checks, print the digests
    ./run.sh scripts_daily_watch.py --send     # and mail the new act-items
    ./run.sh scripts_daily_watch.py --only <investor_id>
    ./run.sh scripts_daily_watch.py --hourly         # the light intraday pass: verdict crossings + live index only

Install:
    # hourly through the session, 10:15–15:15 IST on weekdays (04:45–09:45 UTC)
    45 4-9 * * 1-5 cd /opt/alphawealth && ./run.sh scripts_daily_watch.py --hourly --send >> /var/log/alphanivesh-watch.log 2>&1
    # 18:40 IST on weekdays (13:10 UTC), after NSE close and the NAV cut
    10 13 * * 1-5 cd /opt/alphawealth && ./run.sh scripts_daily_watch.py --send \\
        >> /var/log/alphanivesh-watch.log 2>&1
"""

from __future__ import annotations

import argparse
import logging
import traceback

from api import db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("watch")


def _address_for(investor_id: str):
    row = db.fetch_one(
        "SELECT coalesce(i.email, u.email) AS address, i.display_name FROM investors i "
        "LEFT JOIN users u ON u.id = i.owner_user_id WHERE i.id = %s", (investor_id,))
    return (row or {}).get("address"), (row or {}).get("display_name") or "there"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--send", action="store_true")
    parser.add_argument("--only")
    parser.add_argument("--hourly", action="store_true", help="light intraday pass: verdicts and the live index only")
    args = parser.parse_args()

    pool = db.get_pool(); pool.open(); pool.wait(timeout=20)
    from api.services import cadence, mail, watch

    ids = [args.only] if args.only else watch.everybody()
    ran = mailed = failed = 0
    for investor_id in ids:
        try:
            d = watch.run(investor_id, hourly=args.hourly)
        except Exception:
            log.error("watch failed for %s", investor_id); traceback.print_exc(); failed += 1
            continue
        ran += 1
        # Mailed: anything new to act on, and a drawdown crossing -- the one
        # "note" that is a letter, because it is the moment people sell.
        new_acts = [e for e in d["events"] if e["new"] and (e["severity"] == "act" or e["kind"] == "market")
                    and (not args.hourly or e["kind"] in watch.HOURLY_KINDS)]
        log.info("%s: %d open (%d to act, %d new) — %s", investor_id, len(d["events"]), d["to_act"], len(new_acts), d["reading"])
        if not new_acts:
            continue
        address, name = _address_for(investor_id)
        pref = cadence.preference(investor_id)
        if not args.send or not address or not pref.get("urgent_anyway", True) or not mail.configured():
            continue
        first = name.split()[0].title()
        result = mail.send(address, f"AlphaNivesh: {new_acts[0]['what']}",
                           mail.wrap(watch.as_html(first, d), preheader=d["reading"]),
                           kind="watch", investor_id=investor_id)
        if result.get("sent"):
            watch.mark_told(investor_id, [e["id"] for e in d["events"]])
            mailed += 1
        else:
            log.error("mail failed for %s: %s", investor_id, result.get("why"))
    log.info("done: %d ran, %d mailed, %d failed", ran, mailed, failed)


if __name__ == "__main__":
    main()
