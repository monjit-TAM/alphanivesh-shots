"""Mark the realised alpha ledger for everybody.

Monthly, on the first, after the NAV cut -- and it is harmless to run more
often, since a mark on the same day replaces itself.

    ./run.sh scripts_mark_alpha.py
    5 14 1 * * cd /opt/alphawealth && ./run.sh scripts_mark_alpha.py >> /var/log/alphanivesh-alpha.log 2>&1
"""
from __future__ import annotations
import logging, traceback
from api import db
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("mark")

def main() -> None:
    pool = db.get_pool(); pool.open(); pool.wait(timeout=20)
    from api.services import realised
    for r in db.fetch_all("SELECT id FROM investors ORDER BY id"):
        try:
            opened = realised.open_from_consents(r["id"])
            res = realised.mark(r["id"])
            log.info("%s: opened %d, marked %d, skipped %d", r["id"], opened, res["marked"], res["skipped"])
        except Exception:
            log.error("failed for %s", r["id"]); traceback.print_exc()

if __name__ == "__main__":
    main()
