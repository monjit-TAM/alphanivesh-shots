"""The monthly letter, for everybody owed one.

Runs on the 2nd of each month (after the 1st's ledger mark). Goes to anybody
on a monthly rhythm, and to anybody who has placed orders through the plan --
they are owed the ledger report whatever rhythm they chose. Never twice in a
calendar month; a failed send is retried on the next run.

    ./run.sh scripts_monthly_letter.py                 # who would get one, and the first lines
    ./run.sh scripts_monthly_letter.py --send          # send them
    ./run.sh scripts_monthly_letter.py --only <id>     # one person (with --send to send it)
    ./run.sh scripts_monthly_letter.py --only <id> --to me@example.com --send   # that person's letter, to you (a preview)

Install:
    45 3 2 * * cd /opt/alphawealth && ./run.sh scripts_monthly_letter.py --send >> /var/log/alphanivesh-monthly.log 2>&1
"""
from __future__ import annotations
import argparse, logging, traceback
from api import db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("monthly")


def _address(investor_id):
    row = db.fetch_one("SELECT coalesce(i.email, u.email) AS a FROM investors i LEFT JOIN users u ON u.id = i.owner_user_id WHERE i.id = %s",
                       (investor_id,))
    return (row or {}).get("a")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--send", action="store_true"); ap.add_argument("--only")
    ap.add_argument("--to", help="send to this address instead (a preview); MAIL_ONLY_TO still applies")
    a = ap.parse_args()
    pool = db.get_pool(); pool.open(); pool.wait(timeout=20)
    from api.services import mail, monthly
    ids = [a.only] if a.only else monthly.who_gets_it()
    sent = skipped = failed = 0
    for iid in ids:
        try:
            L = monthly.letter_for(iid)
        except Exception:
            log.error("letter failed for %s", iid); traceback.print_exc(); failed += 1; continue
        to = a.to or _address(iid)
        log.info("%s → %s | %s | %s", iid, to or "(no address)", L["subject"], (L["sections"][0]["text"] if L["sections"] else "")[:120])
        if not a.send:
            continue
        if not to or not mail.configured() or (not a.to and monthly.sent_this_month(to)):
            skipped += 1; continue
        r = mail.send(to, ("[Preview] " if a.to else "") + L["subject"], monthly.as_html(L), text=monthly.as_text(L),
                      kind="monthly_preview" if a.to else "monthly_letter", investor_id=iid)
        if r.get("sent"):
            sent += 1
        else:
            failed += 1; log.error("send failed for %s: %s", iid, r.get("why"))
    log.info("done: %d letters, %d sent, %d skipped, %d failed", len(ids), sent, skipped, failed)


if __name__ == "__main__":
    main()
