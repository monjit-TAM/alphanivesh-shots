"""Print what the FP sandbox actually returns, before anything relies on it.

Run on the droplet with the FP_* variables in the environment:

    ./run.sh -c "import tools.fp_shapes as t; t.main()"

It does, in order, and prints every response verbatim:
  1. a token                              -- proves the credentials
  2. GET fund scheme by ISIN              -- proves the OMS paths and shows a scheme object
  3. POST investor_profile (test person)  -- shows the profile object + what fields it wanted
  4. POST bank_account, mf_investment_account
  5. POST mf_purchase (pending)           -- shows the order object and its 'state'
  6. POST confirm with consent            -- shows whether the consent body is right
  7. POST payment                         -- shows the payment object / redirect
  8. GET the purchase                     -- shows the state after all that
  9. POST mf_redemption on the same account (will fail without units -- and
     the failure message is itself the shape we want to see)

Nothing here touches our database. Every failure prints and continues, so one
wrong field name does not hide the next nine answers. When a name is wrong,
fix it in api/services/fp.py's PATHS / FIELDS -- once.

The test person and bank details below are FP's sandbox conventions: any
syntactically valid PAN/IFSC is accepted there. Change them if the sandbox
rejects them, and never run this against production.
"""

from __future__ import annotations

import json
import sys
import traceback

from api.services import fp

# Sandbox test identities. Not real people.
PERSON = {"name": "Test Investor", "pan": "ABCDE1234F", "date_of_birth": "1985-06-15",
          "email": "test.investor@example.com", "mobile": "9999999999"}
BANK = {"account_number": "000000000001", "ifsc": "HDFC0000001", "holder_name": "Test Investor"}
ISIN = "INF109K01BL4"     # ICICI Prudential Bluechip Fund - Direct - Growth (change freely)


def show(label: str, fn, *a, **k):
    print("\n" + "=" * 78 + f"\n{label}\n" + "=" * 78)
    try:
        out = fn(*a, **k)
        print(json.dumps(out, indent=2, default=str)[:6000])
        return out
    except Exception as err:               # noqa: BLE001 -- printing is the point
        print("FAILED:", type(err).__name__, str(err)[:2000])
        return None


def main() -> None:
    if fp.ENV == "production":
        print("Refusing: FP_ENV is production. This script is for the sandbox.")
        sys.exit(2)
    print("rail:", fp.status())

    tok = show("1. token", fp._bearer)
    if not tok:
        print("\nNo token: check FP_TENANT / FP_CLIENT_ID / FP_CLIENT_SECRET. Stopping.")
        sys.exit(1)
    print("token ok (not printed)")

    show("2. fund scheme by ISIN", fp.fund_scheme, ISIN)

    profile = show("3. investor_profile", fp.create_investor_profile, **PERSON)
    pref = (profile or {}).get("id")
    bank = show("4a. bank_account", fp.create_bank_account, profile_ref=pref, **BANK) if pref else None
    acct = show("4b. mf_investment_account", fp.create_investment_account, profile_ref=pref) if pref else None
    aref, bref = (acct or {}).get("id"), (bank or {}).get("id")

    order = show("5. mf_purchase (pending)", fp.create_purchase,
                 account_ref=aref, isin=ISIN, amount=5000, user_ip="127.0.0.1") if aref else None
    oref = (order or {}).get("id")

    if oref:
        show("6. confirm with consent", fp.confirm, "purchase", oref,
             email=PERSON["email"], mobile=PERSON["mobile"])
        show("7. payment", fp.pay, order_refs=[order.get("old_id") or oref], bank_ref=bref,
             return_url="https://alphanivesh.com/act.html")
        show("8. fetch purchase", fp.fetch, "purchase", oref)

    if aref:
        show("9. mf_redemption (expected to fail: no units yet — read the message)",
             fp.create_redemption, account_ref=aref, isin=ISIN, amount=1000)

    print("\nDone. Compare each object's field names with PATHS / FIELDS in "
          "api/services/fp.py and correct there.")


if __name__ == "__main__":
    main()
