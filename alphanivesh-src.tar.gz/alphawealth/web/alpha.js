/* Your plan: the adviser's letter, then the moves, then the way to act.
 *
 * The letter is drawn first because it is what a person reads; the moves
 * underneath are the same plan as a list, with the amounts, the reason and
 * what each is worth. "Act on this" carries the moves into the placement
 * flow as orders, where the adviser of record and the person's consent take
 * over -- nothing here places anything.
 */
const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);
const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const num = n => Number(n) || 0;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
function short(n){ n = num(n); if (Math.abs(n) >= 1e7) return '₹' + (n/1e7).toFixed(2) + ' cr'; if (Math.abs(n) >= 1e5) return '₹' + (n/1e5).toFixed(1) + ' L'; return '₹' + inr.format(Math.round(n)); }
async function get(path){ const r = await fetch(API + path, {credentials: 'include'}); if (r.status === 401){ location.href = '/signin.html?next=/alpha.html'; throw new Error('signed out'); } const b = await r.json().catch(() => ({})); if (!r.ok) throw new Error(b.detail || 'Could not load this.'); return b; }

let INVESTOR = null;

function mixRow(label, now, target){
  const n = num(now), t = num(target);
  return `<div class="lab">${esc(label)}</div><div class="track"><i style="width:${Math.min(100,n)}%"></i><b style="left:${Math.min(100,t)}%" title="target ${t}%"></b></div><div class="num">${n.toFixed(0)}% → ${t.toFixed(0)}%</div>`;
}

function draw(L){
  const main = $('main'); main.innerHTML = '';
  if (!L.ready){ main.appendChild(el(`<div class="state"><h3>Not yet</h3><p>${esc(L.paragraphs?.[0] || '')}</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`)); return; }
  const p = L.plan, t = p.target, c = p.current, a = p.after, al = p.alpha;

  // The headline: where you are, where the plan takes you.
  const head = el(`<section class="headline"><p class="eyebrow">Your plan · ${esc(p.as_of)}</p>
    <p>${esc(p.reading)}</p>
    <div class="plan-head">
      <div class="pf"><p class="eyebrow">Identifiable, every year</p><b>${short(al.identifiable_per_year)}</b><small>cost and tax you need not pay</small></div>
      <div class="pf"><p class="eyebrow">Capital out of weak holdings</p><b>${short(al.quality_capital)}</b><small>verdict: reduce, or bottom of its category</small></div>
      <div class="pf"><p class="eyebrow">Moved to where it does a job</p><b>${short(al.allocation_moved)}</b><small>allocation brought to target</small></div>
      <div class="pf"><p class="eyebrow">Moves</p><b>${p.moves.length}</b><small>${num(al.from_new_money) > 0 ? short(al.from_new_money) + ' from new money' : 'all from what you hold'}</small></div>
    </div></section>`);
  main.appendChild(head);

  // The letter.
  const letter = el(`<section class="card letter"><p class="to">To ${esc(L.to)}</p></section>`);
  L.paragraphs.forEach(q => { letter.appendChild(el(`<h2>${esc(q.head)}</h2>`)); letter.appendChild(el(`<p>${esc(q.text)}</p>`)); });
  main.appendChild(letter);

  // The mix, now → target.
  const mix = el(`<section class="card"><h2>The mix: where you are, where the plan takes you</h2><p class="lede">The marker is the target for your age, horizon and capacity; the bar is where you are today. ${esc((t.rules || []).join(' '))}</p><div class="mix"></div><p class="note">After the moves: ${esc(a.equity_pct)}% equity · ${esc(a.debt_pct)}% debt · ${esc(a.gold_pct)}% gold · ${esc(a.cash_pct)}% liquid.${p.outside_the_mix && num(p.outside_the_mix.value) ? ' Outside the mix: ' + short(p.outside_the_mix.value) + ' (' + esc(p.outside_the_mix.holdings.map(h => h.name).join(', ')) + ') — ' + esc(p.outside_the_mix.note) : ''}</p></section>`);
  const grid = mix.querySelector('.mix');
  grid.innerHTML = mixRow('Equity', c.equity_pct, t.equity_pct) + mixRow('Debt', c.debt_pct, t.debt_pct) + mixRow('Gold', c.gold_pct, t.gold_pct) + mixRow('Liquid', c.cash_pct, t.cash_pct)
    + mixRow('· large cap', c.within_equity.large_pct, t.within_equity.large_pct) + mixRow('· mid cap', c.within_equity.mid_pct, t.within_equity.mid_pct) + mixRow('· small cap', c.within_equity.small_pct, t.within_equity.small_pct);
  main.appendChild(mix);

  // What the longer record permits: readings, each with its own replay, and the permits.
  if (p.regime && p.regime.readable){
    const r = p.regime;
    const card = el(`<section class="card"><h2>What the longer record permits</h2><p class="lede">${esc(r.principle)}</p><div class="steps"></div><div class="steps permits"></div><p class="note">Proxies: ${esc(Object.values(r.sources || {}).map(s => s.name + ' (since ' + String(s.from).slice(0,4) + ')').join(' · '))}.</p></section>`);
    const rd = card.querySelector('.steps');
    (r.readings || []).forEach(x => {
      const rp = x.replay || {}, lt = rp.like_today;
      const big = rp.edge_pct != null && Math.abs(rp.edge_pct) >= 2;
      const halves = (rp.halves || []).filter(h => h.edge_pct != null).map(h => String(h.from).slice(0,4) + '–' + String(h.to).slice(0,4) + ': ' + (h.edge_pct > 0 ? '+' : '') + h.edge_pct).join(' · ');
      rd.appendChild(el(`<div class="barrier"><b>${esc(x.name)}</b><span>${esc(x.value)}${lt ? ' · ' + lt.windows + ' months like this' : ''}${big ? ' · edge ' + (rp.edge_pct > 0 ? '+' : '') + rp.edge_pct + ' pts · ' + (rp.stable ? 'held out of sample' : 'shadow only') : ' · no edge'}</span><p>${esc(x.say)}${big && halves ? ' Each half: ' + esc(halves) + '.' : ''}</p></div>`));
    });
    (r.shadow || []).forEach(x => rd.appendChild(el(`<div class="barrier"><b>In shadow: ${esc({deployment: 'pace', equity_tilt_pts: 'equity tilt', gold_tilt_pts: 'gold tilt'}[x.permit] || x.permit)}</b><span>would be ${esc(String(x.would_be))} · is ${esc(String(x.is))}</span><p>${esc(x.why)}</p></div>`)));
    const pm = card.querySelector('.permits');
    (r.permits || []).forEach(x => pm.appendChild(el(`<div class="barrier"><b>${esc({deployment: 'New money goes in', equity_tilt_pts: 'Equity inside its band', gold_tilt_pts: 'Gold inside its band', valuation: 'Valuation', note: 'Trend'}[x.permit] || x.permit)}</b><span>${esc(typeof x.value === 'number' ? (x.value > 0 ? '+' : '') + x.value + ' pts' : x.value)}</span><p>${esc(x.why)}</p></div>`)));
    main.appendChild(card);
  }

  // What is in the way.
  if (p.barriers.length){
    const b = el(`<section class="card"><h2>What is in the way</h2><p class="lede">Each of these is costing you return, risk, or both. The moves below remove them in order.</p></section>`);
    p.barriers.forEach(x => b.appendChild(el(`<div class="barrier"><b>${esc(x.what || x.code)}</b><span>${num(x.size) ? short(x.size) : ''}${x.ask === 'dob' ? ' · <a href="/profile.html">add it</a>' : (x.watch ? ' · watching, not acting' : '')}</span><p>${esc(x.why)}</p></div>`)));
    main.appendChild(b);
  }

  // The moves.
  const mv = el(`<section class="card"><h2>The moves, in order</h2><p class="lede">Sells first so the money exists; then the switches that cost nothing; then the buys. One instruction per holding.</p><div class="steps"></div></section>`);
  const steps = mv.querySelector('.steps');
  p.moves.forEach(m => {
    const into = (m.into || []).map(x => x.name || x.symbol || x.stock_name).filter(Boolean).slice(0, 3);
    steps.appendChild(el(`<div class="mv"><div class="n">${m.order}</div><div>
      <h3><span class="kind ${esc(m.kind)}">${esc(m.kind)}</span>${esc(m.what)}</h3>
      <p>${esc(m.why)}</p>
      ${into.length ? `<p class="into">Into: ${esc(into.join(' · '))}</p>` : ''}
      <p class="basis">${esc(m.alpha_basis)}</p></div>
      <div class="amt">${short(m.amount)}${m.alpha_per_year ? `<small>+${short(m.alpha_per_year)} / yr</small>` : ''}</div></div>`));
  });
  const bar = el(`<div class="bar-row"><button type="button" class="btn" id="act">Act on this</button><a class="btn ghost" href="/advice.html">See the full advice</a><span class="note" style="margin:0;padding:0;border:0">${esc(p.what_this_is)}</span></div>`);
  bar.querySelector('#act').addEventListener('click', () => {
    const orders = [];
    p.moves.forEach(m => {
      if (m.kind === 'deploy' || m.kind === 'harvest') return;
      const parts = m.parts || [m];
      parts.forEach(x => {
        if (x.kind === 'buy'){
          (x.into || []).slice(0, 1).forEach(y => orders.push({instrument_id: null, symbol: y.symbol || y.code || '', name: y.name || y.symbol || x.what, side: 'buy', amount: x.amount, asset_class: x.asset_class || 'mutual_fund', because: 'alpha_plan', from_action: 'alpha_plan', note: x.what}));
        } else {
          orders.push({instrument_id: x.instrument_id, symbol: '', name: x.what, side: x.kind === 'switch' ? 'sell' : 'sell', amount: x.amount, asset_class: x.asset_class || 'mutual_fund', because: 'alpha_plan', from_action: 'alpha_plan', note: x.what});
        }
      });
    });
    try{ sessionStorage.setItem('proposed', JSON.stringify({investor_id: INVESTOR, ledger_id: null, source: 'alpha', orders})); }catch(err){}
    location.href = '/act.html';
  });
  mv.appendChild(bar);
  main.appendChild(mv);

  // Your next ₹10,000: where new money goes, by the plan's own arithmetic.
  {
    const c = el(`<section class="card"><h2>Where your next rupee goes</h2><p class="lede">New money is the cheapest way to move the mix — no sale, no tax. Give an amount and the plan says where it goes.</p>
      <form class="nm"><label>₹ <input name="amount" type="number" min="1000" step="500" value="10000" inputmode="numeric"></label>
      <select name="mode"><option value="lump">once</option><option value="monthly">every month</option></select>
      <button class="btn" type="submit">Show me</button></form><div class="nm-out"></div></section>`);
    const out = c.querySelector('.nm-out');
    const go = async (amount, mode) => {
      out.innerHTML = '<div class="skeleton" style="height:60px;margin-top:10px"></div>';
      try{
        const r = await get(`/next/${INVESTOR}?amount=${encodeURIComponent(amount)}&mode=${mode}`);
        out.innerHTML = '';
        if (!r.ready){ out.appendChild(el(`<p class="note">${esc(r.why)}</p>`)); return; }
        out.appendChild(el(`<p style="margin-top:10px">${esc(r.reading)}</p>`));
        const st = el('<div class="steps"></div>');
        r.lines.forEach(l => st.appendChild(el(`<div class="barrier"><b>${short(l.amount)} → ${esc(l.label)}${l.goal ? ' · for ' + esc(l.goal.name) : ''}</b><span>${esc((l.into || []).slice(0, 2).map(x => x.name).join(' · '))}</span><p>${esc(l.why)}</p></div>`)));
        out.appendChild(st);
        if (r.pace) out.appendChild(el(`<p class="note"><b>Pace: ${esc(r.pace.how)}.</b> ${esc(r.pace.why || '')}</p>`));
        const b = el(`<button class="btn" type="button" style="margin-top:10px">Act on this</button>`);
        b.addEventListener('click', () => {
          const orders = r.lines.map(l => { const y = (l.into || [])[0] || {}; return {instrument_id: null, symbol: y.code || '', name: y.name || l.label, side: 'buy', amount: l.amount, asset_class: 'mutual_fund', because: 'next_money', from_action: 'next_money', note: l.why.slice(0, 120)}; });
          try{ sessionStorage.setItem('proposed', JSON.stringify({investor_id: INVESTOR, ledger_id: null, source: 'alpha', orders})); }catch(err){}
          location.href = '/act.html';
        });
        out.appendChild(b);
        out.appendChild(el(`<p class="note">${esc(r.principle)}</p>`));
      }catch(err){ out.innerHTML = ''; out.appendChild(el(`<p class="note">${esc(err.message)}</p>`)); }
    };
    c.querySelector('form').addEventListener('submit', e => { e.preventDefault(); const f = new FormData(e.target); go(f.get('amount'), f.get('mode')); });
    main.appendChild(c);
    go(10000, 'lump');
  }

  // The yearly re-underwrite: everything older than seven years, read again.
  get(`/reunderwrite/${INVESTOR}`).then(U => {
    if (!(U.rows || []).length && !U.undated) return;
    const c = el(`<section class="card"><h2>Would you buy it today?</h2><p class="lede">${esc(U.reading)}</p><div class="steps"></div><p class="note">${esc(U.principle)}</p></section>`);
    const st = c.querySelector('.steps');
    (U.rows || []).forEach(r => st.appendChild(el(`<div class="barrier"><b>${esc(r.name)}</b><span>${esc(r.verdict)} · held ${r.held_years} yrs · ${short(r.value)}${num(r.tax_to_exit) ? ' · ' + short(r.tax_to_exit) + ' tax to exit' : ''}</span><p>${esc(r.say)}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});

  // The family: each person's tax-free allowance, used across the household.
  get(`/family/${INVESTOR}/harvest`).then(F => {
    if ((F.people || []).length < 2 && !num(F.total_saving)) return;
    const c = el(`<section class="card"><h2>Across the family</h2><p class="lede">${esc(F.reading)}</p><div class="steps"></div><p class="note">${esc(F.caveat)}</p></section>`);
    const st = c.querySelector('.steps');
    F.people.forEach(p => st.appendChild(el(`<div class="barrier"><b>${esc(p.name)}</b><span>${p.worth_doing ? short(p.available_gain) + ' to book · saves ' + short(p.saving) : (p.counts ? 'nothing to book' : 'not counted')}</span><p>${esc(p.say || '')}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});

  // What you actually own: company exposure counting through the funds, and the fund-pair overlaps.
  get(`/lookthrough/${INVESTOR}`).then(L => {
    if (!L.readable) return;
    const c = el(`<section class="card"><h2>What you actually own</h2><p class="lede">${esc(L.reading)}</p><div class="lt"></div><div class="steps pairs"></div><p class="note">${esc(L.principle)} Read through: ${L.coverage.funds_read} fund${L.coverage.funds_read === 1 ? '' : 's'}, ${esc(L.coverage.equity_seen_pct)}% of the equity${L.coverage.funds_not_read.length ? '; not readable: ' + esc(L.coverage.funds_not_read.join(', ')) : ''}. Top ten companies: ${esc(L.top10_pct)}% of everything.</p></section>`);
    const lt = c.querySelector('.lt');
    const max = Math.max(...L.companies.slice(0, 12).map(x => num(x.pct)), 1);
    L.companies.slice(0, 12).forEach(x => {
      const d = num(x.direct), t = num(x.through), tot = d + t || 1, w = num(x.pct) / max * 100;
      lt.appendChild(el(`<div class="ltrow" title="${esc(x.via.map(v => v.name + ' ' + short(v.rupees)).join(' · '))}"><span class="nm">${esc(x.name)}</span><span class="bar"><i class="dir" style="width:${w * d / tot}%"></i><i class="thr" style="width:${w * t / tot}%"></i></span><span class="pc">${num(x.pct).toFixed(1)}% · ${short(x.total)}</span></div>`));
    });
    lt.appendChild(el(`<p class="note" style="margin:6px 0 0"><span class="key dir"></span> held directly &nbsp; <span class="key thr"></span> through your funds</p>`));
    const pp = c.querySelector('.pairs');
    (L.pairs || []).slice(0, 4).forEach(p => pp.appendChild(el(`<div class="barrier"><b>${esc(p.a)} · ${esc(p.b)}</b><span>${p.overlap_pct}% alike · ${short(p.duplicated)} duplicated · ${p.shared} shared</span><p>${esc(p.top_shared.join(', '))}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});

  // Each holding's own return, where its record allows one.
  get(`/lookthrough/${INVESTOR}/irr`).then(R => {
    const c = el(`<section class="card"><h2>What each holding has returned</h2><p class="lede">${esc(R.reading)}</p><div class="steps"></div><p class="note">${esc(R.what_it_is)}</p></section>`);
    const st = c.querySelector('.steps');
    (R.holdings || []).slice(0, 12).forEach(h => st.appendChild(el(`<div class="barrier"><b>${esc(h.name)}</b><span>${num(h.irr_pct) >= 0 ? '+' : ''}${esc(h.irr_pct)}% a year · ${esc(h.years)} yrs · ${short(h.invested)} → ${short(h.value)}</span></div>`)));
    if ((R.not_given || []).length) st.appendChild(el(`<p class="note">No rate for: ${esc(R.not_given.slice(0, 8).map(n => n.name + ' (' + n.why + ')').join('; '))}${R.not_given.length > 8 ? '…' : ''}.</p>`));
    main.appendChild(c);
  }).catch(() => {});

  // Household stress: today's holdings through the last two crises, a rupee fall, a rate rise.
  get(`/stress/${INVESTOR}`).then(S => {
    if (!S.drawable) return;
    const c = el(`<section class="card"><h2>If it happened again</h2><p class="lede">${esc(S.reading)}</p><div class="steps"></div><p class="note">${esc(S.principle)}${S.proxies ? ' Proxies: ' + esc(Object.values(S.proxies).map(x => x.name + (x.from ? ' (since ' + String(x.from).slice(0,4) + ')' : '')).join(' · ')) + '.' : ''}</p></section>`);
    const st = c.querySelector('.steps');
    (S.episodes || []).forEach(e => st.appendChild(el(`<div class="barrier"><b>${esc(e.name)}</b><span>${short(e.loss)} · ${esc(e.loss_pct)}%${e.recovery_months_index ? ' · ' + e.recovery_months_index + ' months to recover' : ''}</span><p>${esc(e.say)}${e.worst && e.worst.length ? ' Hardest hit: ' + esc(e.worst.slice(0,3).map(w => w.name + ' (' + w.move_pct + '%)').join(', ')) + '.' : ''}</p></div>`)));
    (S.hypotheticals || []).forEach(e => st.appendChild(el(`<div class="barrier"><b>${esc(e.name)}</b><span>${num(e.effect) >= 0 ? '+' : ''}${short(e.effect)}</span><p>${esc(e.say)}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});

  // The realised ledger: what the plan's moves have earned, against what they replaced.
  get(`/realised/${INVESTOR}`).then(L => {
    const card = el(`<section class="card"><h2>What the plan has earned so far</h2><p class="lede">${esc(L.reading)}</p>
      <div class="plan-head" style="margin-bottom:12px">
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">This month</p><b>${short(L.by_period.this_month)}</b></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">This quarter</p><b>${short(L.by_period.this_quarter)}</b></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">This year</p><b>${short(L.by_period.this_year)}</b></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">Since the start</p><b>${short(L.by_period.since_start)}</b></div>
      </div><div class="steps"></div><p class="note">${esc(L.principle)}</p></section>`);
    const st = card.querySelector('.steps');
    (L.moves || []).slice(0, 12).forEach(m => st.appendChild(el(`<div class="barrier"><b>${esc(m.kind)} · ${esc(m.from || '')}${m.to ? ' → ' + esc(m.to) : ''}</b><span>${m.alpha == null ? 'not marked yet' : (num(m.alpha) >= 0 ? '+' : '') + short(m.alpha)} · placed ${esc(m.placed_on)}</span><p>${esc(m.note || m.basis || '')}</p></div>`)));
    main.appendChild(card);
  }).catch(() => {});

  // The commission meter: what regular plans have taken so far, running.
  get(`/commission/${INVESTOR}`).then(m => {
    if (!m.count) return;
    const c = el(`<section class="card"><h2>The commission meter</h2><p class="lede">${esc(m.reading)}</p><div class="steps"></div><p class="note">${esc(m.principle)}</p></section>`);
    const st = c.querySelector('.steps');
    m.meters.forEach(x => st.appendChild(el(`<div class="barrier"><b>${esc(x.name)}</b><span>${short(x.paid_to_date)} so far · ${short(x.per_year)} / yr${x.method === 'estimated' ? ' · estimated' : ''}</span><p>${esc(x.say)}${x.direct_name ? ' Direct twin: ' + esc(x.direct_name) + '.' : ''}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});
}

async function load(){
  $('main').innerHTML = '<div class="state"><div class="skeleton" style="height:120px"></div><p class="muted" style="margin-top:12px">Working out your plan — this reads every holding against its own record, so it takes a few seconds.</p></div>';
  try{ draw(await get(`/alpha/${INVESTOR}/letter`)); }
  catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not build the plan</h3><p>${esc(err.message)}</p></div>`)); }
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Nothing here yet</h3><p>Bring in a statement first.</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`)); return; }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(`<option value="${esc(i.id)}">${esc(i.display_name)}</option>`)));
    picker.style.display = investors.length > 1 ? '' : 'none';
    let wanted = null; try{ wanted = new URLSearchParams(location.search).get('investor') || sessionStorage.getItem('investor'); }catch(err){}
    INVESTOR = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = INVESTOR; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){}
    picker.addEventListener('change', e => { INVESTOR = e.target.value; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){} load(); });
    load();
  }catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`)); }
}
start();
