/* Goals: what the money is for.
 *
 * Three views on one page, chosen by the hash:
 *   #all            every goal, and where the plan as a whole stands
 *   #goal=<id>      one goal -- earmarks, the replay, the currency, what moved
 *   #conflict       where goals want the same rupees, and what each choice costs
 *
 * Nothing on this page forecasts. The replay says how often a plan like this
 * reached its target across every stretch of history we hold, with the sample
 * size beside it; the currency view says what the rupee did over stretches
 * this long; the conflict view says what a choice costs the other goal. None
 * of it ranks the goals, because which one matters more is not ours to say.
 *
 * The slow calls (replay, since, competition) are fetched after the fast ones
 * and drawn into their own cards, so the goal itself is on screen in under a
 * second and the odds arrive when they arrive.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const money = n => '₹' + inr.format(Math.round(Number(n) || 0));
const num = n => Number(n) || 0;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
const plain = s => String(s ?? '').replace(/_/g, ' ');
const pct = v => (v == null ? 'cannot say' : v + '%');

/* Lakh / crore for the big figures, rupees for the small ones. */
function short(n){
  n = num(n);
  if (Math.abs(n) >= 1e7) return '₹' + (n / 1e7).toFixed(2) + ' cr';
  if (Math.abs(n) >= 1e5) return '₹' + (n / 1e5).toFixed(1) + ' L';
  return money(n);
}
function fmoney(amount, ccy){
  ccy = (ccy || 'INR').toUpperCase();
  if (ccy === 'INR') return short(amount);
  return ccy + ' ' + new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0}).format(num(amount));
}

async function get(path){
  const res = await fetch(API + path, {credentials: 'include'});
  if (res.status === 401){ location.href = '/signin.html?next=' + encodeURIComponent(location.pathname + location.hash); throw new Error('signed out'); }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.detail || 'Could not load this.');
  return body;
}
async function send(method, path, body){
  const res = await fetch(API + path, {method, credentials: 'include',
    headers: {'Content-Type': 'application/json'}, body: body ? JSON.stringify(body) : undefined});
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || 'That did not work.');
  return data;
}

function T(key, fallback){
  if (typeof t === 'function'){ const f = t(key); if (f && f !== key) return f; }
  return fallback || ENGLISH[key] || key;
}
const ENGLISH = {
  "goals.title": "What the money is for",
  "goals.lede": "A goal turns 'is this enough' from a feeling into a calculation. Nothing here is a forecast: every figure is what actually happened across every stretch of history we hold.",
  "goals.all": "All goals", "goals.conflict": "Where they compete", "goals.add": "Add a goal",
  "goals.none": "No goals yet", "goals.none_p": "Set one and the plan gets a number it can be checked against.",
  "goals.committed": "Committed a month", "goals.earmarked": "Earmarked", "goals.still": "Still needed",
  "goals.unassigned": "Not assigned to anything", "goals.covered": "covered",
  "goals.earmarks": "What is behind it", "goals.replay": "How this plan has actually gone",
  "goals.currency": "The rupee, and this bill", "goals.since": "What moved since last time",
  "goals.monthly": "What goes in each month", "goals.assign": "Assign a holding",
  "goals.release": "Take off", "goals.back": "← All goals",
  "goals.reached": "Reached the target", "goals.worst": "Worst stretch", "goals.tenth": "Worst tenth",
  "goals.median": "Middle", "goals.best": "Best", "goals.stretches": "stretches of",
  "goals.years": "years", "goals.save": "Save", "goals.saving": "Saving…",
};

let INVESTOR = null;
let KINDS = [];

/* ------------------------------------------------------------ the frame */

function frame(view){
  const main = $('main');
  main.innerHTML = '';
  main.appendChild(el(`
    <div class="g-head">
      <div><h1 class="display">${esc(T('goals.title'))}</h1>
      <p>${esc(T('goals.lede'))}</p></div>
    </div>`));
  main.appendChild(el(`
    <nav class="tabs" aria-label="Goal views">
      <a href="#all" ${view === 'all' ? 'aria-current="page"' : ''}>${esc(T('goals.all'))}</a>
      <a href="#conflict" ${view === 'conflict' ? 'aria-current="page"' : ''}>${esc(T('goals.conflict'))}</a>
      <a href="#new" ${view === 'new' ? 'aria-current="page"' : ''}>${esc(T('goals.add'))}</a>
    </nav>`));
  const body = el('<div id="body"></div>');
  main.appendChild(body);
  return body;
}
function card(title, lede){
  const c = el(`<section class="card"><h2>${esc(title)}</h2>${lede ? `<p class="lede">${esc(lede)}</p>` : ''}<div class="card-body"></div></section>`);
  c.body = c.querySelector('.card-body');
  return c;
}
function skeleton(h){ return el(`<div class="skeleton" style="height:${h || 80}px;margin-top:12px"></div>`); }
function failed(err){ return el(`<p class="err">${esc(err.message || err)}</p>`); }

/* ------------------------------------------------------------ all goals */

async function viewAll(){
  const body = frame('all');
  body.appendChild(skeleton(120));
  let all;
  try{ all = await get(`/goals/${INVESTOR}`); }
  catch(err){ body.innerHTML = ''; body.appendChild(failed(err)); return; }
  body.innerHTML = '';

  if (!all.count){
    body.appendChild(el(`<div class="state"><h3>${esc(T('goals.none'))}</h3>
      <p>${esc(T('goals.none_p'))}</p><a class="cta" href="#new">${esc(T('goals.add'))}</a></div>`));
    return;
  }

  const head = el(`<section class="headline"><p class="eyebrow">${all.count} goal${all.count === 1 ? '' : 's'}</p>
    <div class="figures">
      <div class="fig"><p class="eyebrow">${esc(T('goals.committed'))}</p><b>${money(all.committed_monthly)}</b></div>
      <div class="fig"><p class="eyebrow">${esc(T('goals.earmarked'))}</p><b>${short(all.earmarked)}</b></div>
      <div class="fig"><p class="eyebrow">${esc(T('goals.still'))}</p><b>${short(all.still_needed)}</b><small>at today's prices and rates</small></div>
      <div class="fig"><p class="eyebrow">${esc(T('goals.unassigned'))}</p><b>${short(all.unassigned && all.unassigned.worth)}</b><small>${esc(all.unassigned ? all.unassigned.share_pct + '% of what you hold' : '')}</small></div>
    </div></section>`);
  head.querySelectorAll('.fig').forEach(f => { f.style.background = 'rgba(255,255,255,.07)'; f.style.borderColor = 'rgba(255,255,255,.12)'; });
  body.appendChild(head);

  const list = card(T('goals.all'));
  all.goals.forEach(g => {
    const covered = Math.min(100, num(g.covered_pct));
    const fx = g.currency && g.currency !== 'INR';
    const row = el(`<article class="goal-row">
      <div>
        <p class="kind">${esc(g.kind_name || g.kind)} · ${esc(g.target_date)} · ${g.years_left} ${esc(T('goals.years'))}</p>
        <h3><a href="#goal=${esc(g.id)}">${esc(g.name)}</a></h3>
        <p>${esc(g.reading || '')}</p>
        <div class="bar ${covered < 100 ? 'short' : ''}"><i style="width:${covered}%"></i></div>
        ${g.mismatch ? `<span class="flag risk">Money needed soon is in equity</span>` : ''}
        ${fx ? `<span class="flag fx">${esc(g.currency)} bill · ${short(g.target_in_inr)} today</span>` : ''}
      </div>
      <div class="side-fig"><b>${fmoney(g.target_amount, g.currency)}</b>
        <span>${covered.toFixed(0)}% ${esc(T('goals.covered'))} · ${money(g.monthly)}/mo</span></div>
    </article>`);
    list.body.appendChild(row);
  });
  body.appendChild(list);

  if (all.mismatches && all.mismatches.length){
    const m = card('Worth fixing first', 'Money needed inside three years sitting in equity is the most common real error in personal finance, and only earmarking can see it.');
    all.mismatches.forEach(x => m.body.appendChild(el(`<div class="item bad"><h3>${esc(x.goal_name)}</h3><p>${esc(x.reading)}</p><p class="muted">${esc(x.what_it_means || '')}</p></div>`)));
    body.appendChild(m);
  }

  if (all.unassigned && all.unassigned.count){
    const u = card(T('goals.unassigned'), all.unassigned.reading);
    const tbl = el('<table class="calls"><thead><tr><th>Holding</th><th>Free</th><th>Worth</th></tr></thead><tbody></tbody></table>');
    all.unassigned.holdings.slice(0, 12).forEach(h => tbl.querySelector('tbody').appendChild(el(
      `<tr><td class="name">${esc(h.name)}<span class="share">${esc(plain(h.asset_class))}</span></td><td>${esc(h.free_pct)}%</td><td>${short(h.worth)}</td></tr>`)));
    u.body.appendChild(tbl);
    body.appendChild(u);
  }
}

/* ------------------------------------------------------------ new goal */

async function viewNew(){
  const body = frame('new');
  if (!KINDS.length){ try{ KINDS = (await get('/goals/kinds')).kinds; }catch(err){ KINDS = []; } }
  const c = card(T('goals.add'), 'The goal is stored in what it costs — a US degree in dollars, a house in rupees. Everything about where you stand against it is computed fresh every time you look.');
  const f = el(`<form class="inline">
    <div><label>Kind<select name="kind">${KINDS.map(k => `<option value="${esc(k.kind)}">${esc(k.name)}</option>`).join('')}</select></label></div>
    <div><label>Name<input name="name" placeholder="e.g. Aarav's masters" required></label></div>
    <div><label>Costs<input name="target_amount" type="number" min="1" step="1" required></label></div>
    <div><label>In<select name="currency"><option>INR</option><option>USD</option><option>GBP</option><option>EUR</option><option>AED</option><option>JPY</option></select></label></div>
    <div><label>Needed by<input name="target_date" type="date" required></label></div>
    <div><label>Putting in monthly<input name="monthly" type="number" min="0" step="100" value="0"></label></div>
    <div><label>Raising it yearly by %<input name="step_up_pct" type="number" min="0" max="50" step="1" value="0"></label></div>
    <div class="wide"><label>Why (optional)<input name="why" placeholder="What this is really for"></label></div>
    <div class="wide"><button class="btn" type="submit">${esc(T('goals.save'))}</button><span class="err" id="newerr"></span></div>
  </form>`);
  f.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(f); const payload = {};
    fd.forEach((v, k) => { if (v !== '') payload[k] = v; });
    const btn = f.querySelector('button'); btn.disabled = true; btn.textContent = T('goals.saving');
    try{
      const made = await send('POST', `/goals/${INVESTOR}`, payload);
      location.hash = '#goal=' + made.id;
    }catch(err){ f.querySelector('#newerr').textContent = err.message; btn.disabled = false; btn.textContent = T('goals.save'); }
  });
  c.body.appendChild(f);
  body.appendChild(c);
}

/* ------------------------------------------------------------ one goal */

async function viewGoal(id){
  const body = frame('goal');
  body.appendChild(el(`<p style="margin-bottom:12px"><a class="back" href="#all">${esc(T('goals.back'))}</a></p>`));
  body.appendChild(skeleton(140));
  let g;
  try{ g = await get(`/goals/one/${id}`); }
  catch(err){ body.appendChild(failed(err)); return; }
  body.querySelector('.skeleton').remove();

  const fx = g.currency && g.currency !== 'INR';
  const covered = Math.min(100, num(g.covered_pct));
  body.appendChild(el(`<section class="headline">
    <p class="eyebrow">${esc(g.kind_name || g.kind)} · needed ${esc(g.target_date)} · ${g.years_left} ${esc(T('goals.years'))}</p>
    <h2 class="display" style="font-size:clamp(22px,3vw,30px);margin-top:6px">${esc(g.name)}</h2>
    ${g.why ? `<p style="opacity:.8">${esc(g.why)}</p>` : ''}
    <div class="figures">
      <div class="fig" style="background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)"><p class="eyebrow">Costs</p><b>${fmoney(g.target_amount, g.currency)}</b>${fx ? `<small>${short(g.target_in_inr)} at the latest fixing</small>` : ''}</div>
      <div class="fig" style="background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)"><p class="eyebrow">${esc(T('goals.earmarked'))}</p><b>${short(g.worth)}</b><small>${covered.toFixed(1)}% ${esc(T('goals.covered'))}</small></div>
      <div class="fig" style="background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)"><p class="eyebrow">${esc(T('goals.still'))}</p><b>${short(g.still_needed)}</b><small>at today's prices</small></div>
      <div class="fig" style="background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)"><p class="eyebrow">Monthly</p><b>${money(g.monthly)}</b>${num(g.step_up_pct) ? `<small>rising ${esc(g.step_up_pct)}% a year</small>` : ''}</div>
    </div>
    <p style="margin-top:14px">${esc(g.reading || '')}</p>
    ${g.mismatch ? `<p style="margin-top:10px;color:#F3C9C4">${esc(g.mismatch.reading)}</p>` : ''}
  </section>`));

  // Earmarks
  const em = card(T('goals.earmarks'), 'A goal claims specific holdings, not a share of the portfolio — so the same rupee cannot be counted for two goals, and money needed soon can be seen sitting in the wrong place.');
  drawEarmarks(em, g, id);
  body.appendChild(em);

  // Monthly
  const mo = card(T('goals.monthly'));
  const mf = el(`<form class="inline">
    <div><label>Monthly<input name="monthly" type="number" min="0" step="100" value="${esc(num(g.monthly))}"></label></div>
    <div><label>Rising yearly by %<input name="step_up_pct" type="number" min="0" max="50" step="1" value="${esc(num(g.step_up_pct))}"></label></div>
    <div><button class="btn ghost" type="submit">${esc(T('goals.save'))}</button><span class="err"></span></div></form>`);
  mf.addEventListener('submit', async e => {
    e.preventDefault(); const fd = new FormData(mf);
    try{ await send('PUT', `/goals/one/${id}/monthly`, {monthly: fd.get('monthly'), step_up_pct: fd.get('step_up_pct')}); viewGoal(id); }
    catch(err){ mf.querySelector('.err').textContent = err.message; }
  });
  mo.body.appendChild(mf);
  body.appendChild(mo);

  // Slow cards, in parallel, each drawing itself when it lands.
  const rp = card(T('goals.replay')); rp.body.appendChild(skeleton(90)); body.appendChild(rp);
  let cv = null;
  if (fx){ cv = card(T('goals.currency')); cv.body.appendChild(skeleton(70)); body.appendChild(cv); }
  const gl = card('The glide path'); gl.body.appendChild(skeleton(60)); body.appendChild(gl);
  const sc = card(T('goals.since')); sc.body.appendChild(skeleton(50)); body.appendChild(sc);
  get(`/goals/one/${id}/glide`).then(x => drawGlide(gl, x, id)).catch(err => { gl.body.innerHTML = ''; gl.body.appendChild(failed(err)); });

  get(`/goals/one/${id}/replay`).then(r => drawReplay(rp, r, g)).catch(err => { rp.body.innerHTML = ''; rp.body.appendChild(failed(err)); });
  if (cv){
    const v = g.currency_view;
    (v ? Promise.resolve(v) : get(`/goals/one/${id}/currency`)).then(x => drawCurrency(cv, x)).catch(err => { cv.body.innerHTML = ''; cv.body.appendChild(failed(err)); });
  }
  get(`/goals/one/${id}/since`).then(s => drawSince(sc, s)).catch(err => { sc.body.innerHTML = ''; sc.body.appendChild(failed(err)); });
}

function drawEarmarks(cardEl, g, id){
  const box = cardEl.body; box.innerHTML = '';
  const held = (g.earmarked && g.earmarked.holdings) || [];
  if (held.length){
    const tbl = el('<table class="calls"><thead><tr><th>Holding</th><th>Share</th><th>Worth</th><th></th></tr></thead><tbody></tbody></table>');
    held.forEach(h => {
      const tr = el(`<tr><td class="name">${esc(h.name)}<span class="share">${esc(plain(h.asset_class))} · whole holding ${short(h.whole_holding)}</span></td>
        <td>${esc(h.share_pct)}%</td><td>${short(h.worth)}</td>
        <td><button type="button" class="btn ghost small">${esc(T('goals.release'))}</button></td></tr>`);
      tr.querySelector('button').addEventListener('click', async () => {
        try{ await send('DELETE', `/goals/one/${id}/earmark/${h.instrument_id}`); viewGoal(id); }
        catch(err){ box.appendChild(failed(err)); }
      });
      tbl.querySelector('tbody').appendChild(tr);
    });
    box.appendChild(tbl);
  } else {
    box.appendChild(el('<p class="muted" style="margin-top:8px">Nothing is earmarked to this goal yet. Until something is, there is no plan to replay — only a target.</p>'));
  }

  // Assign form, from what is still free.
  const f = el(`<form class="inline"><div class="wide"><label>${esc(T('goals.assign'))}<select name="instrument_id"><option value="">Loading what is free…</option></select></label></div>
    <div><label>Share of it %<input name="share_pct" type="number" min="1" max="100" step="1" value="100"></label></div>
    <div><button class="btn ghost" type="submit">Assign</button><span class="err"></span></div></form>`);
  box.appendChild(f);
  get(`/goals/${INVESTOR}/unassigned`).then(u => {
    const sel = f.querySelector('select'); sel.innerHTML = '<option value="">Choose a holding</option>';
    (u.holdings || []).forEach(h => sel.appendChild(el(`<option value="${esc(h.instrument_id)}" data-free="${esc(h.free_pct)}">${esc(h.name)} — ${esc(h.free_pct)}% free, ${short(h.worth)}</option>`)));
    sel.addEventListener('change', () => { const o = sel.selectedOptions[0]; if (o && o.dataset.free) f.querySelector('[name=share_pct]').value = Math.floor(num(o.dataset.free)); });
  }).catch(() => {});
  f.addEventListener('submit', async e => {
    e.preventDefault(); const fd = new FormData(f);
    if (!fd.get('instrument_id')) return;
    try{ await send('POST', `/goals/one/${id}/earmark`, {instrument_id: fd.get('instrument_id'), share_pct: fd.get('share_pct')}); viewGoal(id); }
    catch(err){ f.querySelector('.err').textContent = err.message; }
  });
}

function drawReplay(cardEl, r, g){
  const box = cardEl.body; box.innerHTML = '';
  if (r.currency_note) box.appendChild(el(`<p class="muted" style="margin-top:6px">${esc(r.currency_note)}</p>`));
  if (!r.drawable){
    box.appendChild(el(`<p style="margin-top:10px;font-size:14px;line-height:1.6">${esc(r.why || 'Could not replay this.')}</p>`));
    if (r.what_would_help) box.appendChild(el(`<p class="muted" style="margin-top:6px">${esc(r.what_would_help)}</p>`));
    if (r.skipped && r.skipped.length) box.appendChild(el(`<p class="muted" style="margin-top:6px">Not in this: ${esc(r.skipped.join(', '))}</p>`));
    return;
  }
  box.appendChild(el(`<p class="big" style="margin-top:12px">${esc(r.reached_pct)}%<small>${esc(T('goals.reached'))} · ${r.windows} ${esc(T('goals.stretches'))} ${r.horizon_years} ${esc(T('goals.years'))}${r.thin ? ' · thin sample' : ''}</small></p>`));
  box.appendChild(el(`<div class="dist">
    <div><p class="eyebrow">${esc(T('goals.worst'))}</p><b>${short(r.worst)}</b></div>
    <div><p class="eyebrow">${esc(T('goals.tenth'))}</p><b>${short(r.tenth)}</b></div>
    <div><p class="eyebrow">${esc(T('goals.median'))}</p><b>${short(r.median)}</b></div>
    <div><p class="eyebrow">${esc(T('goals.best'))}</p><b>${short(r.best)}</b></div></div>`));
  box.appendChild(el(`<p style="margin-top:14px;font-size:14px;line-height:1.6;max-width:78ch">${esc(r.reading)}</p>`));
  if (r.on_skipped) box.appendChild(el(`<p class="muted" style="margin-top:8px">${esc(r.on_skipped)}</p>`));
  box.appendChild(el(`<p class="note">${esc(r.what_this_is)} History from ${esc(r.from)} to ${esc(r.to)}.</p>`));
}

function drawCurrency(cardEl, v){
  const box = cardEl.body; box.innerHTML = '';
  if (!v || !v.foreign){ box.appendChild(el('<p class="muted">This goal is in rupees.</p>')); return; }
  if (!v.rate){ box.appendChild(el(`<p style="margin-top:8px">${esc(v.why_no_rate || 'No rate held.')}</p>`)); return; }
  const h = v.history || {};
  box.appendChild(el(`<div class="dist">
    <div><p class="eyebrow">At today's fixing</p><b>${short(v.at_today)}</b></div>
    <div><p class="eyebrow">Plan around</p><b>${v.plan_for ? short(v.plan_for) : '—'}</b></div>
    <div><p class="eyebrow">If a bad stretch</p><b>${v.if_bad_stretch ? short(v.if_bad_stretch) : '—'}</b></div>
    <div><p class="eyebrow">Rupee weakened in</p><b>${h.rupee_weakened_pct ? esc(h.rupee_weakened_pct) + '%' : '—'}</b></div></div>`));
  box.appendChild(el(`<p style="margin-top:14px;font-size:14px;line-height:1.6;max-width:78ch">${esc(v.reading || '')}</p>`));
  if (v.rate && v.rate.as_of) box.appendChild(el(`<p class="note">${esc(v.currency)}/INR ${esc(v.rate.rate)} as of ${esc(v.rate.as_of)} — ${esc(v.rate.source || '')}.</p>`));
}

function drawSince(cardEl, s){
  const box = cardEl.body; box.innerHTML = '';
  const flag = s.urgency ? `<span class="flag ${esc(s.urgency)}">${s.urgency === 'now' ? 'matters now' : s.urgency === 'soon' ? 'worth watching' : 'long way out'}</span>` : '';
  box.appendChild(el(`<p style="margin-top:8px;font-size:14px;line-height:1.6;max-width:78ch">${esc(s.reading || '')}</p>`));
  if (flag) box.appendChild(el(flag));
  const hist = (s.history || []).slice().reverse();
  if (hist.length >= 2){
    // The earmarked value on its own scale. Against the target it flattened
    // to a line, because a goal 7% funded moves within a band the target
    // dwarfs -- and the movement is the point of the picture.
    const pts = hist.map(h => num(h.worth));
    const lo = Math.min(...pts), hi = Math.max(...pts), span = (hi - lo) || 1;
    const W = 600, H = 56;
    const path = pts.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i / (pts.length - 1)) * W},${H - ((v - lo) / span) * (H - 8) - 4}`).join(' ');
    box.appendChild(el(`<svg class="spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-label="Earmarked value at each look">
      <path d="${path}" fill="none" stroke="var(--gain)" stroke-width="2" stroke-linejoin="round"/></svg>`));
    box.appendChild(el(`<p class="muted">What is earmarked, at each of the ${hist.length} looks since ${esc(hist[0].read_at.slice(0, 10))}: from ${short(lo)} to ${short(hi)}. The target is ${short(hist[hist.length - 1].target_in_inr)}.</p>`));
  }
}

/* ------------------------------------------------------------ conflict */

function drawGlide(c, x, id){
  const box = c.body; box.innerHTML = '';
  if (!x.drawable){ box.appendChild(el(`<p class="muted">${esc(x.why)}</p>`)); return; }
  box.appendChild(el(`<p>${esc(x.reading)}</p>`));
  const path = el(`<div class="glide"></div>`);
  x.path.forEach(st => {
    const here = Number(x.years_left) >= st.years_left && (x.path.find(o => o.years_left > st.years_left && Number(x.years_left) >= o.years_left) == null);
    path.appendChild(el(`<div class="gstep${here ? ' here' : ''}"><b>${st.equity_pct}%</b><span>${st.years_left === 0 ? 'last year' : st.years_left + '+ yrs'}</span></div>`));
  });
  box.appendChild(path);
  box.appendChild(el(`<p class="muted" style="margin-top:8px">Earmarked ${short(x.worth)} · ${esc(x.equity_pct)}% equity now against ${esc(x.target_equity_pct)}% for ${Number(x.years_left).toFixed(1)} years out${x.next_step ? ' · next step ' + esc(x.next_step.on) + ' → ' + esc(x.next_step.equity_pct) + '%' : ''}.</p>`));
  if (x.instruction && x.instruction.kind === 'move' && x.instruction.moves.length){
    const b = el(`<button class="btn" type="button" style="margin-top:8px">Act on this</button>`);
    b.addEventListener('click', () => {
      const orders = x.instruction.moves.map(m => ({instrument_id: m.instrument_id, symbol: '', name: m.name, side: 'sell', amount: m.amount, asset_class: 'mutual_fund', because: 'glide', from_action: 'glide', note: `Glide: ${x.name}`}));
      (x.instruction.moves[0].into || []).slice(0, 1).forEach(y => orders.push({instrument_id: null, symbol: y.code || y.symbol || '', name: y.name || '', side: 'buy', amount: x.instruction.amount, asset_class: 'mutual_fund', because: 'glide', from_action: 'glide', note: `Glide: ${x.name}`}));
      try{ sessionStorage.setItem('proposed', JSON.stringify({investor_id: INVESTOR, ledger_id: null, source: 'alpha', orders})); }catch(err){}
      location.href = '/act.html';
    });
    box.appendChild(b);
  }
  box.appendChild(el(`<p class="note" style="margin-top:10px">${esc(x.principle)}</p>`));
}

async function viewConflict(){
  const body = frame('conflict');
  body.appendChild(el(`<p class="muted" style="margin-bottom:14px;max-width:78ch">Where your goals want the same rupees, and what each choice would cost the other goal — in how often it reached its target across every stretch of history we hold. Nothing here is ranked or recommended. Which goal matters more is yours to decide; this shows the price of deciding.</p>`));
  body.appendChild(skeleton(120));
  let c;
  try{ c = await get(`/goals/${INVESTOR}/competition`); }
  catch(err){ body.appendChild(failed(err)); return; }
  body.querySelector('.skeleton').remove();
  if (!c.goals){ body.appendChild(el(`<div class="state"><h3>${esc(c.reading || 'Nothing to compete')}</h3><a class="cta" href="#new">${esc(T('goals.add'))}</a></div>`)); return; }

  const s = c.committed_against_spare || {};
  const spare = card('Committed against spare');
  spare.body.appendChild(el(`<div class="figures">
    <div class="fig"><p class="eyebrow">Committed a month</p><b>${money(s.committed_monthly)}</b><small>${s.goals_committing || 0} goals</small></div>
    <div class="fig"><p class="eyebrow">Spare a month</p><b>${s.spare != null ? money(s.spare) : '—'}</b><small>${s.computable ? 'income − expenses' + (s.monthly_emi ? ' − EMIs' : '') : 'needs income and expenses'}</small></div>
    <div class="fig"><p class="eyebrow">Gap</p><b>${s.computable ? (num(s.gap) > 0 ? money(s.gap) : 'none') : '—'}</b></div></div>`));
  spare.body.appendChild(el(`<p style="margin-top:14px;font-size:14px;line-height:1.6;max-width:78ch">${esc(s.reading || '')}</p>`));
  if (s.computable === false) spare.body.appendChild(el(`<p class="muted" style="margin-top:6px"><a href="/profile.html" style="color:var(--ox)">Add your income and expenses</a> and this becomes a number.</p>`));
  body.appendChild(spare);

  const h = c.holdings || {};
  const hc = card('Holdings claimed by more than one goal', h.reading);
  (h.contested || []).forEach(x => hc.body.appendChild(el(`<div class="item"><h3>${esc(x.name)} <span class="muted">· ${short(x.worth)} · ${esc(x.claimed_pct)}% claimed</span></h3>
    <p>${x.claims.map(k => `${esc(k.goal_name)} ${esc(k.share_pct)}% (${short(k.worth)})`).join(' · ')}</p></div>`)));
  if (h.fully_claimed && h.fully_claimed.length) hc.body.appendChild(el(`<p class="muted" style="margin-top:8px">Fully claimed: ${esc(h.fully_claimed.join(', '))}.</p>`));
  body.appendChild(hc);

  if ((c.holding_trades || []).length){
    const tc = card('What each choice costs', 'For each shared holding: both goals’ odds if it went wholly to one or the other. Stretches that happened, not a forecast.');
    c.holding_trades.forEach(tr => {
      const d = el(`<div class="trade"><b>${esc(tr.holding)}</b><p>${esc(tr.reading || tr.why || '')}</p></div>`);
      if (tr.replayed && tr.a && tr.b){
        d.appendChild(el(`<div class="odds">
          <div><b>${esc(tr.a.name)}</b>now ${pct(tr.a.reached_now)} · takes all ${pct(tr.a.reached_if_takes_all)} · gives up ${pct(tr.a.reached_if_gives_up)}</div>
          <div><b>${esc(tr.b.name)}</b>now ${pct(tr.b.reached_now)} · takes all ${pct(tr.b.reached_if_takes_all)} · gives up ${pct(tr.b.reached_if_gives_up)}</div></div>`));
      }
      tc.body.appendChild(d);
    });
    body.appendChild(tc);
  }
  if ((c.contribution_trades || []).length){
    const cc = card('If one goal absorbed the whole monthly gap');
    c.contribution_trades.forEach(x => cc.body.appendChild(el(`<div class="trade"><b>${esc(x.name)}</b><p>${esc(x.reading || 'Not replayed.')}</p></div>`)));
    body.appendChild(cc);
  }
}

/* ------------------------------------------------------------ routing */

function route(){
  if (!INVESTOR) return;
  const h = location.hash || '#all';
  if (h.startsWith('#goal=')) return viewGoal(decodeURIComponent(h.slice(6)));
  if (h === '#conflict') return viewConflict();
  if (h === '#new') return viewNew();
  return viewAll();
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){
      $('main').innerHTML = '';
      $('main').appendChild(el(`<div class="state"><h3>Nothing here yet</h3><p>Bring in a statement first.</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`));
      return;
    }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(`<option value="${esc(i.id)}">${esc(i.display_name)}</option>`)));
    picker.style.display = investors.length > 1 ? '' : 'none';
    let wanted = null;
    try{ wanted = new URLSearchParams(location.search).get('investor') || sessionStorage.getItem('investor'); }catch(err){}
    INVESTOR = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = INVESTOR;
    try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){}
    picker.addEventListener('change', e => {
      INVESTOR = e.target.value;
      try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){}
      const u = new URL(location.href); u.searchParams.set('investor', INVESTOR); history.replaceState(null, '', u);
      location.hash = '#all'; route();
    });
    window.addEventListener('hashchange', route);
    route();
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(`<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`));
  }
}

start();
