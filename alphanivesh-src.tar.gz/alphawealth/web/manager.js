/* Your portfolio manager.
 *
 * Every asset class reviewed the way a fund manager reviews a book: what it is
 * doing, whether each holding still earns its place, whether something better
 * is available after tax, and exactly what to do and how. The book of orders
 * comes first because it is what to do; the reviews below are why.
 */
const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);
const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const num = n => Number(n) || 0;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
function short(n){ n = num(n); if (Math.abs(n) >= 1e7) return '₹' + (n/1e7).toFixed(2) + ' cr'; if (Math.abs(n) >= 1e5) return '₹' + (n/1e5).toFixed(1) + ' L'; return '₹' + inr.format(Math.round(n)); }
async function get(path){ const r = await fetch(API + path, {credentials: 'include'}); if (r.status === 401){ location.href = '/signin.html?next=/manager.html'; throw new Error('signed out'); } const b = await r.json().catch(() => ({})); if (!r.ok) throw new Error(b.detail || 'Could not load this.'); return b; }
const chipClass = v => String(v || '').toLowerCase().replace(/[^a-z]+/g, '-').replace(/-+$/, '');

let INVESTOR = null;

function draw(D){
  const main = $('main'); main.innerHTML = '';
  if (!D.ready){ main.appendChild(el(`<div class="state"><h3>Not yet</h3><p>${esc(D.why || '')}</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`)); return; }
  const m = D.mandate;
  main.appendChild(el(`<section class="headline"><p class="eyebrow">Your portfolio manager · ${esc(D.as_of)}</p><p>${esc(D.headline)}</p>
    <div class="mand">${['equity','debt','gold','cash'].map(k => `<div><b>${num(m.current[k + '_pct']).toFixed(0)}% → ${num(m.target[k + '_pct']).toFixed(0)}%</b><span>${k === 'cash' ? 'liquid' : k}, now → mandate</span></div>`).join('')}</div></section>`));

  // The book of orders.
  const bk = el(`<section class="card"><h2>What to do, in order</h2><p class="lede">${esc(D.letter || '')}</p><div class="book"></div>${D.pace && D.pace.how ? `<p class="note"><b>Pace for new equity money: ${esc(D.pace.how)}.</b> ${esc(D.pace.why || '')}</p>` : ''}</section>`);
  const list = bk.querySelector('.book');
  (D.book || []).forEach(b => list.appendChild(el(`<div class="bk"><h3>${esc(b.what)}</h3><span class="amt">${num(b.amount) ? short(b.amount) : ''}</span><p>${esc(b.why)}</p><small>How: ${esc(b.how)} · When: ${esc(b.when)}${b.basis ? ' · ' + esc(b.basis) : ''}</small></div>`)));
  if (!(D.book || []).length) list.appendChild(el(`<p class="note">Nothing to do. Every holding is earning its place and the mix is on its mandate — the right move is to leave it alone and keep adding.</p>`));
  const act = el(`<div class="bar-row" style="margin-top:12px"><a class="btn" href="/alpha.html">Act on the plan</a><a class="btn ghost" href="/watch.html">What changed today</a></div>`);
  bk.appendChild(act);
  main.appendChild(bk);

  // The reviews, one per asset class.
  (D.classes || []).forEach(k => {
    const c = el(`<section class="card"><h2>${esc(k.name)}${num(k.value) ? ' · ' + short(k.value) : ''}${k.share_pct ? ' · ' + esc(k.share_pct) + '%' : ''}</h2>${(k.notes || []).map(n => `<p class="lede">${esc(n)}</p>`).join('')}<div class="rows"></div></section>`);
    const rows = c.querySelector('.rows');
    (k.holdings || []).forEach(h => rows.appendChild(el(`<div class="hrow"><h3>${esc(h.name)} <span class="chip ${chipClass(h.verdict)}">${esc(h.verdict)}</span></h3><span class="v">${num(h.value) ? short(h.value) : ''}</span><p>${esc(h.why)}</p>${(h.facts || []).length ? `<p class="facts">${esc(h.facts.join(' '))}</p>` : ''}${h.how ? `<p class="how">How: ${esc(h.how)}${h.wait_days ? ' — after ' + h.wait_days + ' days' : ''}</p>` : ''}</div>`)));
    (k.opportunities || []).forEach(o => rows.appendChild(el(`<div class="hrow"><h3><span class="chip upgrade">opportunity</span></h3><span></span><p>${esc(o.say)}</p>${o.how ? `<p class="how">How: ${esc(o.how)}</p>` : ''}</div>`)));
    if (!(k.holdings || []).length && !(k.opportunities || []).length) rows.appendChild(el(`<p class="note">Nothing held here.</p>`));
    main.appendChild(c);
  });
  main.appendChild(el(`<p class="note" style="margin-top:8px">${esc(D.principle)}</p>`));
}

async function load(){
  $('main').innerHTML = '<div class="state"><div class="skeleton" style="height:140px"></div><p class="muted" style="margin-top:12px">Reviewing every holding against its own record and the research — this takes a few seconds.</p></div>';
  try{ draw(await get(`/pm/${INVESTOR}`)); }
  catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not run the review</h3><p>${esc(err.message)}</p></div>`)); }
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Nothing here yet</h3><p>Bring in a statement first.</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`)); return; }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(`<option value="${esc(i.id)}">${esc(i.display_name)}</option>`)));
    picker.style.display = investors.length > 1 ? '' : 'none';
    let wanted = null; try{ wanted = new URLSearchParams(location.search).get('investor') || sessionStorage.getItem('investor'); }catch(err){}
    INVESTOR = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = INVESTOR; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){}
    picker.addEventListener('change', e => { INVESTOR = e.target.value; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){} load(); });
    load();
  }catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`)); }
}
start();
