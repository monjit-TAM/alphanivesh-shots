/* Today: what the daily check found.
 *
 * The engine looks every day after the close and writes down only what
 * crossed a line. This page shows what is open, worst first, when it was
 * last checked, and what cleared this week -- and on most days says that
 * nothing crossed a line, which is the answer rather than the absence of one.
 */
const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);
const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const num = n => Number(n) || 0;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
function short(n){ n = num(n); if (Math.abs(n) >= 1e7) return '₹' + (n/1e7).toFixed(2) + ' cr'; if (Math.abs(n) >= 1e5) return '₹' + (n/1e5).toFixed(1) + ' L'; return '₹' + inr.format(Math.round(n)); }
async function get(path, opts){ const r = await fetch(API + path, Object.assign({credentials: 'include'}, opts || {})); if (r.status === 401){ location.href = '/signin.html?next=/watch.html'; throw new Error('signed out'); } const b = await r.json().catch(() => ({})); if (!r.ok) throw new Error(b.detail || 'Could not load this.'); return b; }
const when = iso => iso ? new Date(iso).toLocaleString('en-IN', {day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'}) : 'not yet';
const SEV = {act: 'Act', note: 'Know', watch: 'Wait'};
const KIND = {drift: 'Drift', ltcg_room: 'Tax', ltcg_soon: 'Tax date', loss_book: 'Tax', verdict: 'Verdict', market: 'Market', goal: 'Goal', idle: 'Idle money', discipline: 'Discipline', glide: 'Glide path', lookthrough: 'Look-through'};

let INVESTOR = null;

function draw(d){
  const main = $('main'); main.innerHTML = '';
  main.appendChild(el(`<section class="headline"><p class="eyebrow">Today · checked ${esc(when(d.checked_at))}</p><p>${esc(d.reading)}</p>
    <div class="plan-head">
      <div class="pf"><p class="eyebrow">To act on</p><b>${d.to_act}</b><small>crossed a line that costs money</small></div>
      <div class="pf"><p class="eyebrow">To know</p><b>${d.to_know}</b><small>worth knowing, no order implied</small></div>
      <div class="pf"><p class="eyebrow">Cleared this week</p><b>${(d.cleared_this_week || []).length}</b><small>stopped being true</small></div>
      <div class="pf"><p class="eyebrow">Check it now</p><b><button type="button" class="btn" id="run" style="font-size:14px;padding:8px 14px">Run</button></b><small>reads every holding; a few seconds</small></div>
    </div></section>`));
  const card = el(`<section class="card"><h2>What crossed a line</h2><p class="lede">${esc(d.principle)}</p><div class="list"></div></section>`);
  const list = card.querySelector('.list');
  if (!d.events.length){
    list.appendChild(el(`<div class="quiet-day">${d.checked_at ? 'Nothing crossed a line. Leave it alone and keep adding.' : 'The first check has not run yet. Press Run, or wait for this evening’s pass.'}</div>`));
  }
  d.events.forEach(e => {
    const act = e.kind === 'verdict' || e.kind === 'drift' ? `<a href="/alpha.html">see the plan</a>` : e.kind === 'ltcg_room' || e.kind === 'loss_book' ? `<a href="/advice.html">see the advice</a>` : e.kind === 'goal' ? `<a href="/goals.html#goal=${esc((e.detail || {}).goal_id || '')}">open the goal</a>` : '';
    list.appendChild(el(`<div class="ev"><span class="sev ${esc(e.severity)}">${SEV[e.severity] || e.severity}</span><div><h3>${esc(e.what)}</h3><p>${esc(e.why)}</p><small>${esc(KIND[e.kind] || e.kind)} · since ${esc(when(e.opened_at))}${e.new ? ' · new' : ''}${act ? ' · ' + act : ''}</small></div><div class="amt">${e.size ? short(e.size) : ''}</div></div>`));
  });
  main.appendChild(card);
  if ((d.cleared_this_week || []).length){
    const c = el(`<section class="card"><h2>Cleared this week</h2><p class="lede">Things that were true and are not any more — because you acted, or because the market moved.</p></section>`);
    d.cleared_this_week.forEach(x => c.appendChild(el(`<div class="barrier"><b>${esc(x.what)}</b><span>cleared ${esc(x.on)}</span></div>`)));
    main.appendChild(c);
  }
  main.appendChild(el(`<section class="card"><h2>The clock</h2><p class="lede">What the engine does, and when. Watching is continuous; acting is rare and explained.</p><div class="clock">
    <div><b>Every hour</b><span>Prices and verdicts re-read. Only a crossing is kept.</span></div>
    <div><b>Every day</b><span>Drift against bands, tax dates, goal odds, the index against its high. This page.</span></div>
    <div><b>Every month</b><span>The alpha ledger: what each move earned, against what it replaced.</span></div>
    <div><b>Every quarter</b><span>The whole plan re-run: target, barriers, moves, the letter.</span></div>
    <div><b>Every year</b><span>Every holding older than seven years re-underwritten. Tax year closed out.</span></div>
  </div></section>`));
  // The discipline meter: what your own hands cost, from the transaction record.
  get(`/discipline/${INVESTOR}`).then(m => {
    const c = el(`<section class="card"><h2>The discipline meter</h2><p class="lede">${esc(m.reading)}</p>
      <div class="plan-head" style="margin-bottom:12px">
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">Churn cost, 12 months</p><b>${short(m.churn.cost)}</b><small style="color:var(--ink-3)">${m.churn.count} sale${m.churn.count === 1 ? '' : 's'} under a year old</small></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">Sales</p><b>${m.sales}</b><small style="color:var(--ink-3)">${m.planned_sales} from the plan · ${m.unplanned_sales} your own</small></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">Months with purchases</p><b>${m.months_with_purchases} / ${m.months}</b><small style="color:var(--ink-3)">the habit, measured</small></div>
        <div class="pf" style="background:var(--paper);color:var(--ink)"><p class="eyebrow" style="color:var(--ink-3)">In the falls</p><b>${m.nerve ? m.nerve.months_invested_through + ' / ' + m.nerve.hard_months : '—'}</b><small style="color:var(--ink-3)">${m.nerve ? 'hard months you kept buying' : 'not tested yet'}</small></div>
      </div><div class="list"></div><p class="note">${esc(m.principle)}</p></section>`);
    const l = c.querySelector('.list');
    (m.churn.rows || []).forEach(r => l.appendChild(el(`<div class="barrier"><b>${esc(r.name)}</b><span>${short(r.cost)} · held ${r.held_days} days</span><p>${esc(r.say)}</p></div>`)));
    main.appendChild(c);
  }).catch(() => {});

  $('run').addEventListener('click', async () => {
    $('run').disabled = true; $('run').textContent = 'Checking…';
    try{ draw(await get(`/watch/${INVESTOR}/run`, {method: 'POST'})); }
    catch(err){ $('run').disabled = false; $('run').textContent = 'Run'; alert(err.message); }
  });
}

async function load(){
  $('main').innerHTML = '<div class="state"><div class="skeleton" style="height:120px"></div></div>';
  try{ draw(await get(`/watch/${INVESTOR}`)); }
  catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`)); }
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Nothing here yet</h3><p>Bring in a statement first.</p><a class="cta" href="/upload.html">Bring in holdings</a></div>`)); return; }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(`<option value="${esc(i.id)}">${esc(i.display_name)}</option>`)));
    picker.style.display = investors.length > 1 ? '' : 'none';
    let wanted = null; try{ wanted = new URLSearchParams(location.search).get('investor') || sessionStorage.getItem('investor'); }catch(err){}
    INVESTOR = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = INVESTOR; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){}
    picker.addEventListener('change', e => { INVESTOR = e.target.value; try{ sessionStorage.setItem('investor', INVESTOR); }catch(err){} load(); });
    load();
  }catch(err){ $('main').innerHTML = ''; $('main').appendChild(el(`<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`)); }
}
start();
