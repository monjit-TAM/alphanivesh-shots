# AlphaWealth API

A read layer over the canonical wealth model.

## Running it

    cd /opt/alphawealth
    ./venv/bin/pip install -r api/requirements.txt
    ./venv/bin/uvicorn api.main:app --host 127.0.0.1 --port 8100

Docs at `/api/docs`, schema at `/api/openapi.json`.

## Configuration

Connection details come from the environment. The password is read from a file
by default so it is not sitting in the process environment:

    ALPHAWEALTH_DB_HOST           default 127.0.0.1
    ALPHAWEALTH_DB_NAME           default alphawealth_db
    ALPHAWEALTH_DB_USER           default alphawealth_user
    ALPHAWEALTH_DB_PASSWORD_FILE  default /root/.alphawealth_db_pw
    ALPHAWEALTH_DSN               overrides all of the above

## Layout

    api/
        main.py              app, CORS, lifespan, health
        db.py                connection pool, fetch helpers
        routers/wealth.py    HTTP surface, no logic
        services/wealth.py   net worth, allocation, XIRR, timeline

Calculations live in `services/` deliberately: the same functions back the API,
report generation and scheduled digests without dragging FastAPI along.

## Endpoints

    GET /api/health
    GET /api/wealth/investors
    GET /api/wealth/{investor_id}/summary      net worth + allocation + returns
    GET /api/wealth/{investor_id}/networth
    GET /api/wealth/{investor_id}/allocation
    GET /api/wealth/{investor_id}/holdings     ?asset_class=mutual_fund
    GET /api/wealth/{investor_id}/returns
    GET /api/wealth/{investor_id}/timeline     ?months=24
    GET /api/wealth/households/{id}/networth

## A note on XIRR

Portfolio returns are computed as XIRR, not CAGR: contributions arrive
irregularly (a lump sum, then a SIP, then a redemption) and a simple
first-to-last growth rate misrepresents what the investor actually earned.
Transaction types we cannot classify as inflow or outflow are excluded from the
calculation and reported in `unclassified_transaction_types` rather than
guessed at. Where the flows cannot produce a rate -- no inflow, no outflow, or
too short a history -- the API returns null instead of a fabricated number.
