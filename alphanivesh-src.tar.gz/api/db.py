"""Database access for the AlphaWealth API.

One connection pool for the process, opened on startup and closed on shutdown.
Everything reads through `fetch_all` / `fetch_one` so that no router has to
think about cursors or row factories.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Iterator, Optional

from psycopg_pool import ConnectionPool
from psycopg.rows import dict_row


def _dsn() -> str:
    """Build the DSN from the environment.

    We read the password from a file rather than an env var where possible:
    on this box it lives in /root/.alphawealth_db_pw with mode 600, which is
    one fewer place for it to leak from than the process environment.
    """
    explicit = os.getenv("ALPHAWEALTH_DSN")
    if explicit:
        return explicit

    password = os.getenv("ALPHAWEALTH_DB_PASSWORD")
    if not password:
        pw_file = os.getenv("ALPHAWEALTH_DB_PASSWORD_FILE", "/root/.alphawealth_db_pw")
        try:
            with open(pw_file) as handle:
                password = handle.read().strip()
        except OSError as exc:
            raise RuntimeError(
                f"no database password: set ALPHAWEALTH_DSN, or "
                f"ALPHAWEALTH_DB_PASSWORD, or make {pw_file} readable"
            ) from exc

    host = os.getenv("ALPHAWEALTH_DB_HOST", "127.0.0.1")
    name = os.getenv("ALPHAWEALTH_DB_NAME", "alphawealth_db")
    user = os.getenv("ALPHAWEALTH_DB_USER", "alphawealth_user")
    return f"host={host} dbname={name} user={user} password={password}"


# The pool is created on first use rather than at import time. Building it
# eagerly would mean that importing anything in this package -- a service, a
# test, a one-off script -- required a database password to be present, which
# makes the code awkward to test and easy to break.
_pool: Optional[ConnectionPool] = None


def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        _pool = ConnectionPool(
            _dsn(), min_size=1, max_size=8, open=False,
            kwargs={"row_factory": dict_row},
        )
    return _pool


@contextmanager
def connection() -> Iterator[Any]:
    with get_pool().connection() as conn:
        yield conn


def fetch_all(sql: str, params: tuple = ()) -> list[dict]:
    with connection() as conn:
        return conn.execute(sql, params).fetchall()


def fetch_one(sql: str, params: tuple = ()) -> Optional[dict]:
    with connection() as conn:
        return conn.execute(sql, params).fetchone()
