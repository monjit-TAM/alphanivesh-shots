"""Verifying, resetting, and signing in with a provider."""

from __future__ import annotations

import os

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from ..services import accounts, auth, mail
from .auth import current_user

router = APIRouter(prefix="/api/account", tags=["Account"])


@router.post("/verify", summary="Follow a verification link")
def verify(payload: dict = Body(...)) -> dict:
    token = (payload or {}).get("token")
    if not token:
        raise HTTPException(status_code=400, detail="No token.")

    user_id = accounts.verify(token)
    if not user_id:
        return {"ok": False,
                "why": ("That link has expired or been used already. Sign in "
                        "and we will send another.")}

    from .. import db
    row = db.fetch_one("SELECT email, full_name FROM users WHERE id = %s",
                       (user_id,))
    if row:
        accounts.send_welcome(user_id, row["email"], row.get("full_name") or "")

    return {"ok": True,
            "reading": "Address confirmed. You can sign in now."}


@router.post("/verify/resend", summary="Send another verification link")
def resend(user: dict = Depends(current_user)) -> dict:
    from .. import db
    row = db.fetch_one(
        "SELECT id, email, full_name, email_verified_at FROM users WHERE id = %s",
        (user.get("id"),))
    if not row:
        raise HTTPException(status_code=404, detail="No such account.")
    if row.get("email_verified_at"):
        return {"ok": True, "reading": "That address is already confirmed."}

    accounts.send_verification(row["id"], row["email"], row.get("full_name") or "")
    return {"ok": True, "reading": "Sent. It should arrive within a minute."}


@router.post("/reset/request", summary="Ask for a password reset link")
def request_reset(payload: dict = Body(...)) -> dict:
    email = (payload or {}).get("email") or ""
    if "@" not in email:
        raise HTTPException(status_code=400, detail="Enter an email address.")
    return accounts.request_reset(email)


@router.post("/reset", summary="Set a new password with a reset token")
def reset(payload: dict = Body(...)) -> dict:
    token = (payload or {}).get("token")
    password = (payload or {}).get("password")
    if not token:
        raise HTTPException(status_code=400, detail="No token.")
    return accounts.reset(token, password or "")


@router.get("/mail/health", summary="Whether mail is configured and arriving")
def mail_health(user: dict = Depends(current_user)) -> dict:
    """Admin only. What has been sent, and what failed.

    A silent mail failure is discovered weeks later by somebody asking why
    they never hear from us, so it is worth being able to look.
    """
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")

    from .. import db
    rows = db.fetch_all(
        """
        SELECT kind,
               count(*) AS tried,
               count(*) FILTER (WHERE sent) AS arrived,
               max(at) AS last_at
        FROM mail_log
        WHERE at > now() - interval '30 days'
        GROUP BY kind ORDER BY 2 DESC
        """)
    failures = db.fetch_all(
        """
        SELECT to_address, kind, detail, at FROM mail_log
        WHERE NOT sent AND at > now() - interval '7 days'
        ORDER BY at DESC LIMIT 20
        """)

    return {
        "configured": mail.configured(),
        "from": mail.FROM_ADDRESS,
        # Whether the lock is on, and what it allows. A guard nobody can see
        # the state of is one somebody will assume is on when it is not.
        "only_to": sorted(mail.ONLY_TO) or None,
        "locked": bool(mail.ONLY_TO),
        "no_repeat_hours": mail.NO_REPEAT_HOURS,
        "by_kind": [dict(r) for r in rows],
        "recent_failures": [dict(r) for r in failures],
        "reading": (
            "SENDGRID_API_KEY is not set, so nothing can be sent."
            if not mail.configured() else
            f"Mail is configured, and locked to {len(mail.ONLY_TO)} "
            f"address{'es' if len(mail.ONLY_TO) != 1 else ''}. Nobody else can "
            f"be written to." if mail.ONLY_TO else
            "Mail is configured and will send to anybody it is addressed to. "
            "Set MAIL_ONLY_TO to lock it to a list while testing."),
    }


# ---------------------------------------------------------------------------
# Signing in with Google
# ---------------------------------------------------------------------------

@router.get("/google/start", summary="Begin a Google sign-in")
def google_start(next: str = "/dash.html"):
    """Send the browser to Google.

    A redirect rather than a JSON URL for the page to follow, because the
    fewer places a half-finished sign-in can be interrupted the better.
    """
    from fastapi.responses import RedirectResponse
    from ..services import google

    if not google.configured():
        raise HTTPException(
            status_code=503,
            detail="Google sign-in is not configured on this server.")

    return RedirectResponse(google.start_url(next), status_code=302)


@router.get("/google/callback", summary="Where Google sends them back")
def google_callback(request: Request, code: str = "", state: str = "",
                    error: str = ""):
    """Finish the sign-in and open a session.

    Every failure lands on the sign-in page with a reason rather than a stack
    trace, because the person here is trying to get into their own account and
    a technical error tells them nothing they can act on.
    """
    from fastapi.responses import RedirectResponse
    from ..services import google

    from urllib.parse import quote

    def back(why: str = ""):
        """Every failure lands on the sign-in page with something to act on."""
        return RedirectResponse(
            "/signin.html" + (f"?trouble={quote(why)}" if why else ""),
            status_code=302)

    if error:
        # The commonest is somebody changing their mind at Google's screen,
        # which is not an error worth alarming them about.
        return back()

    next_page = google.read_state(state)
    if not next_page:
        return back("That sign-in link had expired. Try again.")

    if not code:
        return back("Google sent us back without a code. Try again.")

    details = google.exchange(code)
    if not details or not details.get("subject"):
        return back("Google would not confirm that sign-in. Try again, or use "
                    "a password.")

    found = accounts.from_provider(
        "google", details["subject"], details.get("email"),
        details.get("name"), details.get("email_verified", False))

    if found.get("error"):
        return back(found["error"])

    token = auth.open_session(
        found["user_id"],
        request.headers.get("user-agent"),
        request.client.host if request.client else None)

    # The same helper the password sign-in uses.
    #
    # This set a cookie called "session" while the app reads an_session, so the
    # browser stored it faithfully and nothing ever looked at it -- the sign-in
    # succeeded, the session row was written, and the next request was still
    # anonymous. Two identities and two sessions in the database and a person
    # bounced back to the sign-in page each time.
    #
    # Setting a cookie in two places is how the two drift apart. One place.
    from .auth import _set_session_cookie

    response = RedirectResponse(next_page, status_code=302)
    _set_session_cookie(response, token,
                        secure=request.url.scheme == "https")
    return response


@router.get("/providers", summary="Which sign-in methods this server offers")
def providers() -> dict:
    """So the sign-in page can show the button only when it would work."""
    from ..services import google
    return {"google": google.configured()}
