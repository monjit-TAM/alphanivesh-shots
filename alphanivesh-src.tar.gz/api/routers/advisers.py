"""Who advises whom, and under whose registration."""

from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import advisers, auth, wealth
from .auth import current_user

router = APIRouter(prefix="/api/advisers", tags=["Advisers"])


def _admins_only(user: dict) -> None:
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")


@router.get("", summary="Every adviser")
def everybody(user: dict = Depends(current_user)) -> dict:
    _admins_only(user)
    return {"advisers": advisers.everybody(),
            "unattributed": advisers.unattributed(90)}


@router.post("", summary="Record an adviser")
def add(payload: dict = Body(...), user: dict = Depends(current_user)) -> dict:
    _admins_only(user)

    name = (payload.get("name") or "").strip()
    kind = payload.get("kind") or "ria"
    registration = (payload.get("registration_no") or "").strip() or None

    if not name:
        raise HTTPException(status_code=400, detail="A name is needed.")
    if kind != "platform" and not registration:
        raise HTTPException(
            status_code=400,
            detail=("A registration number is needed for anything but a "
                    "platform entry. An adviser of record without one cannot "
                    "be an adviser of record."))

    from .. import db
    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO adviser (name, kind, registration_no, registered_from,
                                 registered_to, venue, contact, notes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (name, kind, registration,
             payload.get("registered_from"), payload.get("registered_to"),
             payload.get("venue"), payload.get("contact"),
             payload.get("notes")),
        ).fetchone()

    return {"id": row["id"] if row else None, "advisers": advisers.everybody()}


@router.get("/for/{investor_id}", summary="Who advises this investor")
def for_investor(investor_id: str, on: Optional[str] = None,
                 user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    when = date.fromisoformat(on) if on else None
    found = advisers.of_record(investor_id, when)
    return {"adviser": found,
            "may_advise": advisers.may_advise(investor_id)}


@router.put("/for/{investor_id}", summary="Attach an investor to an adviser")
def attach(investor_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    _admins_only(user)
    if wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    adviser_id = payload.get("adviser_id")
    if not adviser_id:
        raise HTTPException(status_code=400, detail="Which adviser?")

    return advisers.attach(
        investor_id, adviser_id,
        agreed_at=payload.get("agreed_at"),
        agreement_ref=payload.get("agreement_ref"))
