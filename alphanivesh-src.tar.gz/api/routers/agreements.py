"""What somebody agrees to, and the record of having agreed.

**The text is not written yet.** The two files under `agreements/` are
placeholders carrying a drafting brief rather than operative terms, and
`AGREEMENTS_LIVE` defaults to off so nothing can be signed against them by
accident. Everything else here is real: the version is recorded, the text is
fingerprinted, and what somebody saw can be produced years later.

An agreement flow that works perfectly against unreviewed terms is worse than
one that does not work, because it produces signatures on a document nobody
checked.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from ..services import auth, referrals, wealth
from .auth import current_user

router = APIRouter(prefix="/api/agreement", tags=["Agreements"])

FOLDER = Path(os.environ.get("AGREEMENT_DIR", "/opt/alphawealth/agreements"))

# Off unless somebody has deliberately turned it on, having replaced the
# placeholder text with something a lawyer has read.
LIVE = os.environ.get("AGREEMENTS_LIVE", "").lower() in ("1", "true", "yes")

VERSIONS = {
    "client_ria": "v1-draft",
    "client_mfd": "v1",
    # A fourth relationship, for orders routed to a broker. Neither the broker
    # nor the platform advises under it, which is what makes it a different
    # document rather than a variation on the adviser one.
    "client_broker": "v1",
    "professional_terms": "v0",
}


def _text(kind: str) -> tuple[str, str]:
    version = VERSIONS.get(kind)
    if not version:
        raise HTTPException(status_code=404, detail="Unknown agreement.")
    path = FOLDER / f"{kind}_{version}.md"
    if not path.exists():
        raise HTTPException(
            status_code=503,
            detail="That agreement has not been written yet.")
    return path.read_text(encoding="utf-8"), version


def _unresolved(body: str) -> list[str]:
    """Square brackets left in the text.

    A drafted agreement often arrives with a choice in it -- which of two fee
    positions, which jurisdiction -- and a signature on a document with square
    brackets in it is a signature on a document nobody finished. Checked at
    the moment of signing rather than trusted to have been noticed.
    """
    import re
    # Square brackets that are instructions to the reader rather than choices
    # left open: the version the system fills in, and the label on the button
    # somebody presses. Flagging those would cry wolf on two finished
    # documents and teach whoever sees it to ignore the warning on the one
    # that is genuinely unfinished.
    NOT_A_CHOICE = ("SYSTEM GENERATED", "ELECTRONICALLY SIGN",
                    "I AGREE", "DATE/TIME")
    return [g for g in re.findall(r"\[[^\]]{6,}\]", body)
            if not any(w in g.upper() for w in NOT_A_CHOICE)]


@router.get("/needed/{investor_id}", summary="What this investor must agree to")
def needed(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return referrals.what_is_needed(investor_id)


@router.get("/{kind}", summary="The text of an agreement")
def text(kind: str, user: dict = Depends(current_user)) -> dict:
    body, version = _text(kind)
    return {
        "kind": kind,
        "version": version,
        "body": body,
        "live": LIVE and not _unresolved(body),
        "unresolved": _unresolved(body),
        # Said out loud rather than left for somebody to discover.
        "warning": (
            f"This text still has {len(_unresolved(body))} choice(s) left "
            f"open in it and cannot be signed. It is here so the flow around "
            f"it can be walked." if _unresolved(body) else
            None if LIVE else
            "AGREEMENTS_LIVE is not set on this server, so nothing can be "
            "signed against this text yet."),
    }


@router.post("/{kind}", summary="Agree to one")
def agree(kind: str, request: Request, payload: dict = Body(default={}),
          user: dict = Depends(current_user)) -> dict:
    body, version = _text(kind)

    if not LIVE:
        raise HTTPException(
            status_code=503,
            detail=("AGREEMENTS_LIVE is not set on this server, so nothing "
                    "can be signed yet."))

    # Even with the switch on, an unfinished document cannot be signed.
    open_choices = _unresolved(body)
    if open_choices:
        raise HTTPException(
            status_code=503,
            detail=(f"This agreement still has {len(open_choices)} choice"
                    f"{'s' if len(open_choices) != 1 else ''} unresolved in "
                    f"the text: {'; '.join(c[:60] for c in open_choices)}. "
                    f"Nothing can be signed against a document nobody "
                    f"finished."))

    investor_id = payload.get("investor_id")
    if investor_id and not auth.may_see(user, investor_id):
        raise HTTPException(status_code=404, detail="No such investor.")

    if not payload.get("agreed"):
        raise HTTPException(status_code=400,
                            detail="The box has to be ticked.")

    return referrals.record_agreement(
        kind, version, body,
        user_id=(user or {}).get("id"),
        investor_id=investor_id,
        professional_id=payload.get("professional_id"),
        ip=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        esign_name=payload.get("signed_name"))
