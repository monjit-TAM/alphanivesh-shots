"""What somebody agrees to, and the record of having agreed.

**The text is not written yet.** The two files under `agreements/` are
placeholders carrying a drafting brief rather than operative terms, and
`AGREEMENTS_LIVE` defaults to off so nothing can be signed against them by
accident. Everything else here is real: the version is recorded, the text is
fingerprinted, and what somebody saw can be produced years later.

An agreement flow that works perfectly against unreviewed terms is worse than
one that does not work, because it produces signatures on a document nobody
checked.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from ..services import auth, referrals, wealth
from .auth import current_user

router = APIRouter(prefix="/api/agreement", tags=["Agreements"])

FOLDER = Path(os.environ.get("AGREEMENT_DIR", "/opt/alphawealth/agreements"))

# Off unless somebody has deliberately turned it on, having replaced the
# placeholder text with something a lawyer has read.
LIVE = os.environ.get("AGREEMENTS_LIVE", "").lower() in ("1", "true", "yes")

VERSIONS = {
    "client_ria": "v0",
    "client_mfd": "v0",
    "professional_terms": "v0",
}


def _text(kind: str) -> tuple[str, str]:
    version = VERSIONS.get(kind)
    if not version:
        raise HTTPException(status_code=404, detail="Unknown agreement.")
    path = FOLDER / f"{kind}_{version}.md"
    if not path.exists():
        raise HTTPException(
            status_code=503,
            detail="That agreement has not been written yet.")
    return path.read_text(encoding="utf-8"), version


@router.get("/needed/{investor_id}", summary="What this investor must agree to")
def needed(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return referrals.what_is_needed(investor_id)


@router.get("/{kind}", summary="The text of an agreement")
def text(kind: str, user: dict = Depends(current_user)) -> dict:
    body, version = _text(kind)
    return {
        "kind": kind,
        "version": version,
        "body": body,
        "live": LIVE,
        # Said out loud rather than left for somebody to discover.
        "warning": (None if LIVE else
                    "This text has not been through legal review and cannot be "
                    "agreed to. It is here so the flow around it can be built."),
    }


@router.post("/{kind}", summary="Agree to one")
def agree(kind: str, request: Request, payload: dict = Body(default={}),
          user: dict = Depends(current_user)) -> dict:
    if not LIVE:
        raise HTTPException(
            status_code=503,
            detail=("The agreements have not been through legal review, so "
                    "nothing can be signed against them yet. This is "
                    "deliberate: a signature on an unreviewed document is "
                    "worse than no signature."))

    body, version = _text(kind)

    investor_id = payload.get("investor_id")
    if investor_id and not auth.may_see(user, investor_id):
        raise HTTPException(status_code=404, detail="No such investor.")

    if not payload.get("agreed"):
        raise HTTPException(status_code=400,
                            detail="The box has to be ticked.")

    return referrals.record_agreement(
        kind, version, body,
        user_id=(user or {}).get("id"),
        investor_id=investor_id,
        professional_id=payload.get("professional_id"),
        ip=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        esign_name=payload.get("signed_name"))
