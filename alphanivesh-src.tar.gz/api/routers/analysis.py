"""Deeper analysis of what someone holds."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import analysis, auth, wealth
from .auth import current_user

router = APIRouter(prefix="/api/analysis", tags=["Analysis"])


def _permitted(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}/funds", summary="How each fund has done, and where it ranks")
def funds(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return analysis.fund_quality(investor_id)


@router.get("/{investor_id}/equities", summary="Valuation and quality of directly held shares")
def equities(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return analysis.equity_fundamentals(investor_id)


@router.get("/{investor_id}/sectors", summary="Which industries the money is in")
def sectors(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return analysis.sector_exposure(investor_id)


@router.get("/{investor_id}/concentration", summary="How spread out the holdings are")
def concentration(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return analysis.concentration(investor_id)


@router.get("/{investor_id}", summary="Everything, in one call")
def everything(investor_id: str, user: dict = Depends(current_user)) -> dict:
    """What the analysis page loads.

    One request rather than four, because the page needs all of it and four
    round trips on a slow connection is a worse experience than one larger
    response.
    """
    _permitted(user, investor_id)
    return {
        "funds": analysis.fund_quality(investor_id),
        "equities": analysis.equity_fundamentals(investor_id),
        "sectors": analysis.sector_exposure(investor_id),
        "concentration": analysis.concentration(investor_id),
    }
