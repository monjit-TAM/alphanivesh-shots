"""Ariv: answering questions about a portfolio.

Every exchange is routed before it is answered. Most questions have a
computation behind them and never reach a model — which costs nothing, cannot
drift, and returns in milliseconds. What is left goes to a model with a
grounding context, and refusals are the platform's own rather than a prompt's.

And every exchange is recorded, answered or refused, with what it rested on.
Under the licence this runs through we answer for what we say, and an assistant
that speaks without a record is the one part of the platform that could not be
defended two years later.
"""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import (ariv_answers, ariv_router, auth, budget, ledger,
                        wealth)
from .auth import current_user

log = logging.getLogger("alphanivesh.ariv")

router = APIRouter(prefix="/api/ariv", tags=["Ariv"])

# A session is a conversation. Long ones wander, so there is a ceiling, and
# reaching it offers a fresh start rather than cutting somebody off.
MAX_TURNS = 20


@router.post("/{investor_id}", summary="Ask about this portfolio")
def ask(investor_id: str, payload: dict = Body(...),
        user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    question = (payload.get("question") or "").strip()
    session = payload.get("session_id") or str(uuid.uuid4())
    turn = int(payload.get("turn") or 1)

    if not question:
        raise HTTPException(status_code=400, detail="Ask something.")

    started = time.time()
    route, key, message = ariv_router.classify(question)

    # A question that has wandered off the portfolio entirely. Not a refusal
    # of the kind the engine makes -- just not what this is for.
    if route != ariv_router.Route.REFUSE and not ariv_router.is_about_portfolio(question):
        route, key = ariv_router.Route.REFUSE, "off_topic"
        message = ("I only know about this portfolio — what is in it, what it "
                   "has done, and what the platform suggests doing about it. "
                   "Anything else is outside what I can see.")

    answer, basis = None, {}

    if route == ariv_router.Route.REFUSE:
        answer = message

    elif route == ariv_router.Route.LOOKUP:
        result = ariv_answers.answer(key, investor_id)
        if result:
            answer, basis = result["answer"], result.get("basis") or {}
        else:
            # The computation failed rather than the question being wrong.
            # Saying so is better than a generic apology.
            route = ariv_router.Route.REFUSE
            key = "computation_failed"
            answer = ("I could not work that out just now. The figures behind "
                      "it are on the dashboard if you need them immediately.")

    else:
        # The budget is checked before the model is called rather than after,
        # so an investor who has run out is told rather than billed.
        allowed, refusal = budget.may_generate(investor_id)

        if not allowed:
            route, key, answer = ariv_router.Route.REFUSE, "budget_spent", refusal
        else:
            # Generated answers need a model, and the account has no credit
            # yet. Saying which is better than a vague failure: one of those
            # is a bug and the other is a bill.
            route = ariv_router.Route.REFUSE
            key = "needs_generation"
            answer = ("That one needs me to reason rather than look something "
                      "up, and the language model behind it is not connected "
                      "yet. Questions about what things are worth, what the "
                      "tax would be, what to do first, or how your funds "
                      "compare I can answer now.")

    elapsed = int((time.time() - started) * 1000)
    refused = route == ariv_router.Route.REFUSE

    record_id = ledger.record(
        investor_id,
        "ariv_refusal" if refused else "ariv_answer",
        said={"question": question, "answer": answer},
        basis={"route": route, "key": key, "grounding": basis},
        surface="ariv",
        session_id=session,
    )

    # Every exchange metered, including the free ones. The ratio between
    # computed and generated is the thing worth watching: if it moves, either
    # the router has stopped catching common questions or people are asking
    # harder ones, and both are worth knowing before a bill arrives.
    budget.record(investor_id, route, ledger_id=record_id)
    usage = budget.spent(investor_id)

    return {
        "answer": answer,
        "route": route,
        "budget": {
            "used_rupees": usage["month_rupees"],
            "of_rupees": usage["budget_rupees"],
            "generated_this_month": usage["generated"],
        },
        "refused": refused,
        "session_id": session,
        "turn": turn,
        "ms": elapsed,
        "recorded": bool(record_id),
        "ending_soon": turn >= MAX_TURNS - 3,
        "at_limit": turn >= MAX_TURNS,
    }


@router.get("/{investor_id}/suggestions", summary="What to ask")
def suggestions(investor_id: str,
                user: dict = Depends(current_user)) -> dict:
    """Questions worth asking, so nobody faces an empty box.

    Drawn from what this platform can answer without a model, so every
    suggestion works today. An assistant that opens with a blank prompt gets
    asked nothing, or gets asked the one thing it cannot do.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    return {"suggestions": [
        "What should I do first?",
        "How much tax if I sell everything?",
        "What is my largest holding?",
        "How much am I paying in commission?",
        "Am I beating the index?",
        "What sectors am I exposed to?",
    ]}
