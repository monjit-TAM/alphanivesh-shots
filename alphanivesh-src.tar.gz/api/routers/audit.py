"""Reading the advice ledger back.

Admin only. The questions an audit asks are "what was this person told", "what
were they being told on this date", and "give us everything for this range" --
and each needs the basis alongside the words, because the answer to why we said
something is in its inputs.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

import csv
import io
import json

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

from ..services import budget, ledger
from .auth import current_user

router = APIRouter(prefix="/api/audit", tags=["Audit"])


def _admin(user: dict) -> None:
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")


@router.get("/coverage", summary="Whether the ledger is being written to")
def coverage(user: dict = Depends(current_user)) -> dict:
    _admin(user)
    return ledger.coverage()


@router.get("/{investor_id}", summary="What this investor has been told")
def history(investor_id: str, kind: Optional[str] = None,
            limit: int = Query(default=100, le=1000),
            user: dict = Depends(current_user)) -> dict:
    _admin(user)
    return {"investor_id": investor_id,
            "records": ledger.history(investor_id, kind, limit)}


@router.get("/{investor_id}/on/{when}", summary="What they were told on a date")
def as_at(investor_id: str, when: date,
          user: dict = Depends(current_user)) -> dict:
    _admin(user)
    return {"investor_id": investor_id, "date": when.isoformat(),
            "records": ledger.as_at(investor_id, when)}


@router.get("/export/csv", summary="The ledger as a spreadsheet")
def export_csv(investor_id: Optional[str] = None,
               since: Optional[date] = None,
               until: Optional[date] = None,
               user: dict = Depends(current_user)) -> StreamingResponse:
    """A slice of the ledger, flat.

    A regulator asks for a person and a range rather than a database, so both
    filters are optional and combine. CSV because it opens anywhere, and the
    two JSON columns are kept whole in their cells rather than flattened --
    losing the basis to make a tidier spreadsheet would defeat the point.
    """
    _admin(user)
    rows = ledger.export(investor_id, since, until)

    buffer = io.StringIO()
    columns = ["id", "investor_id", "shown_at", "data_as_of", "kind",
               "engine_version", "model", "surface", "caller",
               "corrects", "outcome", "said", "basis"]
    writer = csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()

    for row in rows:
        flat = dict(row)
        for column in ("said", "basis"):
            value = flat.get(column)
            if isinstance(value, (dict, list)):
                flat[column] = json.dumps(value, ensure_ascii=False)
        for column in ("shown_at", "data_as_of"):
            if flat.get(column) is not None:
                flat[column] = flat[column].isoformat()
        writer.writerow(flat)

    buffer.seek(0)
    name = f"advice-ledger-{date.today().isoformat()}.csv"
    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


@router.get("/export/json", summary="The ledger, complete")
def export_json(investor_id: Optional[str] = None,
                since: Optional[date] = None,
                until: Optional[date] = None,
                user: dict = Depends(current_user)) -> StreamingResponse:
    """The same slice, with the structure intact.

    CSV is what somebody opens; this is what somebody verifies against. The
    basis is nested and stays nested.
    """
    _admin(user)
    rows = ledger.export(investor_id, since, until)

    def plain(value):
        if isinstance(value, (date,)):
            return value.isoformat()
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return value

    payload = {
        "exported_at": date.today().isoformat(),
        "filters": {"investor_id": investor_id,
                    "since": since.isoformat() if since else None,
                    "until": until.isoformat() if until else None},
        "records": len(rows),
        "ledger": [{k: plain(v) for k, v in dict(r).items()} for r in rows],
    }
    name = f"advice-ledger-{date.today().isoformat()}.json"
    return StreamingResponse(
        iter([json.dumps(payload, ensure_ascii=False, indent=1, default=str)]),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


@router.get("", summary="Everything, most recent first")
def everything(kind: Optional[str] = None,
               investor_id: Optional[str] = None,
               limit: int = Query(default=200, le=2000),
               user: dict = Depends(current_user)) -> dict:
    """The whole ledger across investors, for the audit page."""
    _admin(user)
    rows = ledger.export(investor_id)
    if kind:
        rows = [r for r in rows if r["kind"] == kind]
    rows = sorted(rows, key=lambda r: r["shown_at"], reverse=True)[:limit]
    return {"records": rows, "coverage": ledger.coverage()}


@router.get("/ariv/cost", summary="What Ariv is costing")
def ariv_cost(days: int = 30, user: dict = Depends(current_user)) -> dict:
    """Across everybody, for whoever is watching the bill."""
    _admin(user)
    return budget.across_everybody(days)
