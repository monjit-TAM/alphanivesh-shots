"""Sign up, sign in, sign out, and the dependency every protected route uses."""

from __future__ import annotations

import logging

from typing import Optional

from fastapi import APIRouter, Cookie, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

from ..services import auth

log = logging.getLogger("alphanivesh.auth.routes")

router = APIRouter(prefix="/api/auth", tags=["Account"])


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def current_user(an_session: Optional[str] = Cookie(default=None)) -> dict:
    """The signed-in user, or a 401.

    Every route that reads someone's financial position depends on this.
    """
    user = auth.resolve_session(an_session)
    if user is None:
        raise HTTPException(status_code=401, detail="Sign in to continue.")
    return user


def require_advisor(user: dict = Depends(current_user)) -> dict:
    if user["role"] not in ("advisor", "admin"):
        raise HTTPException(status_code=403, detail="This is for adviser accounts.")
    return user


# ---------------------------------------------------------------------------
# Payloads
# ---------------------------------------------------------------------------


class RegisterIn(BaseModel):
    email: str
    # Deliberately no min_length here. Pydantic would reject it with "String
    # should have at least 10 characters", which is not something to show a
    # person. The rule lives in auth.register, where it can explain itself.
    password: str
    full_name: str
    role: str = "investor"
    firm_name: Optional[str] = None
    sebi_reg_number: Optional[str] = None
    # The code that brought them, if any. Carried from the landing page
    # through to here so a referred investor is recorded as referred at the
    # moment the account is made rather than attached to somebody afterwards.
    ref: Optional[str] = None


class LoginIn(BaseModel):
    email: str
    password: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


def _set_session_cookie(response: Response, token: str, secure: bool) -> None:
    response.set_cookie(
        auth.SESSION_COOKIE,
        token,
        max_age=int(auth.SESSION_TTL.total_seconds()),
        httponly=True,          # not readable from JavaScript
        secure=secure,          # only sent over TLS in production
        samesite="lax",         # survives normal navigation, not cross-site posts
        path="/",
    )


@router.post("/register", summary="Create an account")
def register(body: RegisterIn, request: Request, response: Response) -> dict:
    try:
        user = auth.register(
            email=body.email, password=body.password, full_name=body.full_name,
            role=body.role, firm_name=body.firm_name,
            sebi_reg_number=body.sebi_reg_number,
        )
    except auth.AuthError as err:
        raise HTTPException(status_code=400, detail=str(err))

    # Where they came from, and what follows from it.
    #
    # A referral code makes this a different account: there is a professional
    # behind it, an agreement to sign, and a book they belong to. A direct
    # signup has none of those, and asking somebody to agree terms with nobody
    # would be theatre.
    came_from = None
    if body.ref:
        from ..services import referrals
        came_from = referrals.whose(body.ref)
        if not came_from:
            # Not fatal. A stale code should not stop somebody signing up --
            # it should make them a direct investor, which is what they are.
            log.info("signup with an unusable referral code")

    token = auth.open_session(
        user["id"], request.headers.get("user-agent"),
        request.client.host if request.client else None,
    )
    _set_session_cookie(response, token, secure=request.url.scheme == "https")

    return {
        "user": {k: user[k] for k in ("id", "email", "full_name", "role")},
        # What the page should do next, decided here rather than in the
        # browser: an adviser goes to their registration, a referred investor
        # to the agreement, everybody else to their portfolio.
        "next": _where_next(user, came_from),
        "referred_by": (came_from or {}).get("firm_name"),
        "must_agree": (came_from or {}).get("agreement_kind"),
    }


def _where_next(user: dict, came_from: Optional[dict]) -> str:
    """Where somebody lands after signing up.

    An adviser or distributor has a registration to record before anything
    works, so sending them to an investor dashboard would show them a page
    that is not for them and hide the one that is.
    """
    if user.get("role") in ("advisor", "distributor"):
        return "/register-pro.html"
    if came_from:
        return "/agree.html"
    return "/upload.html"


@router.post("/login", summary="Sign in")
def login(body: LoginIn, request: Request, response: Response) -> dict:
    try:
        user = auth.authenticate(body.email, body.password)
    except auth.AuthError as err:
        raise HTTPException(status_code=401, detail=str(err))

    token = auth.open_session(
        user["id"], request.headers.get("user-agent"),
        request.client.host if request.client else None,
    )
    _set_session_cookie(response, token, secure=request.url.scheme == "https")
    return {"user": user}


@router.post("/logout", summary="Sign out")
def logout(response: Response, an_session: Optional[str] = Cookie(default=None)) -> dict:
    auth.close_session(an_session)
    response.delete_cookie(auth.SESSION_COOKIE, path="/")
    return {"signed_out": True}


@router.get("/me", summary="Who is signed in")
def me(user: dict = Depends(current_user)) -> dict:
    scope = auth.visible_investor_ids(user)
    return {
        "user": user,
        "investor_count": None if scope is None else len(scope),
    }
