"""What changed while somebody was away."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, away as away_service, wealth
from .auth import current_user

router = APIRouter(prefix="/api/away", tags=["Away"])


@router.get("/{investor_id}", summary="What changed since the last visit")
def since_last_visit(investor_id: str,
                     user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    # None where there is nothing to say -- a first visit, or somebody who was
    # here an hour ago. The page shows nothing rather than an empty panel.
    result = away_service.since_last_visit(investor_id)
    return result or {"nothing_to_report": True}
