"""How often somebody wants to hear from us."""

from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import auth, cadence, wealth
from .auth import current_user

router = APIRouter(prefix="/api/cadence", tags=["Cadence"])


def _may(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="What they asked for")
def preference(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return cadence.preference(investor_id)


@router.put("/{investor_id}", summary="Set it")
def set_preference(investor_id: str, payload: dict = Body(...),
                   user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    try:
        return cadence.set_preference(
            investor_id,
            payload.get("cadence") or cadence.DEFAULT,
            urgent_anyway=payload.get("urgent_anyway", True),
            by_email=payload.get("by_email", True),
            by_whatsapp=payload.get("by_whatsapp", False),
            by_push=payload.get("by_push", False),
            paused_until=(date.fromisoformat(payload["paused_until"])
                          if payload.get("paused_until") else None))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.get("/{investor_id}/due", summary="Is a review owed, and is it worth one")
def due(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return cadence.due(investor_id)


@router.get("", summary="Everybody owed a review today")
def everybody(user: dict = Depends(current_user)) -> dict:
    """Admin only. What a scheduled job would act on."""
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")
    reviews = cadence.everybody_due()
    return {"count": len(reviews), "reviews": reviews}
