"""What the investor agreed to, order by order."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from ..services import auth, consent, wealth
from .auth import current_user

router = APIRouter(prefix="/api/consent", tags=["Consent"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/may/{investor_id}", summary="Whether anything can be placed")
def may(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return consent.may_transact(investor_id)


@router.post("/ask/{investor_id}", summary="Build the screen, record nothing")
def ask(investor_id: str, payload: dict = Body(...),
        user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return consent.ask(investor_id, payload.get("orders") or [],
                       ledger_id=payload.get("ledger_id"))


@router.post("/{investor_id}", summary="Agree to these orders")
def give(investor_id: str, request: Request, payload: dict = Body(...),
         user: dict = Depends(current_user)) -> dict:
    """Only the investor agrees.

    An adviser consenting on their client's behalf is the thing this whole
    layer exists to prevent -- it is what makes an advisory relationship into
    portfolio management, which is a different registration.
    """
    _theirs(user, investor_id)

    owner = wealth.get_investor(investor_id) or {}
    if owner.get("owner_user_id") != (user or {}).get("id"):
        raise HTTPException(
            status_code=403,
            detail=("Only the investor can agree to their own orders. An "
                    "adviser agreeing on a client's behalf is portfolio "
                    "management, which is a different registration."))

    if not payload.get("agreed"):
        raise HTTPException(status_code=400,
                            detail="Nothing was agreed to.")

    try:
        return consent.give(
            investor_id, payload.get("orders") or [],
            ledger_id=payload.get("ledger_id"),
            ip=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"))
    except PermissionError as err:
        raise HTTPException(status_code=409, detail=str(err))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.get("/{investor_id}", summary="What is agreed and unused")
def open_for(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    return {"open": consent.open_for(investor_id)}


@router.delete("/{investor_id}/{consent_id}", summary="Change your mind")
def withdraw(investor_id: str, consent_id: str,
             user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    if not consent.withdraw(investor_id, consent_id):
        raise HTTPException(
            status_code=409,
            detail="That has already been used or withdrawn.")
    return {"withdrawn": consent_id}
