"""Everything the dashboard draws, in one response.

Two things shape this.

The reader wants the headline first -- what went in, what it is worth, what
that gain is a year -- and then the depth. So the response leads with those and
carries the rest behind them.

And they want it for the whole portfolio and for each part. Someone holding
shares and funds is really holding two portfolios: up 40% on one and flat on
the other reads as up 15% overall, which is true and tells them nothing. So
every figure here is computed once for everything and again per asset class.

One call rather than a dozen. The page needs all of it to draw anything, and
twelve round trips on a slow connection is twelve chances to see half a screen.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from .. import db
from ..services import var, debts, analysis, auth, findings, wealth, projections, shocks, peers, xirr, forward, protection
from .auth import current_user

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])

# Asset classes worth a view of their own. A single fixed deposit does not
# need its own tab; a portfolio of shares does.
MIN_POSITIONS_FOR_OWN_VIEW = 1
MIN_VALUE_FOR_OWN_VIEW = Decimal("1000")


def _d(value) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _headline(investor_id: str, asset_class: Optional[str] = None) -> dict:
    """What went in, what it is worth, and what that is a year.

    CAGR rather than the absolute return wherever we can date the money. A
    portfolio up 224% sounds spectacular until you learn it took eleven years,
    which is 11% a year -- the same number, and the one that can be compared
    against anything else.
    """
    summary = wealth.net_worth(investor_id, asset_class=asset_class)
    invested = _d(summary["invested_value"])
    current = _d(summary["total_value"])

    # The earliest purchase we can date, which sets the holding period.
    where = "WHERE h.investor_id = %s"
    params: tuple = (investor_id,)
    if asset_class:
        where += " AND i.asset_class = %s"
        params += (asset_class,)

    row = db.fetch_one(
        f"""
        SELECT min(h.as_of) AS since
        FROM holding_snapshots h
        JOIN instruments i ON i.id = h.instrument_id
        {where} AND h.as_of > '1990-01-01'
        """,
        params,
    )
    since = row["since"] if row else None

    years = None
    cagr = None
    cagr_withheld = None

    if since and invested > 0 and current > 0:
        days = (date.today() - since).days
        years = Decimal(days) / Decimal("365.25")

        # Annualising a short period is where a real gain turns into a
        # ridiculous claim. Eleven months of 166% becomes "205% a year", which
        # asserts it will keep compounding at that rate.
        #
        # And the period itself is often wrong in the same direction. What we
        # measure from is the first snapshot we hold, not the first purchase --
        # somebody who imported a statement last October has fund units bought
        # years earlier, and their gain accrued over all of it. Annualising
        # over the shorter window inflates the rate by however much history is
        # missing.
        if days < 730:
            cagr_withheld = (
                "We have held this position on record for "
                f"{'under a year' if days < 365 else 'about a year'}, which is "
                "too short a window to state a yearly rate from. The gain "
                "itself may have accrued over much longer."
            )
        else:
            try:
                costed_for_rate = _d(summary.get("gain_covers_value")) or current
                cagr = ((costed_for_rate / invested) ** (Decimal(1) / years) - 1) * 100
            except (ArithmeticError, ValueError):
                cagr = None

        # Even over a long window, a rate this high says the record is
        # incomplete rather than that somebody found a way to compound at 80%.
        if cagr is not None and cagr > 80:
            cagr_withheld = (
                "The yearly rate this works out to is implausibly high, which "
                "usually means we hold less of the buying history than the gain "
                "actually spans."
            )
            cagr = None

    # The gain, over the part where both figures are known.
    #
    # This computed the whole portfolio's value minus only the contributions we
    # can trace, so a provident fund and a gold holding entered without a cost
    # produced seventy-one lakh of gain and a 235% return. net_worth was fixed
    # for this and the headline was not, which is how the same wrong number
    # survived in a second place.
    costed = _d(summary.get("gain_covers_value")) or current
    gain = costed - invested

    return {
        "asset_class": asset_class,
        "positions": summary["positions"],
        "invested": str(invested),
        "current": str(current),
        "gain": str(gain),
        # Quantized. Unrounded this rendered as
        # "235.2186127022127855958545387% on that".
        "return_pct": (str((gain / invested * 100).quantize(Decimal("0.1")))
                       if invested else None),
        "gain_covers_pct": summary.get("gain_covers_pct"),
        "without_cost": summary.get("without_cost"),
        "cagr_pct": str(cagr.quantize(Decimal("0.01"))) if cagr is not None else None,
        "cagr_withheld": cagr_withheld,
        "held_since": since.isoformat() if since else None,
        "held_years": str(years.quantize(Decimal("0.1"))) if years else None,
        "as_of": summary["as_of"].isoformat() if summary.get("as_of") else None,
        "priced_today": summary.get("priced_as_of") is not None,
    }


def _movers(investor_id: str, asset_class: Optional[str] = None,
            count: int = 3) -> dict:
    """What has done best and worst.

    By percentage rather than by rupees, because the question is which choices
    worked -- a small position that tripled says more about judgement than a
    large one that drifted up.
    """
    where = "WHERE v.investor_id = %s AND v.invested_value > 0"
    params: tuple = (investor_id,)
    if asset_class:
        where += " AND v.asset_class = %s"
        params += (asset_class,)

    rows = db.fetch_all(
        f"""
        SELECT v.instrument_name, v.symbol, v.current_value, v.invested_value,
               (v.current_value - v.invested_value) AS gain,
               ((v.current_value / v.invested_value) - 1) * 100 AS gain_pct
        FROM v_current_holdings v
        {where}
        ORDER BY gain_pct DESC
        """,
        params,
    )
    if not rows:
        return {"best": [], "worst": []}

    def shape(row: dict) -> dict:
        return {
            "name": row["instrument_name"],
            "symbol": row["symbol"],
            "value": str(row["current_value"]),
            "gain": str(row["gain"]),
            "gain_pct": str(_d(row["gain_pct"]).quantize(Decimal("0.1"))),
        }

    losers = [r for r in rows if _d(r["gain_pct"]) < 0]
    return {
        "best": [shape(r) for r in rows[:count]],
        "worst": [shape(r) for r in reversed(losers[-count:])] if losers else [],
    }


def _value_shape(investor_id: str) -> Optional[dict]:
    """What the directly held shares cost, earn and owe, against their sectors.

    Weighted by position size, because a token holding on a wild multiple
    should not describe the whole book.
    """
    equity = analysis.equity_fundamentals(investor_id)
    if not equity["covered"]:
        return None

    weighted = equity["weighted"]

    # The same measures across every company we hold ratios for, so each figure
    # has a market to sit against rather than floating alone.
    # The largest hundred companies, weighted by size -- which is what "the
    # market" means when somebody compares their portfolio to it. A median
    # across all 2,329 is dominated by small companies nobody holds and made a
    # perfectly ordinary large-cap book look five times more expensive than
    # the market.
    market = db.fetch_one(
        """
        WITH ranked AS (
            SELECT symbol, pe_ttm, pb_ratio, roe, debt_to_equity, revenue_growth_yoy,
                   CASE WHEN market_cap > 3000000 THEN market_cap / 10000000
                        ELSE market_cap END AS cap_cr
            FROM company_fundamentals
            WHERE market_cap IS NOT NULL AND market_cap > 0
        ),
        top_hundred AS (
            SELECT * FROM ranked ORDER BY cap_cr DESC LIMIT 100
        )
        SELECT sum(pe_ttm * cap_cr) / nullif(sum(cap_cr) FILTER (WHERE pe_ttm IS NOT NULL), 0) AS pe,
               sum(pb_ratio * cap_cr) / nullif(sum(cap_cr) FILTER (WHERE pb_ratio IS NOT NULL), 0) AS pb,
               sum(roe * cap_cr) / nullif(sum(cap_cr) FILTER (WHERE roe IS NOT NULL), 0) AS roe,
               sum(debt_to_equity * cap_cr) / nullif(sum(cap_cr) FILTER (WHERE debt_to_equity IS NOT NULL), 0) AS debt_to_equity,
               sum(revenue_growth_yoy * cap_cr) / nullif(sum(cap_cr) FILTER (WHERE revenue_growth_yoy IS NOT NULL), 0) AS revenue_growth,
               count(*) AS companies
        FROM top_hundred
        """
    )

    def pair(key: str, market_key: str) -> Optional[dict]:
        mine = weighted.get(key)
        if mine is None:
            return None
        theirs = market.get(market_key) if market else None
        return {
            "yours": str(_d(mine).quantize(Decimal("0.01"))),
            "market": str(_d(theirs).quantize(Decimal("0.01"))) if theirs else None,
        }

    return {
        "covered": equity["covered"],
        "of": equity["total"],
        "market_from": market["companies"] if market else None,
        "market_is": "the hundred largest companies, weighted by size",
        "pe": pair("pe", "pe"),
        "pb": pair("pb", "pb"),
        "roe": pair("roe", "roe"),
        "debt_to_equity": pair("debt_to_equity", "debt_to_equity"),
        "revenue_growth": pair("revenue_growth", "revenue_growth"),
        "dividend_yield": pair("dividend_yield", None) if weighted.get("dividend_yield") else None,
        "beta": str(_d(weighted["beta"]).quantize(Decimal("0.01"))) if weighted.get("beta") else None,
    }



# India taxes a gain differently depending on how long the thing was held, and
# the boundary is not the same for every asset. Equity and equity funds turn
# long-term after a year; debt funds, gold and property take two or three.
# Getting this wrong by a month is the difference between 20% and 12.5%.
LONG_TERM_MONTHS = {
    "equity": 12,
    "mutual_fund": 12,        # equity-oriented; debt schemes differ and are noted
    "etf": 12,
    "bond": 36,
    "gsec": 36,
    "gold": 36,
    "real_estate": 24,
}
DEFAULT_LONG_TERM_MONTHS = 36

# The exemption on long-term equity gains, and the rates either side of the line.
LTCG_EXEMPT = Decimal("125000")
LTCG_RATE = Decimal("12.5")
STCG_RATE = Decimal("20")


def _tax_shape(investor_id: str) -> Optional[dict]:
    """What the unrealised gains would cost if they were taken today.

    Not advice to take them -- the point is that a gain on paper and a gain in
    the bank are different numbers, and most people never see the difference
    until they sell. A position sitting a few weeks short of its long-term date
    is worth knowing about before rather than after.

    Only positions we can date. Where a holding's purchase date is unknown the
    period cannot be worked out, and guessing would put somebody on the wrong
    side of a rate.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_name, v.asset_class, v.current_value, v.invested_value,
               (SELECT min(h.as_of) FROM holding_snapshots h
                WHERE h.instrument_id = v.instrument_id
                  AND h.investor_id = v.investor_id
                  AND h.as_of > '1990-01-01') AS bought
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0 AND v.invested_value > 0
        """,
        (investor_id,),
    )
    if not rows:
        return None

    today = date.today()
    short_gain = Decimal(0)
    long_gain = Decimal(0)
    undated = Decimal(0)
    nearly: list[dict] = []

    for row in rows:
        gain = _d(row["current_value"]) - _d(row["invested_value"])
        if gain <= 0:
            continue                          # a loss is not taxed until realised
        bought = row["bought"]
        if not bought:
            undated += gain
            continue

        months_held = (today.year - bought.year) * 12 + (today.month - bought.month)
        threshold = LONG_TERM_MONTHS.get(row["asset_class"], DEFAULT_LONG_TERM_MONTHS)

        if months_held >= threshold:
            long_gain += gain
        else:
            short_gain += gain
            # Within three months of turning long-term, which is worth saying:
            # waiting changes the rate on that gain from 20% to 12.5%.
            # Worth raising only where waiting saves something. A hundred
            # rupees of gain crossing the long-term line saves seven rupees of
            # tax, and telling somebody to time a sale around that is noise
            # dressed as advice.
            saving = gain * (STCG_RATE - LTCG_RATE) / 100
            if threshold - months_held <= 3 and saving >= Decimal("2000"):
                nearly.append({
                    "name": row["instrument_name"],
                    "gain": str(gain.quantize(Decimal("1"))),
                    "saving": str(saving.quantize(Decimal("1"))),
                    "months_to_go": threshold - months_held,
                })

    taxable_long = max(long_gain - LTCG_EXEMPT, Decimal(0))
    tax = (taxable_long * LTCG_RATE / 100) + (short_gain * STCG_RATE / 100)

    return {
        "short_term_gain": str(short_gain.quantize(Decimal("1"))),
        "long_term_gain": str(long_gain.quantize(Decimal("1"))),
        "exempt": str(min(long_gain, LTCG_EXEMPT).quantize(Decimal("1"))),
        "estimated_tax": str(tax.quantize(Decimal("1"))),
        "undated_gain": str(undated.quantize(Decimal("1"))) if undated > 0 else None,
        "nearly_long_term": sorted(nearly, key=lambda n: -Decimal(n["gain"]))[:3],
        "method": ("Long-term gains above the ₹1.25 lakh exemption at 12.5%, short-term "
                   "at 20%. Losses are not counted, because they are only worth "
                   "something once taken. This is what today's paper gain would cost "
                   "to realise, not advice to realise it."),
    }


def _volatility(investor_id: str) -> Optional[dict]:
    """How much the holdings move, weighted by what is held.

    Beta against the market for shares, and for funds the swing their own NAV
    history shows. A portfolio's volatility is not the average of its parts --
    holdings that move differently cancel out -- so this is described as the
    volatility of what is held rather than of the portfolio, which would need a
    covariance matrix and more history than we have.
    """
    rows = db.fetch_all(
        """
        SELECT v.current_value, f.beta
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        LEFT JOIN company_fundamentals f ON f.isin = i.isin OR f.symbol = i.symbol
        WHERE v.investor_id = %s AND i.asset_class = 'equity' AND v.current_value > 0
        """,
        (investor_id,),
    )
    weighted = Decimal(0)
    weight = Decimal(0)
    for row in rows:
        if row["beta"] is None:
            continue
        value = _d(row["current_value"])
        weighted += _d(row["beta"]) * value
        weight += value
    if weight <= 0:
        return None

    beta = weighted / weight
    return {
        "beta": str(beta.quantize(Decimal("0.01"))),
        "covered_value": str(weight.quantize(Decimal("1"))),
        "reading": ("moves more than the market" if beta > Decimal("1.1")
                    else "moves less than the market" if beta < Decimal("0.9")
                    else "moves roughly with the market"),
        "method": ("Each share's beta against the market, weighted by what you hold of "
                   "it. A beta of 1.2 means that when the market moved 10%, this has "
                   "historically moved about 12%."),
    }


def _income(investor_id: str) -> Optional[dict]:
    """What the holdings pay out in a year, and what that is on what they cost.

    Dividend yield quoted against current value is the number everybody shows.
    Against what somebody actually paid is the more interesting one: a stock
    bought years ago on a 2% yield may be paying 8% on the original cost.
    """
    rows = db.fetch_all(
        """
        SELECT v.current_value, v.invested_value, f.dividend_yield
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        JOIN company_fundamentals f ON f.isin = i.isin OR f.symbol = i.symbol
        WHERE v.investor_id = %s AND i.asset_class = 'equity'
          AND v.current_value > 0 AND f.dividend_yield IS NOT NULL
        """,
        (investor_id,),
    )
    if not rows:
        return None

    annual = Decimal(0)
    value = Decimal(0)
    cost = Decimal(0)
    for row in rows:
        current = _d(row["current_value"])
        yield_pct = _d(row["dividend_yield"])
        if yield_pct <= 0 or yield_pct > 30:      # a yield past 30% is bad data
            continue
        annual += current * yield_pct / 100
        value += current
        cost += _d(row["invested_value"])

    if value <= 0 or annual <= 0:
        return None

    return {
        "annual_income": str(annual.quantize(Decimal("1"))),
        "yield_on_value": str((annual / value * 100).quantize(Decimal("0.01"))),
        "yield_on_cost": (str((annual / cost * 100).quantize(Decimal("0.01")))
                          if cost > 0 else None),
        "covered_value": str(value.quantize(Decimal("1"))),
        "method": ("Each company's declared yield applied to what you hold. Against "
                   "what you paid rather than what it is worth, because that is the "
                   "return the money you committed is actually earning."),
    }



def _scenario(investor_id: str) -> Optional[dict]:
    """What a bad market would do to this portfolio.

    Two ways of asking, and they answer differently.

    Beta says what happens in an ordinary fall: a portfolio at 1.28 drops about
    a quarter more than the market does. That holds until it does not --
    correlations tighten in a crisis and everything falls together, which is
    why beta understates the worst case.

    So the second figure is what the holdings have actually done. Each one's
    own worst fall, weighted by what is held of it, is a floor built from
    history rather than from a coefficient.
    """
    holdings = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.symbol, v.asset_class,
               v.current_value, f.beta
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        LEFT JOIN company_fundamentals f ON f.isin = i.isin OR f.symbol = i.symbol
        WHERE v.investor_id = %s AND v.current_value > 0
        """,
        (investor_id,),
    )
    if not holdings:
        return None

    total = sum(_d(h["current_value"]) for h in holdings)
    if total <= 0:
        return None

    from ..services import navs

    weighted_beta = Decimal(0)
    beta_weight = Decimal(0)
    weighted_worst = Decimal(0)
    worst_weight = Decimal(0)
    worst_single = None

    for holding in holdings:
        value = _d(holding["current_value"])
        if holding["beta"] is not None:
            weighted_beta += _d(holding["beta"]) * value
            beta_weight += value

        # What this holding has actually done at its worst.
        fall = None
        try:
            if holding["asset_class"] == "equity" and holding["symbol"]:
                fall = navs.equity_drawdown(holding["symbol"], "5y")
            else:
                fall = navs.drawdown(holding["instrument_id"])
        except Exception:
            fall = None

        if fall and fall.get("worst_fall_pct"):
            pct_fall = _d(fall["worst_fall_pct"])
            weighted_worst += pct_fall * value
            worst_weight += value
            loss = value * pct_fall / 100
            if worst_single is None or loss > _d(worst_single["loss"]):
                worst_single = {
                    "name": holding["instrument_name"],
                    "fall_pct": str(pct_fall),
                    "loss": str(loss.quantize(Decimal("1"))),
                }

    beta = (weighted_beta / beta_weight) if beta_weight > 0 else None

    falls = []
    for market_fall in (10, 20, 30):
        if beta is None:
            break
        drop = total * beta * Decimal(market_fall) / 100
        falls.append({
            "market_fall_pct": market_fall,
            "your_fall_pct": str((beta * market_fall).quantize(Decimal("0.1"))),
            "you_would_lose": str(drop.quantize(Decimal("1"))),
            "left_with": str((total - drop).quantize(Decimal("1"))),
        })

    history = None
    if worst_weight > 0:
        average_worst = weighted_worst / worst_weight
        covered = worst_weight / total * 100
        history = {
            "average_worst_fall_pct": str(average_worst.quantize(Decimal("0.1"))),
            "you_would_lose": str((total * average_worst / 100).quantize(Decimal("1"))),
            "covered_pct": str(covered.quantize(Decimal("0.1"))),
            "worst_single": worst_single,
        }

    if not falls and not history:
        return None

    return {
        "total": str(total.quantize(Decimal("1"))),
        "beta": str(beta.quantize(Decimal("0.01"))) if beta is not None else None,
        "falls": falls,
        "history": history,
        "method": ("The first is arithmetic on beta: how much this has moved when the "
                   "market moved, applied to a fall that has not happened. The second "
                   "is what these holdings have each already done at their worst, which "
                   "is usually the larger number -- in a real crisis things fall "
                   "together rather than according to their betas."),
    }


def _structural(investor_id: str, market_cap: Optional[dict],
                concentration: dict, sectors: dict) -> dict:
    """The shape of the portfolio, gathered in one place.

    Nothing new is computed here. The point is that market cap, industry and
    spread are three answers to one question -- what is this portfolio made of
    -- and reading them apart makes each look smaller than it is.
    """
    lines = []

    if market_cap:
        largest = max(
            (("large", market_cap["large"]), ("mid", market_cap["mid"]),
             ("small", market_cap["small"])),
            key=lambda pair: _d(pair[1]),
        )
        lines.append({
            "what": "By company size",
            "reading": f"{_d(largest[1]):.0f}% in {largest[0]} companies",
            "detail": market_cap,
        })

    top_sectors = [s for s in (sectors.get("sectors") or [])
                   if (s.get("sector") or "").lower() != "not classified"][:3]
    if top_sectors:
        lines.append({
            "what": "By industry",
            "reading": (f"{_d(top_sectors[0]['share_pct']):.0f}% in "
                        f"{top_sectors[0]['sector'].lower()}"),
            "detail": {"top": top_sectors,
                       "coverage_pct": sectors.get("attributed_share_pct")},
        })

    if concentration.get("effective_holdings"):
        lines.append({
            "what": "By spread",
            "reading": (f"{concentration['positions']} positions behaving like "
                        f"{concentration['effective_holdings']}"),
            "detail": {"hhi": str(concentration.get("hhi")),
                       "sector_hhi": str(concentration.get("sector_hhi"))},
        })

    return {"lines": lines}



def _risk_radar(investor_id: str, concentration: dict, volatility: Optional[dict],
                scenario: Optional[dict], drift_result: Optional[dict],
                sectors: dict) -> Optional[dict]:
    """Five kinds of risk on one picture.

    A radar is usually where honest numbers go to become a shape. This one
    carries the underlying figure on every axis, so the shape is a way in
    rather than the answer -- somebody who wants to know why an axis is long
    can read the number that made it.

    Each axis runs nought to a hundred, where a hundred is bad. The scaling is
    stated per axis and is judgement rather than measurement, which is exactly
    why the raw figure travels with it.
    """
    axes = []

    # How much rests on one holding. Ten equal holdings score 1,000 on the
    # Herfindahl index; one holding scores 10,000.
    hhi = _d(concentration.get("hhi"))
    if hhi > 0:
        axes.append({
            "axis": "Resting on few holdings",
            "score": str(min(Decimal(100), (hhi / Decimal(50))).quantize(Decimal("1"))),
            "reading": f"{concentration['positions']} positions, spread like "
                       f"{concentration['effective_holdings']}",
            "scale": "The Herfindahl index over 50. Ten equal holdings would score 20.",
        })

    # How much rests on one industry.
    top = [s for s in (sectors.get("sectors") or [])
           if (s.get("sector") or "").lower() != "not classified"]
    if top and _d(sectors.get("attributed_share_pct")) >= 40:
        share = _d(top[0]["share_pct"])
        axes.append({
            "axis": "Resting on one industry",
            "score": str(min(Decimal(100), share * Decimal("1.5")).quantize(Decimal("1"))),
            "reading": f"{share:.0f}% in {top[0]['sector'].lower()}",
            "scale": "A third in one industry scores 50; two thirds scores 100.",
        })

    # How much it moves against the market.
    if volatility and volatility.get("beta"):
        beta = _d(volatility["beta"])
        axes.append({
            "axis": "Moves with the market",
            "score": str(min(Decimal(100), beta * Decimal(50)).quantize(Decimal("1"))),
            "reading": f"beta {beta:.2f}",
            "scale": "A beta of 1.0 -- moving exactly with the market -- scores 50.",
        })

    # What history says the worst case is.
    if scenario and scenario.get("history"):
        worst = _d(scenario["history"]["average_worst_fall_pct"])
        axes.append({
            "axis": "How far it has fallen before",
            "score": str(min(Decimal(100), worst * Decimal("1.4")).quantize(Decimal("1"))),
            "reading": f"{worst:.0f}% at worst, weighted by holding",
            "scale": "A 70% fall scores 100. These are falls that have already happened.",
        })

    # How far from what was intended.
    if drift_result and drift_result.get("worst_gap_pct"):
        gap = _d(drift_result["worst_gap_pct"])
        axes.append({
            "axis": "Away from your plan",
            "score": str(min(Decimal(100), gap * Decimal(2)).quantize(Decimal("1"))),
            "reading": f"{gap:.0f} points from the mix you set",
            "scale": "Fifty points of drift scores 100.",
        })

    # Three axes is the fewest that draws as a shape rather than a line.
    if len(axes) < 3:
        return None

    return {
        "axes": axes,
        "method": ("Each axis is scaled so that a hundred is uncomfortable, and the "
                   "scaling is judgement rather than measurement. The figure behind "
                   "every axis is shown for that reason: the shape is a way in, not "
                   "the answer."),
    }



BENCHMARK_SYMBOL = "NIFTYBEES"


def _benchmark(investor_id: str) -> Optional[dict]:
    """The same money, in the index instead.

    The question somebody is really asking when they ask how they have done is
    whether the choosing was worth it. Against a savings account almost
    anything looks good; against simply buying the market, most portfolios do
    not -- and that comparison is the one that decides whether picking is worth
    the time it costs.

    Measured from the first date we can price the portfolio, using the index
    ETF rather than the index: buying the market means buying this, dividends
    and all.
    """
    since = db.fetch_one(
        """
        SELECT min(as_of) AS first FROM holding_snapshots
        WHERE investor_id = %s AND as_of > '1990-01-01'
        """,
        (investor_id,),
    )
    if not since or not since["first"]:
        return None

    start = since["first"]
    if (date.today() - start).days < 180:
        return None                         # too short a window to say anything

    bounds = db.fetch_all(
        """
        (SELECT trade_date, close FROM benchmark_daily
         WHERE symbol = %s AND trade_date >= %s ORDER BY trade_date LIMIT 1)
        UNION ALL
        (SELECT trade_date, close FROM benchmark_daily
         WHERE symbol = %s ORDER BY trade_date DESC LIMIT 1)
        """,
        (BENCHMARK_SYMBOL, start, BENCHMARK_SYMBOL),
    )
    if len(bounds) < 2:
        return None

    then, now = bounds[0], bounds[1]
    if _d(then["close"]) <= 0 or then["trade_date"] >= now["trade_date"]:
        return None

    index_growth = _d(now["close"]) / _d(then["close"])

    summary = wealth.net_worth(investor_id)
    invested = _d(summary["invested_value"])

    # Both sides of the comparison must be the same money.
    #
    # This used the whole portfolio against the contributions we can trace,
    # so every holding entered without a cost basis counted as pure
    # outperformance. On a real account a provident fund and a gold holding
    # with no recorded cost produced "you are ahead of the index by fifty-four
    # lakh" -- a claim about somebody's skill made entirely of arithmetic on
    # money we could not account for.
    current = _d(summary.get("gain_covers_value")) or _d(summary["total_value"])
    if invested <= 0 or current <= 0:
        return None

    yours = current / invested
    would_be = invested * index_growth
    difference = current - would_be

    years = Decimal((now["trade_date"] - then["trade_date"]).days) / Decimal("365.25")

    def annualise(growth: Decimal) -> Optional[Decimal]:
        if years <= 0 or growth <= 0:
            return None
        try:
            return ((growth ** (Decimal(1) / years)) - 1) * 100
        except (ArithmeticError, ValueError):
            return None

    your_cagr = annualise(yours)
    index_cagr = annualise(index_growth)

    return {
        "since": then["trade_date"].isoformat(),
        "years": str(years.quantize(Decimal("0.1"))),
        "your_value": str(current.quantize(Decimal("1"))),
        "index_value": str(would_be.quantize(Decimal("1"))),
        "difference": str(difference.quantize(Decimal("1"))),
        "ahead": difference > 0,
        # What share of the portfolio this compares. Where it is well under a
        # hundred, the comparison is about part of somebody's money and the
        # page should say which part rather than implying all of it.
        "covers_pct": summary.get("gain_covers_pct"),
        "partial": (_d(summary.get("gain_covers_pct")) < 95
                    if summary.get("gain_covers_pct") else False),
        "your_growth_pct": str(((yours - 1) * 100).quantize(Decimal("0.1"))),
        "index_growth_pct": str(((index_growth - 1) * 100).quantize(Decimal("0.1"))),
        "your_cagr_pct": str(your_cagr.quantize(Decimal("0.1"))) if your_cagr else None,
        "index_cagr_pct": str(index_cagr.quantize(Decimal("0.1"))) if index_cagr else None,
        "method": ("Your cost put into NIFTYBEES on the same day, held since. The ETF "
                   "rather than the index, because buying the market means buying "
                   "something -- and this is what it costs, dividends included. It "
                   "assumes the whole amount went in at the start, which flatters "
                   "whichever of the two rose earlier."),
    }


@router.get("/{investor_id}", summary="Everything the dashboard draws")
def dashboard(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    allocation = wealth.allocation(investor_id)

    # Which asset classes are worth a view of their own.
    classes = [
        a["asset_class"] for a in allocation
        if _d(a["value"]) >= MIN_VALUE_FOR_OWN_VIEW
        and (a.get("positions") or 1) >= MIN_POSITIONS_FOR_OWN_VIEW
    ]

    views: dict = {
        "everything": {
            "headline": _headline(investor_id),
            "movers": _movers(investor_id),
            "returns": wealth.returns(investor_id),
        }
    }
    for asset_class in classes:
        views[asset_class] = {
            "headline": _headline(investor_id, asset_class),
            "movers": _movers(investor_id, asset_class),
        }

    concentration = analysis.concentration(investor_id)
    sectors = analysis.sector_exposure(investor_id)
    holdings = wealth.holdings(investor_id)
    parts = findings._split_by_nature(holdings)
    equity_total = parts["equity"] or Decimal(1)

    volatility = _volatility(investor_id)
    scenario = _scenario(investor_id)
    drift_result = __import__("api.services.profile", fromlist=["drift"]).drift(investor_id)

    market_cap = {
        "large": str((parts["large_cap"] / equity_total * 100).quantize(Decimal("0.1"))),
        "mid": str((parts["mid_cap"] / equity_total * 100).quantize(Decimal("0.1"))),
        "small": str((parts["small_cap"] / equity_total * 100).quantize(Decimal("0.1"))),
        "multi": str((parts["multi_cap"] / equity_total * 100).quantize(Decimal("0.1"))),
        "equity_value": str(parts["equity"]),
    } if parts["equity"] > 0 else None

    shape = _value_shape(investor_id)

    return {
        "investor": wealth.get_investor(investor_id),
        "views": views,
        "classes": classes,
        "allocation": allocation,
        # The market-cap split, which only means something where shares or
        # equity funds are held.
        "market_cap": market_cap,
        "structural": _structural(investor_id, market_cap, concentration, sectors),
        "owed": debts.for_investor(investor_id),
        "concentration": concentration,
        "sectors": sectors,
        "value_shape": shape,
        # Beta handed over rather than fetched: it is computed by a helper
        # private to this router, and a service importing from a router makes
        # both harder to move later.
        "shocks": shocks.for_investor(
            investor_id, beta=(shape or {}).get("beta")),
        "tax": _tax_shape(investor_id),
        "volatility": volatility,
        "income": _income(investor_id),
        "drift": drift_result,
        "cost_drag": projections.cost_drag(investor_id),
        "step_up": projections.step_up(investor_id),
        # Peers is fetched separately -- it makes a network call per category
        # plus one per fund, and six seconds of that in the main load is a
        # dashboard that looks broken while it waits. XIRR is local and cheap.
        "forward": forward.for_investor(investor_id),
        "protection": protection.for_investor(investor_id),
        "value_history": wealth.value_history(investor_id, 24),
        "xirr": xirr.for_investor(investor_id),
        "tail": var.for_investor(investor_id),
        "scenario": scenario,
        "benchmark": _benchmark(investor_id),
        "rebalance": __import__("api.services.rebalance",
                                fromlist=["suggestions"]).suggestions(investor_id),
        "risk_radar": _risk_radar(investor_id, concentration, volatility, scenario,
                                  drift_result, sectors),
        "funds": analysis.fund_quality(investor_id),
        "findings": findings.for_investor(investor_id),
        "timeline": wealth.timeline(investor_id, months=36),
    }
