"""What this person should do with their money, and why."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import (advisers, auth, decide as decide_service, judgement,
                        ledger, wealth)
from .auth import current_user

router = APIRouter(prefix="/api/decide", tags=["Decision"])


@router.get("/{investor_id}", summary="Everything worth doing, in order")
def decide(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    decision = decide_service.decide(investor_id)

    # Worked out fresh, every time.
    #
    # There is no stored advice to fetch: the engine runs against this
    # morning's prices and this morning's holdings, so what somebody sees is
    # what is true now rather than what was true when it was last computed.
    # That is what makes "we said this yesterday and it still stands" a
    # statement about their portfolio rather than about our cache.
    actions = decision.get("actions") or []

    # The adviser's judgement over the engine's output. They can change what is
    # said, hold something back, or add a point the engine never reached --
    # and an adviser who cannot do that is not advising.
    edits = judgement.apply_overrides(investor_id, actions)
    decision["actions"] = edits["actions"]
    if edits.get("reading"):
        decision["adviser_changed"] = {
            "reading": edits["reading"],
            "edited": edits["edited"],
            "suppressed": edits["suppressed"],
            "notes": edits["notes"],
        }

    # What was said before, against what is being said now.
    carried = judgement.since_yesterday(investor_id, decision["actions"])
    if carried:
        decision["since_last_time"] = carried

    # Under whose registration this was given. Recorded on the row, and
    # surfaced so the page can say it rather than leaving it implied.
    decision["adviser"] = advisers.of_record(investor_id)

    record_id = ledger.record(
        investor_id, "decision",
        said={"health": decision.get("health"),
              "actions": decision.get("actions"),
              "withheld": decision.get("withheld"),
              "reading": decision.get("reading")},
        basis={"risk": decision.get("risk"),
               "data_quality": decision.get("data_quality"),
               "investor": decision.get("investor"),
               "adviser_edits": {"edited": edits["edited"],
                                 "suppressed": edits["suppressed"]}},
        surface="dashboard",
    )

    # And noted as shown today, so tomorrow can be compared with it.
    judgement.note_shown(investor_id, decision["actions"], record_id)

    return decision
