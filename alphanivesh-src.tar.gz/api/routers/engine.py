"""The decision engine, for the rest of the group.

A keyed endpoint that takes a complete picture of somebody's finances and
returns what they should do about it, in the order it is worth doing.

Separate from `/api/decide/{investor_id}`, which is this platform's own route
into the same engine. That one assembles the picture from our database; this
one takes it from whoever is calling, so the stocks product, the MF product and
the AIF product can all ask the same question of the same engine and get
answers that agree.

`DECISION_ENGINE_API.md` in this repository is the contract.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter, Body, Header, HTTPException

from ..services import decide as decide_service, ledger

log = logging.getLogger("alphanivesh.engine")

router = APIRouter(prefix="/api/v1", tags=["Engine"])

# Comma-separated, one per caller, so a key can be withdrawn without affecting
# the others and so the logs say which product asked.
KEYS = {
    part.split(":")[0]: part.split(":")[1] if ":" in part else part
    for part in (os.environ.get("ALPHA_ENGINE_KEYS", "") or "").split(",")
    if part.strip()
}

MAX_HOLDINGS = 200


def _caller(key: str | None) -> str:
    if not KEYS:
        raise HTTPException(
            status_code=503,
            detail="The engine has no keys configured. Set ALPHA_ENGINE_KEYS.")
    if not key:
        raise HTTPException(status_code=401,
                            detail="API key required. Pass via X-API-Key header.")
    for name, value in KEYS.items():
        if key == value:
            return name
    raise HTTPException(status_code=401, detail="Invalid API key.")


@router.get("/decide/health", summary="Whether the engine is up")
def health() -> dict:
    return {"status": "healthy", "engine": "alphanivesh-decision-1.0",
            "callers": sorted(KEYS)}


@router.post("/decide", summary="What this person should do with their money")
def decide(payload: dict = Body(...),
           x_api_key: str = Header(default=None)) -> dict:
    """A complete picture in, an ordered answer out.

    Stateless: nothing is stored and the same picture always produces the same
    decision. A disagreement between two callers is a difference in what they
    sent, which is checkable, rather than a difference in what happened, which
    is not.
    """
    caller = _caller(x_api_key)

    holdings = payload.get("holdings")
    if not holdings:
        raise HTTPException(
            status_code=400,
            detail="holdings[] is required — at minimum a list of "
                   "{kind, current_value}.")
    if len(holdings) > MAX_HOLDINGS:
        raise HTTPException(
            status_code=400,
            detail=f"The engine takes {MAX_HOLDINGS} holdings at a time; this "
                   f"picture has {len(holdings)}.")

    for i, holding in enumerate(holdings):
        if not holding.get("kind"):
            raise HTTPException(
                status_code=422,
                detail=f"holdings[{i}] has no kind. One of: equity, "
                       f"mutual_fund, etf, bond, gsec, gold, fixed_deposit, "
                       f"insurance, nps, ppf_epf, real_estate, cash.")
        if holding.get("current_value") is None:
            raise HTTPException(
                status_code=422,
                detail=f"holdings[{i}] has no current_value. The engine cannot "
                       f"weigh a holding whose size it does not know.")

    picture = _picture_from(payload)

    try:
        decision = decide_service.from_picture(picture)
    except Exception as err:                                     # pragma: no cover
        log.exception("engine failed for %s", caller)
        raise HTTPException(status_code=500, detail=str(err)[:200])

    # Advice given through the shared engine is still our advice. A caller
    # acting on it does so on our reasoning, and the record has to say which
    # product asked as well as what we answered.
    investor_ref = (payload.get("investor") or {}).get("reference")
    if investor_ref:
        ledger.record(
            investor_ref, "decision",
            said={"health": decision.get("health"),
                  "actions": decision.get("actions"),
                  "withheld": decision.get("withheld")},
            basis={"picture": {"holdings": len(holdings),
                               "liabilities": len(payload.get("liabilities") or []),
                               "profile": payload.get("investor")},
                   "risk": decision.get("risk"),
                   "data_quality": decision.get("data_quality")},
            surface="api", caller=caller,
        )

    log.info("decision for %s: %d holdings, %d actions",
             caller, len(holdings), len(decision.get("actions") or []))
    return decision


def _picture_from(payload: dict) -> dict:
    """Turn a caller's payload into what the engine reads.

    The translation lives here rather than in the engine so the wire format can
    change without the reasoning changing, and so a caller sending something
    unexpected gets a clear error rather than a strange decision.
    """
    holdings = payload.get("holdings") or []

    total = sum(float(h.get("current_value") or 0) for h in holdings)
    invested = sum(float(h.get("invested_value") or h.get("current_value") or 0)
                   for h in holdings)
    gain_pct = ((total - invested) / invested * 100).quantize(Decimal("0.1")) if invested > 0 else None

    return {
        "investor_id": None,
        "profile": payload.get("investor") or {},
        "summary": {
            "positions": len(holdings),
            "total_value": total,
            "invested_value": invested,
            "absolute_return_pct": gain_pct,
        },
        "holdings": holdings,
        "liabilities": payload.get("liabilities") or [],
        "goals": payload.get("goals") or [],
        "transactions": payload.get("transactions") or [],
        "target_allocation": payload.get("target_allocation") or {},
        # A caller who has not supplied enough for a risk reading gets the
        # cautious default rather than an optimistic guess.
        "risk": payload.get("risk") or {
            "ceiling": 3, "name": "moderate", "binding": "not assessed",
            "why": ("The caller did not supply enough about this person to "
                    "assess risk, so the engine holds to moderate."),
            "capacity": {"band": 3, "name": "moderate", "reasons": []},
            "tolerance": {"band": None, "name": "not known", "evidence": []},
        },
        "behaviour": payload.get("behaviour") or {},
        "source": "external",
    }
