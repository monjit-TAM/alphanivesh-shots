"""What we noticed about a portfolio."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, findings, ledger, wealth
from .auth import current_user

router = APIRouter(prefix="/api/findings", tags=["Findings"])


@router.get("/{investor_id}", summary="Computed observations about this portfolio")
def for_investor(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    found = findings.for_investor(investor_id)

    # Findings are analysis put in front of an investor, so they are recorded
    # like any other advice. The basis is what they were computed against,
    # which is the part an audit asks about.
    ledger.record(
        investor_id, "finding",
        said={"findings": found.get("findings"),
              "worth_doing_now": found.get("worth_doing_now"),
              "reading": found.get("reading")},
        basis={"counted": found.get("counted"),
               "portfolio_total": found.get("portfolio_total"),
               "as_of": found.get("as_of")},
        surface="dashboard",
    )
    return found
