"""What became of what we said."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, followup, wealth
from .auth import current_user

router = APIRouter(prefix="/api/followup", tags=["Follow-up"])


@router.get("/{investor_id}", summary="What became of earlier advice")
def since_last_time(investor_id: str,
                    user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    # None where there is nothing to say -- no advice old enough, or none of
    # it checkable. The page shows nothing rather than an empty panel.
    return followup.since_last_time(investor_id) or {"nothing_yet": True}
