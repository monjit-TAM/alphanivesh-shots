"""One fund, in depth — fetched when somebody asks for it.

Separate from the dashboard's own payload on purpose. A portfolio of eighteen
funds would mean eighteen calls across the network before anything rendered,
and most of them would be for cards nobody opens. This is called when a card
is expanded.
"""

from __future__ import annotations

import logging
from typing import Optional

from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException

from .. import db
from ..services import analysis, auth, dataservice, navs, wealth
from .auth import current_user

log = logging.getLogger("alphanivesh.fund")

router = APIRouter(prefix="/api/fund", tags=["Fund"])




# Ratios worth showing, in the order somebody would ask: what it costs, what it
# earns, what it owes, how it has grown. Each carries how to read it, because a
# number without its units is a number nobody can use.
EQUITY_MEASURES = (
    ("what it costs", (
        ("pe_ttm", "Price to earnings", "x", "What you pay for each rupee it earns"),
        ("pb_ratio", "Price to book", "x", "What you pay for each rupee of its assets"),
        ("ev_ebitda", "Enterprise value to EBITDA", "x", None),
        ("dividend_yield", "Dividend yield", "%", None),
    )),
    ("what it earns", (
        ("roe", "Return on equity", "%", "What it makes on shareholders' money"),
        ("roce", "Return on capital employed", "%", None),
        ("net_margin", "Net margin", "%", "What it keeps of every rupee of sales"),
        ("ebitda_margin", "EBITDA margin", "%", None),
    )),
    ("what it owes", (
        ("debt_to_equity", "Debt to equity", "x", "Borrowings against shareholders' money"),
        ("interest_coverage", "Interest cover", "x", "Times over it can pay its interest"),
        ("current_ratio", "Current ratio", "x", None),
    )),
    ("how it has grown", (
        ("revenue_growth_yoy", "Revenue, year on year", "%", None),
        ("pat_growth_yoy", "Profit, year on year", "%", None),
        ("eps_growth_yoy", "Earnings per share, year on year", "%", None),
    )),
)


def _equity_detail(investor_id: str, instrument_id: str, holding: dict,
                   result: dict) -> dict:
    """What a directly held share is, costs, earns, owes and has grown.

    Fundamentals come from the company master we hold locally; the live price
    and the sector medians come with them. Where a figure is missing it is left
    out rather than shown as a dash, because a page of dashes reads as broken
    when it is only incomplete.
    """
    symbol = (holding.get("symbol") or "").strip().upper()
    isin = (holding.get("isin") or "").strip().upper()

    company = None
    if symbol or isin:
        company = db.fetch_one(
            """
            SELECT * FROM company_fundamentals
            WHERE (%s <> '' AND symbol = %s) OR (%s <> '' AND isin = %s)
            LIMIT 1
            """,
            (symbol, symbol, isin, isin),
        )

    if company is None:
        result["unavailable"].append(
            "We have not matched this to a listed company, so there is nothing "
            "further to show about it."
        )
        return result

    # What each unit cost, against what it is worth now. The file gave a buy
    # price; without showing it beside the current one, a gain is a number
    # without a story.
    holding_row = db.fetch_one(
        """
        SELECT avg_cost, quantity FROM holding_snapshots
        WHERE instrument_id = %s AND investor_id = %s AND avg_cost IS NOT NULL
        ORDER BY as_of LIMIT 1
        """,
        (instrument_id, investor_id),
    )
    if holding_row and holding_row["avg_cost"]:
        result["cost_basis"] = {
            "per_unit": str(holding_row["avg_cost"]),
            "quantity": str(holding_row["quantity"] or 0),
        }

    result["company"] = {
        "name": company["company_name"],
        "symbol": company["symbol"],
        "sector": company["sector"],
        "industry": company["industry"],
        "size": (company["market_cap_category"] or "").title() or None,
        "market_cap": company["market_cap"],
    }

    # The sector's own medians, so each figure has something to sit against.
    # Computed from the companies we hold rather than quoted from anywhere,
    # which is why the count is reported: a median of four companies is not a
    # median worth much.
    medians: dict = {}
    if company["sector"]:
        fields = [f for _, group in EQUITY_MEASURES for f, _, _, _ in group]
        selects = ", ".join(
            f"percentile_cont(0.5) WITHIN GROUP (ORDER BY {f}) AS {f}" for f in fields
        )
        row = db.fetch_one(
            f"SELECT count(*) AS n, {selects} FROM company_fundamentals WHERE sector = %s",
            (company["sector"],),
        )
        if row and row["n"] >= 5:
            medians = {k: v for k, v in row.items() if k != "n" and v is not None}
            medians["_count"] = row["n"]

    groups = []
    for title, measures in EQUITY_MEASURES:
        rows = []
        for field, label, unit, explain in measures:
            value = company.get(field)
            if value is None:
                continue
            rows.append({
                "label": label,
                "value": str(value),
                "unit": unit,
                "explain": explain,
                "sector_median": str(medians[field]) if field in medians else None,
            })
        if rows:
            groups.append({"title": title, "measures": rows})

    result["measures"] = groups
    result["sector_median_from"] = medians.get("_count")

    # Three views of the same company: what you pay, whether it is growing, and
    # whether it earns well on its capital. Each measure against its own sector,
    # because a threshold that ignores the industry mislabels most holdings.
    # Three lenses and a call from each. All three are shown: the same holding
    # is a sell through value and a buy through growth, and an investor shown
    # only the verdict that contradicts how they invest will disbelieve the
    # rest of the page.
    # The engine on stocks.alphamarket is the source of truth for a share's
    # verdict. Their instruction is explicit and right: do not mix the outputs,
    # because two scoring models disagreeing reads as a fault in both.
    #
    # Our own lens measures stay as context beneath it. They are a different
    # measurement rather than a competing verdict -- their fundamental pillar
    # bands the P/E across every industry, which is how a company at its
    # sector's median comes back as "very expensive", and the sector figure is
    # what stops that being read as a fact about the company.
    # Risk-adjusted returns, from whatever price series this kind of holding
    # has. A share and a fund get the same figures against the same benchmark,
    # which is the point: an investor comparing one to the other should not
    # have to translate between two ways of measuring.
    result["ratios"] = _ratios_for(instrument_id, holding)

    try:
        from ..services import rebalance_engine
        engine = rebalance_engine.for_investor(investor_id, max_picks=5)
        if engine and engine.get("available"):
            for line in engine["holdings"]:
                if (line.get("symbol") or line.get("stock_name") or "").upper() == symbol:
                    result["verdict"] = line
                    result["engine_note"] = engine["note"]
                    break
    except Exception as err:                                     # pragma: no cover
        log.warning("rebalance engine failed for %s: %s", symbol, err)

    try:
        from ..services import quantamental
        share = None
        total = db.fetch_one(
            "SELECT sum(current_value) AS total FROM v_current_holdings WHERE investor_id = %s",
            (investor_id,),
        )
        if total and total["total"]:
            share = (Decimal(str(holding["current_value"]))
                     / Decimal(str(total["total"])) * 100)
        result["lenses"] = quantamental.verdicts(symbol=symbol, isin=isin,
                                                 position_share_pct=share)
    except Exception as err:                                     # pragma: no cover
        log.warning("lenses failed for %s: %s", symbol or isin, err)

    # A live price, so the position is worth what it is worth rather than what
    # a statement said last quarter.
    if symbol:
        try:
            quote = dataservice.quote(symbol)
            result["quote"] = {
                "price": quote.get("price"),
                "change_pct": quote.get("change_pct"),
                "is_live": quote.get("is_live", True),
                "as_of": quote.get("as_of"),
                "source": quote.get("source"),
            }
        except dataservice.DataServiceError:
            pass

    # And how far it has fallen, from prices we hold.
    try:
        result["drawdown"] = navs.drawdown(instrument_id)
    except Exception:                                            # pragma: no cover
        pass

    return result



def _ratios_for(instrument_id: str, holding: dict) -> Optional[dict]:
    """Sharpe, Sortino, alpha, beta and capture for one holding.

    Shared by both detail paths. It lived inline in the equity one, which is
    why the fund card had a ratios key that was always None -- the arithmetic
    was fine and nothing asked for it.
    """
    from ..services import ratios

    try:
        return ratios.for_instrument(
            instrument_id,
            asset_class=(holding or {}).get("asset_class") or "mutual_fund")
    except Exception as err:                                     # pragma: no cover
        log.warning("ratios failed for %s: %s", instrument_id, err)
        return None


def _drop_empty_clauses(text: str) -> str:
    """Remove trailing clauses the source filled with nulls.

    The research service writes prose from computed figures, and where a figure
    is missing the sentence still gets written -- "ranking None of None Direct
    plans". Showing that tells the reader we are assembling text from parts,
    which undermines every accurate sentence beside it.
    """
    import re

    # A clause containing None as a word, from the last comma or dash onwards.
    trimmed = re.sub(r"[,\u2014-]\s*[^,\u2014]*\bNone\b[^,\u2014]*(?=[.]|$)", "", text)
    # Or the whole sentence, if None survived elsewhere in it.
    sentences = [s.strip() for s in re.split(r"(?<=[.])\s+", trimmed)
                 if s.strip() and not re.search(r"\bNone\b", s)]
    result = " ".join(sentences).strip()
    return re.sub(r"\s+([.,])", r"\1", result)


@router.get("/{investor_id}/{instrument_id}", summary="Everything about one holding")
def detail(investor_id: str, instrument_id: str,
           user: dict = Depends(current_user)) -> dict:
    """What this fund is, what it has done, and what it holds.

    The narrative comes from the shared data service, which computes it from
    the fund's own NAV history and disclosures and writes it as prose. It is
    better than anything we would write here, because it has the whole scheme
    universe to compare against.

    The arithmetic we hold ourselves -- drawdown, the investor's own position --
    stays ours. Where the two disagree, ours is the one computed from data we
    can inspect: their drawdown reports -100% for a fund whose NAV never fell
    below its starting value, which is wrong in a way that would end somebody's
    trust in every other number on the page.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    holding = db.fetch_one(
        """
        SELECT v.instrument_id, i.name, i.asset_class, i.native_code, i.isin,
               i.symbol, i.category, v.quantity, v.current_value, v.invested_value, v.as_of,
               a.institution, a.account_number
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        JOIN accounts a ON a.id = v.account_id
        WHERE v.investor_id = %s AND v.instrument_id = %s
        LIMIT 1
        """,
        (investor_id, instrument_id),
    )
    if holding is None:
        raise HTTPException(status_code=404, detail="You do not hold that.")

    result: dict = {
        "holding": holding,
        "drawdown": None,
        "narrative": None,
        "record": None,
        "holdings_xray": None,
        "activity": None,
        "company": None,
        "measures": None,
        "lenses": None,
        "verdict": None,
        "quote": None,
        # Computed below rather than left None. The equity path already gets
        # these; the fund path built a separate dict that set them to None and
        # never looked, so every risk-adjusted figure on a fund card was blank
        # while the service computed them correctly on request.
        "ratios": _ratios_for(instrument_id, holding),
        "demands": None,
        "stretches": None,
        "if_you_had": None,
        "dna": None,
        "odds": None,
        "horizon": None,
        "outlook": None,
        "unavailable": [],
    }

    # Ours: the worst fall this fund has had, from prices we hold and can check.
    try:
        result["drawdown"] = navs.drawdown(instrument_id)
    except Exception as err:                                   # pragma: no cover
        log.warning("drawdown failed for %s: %s", instrument_id, err)

    # Ours: how it sits against its category.
    for fund in analysis.fund_quality(investor_id)["funds"]:
        if fund["instrument_id"] == instrument_id:
            result["record"] = fund
            break


    # A share, rather than a fund.
    #
    # The comparisons are the point. "P/E 58" tells a reader nothing; "58,
    # against a median of 34 for capital goods" tells them where it sits. What
    # is deliberately absent is the word "expensive": whether 58 is too much
    # depends on what you expect the company to earn, which is a judgement, and
    # making it here would be the same overreach as a risk score.
    if holding["asset_class"] == "equity":
        return _equity_detail(investor_id, instrument_id, holding, result)

    code = holding.get("native_code")
    if not (code or "").isdigit():
        result["unavailable"].append(
            "We have not matched this to a published scheme, so there is no "
            "record of how it has done."
        )
        return result

    # Theirs: the prose, and what the fund holds.
    #
    # Each is optional. A fund the service cannot describe should leave the
    # rest of the card working rather than failing the whole request.
    try:
        story = dataservice.fund_story(code)
        narrative = story.get("narrative") or {}
        # Their `story` field arrives as a single-element list in some
        # responses and a string in others. Both mean the same thing.
        cleaned = {}
        for key, value in narrative.items():
            # `suits` arrives as a list of fragments that read as one run-on
            # sentence when joined with a space: "an investor who can watch a
            # 79% fall without selling systematic monthly investors". They are
            # separate answers to "who is this for", so they stay separate.
            if isinstance(value, list):
                parts = [str(v).strip() for v in value if str(v).strip()]
                value = parts if key == "suits" else " ".join(parts)
            if not value:
                continue
            if isinstance(value, list):
                cleaned[key] = value
                continue

            text = str(value).strip()
            # Their category comparison emits "ranking None of None Direct
            # plans" when it has no rank. A sentence naming its own missing
            # data is worse than one that stops early.
            text = _drop_empty_clauses(text)
            if text:
                cleaned[key] = text
        result["narrative"] = cleaned or None
        if not cleaned:
            result["unavailable"].append("No written record for this fund yet.")
    except dataservice.NotAvailable as err:
        result["unavailable"].append(str(err))
    except dataservice.DataServiceError as err:
        log.warning("fund_story failed for %s: %s", code, err)
        result["unavailable"].append("The fund research service did not answer.")

    try:
        xray = dataservice.holdings_xray(code)
        coverage = xray.get("coverage") or {}
        # A disclosure with no weights tells us nothing about what the fund is
        # concentrated in. Saying so beats rendering a list of zeroes.
        if coverage.get("equity_wt_pct") in (0, None) and not any(
                (h.get("weight_pct") or 0) > 0 for h in (xray.get("top_holdings") or [])):
            result["unavailable"].append(
                "This fund house publishes its holdings without percentages, so "
                "we cannot show what it is concentrated in."
            )
        else:
            result["holdings_xray"] = xray
    except dataservice.NotAvailable:
        result["unavailable"].append("No published holdings for this fund yet.")
    except dataservice.DataServiceError as err:
        log.warning("holdings_xray failed for %s: %s", code, err)

    # What the manager did between two disclosures.
    #
    # The only part of a fund that shows a decision rather than a position.
    # Everything else here describes what somebody holds; this describes what
    # the person managing their money chose to do with it.
    #
    # Needs two disclosures, so it works for about one fund in eight today --
    # ICICI and Nippon have depth in the vault, most AMCs have one month or
    # none. The service says so in a sentence written for a reader, which is
    # passed straight through.
    try:
        moves = dataservice.activity(code, months=6)
        if moves.get("computable"):
            result["activity"] = moves
        elif moves.get("note"):
            result["unavailable"].append(str(moves["note"]))
    except dataservice.NotAvailable:
        pass
    except dataservice.DataServiceError as err:
        log.warning("activity failed for %s: %s", code, err)

    # Three more the research service computes that we do not.
    #
    # Each is optional and each failure is silent: a fund the service cannot
    # describe should leave the rest of the card intact rather than failing the
    # whole request. Collected here rather than in three try blocks because the
    # handling is identical.
    extras = (
        ("demands", dataservice.mf_behaviour,
         "what this fund asks of whoever holds it"),
        ("stretches", dataservice.mf_stayed,
         "what holders had to sit through to earn its returns"),
        ("if_you_had", dataservice.mf_whatif,
         "what a monthly amount would actually have become"),
        ("dna", dataservice.fund_dna,
         "what kind of fund this actually is"),
        ("odds", dataservice.probability,
         "how often holding this has worked out"),
        ("horizon", dataservice.horizon,
         "how long you needed to hold it"),
        ("outlook", dataservice.forward_outlook,
         "what it looks like from here"),
    )
    for key, fetch, description in extras:
        try:
            payload = fetch(code)
            # Their endpoints answer `computable: false` with a sentence
            # written for a reader rather than an error. Where that happens the
            # sentence is worth more than the absence.
            if payload.get("computable") is False:
                if payload.get("note"):
                    result["unavailable"].append(str(payload["note"]))
                continue
            if payload.get("error"):
                continue
            result[key] = payload
        except dataservice.NotAvailable:
            continue
        except dataservice.DataServiceError as err:
            log.warning("%s failed for %s: %s", key, code, err)

    return result
