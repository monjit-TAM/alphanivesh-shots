"""The guide: what to do about this portfolio, in order.

The dashboard answers seventeen questions well and leaves the reader to
assemble them. This is the assembly -- one argument rather than a set of
findings, in four movements:

    where you stand
    what is wrong with it
    what to do first, and why that first
    what we could not see

The fourth is what keeps it honest. Every tool of this kind can produce a
confident plan; the difference is whether it says which parts of the picture
were missing when it did.

Nothing here computes anything new. It orders and connects what the rest of
the service already knows, which is the whole job -- a reader given seventeen
true statements and no order is not much better off than one given none.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException

from .. import db
from ..services import (analysis, auth, behaviour, dataservice, findings, i18n,
                        ledger,
                        market,
                        profile as profile_service, rebalance,
                        style as style_service, wealth)
from .auth import current_user

log = logging.getLogger("alphanivesh.guide")

router = APIRouter(prefix="/api/guide", tags=["Guide"])


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


@router.get("/{investor_id}", summary="What to do about this portfolio, in order")
def guide(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    summary = wealth.net_worth(investor_id)
    if not summary["positions"]:
        return {"empty": True,
                "why": "There is nothing here yet. Bring in a statement or a "
                       "spreadsheet and this will have something to say."}

    found = findings.for_investor(investor_id)
    drift = profile_service.drift(investor_id)
    trims = rebalance.suggestions(investor_id)
    them = profile_service.get_profile(investor_id) or {}

    how = behaviour.profile(investor_id)

    account = {
        "investor": wealth.get_investor(investor_id),
        "standing": _standing(investor_id, summary),
        "how_you_invest": how,
        "wrong": _what_is_wrong(found, drift),
        "first": _what_to_do_first(found, drift, trims, them, how, investor_id),
        "route": _route(investor_id, summary, them),
        "market": {**market.context(),
                   "for_you": _market_note(how, market.context())},
        "unseen": _what_we_could_not_see(investor_id, summary, them, found),
    }

    # The guide is the platform's account of somebody's position in its own
    # words. Recorded after assembly rather than before, so it cannot reference
    # values that do not exist yet -- which is exactly what the first attempt
    # did, and it broke the endpoint rather than the record.
    ledger.record(
        investor_id, "guide",
        said={k: account.get(k) for k in
              ("standing", "wrong", "first", "route", "market")},
        basis={"how_you_invest": account.get("how_you_invest"),
               "unseen": account.get("unseen"),
               "as_of": account.get("as_of")},
        surface="dashboard",
    )
    return account


def _standing(investor_id: str, summary: dict) -> dict:
    """Where the money is, and whether the choosing has been worth it."""
    from .dashboard import _benchmark, _headline

    headline = _headline(investor_id)
    benchmark = _benchmark(investor_id)

    sentence = i18n.say("guide.standing.opening",
                        value=_money(summary["total_value"]),
                        count=summary["positions"],
                        invested=_money(summary["invested_value"]))

    if headline.get("cagr_pct"):
        # Said as what it is. This is growth between two dates, not a return on
        # money that arrived over time -- and the gaps section says we cannot
        # compute the latter, so calling this one "your return" would read as a
        # contradiction two paragraphs later.
        sentence += " " + i18n.say("guide.standing.growth",
                                   rate=headline["cagr_pct"],
                                   years=headline["held_years"])

    if benchmark:
        if benchmark["ahead"]:
            sentence += " " + i18n.say(
                "guide.standing.ahead",
                yours=_money(benchmark["your_value"]),
                index=_money(benchmark["index_value"]),
                gain=_money(benchmark["difference"]))
        else:
            # Same correction as the ahead case: name the money being
            # compared, or the arithmetic looks wrong against the total the
            # reader can see on the same screen.
            sentence += (f" Of the ₹{_money(benchmark['your_value'])} we can "
                         f"trace the cost of, the same money in an index fund "
                         f"would be ₹{_money(benchmark['index_value'])} — "
                         f"₹{_money(abs(_d(benchmark['difference'])))} more. "
                         f"Over this stretch the choosing has cost rather than "
                         f"paid.")

    return {"reading": sentence, "headline": headline, "benchmark": benchmark}


def _what_is_wrong(found: dict, drift: Optional[dict]) -> dict:
    """The problems, largest first, without the ones that are not problems."""
    serious = [f for f in found["findings"] if f.get("severity") == "act"]
    watch = [f for f in found["findings"] if f.get("severity") == "watch"]

    if not serious and not watch and not (drift and not drift.get("in_line")):
        return {"reading": "Nothing here is urgent. The shape looks reasonable.",
                "problems": []}

    problems = []
    for f in (serious + watch)[:4]:
        problems.append({"headline": f["headline"], "detail": f["detail"],
                         "severity": f.get("severity")})

    if drift and not drift.get("in_line"):
        problems.append({
            "headline": f"{drift['worst_gap_pct']} points from the mix you set",
            "detail": ("Markets do the drifting. What you hold now is not what you "
                       "chose to hold, and the gap has grown without anybody "
                       "deciding it should."),
            "severity": "watch",
        })

    lead = problems[0]["headline"].rstrip(".")
    return {
        "reading": (f"The largest thing is that {lead[0].lower()}{lead[1:]}."
                    if len(problems) == 1
                    else f"{len(problems)} things stand out. The largest is that "
                         f"{lead[0].lower()}{lead[1:]}."),
        "problems": problems,
    }


def _what_to_do_first(found: dict, drift: Optional[dict],
                      trims: Optional[dict], them: dict,
                      how: Optional[dict] = None,
                      investor_id: Optional[str] = None) -> dict:
    """One thing, and why that one.

    Not a list. A reader given six actions does none of them, and the ordering
    is the part that takes judgement -- which is exactly what a list refuses to
    do.
    """
    # The unglamorous things come before the portfolio. Somebody one job loss
    # away from selling equity in a fall has a bigger problem than their
    # sector weighting, whatever the numbers say about the sector weighting.
    emergency = them.get("emergency_fund_months")
    if emergency is not None and _d(emergency) < 3:
        return {
            "do": "Build an emergency fund before touching anything else.",
            "why": ("You have about "
                    f"{emergency} month{'s' if _d(emergency) != 1 else ''} of "
                    "expenses set aside. Until that is closer to six, a job gap or "
                    "a medical bill means selling investments at whatever price the "
                    "market happens to be offering — which is usually a bad one, "
                    "because bad markets and bad personal news arrive together."),
            "before": "Any rebalancing, any fund switching, any of it.",
            "kind": "foundation",
        }

    # What somebody is already doing changes what is worth telling them.
    #
    # Somebody putting money in every month through a falling market has solved
    # the problem most people fail at, and the useful thing to say is whether
    # the amount is enough -- not anything about timing, which they have
    # already answered by not trying to time it.
    #
    # Somebody investing occasionally has not solved it, and the single most
    # valuable thing anybody could tell them is to stop deciding each month.
    style = ((how or {}).get("style") or {}).get("style")
    nerve = (how or {}).get("nerve") or {}

    if style in ("occasional", "sporadic"):
        purchases = ((how or {}).get("style") or {}).get("purchases")
        return {
            "do": "Set up a standing instruction.",
            "why": (f"Your money goes in when you decide to put it in \u2014 "
                    f"{purchases} times in the period we can see. That makes every "
                    f"month a decision, and the months hardest to decide in are "
                    f"the ones where units are cheapest. A standing instruction "
                    f"removes the decision, which is the whole of its value."),
            "before": ("Worth doing before anything about which funds to hold: "
                       "how consistently money goes in matters more than which "
                       "fund it goes into."),
            "kind": "habit",
        }

    now = found.get("worth_doing_now") or []
    if now:
        first = now[0]
        # A finding's headline describes a state -- "everything you hold moves
        # with the market" -- and this section has to say what to do about it.
        # The verb turns the observation into an instruction, which is the
        # difference between a dashboard and a guide.
        verb = first.get("action_verb") or "Look at"
        action = {
            "do": f"{verb}: {first['headline']}",
            "observation": first["headline"],
            "why": first["detail"],
            "before": first.get("why_this_order"),
            "kind": "portfolio",
        }
        # Where the finding is about concentration and we have a shortlist, name
        # the holdings -- "reduce equity" is arithmetic, "these three" is the work.
        if trims and trims.get("candidates"):
            action["candidates"] = trims["candidates"][:3]
            action["tax_note"] = ("Selling has a tax cost, shown against each. "
                                  "The cheapest to exit is not always the one "
                                  "worth exiting.")
        # Somebody still contributing to a regular plan has a first move that
        # costs nothing: point the next instalment at the direct plan. It is a
        # smaller saving than switching and a better decision, and it is
        # invisible unless you know they are still investing.
        # Two findings cover commission -- the older drag calculation and the
        # newer per-fund one -- and either should lead to the same first move
        # for somebody still contributing.
        if (first.get("code") in ("regular_plans", "commission_drag")
                and style in ("monthly", "frequent")):
            from ..services import plans as plan_service
            try:
                redirect = plan_service.redirect_future(investor_id)
            except Exception:
                redirect = None
            if redirect:
                action["do"] = "Send next month's instalment to the direct plan."
                action["why"] = redirect["reading"]
                action["before"] = redirect["why_this_first"]
                action["redirect"] = redirect
                action["then"] = first["headline"]

        # Where the habit is already sound, say so before the criticism.
        # Leading a disciplined investor with a list of faults reads as though
        # nothing they did counted.
        if style == "monthly" and nerve.get("held_nerve"):
            action["standing"] = (
                "Before any of this: the monthly instalments are the part that "
                "matters most and they are already in place. What follows is "
                "worth tidying, not worth disrupting them for.")
        return action

    if drift and not drift.get("in_line"):
        # Only classes there was a plan for. lines[0] picked whichever came
        # first, which on a real portfolio was a holding with no target at all
        # -- "against the None% you set", an accusation about a choice nobody
        # made. The fourth place this same mistake lived.
        planned = [line for line in drift["lines"]
                   if not line.get("never_planned") and line.get("target_pct")]
        worst = max(planned,
                    key=lambda line: abs(_d(line.get("gap_pct"))),
                    default=None)
        if worst:
            return {
                "do": (f"Bring {worst['asset_class'].replace('_', ' ')} back "
                       f"towards your target."),
                "why": (f"It is {worst['actual_pct']}% of the portfolio against "
                        f"the {worst['target_pct']}% you set."),
                "kind": "portfolio",
            }

    return {"do": "Nothing, for now.",
            "why": "Nothing here is worth the cost of acting on it.",
            "kind": "none"}


def _route(investor_id: str, summary: dict, them: dict) -> Optional[dict]:
    """Whether the goal is reachable, and what closes the gap if not.

    Needs a goal to say anything. Where somebody has not set one this returns
    the question rather than inventing a target for them.
    """
    goals = db.fetch_all(
        """
        SELECT name, target_amount, target_date, monthly_contribution
        FROM goals WHERE investor_id = %s AND target_amount > 0
        ORDER BY target_date LIMIT 1
        """,
        (investor_id,),
    )
    if not goals:
        return {"asked": True,
                "reading": ("You have not told us what the money is for. A goal "
                            "turns 'is this enough' from a feeling into a "
                            "calculation.")}

    goal = goals[0]
    years = None
    if goal["target_date"]:
        years = max(1, round((goal["target_date"] - date.today()).days / 365.25, 1))

    payload = {
        "target_amount": float(_d(goal["target_amount"])),
        "years": years or 10,
        "monthly": float(_d(goal["monthly_contribution"])),
        "existing_corpus": float(_d(summary["total_value"])),
    }
    for key, column in (("monthly_income", "monthly_income"),
                        ("monthly_expense", "monthly_expenses"),
                        ("dependents", "dependents"),
                        ("emergency_months", "emergency_fund_months")):
        value = them.get(column)
        if value is not None:
            payload[key] = float(_d(value))
    if them.get("date_of_birth"):
        payload["age"] = (date.today() - them["date_of_birth"]).days // 365

    try:
        result = dataservice.plan(payload)
    except dataservice.DataServiceError as err:
        log.warning("plan failed for %s: %s", investor_id, err)
        return None

    # The allocation the service suggests assumes the foundations are in place.
    # Where they are not, that is said here rather than left to contradict the
    # note sitting beside it.
    caution = None
    emergency = them.get("emergency_fund_months")
    if emergency is not None and _d(emergency) < 6 and result.get("allocation"):
        caution = ("The mix below assumes you can leave it alone through a bad "
                   f"year. With {emergency} months of expenses set aside, a job "
                   "gap would force selling into whatever the market is doing. "
                   "Build the runway first; the allocation still applies after.")

    return {
        "goal": goal["name"],
        "target": str(_d(goal["target_amount"])),
        "years": years,
        "conversation": result.get("conversation"),
        "projection": result.get("projection"),
        "levers": result.get("levers"),
        "allocation": result.get("allocation"),
        "life_notes": result.get("life_notes"),
        "surplus_note": result.get("surplus_note"),
        "caution": caution,
        "disclaimer": result.get("disclaimer"),
    }



def _market_note(how: Optional[dict], context: dict) -> Optional[str]:
    """What the market's position means for this particular investor.

    For somebody on a standing instruction it means nothing they need to act
    on, and saying so is more useful than the number: the whole point of the
    arrangement is that it invests without asking how the market looks.

    For somebody choosing their moments it is the context those choices are
    made in, which is different from a recommendation about them.
    """
    if not context.get("readable"):
        return None

    position = context["position"]
    style = ((how or {}).get("style") or {}).get("style")
    off_peak = abs(_d(position["off_peak_pct"]))

    if style == "monthly":
        return (f"The market is {off_peak:.0f}% off its high. For you that is "
                f"information rather than a decision \u2014 the instalments buy "
                f"more units at lower prices without anybody having to judge "
                f"whether the price is low enough, which is the point of them.")

    followed = context.get("followed") or {}
    if followed.get("countable"):
        return (f"{position['reading']} {followed['reading']} "
                f"That is what has followed, counted from the record. It is not "
                f"a forecast, and there is not one here.")
    return position["reading"]


def _what_we_could_not_see(investor_id: str, summary: dict, them: dict,
                           found: dict) -> dict:
    """The gaps, named.

    Any tool can produce a confident plan. What separates one worth trusting is
    whether it says which parts of the picture were missing when it made it.
    """
    gaps = []

    returns = wealth.returns(investor_id)
    if returns.get("xirr_unavailable_reason"):
        gaps.append({
            "what": "What you actually earned on the money as it went in",
            "why": (f"The growth figure above measures value between two dates. What "
                    f"it cannot measure is the return on money that arrived in "
                    f"instalments, which is the number that tells you whether the "
                    f"investing worked. That needs the purchases, and we hold "
                    f"{returns.get('transaction_coverage_pct', '0')}% of them."),
            "fix": "Import an older statement.",
        })

    sectors = analysis.sector_exposure(investor_id)
    coverage = _d(sectors.get("attributed_share_pct"))
    if coverage < 80:
        gaps.append({
            "what": "What your funds actually own",
            "why": (f"We can see through to the companies behind {coverage:.0f}% of "
                    f"your money. Several fund houses publish holdings without "
                    f"percentages, so their funds cannot be counted through."),
            "fix": None,
        })

    missing = [column for column, label in (
        ("monthly_income", "what you earn"),
        ("monthly_expenses", "what you spend"),
        ("date_of_birth", "your age"),
        ("emergency_fund_months", "your emergency fund"),
    ) if them.get(column) is None]
    if missing:
        gaps.append({
            "what": "Whether this portfolio suits you",
            "why": ("A portfolio is only right or wrong relative to the person "
                    "holding it, and we do not know "
                    + ", ".join(label for column, label in (
                        ("monthly_income", "what you earn"),
                        ("monthly_expenses", "what you spend"),
                        ("date_of_birth", "your age"),
                        ("emergency_fund_months", "your emergency fund"))
                        if column in missing) + "."),
            "fix": "Tell us about yourself.",
        })

    if not db.fetch_one("SELECT 1 FROM target_allocations WHERE investor_id = %s LIMIT 1",
                        (investor_id,)):
        gaps.append({
            "what": "Whether the shape is what you intended",
            "why": ("You have not said what mix you are aiming for, so we can "
                    "report what you hold but not whether it is what you meant "
                    "to hold."),
            "fix": "Set a target mix.",
        })

    if not style_service.get_style(investor_id):
        suggested = style_service.infer(investor_id)
        gaps.append({
            "what": "Which readings to trust when they disagree",
            "why": ("Every holding shows a value, growth and quantamental call, "
                    "and they will not always agree. Which one is yours depends "
                    "on how you invest, and you have not said."
                    + (f" Your holdings suggest {suggested['suggests']}."
                       if suggested and suggested.get("suggests") else "")),
            "fix": "Say how you invest.",
        })

    return {
        "gaps": gaps,
        "reading": ("We could see all of it." if not gaps else
                    f"{len(gaps)} things we could not see, and they change what "
                    f"the rest of this is worth."),
    }


def _money(value: Any) -> str:
    """Indian grouping, no decimals."""
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits
