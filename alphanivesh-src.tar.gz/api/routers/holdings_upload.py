"""Bringing in a file of holdings.

Two steps on purpose. The first reads the file and says what it found, what it
resolved and what it could not; nothing is written. The second commits the rows
the person confirmed.

The alternative -- parse and import in one go -- is faster and quietly wrong.
A file of forty holdings gets checked by nobody, so a row resolved to the wrong
company sits there being priced as a different business until somebody notices
the valuation is odd, which could be months.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from ..services import auth, holdings_file, manual, wealth
from .auth import current_user

router = APIRouter(prefix="/api/holdings-file", tags=["Holdings file"])

MAX_BYTES = 8 * 1024 * 1024
MAX_ROWS = 500


def _permitted(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")



def _resolve_investor(user: dict, investor_id: Optional[str]) -> str:
    """Which investor these holdings belong to.

    A statement carries its own identity -- a name, a PAN, folio numbers -- so
    importing one can work out whose it is. A spreadsheet of tickers carries
    none of that, so it attaches to an investor already on the account.

    Where the person has one, that is the answer and asking would be noise.
    Where they have several, the page has to say which.
    """
    if investor_id:
        if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
            raise HTTPException(status_code=404, detail="No such investor.")
        return investor_id

    scope = auth.visible_investor_ids(user)
    if scope is not None and not scope:
        mine = []
    else:
        mine = wealth.list_investors(limit=3, only_ids=scope)

    if not mine:
        raise HTTPException(
            status_code=400,
            detail="Bring in a statement first, or add a holding by hand. A "
                   "spreadsheet of tickers does not say whose holdings they are.")
    if len(mine) > 1:
        raise HTTPException(
            status_code=400,
            detail="You have more than one person on this account. Open the one "
                   "you mean from your wealth page, then bring the file in from there.")
    return mine[0]["id"]


@router.post("/preview", summary="Read a file and say what is in it")
@router.post("/{investor_id}/preview", include_in_schema=False)
async def preview(file: UploadFile = File(...),
                  asset_class: str = Form("equity"),
                  investor_id: Optional[str] = None,
                  user: dict = Depends(current_user)) -> dict:
    """Parse, resolve, and report. Nothing is written."""
    investor_id = _resolve_investor(user, investor_id)

    content = await file.read()
    if len(content) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="That file is larger than we can read.")

    try:
        parsed = holdings_file.parse(content, file.filename or "")
    except holdings_file.FileUnreadable as err:
        raise HTTPException(status_code=400, detail=str(err))

    if len(parsed.rows) > MAX_ROWS:
        raise HTTPException(
            status_code=400,
            detail=f"That file has {len(parsed.rows)} rows; we read up to {MAX_ROWS} at once.")

    rows: list[dict] = []
    counts = {"resolved": 0, "ambiguous": 0, "unknown": 0}

    for index, row in enumerate(parsed.rows):
        verdict = manual.resolve_for_import(row.identifier, asset_class)
        counts[verdict["status"]] = counts.get(verdict["status"], 0) + 1
        rows.append({
            "line": index,
            "identifier": row.identifier,
            "quantity": str(row.quantity) if row.quantity is not None else None,
            "price": str(row.price) if row.price is not None else None,
            "when": row.when.isoformat() if row.when else None,
            "status": verdict["status"],
            "match": verdict.get("match"),
            "candidates": verdict.get("candidates", []),
            "why": verdict.get("why"),
        })

    return {
        "filename": file.filename,
        "columns_found": parsed.columns_found,
        "header_row": parsed.header_row,
        "sheet": parsed.sheet,
        "skipped": parsed.skipped,
        "counts": counts,
        "rows": rows,
        # Said plainly, because a file that half-imported without saying so is
        # worse than one that refused.
        "summary": _summarise(counts),
    }


def _summarise(counts: dict) -> str:
    resolved = counts.get("resolved", 0)
    unsure = counts.get("ambiguous", 0)
    unknown = counts.get("unknown", 0)

    if not (unsure or unknown):
        return f"All {resolved} holdings recognised."
    parts = [f"{resolved} recognised"]
    if unsure:
        parts.append(f"{unsure} we are not sure about")
    if unknown:
        parts.append(f"{unknown} we could not find")
    return ", ".join(parts) + "."


class ConfirmedRow(BaseModel):
    identifier: str
    # Where the person chose between candidates, this is what they picked.
    isin: Optional[str] = None
    symbol: Optional[str] = None
    name: Optional[str] = None
    quantity: Optional[Decimal] = None
    price: Optional[Decimal] = None
    when: Optional[date] = None


class Commit(BaseModel):
    asset_class: str = "equity"
    rows: list[ConfirmedRow]


@router.post("/commit", summary="Record the rows that were confirmed")
@router.post("/{investor_id}/commit", include_in_schema=False)
def commit(body: Commit, investor_id: Optional[str] = None,
           user: dict = Depends(current_user)) -> dict:
    """Write the confirmed rows as holdings.

    Only what the person accepted. A row they left unresolved is left out, and
    they are told how many -- an import that silently drops rows teaches people
    not to trust the total.
    """
    investor_id = _resolve_investor(user, investor_id)
    if not body.rows:
        raise HTTPException(status_code=400, detail="Nothing to record.")

    added: list[dict] = []
    failed: list[dict] = []

    for row in body.rows:
        quantity = row.quantity or Decimal(0)
        price = row.price
        if quantity <= 0:
            failed.append({"identifier": row.identifier, "why": "no quantity"})
            continue

        # A holdings file gives what was paid, not what it is worth now. The
        # cost is what we know; the current value gets filled in when prices
        # are next fetched, and until then cost is the honest placeholder.
        invested = (price * quantity) if price else None

        values: dict[str, Any] = {
            "name": row.name or row.identifier,
            "quantity": str(quantity),
            "current_value": str(invested) if invested else "0",
            "invested_value": str(invested) if invested else None,
            # What was paid per unit, kept as its own figure. The total can be
            # derived from it but not the other way round once a position is
            # added to, and it is what the buy price column of the file said.
            "avg_cost": str(price) if price else None,
            "as_of": (row.when or date.today()).isoformat(),
        }
        if row.isin:
            values["isin"] = row.isin
        if row.symbol:
            values["symbol"] = row.symbol
        if price:
            values["buy_price"] = str(price)
        if row.when:
            values["buy_date"] = row.when.isoformat()

        try:
            added.append(manual.add_holding(investor_id, body.asset_class, values))
        except ValueError as err:
            failed.append({"identifier": row.identifier, "why": str(err)})

    # Price them straight away. A file gives cost, not value, and a portfolio
    # that shows what somebody paid as though it were what they have is wrong
    # by however much the market has moved since -- which for a holding bought
    # two years ago is the whole point of looking.
    priced = None
    if added:
        try:
            from ..services import navs
            priced = navs.price_equities(investor_id)
        except Exception as err:                                 # pragma: no cover
            # Worth having the holdings at cost rather than not at all.
            priced = {"priced": 0, "why": str(err)}

    return {
        "added": len(added),
        "failed": failed,
        "priced": priced,
        "holdings": added,
        "note": (f"{len(added)} recorded"
                 + (f", {len(failed)} could not be" if failed else "")
                 + (f", {priced['priced']} priced at today's market"
                    if priced and priced.get("priced") else "") + "."),
    }
