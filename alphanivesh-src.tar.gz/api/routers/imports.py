"""Bringing statements in, by whichever route suits the person.

Four ways in, and they exist because people arrive in different states. Someone
who already has the PDF should not be made to request another. Someone who does
not know where it is should not be told to go and find it. Someone who would
rather we looked in their mailbox should be able to say so, and to change their
mind afterwards.

All four converge on the same mapper, so what lands in the canonical model does
not depend on how it got here.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import RedirectResponse
from pydantic import BaseModel

from .. import db
from ..services import casparser, statement_mapper
from .auth import current_user

router = APIRouter(prefix="/api/import", tags=["Import"])

MAX_BYTES = 12 * 1024 * 1024
PAN_PATTERN = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# A registrar takes a few minutes to send a statement. Asking again inside that
# window produces a duplicate email, not a faster answer.
REQUEST_COOLDOWN_MINUTES = 10


def _hash_pan(pan: str) -> str:
    return hashlib.sha256(pan.strip().upper().encode()).hexdigest()


def _record(user_id: str, route: str, **fields) -> str:
    columns = ["user_id", "route"] + list(fields)
    values = [user_id, route] + list(fields.values())
    placeholders = ", ".join(["%s"] * len(values))
    row = db.fetch_one(
        f"INSERT INTO statement_imports ({', '.join(columns)}) "
        f"VALUES ({placeholders}) RETURNING id",
        tuple(values),
    )
    return row["id"]


def _finish(import_id: str, result: statement_mapper.MappingResult) -> None:
    db.fetch_one(
        """
        UPDATE statement_imports
        SET status='mapped', investor_id=%s, accounts_created=%s, holdings_imported=%s,
            holdings_quarantined=%s, transactions_imported=%s, notes=%s::jsonb,
            completed_at=now()
        WHERE id=%s RETURNING id
        """,
        (result.investor_id, result.accounts, result.holdings, result.quarantined,
         result.transactions, json.dumps(result.notes), import_id),
    )


def _abandon(import_id: str, message: str, status: int = 400):
    db.fetch_one(
        "UPDATE statement_imports SET status='failed', error_detail=%s, "
        "provider_message=%s, completed_at=now() WHERE id=%s RETURNING id",
        (message, message, import_id),
    )
    raise HTTPException(status_code=status, detail=message)


def _ingest(payload: dict, user_id: str, import_id: str) -> dict:
    """Map a parsed statement and close out its import record."""
    try:
        result = statement_mapper.map_statement(payload, user_id)
    except PermissionError as err:
        _abandon(import_id, str(err), status=409)
    except Exception:
        _abandon(import_id,
                 "We read your statement but could not file it. We have kept it and "
                 "will look into this.", status=500)

    _finish(import_id, result)
    return {
        "import_id": import_id,
        "investor_id": result.investor_id,
        "accounts": result.accounts,
        "holdings": result.holdings,
        "quarantined": result.quarantined,
        "notes": result.notes,
    }


# ---------------------------------------------------------------------------
# 1. The person already has the file
# ---------------------------------------------------------------------------


@router.post("/statement", summary="Upload a statement PDF")
async def upload_statement(
    file: UploadFile = File(...),
    password: str = Form(""),
    user: dict = Depends(current_user),
) -> dict:
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="That file was empty.")
    if len(raw) > MAX_BYTES:
        raise HTTPException(status_code=413,
                            detail="That file is larger than we expect a statement to be.")

    import_id = _record(
        user["id"], "file_upload", status="parsing", original_filename=file.filename,
        file_size_bytes=len(raw), file_sha256=hashlib.sha256(raw).hexdigest(),
        provider="casparser",
    )

    try:
        parsed = casparser.parse_statement(raw, password, file.filename or "statement.pdf")
    except casparser.CASParserError as err:
        # str(err) carries the provider's explanation. Passing it through means
        # the person is told what to fix rather than that something went wrong.
        _abandon(import_id, str(err), status=503 if err.retryable else 400)

    return _ingest(parsed, user["id"], import_id)


# ---------------------------------------------------------------------------
# 2. Ask the registrar to send one
# ---------------------------------------------------------------------------


class StatementRequest(BaseModel):
    pan: str
    email: str


@router.post("/request", summary="Ask CAMS and KFintech to email a statement")
def request_statement(body: StatementRequest, user: dict = Depends(current_user)) -> dict:
    pan = body.pan.strip().upper()
    email = body.email.strip().lower()

    if not PAN_PATTERN.match(pan):
        raise HTTPException(status_code=400,
                            detail="That does not look like a PAN. Ten characters, like ABCDE1234F.")
    if not EMAIL_PATTERN.match(email):
        raise HTTPException(status_code=400,
                            detail="Please give the email address registered with your folios.")

    pan_hash = _hash_pan(pan)
    recent = db.fetch_one(
        """
        SELECT requested_at, pdf_password FROM statement_requests
        WHERE pan_hash = %s AND requested_at > now() - interval '%s minutes'
        ORDER BY requested_at DESC LIMIT 1
        """,
        (pan_hash, REQUEST_COOLDOWN_MINUTES),
    )
    if recent:
        return {
            "status": "already_requested",
            "requested_at": recent["requested_at"],
            "pdf_password": recent["pdf_password"],
            "message": ("We asked for this statement a few minutes ago. It usually "
                        "arrives within five minutes — check your inbox, and your spam folder."),
        }

    # The registrar encrypts the PDF. We choose the password and tell the person
    # what it is, rather than leaving them to guess at one they set long ago.
    import secrets
    password = "Nivesh" + str(secrets.randbelow(9000) + 1000)

    try:
        casparser.generate_statement(pan, email, password)
        status, message = "requested", None
    except casparser.CASParserError as err:
        status, message = "failed", str(err)

    db.fetch_one(
        """
        INSERT INTO statement_requests (user_id, pan_hash, pan_last4, email, pdf_password,
                                        status, provider_message)
        VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id
        """,
        (user["id"], pan_hash, pan[-4:], email, password, status, message),
    )

    if status == "failed":
        raise HTTPException(status_code=502, detail=message)

    return {
        "status": "requested",
        "pdf_password": password,
        "message": ("CAMS and KFintech will email your statement to " + email +
                    ". It usually takes about five minutes. Come back and upload it here, "
                    "or connect your mailbox and we will collect it ourselves."),
    }


# ---------------------------------------------------------------------------
# 3. Fetch it from the depository
# ---------------------------------------------------------------------------


class DepositoryStart(BaseModel):
    pan: str
    bo_id: str
    dob: str          # yyyy-mm-dd, as held against the demat account


class DepositoryVerify(BaseModel):
    fetch_id: str
    otp: str


@router.post("/depository/start", summary="Ask CDSL to send an OTP")
def depository_start(body: DepositoryStart, user: dict = Depends(current_user)) -> dict:
    pan = body.pan.strip().upper()
    bo_id = re.sub(r"\D", "", body.bo_id or "")
    dob = (body.dob or "").strip()

    if not PAN_PATTERN.match(pan):
        raise HTTPException(status_code=400,
                            detail="That does not look like a PAN. Ten characters, like ABCDE1234F.")
    if len(bo_id) != 16:
        raise HTTPException(status_code=400,
                            detail="The BO ID is sixteen digits. It is on a contract note, "
                                   "or in your broker's app.")
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", dob):
        raise HTTPException(status_code=400,
                            detail="Please give your date of birth as it appears on the demat account.")

    try:
        data = casparser.cdsl_request_otp(pan, bo_id, dob)
    except casparser.CASParserError as err:
        raise HTTPException(status_code=502 if err.retryable else 400, detail=str(err))

    fetch_id = db.fetch_one(
        """
        INSERT INTO depository_fetches (user_id, depository, provider_session, pan_last4)
        VALUES (%s, 'cdsl', %s, %s) RETURNING id
        """,
        (user["id"], data["session_id"], pan[-4:]),
    )["id"]

    return {
        "fetch_id": fetch_id,
        "status": "otp_sent",
        "message": "CDSL is sending a code to the mobile registered against your demat account.",
    }


@router.post("/depository/verify", summary="Hand CDSL the code and collect the statements")
def depository_verify(body: DepositoryVerify, user: dict = Depends(current_user)) -> dict:
    fetch = db.fetch_one(
        """
        SELECT id, provider_session, status, attempts, expires_at
        FROM depository_fetches WHERE id = %s AND user_id = %s
        """,
        (body.fetch_id, user["id"]),
    )
    if fetch is None:
        raise HTTPException(status_code=404, detail="That request has expired. Please start again.")
    if fetch["expires_at"] < datetime.now(timezone.utc):
        raise HTTPException(status_code=410, detail="That code has expired. Please start again.")
    if fetch["attempts"] >= 5:
        raise HTTPException(status_code=429,
                            detail="Too many attempts. Please start again.")

    db.fetch_one("UPDATE depository_fetches SET attempts = attempts + 1 WHERE id = %s RETURNING id",
                 (fetch["id"],))

    try:
        data = casparser.cdsl_verify_otp(fetch["provider_session"], body.otp)
    except casparser.CASParserError as err:
        raise HTTPException(status_code=400, detail=str(err))

    db.fetch_one("UPDATE depository_fetches SET status='verified', completed_at=now() "
                 "WHERE id=%s RETURNING id", (fetch["id"],))

    # CDSL hands statements back in one of three shapes: already parsed, a URL
    # to download, or the file itself. All three end up at the same mapper.
    totals = {"accounts": 0, "holdings": 0, "quarantined": 0}
    notes: list[str] = []
    investor_id = None

    for item in data.get("files") or []:
        payload = None
        if isinstance(item, dict) and (item.get("demat_accounts") or
                                       (item.get("data") or {}).get("demat_accounts")):
            payload = item if item.get("demat_accounts") else item["data"]
        else:
            url = item if isinstance(item, str) else (
                item.get("url") or item.get("file_url") or item.get("download_url"))
            if not url:
                continue
            try:
                payload = casparser.cdsl_parse(casparser.fetch_file(url))
            except casparser.CASParserError:
                continue

        if not payload:
            continue

        import_id = _record(user["id"], "depository_otp", status="parsed", provider="casparser")
        outcome = _ingest(payload, user["id"], import_id)
        investor_id = outcome["investor_id"] or investor_id
        totals["accounts"] += outcome["accounts"]
        totals["holdings"] += outcome["holdings"]
        totals["quarantined"] += outcome["quarantined"]
        notes.extend(outcome["notes"])

    if not totals["holdings"] and not totals["quarantined"]:
        raise HTTPException(status_code=422,
                            detail="CDSL accepted the code but sent nothing we could read.")

    return {"investor_id": investor_id, **totals, "notes": notes[:20]}


# ---------------------------------------------------------------------------
# 4. Look in their mailbox
# ---------------------------------------------------------------------------


@router.post("/inbox/connect", summary="Begin connecting a mailbox")
def inbox_connect(request: Request, provider: str = Query("gmail"),
                  user: dict = Depends(current_user)) -> dict:
    base = str(request.base_url).rstrip("/")
    try:
        data = casparser.inbox_connect(
            provider, f"{base}/api/import/inbox/callback", f"{user['id']}|{provider}"
        )
    except casparser.CASParserError as err:
        raise HTTPException(status_code=502, detail=str(err))
    return {"oauth_url": data["oauth_url"], "expires_in": data.get("expires_in")}


@router.get("/inbox/callback", include_in_schema=False)
def inbox_callback(inbox_token: str = Query(default=""), token: str = Query(default=""),
                   state: str = Query(default="")) -> RedirectResponse:
    """Where the provider sends the person back to.

    No session here: they are returning from an external site, so the only thing
    identifying them is the state we sent out.
    """
    value = inbox_token or token
    user_id, _, provider = state.partition("|")
    if not value or not user_id:
        return RedirectResponse("/upload.html?inbox=failed", status_code=302)

    details = casparser.inbox_status(value)

    db.fetch_one(
        """
        INSERT INTO inbox_connections (user_id, provider, email, inbox_token)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (user_id, provider) WHERE revoked_at IS NULL
        DO UPDATE SET inbox_token = EXCLUDED.inbox_token,
                      email = EXCLUDED.email,
                      connected_at = now()
        RETURNING id
        """,
        (user_id, provider or "gmail", details.get("email"), value),
    )
    return RedirectResponse("/upload.html?inbox=connected", status_code=302)


@router.get("/inbox/status", summary="Is a mailbox connected")
def inbox_status(user: dict = Depends(current_user)) -> dict:
    row = db.fetch_one(
        "SELECT provider, email, inbox_token, last_import_at FROM inbox_connections "
        "WHERE user_id = %s AND revoked_at IS NULL LIMIT 1",
        (user["id"],),
    )
    if row is None:
        return {"connected": False}

    details = casparser.inbox_status(row["inbox_token"])
    if details.get("requires_reconnect"):
        return {"connected": False, "needs_reconnect": True, "email": row["email"]}

    return {
        "connected": True,
        "provider": row["provider"],
        "email": details.get("email") or row["email"],
        "last_import_at": row["last_import_at"],
    }


@router.post("/inbox/disconnect", summary="Disconnect a mailbox")
def inbox_disconnect(user: dict = Depends(current_user)) -> dict:
    row = db.fetch_one(
        "SELECT id, inbox_token FROM inbox_connections WHERE user_id = %s AND revoked_at IS NULL",
        (user["id"],),
    )
    if row:
        # Revoke upstream first, but do not let a failure there stop us from
        # honouring the request locally.
        casparser.inbox_disconnect(row["inbox_token"])
        db.fetch_one("UPDATE inbox_connections SET revoked_at = now() WHERE id = %s RETURNING id",
                     (row["id"],))
    return {"disconnected": True}


@router.post("/inbox/import", summary="Collect statements from the connected mailbox")
def inbox_import(months: int = Query(12, ge=1, le=60),
                 user: dict = Depends(current_user)) -> dict:
    row = db.fetch_one(
        "SELECT id, inbox_token FROM inbox_connections WHERE user_id = %s AND revoked_at IS NULL",
        (user["id"],),
    )
    if row is None:
        raise HTTPException(status_code=400, detail="No mailbox is connected.")

    files, needs_reconnect = casparser.inbox_search_range(row["inbox_token"], months)
    if needs_reconnect:
        raise HTTPException(status_code=401,
                            detail="The mailbox connection has lapsed. Please connect it again.")
    if not files:
        return {"found": 0, "holdings": 0,
                "message": "We looked, but found no statements in that period."}

    totals = {"accounts": 0, "holdings": 0, "quarantined": 0}
    notes: list[str] = []
    investor_id = None

    for item in files:
        payload = item.get("data") if isinstance(item.get("data"), dict) else None
        if payload is None:
            content = casparser.inbox_download(row["inbox_token"], item)
            if not content:
                continue
            try:
                # Statements found this way carry the password the registrar set,
                # which the file listing tells us.
                payload = casparser.parse_statement(content, item.get("password", ""))
            except casparser.CASParserError as err:
                notes.append(f"{item.get('filename', 'A statement')}: {err}")
                continue

        import_id = _record(user["id"], "inbox_fetch", status="parsed",
                            original_filename=item.get("filename"), provider="casparser")
        try:
            outcome = _ingest(payload, user["id"], import_id)
        except HTTPException as err:
            notes.append(str(err.detail))
            continue

        investor_id = outcome["investor_id"] or investor_id
        totals["accounts"] += outcome["accounts"]
        totals["holdings"] += outcome["holdings"]
        totals["quarantined"] += outcome["quarantined"]
        notes.extend(outcome["notes"])

    db.fetch_one("UPDATE inbox_connections SET last_import_at = now() WHERE id = %s RETURNING id",
                 (row["id"],))

    return {"found": len(files), "investor_id": investor_id, **totals, "notes": notes[:20]}


# ---------------------------------------------------------------------------


@router.get("/history", summary="Statements you have brought in")
def history(user: dict = Depends(current_user)) -> dict:
    rows = db.fetch_all(
        """
        SELECT id, route, status, original_filename, holdings_imported,
               holdings_quarantined, error_detail, notes, created_at, completed_at
        FROM statement_imports WHERE user_id = %s
        ORDER BY created_at DESC LIMIT 25
        """,
        (user["id"],),
    )
    return {"count": len(rows), "imports": rows}
