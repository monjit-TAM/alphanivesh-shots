"""The adviser's edits, and what carried over."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import advisers, auth, judgement, professionals, wealth
from .auth import current_user

router = APIRouter(prefix="/api/judgement", tags=["Adviser judgement"])


def _may_edit(user: dict, investor_id: str) -> None:
    """Only somebody registered to advise changes advice.

    Checked against the registration on file rather than a role column, so a
    lapsed certificate takes the right away without anybody having to remember
    to. An MFD reaches this and is refused: distribution and advice are
    separate registrations and this platform does not blur them.

    An investor editing their own recommendations would make the record say
    their adviser advised something nobody advised, which is worse than not
    having the feature at all.
    """
    if wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    if (user or {}).get("role") == "admin":
        return

    standing = professionals.may_edit_advice((user or {}).get("id"))
    if not standing.get("may"):
        raise HTTPException(status_code=403, detail=standing.get("why"))


@router.get("/{investor_id}", summary="What the adviser has changed")
def current(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id):
        raise HTTPException(status_code=404, detail="No such investor.")
    live = judgement.overrides_for(investor_id)
    return {
        "count": len(live),
        "overrides": [{
            "code": code,
            "what": o["what"],
            "because": o["because"],
            "at": o["at"].isoformat(),
            "applies_until": (o["applies_until"].isoformat()
                              if o["applies_until"] else None),
        } for code, o in live.items()],
    }


@router.post("/{investor_id}", summary="Change, hold back or add advice")
def override(investor_id: str, payload: dict = Body(...),
             user: dict = Depends(current_user)) -> dict:
    _may_edit(user, investor_id)

    # An adviser can only edit into a relationship they hold.
    standing = advisers.may_advise(investor_id)
    if not standing.get("may") and (user or {}).get("role") != "admin":
        raise HTTPException(status_code=409, detail=standing.get("why"))

    try:
        return judgement.record_override(
            investor_id,
            payload.get("code") or "",
            payload.get("what") or "edited",
            because=payload.get("because") or "",
            engine_said=payload.get("engine_said"),
            adviser_said=payload.get("adviser_said"),
            said_digest=payload.get("said_digest"),
            by_user_id=(user or {}).get("id"))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.delete("/{investor_id}/{code}", summary="Withdraw an edit")
def withdraw(investor_id: str, code: str,
             user: dict = Depends(current_user)) -> dict:
    _may_edit(user, investor_id)
    judgement.withdraw(investor_id, code)
    return {"withdrawn": code}
