"""Which language, and the strings in it."""

from __future__ import annotations

from fastapi import APIRouter, Header, Query
from fastapi.responses import JSONResponse

from ..services import i18n

router = APIRouter(prefix="/api/language", tags=["Language"])


@router.get("", summary="The languages we have, and how complete each is")
def languages() -> dict:
    return {
        "languages": i18n.available(),
        "default": i18n.DEFAULT,
        "note": ("Completeness is counted; review is not the same thing. A "
                 "catalogue can be fully translated and entirely unchecked, "
                 "and a reader deserves to tell those apart."),
    }


@router.get("/{code}", summary="Every string in one language")
def strings(code: str,
            accept_language: str = Header(default=None)) -> JSONResponse:
    language = i18n.resolve(accept_language, code)
    spec = i18n.LANGUAGES.get(language, {})

    payload = {
        "language": language,
        "name": spec.get("name"),
        "own_name": spec.get("own_name"),
        "reviewed": spec.get("reviewed", False),
        "strings": i18n.catalogue(language) or i18n.catalogue(i18n.DEFAULT),
    }
    # Catalogues change on deploy, not per request.
    return JSONResponse(payload, headers={"Cache-Control": "public, max-age=600"})
