"""What somebody owes, and what it costs them."""

from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import auth, debts, wealth
from .auth import current_user

router = APIRouter(prefix="/api/liabilities", tags=["Liabilities"])


def _may(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="Everything owed, and what it means")
def for_investor(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return debts.for_investor(investor_id)


@router.get("/{investor_id}/net-worth", summary="Owned less owed")
def net_worth(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return debts.net_worth(investor_id)


@router.post("/{investor_id}", summary="Record something owed")
def add(investor_id: str, payload: dict = Body(...),
        user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)

    kind = payload.get("kind")
    outstanding = payload.get("outstanding")
    if not kind or outstanding is None:
        raise HTTPException(
            status_code=400,
            detail="kind and outstanding are both needed. A debt without a "
                   "balance cannot be weighed against anything.")
    try:
        result = debts.add(
            investor_id, kind, outstanding,
            rate_pct=payload.get("rate_pct"),
            monthly_emi=payload.get("monthly_emi"),
            lender=payload.get("lender"),
            ends_on=(date.fromisoformat(payload["ends_on"])
                     if payload.get("ends_on") else None),
            secured_against=payload.get("secured_against"),
            notes=payload.get("notes"))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))

    return {"added": result["id"], **debts.for_investor(investor_id)}


@router.put("/{investor_id}/{liability_id}", summary="Change one")
def update(investor_id: str, liability_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    debts.update(investor_id, liability_id, **payload)
    return debts.for_investor(investor_id)


@router.delete("/{investor_id}/{liability_id}", summary="Remove one")
def remove(investor_id: str, liability_id: str,
           user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    debts.remove(investor_id, liability_id)
    return debts.for_investor(investor_id)
