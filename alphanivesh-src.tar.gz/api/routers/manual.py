"""Holdings the investor records themselves."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..services import auth, manual, wealth
from .auth import current_user

router = APIRouter(prefix="/api/manual", tags=["Manual entry"])


def _permitted(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


class HoldingIn(BaseModel):
    asset_class: str
    # The fields differ by asset class, so the payload is open rather than a
    # fixed shape. The service validates against the form for that class.
    values: dict[str, Any]


@router.get("/forms", summary="What each kind of asset needs")
def forms(user: dict = Depends(current_user)) -> dict:
    """The shape of every asset class.

    Served rather than hard-coded into the page so that adding an asset class
    is a change in one place.
    """
    return {"forms": manual.forms()}


@router.get("/search", summary="Find an instrument by name")
def search(q: str, asset_class: str | None = None, investor_id: str | None = None,
           user: dict = Depends(current_user)) -> dict:
    """Typeahead for the entry form.

    Passing the investor means anything they already hold ranks first, which is
    what keeps one holding from becoming two.
    """
    if investor_id and not auth.may_see(user, investor_id):
        investor_id = None
    return {"results": manual.search_instruments(q, asset_class, investor_id)}


@router.get("/{investor_id}", summary="Holdings this investor entered themselves")
def listing(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    rows = manual.list_manual(investor_id)
    return {"count": len(rows), "holdings": rows}


@router.post("/{investor_id}", summary="Record a holding")
def create(investor_id: str, body: HoldingIn, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    try:
        return manual.add_holding(investor_id, body.asset_class, body.values)
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.delete("/{investor_id}/{instrument_id}", summary="Remove a holding you entered")
def remove(investor_id: str, instrument_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    if not manual.remove_holding(investor_id, instrument_id):
        raise HTTPException(status_code=404,
                            detail="We could not find that among the holdings you entered. "
                                   "Holdings that came from a statement cannot be removed here.")
    return {"removed": True}
