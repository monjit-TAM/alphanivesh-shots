"""Joining two records that are one person."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..services import auth, merge as merge_service
from .auth import current_user

router = APIRouter(prefix="/api/investors", tags=["Investors"])


class MergeRequest(BaseModel):
    keep_id: str
    absorb_id: str


@router.post("/merge/preview", summary="What merging these two would do")
def preview(body: MergeRequest, user: dict = Depends(current_user)) -> dict:
    for investor_id in (body.keep_id, body.absorb_id):
        if not auth.may_see(user, investor_id):
            raise HTTPException(status_code=404, detail="No such investor.")
    try:
        return merge_service.preview(body.keep_id, body.absorb_id)
    except merge_service.MergeRefused as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.post("/merge", summary="Merge two records into one")
def do_merge(body: MergeRequest, user: dict = Depends(current_user)) -> dict:
    try:
        return merge_service.merge(body.keep_id, body.absorb_id, user["id"])
    except merge_service.MergeRefused as err:
        raise HTTPException(status_code=400, detail=str(err))
