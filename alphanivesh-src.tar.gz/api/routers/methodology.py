"""How every figure on this platform is arrived at.

Written to be read by somebody who has to defend it. An adviser asked "why does
your tool say reduce" needs a better answer than "the model scored it 78", and
a compliance officer asked what the platform claims needs to see the claims
written down rather than inferred from screens.

Three things this deliberately does.

**It says where numbers come from rather than that they are accurate.** A
source and a method can be checked; an assurance cannot.

**It names what is estimated.** Commission rates are typical rather than each
scheme's own disclosure. Sector attribution covers the share of a portfolio we
can see through. Saying so costs nothing and is the difference between a
figure and a claim.

**And it says what the platform will not do.** No forecasts, no composite
scores, no reproducing an engine that already exists elsewhere in the group.
Those are decisions rather than gaps, and stating them stops somebody
helpfully filling them in later.
"""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/api/methodology", tags=["Methodology"])


METHOD = {
    "principle": (
        "Every number here traces to a stated rule applied to figures somebody "
        "can check. Where a rule involves judgement, the judgement is written "
        "down. Where a figure is estimated, it says so. Where something cannot "
        "be computed from what we hold, the platform says that rather than "
        "approximating it."
    ),

    "sections": [
        {
            "name": "Where the data comes from",
            "items": [
                {"what": "Fund prices",
                 "how": "AMFI's daily NAV publication, held locally — 122,610 "
                        "daily prices across the schemes our investors hold.",
                 "note": None},
                {"what": "Share prices",
                 "how": "The licensed market feed, through the group's shared "
                        "data service. Quotes are stored as snapshots so a "
                        "holding shows the same figure whether read alone or "
                        "summed with the rest.",
                 "note": None},
                {"what": "Company fundamentals",
                 "how": "2,329 listed companies, refreshed from the group's "
                        "fundamentals database.",
                 "note": None},
                {"what": "What funds hold",
                 "how": "Monthly SEBI portfolio disclosures, ingested per AMC.",
                 "note": "Coverage is partial. Several fund houses publish "
                         "holdings without percentages, and those funds cannot "
                         "be counted through to the companies underneath. Every "
                         "figure derived from this carries the share of the "
                         "portfolio it could see."},
                {"what": "The benchmark",
                 "how": "NIFTYBEES closing prices from April 2021 — 1,317 "
                        "trading days.",
                 "note": "Five years is one market cycle and a bit. It supports "
                         "a statement about what has happened and does not "
                         "support a claim about what is likely."},
                {"what": "Holdings",
                 "how": "Consolidated account statements, broker spreadsheets, "
                        "depository fetches, or entered by hand.",
                 "note": None},
            ],
        },
        {
            "name": "How a company is judged",
            "items": [
                {"what": "The verdict on a share",
                 "how": "From the group's rebalance engine: three pillars — "
                        "fundamental at 35%, momentum at 30%, technical at 35% "
                        "— combined against published thresholds. A total at or "
                        "above +25 is a Buy, at or below -25 a Sell. The "
                        "technical pillar uses RSI(14), MACD(12,26,9), the "
                        "50/200 moving-average crossover, Supertrend(10,3), OBV "
                        "and volume ratio across a 919-stock universe.",
                 "note": "The same engine produces the verdicts in the broker "
                         "reports and the group's other products. A share reads "
                         "the same everywhere, which is why this platform does "
                         "not compute a second opinion."},
                {"what": "Value, growth and quality",
                 "how": "Every ratio compared to the median of the company's own "
                        "sector, and reported as a count: better than the sector "
                        "on three of four measures, worse on one.",
                 "note": "Not a score. A count can be checked against the same "
                         "data by anybody who disagrees with it. This is shown "
                         "alongside the engine's verdict rather than competing "
                         "with it: the engine bands price-to-earnings across "
                         "every industry, and the sector figure is what stops "
                         "'expensive' being read as a fact about the company "
                         "rather than about the band it fell into."},
                {"what": "Company size",
                 "how": "Ranked by market capitalisation: the largest hundred "
                        "are large-cap, the next hundred and fifty mid-cap, the "
                        "rest small-cap.",
                 "note": "SEBI's own definition, so a fund and this platform "
                         "classify the same company the same way."},
            ],
        },
        {
            "name": "How a fund is judged",
            "items": [
                {"what": "Ranking",
                 "how": "Category rank on rolling three-year returns, computed "
                        "across every weekly-stepped three-year window in a "
                        "scheme's history — the median, the quartiles, how often "
                        "a window ended positive, and the worst there has been.",
                 "note": "Point-to-point returns flatter or damn a fund by the "
                         "luck of their endpoints. A distribution across every "
                         "window does not."},
                {"what": "What a fund demands",
                 "how": "Its deepest fall, how long recoveries took, how much it "
                        "swings year to year, and the share of one-year stretches "
                        "that ended positive.",
                 "note": "Read against what the holder has actually sustained, "
                         "from their own transaction record. A fund that demands "
                         "discipline suits somebody who has shown they have it."},
                {"what": "Untested records",
                 "how": "Where a fund's worst three-year stretch is strongly "
                        "positive, that is reported as a fund which has not "
                        "existed through a bad market rather than as a floor.",
                 "note": "A worst case of +30% a year is arithmetically correct "
                         "and tells a reader the opposite of the truth."},
            ],
        },
        {
            "name": "How the portfolio is measured",
            "items": [
                {"what": "Concentration",
                 "how": "The share in the largest holding, the largest five, and "
                        "an effective count — what the portfolio behaves like if "
                        "the holdings were equal.",
                 "note": None},
                {"what": "Sector exposure",
                 "how": "Direct shareholdings plus the companies inside each "
                        "fund, weighted by how much of the fund is held.",
                 "note": "Reported with the share of the portfolio it could see "
                         "through, since not every fund publishes weights."},
                {"what": "What a fall would cost",
                 "how": "Two figures. A beta-based estimate, and what the "
                         "holdings have each actually done in their worst "
                         "recorded stretch.",
                 "note": "Both are shown because the gap between them is the "
                         "point: correlations tighten in a crisis, and beta "
                         "understates the worst case for that reason."},
                {"what": "Against the index",
                 "how": "The same money, invested in NIFTYBEES on the same dates.",
                 "note": None},
                {"what": "Risk-adjusted returns",
                 "how": "Sharpe, Sortino, alpha, beta, up and down capture, "
                        "tracking error and information ratio, computed from "
                        "daily NAV history against NIFTYBEES. A risk-free rate "
                        "of 7% a year is assumed throughout.",
                 "note": "The risk-free rate is a choice rather than a fact and "
                         "it moves every one of these figures. Seven per cent is "
                         "what the group's other analyser uses, so the same fund "
                         "reads the same in a broker report as it does here. "
                         "Sortino is the one to read where it disagrees with "
                         "Sharpe: Sharpe penalises a sharp rise exactly as hard "
                         "as a sharp fall, which is not how anybody experiences "
                         "holding a fund."},
                {"what": "Capital gains",
                 "how": "Computed lot by lot through the group's tax service, "
                        "with the annual long-term exemption applied.",
                 "note": "Lots rather than positions, because units bought in "
                         "March and units bought in October are taxed "
                         "differently on the same day."},
                {"what": "Commission on regular plans",
                 "how": "The difference between a regular and a direct plan, "
                        "estimated from typical trail rates by category.",
                 "note": "Estimated. The exact figure is in each scheme's own "
                         "disclosure, which we do not hold — so treat the rupee "
                         "amounts as close rather than exact. The tax of "
                         "switching is computed from what was actually paid."},
            ],
        },
        {
            "name": "How the person is read",
            "items": [
                {"what": "How they invest",
                 "how": "From the transaction record: whether money goes in "
                        "monthly or in lumps, whether it continued when the "
                        "market fell, and where in each fund's own range the "
                        "purchases landed.",
                 "note": "A standing instruction that ran through a fall shows "
                         "the arrangement held, which is not the same as the "
                         "person having held their nerve. The two are reported "
                         "differently."},
                {"what": "What cannot be read",
                 "how": "Holding periods, whether losses are cut or run, whether "
                        "last year's winner gets bought.",
                 "note": "All need sales, and a consolidated statement reports "
                         "purchases and rarely reports sales. Stated rather than "
                         "estimated."},
            ],
        },
        {
            "name": "What this platform does not do",
            "items": [
                {"what": "Forecasts",
                 "how": "Where the market sits and what followed similar "
                        "readings, always with the number of windows attached.",
                 "note": "'The twelve months after readings like this were "
                         "positive 87% of the time, from 318 overlapping windows "
                         "in five years' is counted. 'The market looks stretched' "
                         "is not, and will not appear here."},
                {"what": "Composite scores",
                 "how": "Where several measures matter, each is reported.",
                 "note": "A single number out of a hundred requires weights "
                         "nobody can derive, and hides which measure is driving "
                         "it. Anybody wanting one can compute it from what is "
                         "shown; nobody can decompose one that was not."},
                {"what": "A return figure without the transactions",
                 "how": "Growth between two dates is reported as growth between "
                        "two dates.",
                 "note": "The return on money that arrived in instalments is a "
                         "different number and needs the purchases. Where those "
                         "are missing, the platform says so instead of showing "
                         "the first and calling it the second."},
                {"what": "Alpha, where beta does not describe the holding",
                 "how": "Reported only where the market explains at least half "
                        "of how something has moved. Below that the platform "
                        "says what the figure would be worth instead of "
                        "printing it.",
                 "note": "Alpha is defined as the return beta does not account "
                         "for, so it is only as meaningful as beta is. A fund "
                         "holding fifty companies moves largely with the market "
                         "and its alpha means something. One company moves on "
                         "its own news: Thermax's five-year record is 6% "
                         "explained by the index, and the alpha that came out of "
                         "it was 23% a year — arithmetically correct, and it "
                         "would have been read as an edge."},
                {"what": "A cost basis that could not have bought the units",
                 "how": "Where a statement's cost works out to more per unit "
                        "than the fund has ever traded at, the holding is set "
                        "aside from the gain — on both sides — and the reason "
                        "given.",
                 "note": "A partly redeemed folio carries the cost of everything "
                         "ever bought against only the units that remain. "
                         "Reporting a loss from that is reporting something that "
                         "did not happen."},
            ],
        },
    ],

    "closing": (
        "Nothing here is advice. It is a description of what has been computed "
        "and how. Whether any of it should change what somebody does depends on "
        "their circumstances, their tax position and their intentions, none of "
        "which a calculation can see — which is what the adviser is for."
    ),
}


@router.get("", summary="How every figure here is arrived at")
def methodology() -> dict:
    return METHOD
