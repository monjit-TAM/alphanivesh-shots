"""Who uses this, for the people running it."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from ..services import people
from .auth import current_user

router = APIRouter(prefix="/api/people", tags=["People"])


def _admins_only(user: dict) -> None:
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")


@router.get("", summary="Everybody, with enough to answer a support question")
def everybody(search: Optional[str] = None, limit: int = 200,
              user: dict = Depends(current_user)) -> dict:
    _admins_only(user)
    return people.everybody(limit=min(limit, 500), search=search)


@router.get("/how-it-is-going", summary="Whether the thing is being used")
def how_it_is_going(days: int = 30,
                    user: dict = Depends(current_user)) -> dict:
    _admins_only(user)
    return people.how_it_is_going(days)


@router.get("/{user_id}", summary="One person, without their portfolio")
def one(user_id: str, user: dict = Depends(current_user)) -> dict:
    _admins_only(user)
    found = people.one(user_id)
    if not found:
        raise HTTPException(status_code=404, detail="No such account.")
    return found
