"""Who places this, and everything there is to place."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Response

from ..services import advisers, auth, placing, professionals, wealth
from .auth import current_user

router = APIRouter(prefix="/api/placing", tags=["Placing"])


def _theirs(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="Everything the advice implies")
def everything(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _theirs(user, investor_id)
    found = placing.everything_actionable(investor_id)
    return {**found, "who": placing.options_for(investor_id, found["orders"])}


@router.post("/{investor_id}/who", summary="Choose who places it")
def choose(investor_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    """Picking somebody starts a relationship.

    Only the investor may do this. An adviser attaching themselves to somebody
    who did not choose them is the thing the mandate exists to prevent.
    """
    _theirs(user, investor_id)

    owner = wealth.get_investor(investor_id) or {}
    if owner.get("owner_user_id") != (user or {}).get("id"):
        raise HTTPException(
            status_code=403,
            detail="Only the investor can choose who acts for them.")

    professional_id = payload.get("professional_id")
    if not professional_id:
        raise HTTPException(status_code=400, detail="Choose one.")

    from .. import db
    pro = db.fetch_one(
        "SELECT id, kind, firm_name, registration_no, status "
        "FROM professional WHERE id = %s", (professional_id,))
    if not pro or pro["status"] != "active":
        raise HTTPException(status_code=409,
                            detail="That firm is not active here.")

    # An adviser of record needs a row in `adviser`, which is the compliance
    # record rather than the platform account. Made on demand rather than
    # kept in step, so the two cannot drift.
    row = db.fetch_one(
        "SELECT id FROM adviser WHERE registration_no = %s",
        (pro["registration_no"],))
    if not row:
        with db.connection() as conn:
            row = conn.execute(
                """
                INSERT INTO adviser (name, kind, registration_no)
                VALUES (%s, %s, %s) RETURNING id
                """,
                (pro["firm_name"], pro["kind"], pro["registration_no"])
            ).fetchone()

    professionals.add_client(professional_id, investor_id, came_by="claimed")

    if pro["kind"] in ("ria", "ra"):
        advisers.attach(investor_id, row["id"])

    return {
        "chosen": pro["firm_name"],
        "kind": pro["kind"],
        "next": ("They are your adviser of record now. There are terms to "
                 "agree before anything can be placed."
                 if pro["kind"] in ("ria", "ra") else
                 "They can place fund orders for you once terms are agreed."),
    }


@router.post("/{investor_id}/slip", summary="The orders, written out")
def slip(investor_id: str, payload: dict = Body(...),
         user: dict = Depends(current_user)) -> Response:
    """For somebody placing them through their own broker.

    An investor is entitled to read the analysis and trade elsewhere, and the
    platform should help rather than pretend the only route is through us.
    """
    _theirs(user, investor_id)
    text = placing.as_order_slip(payload.get("orders") or [])
    return Response(
        content=text, media_type="text/plain",
        headers={"Content-Disposition": 'attachment; filename="orders.txt"'})
