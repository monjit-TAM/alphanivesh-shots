"""Registering as an adviser or a distributor, and managing a client book."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

from fastapi import (APIRouter, Body, Depends, File, HTTPException, UploadFile)

from ..services import auth, professionals, wealth
from .auth import current_user

router = APIRouter(prefix="/api/professional", tags=["Professionals"])

# Certificates land outside the web root. A registration document served from
# a public path is a registration document anybody can read.
VAULT = Path(os.environ.get("CERT_DIR", "/opt/alphawealth/private/certificates"))
ALLOWED = {".pdf", ".png", ".jpg", ".jpeg"}
MOST = 8 * 1024 * 1024


@router.get("/me", summary="What I am registered as")
def me(user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    return {
        "registered": bool(found),
        "professional": found,
        "kinds": [{"kind": k, **v} for k, v in professionals.KINDS.items()],
    }


@router.post("/me", summary="Claim a registration")
def register(payload: dict = Body(...),
             user: dict = Depends(current_user)) -> dict:
    """Records the claim. Grants nothing until a certificate is checked."""
    try:
        return professionals.register(
            (user or {}).get("id"),
            payload.get("kind") or "",
            payload.get("registration_no") or "",
            firm_name=payload.get("firm_name"),
            arn=payload.get("arn"),
            euin=payload.get("euin"),
            registered_from=payload.get("registered_from"),
            registered_to=payload.get("registered_to"))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))


@router.post("/me/certificate", summary="Upload the certificate")
async def certificate(file: UploadFile = File(...),
                      user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    if not found:
        raise HTTPException(
            status_code=400,
            detail="Record your registration details first.")

    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED:
        raise HTTPException(
            status_code=400,
            detail=f"A {' or '.join(sorted(ALLOWED))} file, please.")

    body = await file.read()
    if len(body) > MOST:
        raise HTTPException(status_code=400,
                            detail="That file is larger than 8MB.")
    if not body:
        raise HTTPException(status_code=400, detail="That file is empty.")

    VAULT.mkdir(parents=True, exist_ok=True)
    # Named from the record rather than from what was uploaded, because a
    # filename is user input and this one becomes a path.
    safe = re.sub(r"[^a-zA-Z0-9]", "", found["id"])[:40]
    path = VAULT / f"{safe}{suffix}"
    path.write_bytes(body)
    path.chmod(0o600)

    return professionals.attach_certificate(
        (user or {}).get("id"), str(path),
        (file.filename or "certificate")[:200])


@router.get("/waiting", summary="Registrations to check")
def waiting(user: dict = Depends(current_user)) -> dict:
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")
    return {"waiting": professionals.waiting()}


@router.post("/{professional_id}/decide", summary="Accept or refuse one")
def decide(professional_id: str, payload: dict = Body(...),
           user: dict = Depends(current_user)) -> dict:
    if (user or {}).get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admins only.")

    accept = bool(payload.get("accept"))
    note = (payload.get("note") or "").strip()
    if not accept and not note:
        raise HTTPException(
            status_code=400,
            detail=("A refusal needs a reason. The person will ask, and the "
                    "answer should already be written down."))

    return professionals.decide_on(
        professional_id, accept, by_user_id=(user or {}).get("id"), note=note)


@router.get("/clients", summary="My client book")
def clients(user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    if not found:
        raise HTTPException(
            status_code=403,
            detail="This is for registered advisers and distributors.")
    if found["status"] != "active":
        raise HTTPException(status_code=403, detail=found["standing"])

    book = professionals.clients_of(found["id"])
    return {
        **book,
        "you_are": found["kind_name"],
        "what_you_can_do": found["what_they_see"],
        "may_edit_advice": found["may_edit_advice"],
    }


@router.post("/clients", summary="Add a client to my book")
def add_client(payload: dict = Body(...),
               user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    if not found or found["status"] != "active":
        raise HTTPException(status_code=403,
                            detail="Only an active registration may do this.")

    investor_id = payload.get("investor_id")
    if not investor_id or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    return professionals.add_client(
        found["id"], investor_id,
        came_by=payload.get("came_by") or "introduced",
        consented_at=payload.get("consented_at"),
        consent_ref=payload.get("consent_ref"))
