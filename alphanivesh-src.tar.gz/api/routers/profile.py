"""The investor's circumstances, and what they are saving for."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..services import auth, profile as profile_service, wealth
from .auth import current_user

router = APIRouter(prefix="/api/profile", tags=["Profile"])


def _permitted(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


class ProfileIn(BaseModel):
    # Everything optional. A partly-filled profile is more useful than none,
    # and the analysis says what it cannot work out rather than refusing.
    date_of_birth: Optional[date] = None
    monthly_income: Optional[Decimal] = None
    monthly_expenses: Optional[Decimal] = None
    dependents: Optional[int] = None
    risk_appetite: Optional[str] = None
    horizon_years: Optional[int] = None
    emergency_fund: Optional[Decimal] = None
    notes: Optional[str] = None


class GoalIn(BaseModel):
    kind: str = "other"
    name: str
    target_amount: Optional[Decimal] = None
    target_date: Optional[date] = None
    current_amount: Optional[Decimal] = None
    monthly_contribution: Optional[Decimal] = None
    priority: Optional[int] = None
    is_achieved: Optional[bool] = None


@router.get("/{investor_id}", summary="What we know, and what we cannot say without more")
def read(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return profile_service.capabilities(investor_id)


@router.put("/{investor_id}", summary="Record or change these details")
def write(investor_id: str, body: ProfileIn, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)

    if body.risk_appetite and body.risk_appetite not in ("conservative", "moderate", "aggressive"):
        raise HTTPException(status_code=400,
                            detail="Risk appetite should be conservative, moderate or aggressive.")
    if body.date_of_birth and body.date_of_birth >= date.today():
        raise HTTPException(status_code=400, detail="That date of birth is in the future.")
    if body.monthly_income is not None and body.monthly_income < 0:
        raise HTTPException(status_code=400, detail="Income cannot be negative.")

    profile_service.save_profile(investor_id, body.model_dump(exclude_none=True))
    # Returning the capabilities rather than the profile means the interface can
    # immediately show what the new information unlocked.
    return profile_service.capabilities(investor_id)


@router.post("/{investor_id}/goals", summary="Add something you are saving for")
def add_goal(investor_id: str, body: GoalIn, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    created = profile_service.save_goal(investor_id, body.model_dump(exclude_none=True))
    return {"id": created["id"], "goals": profile_service.list_goals(investor_id)}


@router.put("/{investor_id}/goals/{goal_id}", summary="Change a goal")
def edit_goal(investor_id: str, goal_id: str, body: GoalIn,
              user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    try:
        profile_service.save_goal(investor_id, body.model_dump(exclude_none=True), goal_id)
    except ValueError as err:
        raise HTTPException(status_code=404, detail=str(err))
    return {"goals": profile_service.list_goals(investor_id)}


@router.delete("/{investor_id}/goals/{goal_id}", summary="Remove a goal")
def remove_goal(investor_id: str, goal_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    if not profile_service.delete_goal(investor_id, goal_id):
        raise HTTPException(status_code=404, detail="No such goal.")
    return {"goals": profile_service.list_goals(investor_id)}


class Targets(BaseModel):
    # A mapping of asset class to the share it should be, as percentages.
    targets: dict[str, float]
    tolerance: float = 5.0


@router.get("/{investor_id}/targets", summary="The mix you meant to hold")
def read_targets(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return {
        "targets": profile_service.get_targets(investor_id),
        "drift": profile_service.drift(investor_id),
    }


@router.put("/{investor_id}/targets", summary="Set the mix you mean to hold")
def write_targets(investor_id: str, body: Targets,
                  user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    try:
        profile_service.set_targets(investor_id, body.targets, body.tolerance)
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))
    return {
        "targets": profile_service.get_targets(investor_id),
        "drift": profile_service.drift(investor_id),
    }


class Style(BaseModel):
    style: Optional[str] = None


@router.get("/{investor_id}/style", summary="Which kind of investor, and why it matters")
def read_style(investor_id: str, user: dict = Depends(current_user)) -> dict:
    """What they have said, what the holdings suggest, and what the three mean.

    All three are returned together. Somebody who has never been asked needs
    the explanation before the question makes sense, and the inference gives
    them something to react to rather than a blank choice.
    """
    _permitted(user, investor_id)
    from ..services import style as style_service

    return {
        "stated": style_service.get_style(investor_id),
        "suggested": style_service.infer(investor_id),
        "styles": style_service.explain_all(),
    }


@router.put("/{investor_id}/style", summary="Say which kind of investor you are")
def write_style(investor_id: str, body: Style,
                user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    from ..services import style as style_service

    try:
        style_service.set_style(investor_id, body.style)
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))
    return {
        "stated": style_service.get_style(investor_id),
        "suggested": style_service.infer(investor_id),
    }
