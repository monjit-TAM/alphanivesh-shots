"""Cover held, and whether it is enough."""

from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import auth, protection, wealth
from .auth import current_user

router = APIRouter(prefix="/api/protection", tags=["Protection"])


def _may(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/{investor_id}", summary="What cover exists, and whether it is enough")
def for_investor(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return protection.for_investor(investor_id)


@router.post("/{investor_id}", summary="Record a policy")
def add(investor_id: str, payload: dict = Body(...),
        user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)

    kind = payload.get("kind")
    if not kind:
        raise HTTPException(status_code=400, detail="What kind of policy?")

    try:
        result = protection.add(
            investor_id, kind,
            cover_amount=payload.get("cover_amount"),
            surrender_value=payload.get("surrender_value"),
            annual_premium=payload.get("annual_premium"),
            insurer=payload.get("insurer"),
            policy_ref=payload.get("policy_ref"),
            renews_on=(date.fromisoformat(payload["renews_on"])
                       if payload.get("renews_on") else None),
            covers=payload.get("covers"),
            notes=payload.get("notes"))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))

    return {"added": result["id"], **protection.for_investor(investor_id)}


@router.delete("/{investor_id}/{policy_id}", summary="Remove one")
def remove(investor_id: str, policy_id: str,
           user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    protection.remove(investor_id, policy_id)
    return protection.for_investor(investor_id)
