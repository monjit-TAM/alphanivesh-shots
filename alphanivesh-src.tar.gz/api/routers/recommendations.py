"""Everything worth saying about a portfolio, in one place.

The guide says one thing first, on purpose: a reader given six actions does
none of them. This is the other document -- the complete account, for somebody
who wants to see all of it and decide for themselves, or for an adviser sitting
with them.

Six sections, and the order is the argument:

    what is working        because a page that opens with faults reads as
                           though nothing they did counted, and most people
                           have done something right
    what is not            the problems, largest first, with what each costs
    what is serious        the ones that could actually hurt -- separated
                           because "63% in one industry" and "one fund charges
                           a little more" do not belong in the same list
    what was missed        opportunities rather than errors: a free switch not
                           taken, an exemption unused
    what to correct        the actions, in order, each with why it is there
                           and what doing it involves
    what we cannot say     the gaps, because a complete-looking account with
                           silent holes is worse than an incomplete one

Nothing here is new arithmetic. It is the same findings, lens calls and
behavioural readings the rest of the service computes, arranged so somebody can
read them in one pass and know what to do.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException

from .. import db
from ..services import (analysis, auth, behaviour, buyplan, findings, fit,
                        judgement, ledger,
                        market, plans, profile as profile_service,
                        quantamental, rebalance, rebalance_engine, restructure,
                        style as style_service, wealth)
from .auth import current_user

log = logging.getLogger("alphanivesh.recommendations")

router = APIRouter(prefix="/api/recommendations", tags=["Recommendations"])


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    """Indian grouping, no decimals."""
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits


@router.get("/{investor_id}", summary="Everything recommended, in one place")
def recommendations(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    summary = wealth.net_worth(investor_id)
    if not summary["positions"]:
        return {"empty": True,
                "why": ("There is nothing here to recommend on yet. Bring in a "
                        "statement or a spreadsheet first.")}

    found = findings.for_investor(investor_id)
    how = behaviour.profile(investor_id)
    drift = profile_service.drift(investor_id)
    them = profile_service.get_profile(investor_id) or {}

    try:
        commission = plans.summary(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("plan summary failed for %s: %s", investor_id, err)
        commission = None

    try:
        redirect = plans.redirect_future(investor_id)
    except Exception:
        redirect = None


    account = {
        "investor": wealth.get_investor(investor_id),
        "as_of": summary.get("as_of").isoformat() if summary.get("as_of") else None,
        "headline": _headline(investor_id, summary),
        "working": _what_is_working(investor_id, how, summary),
        "not_working": _what_is_not(found, drift, summary),
        "serious": _what_is_serious(found, investor_id),
        "missed": _what_was_missed(commission, redirect, investor_id, them),
        "correct": _what_to_correct(found, drift, redirect, commission,
                                    investor_id, how),
        "holdings": _holding_calls(investor_id),
        # Selling without saying where the money goes is half an instruction.
        # The engine sizes the buys against what the sells would raise, which
        # is the part that makes a rebalance a plan rather than a list.
        "redeploy": _redeploy(investor_id),
        # What the funds demand, against what this person has shown they can
        # sustain. Two figures that mean much more together than apart.
        "can_you_hold_it": _can_hold(investor_id),
        # What the funds hold, seen through to the companies, with the share
        # that could be resolved stated -- a look-through covering two funds of
        # eleven is a different claim from one covering all of them.
        "through_the_funds": _look_through(investor_id),
        # What is absent, what would fill it, and what the portfolio becomes
        # if the changes are made. The last is the part nobody shows, and it is
        # usually the argument that persuades.
        "missing": restructure.alternatives(investor_id),
        "cannot_say": _what_we_cannot_say(investor_id, them, how),
        "market": market.context(),
    }

    # Recorded before it is sent, and the object recorded is the object sent.
    # Reconstructing the record afterwards is how the two drift, and a ledger
    # that disagrees with what somebody saw is worse than none.
    ledger.record(
        investor_id, "buy_plan",
        said={"correct": account.get("correct"),
              "redeploy": account.get("redeploy"),
              "missing": account.get("missing"),
              "can_you_hold_it": account.get("can_you_hold_it")},
        basis={"headline": account.get("headline"),
               "cannot_say": account.get("cannot_say"),
               "market": account.get("market"),
               "as_of": account.get("as_of")},
        surface="advice_page",
    )
    return account


def _headline(investor_id: str, summary: dict) -> dict:
    """The position, in one line, before any judgement about it."""
    from .dashboard import _headline as figures

    numbers = figures(investor_id)
    gain = _d(summary["absolute_gain"])

    line = (f"₹{_money(summary['total_value'])} across "
            f"{summary['positions']} holdings.")
    if summary.get("absolute_return_pct") is not None:
        direction = "up" if gain >= 0 else "down"
        line += (f" That is {direction} {abs(_d(summary['absolute_return_pct'])):.1f}% "
                 f"on what we can measure.")
    if summary.get("value_outside_gain"):
        line += (f" A further ₹{_money(summary['value_outside_gain'])} sits in "
                 f"holdings whose cost we cannot establish, so it is not counted "
                 f"in that figure.")

    return {"reading": line, "figures": numbers}


def _what_is_working(investor_id: str, how: dict, summary: dict) -> dict:
    """What this investor has got right.

    First on purpose. Most portfolios have something working, and a page that
    opens with faults teaches the reader that nothing they did counted -- after
    which the criticism lands as noise rather than as advice.
    """
    good = []

    style = (how or {}).get("style") or {}
    nerve = (how or {}).get("nerve") or {}

    if style.get("style") == "monthly":
        good.append({
            "what": "You invest on a schedule",
            "why": style["reading"],
            "worth": ("This is the part that decides most of a long-term result, "
                      "and it is the part most people cannot sustain."),
        })

    if nerve.get("held_nerve"):
        good.append({
            "what": "You kept going when the market fell",
            "why": nerve["reading"],
            "worth": None,
        })

    placement = (how or {}).get("placement") or {}
    if placement and _d(placement.get("average_placement_pct")) <= 40:
        good.append({
            "what": "You buy when prices are off their highs",
            "why": placement["reading"],
            "worth": None,
        })

    # Beating the index is worth saying where it is true, and worth not
    # claiming where it is not.
    from .dashboard import _benchmark
    benchmark = _benchmark(investor_id)
    if benchmark and benchmark["ahead"]:
        good.append({
            "what": f"You are ahead of the index by ₹{_money(benchmark['difference'])}",
            "why": (f"The same money in an index fund would be "
                    f"₹{_money(benchmark['index_value'])} over the same "
                    f"{benchmark['years']} years. Picking has paid so far."),
            "worth": None,
        })

    # A spread of holdings is worth noting where it is genuinely spread.
    concentration = analysis.concentration(investor_id)
    if concentration.get("effective_holdings") and \
            _d(concentration["effective_holdings"]) >= 10:
        good.append({
            "what": "The money is genuinely spread",
            "why": (f"{concentration['positions']} positions behaving like "
                    f"{concentration['effective_holdings']} equal ones, which "
                    f"means no single holding decides your result."),
            "worth": None,
        })

    return {
        "items": good,
        # A count, not a repeat of the first item -- the heading and the first
        # bullet saying the same thing reads as a rendering fault.
        "reading": (f"{len(good)} thing{'s' if len(good) != 1 else ''} here "
                    f"{'are' if len(good) != 1 else 'is'} working." if good else
                    "Nothing here stands out as clearly working yet, which is "
                    "usually a sign the record is too short rather than that "
                    "something is wrong."),
    }


def _what_is_not(found: dict, drift: Optional[dict], summary: dict) -> dict:
    """The problems, largest first, with what each one costs."""
    problems = []

    for finding in found["findings"]:
        if finding.get("severity") not in ("act", "watch"):
            continue
        problems.append({
            "what": finding["headline"],
            "why": finding["detail"],
            "severity": finding.get("severity"),
            "code": finding.get("code"),
            "costs": finding.get("evidence", {}).get("over_twenty_years")
                     or finding.get("evidence", {}).get("would_lose"),
        })

    if drift and not drift.get("in_line"):
        # The widest gap among classes there was actually a plan for. Taking
        # lines[0] picked gold, which has no target -- and rendered "gold is
        # 37.1% against the None% you chose", which is both nonsense and an
        # accusation about a choice nobody made.
        planned = [line for line in drift["lines"]
                   if not line.get("never_planned") and line.get("target_pct")]
        worst = max(planned,
                    key=lambda line: abs(Decimal(str(line.get("gap_pct") or 0))),
                    default=None)

        if worst:
            problems.append({
                "what": f"{drift['worst_gap_pct']} points from the mix you set",
                "why": (f"{worst['asset_class'].replace('_', ' ').title()} is "
                        f"{worst['actual_pct']}% against the "
                        f"{worst['target_pct']}% you set. Markets do the "
                        f"drifting; what you hold now is not what you decided "
                        f"to hold."),
                "severity": "watch",
                "code": "drift",
                "costs": None,
            })

        # And a class held with no target is worth saying, differently. It is
        # not drift -- it is a plan that predates a holding.
        for line in drift["lines"]:
            if not line.get("never_planned"):
                continue
            problems.append({
                "what": (f"{line['asset_class'].replace('_', ' ').title()} is "
                         f"{line['actual_pct']}% and your plan does not "
                         f"mention it"),
                "why": (line.get("note") or
                        "You hold this and your target mix does not mention "
                        "it. That usually means the plan was set before this "
                        "was here."),
                "severity": "know",
                "code": "unplanned_class",
                "costs": None,
            })

    return {
        "items": problems,
        "reading": (f"{len(problems)} thing{'s' if len(problems) != 1 else ''} "
                    f"worth attention." if problems else
                    "Nothing here needs correcting."),
    }


def _what_is_serious(found: dict, investor_id: str) -> dict:
    """The ones that could actually hurt.

    Separated from the rest because "63% of your money is in one industry" and
    "one fund charges slightly more than its sibling" do not belong in the same
    list, and a reader who cannot tell them apart will treat both as noise.
    """
    serious = []

    for finding in found["findings"]:
        if finding.get("severity") != "act":
            continue
        evidence = finding.get("evidence") or {}
        serious.append({
            "what": finding["headline"],
            "why": finding["detail"],
            "how_bad": _how_bad(finding, evidence),
        })

    return {
        "items": serious,
        "reading": (
            "Nothing here rises to serious." if not serious else
            f"{len(serious)} of these could cost real money if left alone."
        ),
    }


def _how_bad(finding: dict, evidence: dict) -> Optional[str]:
    """What the worst case looks like, where it can be stated in rupees."""
    if evidence.get("would_lose"):
        return (f"₹{_money(evidence['would_lose'])} if what has already happened "
                f"once happens again.")
    if evidence.get("over_twenty_years"):
        return (f"₹{_money(evidence['over_twenty_years'])} over twenty years if "
                f"nothing changes.")
    if evidence.get("share_pct"):
        return f"{evidence['share_pct']}% of everything you hold rests on it."
    return None


def _what_was_missed(commission: Optional[dict], redirect: Optional[dict],
                     investor_id: str, them: dict) -> dict:
    """Opportunities rather than errors.

    Somebody who never switched to a direct plan has not made a mistake -- they
    were sold a regular plan and nobody told them. Framing it as an error is
    both wrong and the fastest way to lose a reader.
    """
    missed = []

    if redirect:
        missed.append({
            "what": "A free switch on everything you invest from here",
            "why": redirect["reading"],
            "worth": (f"About ₹{_money(redirect['saves_first_year'])} in the first "
                      f"year, and more every year after as the balance grows."),
            "costs_nothing": True,
        })

    if commission and commission.get("funds"):
        free = [f for f in commission["funds"] if _d(f["tax_to_switch"]) <= 0]
        if free:
            total = sum(_d(f["saving_a_year"]) for f in free)
            missed.append({
                "what": f"{len(free)} fund{'s' if len(free) != 1 else ''} you "
                        f"could move today without paying tax",
                "why": ("These are not in profit, so switching them to the direct "
                        "plan triggers nothing. There is no argument for keeping "
                        "the regular plan on a holding that costs nothing to move."),
                "worth": f"About ₹{_money(total)} a year.",
                "costs_nothing": True,
            })

    # The long-term exemption, where it is going unused.
    from .dashboard import _tax_shape
    tax = _tax_shape(investor_id)
    if tax:
        long_gain = _d(tax["long_term_gain"])
        exempt = _d(tax["exempt"])
        if 0 < long_gain < Decimal("125000"):
            unused = Decimal("125000") - long_gain
            missed.append({
                "what": f"₹{_money(unused)} of the tax-free allowance unused this year",
                "why": ("The first ₹1.25 lakh of long-term equity gains is exempt "
                        "each year, and an allowance not used is not carried "
                        "forward. Realising gains up to it and buying back costs "
                        "nothing in tax and raises the cost basis for later."),
                "worth": f"Up to ₹{_money(unused * Decimal('0.125'))} of tax saved later.",
                "costs_nothing": False,
            })
        for near in (tax.get("nearly_long_term") or [])[:2]:
            missed.append({
                "what": f"{near['name']} turns long-term in "
                        f"{near['months_to_go']} month"
                        f"{'s' if near['months_to_go'] != 1 else ''}",
                "why": ("Selling before then is taxed at 20% rather than 12.5%. "
                        "Waiting is the whole of the action."),
                "worth": f"About ₹{_money(near.get('saving', 0))}.",
                "costs_nothing": True,
            })

    return {
        "items": missed,
        "reading": (
            "Nothing obvious being left on the table." if not missed else
            f"{len(missed)} thing{'s' if len(missed) != 1 else ''} available that "
            f"nobody has taken."
        ),
    }


def _what_to_correct(found: dict, drift: Optional[dict], redirect: Optional[dict],
                     commission: Optional[dict], investor_id: str,
                     how: dict) -> dict:
    """The actions, in order, each with why it sits where it does.

    Ordered by what it costs to act against what it saves. Free actions first
    -- not because they matter most, but because there is no argument against
    them and a reader who does one thing is more likely to do the next.
    """
    steps = []

    if redirect:
        steps.append({
            "do": "Point your next instalment at the direct plan",
            "why": redirect["why_this_first"],
            "involves": ("Stop the existing SIP and start one in the direct plan "
                         "of the same fund. Ten minutes with your broker or the "
                         "AMC's site."),
            "costs": "Nothing.",
            "worth": f"₹{_money(redirect['saves_first_year'])} in the first year.",
        })

    if commission:
        free = [f for f in commission["funds"] if _d(f["tax_to_switch"]) <= 0]
        for fund in free[:3]:
            steps.append({
                "do": f"Switch {fund['name'][:44]} to its direct plan",
                "why": fund["reading"],
                "involves": "A switch request with the AMC. It settles in a day or two.",
                "costs": "Nothing — this holding is not in profit.",
                "worth": f"₹{_money(fund['saving_a_year'])} a year.",
            })

    now = found.get("worth_doing_now") or []
    for finding in now[:2]:
        if finding.get("code") in ("regular_plans", "commission_drag") and redirect:
            continue          # already covered by the redirect step
        steps.append({
            "do": f"{finding.get('action_verb', 'Look at')}: {finding['headline']}",
            "why": finding["detail"],
            "involves": finding.get("why_this_order"),
            "costs": _cost_of_acting(finding),
            "worth": _how_bad(finding, finding.get("evidence") or {}),
        })

    if drift and not drift.get("in_line"):
        out = [line for line in drift["lines"] if line["beyond_tolerance"]]
        if out:
            steps.append({
                "do": "Bring the mix back towards what you chose",
                "why": (f"You are {drift['worst_gap_pct']} points from your target. "
                        f"The largest gap is "
                        f"{out[0]['asset_class'].replace('_', ' ')} at "
                        f"{out[0]['actual_pct']}% against {out[0]['target_pct']}%."),
                "involves": (f"Moving about ₹{_money(abs(_d(out[0]['to_move'])))} "
                             f"between asset classes, which means selling."),
                "costs": "Capital gains tax on whatever is sold.",
                "worth": None,
            })

    return {
        "steps": steps,
        "reading": (
            "Nothing needs doing." if not steps else
            f"{len(steps)} step{'s' if len(steps) != 1 else ''}, in the order "
            f"they are worth doing."
        ),
        "note": ("Free actions come first. Not because they matter most, but "
                 "because nothing argues against them, and somebody who does "
                 "one thing is more likely to do the next."),
    }


def _cost_of_acting(finding: dict) -> Optional[str]:
    code = finding.get("code") or ""
    if "concentration" in code or code == "fund_overlap":
        return "Selling has a tax cost, which depends on what you sell."
    if code in ("regular_plans", "commission_drag"):
        return "Nothing, if you redirect. Tax, if you switch what you hold."
    return None


def _holding_calls(investor_id: str) -> dict:
    """The three lens calls for every share, in one list.

    Gathered here rather than left inside expandable cards, because somebody
    reading a recommendations page wants to see all of them at once -- and
    because the disagreements between lenses are easier to see side by side.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.symbol, v.isin,
               v.current_value, v.asset_class
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.asset_class = 'equity'
          AND v.current_value > 0
        ORDER BY v.current_value DESC
        LIMIT 15
        """,
        (investor_id,),
    )

    total = sum(_d(r["current_value"]) for r in rows) or Decimal(1)
    calls = []

    for row in rows:
        share = _d(row["current_value"]) / total * 100
        try:
            verdict = quantamental.verdicts(
                symbol=row["symbol"], isin=row["isin"],
                position_share_pct=share)
        except Exception:
            verdict = None
        if not verdict:
            continue
        calls.append({
            "name": row["instrument_name"],
            "symbol": row["symbol"],
            "value": str(_d(row["current_value"]).quantize(Decimal("1"))),
            "share_pct": str(share.quantize(Decimal("0.1"))),
            "calls": [{"lens": c["title"], "verdict": c["verdict"],
                       "because": c["because"]} for c in verdict["calls"]],
            "position": verdict.get("position"),
        })

    return {
        "items": calls,
        "reading": (
            "You hold no shares directly, so there is nothing to read three ways "
            "— the fund readings are on each holding instead."
            if not rows else
            f"{len(calls)} of your {len(rows)} shares, seen three ways."
        ),
        "note": ("Three lenses on each company, and they will not always agree. "
                 "A holding that is dear on value and compounding on growth is a "
                 "sell to one investor and a buy to another, and both are "
                 "reasoning correctly from what they are looking for."),
    }




def _why_sell_plainly(sell: dict) -> str:
    """Why this holding is on the sell list, in words about the holding.

    The engine says "Fair PE of 22.1. High volatility (beta 1.54). Deep
    drawdown (-31%). RSI weak (33.1). MACD negative." Every one of those is a
    fact about an indicator. What somebody needs is what the indicators
    together are saying about the company, which is what this writes.

    The engine's own text is kept and shown underneath for anybody who wants
    it. This is a translation rather than a replacement.
    """
    reason = str(sell.get("reason") or "")
    lowered = reason.lower()

    parts = []

    if "expensive" in lowered or "very expensive" in lowered:
        parts.append("priced high against what it earns")
    elif "fair pe" in lowered:
        parts.append("fairly priced")

    if "under pressure" in lowered or "drawdown" in lowered:
        parts.append("well below where it has been")

    if "52-week low" in lowered:
        parts.append("near its lowest in a year")

    if "weak fundamentals" in lowered:
        parts.append("the business figures are weak rather than the price "
                     "merely being low")

    if not parts:
        return ("Ranked weakest of what you hold on the engine's own "
                "measures.")

    first = parts[0][0].upper() + parts[0][1:]
    rest = "; ".join(parts[1:])
    return first + ("; " + rest if rest else "") + "."


def _redeploy(investor_id: str) -> Optional[dict]:
    """What to sell, what it raises, and where it would go.

    A sell recommendation on its own leaves somebody holding cash and no
    better off. The engine allocates the proceeds across ranked candidates
    with a suggested quantity for each, which is what turns "reduce this"
    into something a person can actually execute.

    Whole shares only, so there is always a remainder. It is reported rather
    than rounded away: money the plan does not place is money sitting idle,
    and somebody should know it is there.
    """
    # The full fifteen, so there is a pool to build a mix from. Asking for
    # eight and taking all eight is how a portfolio ends up entirely
    # micro-cap: the engine ranks, and the top of any ranking is whatever
    # scored highest rather than whatever fits.
    try:
        engine = rebalance_engine.for_investor(investor_id, max_picks=15)
    except Exception as err:                                     # pragma: no cover
        log.warning("redeploy failed for %s: %s", investor_id, err)
        return None

    if engine and engine.get("nothing_to_rank"):
        # Not an outage. Somebody holding only funds has no shares to rank,
        # and saying the engine could not be reached about a healthy service
        # is both wrong and the kind of wrong nobody investigates.
        return {"available": False, "nothing_to_rank": True,
                "why": engine.get("why")}

    if not engine or not engine.get("available"):
        why = (engine or {}).get("why")
        if not why:
            # Genuinely unreachable, and worth a line in the log -- this sat
            # broken on a real portfolio for days because the failure was
            # silent and the message was wrong.
            log.warning("rebalance engine gave nothing for %s", investor_id)
            why = "The engine could not be reached."
        return {"available": False, "why": why}

    sells = engine.get("sell") or []
    buys = engine.get("buy") or []

    if not sells:
        return {
            "available": True,
            "nothing_to_sell": True,
            "reading": ("Nothing in your shares is weak enough to sell, so there "
                        "is nothing to redeploy. That is a result rather than a "
                        "gap."),
        }

    raised = _d(engine.get("sell_total"))

    # Which industries this portfolio already carries, so the buys can go where
    # it is thin rather than where it is already heavy.
    try:
        sectors = analysis.sector_exposure(investor_id)
        held_sectors = {s["sector"]: _d(s["share_pct"])
                        for s in (sectors.get("sectors") or [])
                        if s.get("sector")}
    except Exception:
        held_sectors = {}

    total = _d(wealth.net_worth(investor_id).get("total_value"))
    plan = buyplan.choose(buys, raised, held_sectors, total)
    buys = plan.get("picks") or buys
    placed = _d(plan.get("placed") or engine.get("buy_allocated"))
    left = _d(plan.get("left_over") or engine.get("unallocated"))

    return {
        "available": True,
        "nothing_to_sell": False,
        "sells": [{
            "name": s.get("stock_name"),
            "quantity": s.get("quantity"),
            "current_price": s.get("current_price"),
            "raises": str(_d(s.get("sell_value")).quantize(Decimal("1"))),
            "why": s.get("reason"),
            # What it means for this portfolio, rather than what the indicators
            # read. The engine's own text stays available underneath.
            "why_plain": _why_sell_plainly(s),
        } for s in sells],
        "raises_total": str(raised.quantize(Decimal("1"))),
        "buys": [{
            "name": b.get("stock_name"),
            "sector": b.get("sector"),
            "size": b.get("cap_segment"),
            "small": str(b.get("cap_segment") or "").lower().startswith(
                ("micro", "small")),
            "price": b.get("current_price"),
            "weight_pct": b.get("weight"),
            "quantity": b.get("suggested_quantity"),
            "amount": str(_d(b.get("investable_amount")).quantize(Decimal("1"))),
            "grade": b.get("grade"),
            "signal": b.get("signal"),
            "alpha_score": b.get("alpha_score"),
            "why": b.get("rationale"),
            "why_this_one": b.get("why_this_one"),
            "portfolio_pct": b.get("portfolio_pct"),
        } for b in buys],
        "mix": plan.get("mix"),
        "chosen_from": plan.get("considered"),
        "selection_note": plan.get("note"),
        "places_total": str(placed.quantize(Decimal("1"))),
        "left_over": str(left.quantize(Decimal("1"))),
        "alerts": engine.get("alerts") or [],
        "shape_change": _shape_of_buys(buys, sells, raised),
        "reading": (
            f"Selling {len(sells)} holding{'s' if len(sells) != 1 else ''} would "
            f"raise ₹{_money(raised)}."
            + (f" The engine would place ₹{_money(placed)} of it across "
               f"{len(buys)} companies, leaving ₹{_money(left)} that does not "
               f"divide into whole shares." if buys else
               " There is nothing it would buy with the proceeds right now.")
        ),
        "note": engine.get("note"),
        "caveat": ("Selling has a tax cost that is not in these figures. What "
                   "each sale would cost is set out against the holding itself, "
                   "and on a position with a large gain it can outweigh the "
                   "reason for selling."),
    }



# Size labels the engine returns, smallest first, so a shift down the scale can
# be noticed rather than inferred from company names nobody recognises.
_SIZE_ORDER = ("micro", "small", "mid", "large", "mega")


def _shape_of_buys(buys: list[dict], sells: list[dict],
                   raised: Decimal) -> Optional[dict]:
    """Whether the redeployment changes what kind of portfolio this is.

    The engine ranks candidates on its composite score and allocates evenly.
    Nothing in that asks whether eight microcaps in place of one large company
    is a portfolio somebody wants -- and on a real run it suggested exactly
    that: sell a listed financial services company, buy Dwarkesh Sugar,
    Archidply and six others at six thousand rupees each.

    Each of those is a defensible pick on its own numbers. Together they are a
    different risk than what was sold: thinner trading, positions too small to
    matter if they work, and eight more things to follow. That is a decision
    rather than a detail, so it is said rather than left for somebody to work
    out from company names they will not recognise.
    """
    if not buys:
        return None

    sizes = [str(b.get("cap_segment") or "").lower() for b in buys]
    small = sum(1 for size in sizes if size.startswith(("micro", "small")))

    positions = len(buys)
    typical = (raised / positions) if positions else Decimal(0)

    notes = []
    if small >= max(2, positions * 0.6):
        notes.append(
            f"{small} of the {positions} are small or micro-cap companies. They "
            f"trade thinly, which matters less when buying than when selling: "
            f"in a falling market the price you can actually get may be well "
            f"below the one on screen.")

    if positions >= 5:
        notes.append(
            f"This turns {len(sells)} holding"
            f"{'s' if len(sells) != 1 else ''} into {positions}, at about "
            f"₹{_money(typical)} each. Positions that size move a portfolio "
            f"very little whichever way they go, and each one is something else "
            f"to follow.")

    if not notes:
        return None

    return {
        "notes": notes,
        "small_count": small,
        "positions": positions,
        "typical_position": str(typical.quantize(Decimal("1"))),
        "reading": ("Worth knowing before acting: this changes what kind of "
                    "portfolio you have, not just which companies are in it."),
    }



def _can_hold(investor_id: str) -> Optional[dict]:
    """Whether the funds held are ones this person can sit through."""
    try:
        return fit.for_investor(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("fit check failed for %s: %s", investor_id, err)
        return None



def _look_through(investor_id: str) -> Optional[dict]:
    """The companies inside the funds, and how much of the money we could see."""
    from ..services import dataservice

    rows = db.fetch_all(
        """
        SELECT i.native_code, v.quantity, v.current_value
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0 AND i.native_code ~ '^[0-9]+$'
        ORDER BY v.current_value DESC LIMIT 15
        """,
        (investor_id,),
    )
    if not rows:
        return None

    # The value as well as the units. Units alone say nothing about size to a
    # service that does not hold the NAV for that scheme, and every weight came
    # back as zero per cent -- correct arithmetic on a denominator we never
    # supplied.
    # `current_value` is the field it reads. Two rounds were spent guessing at
    # `units` and then `value`; the answer was in the service's own source and
    # a grep would have found it either time.
    holdings = [{"scheme_code": str(r["native_code"]),
                 "current_value": float(_d(r["current_value"]))} for r in rows]
    try:
        result = dataservice.mf_portfolio_insights(holdings)
    except Exception as err:                                     # pragma: no cover
        log.warning("look-through failed for %s: %s", investor_id, err)
        return None

    through = result.get("lookthrough") or {}
    seen = _d(through.get("seen_pct_of_portfolio"))

    # Parked, not broken.
    #
    # Some AMCs publish holdings in a column called weight_pct that does not
    # contain percentages: one scheme's 251 holdings sum to 8,056 on a single
    # disclosure date. The service's arithmetic is right -- it filters to the
    # latest date and weights by fund size correctly -- and the input is not a
    # percentage, so ICICI Bank comes back as 81% of a portfolio.
    #
    # Already recorded from an earlier session: five fund houses publish
    # without percentages and one sums to 8,169%. This is the same fault
    # surfacing through a different endpoint.
    #
    # Anything over a hundred is impossible, and a look-through that says
    # something impossible is worse than one that says nothing: the reader
    # cannot tell which of the other numbers to trust.
    if seen > 100:
        return {
            "usable": False,
            "why": (f"The disclosures behind these funds do not add up — they "
                    f"total {seen:.0f}% of the portfolio, which cannot be right. "
                    f"Some fund houses publish holdings in a column that is not "
                    f"a percentage, and until that is sorted at the source we "
                    f"would rather show nothing than show that."),
            "seen_pct": str(seen.quantize(Decimal("0.1"))),
        }

    return {
        "reading": result.get("conversation"),
        "resolution": result.get("resolution"),
        "per_fund": result.get("per_fund"),
        "lookthrough": through,
        "seen_pct": str(seen.quantize(Decimal("0.1"))),
        # A look-through that resolved nothing is not a look-through. Saying
        # "AXISBANK appears in 3 of your funds at 0.0% of the portfolio" reads
        # as a finding when it is an admission.
        "usable": seen > 0,
        "disclaimer": result.get("disclaimer"),
    }


def _what_we_cannot_say(investor_id: str, them: dict, how: dict) -> dict:
    """The gaps.

    A complete-looking account with silent holes is worse than an incomplete
    one: the reader cannot tell which parts to lean on.
    """
    from .guide import _what_we_could_not_see

    gaps = _what_we_could_not_see(
        investor_id, wealth.net_worth(investor_id), them,
        findings.for_investor(investor_id))

    # What the behavioural record cannot support, which is invisible otherwise.
    for item in (how or {}).get("not_readable") or []:
        gaps["gaps"].append({"what": item["what"], "why": item["why"], "fix": None})

    return gaps


@router.get("/{investor_id}/instruction",
            summary="The shortlist, sized into something actionable")
def instruction(investor_id: str, amount: Optional[float] = None,
                user: dict = Depends(current_user)) -> dict:
    """How much of each, in what order, and what it costs.

    Separate from the shortlist because they answer different questions. The
    shortlist says which holdings look weakest against their sector; this says
    what acting on that would actually involve -- and somebody may well want
    the first without the second.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    result = rebalance.instruction(investor_id, amount)
    if not result:
        return {"nothing_to_do": True,
                "why": ("Either there is no plan to be adrift from, or the "
                        "portfolio is close enough to it that trading would "
                        "cost more than it corrects.")}

    # An instruction is advice, and advice is recorded -- with what it rested
    # on, like everything else.
    ledger.record(
        investor_id, "buy_plan",
        said={"steps": result["steps"], "reading": result["reading"]},
        basis={"wanted": result["wanted"], "raised": result["raised"],
               "tax": result["tax"], "put_into": result["put_into"]},
        surface="advice_page")

    return result
