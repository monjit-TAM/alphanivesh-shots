"""Referral codes: who a code belongs to, and minting them."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException

from ..services import professionals, referrals
from .auth import current_user

router = APIRouter(prefix="/api/referral", tags=["Referrals"])


@router.get("/{code}", summary="Who a code belongs to")
def whose(code: str) -> dict:
    """Deliberately open, and deliberately thin.

    Somebody arriving on a link has not signed in yet, so this cannot require
    a session. It returns the firm name and nothing else -- enough for the
    signup page to say who referred them, and not enough to enumerate anybody's
    client base by trying codes.
    """
    found = referrals.whose(code)
    if not found:
        raise HTTPException(status_code=404, detail="Unknown code.")
    return {"firm_name": found["firm_name"], "kind": found["kind"]}


@router.get("", summary="My codes")
def mine(user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    if not found or found["status"] != "active":
        raise HTTPException(status_code=403,
                            detail="Only an active registration has codes.")
    return {"codes": referrals.codes_for(found["id"])}


@router.post("", summary="Mint one")
def mint(payload: dict = Body(default={}),
         user: dict = Depends(current_user)) -> dict:
    found = professionals.for_user((user or {}).get("id"))
    if not found or found["status"] != "active":
        raise HTTPException(status_code=403,
                            detail="Only an active registration has codes.")
    made = referrals.make_code(found["id"], (payload or {}).get("label"))
    return {**made, "codes": referrals.codes_for(found["id"])}
