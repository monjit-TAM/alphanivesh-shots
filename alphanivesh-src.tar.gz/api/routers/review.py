"""The periodic review."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response

from ..services import auth, ledger, review, wealth
from .auth import current_user

router = APIRouter(prefix="/api/review", tags=["Review"])


@router.get("/{investor_id}", summary="The review, if one is owed")
def for_investor(investor_id: str, force: bool = False,
                 user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    written = review.assemble(investor_id, force=force)
    if not written:
        return {"nothing_to_send": True,
                "why": ("Either the rhythm has not come round or nothing has "
                        "happened worth a message. A review that arrives with "
                        "nothing in it teaches somebody to ignore the next "
                        "one.")}

    # What somebody was shown is recorded, and a review is a thing shown.
    ledger.record(
        investor_id, "notification",
        said={"subject": written["subject"],
              "sections": [{"title": s["title"],
                            "items": [i["headline"] for i in s["items"]]}
                           for s in written["sections"]]},
        basis={"covers_days": written["covers_days"],
               "cadence": written["cadence"]},
        surface="review")

    return written


@router.get("/{investor_id}/preview.html",
            summary="The review as it would arrive")
def preview(investor_id: str, force: bool = True,
            user: dict = Depends(current_user)) -> Response:
    """The email, rendered.

    Worth having before anything is sent to anybody: a review that reads well
    as a data structure can still arrive looking broken, and the only way to
    know is to look at it.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    written = review.assemble(investor_id, force=force)
    if not written:
        return Response(
            content="<p style='font-family:sans-serif'>Nothing worth sending.</p>",
            media_type="text/html")

    return Response(content=review.as_html(written), media_type="text/html")
