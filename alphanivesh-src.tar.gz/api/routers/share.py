"""Exporting your own data, and sharing a view of it."""

from __future__ import annotations

import json
from datetime import date

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import StreamingResponse

from ..services import auth, ledger, sharing, wealth
from .auth import current_user

router = APIRouter(prefix="/api", tags=["Share"])


def _may(user: dict, investor_id: str) -> None:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


# ------------------------------------------------------------------ export

@router.get("/export/{investor_id}", summary="Everything we hold about you")
def export_json(investor_id: str,
                user: dict = Depends(current_user)) -> StreamingResponse:
    _may(user, investor_id)
    payload = sharing.everything(investor_id)
    name = f"alphanivesh-{date.today().isoformat()}.json"
    return StreamingResponse(
        iter([json.dumps(payload, ensure_ascii=False, indent=1, default=str)]),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/export/{investor_id}/{part}.csv", summary="One table, flat")
def export_csv(investor_id: str, part: str,
               user: dict = Depends(current_user)) -> StreamingResponse:
    _may(user, investor_id)
    if part not in ("holdings", "transactions", "goals", "liabilities"):
        raise HTTPException(
            status_code=400,
            detail="One of: holdings, transactions, goals, liabilities.")
    name = f"alphanivesh-{part}-{date.today().isoformat()}.csv"
    return StreamingResponse(
        iter([sharing.as_csv(investor_id, part)]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ------------------------------------------------------------------- share

@router.post("/share/{investor_id}", summary="Make a link that expires")
def make_share(investor_id: str, payload: dict = Body(default={}),
               user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    try:
        result = sharing.create(
            investor_id,
            scope=payload.get("scope", "advice"),
            days=payload.get("days", sharing.DEFAULT_DAYS),
            label=payload.get("label"),
            created_by=(user or {}).get("id"))
    except ValueError as err:
        raise HTTPException(status_code=400, detail=str(err))

    # Sharing somebody's position is an act worth recording, like any other.
    ledger.record(
        investor_id, "notification",
        said={"shared": result["scope"], "expires": result["expires_at"]},
        basis={"days": result["days"], "by": (user or {}).get("email")},
        surface="share")

    return result


@router.get("/share/{investor_id}", summary="Links you have made")
def list_shares(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    return {"shares": sharing.live(investor_id)}


@router.delete("/share/{investor_id}/{share_id}", summary="Stop a link working")
def revoke(investor_id: str, share_id: str,
           user: dict = Depends(current_user)) -> dict:
    _may(user, investor_id)
    sharing.revoke(investor_id, share_id)
    return {"shares": sharing.live(investor_id)}


@router.get("/shared/{token}", summary="Open a shared view")
def open_shared(token: str) -> dict:
    """No sign-in. The token is the credential, which is why it expires.

    Deliberately outside the auth dependency: a recipient has no account here
    and should not need one. What protects this is that the link is unguessable,
    short-lived, revocable, and counted.
    """
    resolved = sharing.resolve(token)
    if not resolved:
        raise HTTPException(status_code=404, detail="No such link.")
    if resolved.get("gone"):
        raise HTTPException(status_code=410, detail=resolved["why"])

    investor_id = resolved["investor_id"]
    scope = resolved["scope"]

    from ..services import decide as decide_service
    from .dashboard import dashboard as dashboard_view

    payload = {
        "shared": True,
        "scope": scope,
        "expires_at": resolved["expires_at"],
        "investor": wealth.get_investor(investor_id),
        "note": ("A read-only view shared with you. It stops working on the "
                 "date above."),
    }

    admin = {"id": None, "role": "admin"}
    if scope in ("advice", "both"):
        payload["decision"] = decide_service.decide(investor_id)
    if scope in ("holdings", "both"):
        payload["dashboard"] = dashboard_view(investor_id, user=admin)

    return payload
