"""Everything the reading page needs, in one response.

The page tells someone what their portfolio is doing, in order, as prose. It
needs the wealth summary, the findings, the fund records, the sector split and
the concentration -- all at once, because the narrative moves between them and
five round trips on a slow connection is five chances to see half a page.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import analysis, auth, findings, profile, wealth
from .auth import current_user

router = APIRouter(prefix="/api/story", tags=["Story"])


@router.get("/{investor_id}", summary="The whole reading, in one call")
def story(investor_id: str, user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    return {
        "investor": wealth.get_investor(investor_id),
        "net_worth": wealth.net_worth(investor_id),
        "allocation": wealth.allocation(investor_id),
        "returns": wealth.returns(investor_id),
        "findings": findings.for_investor(investor_id),
        "funds": analysis.fund_quality(investor_id),
        "sectors": analysis.sector_exposure(investor_id),
        "concentration": analysis.concentration(investor_id),
        # What the reader has told us about themselves, and what remains
        # unanswerable without more. The closing chapter is built from this.
        "profile": profile.capabilities(investor_id),
    }
