"""More than one way to do it."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..services import auth, ledger, ways, wealth
from .auth import current_user

router = APIRouter(prefix="/api/ways", tags=["Ways"])


@router.get("/{investor_id}", summary="Every action, and the ways of doing it")
def for_investor(investor_id: str,
                 user: dict = Depends(current_user)) -> dict:
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")

    result = ways.for_investor(investor_id)

    # Setting out the alternatives is advice, and advice is recorded. The
    # ledger cares what somebody was shown, and showing four ways of doing
    # something is a different act from showing one.
    if result.get("actions"):
        ledger.record(
            investor_id, "decision",
            said={"actions": [{"code": a["code"], "what": a["what"],
                               "ways": [w["code"] for w in
                                        ((a.get("ways") or {}).get("ways") or [])]}
                              for a in result["actions"]]},
            basis={"with_alternatives": result["with_alternatives"]},
            surface="advice_page")

    return result
