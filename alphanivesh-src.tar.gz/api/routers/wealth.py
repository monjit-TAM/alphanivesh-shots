"""Routes for reading an investor's consolidated wealth.

Every route here is scoped to the signed-in user. The scope itself is worked
out in services/auth.visible_investor_ids; these routes only enforce it.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from ..services import auth, peers, summaries, wealth
from .auth import current_user

router = APIRouter(prefix="/api/wealth", tags=["Wealth"])


def _permitted(user: dict, investor_id: str) -> None:
    """Guard for a single investor.

    Deliberately returns 404 rather than 403 when the user may not see the
    record. A 403 confirms that the id exists, which is a small leak but a real
    one: it lets someone walk ids and learn who is on the platform.
    """
    if not auth.may_see(user, investor_id):
        raise HTTPException(status_code=404, detail="No such investor.")
    if wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")


@router.get("/investors", summary="Investors you can see")
def list_investors(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user: dict = Depends(current_user),
) -> dict:
    scope = auth.visible_investor_ids(user)
    if scope is not None and not scope:
        # A new account with nothing imported yet. Not an error.
        return {"count": 0, "investors": []}
    rows = wealth.list_investors(limit=limit, offset=offset, only_ids=scope)
    return {"count": len(rows), "investors": rows}


@router.get("/{investor_id}/summary", summary="Net worth, allocation and returns in one call")
def summary(investor_id: str, user: dict = Depends(current_user)) -> dict:
    """What the dashboard loads first.

    Bundled into one response because the landing view needs all three, and
    three round trips on a slow connection is a worse experience than one
    slightly larger payload.
    """
    _permitted(user, investor_id)
    return {
        "investor": wealth.get_investor(investor_id),
        "net_worth": wealth.net_worth(investor_id),
        "allocation": wealth.allocation(investor_id),
        "returns": wealth.returns(investor_id),
    }


@router.get("/{investor_id}/networth", summary="Current value, cost and gain")
def net_worth(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return wealth.net_worth(investor_id)


@router.get("/{investor_id}/allocation", summary="Split of current value by asset class")
def allocation(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return {"asset_classes": wealth.allocation(investor_id)}


@router.get("/{investor_id}/holdings", summary="Every current position")
def holdings(
    investor_id: str,
    asset_class: str | None = Query(None, description="Filter to one asset class"),
    user: dict = Depends(current_user),
) -> dict:
    _permitted(user, investor_id)
    rows = wealth.holdings(investor_id, asset_class)
    return {"count": len(rows), "holdings": rows}


@router.get("/{investor_id}/returns", summary="Absolute return and XIRR")
def returns(investor_id: str, user: dict = Depends(current_user)) -> dict:
    _permitted(user, investor_id)
    return wealth.returns(investor_id)


@router.get("/{investor_id}/timeline", summary="Portfolio value month by month")
def timeline(
    investor_id: str,
    months: int = Query(24, ge=1, le=120),
    user: dict = Depends(current_user),
) -> dict:
    _permitted(user, investor_id)
    return {"months": months, "points": wealth.timeline(investor_id, months)}


@router.get("/{investor_id}/summaries",
            summary="A line of analysis against every holding")
def holding_summaries(investor_id: str,
                      user: dict = Depends(current_user)) -> dict:
    """Sortino and the behaviour band, per holding.

    Separate from the holdings list so the list is never held up by it: the
    figures arrive a moment later and fill in, which is right for something
    that decorates rather than something somebody is waiting for.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return summaries.for_holdings(investor_id)


@router.get("/{investor_id}/peers",
            summary="Where each fund stands among its peers")
def peer_standing(investor_id: str,
                  user: dict = Depends(current_user)) -> dict:
    """Separate from the dashboard because it is slow.

    One call per category plus one per fund, which came to six seconds on a
    real portfolio. That is fine arriving a moment after the page and not fine
    holding it up.
    """
    if not auth.may_see(user, investor_id) or wealth.get_investor(investor_id) is None:
        raise HTTPException(status_code=404, detail="No such investor.")
    return peers.for_investor(investor_id) or {"computable": False}
