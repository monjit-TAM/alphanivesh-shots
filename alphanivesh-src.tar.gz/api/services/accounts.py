"""Getting in, and proving who you are.

Four flows: proving an address belongs to you, resetting a forgotten password,
the welcome that follows, and signing in with a provider instead of a password.

**The security decisions, stated rather than buried.**

Tokens are single use, short lived and stored hashed. A reset token sitting in
plaintext in a database is a password sitting in plaintext in a database
wearing a hat, and the plaintext exists only in the link that was mailed.

Requesting a reset says the same thing whether or not the address exists. The
alternative tells an attacker which of ten thousand addresses have accounts
here, which is worth more to them than the reset.

A reset consumes every other outstanding token for that account. Somebody who
asks twice because the first did not arrive should not leave two working keys
behind.

And signing in with a provider only joins an existing account when the
provider says the address is verified. Google will tell you an address is
unverified if it is, and treating that as good enough is how accounts get taken
over by anybody willing to register the same address elsewhere.

**The messages themselves matter more than they look.** A verification email is
often the first thing somebody sees from a product, and one that reads like a
system notification sets the tone for everything after it.
"""

from __future__ import annotations

import hashlib
import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .. import db
from . import mail

log = logging.getLogger("alphanivesh.identity")

SITE = os.environ.get("SITE_URL", "https://alphanivesh.com")

# Long enough to find the email in a busy inbox, short enough that a forwarded
# message is not a standing key to somebody's money.
VERIFY_HOURS = 48
RESET_HOURS = 2


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _issue(user_id: str, purpose: str, hours: int) -> str:
    """Mint a token, store its hash, return the plaintext once."""
    token = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(hours=hours)

    with db.connection() as conn:
        # Anything outstanding for this purpose is spent. Somebody who asks
        # twice because the first did not arrive should not leave a second
        # working key behind them.
        conn.execute(
            """
            UPDATE auth_token SET used_at = now()
            WHERE user_id = %s AND purpose = %s AND used_at IS NULL
            """,
            (user_id, purpose),
        )
        conn.execute(
            """
            INSERT INTO auth_token (user_id, purpose, token_hash, expires_at)
            VALUES (%s, %s, %s, %s)
            """,
            (user_id, purpose, _hash(token), expires),
        )
    return token


def _spend(token: str, purpose: str) -> Optional[str]:
    """Consume a token, returning the user it belonged to.

    Marked used inside the same statement that reads it, so two requests
    arriving together cannot both succeed.
    """
    row = db.fetch_one(
        """
        UPDATE auth_token SET used_at = now()
        WHERE token_hash = %s AND purpose = %s
          AND used_at IS NULL AND expires_at > now()
        RETURNING user_id
        """,
        (_hash(token), purpose),
    )
    return (row or {}).get("user_id")


# ---------------------------------------------------------------------------
# Proving the address
# ---------------------------------------------------------------------------

def send_verification(user_id: str, email: str, name: str = "") -> dict:
    token = _issue(user_id, "verify_email", VERIFY_HOURS)
    link = f"{SITE}/verify.html?token={token}"
    first = (name or "").split()[0].title() if name else "there"

    body = f"""
<p>Hello {first},</p>

<p>One thing before we start: we need to know this address reaches you. It is
where everything we ever send you will go — what changed in your portfolio,
what is worth doing about it, and the occasional thing that has a deadline.</p>

{mail.button("Confirm this is your address", link)}

<p style="font-size:13px;color:#6B635A">The link works for
{VERIFY_HOURS} hours. If it expires, ask for another from the sign-in page.</p>

<p style="font-size:13px;color:#6B635A">If you did not sign up for
AlphaNivesh, somebody has used your address by mistake. Ignore this and nothing
will happen — the account cannot be used until this link is followed.</p>
"""
    return mail.send(
        email, "Confirm your address",
        mail.wrap(body, preheader="One link, and you are in."),
        kind="verify_email",
        text=(f"Hello {first},\n\nConfirm your address: {link}\n\n"
              f"The link works for {VERIFY_HOURS} hours."))


def verify(token: str) -> Optional[str]:
    """Follow the link. Returns the user id, or None."""
    user_id = _spend(token, "verify_email")
    if not user_id:
        return None

    with db.connection() as conn:
        conn.execute(
            "UPDATE users SET email_verified_at = now() WHERE id = %s",
            (user_id,))
    return user_id


# ---------------------------------------------------------------------------
# The welcome
# ---------------------------------------------------------------------------

def send_welcome(user_id: str, email: str, name: str = "") -> dict:
    """Once, after the address is proved.

    Says what the product does and what to do first, because somebody who has
    just verified an address is at the one moment they are most likely to act.
    """
    row = db.fetch_one("SELECT welcomed_at FROM users WHERE id = %s", (user_id,))
    if row and row.get("welcomed_at"):
        return {"sent": False, "why": "Already welcomed."}

    first = (name or "").split()[0].title() if name else "there"
    body = f"""
<p>Hello {first}, and welcome.</p>

<p>AlphaNivesh looks at what you already hold and tells you what is true about
it — what it is worth, what it is exposed to, what it costs you, and what is
worth doing. It computes rather than guesses, and where it cannot compute
something it says so instead of estimating.</p>

<p><b>The one thing to do first is bring your holdings in.</b> A consolidated
account statement from CAMS or KFintech covers most of it, and everything else
on the site follows from having it.</p>

{mail.button("Bring in your holdings", f"{SITE}/upload.html")}

<p>After that, three things are worth a look:</p>

<p style="margin:0 0 6px"><b>Your snapshot</b> — everything that matters on one
page.<br>
<b>What to do now</b> — what is worth doing, in order, with what each would
cost.<br>
<b>How this works</b> — where every number comes from, if you would rather
check than trust.</p>

<p style="margin-top:22px">You decide how often we get in touch, and the
default is once a quarter. Anything urgent reaches you regardless — a standing
instruction stopping, or a tax allowance about to expire. Neither is common.</p>
"""
    result = mail.send(
        email, "Welcome — and the one thing to do first",
        mail.wrap(body, preheader="Bring your holdings in and the rest follows."),
        kind="welcome", 
        text=(f"Hello {first}, and welcome.\n\n"
              f"The one thing to do first is bring your holdings in: "
              f"{SITE}/upload.html"))

    if result.get("sent"):
        with db.connection() as conn:
            conn.execute("UPDATE users SET welcomed_at = now() WHERE id = %s",
                         (user_id,))
    return result


# ---------------------------------------------------------------------------
# Forgetting the password
# ---------------------------------------------------------------------------

def request_reset(email: str) -> dict:
    """Ask for a reset link.

    Says the same thing whether or not the address has an account. The
    alternative tells somebody which addresses are registered here, which is
    worth more to an attacker than the reset itself.
    """
    said = {"ok": True,
            "reading": ("If that address has an account, a link is on its way. "
                        "It works for two hours.")}

    row = db.fetch_one(
        "SELECT id, email, full_name, email_verified_at FROM users "
        "WHERE lower(email) = lower(%s)", (email,))
    if not row:
        log.info("reset requested for unknown address")
        return said

    # An unverified address has not been proved to belong to anybody, and
    # sending a key to it would be sending a key to whoever claimed it.
    if not row.get("email_verified_at"):
        send_verification(row["id"], row["email"], row.get("full_name") or "")
        return said

    token = _issue(row["id"], "reset_password", RESET_HOURS)
    link = f"{SITE}/reset.html?token={token}"
    first = (row.get("full_name") or "").split()[0].title() or "there"

    body = f"""
<p>Hello {first},</p>

<p>Somebody asked to reset the password on this account. If that was you:</p>

{mail.button("Choose a new password", link)}

<p style="font-size:13px;color:#6B635A">The link works for {RESET_HOURS} hours
and once only.</p>

<p style="font-size:13px;color:#6B635A">If it was not you, nothing has changed
and you do not need to do anything. Your password still works and this link
expires on its own. Worth telling us if it keeps happening.</p>
"""
    mail.send(row["email"], "Reset your password",
              mail.wrap(body, preheader="One link, valid for two hours."),
              kind="reset_password", investor_id=None,
              text=f"Reset your password: {link}\n\nValid for {RESET_HOURS} hours.")
    return said


def reset(token: str, new_password: str) -> dict:
    """Spend the token and set the password."""
    from .auth import _hasher

    # The same floor registration uses. A reset that accepts a weaker password
    # than signup is a way round the rule rather than a convenience.
    if len(new_password or "") < 10:
        return {"ok": False,
                "why": ("Please choose a password of at least ten characters. "
                        "A short phrase you will remember works well.")}

    user_id = _spend(token, "reset_password")
    if not user_id:
        return {"ok": False,
                "why": ("That link has expired or been used already. Ask for "
                        "another and it will arrive within a minute.")}

    with db.connection() as conn:
        conn.execute(
            "UPDATE users SET password_hash = %s WHERE id = %s",
            (_hasher.hash(new_password), user_id))
        # Following a reset link proves the address, so anybody who reset this
        # way does not also need to verify.
        conn.execute(
            "UPDATE users SET email_verified_at = coalesce(email_verified_at, now()) "
            "WHERE id = %s", (user_id,))

    row = db.fetch_one("SELECT email, full_name FROM users WHERE id = %s",
                       (user_id,))
    if row:
        body = f"""
<p>Your AlphaNivesh password was changed a moment ago.</p>

<p>If that was you, there is nothing to do.</p>

<p><b>If it was not</b>, somebody has access to your email. Reset it again from
the sign-in page and change your email password too — this message is the only
warning you will get, and it is worth acting on immediately.</p>
"""
        mail.send(row["email"], "Your password was changed",
                  mail.wrap(body, preheader="If this was not you, act now."),
                  kind="password_changed",
                  text="Your AlphaNivesh password was changed. If that was not "
                       "you, reset it again immediately.")

    return {"ok": True, "reading": "Password changed. You can sign in with it now."}


# ---------------------------------------------------------------------------
# Signing in with a provider
# ---------------------------------------------------------------------------

def from_provider(provider: str, subject: str, email: Optional[str],
                  name: Optional[str], email_verified: bool) -> dict:
    """Find or make the account behind a provider sign-in.

    **Only joins an existing account when the provider says the address is
    verified.** Google will tell you an address is unverified when it is, and
    treating that as good enough lets anybody who registers the same address
    elsewhere walk into somebody's account.
    """
    known = db.fetch_one(
        "SELECT user_id FROM identity WHERE provider = %s AND subject = %s",
        (provider, subject))

    if known:
        with db.connection() as conn:
            conn.execute("UPDATE identity SET last_used_at = now() "
                         "WHERE provider = %s AND subject = %s",
                         (provider, subject))
        return {"user_id": known["user_id"], "created": False}

    if email and email_verified:
        existing = db.fetch_one(
            "SELECT id FROM users WHERE lower(email) = lower(%s)", (email,))
        if existing:
            with db.connection() as conn:
                conn.execute(
                    """
                    INSERT INTO identity (user_id, provider, subject, email,
                                          last_used_at)
                    VALUES (%s, %s, %s, %s, now())
                    """,
                    (existing["id"], provider, subject, email))
                conn.execute(
                    "UPDATE users SET email_verified_at = "
                    "coalesce(email_verified_at, now()) WHERE id = %s",
                    (existing["id"],))
            return {"user_id": existing["id"], "created": False, "linked": True}

    if not email:
        return {"error": ("That provider did not give us an email address, and "
                          "we cannot make an account without one.")}

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO users (email, full_name, role, password_hash,
                               email_verified_at)
            VALUES (%s, %s, 'investor', '', %s)
            RETURNING id
            """,
            (email, name or email.split("@")[0],
             datetime.now(timezone.utc) if email_verified else None),
        ).fetchone()
        user_id = row["id"]
        conn.execute(
            """
            INSERT INTO identity (user_id, provider, subject, email, last_used_at)
            VALUES (%s, %s, %s, %s, now())
            """,
            (user_id, provider, subject, email))

    # The same portfolio a password signup gets. Without this somebody who
    # arrives on an adviser's link and signs in with Google becomes a stranger
    # with no portfolio, which is the bug the password path just had.
    try:
        from .auth import _make_portfolio
        _make_portfolio(user_id, name or "", email, None)
    except Exception as err:                                     # pragma: no cover
        log.error("NO PORTFOLIO MADE for %s: %s", email, err)

    if email_verified:
        send_welcome(user_id, email, name or "")

    return {"user_id": user_id, "created": True}
