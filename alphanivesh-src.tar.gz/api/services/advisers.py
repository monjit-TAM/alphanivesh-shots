"""Under whose licence.

We are a technology platform. Until our own registration comes through, the
adviser of record on anything an investor acts upon is the registered adviser
whose relationship they are in — in practice a broker on the Kambala platform
using their own RIA licence, with our reasoning behind it.

**That arrangement holds only if the record says so**, and only if it says so
at the moment the advice is given. Reconstructing it afterwards from whoever
the investor happened to be with is the kind of attribution that does not
survive being asked about.

**The distinction that matters.** Somebody signing into this platform and
reading "sell ₹1.28 lakh of Apollo and buy it back" has been advised. Which
firm advised them is a fact about the arrangement, not about the software, and
it has to be recorded as one.

**Where there is no mandate**, this says so rather than guessing. A
recommendation given into a relationship nobody has recorded is one nobody can
account for, and the honest response is to flag it rather than to attribute it
to whoever seems likeliest.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.advisers")


def of_record(investor_id: str, on: Optional[date] = None) -> Optional[dict]:
    """Who was advising this investor, on a date.

    Defaults to today. Pass a date to answer the question a regulator actually
    asks, which is about a day in the past rather than about now.
    """
    when = on or date.today()

    row = db.fetch_one(
        """
        SELECT a.id, a.name, a.kind, a.registration_no,
               a.registered_from, a.registered_to, a.venue,
               m.began_on, m.ended_on, m.agreed_at, m.agreement_ref
        FROM advisory_mandate m
        JOIN adviser a ON a.id = m.adviser_id
        WHERE m.investor_id = %s
          AND m.began_on <= %s
          AND (m.ended_on IS NULL OR m.ended_on >= %s)
        ORDER BY m.began_on DESC
        LIMIT 1
        """,
        (investor_id, when, when),
    )
    if not row:
        return None

    # Was the registration live on the day? A recommendation made under a
    # registration that had lapsed is a different problem from one made under
    # no registration at all, and the record should be able to tell them
    # apart.
    lapsed = bool(row["registered_to"] and row["registered_to"] < when)
    early = bool(row["registered_from"] and row["registered_from"] > when)

    return {
        "adviser_id": row["id"],
        "name": row["name"],
        "kind": row["kind"],
        "registration_no": row["registration_no"],
        "venue": row["venue"],
        "mandate_from": row["began_on"].isoformat() if row["began_on"] else None,
        "agreed_at": row["agreed_at"].isoformat() if row["agreed_at"] else None,
        "registration_live": not (lapsed or early),
        "trouble": ("The registration had lapsed on that date."
                    if lapsed else
                    "The registration had not begun on that date."
                    if early else None),
    }


def may_advise(investor_id: str) -> dict:
    """Whether advice can be given into this relationship, and under whom.

    Called before anything is shown that somebody could act on. The answer is
    not a boolean because the useful part is why, and because "no" has three
    different causes with three different fixes.
    """
    found = of_record(investor_id)

    if not found:
        return {
            "may": False,
            "why": ("No adviser is recorded for this investor. Anything shown "
                    "here would be advice given into a relationship nobody has "
                    "a record of, and the record is what makes the "
                    "arrangement work."),
            "fix": "Record which registered adviser this investor is with.",
            "adviser": None,
        }

    if found["kind"] == "platform":
        return {
            "may": False,
            "why": ("The adviser of record is this platform, which is not "
                    "registered. Until it is, advice an investor acts on has "
                    "to be given under a registered firm's licence."),
            "fix": "Attach this investor to a registered adviser.",
            "adviser": found,
        }

    if not found["registration_live"]:
        return {
            "may": False,
            "why": found["trouble"],
            "fix": "Check the registration dates, or move the investor.",
            "adviser": found,
        }

    if not found["agreed_at"]:
        return {
            # Not a hard no: the arrangement exists and the adviser is
            # registered. What is missing is the investor's agreement to it,
            # which is a gap worth flagging rather than a reason to show
            # nothing.
            "may": True,
            "caveat": ("No agreement date is recorded for this mandate. The "
                       "adviser is registered and the relationship exists, but "
                       "nothing says when the investor agreed to it."),
            "adviser": found,
        }

    return {"may": True, "adviser": found}


def attach(investor_id: str, adviser_id: str, *,
           agreed_at: Optional[Any] = None,
           agreement_ref: Optional[str] = None) -> dict:
    """Put an investor with an adviser.

    Ends any current mandate first, because two open mandates would make "who
    advised this" a question with two answers.
    """
    with db.connection() as conn:
        conn.execute(
            """
            UPDATE advisory_mandate SET ended_on = current_date
            WHERE investor_id = %s AND ended_on IS NULL
            """,
            (investor_id,))
        conn.execute(
            """
            INSERT INTO advisory_mandate
                (investor_id, adviser_id, agreed_at, agreement_ref)
            VALUES (%s, %s, %s, %s)
            """,
            (investor_id, adviser_id, agreed_at, agreement_ref))

    return of_record(investor_id) or {}


def everybody() -> list[dict]:
    """Every adviser, with how many investors sit under each."""
    rows = db.fetch_all(
        """
        SELECT a.*,
               (SELECT count(*) FROM advisory_mandate m
                 WHERE m.adviser_id = a.id AND m.ended_on IS NULL) AS investors,
               (SELECT count(*) FROM advice_ledger l
                 WHERE l.adviser_id = a.id) AS advice_given
        FROM adviser a
        ORDER BY a.active DESC, a.name
        """)
    return [{
        "id": r["id"], "name": r["name"], "kind": r["kind"],
        "registration_no": r["registration_no"],
        "venue": r["venue"], "active": r["active"],
        "investors": r["investors"], "advice_given": r["advice_given"],
        "registered_to": (r["registered_to"].isoformat()
                          if r["registered_to"] else None),
    } for r in rows]


def unattributed(days: int = 90) -> dict:
    """Advice with no adviser against it.

    The number to watch. Every row here is something an investor was shown
    that the record cannot attribute to a registered firm, and the count
    should be falling towards zero rather than sitting wherever it lands.
    """
    row = db.fetch_one(
        """
        SELECT count(*) AS rows,
               count(DISTINCT investor_id) AS investors,
               min(shown_at)::date AS oldest
        FROM advice_ledger
        WHERE adviser_id IS NULL
          AND shown_at > now() - (%s || ' days')::interval
        """,
        (days,)) or {}

    count = int(row.get("rows") or 0)
    return {
        "rows": count,
        "investors": int(row.get("investors") or 0),
        "oldest": row["oldest"].isoformat() if row.get("oldest") else None,
        "reading": (
            "Everything shown in this period is attributed to a registered "
            "adviser." if not count else
            f"{count} pieces of advice across {row.get('investors')} investors "
            f"carry no adviser. Each is something somebody was shown that the "
            f"record cannot attribute to a registered firm."),
    }
