"""What the holdings are, beyond what they are worth.

Everything here reads published figures -- a fund's own disclosed returns, a
company's own reported ratios -- and compares them. Nothing is scored. Where
AlphaLensMF returns "risk 6.8" from weights somebody chose, this says "your
fund is 31st of 42 in its category over three years", which the reader can
check and disagree with.

The distinction matters most where the two look alike. A health score out of
100 and a category rank both compress a lot into one number, but only one of
them can be traced back to something.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db


def _d(value: Any) -> Optional[Decimal]:
    return Decimal(str(value)) if value is not None else None


def _pct(value: Any) -> str:
    return f"{Decimal(str(value)):.1f}%" if value is not None else "—"


# ---------------------------------------------------------------------------
# How the funds have done
# ---------------------------------------------------------------------------


def fund_quality(investor_id: str) -> dict:
    """Each fund's record, and where it sits among the funds doing the same job.

    Category rank is the comparison that matters to somebody holding a fund.
    "Did it beat the Nifty" is the wrong question for a small-cap fund; "of the
    42 funds with the same mandate, where does mine come" is the right one.

    Rolling returns rather than trailing ones wherever possible. A fund's
    one-year number says as much about when you happened to look as about the
    fund. The median across every three-year window, the worst of them, and how
    often they were positive describes what holding it has actually been like.
    """
    rows = db.fetch_all(
        """
        SELECT i.id, i.name, i.native_code,
               v.current_value, v.invested_value,
               r.ret_1y, r.cagr_3y, r.cagr_5y,
               r.roll3_median, r.roll3_worst, r.roll3_pos_pct, r.roll3_windows,
               r.roll5_median, r.roll5_worst, r.roll5_pos_pct,
               r.cat_rank, r.cat_n, r.nav_date
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        LEFT JOIN scheme_returns r ON r.scheme_code = i.native_code
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )

    assessed: list[dict] = []
    unknown: list[str] = []

    for row in rows:
        if row["cat_rank"] is None and row["roll3_median"] is None:
            unknown.append(row["name"])
            continue

        # Where in the category, as a proportion. Lower is better.
        quartile = None
        if row["cat_rank"] and row["cat_n"]:
            position = Decimal(row["cat_rank"]) / Decimal(row["cat_n"])
            quartile = 1 if position <= Decimal("0.25") else \
                       2 if position <= Decimal("0.5") else \
                       3 if position <= Decimal("0.75") else 4

        assessed.append({
            "instrument_id": row["id"],
            "name": row["name"],
            "value": row["current_value"],
            "return_1y": row["ret_1y"],
            "cagr_3y": row["cagr_3y"],
            "cagr_5y": row["cagr_5y"],
            "rolling_3y_median": row["roll3_median"],
            "rolling_3y_worst": row["roll3_worst"],
            "rolling_3y_positive_pct": row["roll3_pos_pct"],
            "rolling_3y_windows": row["roll3_windows"],
            "rolling_5y_median": row["roll5_median"],
            "rolling_5y_worst": row["roll5_worst"],
            "category_rank": row["cat_rank"],
            "category_size": row["cat_n"],
            "quartile": quartile,
            "as_of": row["nav_date"],
        })

    return {
        "funds": assessed,
        "not_assessed": unknown,
        "note": (f"{len(unknown)} of your funds have no published record we hold yet."
                 if unknown else None),
    }


def laggards(investor_id: str) -> list[dict]:
    """Funds in the bottom quarter of their category.

    Stated as position rather than as a verdict. A fund can sit in the fourth
    quartile for three years and still be the right thing to hold -- a value
    fund through a growth market, for instance -- so this reports where it
    stands and leaves the conclusion to a person.
    """
    return [
        f for f in fund_quality(investor_id)["funds"]
        if f["quartile"] == 4 and f["category_size"] and f["category_size"] >= 10
    ]


# ---------------------------------------------------------------------------
# What the equity holdings are made of
# ---------------------------------------------------------------------------


def equity_fundamentals(investor_id: str) -> dict:
    """Valuation and quality for directly held shares.

    Only for shares held directly. What a fund holds is the fund manager's
    business; what somebody bought themselves is theirs.
    """
    rows = db.fetch_all(
        """
        SELECT i.name, i.symbol, i.isin, v.current_value, v.quantity,
               f.company_name, f.sector, f.industry, f.market_cap_category,
               f.pe_ttm, f.pb_ratio, f.peg_ratio, f.roe, f.roce,
               f.debt_to_equity, f.revenue_growth_yoy, f.pat_growth_yoy,
               f.dividend_yield, f.beta, f.high_52w
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        LEFT JOIN company_fundamentals f
               ON f.symbol = i.symbol OR f.isin = i.isin
        WHERE v.investor_id = %s AND i.asset_class = 'equity'
          AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )

    covered = [r for r in rows if r["company_name"]]
    total = sum(_d(r["current_value"]) or Decimal(0) for r in covered)

    # Weighted averages, which is the only honest way to describe a portfolio's
    # valuation: a small position on a high multiple should not drag the whole
    # picture.
    def weighted(field: str) -> Optional[Decimal]:
        weight = Decimal(0)
        running = Decimal(0)
        for row in covered:
            value = _d(row["current_value"]) or Decimal(0)
            figure = _d(row[field])
            if figure is not None and value > 0:
                running += figure * value
                weight += value
        return (running / weight) if weight > 0 else None

    return {
        "holdings": rows,
        "covered": len(covered),
        "total": len(rows),
        "weighted": {
            "pe": weighted("pe_ttm"),
            "pb": weighted("pb_ratio"),
            "roe": weighted("roe"),
            "debt_to_equity": weighted("debt_to_equity"),
            "revenue_growth": weighted("revenue_growth_yoy"),
            "dividend_yield": weighted("dividend_yield"),
            "beta": weighted("beta"),
        },
        "value": total,
    }


# ---------------------------------------------------------------------------
# What the whole portfolio is exposed to
# ---------------------------------------------------------------------------


# What a usable disclosure looks like.
#
# An equity fund's published holdings rarely sum to exactly a hundred: ten to
# fifteen per cent sits in cash, treasury bills and receivables that are not
# named as holdings. Quant Multi Cap sums to 85.7, HDFC Small Cap to 89.8 --
# both entirely normal, and an earlier 90% floor excluded them along with the
# genuinely broken ones.
#
# What is not usable is a disclosure with no weights at all (five funds here
# publish holdings without percentages) or one summing to 8,169% (one fund,
# wrong at source). Those are set aside and named.
#
# A debt fund is a separate case. ICICI Floating Interest sums to 47% because
# most of what it holds is money-market paper rather than companies -- the
# disclosure is fine, it simply has little equity to attribute.
WEIGHT_SUM_MIN = Decimal("70")
WEIGHT_SUM_MAX = Decimal("115")


def _usable_schemes() -> dict[str, Decimal]:
    """Schemes we can read through, and what their weights sum to.

    The sum is returned alongside because attribution normalises by it. A fund
    naming holdings worth 87 parts in 100 of itself still allocates its equity
    in those proportions; scaling to a hundred is what makes the sector shares
    right rather than uniformly understated.
    """
    rows = db.fetch_all(
        """
        WITH latest AS (
            SELECT scheme_code, max(as_of) AS as_of
            FROM scheme_constituents GROUP BY scheme_code
        )
        SELECT c.scheme_code, sum(c.weight_pct) AS weight_sum
        FROM scheme_constituents c
        JOIN latest l ON l.scheme_code = c.scheme_code AND l.as_of = c.as_of
        GROUP BY c.scheme_code
        HAVING sum(c.weight_pct) BETWEEN %s AND %s
        """,
        (WEIGHT_SUM_MIN, WEIGHT_SUM_MAX),
    )
    return {r["scheme_code"]: _d(r["weight_sum"]) or Decimal(100) for r in rows}


def sector_exposure(investor_id: str) -> dict:
    """Which industries the money is in, counting through the funds.

    A person holding four equity funds has sector exposure whether they think
    about it or not, and it is the fund managers' choices rather than theirs.
    Adding the funds' disclosed holdings to any directly held shares is the
    only way to see it.
    """
    # Directly held shares.
    direct = db.fetch_all(
        """
        WITH one_match AS (
            SELECT DISTINCT ON (v.instrument_id)
                   v.instrument_id, v.current_value,
                   coalesce(f.sector, 'Not classified') AS sector
            FROM v_current_holdings v
            JOIN instruments i ON i.id = v.instrument_id
            LEFT JOIN company_fundamentals f
                   ON (i.isin IS NOT NULL AND f.isin = i.isin)
                   OR (i.isin IS NULL AND i.symbol IS NOT NULL AND f.symbol = i.symbol)
            WHERE v.investor_id = %s AND i.asset_class = 'equity' AND v.current_value > 0
            ORDER BY v.instrument_id, f.isin NULLS LAST
        )
        SELECT sector, sum(current_value) AS value FROM one_match GROUP BY 1
        """,
        (investor_id,),
    )

    usable = _usable_schemes()

    # Held through funds: each fund's value spread across its disclosed
    # constituents by weight, then those companies mapped to sectors. Only
    # schemes whose weights add up; the rest are counted as unattributed rather
    # than distorting every share.
    # Two things here would silently inflate every figure if left alone.
    #
    # A scheme has several months of disclosures, so joining without pinning
    # the date multiplies each holding by the number of months on record. And
    # a company can match company_fundamentals on both ISIN and symbol, which
    # duplicates the row again. The portfolio came out at five crore against an
    # actual sixty-four lakh.
    #
    # So: pick each scheme's latest disclosure first, then attach at most one
    # sector per constituent.
    through_funds = db.fetch_all(
        """
        WITH latest AS (
            SELECT scheme_code, max(as_of) AS as_of
            FROM scheme_constituents
            GROUP BY scheme_code
        ),
        constituents AS (
            SELECT c.scheme_code, c.isin, c.symbol, c.instrument_name, c.weight_pct
            FROM scheme_constituents c
            JOIN latest l ON l.scheme_code = c.scheme_code AND l.as_of = c.as_of
        ),
        classified AS (
            SELECT DISTINCT ON (con.scheme_code, con.instrument_name)
                   con.scheme_code, con.weight_pct,
                   coalesce(f.sector, 'Not classified') AS sector
            FROM constituents con
            LEFT JOIN company_fundamentals f
                   ON (con.isin IS NOT NULL AND f.isin = con.isin)
                   OR (con.isin IS NULL AND con.symbol IS NOT NULL AND f.symbol = con.symbol)
            ORDER BY con.scheme_code, con.instrument_name, f.isin NULLS LAST
        ),
        totals AS (
            SELECT scheme_code, sum(weight_pct) AS weight_sum
            FROM classified GROUP BY scheme_code
        )
        SELECT cl.sector,
               -- Divided by the scheme's own sum, not by a hundred. A fund
               -- naming holdings worth 87 parts in 100 of itself still splits
               -- its equity in those proportions; dividing by a hundred would
               -- understate every sector by the same missing 13 parts.
               sum(v.current_value * cl.weight_pct / t.weight_sum) AS value
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        JOIN classified cl ON cl.scheme_code = i.native_code
        JOIN totals t ON t.scheme_code = cl.scheme_code AND t.weight_sum > 0
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0
          AND i.native_code = ANY(%s)
        GROUP BY 1
        """,
        (investor_id, list(usable)),
    )

    combined: dict[str, Decimal] = {}
    for row in list(direct) + list(through_funds):
        sector = row["sector"]
        combined[sector] = combined.get(sector, Decimal(0)) + (_d(row["value"]) or Decimal(0))

    total = sum(combined.values())
    ranked = sorted(
        ({"sector": k, "value": v,
          "share_pct": (str((v / total * 100).quantize(Decimal("0.1")))
                       if total else "0.0")}
         for k, v in combined.items()),
        key=lambda r: r["value"], reverse=True,
    )

    # What the portfolio is actually worth, so the caller can see whether the
    # attribution adds up. Funds whose constituents we do not hold contribute
    # nothing, so this will usually be less than the total -- but it should
    # never be more, and if it is, something is double counting.
    actual = db.fetch_one(
        "SELECT coalesce(sum(current_value), 0) AS total FROM v_current_holdings "
        "WHERE investor_id = %s",
        (investor_id,),
    )
    portfolio_total = _d(actual["total"]) or Decimal(0)

    # Which funds could not be read through, and what they are worth. Somebody
    # looking at a breakdown covering half their money should be told so
    # plainly, rather than shown a complete-looking chart of half the truth.
    unattributed = db.fetch_all(
        """
        SELECT i.name, v.current_value,
               CASE WHEN c.scheme_code IS NULL THEN 'no published holdings'
                    ELSE 'holdings published without weights' END AS why
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        LEFT JOIN (SELECT DISTINCT scheme_code FROM scheme_constituents) c
               ON c.scheme_code = i.native_code
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0
          AND NOT (i.native_code = ANY(%s))
        ORDER BY v.current_value DESC
        """,
        (investor_id, list(usable)),
    )

    return {
        "sectors": ranked,
        "total_attributed": total,
        "portfolio_total": portfolio_total,
        # Quantized. Unrounded this rendered as
        # "32.02764568903778061272892676% of the portfolio" on the page, which
        # is a Decimal escaping rather than a figure.
        "attributed_share_pct": (str((total / portfolio_total * 100)
                                     .quantize(Decimal("0.1")))
                                 if portfolio_total else None),
        "not_attributed": [
            {"name": r["name"], "value": r["current_value"], "why": r["why"]}
            for r in unattributed
        ],
        "not_attributed_value": sum(_d(r["current_value"]) or Decimal(0)
                                    for r in unattributed),
        "method": ("Directly held shares, plus each fund's value spread across the "
                   "companies it has disclosed holding, by weight. Funds whose "
                   "published weights do not add up to roughly a hundred are left "
                   "out rather than distorting the rest."),
    }


def concentration(investor_id: str) -> dict:
    """How spread out the money really is.

    The Herfindahl index is the standard measure and worth using because it is
    not arbitrary: it is the sum of squared shares, so it rises sharply when a
    few positions dominate and is comparable between portfolios of different
    sizes. Ten equal holdings score 1,000; one holding scores 10,000.
    """
    rows = db.fetch_all(
        """
        SELECT v.current_value FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0
        """,
        (investor_id,),
    )
    if not rows:
        return {"hhi": None, "positions": 0}

    total = sum(_d(r["current_value"]) or Decimal(0) for r in rows)
    if total <= 0:
        return {"hhi": None, "positions": len(rows)}

    shares = [(_d(r["current_value"]) or Decimal(0)) / total * 100 for r in rows]
    hhi = sum(s * s for s in shares)

    # The number of equally-sized holdings that would give the same score.
    # Easier to grasp than the index itself: "as spread out as six equal
    # holdings" means something to a reader in a way that "1,647" does not.
    effective = (Decimal(10000) / hhi) if hhi > 0 else Decimal(0)

    sectors = sector_exposure(investor_id)["sectors"]
    sector_hhi = sum((_d(s["share_pct"]) or Decimal(0)) ** 2 for s in sectors)

    return {
        "hhi": hhi.quantize(Decimal("1")),
        "effective_holdings": effective.quantize(Decimal("0.1")),
        "positions": len(rows),
        "sector_hhi": sector_hhi.quantize(Decimal("1")) if sectors else None,
        "sector_count": len(sectors),
        "reading": ("concentrated" if hhi > 2500 else
                    "somewhat concentrated" if hhi > 1500 else "spread out"),
        "method": ("Herfindahl index: the sum of each holding's squared percentage "
                   "share. Ten equal holdings would score 1,000."),
    }
