"""Answers that are computations.

Every function here returns a sentence built from figures the platform already
holds. No model, no prompt, no context window — so no possibility of the answer
drifting from what the dashboard says, because both read the same value.

That is the point. A portfolio assistant that generates *"your portfolio is
worth about thirty-four lakh"* from a context window is doing something
strictly worse than reading the number: it costs money, it takes a second, and
it can be wrong in a way nobody notices until somebody checks.

**The writing matters as much as the number.** These are the answers people ask
for most, so they should read like a person who knows the portfolio, not like a
field lookup. "₹33,87,247" answers the question; "₹33,87,247, up 66% on what
you put in, across 23 holdings" answers it the way somebody would.

**And each says what it cannot see.** A tax figure computed from holdings whose
purchase dates we inferred is worth having and worth qualifying, and the
qualification belongs in the answer rather than in a footnote nobody reads.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Callable, Optional

log = logging.getLogger("alphanivesh.ariv.answers")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def worth(investor_id: str) -> dict:
    """What it is worth, and what went in."""
    from . import debts, wealth

    summary = wealth.net_worth(investor_id)
    total = _d(summary.get("total_value"))
    invested = _d(summary.get("invested_value"))
    gain = total - invested
    owed = debts.for_investor(investor_id)

    line = (f"{_money(total)} across {summary.get('positions')} holdings, "
            f"against {_money(invested)} put in — "
            f"{'up' if gain >= 0 else 'down'} {_money(abs(gain))}.")

    if owed["recorded"] and _d(owed["total"]) > 0:
        net = total - _d(owed["total"])
        line += (f" Less {_money(owed['total'])} owed, that is {_money(net)} net.")
    elif not owed["recorded"]:
        line += (" That is what you hold rather than what you are worth — we "
                 "do not know what you owe.")

    return {"answer": line,
            "basis": {"total": str(total), "invested": str(invested),
                      "positions": summary.get("positions"),
                      "owed": owed.get("total") if owed["recorded"] else None}}


def gain(investor_id: str) -> dict:
    """The gain, with the caveat that makes it honest."""
    from . import wealth

    summary = wealth.net_worth(investor_id)
    total = _d(summary.get("total_value"))
    invested = _d(summary.get("invested_value"))
    made = total - invested
    pct = (made / invested * 100) if invested > 0 else Decimal(0)

    line = (f"{'Up' if made >= 0 else 'Down'} {_money(abs(made))}, which is "
            f"{abs(pct):.1f}% on the {_money(invested)} we can account for.")

    cagr = summary.get("cagr_pct")
    years = summary.get("held_years")
    if cagr and years:
        line += (f" Between the first holding we can date and today that is "
                 f"{cagr}% a year over {years} years — growth between two "
                 f"dates, which is not the same as the return on money that "
                 f"arrived in instalments.")

    return {"answer": line,
            "basis": {"gain": str(made), "pct": str(pct.quantize(Decimal('0.1'))),
                      "invested": str(invested)}}


def tax(investor_id: str) -> dict:
    """What selling would cost, and the exemption most people forget."""
    from . import harvest
    from ..routers.dashboard import _tax_shape

    try:
        position = _tax_shape(investor_id)
    except Exception:
        position = None

    if not position:
        return {"answer": "I cannot work that out without knowing when you "
                          "bought things, and we do not hold those dates.",
                "basis": {}}

    line = (f"About {_money(position['estimated_tax'])} if you sold everything "
            f"today. Short-term gains of {_money(position['short_term_gain'])} "
            f"at 20%, long-term of {_money(position['long_term_gain'])} at "
            f"12.5% after the ₹1.25 lakh annual exemption.")

    try:
        chance = harvest.opportunity(investor_id)
    except Exception:
        chance = None

    if chance and chance.get("worth_doing"):
        line += (f" Worth knowing: {_money(chance['available_gain'])} of that "
                 f"long-term gain could be realised tax-free before March, "
                 f"saving about {_money(chance['saving'])}. The allowance does "
                 f"not carry forward.")

    return {"answer": line, "basis": position}


def largest(investor_id: str) -> dict:
    """The holding that decides the result."""
    from . import wealth

    holdings = wealth.holdings(investor_id)
    live = [h for h in holdings if _d(h.get("current_value")) > 0]
    if not live:
        return {"answer": "There is nothing here yet.", "basis": {}}

    live.sort(key=lambda h: -_d(h["current_value"]))
    top = live[0]
    total = sum((_d(h["current_value"]) for h in live), Decimal(0))
    share = _d(top["current_value"]) / total * 100 if total > 0 else Decimal(0)

    line = (f"{top['instrument_name']}, worth {_money(top['current_value'])} — "
            f"{share:.1f}% of everything you hold.")
    if share >= 20:
        line += (" A position that size means your overall result is mostly a "
                 "bet on this one, however good it is.")

    return {"answer": line,
            "basis": {"name": top["instrument_name"],
                      "value": str(_d(top["current_value"])),
                      "share_pct": str(share.quantize(Decimal("0.1")))}}


def what_to_do(investor_id: str) -> dict:
    """The first thing, and why that first."""
    from . import decide

    decision = decide.decide(investor_id)
    if decision.get("empty"):
        return {"answer": decision.get("why", "Nothing to work with yet."),
                "basis": {}}

    first = decision.get("first")
    health = decision.get("health") or {}

    if not first:
        return {"answer": health.get("reading",
                                     "Nothing here needs acting on."),
                "basis": {"health": health}}

    line = f"{first['what']} {first['why']}"
    if first.get("impact"):
        line += f" {first['impact']}"

    others = len(decision.get("actions") or []) - 1
    if others > 0:
        line += (f" There {'are' if others != 1 else 'is'} {others} other "
                 f"thing{'s' if others != 1 else ''} worth doing after that.")

    return {"answer": line,
            "basis": {"health": health, "first": first,
                      "risk": decision.get("risk")}}


def commission(investor_id: str) -> dict:
    """What the regular plans cost."""
    from . import plans

    try:
        summary = plans.summary(investor_id)
    except Exception:
        summary = None

    if not summary or not summary.get("funds"):
        return {"answer": "Nothing you hold is on a regular plan, so you are "
                          "not paying trail commission on any of it.",
                "basis": {}}

    return {"answer": summary["reading"],
            "basis": {"annual": summary.get("total_a_year"),
                      "funds": len(summary.get("funds") or [])}}


def holdings(investor_id: str) -> dict:
    """What is held, summarised rather than listed.

    Twenty-three holdings read aloud is not an answer. The shape is.
    """
    from . import wealth

    rows = wealth.holdings(investor_id)
    live = [h for h in rows if _d(h.get("current_value")) > 0]
    if not live:
        return {"answer": "Nothing yet.", "basis": {}}

    by_class: dict[str, Decimal] = {}
    for holding in live:
        kind = holding.get("asset_class") or "other"
        by_class[kind] = by_class.get(kind, Decimal(0)) + _d(holding["current_value"])

    total = sum(by_class.values(), Decimal(0))
    parts = sorted(by_class.items(), key=lambda kv: -kv[1])

    described = ", ".join(
        f"{_money(value)} in {kind.replace('_', ' ')}"
        for kind, value in parts[:3])

    return {"answer": (f"{len(live)} holdings worth {_money(total)}: {described}"
                       + ("." if len(parts) <= 3 else
                          f", and {len(parts) - 3} other kinds.")),
            "basis": {"count": len(live),
                      "by_class": {k: str(v) for k, v in by_class.items()}}}


def sectors(investor_id: str) -> dict:
    """What the money is exposed to, counting through the funds."""
    from . import analysis

    try:
        exposure = analysis.sector_exposure(investor_id)
    except Exception:
        exposure = None

    listed = [s for s in ((exposure or {}).get("sectors") or [])
              if (s.get("sector") or "").lower() != "not classified"]
    if not listed:
        return {"answer": "We cannot see through to the companies behind your "
                          "holdings well enough to say.", "basis": {}}

    top = listed[0]
    line = (f"{_d(top['share_pct']):.0f}% in "
            f"{(top['sector'] or '').lower()}, counting through what your funds "
            f"hold as well as the shares you own directly.")

    if _d(top["share_pct"]) >= 40:
        line += (" Holdings that look separate can be the same bet: when that "
                 "industry has a bad year, most of the portfolio has one.")

    others = ", ".join(f"{(s['sector'] or '').lower()} {_d(s['share_pct']):.0f}%"
                       for s in listed[1:4])
    if others:
        line += f" Then {others}."

    return {"answer": line,
            "basis": {"top": top,
                      "seen_pct": (exposure or {}).get("attributed_share_pct")}}


def owed(investor_id: str) -> dict:
    """What is owed, or that we do not know."""
    from . import debts

    position = debts.for_investor(investor_id)
    return {"answer": position["reading"],
            "basis": {"total": position.get("total"),
                      "recorded": position["recorded"]}}


def benchmark(investor_id: str) -> dict:
    """Against simply buying the market."""
    from ..routers.dashboard import _benchmark

    try:
        against = _benchmark(investor_id)
    except Exception:
        against = None

    if not against:
        return {"answer": "We cannot compare that without knowing when you "
                          "started.", "basis": {}}

    ahead = against.get("ahead")
    line = (f"{'Ahead by' if ahead else 'Behind by'} "
            f"{_money(abs(_d(against['difference'])))}. The same money into "
            f"NIFTYBEES on the same dates would be "
            f"{_money(against['index_value'])} today, against "
            f"{_money(against['your_value'])} here, over "
            f"{against.get('years')} years.")

    return {"answer": line, "basis": against}


# The key from the router maps to the function that answers it.
ANSWERS: dict[str, Callable[[str], dict]] = {
    "worth": worth,
    "gain": gain,
    "tax": tax,
    "largest": largest,
    "what_to_do": what_to_do,
    "commission": commission,
    "holdings": holdings,
    "sectors": sectors,
    "owed": owed,
    "benchmark": benchmark,
}


def answer(key: str, investor_id: str) -> Optional[dict]:
    """Produce one, or nothing if the key has no answer.

    Nothing rather than an apology: a caller that gets None can fall through to
    the model, which is a better outcome than a deterministic "I cannot answer
    that" for a question a model could handle.
    """
    fn = ANSWERS.get(key)
    if not fn:
        return None
    try:
        return fn(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("deterministic answer %s failed: %s", key, err)
        return None
