"""Deciding what a question needs.

Most questions somebody asks about their own portfolio have exact answers we
have already computed. *What is it worth. How much tax if I sell. What is my
largest holding. What should I do first.* Sending those to a model is worse in
every way that matters: it costs money, it adds a second of latency, and it
introduces the possibility of a wrong answer to a question that has a right
one.

So the router asks a cheaper question first — **can this be answered by
looking it up?** — and only what survives that goes to a model.

Three things follow from it.

**Deterministic answers cannot drift.** The answer is the computation. There is
no prompt to get wrong, no context to truncate, and the same question tomorrow
gives the same answer unless the underlying number changed.

**Cost falls by roughly the share of questions that route this way**, which on
a portfolio assistant should be most of them. That is a better lever than a
cheaper model: a weaker model on financial advice under a licence saves
pennies and risks a wrong answer that costs far more.

**And the refusals live here rather than in a prompt.** A question about where
the market is going gets the same answer whether or not a model is available,
because the platform does not forecast and that is a property of the platform
rather than of its phrasing.

**What this cannot do** is understand a question it has no pattern for. The
matching is deliberately conservative: an unmatched question goes to the model
with a proper context, which is the safe direction. Matching too eagerly would
answer the wrong question confidently, which is the failure worth avoiding.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Callable, Optional

log = logging.getLogger("alphanivesh.ariv.router")


class Route:
    """How a question will be answered."""
    LOOKUP = "deterministic"    # answered from a computation
    GENERATE = "generated"      # needs a model, with grounding
    REFUSE = "refused"          # outside what this platform will answer


# ---------------------------------------------------------------------------
# What the platform will not answer
# ---------------------------------------------------------------------------
#
# These are the engine's own refusals, inherited rather than restated. Ariv
# does not get to route around them because somebody asked conversationally --
# a forecast is a forecast whether it arrives through a chart or a sentence.

REFUSALS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r"\b(will|going to|gonna)\b.*\b(market|nifty|sensex|price|stock|fund)\b"
                r".*\b(go up|go down|rise|fall|crash|rally|recover)\b|"
                r"\b(market|nifty|sensex)\b.*\b(forecast|prediction|outlook for|"
                r"where.*head|next year|next month)\b", re.I),
     "forecast",
     "This platform does not forecast, and I am not going to start. What I can "
     "tell you is where the market sits now and what has followed readings like "
     "it — counted from history, with the number of windows attached, so you "
     "can see how much it rests on."),

    (re.compile(r"\b(score|rate|grade)\b.*\b(my portfolio|out of|/10|/100)\b|"
                r"\bhealth score\b|\bhow good is my portfolio\b", re.I),
     "composite_score",
     "There is no score here on purpose. A single number needs weights nobody "
     "can derive and hides which measure is driving it. What I can give you is "
     "the count: what is urgent, what is leaking, what is worth doing when you "
     "have time — and each of those opens into the thing it counts."),

    (re.compile(r"\bshould i (buy|invest in|get into)\b(?!.*\b(more|instead)\b)|"
                r"\bis \w+ a good (buy|stock|investment)\b|"
                r"\bwhat.*(hot|best) (stock|share)s? (now|today|right now)\b", re.I),
     "unrated_recommendation",
     "I can only give you a verdict on something this platform has actually "
     "computed one for — the shares you hold, and the funds our screener "
     "covers. On anything else I would be guessing, and a guess that sounds "
     "confident is worse than no answer."),

    (re.compile(r"\b(income tax|itr|file.*return|80c|hra|salary.*tax|"
                r"tax slab|old regime|new regime)\b", re.I),
     "income_tax",
     "Capital gains on your holdings I can work out. Income tax is a different "
     "question and not one this platform computes — worth an accountant rather "
     "than a guess from me."),

    (re.compile(r"\b(should i|is it worth).*(loan|borrow|mortgage|emi)\b.*"
                r"\b(invest|market|equity)\b|"
                r"\bborrow.*to invest\b|\bleverage\b", re.I),
     "leverage",
     "Borrowing to invest is not something this platform will advise on. The "
     "arithmetic can look attractive and the failure case is losing money you "
     "did not have — that is a conversation for a person who knows your whole "
     "situation, not a tool."),
]


# ---------------------------------------------------------------------------
# What can be answered by looking it up
# ---------------------------------------------------------------------------
#
# Each pattern maps to a function that produces the answer from computed
# values. Ordered by how commonly the question is asked, since the first match
# wins and the common cases should not sit behind the rare ones.

LOOKUPS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b(what|how much).*(worth|value|total|net worth|portfolio)\b|"
                r"\bhow much (do i have|money)\b", re.I),
     "worth"),

    (re.compile(r"\bhow (much|many).*(gain|profit|made|up|return)\b|"
                r"\b(am i|have i) (up|down|made|lost)\b|"
                r"\bwhat.*my (return|gain|profit)\b", re.I),
     "gain"),

    (re.compile(r"\b(tax|capital gain).*(if i sell|selling|owe|pay)\b|"
                r"\bhow much tax\b", re.I),
     "tax"),

    (re.compile(r"\b(largest|biggest|top).*(holding|position|stock|fund)\b|"
                r"\bwhat.*most of my money\b", re.I),
     "largest"),

    (re.compile(r"\bwhat should i do\b|\bwhat.*first\b|"
                r"\b(any|what).*(action|recommend|suggest)\b", re.I),
     "what_to_do"),

    (re.compile(r"\b(commission|regular plan|direct plan|expense|fee)\b.*"
                r"\b(pay|cost|much)\b|\bhow much.*commission\b", re.I),
     "commission"),

    (re.compile(r"\bwhat (do i|am i) (hold|own)\b|\blist.*(holding|fund|stock)\b|"
                r"\bhow many (holding|fund|stock)\b", re.I),
     "holdings"),

    (re.compile(r"\b(sector|industry|exposed|concentration|diversif)\b", re.I),
     "sectors"),

    (re.compile(r"\b(owe|debt|loan|liabilit)\b", re.I),
     "owed"),

    (re.compile(r"\bhow (am i|have i) (doing|performed)\b.*\b(index|nifty|market)\b|"
                r"\b(beat|against|versus|vs).*\b(index|nifty|market)\b", re.I),
     "benchmark"),
]


# Asking for an explanation is not asking for a figure.
#
# "Explain the sector concentration more simply" contains the word sector and
# matched the sector lookup, which would have returned the percentages -- a
# confident answer to a question nobody asked. Somebody asking why, or how, or
# for something restated wants reasoning, and reasoning is what a model is for.
WANTS_REASONING = re.compile(
    r"\b(why|explain|how come|what do you mean|in simple|simpler|more simply|"
    r"break.*down|help me understand|elaborate|what does that mean|"
    r"how did you|where.*get that|are you sure|justify)\b", re.I)


def classify(question: str) -> tuple[str, Optional[str], Optional[str]]:
    """Which route this question takes.

    Returns (route, key, message). For a refusal the message is what to say;
    for a lookup the key names the answer to produce; for generation both are
    None and the question goes to a model with a grounding context.

    Refusals are checked first. A question that both asks for a forecast and
    mentions a holding is still a forecast, and the order decides which wins.
    """
    text = (question or "").strip()
    if not text:
        return Route.REFUSE, "empty", "Ask me something about your portfolio."

    if len(text) > 500:
        return (Route.REFUSE, "too_long",
                "That is longer than I can work with. What is the one thing you "
                "want to know?")

    for pattern, key, message in REFUSALS:
        if pattern.search(text):
            log.info("refusing (%s): %s", key, text[:60])
            return Route.REFUSE, key, message

    # Reasoning beats lookup. A question containing both a topic word and a
    # request to explain is asking about the reasoning, not for the figure.
    if WANTS_REASONING.search(text):
        log.info("generating (asked for reasoning): %s", text[:60])
        return Route.GENERATE, None, None

    for pattern, key in LOOKUPS:
        if pattern.search(text):
            log.info("lookup (%s): %s", key, text[:60])
            return Route.LOOKUP, key, None

    log.info("generating: %s", text[:60])
    return Route.GENERATE, None, None


def is_about_portfolio(question: str) -> bool:
    """Whether this is a question this platform has any business answering.

    Not a safety check -- the refusal list does that. This catches the
    conversational drift that a long session produces: somebody who started
    asking about their funds and ended up asking about the weather has left the
    thing Ariv is for, and continuing to answer is how an assistant becomes a
    chatbot.
    """
    text = (question or "").lower()

    portfolio_words = (
        "portfolio", "holding", "fund", "stock", "share", "equity", "invest",
        "sip", "tax", "gain", "loss", "return", "sell", "buy", "market",
        "nifty", "sector", "risk", "allocation", "money", "worth", "value",
        "debt", "loan", "owe", "emergency", "goal", "retire", "commission",
        "direct", "regular", "nav", "dividend", "rebalance", "diversif",
        "my ", "i own", "i hold", "should i", "what do i",
    )
    return any(word in text for word in portfolio_words)
