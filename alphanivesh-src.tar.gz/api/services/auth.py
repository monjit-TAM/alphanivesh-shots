"""Accounts, sessions, and who is allowed to see whose money.

The last part is the one that matters. Everything in this platform is somebody's
financial position, so every read has to be scoped to the person asking. That
scope is decided here, in one place, rather than being reimplemented in each
route.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import logging

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError

from .. import db

# Argon2id with the library's defaults, which track current guidance. Password
# hashing is one of the few places where using the well-trodden default is
# straightforwardly better than having an opinion.
log = logging.getLogger("alphanivesh.auth")

_hasher = PasswordHasher()

SESSION_TTL = timedelta(days=14)
SESSION_COOKIE = "an_session"


class AuthError(Exception):
    """Raised for anything a caller is allowed to be told about."""


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Accounts
# ---------------------------------------------------------------------------


def register(email: str, password: str, full_name: str,
             role: str = "investor", firm_name: Optional[str] = None,
             sebi_reg_number: Optional[str] = None,
             ref: Optional[str] = None) -> dict:
    email = (email or "").strip()
    full_name = (full_name or "").strip()

    if "@" not in email or "." not in email.split("@")[-1]:
        raise AuthError("Enter a valid email address.")
    if len(password or "") < 10:
        raise AuthError("Please choose a password of at least 10 characters. "
                        "A short phrase you will remember works well.")
    if not full_name:
        raise AuthError("Enter your name.")
    # Three, not two.
    #
    # A distributor picking "advisor" because it is the only professional
    # option gets an advisory agreement and rights they are not registered
    # for. Distribution and advice are separate registrations and the very
    # first form has to know the difference, because everything after it
    # follows from this answer.
    if role not in ("investor", "advisor", "distributor"):
        # Admin accounts are made deliberately, not through the signup form.
        raise AuthError("Choose whether you are an investor, an adviser, or "
                        "a distributor.")

    existing = db.fetch_one("SELECT id FROM users WHERE lower(email) = lower(%s)", (email,))
    if existing:
        raise AuthError("An account with that email already exists.")

    row = db.fetch_one(
        """
        INSERT INTO users (email, password_hash, full_name, role, firm_name, sebi_reg_number)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING id, email, full_name, role, firm_name, created_at
        """,
        (email, _hasher.hash(password), full_name, role, firm_name, sebi_reg_number),
    )

    # A portfolio to put holdings in.
    #
    # Signing up made a user and nothing else, so an adviser could hand out a
    # link, somebody could come through it, and there was nothing to attach
    # them to. Nobody noticed because an account without a portfolio looks
    # fine until you go looking for the client you brought.
    #
    # Made here rather than in the router so it happens however somebody signs
    # up -- password, Google, or whatever is added next.
    if role == "investor":
        try:
            _make_portfolio(row["id"], full_name, email, ref)
        except Exception as err:                                 # pragma: no cover
            log.error("NO PORTFOLIO MADE for %s: %s", email, err)

    try:
        from . import accounts
        accounts.send_verification(row["id"], email, full_name)
    except Exception as err:                                     # pragma: no cover
        log.error("VERIFICATION NOT SENT to %s: %s", email, err)

    return row


def _make_portfolio(user_id: str, full_name: str, email: str,
                    ref: Optional[str]) -> None:
    """The investor record, and who brought them.

    A code that does not resolve makes them a direct investor rather than
    failing the signup. They came to us with a code that no longer works,
    which makes them exactly as direct as somebody who arrived with none.
    """
    from . import referrals

    came_from = referrals.whose(ref) if ref else None

    with db.connection() as conn:
        investor = conn.execute(
            """
            INSERT INTO investors (kind, display_name, email, owner_user_id,
                                   is_direct, came_via)
            VALUES ('individual', %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (full_name or email.split("@")[0], email, user_id,
             came_from is None,
             came_from["code_id"] if came_from else None),
        ).fetchone()

        if came_from:
            # Into the adviser's book. Consent is deliberately null: they have
            # not agreed anything yet, and the book shows that as the first
            # thing needing attention.
            conn.execute(
                """
                INSERT INTO client_of
                    (professional_id, investor_id, came_by)
                VALUES (%s, %s, 'introduced')
                """,
                (came_from["professional_id"], investor["id"]))

    if came_from:
        referrals.note_used(came_from["code_id"])
        log.info("investor %s arrived via %s", investor["id"],
                 came_from["firm_name"])


def authenticate(email: str, password: str) -> dict:
    row = db.fetch_one(
        "SELECT id, email, password_hash, full_name, role, is_active FROM users "
        "WHERE lower(email) = lower(%s)",
        ((email or "").strip(),),
    )

    # The same message whether the address is unknown or the password is wrong.
    # Distinguishing them tells an attacker which addresses are registered.
    generic = AuthError("Those details do not match an account.")

    if row is None:
        # Spend roughly the time a real verification would, so the response
        # time does not reveal whether the address exists.
        _hasher.hash("timing-equalisation")
        raise generic
    if not row["is_active"]:
        raise AuthError("This account has been disabled.")

    try:
        _hasher.verify(row["password_hash"], password or "")
    except (VerifyMismatchError, VerificationError):
        raise generic

    if _hasher.check_needs_rehash(row["password_hash"]):
        db.fetch_one(
            "UPDATE users SET password_hash = %s WHERE id = %s RETURNING id",
            (_hasher.hash(password), row["id"]),
        )

    db.fetch_one("UPDATE users SET last_login_at = now() WHERE id = %s RETURNING id", (row["id"],))
    return {k: row[k] for k in ("id", "email", "full_name", "role")}


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------


def open_session(user_id: str, user_agent: Optional[str], ip: Optional[str]) -> str:
    """Start a session and return the token to put in the cookie."""
    token = secrets.token_urlsafe(32)
    db.fetch_one(
        """
        INSERT INTO sessions (user_id, token_hash, user_agent, ip_address, expires_at)
        VALUES (%s, %s, %s, %s, %s)
        RETURNING id
        """,
        (user_id, _hash_token(token), (user_agent or "")[:400], ip, _now() + SESSION_TTL),
    )
    return token


def resolve_session(token: Optional[str]) -> Optional[dict]:
    """Return the signed-in user for a cookie value, or None."""
    if not token:
        return None

    row = db.fetch_one(
        """
        SELECT s.id AS session_id, u.id, u.email, u.full_name, u.role, u.is_active
        FROM sessions s
        JOIN users u ON u.id = s.user_id
        WHERE s.token_hash = %s
          AND s.revoked_at IS NULL
          AND s.expires_at > now()
        """,
        (_hash_token(token),),
    )
    if row is None or not row["is_active"]:
        return None

    db.fetch_one(
        "UPDATE sessions SET last_seen_at = now() WHERE id = %s RETURNING id",
        (row["session_id"],),
    )
    return {k: row[k] for k in ("id", "email", "full_name", "role")}


def close_session(token: Optional[str]) -> None:
    if not token:
        return
    db.fetch_one(
        "UPDATE sessions SET revoked_at = now() WHERE token_hash = %s AND revoked_at IS NULL "
        "RETURNING id",
        (_hash_token(token),),
    )


# ---------------------------------------------------------------------------
# Access scope
# ---------------------------------------------------------------------------


def visible_investor_ids(user: dict) -> Optional[list[str]]:
    """Which investors this user may read.

    Returns a list of ids, or None meaning no restriction (admin only).
    An empty list means the user can see nothing, which is the correct
    starting position for a new account that has not imported anything.

      investor  their own records, by ownership
      advisor   their own records, plus clients they hold a live mandate for
      admin     everything

    Callers must treat an empty list as "no rows", never as "no filter". That
    mistake would turn a new user's empty dashboard into everybody's data.
    """
    if user["role"] == "admin":
        return None

    rows = db.fetch_all(
        "SELECT id FROM investors WHERE owner_user_id = %s", (user["id"],)
    )
    ids = [r["id"] for r in rows]

    if user["role"] == "advisor":
        clients = db.fetch_all(
            """
            SELECT investor_id FROM advisory_relationships
            WHERE advisor_user_id = %s AND is_active AND revoked_at IS NULL
            """,
            (user["id"],),
        )
        ids.extend(c["investor_id"] for c in clients)

    return sorted(set(ids))


def may_see(user: dict, investor_id: str) -> bool:
    scope = visible_investor_ids(user)
    return scope is None or investor_id in scope


def claim_investor(user_id: str, investor_id: str) -> None:
    """Attach an unowned investor record to a user.

    Used when someone imports a statement that resolves to an investor already
    in the system from an earlier migration. Only unowned records can be
    claimed; anything already belonging to someone else needs a human to look
    at it, because two people claiming one PAN is either a family sharing an
    email or a mistake worth catching.
    """
    updated = db.fetch_one(
        """
        UPDATE investors SET owner_user_id = %s
        WHERE id = %s AND owner_user_id IS NULL
        RETURNING id
        """,
        (user_id, investor_id),
    )
    if updated is None:
        raise AuthError("That investor record is already linked to another account.")
