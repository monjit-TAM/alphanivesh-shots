"""What changed while you were away.

The problem this answers: prices move daily, holdings change on import, and the
advice barely changes at all. A portfolio in good order gives the same answer
next week. That is honest, and it is not a reason to come back.

So rather than manufacturing news, this reports what actually happened in the
reader's absence — and scales with how long that was. A day away is a line. A
quarter away is a briefing.

**What it will not do.** It will not pad. A week where nothing happened says
nothing happened, because a summary that always finds five things has stopped
distinguishing between finding something and having something to say. It will
not report a price move as an event: a portfolio that rose 2% because the
market rose 2% is not news, and calling it news trains people to ignore the
ones that matter.

**What counts as worth saying** is a change somebody did not make and would
want to know about: a holding crossing the long-term tax boundary, a position
growing past a fifth of the portfolio through price alone, the financial year
running out with an allowance unused, a standing instruction that stopped.

Each of those has a consequence and a deadline. That is the test.

**One thing missing on purpose.** What the funds themselves bought and sold
each month would be the best section here — an investor whose exposure to one
bank went from a quarter to a third because three managers bought it made no
decision and would want to know. The disclosure coverage does not support it
yet: two funds in twelve have month-over-month holdings. The section is
designed for and left out rather than shipped mostly empty.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.away")

# Below this a price move is weather rather than news.
MOVE_WORTH_SAYING = Decimal("5")

# A position past this share decides the portfolio's result.
HEAVY = Decimal("20")

# Long enough away that the summary should read as a briefing.
LONG_ABSENCE_DAYS = 30


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


# A visit is a burst of records, not one. Loading the dashboard writes a
# decision, a guide, findings and a buy plan within a second of each other, so
# anything closer together than this is the same visit.
SAME_VISIT_MINUTES = 30


def _last_seen(investor_id: str) -> Optional[datetime]:
    """When this investor was last here — before today.

    The obvious version of this was wrong in a way that made the panel
    impossible: rendering the dashboard writes to the advice ledger, and this
    read the ledger to decide when somebody last visited. Every visit reset
    the clock, so "while you were away" could never fire.

    So: group the records into visits, and return the one before the current
    one. Somebody arriving now is mid-visit; what they want to know is what
    changed since the visit before it.
    """
    rows = db.fetch_all(
        """
        SELECT shown_at FROM advice_ledger
        WHERE investor_id = %s AND surface IN ('dashboard', 'advice_page')
        ORDER BY shown_at DESC LIMIT 400
        """,
        (investor_id,),
    )
    if len(rows) < 2:
        return None

    gap = timedelta(minutes=SAME_VISIT_MINUTES)
    # Walk back until the records stop being consecutive. The first big gap is
    # the boundary of the current visit; what precedes it is the previous one.
    previous = rows[0]["shown_at"]
    for row in rows[1:]:
        if previous - row["shown_at"] > gap:
            return row["shown_at"]
        previous = row["shown_at"]

    # Every record we hold is one visit -- a first-time reader, and there is
    # nothing to have been away from.
    return None


def since_last_visit(investor_id: str) -> Optional[dict]:
    """What happened while they were gone, or nothing if nothing did.

    Returns None for a first visit and for somebody who was here an hour ago.
    Both are correct: there is no "while you were away" for somebody who never
    left, and inventing one is how a useful thing becomes noise.
    """
    last = _last_seen(investor_id)
    if not last:
        return None

    away = datetime.now(last.tzinfo) - last
    days = away.days

    # Same session, near enough. Nothing has happened.
    if days < 1:
        return None

    changes: list[dict] = []
    changes += _value_moved(investor_id, last.date())
    changes += _crossed_a_threshold(investor_id)
    changes += _turned_long_term(investor_id)
    changes += _year_running_out(investor_id)
    changes += _instalments_stopped(investor_id)
    changes += _idle_money(investor_id, days)
    changes += _what_the_gap_cost(investor_id, days)
    changes += _left_on_the_table(investor_id, days)

    if not changes:
        return {
            "away_days": days,
            "quiet": True,
            "reading": (f"Nothing has needed your attention in the "
                        f"{_describe_absence(days)} since you were last here. "
                        f"That is worth saying rather than filling the space: "
                        f"a portfolio that does not need watching is the point."),
        }

    ordered = sorted(changes, key=lambda c: -c.get("weight", 0))

    return {
        "away_days": days,
        "quiet": False,
        "last_here": last.date().isoformat(),
        "changes": ordered,
        "reading": _reading(ordered, days),
        "briefing": days >= LONG_ABSENCE_DAYS,
    }


def _describe_absence(days: int) -> str:
    if days == 1:
        return "day"
    if days < 7:
        return f"{days} days"
    if days < 14:
        return "week"
    if days < 45:
        return f"{days // 7} weeks"
    if days < 365:
        return f"{days // 30} months"
    return "year or more"


def _reading(changes: list[dict], days: int) -> str:
    first = changes[0]
    return (f"{len(changes)} thing{'s' if len(changes) != 1 else ''} changed in "
            f"the {_describe_absence(days)} you were away. "
            f"{first['headline']}")



# ---------------------------------------------------------------------------
# What it cost to have been away, and what was left on the table
# ---------------------------------------------------------------------------

# What a debt fund would reasonably have returned, annualised. Used only to
# price idle cash against the obvious alternative -- not a recommendation and
# not a promise, which is why it is stated rather than buried.
DEBT_FUND_PCT = Decimal("7")

# What a liquid fund pays, roughly. The gap between this and the above is the
# cost of leaving money parked longer than it needed to be.
LIQUID_PCT = Decimal("6")


def _idle_money(investor_id: str, days: int) -> list[dict]:
    """Money that sat in liquid funds longer than liquid funds are for.

    Liquid funds are for money about to be used. Money that sits in one for a
    quarter is money earning the least of any option available to it, and the
    cost is small per month and real over a year.

    Costed against a debt fund rather than against equity, because the
    comparison has to be like for like: somebody keeping money safe should be
    shown what safe money could have earned, not what risk would have paid.
    """
    if days < 30:
        return []

    rows = db.fetch_all(
        """
        SELECT v.instrument_name, v.current_value
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
          AND (i.name ILIKE '%%liquid%%' OR i.name ILIKE '%%overnight%%'
               OR i.category ILIKE '%%liquid%%')
        """,
        (investor_id,),
    )
    if not rows:
        return []

    parked = sum((_d(r["current_value"]) for r in rows), Decimal(0))
    if parked < Decimal("100000"):
        return []

    # What the difference would have been over the period they were away.
    forgone = parked * (DEBT_FUND_PCT - LIQUID_PCT) / 100 * Decimal(days) / 365
    if forgone < Decimal("1000"):
        return []

    return [{
        "kind": "idle_money",
        "weight": float(forgone),
        "headline": (f"{_money(parked)} has been sitting in liquid funds for "
                     f"the {_describe_absence(days)} you were away."),
        "detail": (f"Liquid funds are for money you are about to use. Held "
                   f"this long, the difference against a short-duration debt "
                   f"fund is roughly {_money(forgone)} — small in itself and "
                   f"repeating every month it stays there. If this money is "
                   f"earmarked for something soon that is exactly right; if it "
                   f"is not, it is working less hard than it could."),
        "tone": "warn",
    }]


def _what_the_gap_cost(investor_id: str, days: int) -> list[dict]:
    """What not holding something cost while they were away.

    The only shape in which market movement belongs in a personal summary.
    "Gold rose twelve per cent" is commentary; "gold rose twelve per cent while
    everything you hold fell together, and you hold none" is about their
    portfolio and points at something they can still do.

    So the market fact never leads. It arrives as the consequence of a gap this
    platform already identified, and where there is no gap there is no
    sentence.
    """
    if days < 30:
        return []

    from . import dataservice, restructure

    try:
        gaps = restructure.what_is_missing(investor_id)
    except Exception:
        return []

    missing = {g.get("code") for g in (gaps or {}).get("gaps", [])}
    if not missing:
        return []

    out = []

    # Something that does not fall when equities do.
    if "no_stable_cushion" in missing or "single_asset_class" in missing:
        moved = _market_moved(days)
        if moved and moved["equity_pct"] < -5:
            out.append({
                "kind": "gap_cost",
                "weight": abs(moved["equity_pct"]) * 10,
                "headline": (f"Equities fell {abs(moved['equity_pct']):.0f}% "
                             f"while you were away, and everything you hold "
                             f"moves with them."),
                "detail": ("There is nothing here that rises when equities "
                           "fall, so the whole portfolio moved together. That "
                           "is survivable if you can leave it alone — and what "
                           "somebody sells in a fall is the part that would "
                           "have recovered. Something steady is what makes "
                           "leaving it alone possible."),
                "tone": "loss",
            })

    return out[:1]


def _market_moved(days: int) -> Optional[dict]:
    """How the market moved over the period, from the benchmark we hold.

    Our own NIFTYBEES series rather than a headline figure, so the number in a
    summary agrees with the number on the benchmark card.
    """
    rows = db.fetch_all(
        """
        SELECT trade_date, close FROM benchmark_daily
        WHERE symbol = 'NIFTYBEES' AND trade_date >= %s
        ORDER BY trade_date
        """,
        (date.today() - timedelta(days=days),),
    )
    if len(rows) < 5:
        return None

    start, end = _d(rows[0]["close"]), _d(rows[-1]["close"])
    if start <= 0:
        return None

    return {"equity_pct": round(float((end - start) / start * 100), 1),
            "from": rows[0]["trade_date"].isoformat(),
            "to": rows[-1]["trade_date"].isoformat()}


def _left_on_the_table(investor_id: str, days: int) -> list[dict]:
    """Things that were available and not taken.

    The test each of these passes: does knowing it change a decision somebody
    can still make? An unused allowance does. A free plan switch does. A fund
    they sold last March that has since risen does not -- it tells them they
    were wrong and offers nothing, which is a worse thing to send somebody than
    silence.
    """
    from . import plans

    out = []

    try:
        redirect = plans.redirect_future(investor_id)
    except Exception:
        redirect = None

    if redirect and _d(redirect.get("saves_first_year")) > 0:
        # What the commission cost over the period rather than over a year,
        # because that is the part that was actually lost while they were gone.
        over_period = (_d(redirect["saves_first_year"])
                       * Decimal(days) / 365)
        if over_period >= Decimal("500"):
            out.append({
                "kind": "still_paying_commission",
                "weight": float(over_period),
                "headline": (f"About {_money(over_period)} went to commission "
                             f"while you were away, on instalments that could "
                             f"have gone to a direct plan."),
                "detail": (redirect["reading"] + " Redirecting the next "
                           "instalment costs nothing — a purchase is not a "
                           "sale, so nothing is realised and no holding period "
                           "restarts."),
                "tone": "warn",
            })

    return out


# ---------------------------------------------------------------------------
# What counts
# ---------------------------------------------------------------------------

def _value_moved(investor_id: str, since: date) -> list[dict]:
    """A move large enough to be worth mentioning.

    Not every move. A portfolio that rose two per cent because the market rose
    two per cent is not news, and reporting it as news is how somebody learns
    to skip the summary that also contains the thing that mattered.
    """
    # Snapshots are written per import, not per day, so a date early in the
    # window may hold one repriced fund rather than the whole portfolio.
    # Comparing that to a complete snapshot produced "68,575% up" on a real
    # account -- ₹4,924 against ₹33,82,220, both correct sums of what happened
    # to be stored on their respective days.
    #
    # So a date only counts as a portfolio if it covers most of the holdings we
    # hold now. A partial day is not a smaller portfolio; it is a different
    # question being answered.
    rows = db.fetch_all(
        """
        SELECT as_of, sum(current_value) AS total, count(*) AS positions
        FROM holding_snapshots
        WHERE investor_id = %s AND as_of >= %s
        GROUP BY as_of ORDER BY as_of
        """,
        (investor_id, since),
    )
    if len(rows) < 2:
        return []

    live = db.fetch_one(
        "SELECT count(*) AS n FROM v_current_holdings "
        "WHERE investor_id = %s AND current_value > 0", (investor_id,))
    expected = (live or {}).get("n") or 0
    if not expected:
        return []

    complete = [r for r in rows if r["positions"] >= expected * 0.8]
    if len(complete) < 2:
        # Not enough complete days to compare. Saying nothing is right: the
        # alternative is a percentage that describes our import schedule
        # rather than their portfolio.
        return []

    start, end = _d(complete[0]["total"]), _d(complete[-1]["total"])
    if start <= 0:
        return []

    change = end - start
    pct = change / start * 100

    # A move past this is almost certainly a data artefact rather than a
    # market move. Two months of the worst crash on record is about 40%.
    if abs(pct) > 60:
        log.warning("implausible move for %s: %.0f%% between %s and %s",
                    investor_id, pct, complete[0]["as_of"], complete[-1]["as_of"])
        return []

    if abs(pct) < MOVE_WORTH_SAYING:
        return []

    return [{
        "kind": "value_moved",
        "weight": float(abs(pct)),
        "headline": (f"Your portfolio is {_money(abs(change))} "
                     f"{'higher' if change > 0 else 'lower'} than when you left."),
        "detail": (f"{_money(start)} then, {_money(end)} now — "
                   f"{abs(pct):.1f}% {'up' if change > 0 else 'down'}. "
                   f"Whether that is the market moving or your holdings moving "
                   f"differently from it is the more useful question, and the "
                   f"benchmark card answers it."),
        "tone": "gain" if change > 0 else "loss",
    }]


def _crossed_a_threshold(investor_id: str) -> list[dict]:
    """A position that grew past a fifth without anybody buying more.

    The change nobody made. A holding that rises until it decides the portfolio
    has changed the risk, and no decision was taken at any point -- which is
    exactly why it goes unnoticed.
    """
    # Only holdings we could match to a scheme. An unresolved position carries
    # a value from whatever statement mentioned it and has never been repriced,
    # so its share of the portfolio is a number we cannot stand behind.
    #
    # This surfaced on a real account: a matched Axis Small Cap holding and an
    # unmatched one were reported as 63% concentration between them, on the
    # assumption they were different funds. They may be the same fund in two
    # folios, or the unmatched one may be mispriced -- and a finding that
    # cannot tell the difference should not assert a percentage.
    #
    # Resolution means different things by kind: a share is identified by its
    # symbol, a fund by its AMFI scheme code. Testing both against native_code
    # excluded every share somebody owned, which on an equity-heavy portfolio
    # left the concentration figure describing the small remainder.
    #
    # And the explanation lives here rather than inside the SQL, because a
    # percent sign in an SQL comment is still a percent sign to the driver --
    # which is how a comment about percentages broke the query it described.
    rows = db.fetch_all(
        """
        SELECT v.instrument_name, v.current_value
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
          AND (
            (i.asset_class = 'equity' AND i.symbol IS NOT NULL)
            OR (i.asset_class <> 'equity'
                AND i.native_code IS NOT NULL
                AND i.native_code NOT LIKE 'name:' || '%%')
          )
        """,
        (investor_id,),
    )
    if not rows:
        return []

    total = sum((_d(r["current_value"]) for r in rows), Decimal(0))
    if total <= 0:
        return []

    heavy = [(r["instrument_name"], _d(r["current_value"]) / total * 100)
             for r in rows
             if _d(r["current_value"]) / total * 100 >= HEAVY]
    if not heavy:
        return []

    heavy.sort(key=lambda pair: -pair[1])

    # One entry however many qualify. Two cards saying the same sentence about
    # different holdings reads as a template rather than as a finding.
    if len(heavy) == 1:
        name, share = heavy[0]
        headline = f"{name} is now {share:.0f}% of everything you hold."
    else:
        names = " and ".join(n for n, _ in heavy[:2])
        combined = sum(share for _, share in heavy[:2])
        headline = (f"{names} are {combined:.0f}% of everything you hold "
                    f"between them.")

    return [{
        "kind": "concentration",
        "weight": float(heavy[0][1]),
        "headline": headline,
        "detail": ("A position that size means your overall result is mostly a "
                   "bet on it. If it grew here by rising rather than by your "
                   "buying more, the risk changed without a decision being "
                   "taken — which is how concentration usually happens."),
        "tone": "warn",
    }]


def _turned_long_term(investor_id: str) -> list[dict]:
    """Holdings that crossed the tax boundary while nobody was looking.

    Predictable months ahead and completely uninteresting until the week it
    happens, which is exactly what a summary like this is for.
    """
    from . import harvest

    try:
        held = harvest.positions(investor_id)
    except Exception:
        return []

    # Crossed within the last sixty days: recent enough to be news.
    just_crossed = [
        h for h in held
        if h["long_term"] and h["gain"] > 0
        and h["months_held"] <= (12 if h["asset_class"] in
                                 ("equity", "mutual_fund", "etf") else 24) + 2
    ]
    if not just_crossed:
        return []

    biggest = max(just_crossed, key=lambda h: h["gain"])
    saving = biggest["gain"] * Decimal("7.5") / 100   # 20% to 12.5%

    return [{
        "kind": "turned_long_term",
        "weight": float(saving),
        "headline": (f"{biggest['name']} has passed a year, so its gain is "
                     f"taxed at 12.5% rather than 20%."),
        "detail": (f"On {_money(biggest['gain'])} of gain that is about "
                   f"{_money(saving)} less tax if you sell now than if you had "
                   f"sold a month ago. Nothing to do about it — worth knowing "
                   f"if selling was on your mind."),
        "tone": "gain",
    }]


def _year_running_out(investor_id: str) -> list[dict]:
    """The exemption that dies in March.

    Only raised when there is something to lose and time is short. Mentioning
    it in May is noise; mentioning it in February is worth money.
    """
    from . import harvest

    today = date.today()
    if today.month not in (12, 1, 2, 3):
        return []

    try:
        chance = harvest.opportunity(investor_id)
    except Exception:
        return []

    if not chance or not chance.get("worth_doing"):
        return []

    return [{
        "kind": "year_ending",
        "weight": float(_d(chance["saving"])),
        "headline": (f"{_money(chance['available_gain'])} of tax-free allowance "
                     f"expires on the 31st of March."),
        "detail": (f"Realising that much long-term gain before the year ends "
                   f"saves about {_money(chance['saving'])}, and the allowance "
                   f"does not carry forward. Sell and buy straight back: the "
                   f"holding is unchanged and the cost base resets higher."),
        "tone": "warn",
    }]


def _instalments_stopped(investor_id: str) -> list[dict]:
    """A standing instruction that quietly stopped.

    Our behavioural engine can see this and nobody tells people. A SIP that
    lapsed because a card expired is the most common way a plan stops working,
    and it produces no notification from anybody.
    """
    from . import behaviour

    try:
        how = behaviour.profile(investor_id)
    except Exception:
        return []

    style = ((how or {}).get("style") or {})
    if style.get("style") != "monthly":
        return []

    # The field is `last`, not `last_month`. Worth the note because a wrong
    # key here fails silently: the check simply never fires, and a stopped SIP
    # goes unreported by a feature built to report exactly that.
    last = style.get("last")
    if not last:
        return []

    try:
        last_date = datetime.strptime(str(last)[:7], "%Y-%m").date()
    except (ValueError, TypeError):
        return []

    months_quiet = ((date.today().year - last_date.year) * 12
                    + (date.today().month - last_date.month))

    if months_quiet < 2:
        return []

    return [{
        "kind": "sip_stopped",
        "weight": 1000.0,   # ranks high: a stopped plan is not a small thing
        "headline": (f"Your monthly investing stopped about {months_quiet} "
                     f"months ago."),
        "detail": ("We have no record of an instalment since then. A standing "
                   "instruction lapsing — an expired card, a changed account — "
                   "is the most common way a plan stops working, and nobody "
                   "sends a message when it happens. Worth checking whether "
                   "this was a decision or an accident."),
        "tone": "warn",
    }]
