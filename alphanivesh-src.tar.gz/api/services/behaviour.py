"""How somebody actually invests, as opposed to how they would describe it.

A portfolio says what somebody owns. The transaction record says how they came
to own it, and the two tell different stories: one investor arrived at five
funds through thirteen hundred monthly instalments, another at sixteen funds
through nineteen one-off purchases. Same asset class, same country, entirely
different behaviour -- and the advice that suits one is wrong for the other.

Four things are measurable from what we hold:

    whether the money goes in monthly or in lumps
    whether it kept going in when the market fell
    where in a fund's own range the purchases landed
    how the money is spread across decisions

What is not measurable, and is not guessed at: how long positions are held
before selling, whether losses are cut or run, whether last year's winner gets
bought. All of those need sales, and the record holds one sale across every
investor. Where a reading cannot be supported the section says so rather than
filling the space.

The point of any of it is not to characterise somebody. It is that the same
portfolio needs different advice depending on how it was built: telling a
disciplined monthly investor to "stay the course" is noise, and telling
somebody who buys in lumps at market highs the same thing misses the thing
worth saying.
"""

from __future__ import annotations

import logging
import statistics
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db
from . import i18n

log = logging.getLogger("alphanivesh.behaviour")

# Transaction types that put money in. `costbasis` is excluded: it is a
# synthetic row carrying a statement's cost figure, not a purchase that
# happened on a date.
BUYING = ("purchase", "sip", "purchase_sip", "switch in")
SELLING = ("redemption", "switch out", "sell")

# Below this there is not enough of a record to read anything from.
MIN_TRANSACTIONS = 6

# A month's contributions counted as regular if they land within this of the
# median gap. SIP dates move for weekends and holidays.
REGULAR_TOLERANCE_DAYS = 6


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _buys(investor_id: str) -> list[dict]:
    return db.fetch_all(
        """
        SELECT t.txn_date, t.txn_type, t.amount, t.quantity, t.price,
               t.instrument_id, i.name AS instrument_name
        FROM canonical_transactions t
        JOIN instruments i ON i.id = t.instrument_id
        WHERE t.investor_id = %s
          AND t.txn_type = ANY(%s)
          AND t.txn_date > '1990-01-01'
          AND t.amount > 0
        ORDER BY t.txn_date
        """,
        (investor_id, list(BUYING)),
    )


def how_they_invest(investor_id: str) -> Optional[dict]:
    """Monthly instalments or occasional lumps, and how consistently.

    The distinction matters more than it sounds. Somebody investing the same
    amount every month has already solved the timing problem and does not need
    advice about it; somebody putting in lumps has not, and where those lumps
    landed is worth knowing.
    """
    buys = _buys(investor_id)
    if len(buys) < MIN_TRANSACTIONS:
        return {
            "readable": False,
            "why": (f"We hold {len(buys)} purchase"
                    f"{'' if len(buys) == 1 else 's'} for you. Reading how "
                    f"somebody invests takes more of a record than that -- "
                    f"import an older statement and this will have something "
                    f"to say."),
        }

    # Grouped by month, because a SIP is a monthly rhythm however many funds
    # it is split across.
    by_month: dict[tuple[int, int], Decimal] = defaultdict(Decimal)
    for buy in buys:
        key = (buy["txn_date"].year, buy["txn_date"].month)
        by_month[key] += _d(buy["amount"])

    months = sorted(by_month)
    span_months = len(months)
    if span_months < 3:
        return {"readable": False,
                "why": "The purchases we hold span less than three months."}

    # How many of the months between first and last had money going in. A
    # monthly investor scores near one; somebody who buys occasionally scores
    # low, and both are legitimate.
    first, last = months[0], months[-1]
    calendar_months = ((last[0] - first[0]) * 12 + (last[1] - first[1])) + 1
    coverage = Decimal(span_months) / Decimal(max(calendar_months, 1))

    amounts = [by_month[m] for m in months]
    median_amount = Decimal(str(statistics.median([float(a) for a in amounts])))

    # How much the monthly amounts vary. A SIP is nearly constant; lump
    # investing is not.
    if len(amounts) > 1 and median_amount > 0:
        spread = Decimal(str(statistics.pstdev([float(a) for a in amounts])))
        variation = spread / median_amount
    else:
        variation = Decimal(0)

    sip_flagged = sum(1 for b in buys if "sip" in (b["txn_type"] or "").lower())
    sip_share = Decimal(sip_flagged) / Decimal(len(buys)) * 100

    # Whether the same amount keeps recurring, which is what a standing
    # instruction looks like in a transaction record. Measuring the variation
    # of monthly totals missed it: a portfolio of five SIPs has a total that
    # moves whenever one of them starts, stops or changes, while every
    # individual instalment is identical.
    #
    # Somebody paying 4,000 a month across five funds, every month for eleven
    # months, was reading as "regular but not on a fixed rhythm" -- which is
    # exactly backwards about the most disciplined investor in the book.
    amount_counts: dict[Decimal, int] = defaultdict(int)
    for buy in buys:
        amount_counts[_d(buy["amount"]).quantize(Decimal("0.01"))] += 1
    repeated = sum(count for count in amount_counts.values() if count >= 3)
    repeat_share = Decimal(repeated) / Decimal(len(buys)) * 100

    # A standing instruction leaves a rhythm, not just a recurring amount.
    # Nineteen purchases across eleven months is under two a month; forty-eight
    # is four or five, which is what several SIPs debiting together looks like.
    # Reading the first as monthly overstated somebody who invests when they
    # decide to, and the difference matters: one of them needs no advice about
    # timing and the other does.
    per_month = Decimal(len(buys)) / Decimal(max(span_months, 1))

    if (sip_share >= 60
            or (coverage >= Decimal("0.8") and repeat_share >= 60
                and per_month >= Decimal("2.5"))):
        style = "monthly"
    elif coverage >= Decimal("0.7"):
        style = "frequent"
    elif coverage >= Decimal("0.4"):
        style = "occasional"
    else:
        style = "sporadic"

    return {
        "readable": True,
        "style": style,
        "purchases": len(buys),
        "months_invested": span_months,
        "months_available": calendar_months,
        "coverage_pct": str((coverage * 100).quantize(Decimal("0.1"))),
        "median_month": str(median_amount.quantize(Decimal("1"))),
        "variation": str(variation.quantize(Decimal("0.01"))),
        "sip_share_pct": str(sip_share.quantize(Decimal("0.1"))),
        "repeat_share_pct": str(repeat_share.quantize(Decimal("0.1"))),
        "per_month": str(per_month.quantize(Decimal("0.1"))),
        "first": months[0], "last": months[-1],
        "reading": _describe_style(style, len(buys), span_months, calendar_months,
                                   median_amount),
    }


def _describe_style(style: str, purchases: int, months: int, available: int,
                    median: Decimal) -> str:
    if style == "monthly":
        return i18n.say("behave.monthly", months=available,
                        amount=f"{median:,.0f}", count=purchases)
    if style == "frequent":
        return i18n.say("behave.frequent", count=purchases, months=months,
                        available=available, amount=f"{median:,.0f}")
    if style == "occasional":
        return i18n.say("behave.occasional", count=purchases, months=months,
                        available=available, amount=f"{median:,.0f}")
    return (f"{purchases} purchases across {months} of the last {available} "
            f"months. Too irregular to read a habit from, which is itself worth "
            f"knowing: nothing here is happening automatically.")


def kept_going(investor_id: str, automatic: bool = False) -> Optional[dict]:
    """Whether the contributions continued when the market fell.

    The single most valuable thing in a transaction record. Everybody intends
    to keep investing through a fall; the record says whether they did, and
    somebody who did has already demonstrated the thing that most determines
    how they will do over twenty years.
    """
    buys = _buys(investor_id)
    if len(buys) < MIN_TRANSACTIONS:
        return None

    market = db.fetch_all(
        """
        SELECT trade_date, close FROM benchmark_daily
        WHERE symbol = 'NIFTYBEES' ORDER BY trade_date
        """
    )
    if len(market) < 250:
        return None

    # A running high, so "the market was down" means down from where it had
    # been rather than down from where it ended up.
    peak = Decimal(0)
    fall_on: dict[date, Decimal] = {}
    for row in market:
        close = _d(row["close"])
        peak = max(peak, close)
        if peak > 0:
            fall_on[row["trade_date"]] = (peak - close) / peak * 100

    dates = sorted(fall_on)

    def fall_near(when: date) -> Optional[Decimal]:
        earlier = [d for d in dates if d <= when]
        return fall_on[earlier[-1]] if earlier else None

    # Months where the market was meaningfully off its high at some point.
    hard_months: set[tuple[int, int]] = set()
    for when, fall in fall_on.items():
        if fall >= 8:
            hard_months.add((when.year, when.month))

    if not hard_months:
        return {"tested": False,
                "why": ("The market has not fallen far enough during the period "
                        "we hold your purchases for. This will mean something "
                        "after the next bad stretch.")}

    invested_months = {(b["txn_date"].year, b["txn_date"].month) for b in buys}
    span = sorted(invested_months | hard_months)
    if not span:
        return None

    # Only the hard months that fall inside the window we have purchases for.
    window = {m for m in hard_months
              if min(invested_months) <= m <= max(invested_months)}
    if not window:
        return {"tested": False,
                "why": ("The market's falls did not overlap the period we hold "
                        "your purchases for.")}

    kept = window & invested_months
    worst = max((fall_on[d] for d in dates
                 if (d.year, d.month) in window), default=Decimal(0))

    return {
        "tested": True,
        "hard_months": len(window),
        "months_invested_through": len(kept),
        "worst_fall_pct": str(worst.quantize(Decimal("0.1"))),
        "held_nerve": len(kept) == len(window),
        "reading": _describe_nerve(len(kept), len(window), worst, automatic),
    }


def _describe_nerve(kept: int, total: int, worst: Decimal,
                    automatic: bool = False) -> str:
    """What continuing through a fall means, which depends on how it happened.

    A standing instruction cannot miss a fall -- that is what automatic means,
    and the credit belongs to setting it up rather than to holding nerve on the
    day. Somebody choosing to invest during a fall did something harder.

    Told apart because praising both identically is flattery, and a reader who
    notices they are being flattered stops believing the rest.
    """
    if total == 0:
        return "No falls to test against yet."
    if kept == total and automatic:
        return i18n.say("behave.nerve.automatic", months=total,
                        worst=f"{worst:.0f}")
    if kept == total:
        return i18n.say("behave.nerve.chosen", months=total,
                        worst=f"{worst:.0f}")
    if kept == 0:
        return (f"The market was more than 8% off its high in {total} "
                f"month{'s' if total != 1 else ''} while you were investing, and "
                f"no money went in during any of them. Falls are when units are "
                f"cheapest, which is exactly when stopping costs the most.")
    return (f"Of {total} months where the market was more than 8% off its high, "
            f"you invested in {kept}. Partly held, which is more than most "
            f"manage.")


def where_they_bought(investor_id: str) -> Optional[dict]:
    """Where in a fund's own range the purchases landed.

    Not a judgement about skill. Somebody investing monthly buys at every
    price by construction, and that is the point of doing it. It matters for
    somebody choosing their moments, because where those moments fell is the
    whole of their timing.
    """
    buys = [b for b in _buys(investor_id) if b["price"] and _d(b["price"]) > 0]
    if len(buys) < MIN_TRANSACTIONS:
        return None

    placements: list[Decimal] = []
    for buy in buys:
        band = db.fetch_one(
            """
            SELECT min(nav) AS low, max(nav) AS high
            FROM nav_history
            WHERE instrument_id = %s
              AND as_of BETWEEN %s AND %s
            """,
            (buy["instrument_id"],
             buy["txn_date"] - timedelta(days=365),
             buy["txn_date"]),
        )
        if not band or band["low"] is None or band["high"] is None:
            continue
        low, high = _d(band["low"]), _d(band["high"])
        if high <= low:
            continue
        price = _d(buy["price"])
        placements.append((price - low) / (high - low) * 100)

    if len(placements) < MIN_TRANSACTIONS:
        return None

    average = sum(placements) / len(placements)
    near_high = sum(1 for p in placements if p >= 80)
    near_low = sum(1 for p in placements if p <= 20)

    return {
        "purchases_placed": len(placements),
        "average_placement_pct": str(average.quantize(Decimal("0.1"))),
        "near_high": near_high,
        "near_low": near_low,
        "reading": _describe_placement(average, near_high, near_low, len(placements)),
    }


def _describe_placement(average: Decimal, near_high: int, near_low: int,
                        total: int) -> str:
    # Described from where the purchases actually sat. An average of 26 with
    # three of eighteen in the bottom fifth is not "near the bottom" -- it is
    # the lower half, and saying more than that contradicts the count printed
    # in the next sentence.
    where = ("in the upper part of" if average >= 65
             else "in the lower part of" if average <= 35
             else "across")
    base = (f"Your purchases landed on average {average:.0f}% of the way up each "
            f"fund's twelve-month range \u2014 {where} the range it had been "
            f"trading in.")
    if average >= 65:
        return base + (f" {near_high} of {total} were in the top fifth. Buying "
                       f"after a run is what most people do, because a rising "
                       f"price is what makes a fund worth noticing.")
    if average <= 35:
        detail = (f" {near_low} of {total} were in the bottom fifth."
                  if near_low else "")
        return base + detail + (" Buying when a fund is off its recent highs is "
                                "uncomfortable, and it is where the units are "
                                "cheapest.")
    return base + " Spread across the range, which is what investing regularly does."


def spread_of_decisions(investor_id: str) -> Optional[dict]:
    """How many separate decisions the portfolio represents.

    Sixteen funds bought once each and five funds bought two hundred times each
    are different things. The first is a collection of decisions, the second is
    one decision repeated -- and a collection needs pruning where a habit needs
    protecting.
    """
    rows = db.fetch_all(
        """
        SELECT i.name, count(*) AS purchases, sum(t.amount) AS invested
        FROM canonical_transactions t
        JOIN instruments i ON i.id = t.instrument_id
        WHERE t.investor_id = %s AND t.txn_type = ANY(%s)
          AND t.txn_date > '1990-01-01' AND t.amount > 0
        GROUP BY i.name ORDER BY 3 DESC
        """,
        (investor_id, list(BUYING)),
    )
    if not rows:
        return None

    total_buys = sum(r["purchases"] for r in rows)
    funds = len(rows)
    per_fund = Decimal(total_buys) / Decimal(funds)

    return {
        "funds_bought": funds,
        "purchases": total_buys,
        "purchases_per_fund": str(per_fund.quantize(Decimal("0.1"))),
        "reading": (
            f"{total_buys} purchases across {funds} fund"
            f"{'s' if funds != 1 else ''}"
            + (f", which is one decision repeated rather than {funds} separate ones."
               if per_fund >= 10 else
               f" \u2014 close to one purchase each, so this portfolio is "
               f"{funds} separate decisions."
               if per_fund <= 2 else ".")
        ),
    }


def profile(investor_id: str) -> dict:
    """Everything readable about how this portfolio was built.

    Assembled rather than scored. A reader should be able to disagree with any
    one part without the rest collapsing, which a single number does not allow.
    """
    style = how_they_invest(investor_id)
    result: dict = {"style": style}

    if not style or not style.get("readable"):
        result["reading"] = (style or {}).get(
            "why", "We do not hold enough of your purchase history to read anything.")
        result["not_readable"] = _cannot_read()
        return result

    # Whether the investing was automatic changes what continuing through a
    # fall demonstrates.
    result["nerve"] = kept_going(investor_id, automatic=(style["style"] == "monthly"))
    result["placement"] = where_they_bought(investor_id)
    result["spread"] = spread_of_decisions(investor_id)
    result["not_readable"] = _cannot_read()

    parts = [style["reading"]]
    for key in ("nerve", "placement", "spread"):
        section = result.get(key)
        if section and section.get("reading"):
            parts.append(section["reading"])
    result["reading"] = " ".join(parts)
    return result


def _cannot_read() -> list[dict]:
    """What a transaction record without sales cannot tell us.

    Stated because the absence is invisible otherwise: a page about how
    somebody invests that never mentions selling reads as though selling had
    been considered and found unremarkable.
    """
    return [
        {"what": "Whether you hold or trade",
         "why": ("A consolidated statement reports purchases and rarely reports "
                 "sales. Without them there is no holding period to measure.")},
        {"what": "Whether you cut losses or let them run",
         "why": "Same reason: it needs the sales."},
        {"what": "Whether you buy last year's winner",
         "why": ("This needs several years of purchases to see a pattern in. We "
                 "hold months.")},
    ]
