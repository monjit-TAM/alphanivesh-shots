"""What to hold that is not equity.

Every recommendation this platform makes ends in a share or an equity fund.
That is a limitation of the engine rather than a view about markets, and it
produces a specific incoherence: the risk cards tell somebody they hold nothing
that rises when equities fall, and the next card recommends more equity.

Three gaps, in the order they matter.

**Somewhere to keep the emergency fund.** The engine asks for one on almost
every portfolio and never says where. "Build six months of expenses" without
"in a liquid fund, and here are three" is half an instruction, and the half
that is missing is the one requiring a decision.

**Something that does not fall when equities do.** Gold is the honest answer
for Indian investors: it is uncorrelated enough to matter, easy to hold through
an ETF or a sovereign bond, and every portfolio we hold has none of it.

**And a cheaper way to hold the market.** Somebody who does not want to pick
funds should be told that an index ETF exists and costs a fifth of what an
active fund does. Most platforms will not say this because they earn nothing
from it.

**What this is not.** Not a fixed allocation model. There is no rule here that
says twenty per cent gold — what there is is a check for whether somebody has
anything at all in a role, and a suggestion where they have nothing. The
difference matters: a model portfolio is a view about markets, and "you have
nothing you can reach in an emergency" is an observation.

**And the ETF chooser is the data service's, not ours.** We pass what the
money is for and how long it has; it returns instruments that fit. Building our
own list would mean maintaining one.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.beyond")

# Below this, a holding in some role is a token rather than a position -- and
# saying somebody "has gold" because of ₹5,000 in a portfolio of ₹34 lakh would
# be technically true and useless.
MEANINGFUL_SHARE_PCT = Decimal("2")

# What each role is for, and what counts as filling it.
ROLES = {
    "reachable": {
        "name": "money you can reach",
        "classes": ("fixed_deposit", "cash"),
        "name_patterns": ("liquid", "overnight", "ultra short", "money market"),
        "why": ("Something you can turn into cash in a day without selling a "
                "holding at whatever price that morning offers."),
    },
    "steady": {
        "name": "something steady",
        "classes": ("bond", "gsec", "ppf_epf"),
        "name_patterns": ("debt", "gilt", "corporate bond", "banking and psu",
                          "short duration", "dynamic bond"),
        "why": ("Something whose price does not move with the equity market, "
                "so a bad year in shares is not a bad year in everything."),
    },
    "different": {
        "name": "something that moves differently",
        "classes": ("gold",),
        "name_patterns": ("gold", "silver", "sovereign gold"),
        "why": ("Gold has historically risen in the periods when Indian "
                "equities fell hardest. Not always, and not by a rule — but "
                "often enough that holding none of it is a decision worth "
                "making deliberately."),
    },
}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if number >= 0 else "-₹") + digits


def what_is_missing(investor_id: str) -> dict:
    """Which roles nothing in this portfolio is filling.

    The convenience wrapper for this platform. A caller elsewhere in the group
    passes holdings to `from_holdings` -- the reasoning is the same and only
    the source of the list differs, which is what the shared engine promises.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_name, v.asset_class, v.current_value, i.name
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
        """,
        (investor_id,),
    )
    return from_holdings([dict(r) for r in rows])


def from_holdings(rows: list[dict]) -> dict:
    """The same question, asked of a list somebody handed us."""
    if not rows:
        return {"total": "0", "roles": {}}

    total = sum((_d(r.get("current_value") or r.get("value")) for r in rows),
                Decimal(0))
    filled: dict[str, Decimal] = {}

    for key, role in ROLES.items():
        held = Decimal(0)
        for row in rows:
            # External callers name the field differently, so read whichever
            # is there rather than requiring one.
            name = " ".join(str(row.get(k) or "") for k in
                            ("name", "instrument_name", "scheme_name")).lower()
            kind = row.get("asset_class") or row.get("kind") or ""
            if (kind in role["classes"]
                    or any(p in name for p in role["name_patterns"])):
                held += _d(row.get("current_value") or row.get("value"))
        filled[key] = held

    return {
        "total": str(total.quantize(Decimal("1"))),
        "roles": {
            key: {
                "name": ROLES[key]["name"],
                "held": str(value.quantize(Decimal("1"))),
                "share_pct": str((value / total * 100).quantize(Decimal("0.1"))
                                 if total > 0 else Decimal(0)),
                "filled": (value / total * 100) >= MEANINGFUL_SHARE_PCT
                          if total > 0 else False,
                "why": ROLES[key]["why"],
            }
            for key, value in filled.items()
        },
    }


# What the chooser calls each bucket, against the role it fills here. Read
# from the endpoint rather than guessed: it returns a list of buckets with a
# pick and an alternative in each, and my first version looked for a "buckets"
# dict that does not exist.
BUCKET_FOR_ROLE = {
    "reachable": ("liquid", "cash", "overnight", "money"),
    "steady": ("debt", "bond", "gilt", "gsec"),
    "different": ("gold", "commodity", "silver"),
}

# Below this daily turnover an ETF is hard to get out of at a fair price, and
# an instrument somebody cannot exit is not a place to keep an emergency fund.
THIN_CR = 1.0


def suggestions(role: str) -> Optional[dict]:
    """What actually fills a role, from the chooser's own picks.

    Their list rather than one maintained here, and their liquidity figures
    with it -- an ETF nobody trades is one somebody cannot exit at a fair price
    on the day they need to, which matters most for exactly the role people
    reach for first.
    """
    from . import dataservice

    if role not in ROLES:
        return None

    horizon = {"reachable": "now", "steady": "3y", "different": "5y"}[role]

    try:
        picked = dataservice.etf_chooser(horizon=horizon)
    except Exception as err:
        log.warning("etf chooser failed for %s: %s", role, err)
        picked = None

    wanted = BUCKET_FOR_ROLE[role]
    options = []

    for entry in (picked or {}).get("allocation") or []:
        bucket = (entry.get("bucket") or "").lower()
        why = (entry.get("why") or "").lower()
        if not any(w in bucket or w in why for w in wanted):
            continue

        for which in ("pick", "alternative"):
            instrument = entry.get(which)
            if not instrument or not instrument.get("symbol"):
                continue
            turnover = instrument.get("turnover_cr")
            options.append({
                "symbol": instrument["symbol"],
                "name": instrument.get("name"),
                "traded_cr": turnover,
                "thin": bool(turnover is not None and turnover < THIN_CR),
                "note": instrument.get("receipt"),
                "bucket_why": entry.get("why"),
            })

    return {
        "role": role,
        "role_name": ROLES[role]["name"],
        "why": ROLES[role]["why"],
        "options": options[:3],
        "note": ("These fill the role rather than being recommendations to buy "
                 "any particular one. What matters is that something is doing "
                 "this job; the cheapest liquid thing that does it is usually "
                 "the right answer."),
    }


def actions_for(investor_id: str, them: dict,
                summary: dict, holdings: Optional[list[dict]] = None) -> list[dict]:
    """The INVEST-tier actions that are not about buying more equity.

    Returned as plain dicts for the decision engine to turn into Actions,
    because the engine owns the Action shape and importing it here would make
    two modules depend on each other.
    """
    missing = (from_holdings(holdings) if holdings is not None
               else what_is_missing(investor_id))
    roles = missing.get("roles") or {}
    total = _d(missing.get("total"))
    if total <= 0:
        return []

    out: list[dict] = []
    expenses = _d(them.get("monthly_expenses"))

    # Money you can reach. First, because it is the one that decides whether
    # somebody has to sell in a bad month -- and selling in a bad month is
    # where most of the damage in investing actually happens.
    if not (roles.get("reachable") or {}).get("filled"):
        target = expenses * 6 if expenses > 0 else None
        picks = suggestions("reachable")
        out.append({
            "code": "hold_something_reachable",
            "what": ("There is nothing here you could turn into cash tomorrow."
                     if not target else
                     f"Nothing here can be reached quickly, against "
                     f"{_money(target)} of expenses over six months."),
            "why": (ROLES["reachable"]["why"] + " Without it, an unexpected "
                    "bill means selling something — and the something that "
                    "gets sold is whatever is easiest, not whatever is worth "
                    "least."),
            "how": _how_to(picks, target),
            "impact": ("It is what lets you leave the rest alone in a bad "
                       "year."),
            "worth": None,
            "evidence": {"basis": "role_gap", "role": "reachable",
                         "target": str(target) if target else None},
            "options": (picks or {}).get("options") or [],
        })

    # Something that does not move with equities.
    if not (roles.get("different") or {}).get("filled"):
        share = _d((roles.get("different") or {}).get("share_pct"))
        picks = suggestions("different")
        out.append({
            "code": "hold_something_different",
            "what": ("Nothing here rises when equities fall."
                     if share <= 0 else
                     f"Only {share:.1f}% of this holds anything that moves "
                     f"differently from equities."),
            "why": ROLES["different"]["why"],
            "how": _how_to(picks, None),
            "impact": ("A portfolio where everything falls together is one "
                       "somebody is more likely to sell at the bottom of, and "
                       "what gets sold in a fall is the part that would have "
                       "recovered."),
            "worth": None,
            "evidence": {"basis": "role_gap", "role": "different"},
            "options": (picks or {}).get("options") or [],
        })

    # And something steady, but only where the portfolio is large enough for
    # it to matter and there is genuinely nothing.
    if (not (roles.get("steady") or {}).get("filled")
            and total > Decimal("500000")):
        picks = suggestions("steady")
        out.append({
            "code": "hold_something_steady",
            "what": "All of this moves with the equity market.",
            "why": (ROLES["steady"]["why"] + " On a portfolio this size, a "
                    "year like 2008 or March 2020 takes a number that is hard "
                    "to look at."),
            "how": _how_to(picks, None),
            "impact": ("Less to lose in a bad year, and less to gain in a good "
                       "one — which is the trade, stated rather than hidden."),
            "worth": None,
            "evidence": {"basis": "role_gap", "role": "steady"},
            "options": (picks or {}).get("options") or [],
        })

    return out


def _how_to(picks: Optional[dict], target: Optional[Decimal]) -> str:
    """What to actually do, with instruments where we have them."""
    if not picks or not picks.get("options"):
        return ((f"Move about {_money(target)} into a liquid fund or a sweep "
                 f"deposit. " if target else "")
                + "Any low-cost fund or ETF doing this job will do; the "
                  "cheapest one usually is the right answer.")

    names = ", ".join(o["symbol"] or o["name"] for o in picks["options"][:3]
                      if (o.get("symbol") or o.get("name")))
    return ((f"About {_money(target)} to start. " if target else "")
            + f"Instruments that do this job: {names}. "
            + "These fill the role rather than being recommendations to buy "
              "any particular one.")
