"""What Ariv is allowed to cost.

Fifty rupees per investor per month, which at current pricing is about
fifty-five generated answers. With most questions routing to a computation and
costing nothing, that works out to roughly six questions a day before anybody
notices a ceiling exists.

**The routing is the cost control; this is the backstop.** A question answered
from a computation costs nothing, takes five milliseconds and cannot drift. If
seven questions in ten go that way — which they do — then the budget only ever
has to cover the remaining three, and it covers them generously.

**Measured rather than assumed.** Token counts vary with how much context an
answer needs, so a flat per-question estimate would be wrong in both
directions. The API returns actual usage and this records it, which also means
the assumed prices can be checked against what was really spent.

**And running out is not being cut off.** Deterministic answers keep working
when the budget is gone — what somebody's portfolio is worth, what the tax
would be, what to do first. The thing that stops is the reasoning, and the
message says so plainly rather than pretending the assistant is broken.

**Two ceilings, not one.** A monthly budget alone lets somebody spend it all in
one sitting and then find nothing works for three weeks. A daily cap alongside
it spreads the same allowance across the month without ever being the binding
constraint for normal use.
"""

from __future__ import annotations

import logging
import os
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.budget")

# What one investor may spend on generated answers in a month, in paise.
# Fifty rupees.
MONTHLY_PAISE = int(os.environ.get("ARIV_MONTHLY_PAISE", "5000"))

# And in a day, so a single sitting cannot consume the month. A third of the
# monthly allowance, which no ordinary use will reach.
DAILY_PAISE = int(os.environ.get("ARIV_DAILY_PAISE", "1700"))

# What the model costs, in paise per million tokens. Stated here rather than
# buried so that when pricing changes somebody can find it -- and so the
# recorded spend can be checked against the assumption.
#
# Roughly $3 and $15 per million at 88 rupees to the dollar. Verify against the
# console rather than trusting these: they were right when written and prices
# move.
PAISE_PER_MILLION_IN = int(os.environ.get("ARIV_PAISE_IN", "26400"))
PAISE_PER_MILLION_OUT = int(os.environ.get("ARIV_PAISE_OUT", "132000"))

# What a generated answer typically costs, for estimating before it is made.
# About 2,000 tokens of context and 300 of answer.
TYPICAL_IN, TYPICAL_OUT = 2000, 300


def _period(when: Optional[date] = None) -> str:
    when = when or date.today()
    return f"{when.year:04d}-{when.month:02d}"


def cost_of(tokens_in: int, tokens_out: int) -> int:
    """What an exchange cost, in paise."""
    return round(
        (tokens_in * PAISE_PER_MILLION_IN
         + tokens_out * PAISE_PER_MILLION_OUT) / 1_000_000)


def typical_cost() -> int:
    """What the next generated answer is likely to cost."""
    return cost_of(TYPICAL_IN, TYPICAL_OUT)


def spent(investor_id: str) -> dict:
    """What this investor has spent this month and today."""
    month = db.fetch_one(
        """
        SELECT coalesce(sum(cost_paise), 0) AS paise,
               count(*) FILTER (WHERE route = 'generated') AS generated,
               count(*) AS asked
        FROM ariv_usage WHERE investor_id = %s AND period = %s
        """,
        (investor_id, _period()),
    ) or {}

    today = db.fetch_one(
        """
        SELECT coalesce(sum(cost_paise), 0) AS paise
        FROM ariv_usage
        WHERE investor_id = %s AND asked_at::date = current_date
        """,
        (investor_id,),
    ) or {}

    month_paise = int(month.get("paise") or 0)
    today_paise = int(today.get("paise") or 0)

    return {
        "month_paise": month_paise,
        "today_paise": today_paise,
        "month_rupees": str(Decimal(month_paise) / 100),
        "budget_rupees": str(Decimal(MONTHLY_PAISE) / 100),
        "left_paise": max(0, MONTHLY_PAISE - month_paise),
        "generated": int(month.get("generated") or 0),
        "asked": int(month.get("asked") or 0),
        "period": _period(),
    }


def may_generate(investor_id: str) -> tuple[bool, Optional[str]]:
    """Whether there is room for one more generated answer.

    Returns the verdict and, where it is no, what to say. The message matters:
    somebody who has run out should understand that the assistant still works
    for most things rather than concluding it is broken.
    """
    usage = spent(investor_id)
    expected = typical_cost()

    if usage["month_paise"] + expected > MONTHLY_PAISE:
        return False, (
            f"That question needs me to reason rather than look something up, "
            f"and this month's allowance for that is used up — "
            f"₹{usage['month_rupees']} of ₹{usage['budget_rupees']} across "
            f"{usage['generated']} such questions. Everything I answer from "
            f"your own figures still works: what things are worth, what the tax "
            f"would be, what to do first, how your funds compare. The allowance "
            f"resets at the start of next month."
        )

    if usage["today_paise"] + expected > DAILY_PAISE:
        return False, (
            "That one needs reasoning, and today's share of the monthly "
            "allowance is used. It resets tomorrow — and anything I can answer "
            "from your own figures works now."
        )

    return True, None


def record(investor_id: str, route: str, *,
           tokens_in: int = 0, tokens_out: int = 0,
           model: Optional[str] = None,
           ledger_id: Optional[str] = None) -> int:
    """Note what an exchange cost, and return it in paise.

    Deterministic and refused answers are recorded at zero rather than not
    recorded. The ratio between free and paid answers is the thing worth
    watching -- if it moves, either the router has stopped catching common
    questions or people are asking harder ones, and both are worth knowing
    before the bill arrives.
    """
    paise = cost_of(tokens_in, tokens_out) if route == "generated" else 0

    try:
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO ariv_usage
                    (investor_id, ledger_id, period, route, model,
                     tokens_in, tokens_out, cost_paise)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (investor_id, ledger_id, _period(), route, model,
                 tokens_in, tokens_out, paise),
            )
    except Exception as err:                                     # pragma: no cover
        # Loud. A meter that stops without anybody noticing is how a budget
        # becomes a surprise.
        log.error("ARIV USAGE NOT RECORDED for %s: %s", investor_id, err)

    return paise


def across_everybody(days: int = 30) -> dict:
    """What Ariv is costing in total, for whoever is watching the bill."""
    row = db.fetch_one(
        """
        SELECT count(*) AS exchanges,
               count(*) FILTER (WHERE route = 'generated') AS generated,
               count(*) FILTER (WHERE route = 'deterministic') AS computed,
               count(*) FILTER (WHERE route = 'refused') AS refused,
               count(DISTINCT investor_id) AS investors,
               coalesce(sum(cost_paise), 0) AS paise
        FROM ariv_usage
        WHERE asked_at > now() - (%s || ' days')::interval
        """,
        (days,),
    ) or {}

    exchanges = int(row.get("exchanges") or 0)
    generated = int(row.get("generated") or 0)
    paise = int(row.get("paise") or 0)
    investors = int(row.get("investors") or 0)

    return {
        "days": days,
        "exchanges": exchanges,
        "generated": generated,
        "computed": int(row.get("computed") or 0),
        "refused": int(row.get("refused") or 0),
        "investors": investors,
        "total_rupees": str(Decimal(paise) / 100),
        "per_investor_rupees": (str((Decimal(paise) / investors / 100)
                                    .quantize(Decimal("0.01")))
                                if investors else "0"),
        "free_share_pct": (round((exchanges - generated) / exchanges * 100)
                           if exchanges else 0),
        "reading": (
            f"{exchanges} questions from {investors} "
            f"{'investor' if investors == 1 else 'investors'} over {days} days, "
            f"₹{Decimal(paise) / 100} in total. "
            f"{round((exchanges - generated) / exchanges * 100) if exchanges else 0}% "
            f"were answered from computations and cost nothing — which is the "
            f"cost control working, rather than the budget."
        ),
    }
