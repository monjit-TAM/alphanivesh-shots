"""Choosing what to buy, from candidates somebody else ranked.

The rebalance engine ranks the NSE universe on its composite score and
allocates the proceeds evenly across the top few. That is the right job for it
and the wrong output to hand an investor unchanged, because ranking knows
nothing about the portfolio the money is leaving.

On a real run it proposed selling one listed financial services company and
buying eight micro and small caps at six thousand rupees each -- into a
portfolio already 63% capital goods with nothing in banking, pharma or
technology. Every pick defensible alone; together a worse portfolio than the
one being fixed.

What this adds is the part that needs the holdings:

**A size mix.** Large, mid and small in roughly forty, thirty and twenty-five
per cent, with micro capped at five. Not because small companies are bad --
they are where returns come from -- but because a portfolio built entirely of
them cannot be sold in a falling market at the prices on screen.

**Sector weight where the portfolio is thin.** Somebody two thirds in capital
goods does not need more industrials however well they rank. They need the
industries they do not own, and a candidate in one of those is worth more to
them than a better-ranked one in an industry they already carry.

**Positions large enough to matter.** Six thousand rupees in a thirty-three
lakh portfolio is 0.18%: too small to help if it works and one more thing to
follow either way. Fewer, larger holdings beat more, smaller ones.

The engine's ranking is respected throughout -- this reorders and reweights
within what it proposed rather than substituting a judgement of its own. Where
the candidate pool cannot support the mix, that is said rather than quietly
approximated.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

log = logging.getLogger("alphanivesh.buyplan")

# What a spread of company sizes looks like. Micro is capped rather than
# excluded: it is where a portfolio can earn its keep, and where it can also
# become unsellable.
SIZE_TARGET = {
    "large": Decimal("40"),
    "mid": Decimal("30"),
    "small": Decimal("25"),
    "micro": Decimal("5"),
}

# Below this a position does not move a portfolio whichever way it goes, and
# still has to be followed.
MIN_POSITION = Decimal("15000")

# More than this and nobody keeps track.
MAX_POSITIONS = 8

# A sector at or under this share of the portfolio counts as one the investor
# does not really own.
THIN_SECTOR = Decimal("5")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _size_of(candidate: dict) -> str:
    """Which band a candidate falls in, from whatever the engine called it."""
    raw = str(candidate.get("cap_segment") or candidate.get("size") or "").lower()
    for band in ("mega", "large", "mid", "small", "micro"):
        if raw.startswith(band):
            return "large" if band == "mega" else band
    return "small"


def choose(candidates: list[dict], budget: Decimal,
           held_sectors: dict[str, Decimal],
           portfolio_total: Decimal) -> dict:
    """Which of the ranked candidates to actually buy, and how much of each.

    Candidates arrive in the engine's order, best first. That order is kept
    within each decision -- what changes is which ones are reachable, given
    that the result has to be a portfolio rather than a list.
    """
    if not candidates or budget <= 0:
        return {"picks": [], "why_not": "There is nothing to place."}

    # How many positions the budget supports at a size that matters. A large
    # sum can carry eight; a small one should buy two things properly rather
    # than eight things pointlessly.
    affordable = int(budget / MIN_POSITION)
    positions = max(1, min(affordable, MAX_POSITIONS, len(candidates)))

    if affordable < 1:
        # Everything into the single best candidate that fits, since splitting
        # further would produce holdings too small to be worth owning.
        best = candidates[0]
        return _single(best, budget)

    # Thin means "you hold little or none of this", and the second half was
    # missing.
    #
    # This was built only from sectors already held, so an industry the
    # investor holds nothing of was absent from the dict entirely and never
    # counted as thin. Every buy then read "adds to pharma, which you already
    # hold" about somebody with no pharma at all -- a false claim about their
    # portfolio, which is worse than saying nothing.
    #
    # A sector missing from held_sectors is held at zero. That is as thin as
    # it gets.
    thin = {sector for sector, share in held_sectors.items()
            if _d(share) <= THIN_SECTOR}
    absent = {(c.get("sector") or "").strip() for c in candidates
              if c.get("sector")
              and not any(_same_sector(c.get("sector"), h)
                          for h in held_sectors)}
    thin |= {s for s in absent if s}
    heavy = {sector for sector, share in held_sectors.items()
             if share >= Decimal("20")}

    # Ranked within size band, so the mix can be built without discarding the
    # engine's ordering.
    by_size: dict[str, list[dict]] = {"large": [], "mid": [], "small": [], "micro": []}
    for candidate in candidates:
        by_size[_size_of(candidate)].append(candidate)

    picks: list[dict] = []
    used_sectors: set[str] = set()

    # Fill the bands in the order the target weights them, and within a band
    # prefer a candidate in an industry this portfolio does not already carry.
    for band in ("large", "mid", "small", "micro"):
        share = SIZE_TARGET[band] / 100
        want = max(0, round(positions * float(share)))
        if band == "micro":
            want = min(want, 1)          # the cap, in whole positions

        pool = by_size.get(band) or []
        if not pool:
            continue

        # Candidates in industries the investor is thin in come first; ones in
        # an industry already carrying a fifth of the money come last, however
        # they rank.
        def preference(item: dict) -> tuple:
            sector = str(item.get("sector") or "")
            already = sector in used_sectors
            return (already, sector in heavy, sector not in thin)

        for candidate in sorted(pool, key=preference):
            if len([p for p in picks if _size_of(p) == band]) >= want:
                break
            sector = str(candidate.get("sector") or "")
            if sector and sector in used_sectors:
                continue            # one per industry, so the fix is not a new bet
            picks.append(candidate)
            if sector:
                used_sectors.add(sector)

    # Where the pool could not fill a band, take the best of what remains --
    # but not more micro-caps. The cap is the point of having one, and a
    # fallback that ignores it turns a one-in-eight limit into three in seven,
    # which is what happened on the first real run.
    if len(picks) < positions:
        micro_held = sum(1 for p in picks if _size_of(p) == "micro")
        for candidate in candidates:
            if len(picks) >= positions:
                break
            if candidate in picks:
                continue
            band = _size_of(candidate)
            if band == "micro" and micro_held >= 1:
                continue
            sector = str(candidate.get("sector") or "")
            if sector and sector in used_sectors:
                continue
            picks.append(candidate)
            if band == "micro":
                micro_held += 1
            if sector:
                used_sectors.add(sector)

    if not picks:
        return {"picks": [], "why_not": "None of the candidates fit."}

    return _size_them(picks, budget, thin, portfolio_total, candidates,
                      held_sectors)


def _single(candidate: dict, budget: Decimal) -> dict:
    price = _d(candidate.get("current_price"))
    quantity = int(budget / price) if price > 0 else 0
    return {
        "picks": [{
            **candidate,
            "suggested_quantity": quantity,
            "investable_amount": str((price * quantity).quantize(Decimal("1"))),
            "weight": "100",
            "why_this_one": ("The whole amount into one holding, because "
                             "splitting it further would leave positions too "
                             "small to be worth following."),
        }],
        "note": ("A smaller sum buys one thing properly rather than several "
                 "things pointlessly."),
    }


def _size_them(picks: list[dict], budget: Decimal, thin: set,
               portfolio_total: Decimal, pool: list[dict],
               # What is actually held, so a sector absent from it reads as
               # held at zero rather than as already owned.
               held_sectors: Optional[dict] = None) -> dict:
    """How much of each, and why each one is on the list."""
    # Weighted by band rather than evenly: the target mix is the point, and an
    # even split across whatever was picked would not produce it.
    weights: dict[str, Decimal] = {}
    for pick in picks:
        band = _size_of(pick)
        weights[band] = weights.get(band, Decimal(0)) + SIZE_TARGET[band]

    sized = []
    placed = Decimal(0)

    for pick in picks:
        band = _size_of(pick)
        in_band = [p for p in picks if _size_of(p) == band]
        band_share = SIZE_TARGET[band] / sum(weights.values()) if weights else Decimal(0)
        share = band_share / len(in_band) if in_band else Decimal(0)

        allocated = budget * share
        price = _d(pick.get("current_price"))
        quantity = int(allocated / price) if price > 0 else 0
        amount = price * quantity
        placed += amount

        sector = str(pick.get("sector") or "")
        sized.append({
            **pick,
            "size_band": band,
            "suggested_quantity": quantity,
            "investable_amount": str(amount.quantize(Decimal("1"))),
            "weight": str((share * 100).quantize(Decimal("0.1"))),
            "portfolio_pct": str((amount / portfolio_total * 100).quantize(Decimal("0.01"))
                                 if portfolio_total > 0 else Decimal(0)),
            "why_this_one": _why_chosen(pick, band, sector, thin,
                                        held_sectors),
        })

    # Whatever the mix could not absorb goes to the largest holdings rather
    # than sitting idle. A third of the budget unplaced is not a rounding
    # remainder, it is money doing nothing -- and topping up the large-cap
    # positions is the least risky place to put it.
    spare = budget - placed
    if spare > MIN_POSITION and sized:
        biggest = sorted(sized, key=lambda item: (
            ("large", "mid", "small", "micro").index(item["size_band"])))
        for item in biggest:
            if spare <= 0:
                break
            price = _d(item.get("current_price"))
            if price <= 0:
                continue
            extra = int(spare / price)
            if extra <= 0:
                continue
            item["suggested_quantity"] += extra
            added = price * extra
            item["investable_amount"] = str(
                (_d(item["investable_amount"]) + added).quantize(Decimal("1")))
            item["portfolio_pct"] = str(
                (_d(item["investable_amount"]) / portfolio_total * 100)
                .quantize(Decimal("0.01")) if portfolio_total > 0 else Decimal(0))
            placed += added
            spare -= added

    return {
        "picks": [s for s in sized if s["suggested_quantity"] > 0],
        "placed": str(placed.quantize(Decimal("1"))),
        "left_over": str((budget - placed).quantize(Decimal("1"))),
        "mix": _describe_mix(sized),
        "considered": len(pool),
        "note": ("Chosen from the engine's ranking rather than instead of it. "
                 "What is added is the part a ranking cannot know: the mix of "
                 "company sizes, and which industries this portfolio is already "
                 "carrying too much of."),
    }


def _why_chosen(pick: dict, band: str, sector: str, thin: set,
                held: Optional[dict] = None) -> str:
    """Why this holding, for this portfolio.

    The engine already says what its indicators read. This says what the
    holding does here -- which industry it fills, how easily it could be sold
    on a bad day, and what the grade means in words rather than as a letter.

    "Graded B+ by the engine" was most of what this used to produce, which is
    barely a reason and was identical for every pick that scored similarly.
    A reason that does not distinguish one holding from another is not doing
    the work.
    """
    parts = []

    named = _sector_name(sector)

    # How much of this industry is actually held, matched on meaning rather
    # than spelling -- "Industrial" and "Industrials" are the same thing and an
    # exact comparison said otherwise.
    share = Decimal(0)
    for held_name, held_share in (held or {}).items():
        if _same_sector(sector, held_name):
            share += _d(held_share)

    # A twentieth of a per cent is holding nothing in any sense a reader would
    # recognise. Saying "adds to pharma, which you already hold" about 0.05%
    # is technically true and reads as false, which is the worse failure.
    holds_none = bool(named) and share < Decimal("0.5")
    holds_little = bool(named) and Decimal("0.5") <= share <= THIN_SECTOR

    if named and holds_none:
        parts.append(f"you hold nothing in {named}, so this spreads the "
                     f"portfolio rather than concentrating it")
    elif named and holds_little:
        parts.append(f"you hold {share:.1f}% in {named}, so this spreads the "
                     f"portfolio rather than concentrating it")
    elif named:
        parts.append(f"adds to {named}, which is {share:.1f}% of what you "
                     f"already hold")

    if band == "large":
        parts.append("large enough to sell on a bad day at something near the "
                     "screen price")
    elif band == "mid":
        parts.append("mid-sized, so it moves more than the index in both "
                     "directions")
    elif band == "small":
        parts.append("a small company, which means wider swings and a price on "
                     "exit that can differ from the one on screen")
    elif band == "micro":
        parts.append("a micro-cap, held to one position because they are hard "
                     "to exit when it matters")

    # The grade, in words. A letter means nothing to somebody who has not read
    # the methodology, and most people have not.
    grade = str(pick.get("grade") or "")
    if grade.startswith("A"):
        parts.append("among the strongest the engine ranks")
    elif grade.startswith("B"):
        parts.append("solidly ranked rather than exceptional")
    elif grade.startswith("C"):
        parts.append("middling on the engine's measures, and here because it "
                     "fits the mix rather than because it stands out")

    # What the trend is doing, where the engine has said.
    reading = str(pick.get("rationale") or "").lower()
    if "confirmed uptrend" in reading:
        parts.append("the price has been rising and the trend is confirmed "
                     "rather than a single good week")
    if "overbought" in reading:
        parts.append("though it is bought up at the moment, so a pullback "
                     "would not be a surprise")
    elif "near 52-week high" in reading:
        parts.append("trading near its highest in a year")

    if not parts:
        return "Ranked well by the engine and fits the mix."

    # Three clauses. Five was everything true about the holding rather than
    # the three things worth knowing, and a sentence nobody finishes says
    # nothing however accurate it is.
    parts = parts[:3]

    first = parts[0][0].upper() + parts[0][1:]
    rest = "; ".join(parts[1:])
    return first + ("; " + rest if rest else "") + "."



def _same_sector(a: Optional[str], b: Optional[str]) -> bool:
    """Whether two sector names mean the same industry.

    The engine's candidates and the exposure figures use different
    vocabularies -- "Industrial" against "Industrials", "IT" against
    "Information Technology" -- so an exact match told somebody holding 12.7%
    in industrials that they held nothing in industrial.

    Compared on a normalised form rather than by mapping every pair, because
    the vocabularies will drift again and a mapping would need maintaining
    every time either side adds a name.
    """
    return _normal(a) == _normal(b) if a and b else False


def _normal(name: Optional[str]) -> str:
    """A sector name reduced to what it is actually saying."""
    if not name:
        return ""
    text = name.lower().strip()
    for word in (" sector", " services", "&", " and "):
        text = text.replace(word, " ")
    text = "".join(c for c in text if c.isalnum() or c == " ").strip()
    # Singular, so Industrials and Industrial meet.
    if text.endswith("s") and not text.endswith("ss"):
        text = text[:-1]
    known = {
        "it": "informationtechnology",
        "informationtechnology": "informationtechnology",
        "tech": "informationtechnology",
        "nbfc": "financial",
        "finance": "financial",
        "financial": "financial",
        "bank": "financial",
        "pharma": "healthcare",
        "healthcare": "healthcare",
        "auto": "automobile",
        "fmcg": "fastmovingconsumergood",
    }
    squashed = text.replace(" ", "")
    return known.get(squashed, squashed)


def _sector_name(sector: Optional[str]) -> Optional[str]:
    """A sector as it should read in a sentence.

    Lowercasing everything turned "IT" into "it" -- "you hold almost nothing
    in it" reads as a pronoun with no antecedent. Acronyms keep their case.
    """
    if not sector:
        return None
    name = sector.strip()
    if not name:
        return None
    # An acronym: short, or already all capitals.
    if name.isupper() or len(name) <= 4:
        return name
    return name.lower()


def _describe_mix(picks: list[dict]) -> dict:
    counts: dict[str, int] = {}
    for pick in picks:
        band = pick.get("size_band") or _size_of(pick)
        counts[band] = counts.get(band, 0) + 1

    total = sum(counts.values()) or 1
    micro_share = counts.get("micro", 0) / total * 100

    parts = [f"{count} {band}" for band, count in
             sorted(counts.items(),
                    key=lambda kv: ("large", "mid", "small", "micro").index(kv[0]))]

    return {
        "counts": counts,
        "reading": ("A mix of " + ", ".join(parts) + "."
                    + (f" Micro-caps are {micro_share:.0f}% of the picks, which "
                       f"is where they belong: worth owning, not worth "
                       f"depending on."
                       if counts.get("micro") else
                       " Nothing micro-cap, which keeps all of it sellable.")),
    }
