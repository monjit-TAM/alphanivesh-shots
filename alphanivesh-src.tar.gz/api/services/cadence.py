"""When to say something, and whether there is anything worth saying.

Two questions, and they are not the same one. The cadence answers when somebody
agreed to hear from us. Whether anything has happened worth a message is
answered separately, and a review that arrives on schedule with nothing in it
is how somebody learns to ignore the next one.

**So both have to be true.** The rhythm has come round, and there is something
to say. A quarterly reader with a quiet quarter gets nothing, and that is the
feature rather than a failure.

**Urgent things do not wait.** Somebody who chose an annual review still wants
to know their standing instruction stopped, or that the allowance expires this
month. The cadence governs the review; it does not govern whether we ever
speak, and conflating the two would mean either nagging the annual reader or
failing the one who needed telling.

**One a month per person, roughly, and treat that as the design.** Daily
insight feeds and streaks work for a quarter and then get muted, which is worse
than never having sent anything: the muting takes the important messages with
it.

**And the test for anything at all:** would this be worth an SMS from a person
who knows their money? If not, it does not send.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.cadence")

CADENCES = {
    "monthly": {"days": 30, "name": "every month"},
    "quarterly": {"days": 91, "name": "every three months"},
    "half_yearly": {"days": 182, "name": "twice a year"},
    "annually": {"days": 365, "name": "once a year"},
}

DEFAULT = "quarterly"


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def preference(investor_id: str) -> dict:
    """What somebody asked for, or the default with a note that they have not."""
    row = db.fetch_one(
        """
        SELECT cadence, urgent_anyway, by_email, by_whatsapp, by_push,
               last_review_on, paused_until, asked_on
        FROM contact_preference WHERE investor_id = %s
        """,
        (investor_id,),
    )

    if not row:
        return {
            "chosen": False,
            "cadence": DEFAULT,
            "cadence_name": CADENCES[DEFAULT]["name"],
            "urgent_anyway": True,
            "by_email": True,
            "by_whatsapp": False,
            "by_push": False,
            "last_review_on": None,
            "paused_until": None,
            "reading": ("You have not said how often you want to hear from us, "
                        "so this defaults to every three months. Worth setting "
                        "— a review that arrives more often than somebody wants "
                        "gets ignored, and one that arrives less often than they "
                        "need is not much use either."),
        }

    return {
        "chosen": True,
        "cadence": row["cadence"],
        "cadence_name": CADENCES.get(row["cadence"], {}).get("name", row["cadence"]),
        "urgent_anyway": row["urgent_anyway"],
        "by_email": row["by_email"],
        "by_whatsapp": row["by_whatsapp"],
        "by_push": row["by_push"],
        "last_review_on": (row["last_review_on"].isoformat()
                           if row["last_review_on"] else None),
        "paused_until": (row["paused_until"].isoformat()
                         if row["paused_until"] else None),
        "reading": _reading(row),
    }


def _reading(row: dict) -> str:
    name = CADENCES.get(row["cadence"], {}).get("name", row["cadence"])

    if row["paused_until"] and row["paused_until"] > date.today():
        return (f"Paused until {row['paused_until'].isoformat()}. After that, "
                f"a review {name}.")

    line = f"A review {name}"

    where = [label for label, on in (("by email", row["by_email"]),
                                     ("on WhatsApp", row["by_whatsapp"]),
                                     ("as a notification", row["by_push"]))
             if on]
    if where:
        line += ", " + " and ".join(where)
    line += "."

    if row["urgent_anyway"]:
        line += (" Anything urgent still reaches you between reviews — a "
                 "standing instruction stopping, or an allowance about to "
                 "expire, does not wait for a schedule.")

    return line


def set_preference(investor_id: str, cadence: str, **options: Any) -> dict:
    """Record what somebody asked for."""
    if cadence not in CADENCES:
        raise ValueError(f"cadence must be one of {', '.join(CADENCES)}")

    with db.connection() as conn:
        conn.execute(
            """
            INSERT INTO contact_preference
                (investor_id, cadence, urgent_anyway, by_email, by_whatsapp,
                 by_push, paused_until)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (investor_id) DO UPDATE SET
                cadence = EXCLUDED.cadence,
                urgent_anyway = EXCLUDED.urgent_anyway,
                by_email = EXCLUDED.by_email,
                by_whatsapp = EXCLUDED.by_whatsapp,
                by_push = EXCLUDED.by_push,
                paused_until = EXCLUDED.paused_until,
                updated_at = now()
            """,
            (investor_id, cadence,
             bool(options.get("urgent_anyway", True)),
             bool(options.get("by_email", True)),
             bool(options.get("by_whatsapp", False)),
             bool(options.get("by_push", False)),
             options.get("paused_until")),
        )
    return preference(investor_id)


def due(investor_id: str) -> dict:
    """Whether a review is owed, and whether there is anything to put in it.

    Both have to be true. A quarterly reader with a quiet quarter gets nothing,
    which is the feature — a review that arrives on schedule with nothing in it
    teaches somebody to ignore the next one, and the next one may be the one
    that mattered.
    """
    pref = preference(investor_id)

    paused = pref.get("paused_until")
    if paused and date.fromisoformat(paused) > date.today():
        return {"due": False, "why": f"Paused until {paused}."}

    every = CADENCES[pref["cadence"]]["days"]
    last = pref.get("last_review_on")

    if last:
        days_since = (date.today() - date.fromisoformat(last)).days
    else:
        # Never reviewed. Due once they have been here long enough for there
        # to be something to review -- a summary of a fortnight is a summary
        # of nothing.
        first = db.fetch_one(
            "SELECT min(shown_at)::date AS started FROM advice_ledger "
            "WHERE investor_id = %s", (investor_id,))
        started = (first or {}).get("started")
        if not started:
            return {"due": False, "why": "Nothing has been shown to them yet."}
        days_since = (date.today() - started).days

    if days_since < every:
        return {
            "due": False,
            "why": (f"{days_since} days since the last one, and they asked for "
                    f"{pref['cadence_name']}."),
            "next_in_days": every - days_since,
        }

    worth = _worth_saying(investor_id)
    if not worth["anything"]:
        return {
            "due": False,
            "why": ("The rhythm has come round and nothing has happened worth "
                    "a message. A review that arrives with nothing in it "
                    "teaches somebody to ignore the next one."),
            "quiet_since": days_since,
        }

    return {
        "due": True,
        "days_since": days_since,
        "cadence": pref["cadence"],
        "by": [k for k in ("by_email", "by_whatsapp", "by_push") if pref.get(k)],
        "contents": worth["items"],
        "reading": worth["reading"],
    }


def _worth_saying(investor_id: str) -> dict:
    """Is there anything in this review, or would it be a newsletter?

    Assembled from the things that already know how to notice something: what
    changed while they were away, what became of earlier advice, and whether
    anything is newly urgent.
    """
    items = []

    from . import away, followup

    try:
        gone = away.since_last_visit(investor_id)
        if gone and not gone.get("quiet"):
            for change in (gone.get("changes") or [])[:3]:
                items.append({"kind": "changed", "headline": change["headline"],
                              "detail": change.get("detail")})
    except Exception:
        pass

    try:
        before = followup.since_last_time(investor_id)
        if before:
            for done in (before.get("acted_on") or [])[:2]:
                if done.get("produced_reading"):
                    items.append({"kind": "worked",
                                  "headline": done.get("outcome"),
                                  "detail": done.get("produced_reading")})
    except Exception:
        pass

    urgent = urgent_now(investor_id)
    for item in urgent.get("items", []):
        items.append({"kind": "urgent", "headline": item["headline"],
                      "detail": item.get("detail")})

    return {
        "anything": bool(items),
        "items": items[:5],
        "reading": (f"{len(items)} thing{'s' if len(items) != 1 else ''} worth "
                    f"saying." if items else "Nothing worth saying."),
    }


def urgent_now(investor_id: str) -> dict:
    """What should not wait for a schedule.

    Deliberately short. Every entry here has a consequence and a deadline, and
    anything without both belongs in the review instead — the value of an
    urgent channel is entirely in how rarely it is used.
    """
    items = []
    today = date.today()

    # The allowance that dies in March. Worth money, and only in the months
    # where acting is still possible.
    if today.month in (1, 2, 3):
        try:
            from . import harvest
            chance = harvest.opportunity(investor_id)
            if chance and chance.get("worth_doing"):
                items.append({
                    "code": "year_ending",
                    "headline": (f"₹{int(_d(chance['available_gain'])):,} of "
                                 f"tax-free allowance expires on 31 March."),
                    "detail": (f"Realising that much long-term gain before the "
                               f"year ends saves about "
                               f"₹{int(_d(chance['saving'])):,}, and the "
                               f"allowance does not carry forward."),
                    "deadline": f"{today.year}-03-31",
                })
        except Exception:
            pass

    # A standing instruction that stopped. Our behavioural engine sees this
    # and nobody else tells people.
    try:
        from . import behaviour
        how = behaviour.profile(investor_id)
        style = ((how or {}).get("style") or {})
        if style.get("style") == "monthly" and style.get("last"):
            last = str(style["last"])[:7]
            year, month = int(last[:4]), int(last[5:7])
            quiet = (today.year - year) * 12 + (today.month - month)
            if quiet >= 2:
                items.append({
                    "code": "sip_stopped",
                    "headline": f"Your monthly investing stopped about "
                                f"{quiet} months ago.",
                    "detail": ("A standing instruction lapsing — an expired "
                               "card, a changed account — is the most common "
                               "way a plan stops working, and nobody sends a "
                               "message when it happens."),
                })
    except Exception:
        pass

    return {"items": items, "any": bool(items)}


def mark_sent(investor_id: str) -> None:
    """Note that a review went, so the next is due from now."""
    with db.connection() as conn:
        conn.execute(
            """
            INSERT INTO contact_preference (investor_id, last_review_on)
            VALUES (%s, current_date)
            ON CONFLICT (investor_id)
            DO UPDATE SET last_review_on = current_date, updated_at = now()
            """,
            (investor_id,),
        )


def everybody_due() -> list[dict]:
    """Who is owed a review today.

    For whatever runs on a schedule. Returns only those where both the rhythm
    has come round and there is something to say, so a caller can send without
    deciding anything.
    """
    rows = db.fetch_all("SELECT id, display_name FROM investors")
    out = []
    for row in rows:
        try:
            verdict = due(row["id"])
        except Exception as err:
            log.warning("cadence check failed for %s: %s", row["id"], err)
            continue
        if verdict.get("due"):
            out.append({"investor_id": row["id"],
                        "name": row["display_name"],
                        **verdict})
    return out
