"""Talking to CASParser.

CASParser turns a consolidated account statement PDF into structured JSON. It is
the same service AlphaLensMF and AlphaLens Stocks already use in production, and
this client is deliberately a thin wrapper: it sends the file, checks the
envelope, and hands back the payload. Anything clever happens in the mapping
layer, where it can be tested against a real document.

A warning worth carrying: the parser's output is not always sound. Statements in
production have come back with the AMC name misaligned against the scheme, and
in one case an entire table row folded into a scheme name with unrelated numbers
in the numeric fields. The mapping layer validates before it trusts, and the
importer quarantines what fails. Do not let anything skip that check because the
JSON looked well-formed.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("alphanivesh.casparser")

BASE_URL = "https://api.casparser.in/v4"

# A statement can take a while on a large portfolio.
TIMEOUT = httpx.Timeout(120.0, connect=15.0)


class CASParserError(Exception):
    """Something went wrong that the person who uploaded should hear about."""

    def __init__(self, message: str, *, retryable: bool = False):
        super().__init__(message)
        self.retryable = retryable


def _api_key() -> str:
    """Read the key from the environment file rather than the environment.

    Keeping it out of the process environment means it does not appear in a
    crash dump, a subprocess, or anything that prints os.environ.
    """
    key = os.getenv("CASPARSER_API_KEY")
    if key:
        return key

    env_path = Path(os.getenv("ALPHAWEALTH_ENV_FILE", "/opt/alphawealth/.env"))
    try:
        for line in env_path.read_text().splitlines():
            if line.startswith("CASPARSER_API_KEY="):
                return line.split("=", 1)[1].strip()
    except OSError:
        pass

    raise CASParserError(
        "Statement parsing is not configured on this server. "
        "Nothing you did caused this."
    )


def _headers() -> dict:
    return {"x-api-key": _api_key()}


def _json_headers(inbox_token: Optional[str] = None) -> dict:
    headers = {"x-api-key": _api_key(), "Content-Type": "application/json"}
    if inbox_token:
        headers["x-inbox-token"] = inbox_token
    return headers


def _unwrap(response: httpx.Response) -> dict:
    """Pull the payload out of CASParser's envelope, or raise something useful.

    Responses look like {"status": ..., "msg": ..., "data": {...}}. A failure
    carries a message we can generally show the user as-is, since they are
    written for the person holding the statement rather than for us.
    """
    if response.status_code == 401 or response.status_code == 403:
        raise CASParserError(
            "We could not reach the statement reader. Please try again shortly."
        )
    if response.status_code == 429:
        raise CASParserError(
            "The statement reader is busy. Please try again in a few minutes.",
            retryable=True,
        )
    if response.status_code >= 500:
        raise CASParserError(
            "The statement reader is having trouble. Please try again shortly.",
            retryable=True,
        )

    try:
        body = response.json()
    except ValueError:
        log.error("casparser returned non-JSON: %s %s",
                  response.status_code, response.text[:200])
        raise CASParserError("We could not read the response from the statement reader.")

    # A refusal is wrapped: {"status": "failed", "msg": ..., "data": {}}.
    # A successful parse is not wrapped at all -- the statement comes back at
    # the top level, with keys like mutual_funds and demat_accounts. Assuming
    # an envelope in both cases meant throwing away every good response.
    if body.get("status") == "failed":
        # Info rather than error: a wrong password is an ordinary event, not a
        # fault in the system.
        log.info("casparser refused a statement: %s | %s",
                 response.status_code, str(body.get("msg"))[:200])
        # Keep the provider's own words. They are written for the person
        # holding the statement and usually say precisely what is wrong;
        # a generic substitute helps nobody.
        message = (body.get("msg") or body.get("detail") or "").strip()
        if not message:
            message = (
                "We could not read that statement. Check that it is the original "
                "PDF from CAMS, KFintech, CDSL or NSDL, and that the password is right."
            )
        raise CASParserError(_friendly(message))

    # Some endpoints do wrap their result; the parse endpoints do not. Accept
    # either rather than depending on which.
    payload = body.get("data") if isinstance(body.get("data"), dict) and body["data"] else body

    known = ("mutual_funds", "demat_accounts", "insurance", "nps", "investor")
    if not any(k in payload for k in known):
        log.error("casparser returned an unfamiliar shape: %s", sorted(payload.keys())[:12])
        raise CASParserError("We read that file but did not recognise it as a statement.")

    return payload


# The parser's messages are mostly fine to show. These are the ones worth
# rewording, because the original assumes the reader knows what a CAS is.
_REPHRASE = {
    "no pdf file or url detected": "No file arrived. Please choose your statement and try again.",
    "incorrect password": "That password did not open the statement. It is usually your PAN in capitals, or the password the registrar emailed you.",
    "invalid password": "That password did not open the statement. It is usually your PAN in capitals, or the password the registrar emailed you.",
    "unsupported file": "That file is not a statement we can read. It should be the PDF sent by CAMS, KFintech, CDSL or NSDL.",
}


def _friendly(message: str) -> str:
    return _REPHRASE.get(message.strip().lower(), message)


def parse_statement(pdf_bytes: bytes, password: str, filename: str = "statement.pdf") -> dict:
    """Send a statement PDF and get its contents back as structured data.

    `smart/parse` works out for itself which registrar produced the statement,
    which saves asking the person a question they will not reliably know the
    answer to.
    """
    if not pdf_bytes:
        raise CASParserError("No file arrived. Please choose your statement and try again.")

    # The field is pdf_file, and the password is only sent when there is one.
    # Both taken from the AlphaLens Stocks implementation, which has been
    # parsing real statements in production for months.
    files = {"pdf_file": (filename, pdf_bytes, "application/pdf")}
    data = {"password": password} if password else {}

    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/smart/parse",
                headers=_headers(),
                files=files,
                data=data,
            )
    except httpx.TimeoutException:
        raise CASParserError(
            "Reading the statement took too long. Please try again.", retryable=True
        )
    except httpx.HTTPError:
        raise CASParserError(
            "We could not reach the statement reader. Please try again shortly.",
            retryable=True,
        )

    return _unwrap(response)


def request_statement(pan: str, email: str, provider: str = "kfintech") -> dict:
    """Ask a registrar to email a fresh statement to the investor.

    Not used by the upload path. Kept here because it is the natural next route
    to offer someone who does not have a statement to hand, and it belongs with
    the rest of the client rather than somewhere else later.
    """
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/generate",
                headers=_headers(),
                json={"pan": pan, "email": email, "provider": provider},
            )
    except httpx.HTTPError:
        raise CASParserError(
            "We could not reach the statement service. Please try again shortly.",
            retryable=True,
        )

    return _unwrap(response)


# ---------------------------------------------------------------------------
# Asking a registrar to send a statement
# ---------------------------------------------------------------------------


def generate_statement(pan: str, email: str, password: str,
                       from_date: str = "1990-01-01") -> dict:
    """Ask CAMS and KFintech to email a consolidated statement.

    The date range goes back to 1990 deliberately. A statement covering only
    recent months leaves the return uncomputable -- our own XIRR declines to
    answer when it cannot see the purchases behind the holdings -- so there is
    no reason to ask for less than everything.
    """
    from datetime import date as _date

    payload = {
        "pan": pan.strip().upper(),
        "email": email.strip().lower(),
        "password": password,
        "from_date": from_date,
        "to_date": _date.today().isoformat(),
    }
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(f"{BASE_URL}/generate", headers=_json_headers(),
                                   json=payload)
    except httpx.HTTPError:
        raise CASParserError("We could not reach the statement service. "
                             "Please try again shortly.", retryable=True)
    return _unwrap(response)


# ---------------------------------------------------------------------------
# Fetching straight from the depository
# ---------------------------------------------------------------------------


def cdsl_request_otp(pan: str, bo_id: str, dob: str) -> dict:
    """Start a CDSL fetch. They text a code to the registered mobile.

    Returns the session id that the verify step needs.
    """
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/cdsl/fetch", headers=_json_headers(),
                json={"pan": pan.strip().upper(),
                      "bo_id": re.sub(r"\D", "", bo_id),
                      "dob": dob.strip()},
            )
    except httpx.HTTPError:
        raise CASParserError("We could not reach CDSL just now. Please try again shortly.",
                             retryable=True)

    data = _unwrap(response)
    if not data.get("session_id"):
        raise CASParserError(
            "CDSL could not match those details. Check the PAN, BO ID and date of "
            "birth against your demat account."
        )
    return data


def cdsl_verify_otp(session_id: str, otp: str, num_periods: int = 1) -> dict:
    """Hand CDSL the code and get the statements back."""
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/cdsl/fetch/{session_id}/verify",
                headers=_json_headers(),
                json={"otp": re.sub(r"\D", "", otp), "num_periods": num_periods},
            )
    except httpx.HTTPError:
        raise CASParserError("We could not reach CDSL just now. Please try again shortly.",
                             retryable=True)
    return _unwrap(response)


def cdsl_parse(pdf_bytes: bytes, filename: str = "cas.pdf") -> dict:
    """Parse a statement file that CDSL handed back as a download."""
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/cdsl/parse", headers=_headers(),
                files={"pdf_file": (filename, pdf_bytes, "application/pdf")},
            )
    except httpx.HTTPError:
        raise CASParserError("We could not read that statement. Please try again shortly.",
                             retryable=True)
    return _unwrap(response)


def fetch_file(url: str) -> bytes:
    """Download a statement CDSL pointed us at."""
    try:
        with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
            response = client.get(url)
            response.raise_for_status()
            return response.content
    except httpx.HTTPError:
        raise CASParserError("We could not download one of the statements.", retryable=True)


# ---------------------------------------------------------------------------
# Reading statements out of a mailbox
# ---------------------------------------------------------------------------

INBOX_PROVIDERS = ("gmail", "microsoft", "zoho")


def inbox_connect(provider: str, redirect_uri: str, state: str) -> dict:
    """Begin the consent flow. Returns the URL to send the person to."""
    if provider not in INBOX_PROVIDERS:
        provider = "gmail"
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/inbox/connect", headers=_json_headers(),
                json={"provider": provider, "redirect_uri": redirect_uri, "state": state},
            )
    except httpx.HTTPError:
        raise CASParserError("We could not start the connection. Please try again shortly.",
                             retryable=True)

    data = _unwrap(response)
    if not data.get("oauth_url"):
        raise CASParserError("We could not start the connection. Please try again shortly.")
    return data


def inbox_status(inbox_token: str) -> dict:
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(f"{BASE_URL}/inbox/status",
                                   headers=_json_headers(inbox_token))
            return response.json()
    except (httpx.HTTPError, ValueError):
        return {}


def inbox_disconnect(inbox_token: str) -> None:
    """Revoke upstream. Failure here is not fatal: we revoke locally regardless,
    because a person asking to disconnect should not be told to try again."""
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            client.post(f"{BASE_URL}/inbox/disconnect", headers=_json_headers(inbox_token))
    except httpx.HTTPError:
        pass


def inbox_search(inbox_token: str, start: str, end: str) -> dict:
    """Look for statements in one window of the mailbox.

    Callers should walk a long range in short windows rather than asking for it
    all at once -- see inbox_search_range.
    """
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/inbox/cas", headers=_json_headers(inbox_token),
                json={"start_date": start, "end_date": end},
            )
            return response.json()
    except (httpx.HTTPError, ValueError):
        return {}


def inbox_search_range(inbox_token: str, months: int = 12) -> tuple[list[dict], bool]:
    """Walk a mailbox over several months and collect the statements found.

    Thirty-day windows, six at a time. Both numbers are from the implementation
    that has been doing this in production: mail providers reject or time out on
    long windows, and asking sequentially takes about nineteen seconds for a
    year, which becomes a minute and a half over five. Six in parallel keeps a
    five-year search near fifteen seconds and stays inside the rate limit.

    Returns the files found and whether the connection needs re-authorising.
    """
    from concurrent.futures import ThreadPoolExecutor
    from datetime import date as _date, timedelta as _td

    end = _date.today()
    start = end - _td(days=30 * max(1, min(months, 60)))

    windows: list[tuple[str, str]] = []
    cursor = start
    while cursor < end:
        stop = min(cursor + _td(days=30), end)
        windows.append((cursor.isoformat(), stop.isoformat()))
        cursor = stop

    found: dict[str, dict] = {}
    needs_reconnect = False

    with ThreadPoolExecutor(max_workers=6) as pool:
        for result in pool.map(lambda w: inbox_search(inbox_token, w[0], w[1]), windows):
            if result.get("requires_reconnect"):
                needs_reconnect = True
                break
            for item in result.get("files") or []:
                # The same statement turns up in overlapping windows; the id is
                # what makes them one file rather than several.
                key = str(item.get("id") or item.get("message_id") or item.get("file_url"))
                if key and key not in found:
                    found[key] = item

    return list(found.values()), needs_reconnect


def inbox_download(inbox_token: str, file_ref: dict) -> Optional[bytes]:
    """Retrieve one statement the mailbox search turned up."""
    url = file_ref.get("url") or file_ref.get("file_url") or file_ref.get("download_url")
    if not url:
        return None
    try:
        with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
            response = client.get(url, headers={"x-inbox-token": inbox_token})
            response.raise_for_status()
            return response.content
    except httpx.HTTPError:
        return None
