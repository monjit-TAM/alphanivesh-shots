"""What the investor agreed to do, order by order.

Under an advisory licence the decision to transact is the investor's. Not "they
agreed to the plan", not "they signed an agreement in March" — **this order,
this quantity, this moment**, tied to the piece of advice that prompted it.

That evidence is the difference between an adviser with an execution partner
and unauthorised portfolio management, and it is the first thing a regulator
asks for. It cannot be reconstructed afterwards, so it is captured before
anything is placed or not at all.

**What is stored is what they saw.** Not a boolean, but the instrument, the
side, the quantity, the price on the screen, the estimated cost, and the ledger
row that advised it. An investor who says "I never agreed to sell that" is
answered by producing the screen they agreed on, not by an assertion that a box
was ticked.

**Consent expires**, and the window is short. Somebody who agreed against
Monday's prices has not agreed to Friday's, and a mandate outliving the figures
it was given on is not consent to anything. Thirty minutes for equities, where
the price moves; a day for funds, which transact at a NAV nobody has seen yet.

**And nothing here places an order.** This records agreement. Placing is a
separate step that reads these rows and refuses without one, so a bug in the
execution path cannot manufacture consent that was never given.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.consent")

# How long agreement lasts.
#
# An equity price moves while somebody reads; a fund transacts at a NAV struck
# after the cut-off, so the price was never on the screen to begin with and the
# window is about the decision rather than the quote.
EQUITY_MINUTES = 30
FUND_HOURS = 24


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _window(kind: str) -> timedelta:
    return (timedelta(hours=FUND_HOURS) if kind in ("mutual_fund", "etf")
            else timedelta(minutes=EQUITY_MINUTES))


def may_transact(investor_id: str) -> dict:
    """Whether an order can be consented to at all.

    Checked before anything is shown, because offering somebody a confirm
    button and refusing it afterwards is worse than not offering it.
    """
    from . import advisers, referrals

    standing = advisers.may_advise(investor_id)
    if not standing.get("may"):
        return {
            "may": False,
            "why": standing.get("why"),
            "fix": standing.get("fix"),
        }

    needed = referrals.what_is_needed(investor_id)
    if needed.get("needed"):
        return {
            "may": False,
            "why": needed.get("why"),
            "fix": "The agreement has to be signed first.",
        }

    return {"may": True, "adviser": standing.get("adviser")}


def ask(investor_id: str, orders: list[dict], *,
        ledger_id: Optional[str] = None) -> dict:
    """Prepare what will be shown, without recording anything.

    Separate from `give` on purpose: this builds the screen, and consent is a
    second act by the person reading it. A single call that both showed and
    recorded would make the record say somebody agreed to something at the
    moment it was rendered.
    """
    standing = may_transact(investor_id)
    if not standing.get("may"):
        return {"may": False, **standing}

    lines, total_cost, total_tax = [], Decimal(0), Decimal(0)
    for order in orders:
        cost = _d(order.get("est_cost"))
        tax = _d(order.get("est_tax"))
        total_cost += cost
        total_tax += tax
        lines.append({
            "instrument_id": order.get("instrument_id"),
            "symbol": order.get("symbol"),
            "name": order.get("name"),
            "side": order.get("side"),
            "quantity": str(order.get("quantity") or ""),
            "amount": str(order.get("amount") or ""),
            "price_shown": str(order.get("price") or ""),
            "est_cost": str(cost),
            "est_tax": str(tax),
            "kind": order.get("asset_class"),
        })

    kinds = {o.get("asset_class") for o in orders}
    window = max((_window(k) for k in kinds), default=_window("equity"))

    return {
        "may": True,
        "orders": lines,
        "total_cost": str(total_cost),
        "total_tax": str(total_tax),
        "good_for_minutes": int(window.total_seconds() // 60),
        "adviser": standing.get("adviser"),
        "ledger_id": ledger_id,
        # Said plainly on the screen, because somebody agreeing to a trade
        # should know what they are agreeing to and what they are not.
        "what_this_is": (
            "Agreeing here places these orders. The prices shown are the last "
            "we saw and are not what you will get — a market order fills at "
            "whatever the market is when it arrives, and a fund transacts at a "
            "price struck after the cut-off."
        ),
        "what_this_is_not": (
            "This is not a standing instruction. It covers these orders and "
            "nothing else, and it lapses if you do not act on it."
        ),
    }


def give(investor_id: str, orders: list[dict], *,
         ledger_id: Optional[str] = None,
         ip: Optional[str] = None,
         user_agent: Optional[str] = None,
         how: str = "in_app",
         otp_ref: Optional[str] = None) -> dict:
    """Record it. One row per order, all sharing what was on the screen.

    A row per order because each is placed, filled or rejected separately, and
    a single row covering four orders cannot say that three went and one did
    not.
    """
    standing = may_transact(investor_id)
    if not standing.get("may"):
        raise PermissionError(standing.get("why") or "Cannot transact.")
    if not orders:
        raise ValueError("Nothing to agree to.")

    from . import advisers
    adviser = advisers.of_record(investor_id)

    kinds = {o.get("asset_class") for o in orders}
    expires = datetime.now(timezone.utc) + max(
        (_window(k) for k in kinds), default=_window("equity"))

    # The whole basket as it appeared, stored against every row, so any one of
    # them can reproduce the screen rather than describe it.
    shown = json.dumps({"orders": orders,
                        "shown_at": datetime.now(timezone.utc).isoformat()},
                       ensure_ascii=False, default=str)

    made = []
    with db.connection() as conn:
        for order in orders:
            row = conn.execute(
                """
                INSERT INTO order_consent
                    (investor_id, adviser_id, ledger_id, instrument_id, symbol,
                     name, side, quantity, amount, price_shown, est_cost,
                     est_tax, shown, expires_at, ip, user_agent, how, otp_ref)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s)
                RETURNING id
                """,
                (investor_id, (adviser or {}).get("adviser_id"), ledger_id,
                 order.get("instrument_id"), order.get("symbol"),
                 order.get("name"), order.get("side"),
                 order.get("quantity"), order.get("amount"),
                 order.get("price"), order.get("est_cost"),
                 order.get("est_tax"), shown, expires, ip,
                 (user_agent or "")[:400], how, otp_ref),
            ).fetchone()
            made.append(row["id"])

    log.info("consent for %d orders from %s, under %s", len(made),
             investor_id, (adviser or {}).get("name") or "no adviser")

    _note_in_ledger(investor_id, orders, made, adviser)

    return {
        "consent_ids": made,
        "expires_at": expires.isoformat(),
        "good_for_minutes": int((expires - datetime.now(timezone.utc))
                                .total_seconds() // 60),
        "reading": (f"Recorded. These {len(made)} order"
                    f"{'s' if len(made) != 1 else ''} can be placed for the "
                    f"next {int((expires - datetime.now(timezone.utc)).total_seconds() // 60)} "
                    f"minutes, after which you would need to agree again "
                    f"against the prices at that time."),
    }


def _note_in_ledger(investor_id: str, orders: list[dict], ids: list[str],
                    adviser: Optional[dict]) -> None:
    """Consent is a thing that happened to somebody's money.

    It belongs in the same record as the advice that prompted it, so the
    sequence reads in one place rather than needing two tables joined by
    somebody who knows to.
    """
    try:
        from . import ledger
        ledger.record(
            investor_id, "notification",
            said={"agreed_to": [
                {"side": o.get("side"), "symbol": o.get("symbol"),
                 "quantity": str(o.get("quantity") or ""),
                 "amount": str(o.get("amount") or "")} for o in orders]},
            basis={"consent_ids": ids,
                   "adviser": (adviser or {}).get("name"),
                   "registration": (adviser or {}).get("registration_no")},
            surface="consent")
    except Exception:                                            # pragma: no cover
        log.error("consent recorded but not in the ledger for %s", investor_id)


def open_for(investor_id: str) -> list[dict]:
    """Consent given and not yet used, with what is left of its life."""
    rows = db.fetch_all(
        """
        SELECT id, symbol, name, side, quantity, amount, price_shown,
               est_cost, given_at, expires_at
        FROM order_consent
        WHERE investor_id = %s AND used_at IS NULL AND withdrawn_at IS NULL
          AND expires_at > now()
        ORDER BY given_at DESC
        """,
        (investor_id,))
    now = datetime.now(timezone.utc)
    return [{
        "id": r["id"], "symbol": r["symbol"], "name": r["name"],
        "side": r["side"],
        "quantity": str(r["quantity"] or ""),
        "amount": str(r["amount"] or ""),
        "price_shown": str(r["price_shown"] or ""),
        "given_at": r["given_at"].isoformat(),
        "minutes_left": max(0, int((r["expires_at"] - now).total_seconds() // 60)),
    } for r in rows]


def claim(consent_id: str, order_ref: str) -> Optional[dict]:
    """Spend a consent to place an order.

    Marked used in the same statement that reads it, so two placements racing
    cannot both succeed against one agreement. Returns None where it has
    expired, been used, or been withdrawn -- and the caller must treat that as
    a refusal to place rather than as an error to retry.
    """
    row = db.fetch_one(
        """
        UPDATE order_consent
        SET used_at = now(), order_ref = %s
        WHERE id = %s AND used_at IS NULL AND withdrawn_at IS NULL
          AND expires_at > now()
        RETURNING id, investor_id, symbol, side, quantity, amount
        """,
        (order_ref, consent_id))
    if not row:
        log.warning("consent %s could not be claimed: expired, used or "
                    "withdrawn", consent_id)
        return None
    return dict(row)


def withdraw(investor_id: str, consent_id: str) -> bool:
    """Change your mind, before it is used."""
    row = db.fetch_one(
        """
        UPDATE order_consent SET withdrawn_at = now()
        WHERE id = %s AND investor_id = %s AND used_at IS NULL
        RETURNING id
        """,
        (consent_id, investor_id))
    return bool(row)
