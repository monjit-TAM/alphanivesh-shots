"""Talking to the shared data layer on alphaforge-prod.

Alpha Data Service (port 5004) is the only layer built for consumption from
another box: sixty-eight endpoints over licensed feeds, the fund vault and the
company master, Redis-cached, behind a key. Everything AlphaNivesh needs about
prices, fundamentals and fund analytics is there, and most of it is better than
anything we would build here.

Reached over the DigitalOcean VPC rather than the public address, so the
traffic never leaves their network.

Four things the integration guide warns about, all of which shape this file:

  The auth middleware returns 500 rather than 401 on a missing key. A 500 from
  this service means "no key" at least as often as it means "broken", so the
  error handling says so instead of reporting a server fault.

  OHLCV is the unadjusted exchange record, with 561 known price seams where
  splits and bonuses were never back-applied. Anything computed across a seam
  is wrong, so we do not compute returns from it.

  Several endpoints answer `computable: false` with a note meant to be shown to
  a person. That note is carried through rather than flattened into an empty
  state.

  Vault coverage is thin outside ICICI and Nippon. A fund with no disclosures
  returns nothing, which is a fact about the data rather than an error.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

import httpx

log = logging.getLogger("alphanivesh.dataservice")

# The VPC address. The public one works too but the traffic would leave DO's
# network for no reason.
BASE_URL = os.environ.get("ALPHA_DATA_URL", "http://10.122.0.2:5004")
API_KEY = os.environ.get("ALPHA_DATA_KEY", "alpha_data_internal_2026")

# Generous, because some fund endpoints compute over years of NAV history.
TIMEOUT = httpx.Timeout(30.0, connect=6.0)


class DataServiceError(Exception):
    """The service could not answer. Carries something worth showing."""


class NotAvailable(DataServiceError):
    """The service answered honestly that it does not hold this."""


def _client() -> httpx.Client:
    return httpx.Client(base_url=BASE_URL, timeout=TIMEOUT,
                        headers={"X-API-Key": API_KEY})


def _get(path: str, **params: Any) -> dict:
    try:
        with _client() as client:
            response = client.get(path, params={k: v for k, v in params.items()
                                                if v is not None})
    except httpx.HTTPError as err:
        raise DataServiceError(f"could not reach the data service: {err}")

    if response.status_code == 404:
        # Their 404 is structured and says which sources were tried. Renamed
        # symbols are the usual cause -- PVR became PVRINOX.
        raise NotAvailable(_detail(response) or "not held")
    if response.status_code == 500:
        # Documented: a missing or wrong key crashes the middleware rather than
        # returning 401. Saying "server error" would send somebody debugging
        # the wrong box.
        raise DataServiceError(
            "the data service rejected the request; usually the API key")
    if response.status_code >= 400:
        raise DataServiceError(_detail(response) or f"status {response.status_code}")

    try:
        return response.json()
    except ValueError:
        raise DataServiceError("the data service returned something unreadable")


def _detail(response: httpx.Response) -> Optional[str]:
    try:
        body = response.json()
    except ValueError:
        return None
    return body.get("detail") or body.get("message") or body.get("note")


def healthy() -> bool:
    """Whether the service is up. Open endpoint, no key needed."""
    try:
        with httpx.Client(base_url=BASE_URL, timeout=httpx.Timeout(5.0)) as client:
            return client.get("/health").status_code == 200
    except httpx.HTTPError:
        return False


# ---------------------------------------------------------------------------
# Shares
# ---------------------------------------------------------------------------


def quote(symbol: str) -> dict:
    """The current price, or yesterday's close said plainly.

    When no live source answers, the service returns the bhavcopy close with
    `is_live: false` and an `as_of` date rather than pretending. Both are
    passed through: showing a stale price as live is the kind of small lie that
    makes everything else suspect.
    """
    return _get(f"/data/equity/quote/{symbol.upper()}")


def _post(path: str, body: dict) -> dict:
    try:
        with _client() as client:
            response = client.post(path, json=body)
    except httpx.HTTPError as err:
        raise DataServiceError(f"could not reach the data service: {err}")

    if response.status_code == 500:
        raise DataServiceError(
            "the data service rejected the request; usually the API key")
    if response.status_code >= 400:
        raise DataServiceError(_detail(response) or f"status {response.status_code}")
    try:
        return response.json()
    except ValueError:
        raise DataServiceError("the data service returned something unreadable")



def quotes(symbols: list[str]) -> dict[str, dict]:
    """Many prices in one call, keyed by symbol.

    POST with the symbols in the body -- the route is documented with no
    parameters at all, and a GET returns 405. The response nests them under
    `quotes`; this returns that mapping directly, because a caller wanting
    prices should not have to know the envelope.

    Batched rather than looped. The single-quote route is cached for fifteen
    seconds and shares an upstream rate limit with every other product on that
    box, and Groww already returns 429 under load.
    """
    if not symbols:
        return {}
    payload = _post("/data/equity/quotes",
                    {"symbols": [s.strip().upper() for s in symbols if s and s.strip()]})
    quoted = payload.get("quotes")
    return quoted if isinstance(quoted, dict) else {}


# Sources that mean a live market price rather than a stored close. Worth
# distinguishing: showing yesterday's close as today's price is the kind of
# small lie that makes every other figure suspect.
LIVE_SOURCES = {"kite", "groww", "truedata"}


def is_live(quote: dict) -> bool:
    return str(quote.get("source", "")).lower() in LIVE_SOURCES


def fundamentals(symbol: str) -> dict:
    """Ratios, growth and quality for one company.

    Preferred over calling Alpha Fundamentals on 5015 directly: this proxies the
    same data, joins the company master for sector and industry, caches for a
    day, and is the only one of the two with a key.
    """
    return _get(f"/data/equity/fundamentals/{symbol.upper()}")


def ohlcv(symbol: str, period: str = "1y", interval: str = "1d") -> dict:
    """Daily bars for a share.

    `period` is the only range parameter that works -- start and end are
    accepted and ignored. Valid: 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, max.

    The series is the unadjusted exchange record: splits and bonuses are not
    back-applied, and there are hundreds of known seams where a price steps for
    a corporate action rather than a market move. Anything computed across one
    is wrong, so callers should detect them rather than assume continuity.
    """
    return _get(f"/data/equity/ohlcv/{symbol.upper()}",
                period=period, interval=interval)


def profile(symbol: str) -> dict:
    return _get(f"/data/equity/profile/{symbol.upper()}")


def resolve_isins(isins: list[str]) -> dict:
    """ISIN to symbol, against their master rather than our copy."""
    if not isins:
        return {}
    try:
        with _client() as client:
            response = client.post("/data/equity/resolve-isins",
                                   json={"isins": [i.upper() for i in isins]})
            response.raise_for_status()
            return response.json()
    except httpx.HTTPError as err:
        raise DataServiceError(f"could not resolve those ISINs: {err}")


# ---------------------------------------------------------------------------
# Funds
# ---------------------------------------------------------------------------


def mf_screener(category: str = "", *, sort: str = "cat_rank",
                limit: int = 10, plan: str = "Direct",
                min_roll3: Optional[float] = None) -> list[dict]:
    """Funds in a category, ranked on their own rolling record.

    Their note puts the case better than a summary would: point returns flatter
    or damn by endpoint luck, and rolling distributions do not. Every figure
    here is computed across all weekly-stepped three-year windows in a scheme's
    history -- the median, the quartiles, how often it ended positive, and the
    worst window there has been.

    Direct plans by default, which is the analytical choice as well as the
    honest one: recommending a regular plan while the rest of the page explains
    what commission costs would be incoherent.
    """
    payload = _get("/data/mf/screener", category=category, sort=sort,
                   limit=limit, plan=plan, min_roll3=min_roll3)
    return payload.get("results") or []


def etf_chooser(**params: Any) -> dict:
    """What to hold for a horizon, bucketed by what each bucket is for."""
    return _get("/data/etf/chooser", **params)


def scheme(code: str) -> dict:
    return _get(f"/data/mf/scheme/{code}")


def nav_history(code: str) -> dict:
    return _get(f"/data/mf/nav/history/{code}")


def fund_story(code: str) -> dict:
    """What this fund has actually done, computed and narrated.

    Returns prose fields alongside the figures each sentence rests on. A fund
    with under 260 NAV rows answers "insufficient history" rather than
    degrading into something wrong -- which happens more than you would think,
    because AMFI issues a fresh scheme code on a rename.
    """
    return _get(f"/data/mf/xray/{code}")


def mf_stayed(code: str) -> dict:
    """The stretches somebody had to sit through to earn this fund's returns.

    The other half of the behaviour score. That says how hard a fund is to
    hold; this lists the actual episodes -- what fell, how far, for how long --
    and makes the point that every long-term figure the fund advertises was
    earned by people who did not sell during them.

    Worth showing beside a projection rather than after it. A number somebody
    is told they might reach means something different once they have read what
    reaching it involved.
    """
    return _get(f"/data/mf/stayed/{code}")


def mf_whatif(code: str, **params: Any) -> dict:
    """What a monthly amount into this fund would actually have become.

    Walks the fund's published NAV path rather than compounding an assumed
    rate, so the dips are in it. A projection at a smooth twelve per cent and
    the same fund's real path reach different places, and the difference is the
    part somebody has to live through.
    """
    return _get(f"/data/mf/whatif/{code}", **params)


def mf_portfolio_insights(holdings: list[dict]) -> dict:
    """What a set of funds looks like seen through to the companies underneath.

    Reports how many funds it could resolve and how many have disclosures in
    the pipeline, which matters more than the analysis: a look-through covering
    two funds of eleven is a different claim from one covering all of them, and
    the number is the only way a reader can tell.
    """
    return _post("/data/mf/portfolio-insights", {"holdings": holdings})


def mf_behaviour(code: str) -> dict:
    """What a fund asks of the person holding it.

    Not how it has performed -- how hard it has been to hold. The deepest fall,
    how long recoveries took, how much it swings year to year, and how often a
    one-year stretch ended positive. A fund returning eighteen per cent a year
    through a seventy-eight per cent drawdown has produced that return only for
    the people who did not sell, and this is the figure that says who those
    people had to be.

    Pairs with our own behavioural reading, which measures what somebody has
    actually sustained. A fund that demands discipline in the hands of somebody
    who stopped investing during a fifteen per cent fall is a mismatch neither
    figure shows alone.
    """
    return _get(f"/data/mf/behaviour/{code}")


def mf_tax(holdings: list[dict]) -> dict:
    """Capital gains across a set of holdings, lot by lot.

    Takes lots rather than positions, which is what the law actually works on:
    the units bought in March and the units bought in October are taxed
    differently on the same day, and a calculation that averages them is wrong
    in a way that only shows up when somebody files.

    Replaces our own rate table. Theirs handles the annual exemption and the
    long-term boundary properly, and where two implementations of tax disagree
    the answer is not to keep both.
    """
    return _post("/data/mf/tax", {"holdings": holdings})


def mf_dna_board(sort: str = "quality", limit: int = 10) -> dict:
    """Funds ranked by what they actually own, not by what they returned.

    Ownership-weighted market percentiles: fifty is the market's middle. Only
    funds whose SEBI disclosures we hold and which are at least half NSE
    equity, so the coverage note matters as much as the ranking.
    """
    return _get("/data/mf/dna-board", sort=sort, limit=limit)


def fund_dna(code: str) -> dict:
    """What kind of fund this actually is, rather than what it is called.

    A fund's category is a label its house chose; how it behaves is a fact
    about what it holds and how its NAV has moved. Where the two disagree --
    a flexi cap that behaves like a mid cap fund, a large cap running a third
    of its book in smaller companies -- the behaviour is the thing somebody is
    actually exposed to.
    """
    return _get(f"/data/mf/dna/{code}")


def holdings_xray(code: str) -> dict:
    """What a fund holds, priced, with each company's own ratios.

    Better than the disclosure alone: the top holdings come back with P/E and
    ROE attached, so "what is your fund actually buying" and "at what
    valuation" are one question.
    """
    return _get(f"/data/mf/holdings-xray/{code}")


def activity(code: str, months: int = 6) -> dict:
    """What the manager did between two disclosures.

    The difference between two portfolios rather than a snapshot of one, which
    is the only part that shows a decision. Entries and exits at any size; adds
    and trims only past 0.25 percentage points, because below that it is
    rebalancing rather than intent.

    Answers `computable: false` with a note where a fund has fewer than two
    usable disclosures -- expect that for most AMCs outside ICICI and Nippon.
    """
    return _get(f"/data/mf/activity/{code}", months=max(1, min(months, 24)))


def behaviour(code: str) -> dict:
    """Drawdowns and how long recovery took -- whether you could have held it."""
    return _get(f"/data/mf/behaviour/{code}")


def probability(code: str) -> dict:
    """Base rates from rolling windows, rather than a single trailing figure."""
    return _get(f"/data/mf/probability/{code}")


def horizon(code: str) -> dict:
    """How long you needed to hold before the odds turned."""
    return _get(f"/data/mf/horizon/{code}")


def forward_outlook(code: str) -> dict:
    """Forward valuation of what the fund holds."""
    return _get(f"/data/mf/forward-outlook/{code}")


# ---------------------------------------------------------------------------
# Whole portfolio
# ---------------------------------------------------------------------------


def plan_drag(holdings: list[dict]) -> dict:
    """Regular versus direct, in rupees, per holding.

    Worth comparing against our own commission-drag finding. Where two
    independent calculations disagree, one of them is wrong and it is worth
    knowing which before either is shown to anybody.
    """
    return _post("/api/portfolio/plan-drag", {"holdings": holdings})


def counterfactual(cashflows: list[dict]) -> dict:
    """What the same money would have done in an index fund or a deposit.

    Two guards worth handling rather than hiding: if undated cashflows exceed
    five per cent of the amount invested it suppresses the actual value rather
    than claiming outperformance it cannot date, and if redemptions exceed
    purchases it returns not-computable rather than a meaningless number.
    """
    return _post("/api/portfolio/counterfactual", {"cashflows": cashflows})


def tax(lots: list[dict]) -> dict:
    """Short and long term gains per lot, with the exemption applied."""
    return _post("/data/mf/tax", {"lots": lots})


def plan(payload: dict) -> dict:
    """A route to a goal: what the money projects to, and what closes the gap.

    Returns the projection, three levers for closing a shortfall (raise the
    monthly, extend the horizon, or need a higher return), an allocation by
    horizon, and notes about the things that matter more than fund choice --
    term cover, health insurance, an emergency runway.

    The fund picks are the top three by category rank on rolling three-year
    returns, each carrying why it is there and the worst it has done over any
    three years. That is a rank on a stated measure rather than a score, which
    is what makes it repeatable by anybody with the same data.
    """
    return _post("/data/mf/plan", payload)


def goal_fit(payload: dict) -> dict:
    return _post("/data/mf/goal-fit", payload)


def portfolio_insights(holdings: list[dict]) -> dict:
    return _post("/data/mf/portfolio-insights", {"holdings": holdings})
