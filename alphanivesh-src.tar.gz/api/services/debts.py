"""What somebody owes.

Half a balance sheet is not a balance sheet, and the half we had was the
flattering one. A portfolio worth thirty-four lakh against a home loan of
thirty-four lakh is a different position from the same portfolio held free of
debt, and until now the platform showed both identically.

Three things this changes.

**Net worth becomes net.** What somebody owns less what they owe, which is the
number people mean when they ask what they are worth.

**Risk capacity gets its missing input.** An EMI costs the same amount whatever
the market did that month, and it is the thing most likely to force a sale at a
bad moment. The risk engine has been reporting the absence of this as a hole in
its own calculation.

**And some debt outranks any investment.** A credit card at 42% is a guaranteed
42% cost. No fund promises that, so repaying it is the highest certain return
available and no allocation question is interesting until it is answered. The
decision engine already knows this; it had nothing to apply it to.

**What is not assumed:** that no rows means no debt. Somebody who has entered
nothing and somebody with nothing owed are different, and the second is a
strong position while the first is an unknown. The platform says which.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.debts")

KINDS = {
    "home_loan": "Home loan",
    "car_loan": "Car loan",
    "personal_loan": "Personal loan",
    "education_loan": "Education loan",
    "credit_card": "Credit card",
    "gold_loan": "Gold loan",
    "loan_against_securities": "Loan against securities",
    "business_loan": "Business loan",
    "other": "Other",
}

# Above this a debt costs more than a portfolio can reliably earn, at which
# point repaying it is the best certain return available. Twelve rather than a
# precise figure because the honest comparison is against long-run equity
# returns, and those are a range rather than a number.
EXPENSIVE = Decimal("12")

# What a loan bought. A home loan sits against an appreciating asset; a personal
# loan against a holiday does not, and "total debt" hides the difference.
PRODUCTIVE = ("home_loan", "education_loan", "business_loan")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits


def for_investor(investor_id: str) -> dict:
    """Everything owed, and what it means.

    Returns `recorded: False` where nothing has been entered, which is not the
    same as owing nothing. The distinction matters to the risk engine: no debt
    is a strong position and no information about debt is a gap in the middle of
    a capacity calculation.
    """
    rows = db.fetch_all(
        """
        SELECT id, kind, lender, outstanding, rate_pct, monthly_emi,
               ends_on, secured_against, notes
        FROM liabilities WHERE investor_id = %s
        ORDER BY rate_pct DESC NULLS LAST, outstanding DESC
        """,
        (investor_id,),
    )

    if not rows:
        return {
            "recorded": False,
            "count": 0,
            "total": "0",
            "reading": ("You have not told us what you owe. That is not the "
                        "same as owing nothing — and debt costs a fixed amount "
                        "whatever the market does, which makes it the thing "
                        "most likely to force a sale at a bad moment."),
            "why_it_matters": ("Without it we cannot say what you are actually "
                               "worth, and the risk we suggest is capped at "
                               "moderate regardless of what your portfolio "
                               "could carry."),
        }

    total = sum((_d(r["outstanding"]) for r in rows), Decimal(0))
    emi = sum((_d(r["monthly_emi"]) for r in rows), Decimal(0))

    debts = []
    for row in rows:
        rate = _d(row["rate_pct"])
        outstanding = _d(row["outstanding"])
        expensive = rate >= EXPENSIVE

        debts.append({
            "id": row["id"],
            "kind": row["kind"],
            "label": KINDS.get(row["kind"], row["kind"]),
            "lender": row["lender"],
            "outstanding": str(outstanding),
            "rate_pct": str(rate) if row["rate_pct"] is not None else None,
            "monthly_emi": (str(_d(row["monthly_emi"]))
                            if row["monthly_emi"] is not None else None),
            "ends_on": row["ends_on"].isoformat() if row["ends_on"] else None,
            "secured_against": row["secured_against"],
            "expensive": expensive,
            "productive": row["kind"] in PRODUCTIVE,
            "costs_a_year": (str((outstanding * rate / 100).quantize(Decimal("1")))
                             if rate > 0 else None),
            "reading": _reading_for(row, rate, outstanding, expensive),
        })

    dearest = max((d for d in debts if d["rate_pct"]),
                  key=lambda d: _d(d["rate_pct"]), default=None)
    expensive_total = sum(
        (_d(d["outstanding"]) for d in debts if d["expensive"]), Decimal(0))

    return {
        "recorded": True,
        "count": len(debts),
        "debts": debts,
        "total": str(total.quantize(Decimal("1"))),
        "monthly_emi": str(emi.quantize(Decimal("1"))),
        "expensive_total": str(expensive_total.quantize(Decimal("1"))),
        "dearest": dearest,
        # sum() over an empty generator returns the integer 0, which has no
        # quantize -- so a debt recorded without a rate crashed the whole
        # response. The start value makes it a Decimal whether or not anything
        # is summed.
        "annual_interest": str(sum(
            (_d(d["costs_a_year"]) for d in debts if d["costs_a_year"]),
            Decimal(0),
        ).quantize(Decimal("1"))),
        "reading": _overall(debts, total, emi, expensive_total, dearest),
    }


def _reading_for(row: dict, rate: Decimal, outstanding: Decimal,
                 expensive: bool) -> str:
    label = KINDS.get(row["kind"], row["kind"]).lower()

    if expensive:
        return (f"₹{_money(outstanding)} at {rate:.1f}% is a guaranteed "
                f"{rate:.1f}% cost. No investment offers a guaranteed return at "
                f"that level, so clearing this beats anything you could do with "
                f"the same money in the market.")

    if row["kind"] in PRODUCTIVE:
        return (f"₹{_money(outstanding)} at {rate:.1f}%, against something that "
                f"can grow. Debt like this is not automatically worth clearing "
                f"early — money that earns more than {rate:.1f}% elsewhere is "
                f"doing more good there."
                if rate > 0 else
                f"₹{_money(outstanding)} against something that can grow.")

    return (f"₹{_money(outstanding)} at {rate:.1f}%. Not urgent at that rate, "
            f"and it is a fixed cost the market does not care about."
            if rate > 0 else f"₹{_money(outstanding)} owed.")


def _overall(debts: list[dict], total: Decimal, emi: Decimal,
             expensive_total: Decimal, dearest: Optional[dict]) -> str:
    if expensive_total > 0 and dearest:
        return (f"₹{_money(expensive_total)} of what you owe is at 12% or more — "
                f"the dearest at {_d(dearest['rate_pct']):.1f}%. Clearing that "
                f"is a certain return no fund can promise, and it comes before "
                f"any question about what to invest in.")

    if emi > 0:
        return (f"₹{_money(total)} owed across "
                f"{len(debts)} {'loan' if len(debts) == 1 else 'loans'}, costing "
                f"₹{_money(emi)} a month. None of it is at a rate that makes "
                f"early repayment obviously better than investing — but it is a "
                f"fixed cost whatever the market does.")

    return (f"₹{_money(total)} owed. Nothing at a rate that argues for clearing "
            f"it ahead of investing.")


def net_worth(investor_id: str) -> dict:
    """What is owned, less what is owed.

    The number people mean when they ask what they are worth, and the one the
    platform could not produce until there was somewhere to record debt.
    """
    from . import wealth

    assets = wealth.net_worth(investor_id)
    owed = for_investor(investor_id)

    gross = _d(assets.get("total_value"))
    debt = _d(owed.get("total"))
    net = gross - debt

    return {
        "assets": str(gross.quantize(Decimal("1"))),
        "liabilities": str(debt.quantize(Decimal("1"))),
        "net": str(net.quantize(Decimal("1"))),
        "debt_recorded": owed["recorded"],
        "reading": (
            f"₹{_money(net)} — ₹{_money(gross)} held against ₹{_money(debt)} owed."
            if owed["recorded"] and debt > 0 else
            f"₹{_money(gross)} held, and nothing owed that you have told us about."
            if owed["recorded"] else
            f"₹{_money(gross)} held. We do not know what you owe, so this is "
            f"what you have rather than what you are worth."
        ),
    }


# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------

def add(investor_id: str, kind: str, outstanding: Any,
        rate_pct: Any = None, monthly_emi: Any = None,
        lender: Optional[str] = None, ends_on: Optional[date] = None,
        secured_against: Optional[str] = None,
        notes: Optional[str] = None) -> dict:
    if kind not in KINDS:
        raise ValueError(f"Unknown kind. One of: {', '.join(sorted(KINDS))}")

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO liabilities
                (investor_id, kind, lender, outstanding, rate_pct,
                 monthly_emi, ends_on, secured_against, notes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (investor_id, kind, lender, outstanding, rate_pct,
             monthly_emi, ends_on, secured_against, notes),
        ).fetchone()
    return {"id": row["id"] if row else None}


def update(investor_id: str, liability_id: str, **fields: Any) -> bool:
    allowed = {"kind", "lender", "outstanding", "rate_pct", "monthly_emi",
               "ends_on", "secured_against", "notes"}
    changes = {k: v for k, v in fields.items() if k in allowed and v is not None}
    if not changes:
        return False

    sets = ", ".join(f"{k} = %s" for k in changes)
    params = list(changes.values()) + [liability_id, investor_id]

    with db.connection() as conn:
        conn.execute(
            f"UPDATE liabilities SET {sets}, updated_at = now() "
            f"WHERE id = %s AND investor_id = %s",
            tuple(params))
    return True


def remove(investor_id: str, liability_id: str) -> bool:
    with db.connection() as conn:
        conn.execute(
            "DELETE FROM liabilities WHERE id = %s AND investor_id = %s",
            (liability_id, investor_id))
    return True
