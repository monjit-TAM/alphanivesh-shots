"""What this person should do with their money, and why.

The whole platform arranged into one answer. Every diagnostic that exists —
findings, drift, commission, gaps, behaviour, market — arrives here as a
candidate action, gets a tier and a set of guardrails, and comes out in the
order it is worth doing.

The sequence the design insists on, and the reason for it:

    Investor → Goals → Financial Health → Portfolio Diagnosis →
    Risk → Behaviour → Market Context → Action → Allocation → Product

Read backwards, that is how most tools work: a product ranking exists, and a
justification is assembled around it. Read forwards, the product is the last
question and often not asked at all — plenty of correct answers involve buying
nothing.

What this module contributes is the translation. Every service already produces
a finding; none of them knows whether its finding is a protection, a leak or an
optimisation, and none of them can see the others. Here they are placed against
each other, and several of them lose: a sector concentration is a real problem
and it is not the one to act on when the emergency fund is two months deep.
"""

from __future__ import annotations

import logging
import re
from decimal import Decimal
from typing import Any, Optional

from .. import db
from .hierarchy import Action, Tier, order

log = logging.getLogger("alphanivesh.decide")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits


def picture_for(investor_id: str) -> dict:
    """Assemble what the engine needs, from what this platform holds.

    The only function here that touches our database. Everything below it works
    from the picture alone, which is what lets another product in the group
    call the engine with a picture assembled from theirs.

    A broker has positions and KYC; an RIA has goals from a conversation; this
    platform has statements and a profile form. Same engine, three sources.
    """
    from . import behaviour, profile as profile_service, risk, wealth

    return {
        "investor_id": investor_id,
        "profile": profile_service.get_profile(investor_id) or {},
        "summary": wealth.net_worth(investor_id),
        # Holdings, so every check below works from the picture rather than
        # reaching back into our database. External callers already send these.
        "holdings": wealth.holdings(investor_id),
        "risk": risk.ceiling(investor_id),
        "behaviour": behaviour.profile(investor_id),
        "source": "alphanivesh",
    }


def decide(investor_id: str) -> dict:
    """Everything worth doing, in order, with the reasoning attached.

    The convenience wrapper for this platform. A caller elsewhere in the group
    builds a picture themselves and calls `from_picture`.
    """
    return from_picture(picture_for(investor_id))


def from_picture(picture: dict) -> dict:
    """The engine proper: a complete picture in, an ordered answer out.

    Stateless by design. The same picture always produces the same decision, so
    a disagreement between two products is a difference in what they sent
    rather than a mystery in what happened.
    """
    investor_id = picture.get("investor_id")
    them = picture.get("profile") or {}
    summary = picture.get("summary") or {}
    if not summary.get("positions"):
        return {"empty": True,
                "why": ("There is nothing here to decide about yet. Bring in a "
                        "statement or a spreadsheet first.")}

    limits = picture.get("risk") or {"ceiling": 3, "name": "moderate"}
    how = picture.get("behaviour") or {}

    investor = {
        "emergency_fund_months": them.get("emergency_fund_months"),
        "risk_ceiling": limits["ceiling"],
        "monthly_income": them.get("monthly_income"),
        "monthly_expenses": them.get("monthly_expenses"),
    }

    candidates: list[Action] = []
    candidates += _protect(picture, them, summary)
    candidates += _fix(picture, them, summary)
    candidates += _optimise(picture, them, summary, limits)
    if not picture.get("investor_id"):
        # Our own route gets these through the findings engine, which knows
        # more. A caller sending only holdings gets what holdings alone
        # support, which is more than nothing and is honestly labelled.
        holdings = picture.get("holdings") or []
        candidates += _from_holdings(holdings, limits)
        candidates += _fix_from_holdings(holdings)
    candidates += _invest(picture, them, summary, how)

    sequence = order(candidates, investor)

    from . import wealth

    return {
        "investor": (wealth.get_investor(investor_id) if investor_id else None),
        "risk": limits,
        "health": _health(investor_id, candidates, summary, them),
        **sequence,
        "review_on": _next_review(candidates),
        "data_quality": _data_quality(picture, them, how),
        "principle": (
            "Read top to bottom. Each tier assumes the ones above it are "
            "settled, because they are the ones that make the rest matter: a "
            "portfolio arranged perfectly is worth nothing to somebody forced "
            "to sell it at the wrong moment."
        ),
    }


# ---------------------------------------------------------------------------
# Protect: things that could undo everything else
# ---------------------------------------------------------------------------

def _protect(picture: dict, them: dict, summary: dict) -> list[Action]:
    investor_id = picture.get("investor_id")
    actions: list[Action] = []

    months = them.get("emergency_fund_months")
    expenses = _d(them.get("monthly_expenses"))

    if months is not None and _d(months) < 6 and expenses > 0:
        short = (Decimal(6) - _d(months)) * expenses
        actions.append(Action(
            tier=Tier.PROTECT, code="emergency",
            what=f"Build the emergency fund to six months — about "
                 f"₹{_money(short)} more.",
            why=(f"You have about {months} months of expenses set aside. Until "
                 f"that is closer to six, a job gap or a medical bill is paid "
                 f"by selling investments at whatever price the market happens "
                 f"to be offering — and bad markets and bad personal news "
                 f"arrive together more often than chance would suggest."),
            how="A liquid fund. It earns less than equity and can be reached in "
                "a day, which is the entire point of it.",
            impact="Removes the main reason people sell at the bottom.",
            risk="The money earns less while it sits there. That is the cost of "
                 "not having to sell something else.",
            costs="Nothing beyond the return given up.",
            worth=f"₹{_money(short)} of protection.",
            evidence={"shortfall": str(short), "months_now": str(months),
                      "basis": "cashflow"},
            source="Your profile, and the monthly expenses you entered.",
        ))

    # Cover, where somebody depends on the income.
    dependants = int(them.get("dependents") or 0)
    cover = _d(them.get("life_cover"))
    income = _d(them.get("monthly_income"))

    if dependants > 0 and income > 0:
        annual = income * 12
        needed = annual * 10
        if cover < needed:
            actions.append(Action(
                tier=Tier.PROTECT, code="protection_gap",
                what=(f"Term cover of about ₹{_money(needed)} — you have "
                      f"₹{_money(cover)}." if cover > 0 else
                      f"Term cover of about ₹{_money(needed)}."),
                why=(f"{dependants} "
                     f"{'person depends' if dependants == 1 else 'people depend'} "
                     f"on this income. Ten times annual income is the usual "
                     f"guide, and it is the unglamorous thing that decides "
                     f"whether a plan survives contact with an accident."),
                how="Term insurance, not an endowment or a ULIP. Pure cover is "
                    "cheap; cover bundled with investment is neither good cover "
                    "nor good investment.",
                impact="The plan survives if the income does not.",
                risk="An annual premium, which is a cost rather than a risk.",
                evidence={"cover_gap": str(needed - cover), "basis": "dependants"},
                source="Your profile: income and dependants.",
            ))

    # Expensive debt, which compounds against somebody faster than any
    # portfolio compounds for them.
    # From the picture where the caller supplied one, from our tables where
    # this platform assembled it. An engine that reads only its own database
    # cannot be shared, and one that silently ignores what a caller sent is
    # worse than one that refuses to run.
    debts = _liabilities_from(picture, investor_id)

    for debt in debts[:2]:
        rate = _d(debt["rate_pct"])
        actions.append(Action(
            tier=Tier.PROTECT, code="expensive_debt",
            what=f"Clear the {debt['kind'].replace('_', ' ')} at {rate:.1f}% "
                 f"before investing more.",
            why=(f"₹{_money(debt['outstanding'])} at {rate:.1f}% is a guaranteed "
                 f"{rate:.1f}% cost. No investment offers a guaranteed return at "
                 f"that level, so paying it off is the highest certain return "
                 f"available to you."),
            how="Every spare rupee at the highest rate first, then the next.",
            impact=f"A certain {rate:.1f}% return, which no fund can promise.",
            risk="Money used to repay is money not invested, and the market may "
                 "rise while you do it. The certainty is the point.",
            evidence={"annual_saving": str(_d(debt["outstanding"]) * rate / 100),
                      "basis": "interest_rate"},
            source="Your recorded liabilities.",
        ))

    return actions


# ---------------------------------------------------------------------------
# Fix: money leaking, or risk nobody chose
# ---------------------------------------------------------------------------


def _liabilities_from(picture: dict, investor_id: Optional[str]) -> list[dict]:
    """Expensive debt, from wherever this picture came from.

    Above 12% is the threshold, because that is roughly where a debt costs more
    than a portfolio can reliably earn -- at which point repaying it is the
    highest certain return available and no allocation question is interesting
    until it is answered.
    """
    supplied = picture.get("liabilities")
    if supplied:
        debts = [d for d in supplied
                 if _d(d.get("rate_pct")) >= 12 and _d(d.get("outstanding")) > 0]
        return sorted(debts, key=lambda d: -_d(d.get("rate_pct")))

    if not investor_id or not _has_table("liabilities"):
        return []

    return db.fetch_all(
        """
        SELECT kind, outstanding, rate_pct, monthly_emi FROM liabilities
        WHERE investor_id = %s AND rate_pct IS NOT NULL AND rate_pct >= 12
        ORDER BY rate_pct DESC
        """,
        (investor_id,),
    )


def _fix(picture: dict, them: dict, summary: dict) -> list[Action]:
    """Money leaking, or risk nobody chose.

    Commission detection needs the holdings matched to the scheme master, which
    this platform does at import. A caller sending raw holdings gets nothing
    here -- and that absence is reported in data_quality rather than passing as
    "nothing is leaking".
    """
    from . import plans

    investor_id = picture.get("investor_id")
    actions: list[Action] = []
    if not investor_id:
        return actions

    try:
        redirect = plans.redirect_future(investor_id)
    except Exception:
        redirect = None

    if redirect:
        actions.append(Action(
            tier=Tier.FIX, code="redirect_sip",
            what="Point your next instalment at the direct plan.",
            why=redirect["reading"],
            how="Stop the existing SIP and start one in the direct plan of the "
                "same fund. Ten minutes with the AMC or your broker.",
            impact=f"About ₹{_money(redirect['saves_first_year'])} in the first "
                   f"year, more every year after as the balance grows.",
            risk="None. A new purchase is not a sale, so nothing is realised and "
                 "no holding period restarts.",
            costs="Nothing.",
            worth=f"₹{_money(redirect['saves_first_year'])} a year and rising.",
            evidence={"annual_saving": redirect["saves_first_year"],
                      "basis": "cost_structure"},
            source="Your transaction record and the AMFI scheme master.",
        ))

    # The exemption that expires every March. Placed in FIX rather than
    # OPTIMISE because it is money leaking: an allowance nobody uses is worth
    # nothing, and it does not carry forward.
    try:
        from . import harvest
        chance = harvest.opportunity(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("harvest check failed for %s: %s", investor_id, err)
        chance = None

    if chance and chance.get("worth_doing"):
        first = (chance.get("plan") or [{}])[0]
        actions.append(Action(
            tier=Tier.FIX, code="harvest_exemption",
            what=f"Realise ₹{_money(chance['available_gain'])} of long-term gain "
                 f"before March and pay nothing on it.",
            why=chance["reading"] + " " + (
                f"The allowance is annual and does not carry forward — "
                f"unused, it is simply gone on the 1st of April."),
            how=(f"Sell about ₹{_money(first.get('sell_value'))} of "
                 f"{first.get('name', 'the holding')} and buy the same thing "
                 f"back. Nothing about what you own changes; the cost base "
                 f"resets higher and that much gain stops being taxable later."
                 if first else None),
            impact=f"About ₹{_money(chance['saving'])} this year, and the same "
                   f"again every year you do it.",
            risk=chance["costs"] + " " + (first.get("exit_load_risk") or ""),
            costs="Brokerage twice, and a day or two out of the market.",
            worth=f"₹{_money(chance['saving'])}",
            evidence={"annual_saving": chance["saving"],
                      "months_left": chance["months_left"],
                      "basis": "tax_allowance"},
            source="Your holdings and their purchase dates, against the "
                   "₹1.25 lakh annual long-term exemption.",
            confidence="firm",
            confidence_why=chance["caveat"],
        ))

    # And the other half: losses that could offset gains already made.
    try:
        from . import harvest as _h
        underwater = _h.losses(investor_id)
    except Exception:
        underwater = None

    if underwater:
        actions.append(Action(
            tier=Tier.FIX, code="harvest_losses",
            what=f"₹{_money(underwater['offsettable'])} of loss could offset "
                 f"gains you have already made.",
            why=underwater["reading"],
            how="Sell the holding, set the loss against a gain realised the "
                "same year, and buy back if you still want it.",
            impact=f"About ₹{_money(underwater['saving'])} less tax.",
            risk=underwater["caveat"],
            worth=f"₹{_money(underwater['saving'])}",
            evidence={"annual_saving": underwater["saving"],
                      "basis": "tax_allowance"},
            source="Your holdings, valued today against what you paid.",
        ))

    # Where the commission and the ranking are about the same funds, that is
    # one finding rather than two -- and a stronger one than either alone.
    try:
        from . import peers as peers_service
        both = peers_service.commission_meets_quartile(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("commission/quartile check failed for %s: %s",
                    investor_id, err)
        both = None

    if both and both.get("found"):
        worst = both["funds"][0]
        actions.append(Action(
            tier=Tier.FIX, code="paying_for_laggards",
            what=(f"You are paying commission on {both['count']} "
                  f"fund{'s' if both['count'] != 1 else ''} that "
                  f"{'is' if both['count'] == 1 else 'are'} also lagging their "
                  f"peers."),
            why=both["reading"] + " " + both["why_it_matters"],
            how=("Switching to the direct plan removes the commission and "
                 "keeps the fund. Whether to keep the fund at all is the "
                 "separate question, and worth answering before switching "
                 "rather than after."),
            impact=f"₹{_money(both['commission_a_year'])} a year, and it "
                   f"separates the cost question from the fund question.",
            risk=both["not_a_claim"],
            evidence={"annual_saving": both["commission_a_year"],
                      "at_risk": both["money"],
                      "basis": "cost_and_ranking"},
            source="Your holdings, matched to the AMFI master and to each "
                   "fund's standing among its category.",
        ))

    try:
        commission = plans.summary(investor_id)
    except Exception:
        commission = None

    if commission:
        free = [f for f in commission["funds"] if _d(f["tax_to_switch"]) <= 0]
        for fund in free[:2]:
            actions.append(Action(
                tier=Tier.FIX, code="switch_free",
                what=f"Switch {fund['name'][:44]} to its direct plan.",
                why=fund["reading"],
                how="A switch request with the AMC, settling in a day or two.",
                impact=f"₹{_money(fund['saving_a_year'])} a year.",
                risk="None here — this holding is not in profit, so switching "
                     "realises nothing.",
                costs="Nothing.",
                worth=f"₹{_money(fund['saving_a_year'])} a year.",
                evidence={"annual_saving": fund["saving_a_year"],
                          "basis": "cost_structure"},
                source="Your holdings, matched to the AMFI scheme master.",
            ))

    return actions


# ---------------------------------------------------------------------------
# Optimise: the holdings are sound, the arrangement is not
# ---------------------------------------------------------------------------

def _optimise(picture: dict, them: dict, summary: dict,
              limits: dict) -> list[Action]:
    from . import findings as findings_service, profile as profile_service

    investor_id = picture.get("investor_id")
    actions: list[Action] = []
    if not investor_id:
        return actions

    found = findings_service.for_investor(investor_id)
    for finding in (found.get("worth_doing_now") or [])[:3]:
        code = finding.get("code") or ""
        if code in ("regular_plans", "commission_drag", "emergency_shortfall",
                    "protection_gap"):
            continue        # already placed in a tier above this one

        evidence = dict(finding.get("evidence") or {})
        evidence.setdefault("basis", "portfolio_structure")

        actions.append(Action(
            tier=Tier.OPTIMISE, code=code,
            what=f"{finding.get('action_verb', 'Look at')}: {finding['headline']}",
            why=finding["detail"],
            how=finding.get("why_this_order"),
            impact=_impact_of(finding),
            risk="Acting means selling, which has a tax cost and puts money "
                 "briefly out of the market.",
            evidence=evidence,
            source="Computed from your holdings, priced today.",
            confidence=finding.get("certainty", "firm"),
        ))

    drift = profile_service.drift(investor_id)
    if drift and not drift.get("in_line"):
        # The widest gap among classes there was actually a plan for.
        #
        # lines[0] picked whichever class happened to be first, which on a real
        # portfolio was gold -- a holding with no target at all -- and produced
        # "gold is 37.1% against the None% you set". Third place this same
        # mistake appeared; the other two were in the findings and the guide.
        planned = [line for line in drift["lines"]
                   if not line.get("never_planned") and line.get("target_pct")]
        worst = max(planned,
                    key=lambda line: abs(_d(line.get("gap_pct"))),
                    default=None)

    if drift and not drift.get("in_line") and worst:
        actions.append(Action(
            tier=Tier.OPTIMISE, code="rebalance",
            what="Bring the mix back towards what you chose.",
            why=(f"You are {drift['worst_gap_pct']} points from your target. "
                 f"{worst['asset_class'].replace('_', ' ').title()} is "
                 f"{worst['actual_pct']}% against the {worst['target_pct']}% you "
                 f"set. Markets do the drifting; what you hold now is not what "
                 f"you decided to hold."),
            how=f"Moving about ₹{_money(abs(_d(worst['to_move'])))} between "
                f"classes, which means selling.",
            impact="The portfolio matches the intention again.",
            risk="Capital gains tax on whatever is sold.",
            evidence={"at_risk": str(abs(_d(worst["to_move"]))),
                      "basis": "stated_target"},
            source="Your target allocation, against today's prices.",
        ))

    return actions


# ---------------------------------------------------------------------------
# Invest: what to do with money not yet working
# ---------------------------------------------------------------------------

def _invest(picture: dict, them: dict, summary: dict,
            how: dict) -> list[Action]:
    actions: list[Action] = []

    # What is not equity.
    #
    # Every suggestion this engine made ended in a share or an equity fund,
    # which produced a specific incoherence: the risk cards say somebody holds
    # nothing that rises when equities fall, and the next card recommends more
    # equity.
    #
    # Not an allocation model. There is no rule here saying twenty per cent
    # gold -- there is a check for whether anything at all fills a role, and a
    # suggestion where nothing does. "You have nothing you could reach in an
    # emergency" is an observation; "you should hold 20% debt" is a view.
    holdings = picture.get("holdings")
    if holdings:
        try:
            from . import beyond
            for gap in beyond.actions_for(None, them or {}, summary or {},
                                          holdings=holdings):
                actions.append(Action(
                    tier=Tier.INVEST, code=gap["code"],
                    what=gap["what"], why=gap["why"], how=gap["how"],
                    impact=gap["impact"],
                    evidence=gap["evidence"],
                    source="Your holdings, grouped by what each one is for.",
                    confidence="firm",
                    confidence_why=(
                        "Whether something fills a role is observable. How much "
                        "of it to hold is a judgement about you, and this does "
                        "not make one."),
                ))
        except Exception as err:                                 # pragma: no cover
            log.warning("role gaps failed: %s", err)

    income = _d(them.get("monthly_income"))
    expenses = _d(them.get("monthly_expenses"))
    style = ((how or {}).get("style") or {}).get("style")

    if income > 0 and expenses > 0:
        spare = income - expenses
        investing = _d(((how or {}).get("style") or {}).get("median_month"))
        unused = spare - investing
        if unused > Decimal("5000"):
            actions.append(Action(
                tier=Tier.INVEST, code="increase_sip",
                what=f"About ₹{_money(unused)} a month is not going anywhere.",
                why=(f"Your income less your expenses leaves about "
                     f"₹{_money(spare)} a month, and about ₹{_money(investing)} "
                     f"of it is being invested. Money without a job tends to get "
                     f"spent, and a standing instruction is the difference "
                     f"between intending to invest it and investing it."),
                how="Raise the existing instalment, or start a second one.",
                impact="Compounds for as long as it runs.",
                risk="Committing more each month leaves less room if the income "
                     "changes. Worth setting at a level that survives a bad "
                     "quarter rather than the best one.",
                evidence={"annual_saving": str(unused * 12), "basis": "cashflow"},
                source="Your profile, against your transaction record.",
            ))

    if style in ("occasional", "sporadic"):
        actions.append(Action(
            tier=Tier.INVEST, code="automate",
            what="Set up a standing instruction.",
            why=("Your money goes in when you decide to put it in, which makes "
                 "every month a decision — and the months hardest to decide in "
                 "are the ones where units are cheapest."),
            how="A monthly SIP into what you already hold. The amount matters "
                "less than the fact that it happens without you.",
            impact="Removes the timing decision, which is the one most people "
                   "get wrong.",
            risk="None, beyond committing an amount each month.",
            evidence={"basis": "behaviour"},
            source="Your transaction record.",
        ))

    return actions


# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Diagnostics that need only the holdings themselves
# ---------------------------------------------------------------------------

# Above this share, one holding decides the result.
HEAVY_SINGLE = Decimal("20")
HEAVY_TOP_FIVE = Decimal("70")
HEAVY_CLASS = Decimal("85")



# What a fund holds, from its name. Not perfect and better than treating every
# mutual fund as equity, which is what grouping by `kind` alone does -- it
# called a corporate bond fund a market-correlated holding and reported "100%
# moves with the market" on a portfolio with sixteen per cent in debt.
_DEBT_WORDS = re.compile(
    r"\b(bond|debt|gilt|g-?sec|liquid|overnight|money market|treasury|"
    r"corporate bond|banking and psu|credit risk|duration|income fund|"
    r"savings fund|ultra short|low duration|short term|medium term)\b", re.I)
_GOLD_WORDS = re.compile(r"\bgold|silver\b", re.I)
_HYBRID_WORDS = re.compile(r"\b(hybrid|balanced|asset allocat|multi asset|"
                           r"equity savings|arbitrage)\b", re.I)


def _moves_with_market(holding: dict) -> bool:
    """Whether this holding falls when equities fall.

    The question the allocation warning is actually asking. A corporate bond
    fund and a mid cap fund are both `mutual_fund` and only one of them is
    what somebody means by "everything moves together".
    """
    kind = (holding.get("kind") or "").lower()
    if kind in ("bond", "gsec", "fixed_deposit", "cash", "gold"):
        return False
    if kind not in ("mutual_fund", "etf", "equity"):
        return False

    name = (holding.get("name") or holding.get("scheme_name") or "")
    category = holding.get("category") or ""
    text = f"{name} {category}"

    if _GOLD_WORDS.search(text):
        return False
    if _DEBT_WORDS.search(text):
        return False
    if _HYBRID_WORDS.search(text):
        return False        # partly, and "partly" is not what this warns about
    return True


def _from_holdings(holdings: list[dict], limits: dict) -> list[Action]:
    """What can be said from a holdings list and nothing else.

    Concentration and allocation need no database, no scheme master and no
    price history -- only the values a caller has already sent. Refusing to
    report them to an external caller was a limitation of the implementation
    rather than of the information, and the kind of gap that makes a shared
    service not worth sharing.
    """
    if not holdings:
        return []

    total = sum(_d(h.get("current_value")) for h in holdings)
    if total <= 0:
        return []

    actions: list[Action] = []

    # One holding carrying the result.
    ranked = sorted(holdings, key=lambda h: -_d(h.get("current_value")))
    top = ranked[0]
    top_share = _d(top.get("current_value")) / total * 100

    if top_share >= HEAVY_SINGLE:
        name = (top.get("name") or top.get("symbol") or top.get("scheme_code")
                or "one holding")
        actions.append(Action(
            tier=Tier.OPTIMISE, code="concentration_single",
            what=f"{top_share:.0f}% of this portfolio is in {name}.",
            why=(f"₹{_money(top.get('current_value'))} of ₹{_money(total)} rests "
                 f"on one holding. However good it is, a position that size "
                 f"means the overall result is mostly a bet on it — and the "
                 f"other holdings are close to decoration."),
            how="Trimming it into something that does not move with it.",
            impact=f"Reduces a position carrying {top_share:.0f}% of everything.",
            risk="Selling has a tax cost, and a concentrated position that has "
                 "done well is often concentrated because it did well.",
            evidence={"at_risk": str(_d(top.get("current_value"))),
                      "share_pct": f"{top_share:.1f}",
                      "basis": "portfolio_structure"},
            source="The holdings you sent, valued as supplied.",
        ))

    # The top five carrying it between them.
    if len(ranked) >= 5:
        five = sum(_d(h.get("current_value")) for h in ranked[:5])
        five_share = five / total * 100
        if five_share >= HEAVY_TOP_FIVE and top_share < HEAVY_SINGLE:
            actions.append(Action(
                tier=Tier.OPTIMISE, code="concentration_top5",
                what=f"Five holdings are {five_share:.0f}% of the portfolio.",
                why=(f"₹{_money(five)} of ₹{_money(total)} sits in five of "
                     f"{len(holdings)} holdings. The rest are small enough to "
                     f"have little effect either way, which means the work of "
                     f"following them is not buying much."),
                how="Either concentrate deliberately, or make the small holdings "
                    "large enough to matter.",
                impact="Fewer things to follow, or more of them counting.",
                risk="Consolidating means selling, which has a tax cost.",
                evidence={"at_risk": str(five), "basis": "portfolio_structure"},
                source="The holdings you sent.",
            ))

    # Everything in one kind of thing.
    # Grouped by what a holding does rather than what it is called.
    correlated = sum(_d(h.get("current_value")) for h in holdings
                     if _moves_with_market(h))
    class_share = correlated / total * 100

    if class_share >= HEAVY_CLASS:
        actions.append(Action(
            tier=Tier.OPTIMISE, code="single_asset_class",
            what=f"{class_share:.0f}% of this is in things that move with the "
                 f"market.",
            why=("In a bad year everything here falls together, and there is "
                 "nothing that does not. Something steady is what lets the rest "
                 "be left alone rather than sold — and what somebody sells in a "
                 "fall is the part that would have recovered."),
            how="Debt funds or deposits for the part you might need within "
                "three years.",
            impact="Gives you something to draw on that has not fallen.",
            risk="The steady part earns less. That is what it is for.",
            # No risk_level here. The field means "the risk this action would
            # introduce", and this one suggests adding debt funds -- it lowers
            # risk. Tagging it 4 to describe the situation made the suitability
            # guardrail withhold the action that fixes the situation, which is
            # the guardrail working correctly on a wrong input.
            evidence={"at_risk": str(correlated),
                      "basis": "portfolio_structure"},
            source="The holdings you sent, grouped by kind.",
        ))

    return actions



def _fix_from_holdings(holdings: list[dict]) -> list[Action]:
    """Money leaking, from a caller's holdings alone.

    Commission on a regular plan is detectable from the scheme name and the
    AMFI master, both of which we have -- so a caller sending holdings can have
    this even though we know nothing else about them. What we cannot compute
    without their transaction history is the tax of switching, and that absence
    is stated rather than assumed away: telling somebody to switch without
    saying what it costs is advice that can lose them money.
    """
    from . import plans

    actions: list[Action] = []
    if not holdings:
        return actions

    total = sum(_d(h.get("current_value")) for h in holdings)
    regular = []

    for holding in holdings:
        if (holding.get("kind") or "") != "mutual_fund":
            continue
        name = holding.get("name") or holding.get("scheme_name") or ""
        if not name or plans._plan_of(name) != "regular":
            continue

        value = _d(holding.get("current_value"))
        if value <= 0:
            continue

        try:
            twin = plans.find_direct_twin(name, holding.get("category"))
        except Exception:
            twin = None
        if not twin:
            continue

        trail = plans._trail_for(holding.get("category"))
        saving = value * trail / 100
        if saving < Decimal("2000"):
            continue
        regular.append({"name": name, "value": value, "saving": saving,
                        "direct": twin.get("name")})

    if not regular:
        return actions

    annual = sum(r["saving"] for r in regular)
    over_twenty = annual * 20

    actions.append(Action(
        tier=Tier.FIX, code="regular_plans",
        what=f"₹{_money(annual)} a year goes to commission on "
             f"{len(regular)} fund{'s' if len(regular) != 1 else ''}.",
        why=(f"A regular plan and a direct plan are the same fund, run by the "
             f"same manager, holding the same companies. The difference is a "
             f"trail commission taken out of the NAV every year, forever, for a "
             f"sale that happened once. Over twenty years at this holding that "
             f"is about ₹{_money(over_twenty)}."),
        how="A switch request with the AMC, or — if you are still contributing "
            "— point the next instalment at the direct plan, which costs "
            "nothing at all because a purchase is not a sale.",
        impact=f"₹{_money(annual)} a year, rising as the balance grows.",
        risk="Switching what you already hold realises a capital gain. We "
             "cannot see what you paid or when, so we cannot tell you what "
             "that would cost — and on a holding with a large gain it can "
             "exceed several years of the commission it saves.",
        evidence={"annual_saving": str(annual),
                  "over_twenty_years": str(over_twenty),
                  "funds": [r["name"] for r in regular[:5]],
                  "basis": "cost_structure"},
        source="The scheme names you sent, matched to the AMFI master.",
        confidence="firm",
        confidence_why=("The commission is estimated from typical trail rates "
                        "by category rather than each scheme's own disclosure, "
                        "so treat the rupee figures as close rather than exact."),
    ))
    return actions


def _impact_of(finding: dict) -> Optional[str]:
    evidence = finding.get("evidence") or {}
    if evidence.get("would_lose"):
        return (f"Removes ₹{_money(evidence['would_lose'])} of exposure to a "
                f"fall that has already happened once.")
    if evidence.get("share_pct"):
        return f"Reduces a position carrying {evidence['share_pct']}% of everything."
    return None


def _health(investor_id: str, candidates: list[Action], summary: dict,
            them: dict) -> dict:
    """A reading rather than a score.

    Deliberately not a number out of a hundred. A composite needs weights
    nobody can derive and hides which measure is driving it, and the reader
    cannot decompose one they were handed. What they can act on is a count:
    three things working, two needing attention, one urgent — each of which
    opens into the thing itself.
    """
    from . import findings as findings_service

    found = findings_service.for_investor(investor_id)
    urgent = [a for a in candidates if a.tier == Tier.PROTECT]
    leaking = [a for a in candidates if a.tier == Tier.FIX]
    shape = [a for a in candidates if a.tier == Tier.OPTIMISE]

    working = []
    if summary.get("absolute_return_pct") and _d(summary["absolute_return_pct"]) > 0:
        working.append("The portfolio is ahead of what went into it.")
    if not urgent:
        working.append("Nothing here is urgent.")
    if not leaking:
        working.append("Nothing is leaking money for no return.")

    return {
        "urgent": len(urgent),
        "leaking": len(leaking),
        "shape": len(shape),
        "working": working,
        "reading": _health_reading(len(urgent), len(leaking), len(shape), working),
        "why_not_a_score": (
            "There is no health score here on purpose. A single number needs "
            "weights nobody can derive, hides which measure is driving it, and "
            "cannot be taken apart by the person reading it. A count can: every "
            "figure below opens into the thing it counts."
        ),
    }


def _health_reading(urgent: int, leaking: int, shape: int,
                    working: list[str]) -> str:
    if urgent:
        return (f"{urgent} thing{'s' if urgent != 1 else ''} here "
                f"{'need' if urgent != 1 else 'needs'} attention before anything "
                f"else about this portfolio matters.")
    if leaking:
        return (f"Nothing urgent. {leaking} thing{'s' if leaking != 1 else ''} "
                f"{'are' if leaking != 1 else 'is'} costing money for no return, "
                f"which is the next thing worth an hour.")
    if shape:
        return (f"Nothing urgent and nothing leaking. "
                f"{shape} thing{'s' if shape != 1 else ''} about the shape "
                f"worth looking at when you have time.")
    return ("Nothing needs doing. That is a finding rather than an absence of "
            "one, and it is rarer than it sounds.")


def _next_review(candidates: list[Action]) -> dict:
    """When to look again, and what would bring that forward."""
    urgent = any(a.tier == Tier.PROTECT for a in candidates)
    return {
        "months": 3 if urgent else 6,
        "why": ("Sooner than usual, because something here needs settling."
                if urgent else
                "Twice a year is enough for a portfolio in reasonable order. "
                "Looking more often mostly produces trading."),
        "sooner_if": [
            "Your income or expenses change materially",
            "You take on or clear a debt",
            "A goal moves, or a new one appears",
            "You add or sell a large holding",
            "The market falls far enough that you think about selling",
        ],
    }


def _data_quality(picture: dict, them: dict, how: dict) -> dict:
    """How much of this rests on things we actually know.

    Confidence in a recommendation is mostly confidence in its inputs, and a
    system that reports the first without the second is asking to be trusted
    on the strength of its tone.
    """
    investor_id = picture.get("investor_id")
    have = []
    missing = []

    checks = [
        ("what you earn", bool(them.get("monthly_income"))),
        ("what you spend", bool(them.get("monthly_expenses"))),
        ("your age", bool(them.get("date_of_birth"))),
        ("your dependants", them.get("dependents") is not None),
        ("your emergency fund", them.get("emergency_fund_months") is not None),
        ("what you owe", bool(picture.get("liabilities"))
                          or _has_rows("liabilities", investor_id)),
        ("your goals", bool(picture.get("goals"))
                        or _has_rows("goals", investor_id)),
        ("your target mix", bool(picture.get("target_allocation"))
                             or _has_rows("target_allocations", investor_id)),
        ("how you actually invest",
         bool(((how or {}).get("style") or {}).get("readable"))),
    ]
    for label, known in checks:
        (have if known else missing).append(label)

    share = len(have) / len(checks) * 100

    return {
        "known": have,
        "missing": missing,
        "completeness_pct": round(share),
        "confidence": ("firm" if share >= 80 else
                       "reasonable" if share >= 55 else "thin"),
        "reading": (
            f"This rests on {len(have)} of {len(checks)} things worth knowing "
            f"about you."
            + (f" We do not know {', '.join(missing[:3])}"
               + (f" and {len(missing) - 3} other things." if len(missing) > 3
                  else ".")
               if missing else " Nothing material is missing.")
        ),
    }


def _has_table(name: str) -> bool:
    return bool(db.fetch_one(
        "SELECT 1 AS ok FROM information_schema.tables "
        "WHERE table_schema = 'public' AND table_name = %s", (name,)))


def _has_rows(table: str, investor_id: str) -> bool:
    if not _has_table(table):
        return False
    return bool(db.fetch_one(
        f"SELECT 1 AS ok FROM {table} WHERE investor_id = %s LIMIT 1",
        (investor_id,)))
