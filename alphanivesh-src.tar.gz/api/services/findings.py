"""What is worth telling someone about their own portfolio.

Every finding here is computed from the investor's actual holdings. Nothing is
generated, inferred by a model, or padded to make the list look busy: a
portfolio with nothing wrong returns nothing, and saying so is a legitimate
answer.

Three rules the whole module follows.

Evidence, not adjectives. A finding carries the numbers that produced it, so
the reader can check the reasoning rather than take it on faith. "22.4% of your
wealth sits in one fund" is useful; "you are over-concentrated" is not.

Thresholds are explicit. Every number that decides whether a finding fires is a
named constant below, with a note on where it comes from. Someone auditing this
should be able to see exactly why their portfolio did or did not trigger
something.

Estimates say so. Where we do not hold the underlying data -- expense ratios
being the current example -- the finding states that the figure is an estimate
and what it was derived from. A confident rupee number resting on an
unmentioned assumption is worse than no number.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from functools import lru_cache
import logging
from decimal import Decimal
from typing import Optional

from .. import db
from . import i18n

log = logging.getLogger("alphanivesh.findings")

# ---------------------------------------------------------------------------
# Thresholds
#
# These are judgement calls, set where a reasonable adviser would start paying
# attention rather than at the point of alarm. They are deliberately in one
# place so they can be argued with.
# ---------------------------------------------------------------------------

SINGLE_HOLDING_WATCH = Decimal("15")     # % of net worth in one holding
SINGLE_HOLDING_HIGH = Decimal("25")
TOP_FIVE_WATCH = Decimal("60")           # % of net worth in the five largest
SINGLE_ISSUER_WATCH = Decimal("40")      # % with one fund house or issuer

IDLE_DAYS = 120                          # liquid money untouched this long
IDLE_MIN_VALUE = Decimal("50000")        # below this it is a float, not a problem

DRAG_MIN_ANNUAL = Decimal("2000")        # do not raise it for trivial amounts

# Structural thresholds. Chosen where a reasonable adviser starts paying
# attention rather than where they would sound an alarm, and gathered here so
# they can be argued with rather than hunted for.
SMALL_CAP_WATCH = Decimal("30")     # % of equity in small caps
SMALL_CAP_HIGH = Decimal("40")
EQUITY_NO_CUSHION = Decimal("90")   # % in equity with nothing stable behind it
TOO_CONSERVATIVE = Decimal("80")    # % in debt and cash
TOO_MANY_FUNDS = 15                 # holdings past which nobody tracks them
MIN_PORTFOLIO_FOR_STRUCTURE = Decimal("50000")  # below this, none of it matters

# Rate used when projecting what a recurring cost adds up to. Money not paid in
# commission would itself have been invested, so a flat multiplication would
# understate the loss. 11% is a long-run Indian equity assumption -- deliberately
# below the trailing average, because a projection that flatters itself is worth
# less than one nobody can dispute.
PROJECTION_RATE = Decimal("0.11")
PROJECTION_YEARS = (5, 10, 20)


def _compounded_cost(annual: Decimal, years: int, rate: Decimal = PROJECTION_RATE) -> Decimal:
    """What an annual cost becomes when the unpaid amount would have compounded.

    The future value of an ordinary annuity: each year's saving is invested and
    grows for the remaining term.
    """
    r = float(rate)
    n = int(years)
    factor = ((1 + r) ** n - 1) / r
    return (annual * Decimal(str(factor))).quantize(Decimal("1"))

# Difference between a regular plan and its direct equivalent, by category.
# These are typical published spreads for Indian mutual funds; they are not
# scheme-specific, which is why anything derived from them is presented as an
# estimate. Replace with real expense ratios once the scheme master carries
# them and this becomes an exact figure.
COMMISSION_SPREAD = {
    "equity": Decimal("1.00"),
    "sectoral/thematic": Decimal("1.00"),
    "hybrid": Decimal("0.75"),
    "debt": Decimal("0.50"),
    "liquid": Decimal("0.20"),
    "other": Decimal("0.75"),
}
DEFAULT_SPREAD = Decimal("0.75")


@dataclass
class Finding:
    """One observation about a portfolio.

    `severity` is 'watch' or 'act'. There is deliberately no 'critical': this
    is a research tool, and an alarming label on a computed threshold would be
    overclaiming.
    """
    code: str
    severity: str
    headline: str
    detail: str
    evidence: dict
    estimated: bool = False

    def as_dict(self) -> dict:
        return asdict(self)


def _d(v) -> Decimal:
    return Decimal(str(v)) if v is not None else Decimal(0)


def _money(v: Decimal) -> str:
    """Indian grouping, no decimals. 5760849 -> '57,60,849'."""
    n = int(round(float(v)))
    s = str(abs(n))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        head = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", head)
        s = head + "," + tail
    return ("-" if n < 0 else "") + s


# ---------------------------------------------------------------------------
# Plan detection
# ---------------------------------------------------------------------------

_DIRECT = re.compile(r"\bdirect\b", re.I)
_REGULAR = re.compile(r"\bregular\b", re.I)


def plan_type(scheme_name: str) -> str:
    """'direct', 'regular', or 'unknown'.

    A third of the scheme names in our data say neither -- "K123-Kotak Midcap
    Fund-Growth" gives no clue. Those stay unknown and are left out of any
    calculation rather than being assumed one way or the other, because
    assuming 'regular' would inflate the drag figure and assuming 'direct'
    would hide it.
    """
    name = scheme_name or ""
    if _DIRECT.search(name):
        return "direct"
    if _REGULAR.search(name):
        return "regular"
    return "unknown"


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------



# What to call a holding in a sentence. The concentration finding said "a
# single fund" whatever the holding was, which read as a mistake the moment
# somebody held shares -- and a reader who catches one wrong word starts
# doubting the numbers beside it.
_SINGULAR = {
    "equity": "one company",
    "mutual_fund": "a single fund",
    "etf": "a single ETF",
    "bond": "one bond",
    "gsec": "one government security",
    "gold": "gold",
    "fixed_deposit": "one deposit",
    "insurance": "one policy",
    "real_estate": "one property",
    "unlisted": "one unlisted holding",
    "cash": "cash",
}



def _sector_name(sector: Optional[str]) -> str:
    """An industry's name in the reader's language.

    Sectors arrive from the database as English strings and there are about
    twenty of them, so they are a catalogue rather than a translation problem.
    Falls back to the English lowercased, which is what the sentence used
    before any of this existed.
    """
    if not sector:
        return ""
    key = "sector." + sector.lower().replace(" ", "_").replace("&", "and")
    name = i18n.say(key)
    return name if name != key else sector.lower()


def _a_single(asset_class: Optional[str]) -> str:
    """"one company", "a single fund" -- the phrase, in the reader's language.

    A sentence is only as translated as its least translated part. Getting the
    template right and leaving the noun in English produces something worse
    than either: a reader who can tell the machine tried and did not finish.
    """
    key = f"single.{asset_class}" if asset_class else "single.other"
    phrase = i18n.say(key)
    if phrase != key:
        return phrase
    return _SINGULAR.get(asset_class or "", i18n.say("single.other"))


def _concentration(holdings: list[dict], total: Decimal) -> list[Finding]:
    if not holdings or total <= 0:
        return []

    # Only positions that still hold something. A statement lists folios the
    # investor exited years ago, and counting those would say "five holdings out
    # of 31" about a portfolio with 20 live ones.
    #
    # And only positions somebody could actually change. A provident fund at
    # forty-seven per cent was reported as "your portfolio is concentrated in
    # one holding" with a suggestion to decide about it -- but nobody decides
    # about their EPF balance, and the finding read as though they should.
    # The concentration is real and it is not a decision.
    from .rebalance import investable
    live = [h for h in holdings
            if _d(h.get("current_value")) > 0 and investable(h)]
    if not live:
        return []

    out: list[Finding] = []
    ranked = sorted(live, key=lambda h: _d(h["current_value"]), reverse=True)

    top = ranked[0]
    top_share = _d(top["current_value"]) / total * 100
    if top_share >= SINGLE_HOLDING_WATCH:
        severe = top_share >= SINGLE_HOLDING_HIGH
        out.append(Finding(
            code="concentration_single",
            severity="act" if severe else "watch",
            headline=i18n.say("find.concentration_single.head",
                              share=f"{top_share:.1f}",
                              what=_a_single(top.get("asset_class"))),
            detail=i18n.say(
                "find.concentration_single.detail",
                name=normalise_display(top["instrument_name"]),
                value=_money(_d(top["current_value"])),
                share=f"{top_share:.1f}",
            ),
            evidence={
                "instrument": top["instrument_name"],
                "asset_class": top.get("asset_class"),
                "value": str(_d(top["current_value"])),
                "share_pct": f"{top_share:.2f}",
                "threshold_pct": str(SINGLE_HOLDING_WATCH),
            },
        ))

    if len(ranked) >= 5:
        five = sum(_d(h["current_value"]) for h in ranked[:5])
        five_share = five / total * 100
        if five_share >= TOP_FIVE_WATCH:
            out.append(Finding(
                code="concentration_top5",
                severity="watch",
                headline=i18n.say("find.concentration_top5.head", share=f"{five_share:.0f}"),
                detail=(
                    f"₹{_money(five)} of ₹{_money(total)} sits in five holdings out of "
                    f"{len(live)}. The rest are small enough that they have little "
                    f"effect on your overall return either way."
                ),
                evidence={
                    "top_five_value": str(five),
                    "total_value": str(total),
                    "share_pct": f"{five_share:.2f}",
                    "holding_count": len(live),
                },
            ))

    # Concentration by fund house. Two funds from one AMC is ordinary; most of
    # a portfolio with one AMC is a single point of failure people rarely see,
    # because it hides behind having "several different funds".
    # Only across things somebody chose an issuer for. A provident fund was
    # reported as "47% of your money is with EPFO" alongside a line about
    # sharing research and house views -- EPFO is not a fund house and nobody
    # diversifies away from it.
    by_issuer: dict[str, Decimal] = {}
    for h in holdings:
        if not investable(h):
            continue
        issuer = (h.get("institution") or "").strip()
        if issuer:
            by_issuer[issuer] = by_issuer.get(issuer, Decimal(0)) + _d(h["current_value"])

    if by_issuer:
        name, value = max(by_issuer.items(), key=lambda kv: kv[1])
        share = value / total * 100
        if share >= SINGLE_ISSUER_WATCH and len(by_issuer) > 1:
            out.append(Finding(
                code="concentration_issuer",
                severity="watch",
                headline=i18n.say("find.concentration_issuer.head", share=f"{share:.0f}", name=name),
                detail=(
                    f"₹{_money(value)} sits with one institution. Holding several funds "
                    f"from the same house gives less spread than it appears to, since they "
                    f"often share research, house views and sometimes the same stocks."
                ),
                evidence={
                    "institution": name,
                    "value": str(value),
                    "share_pct": f"{share:.2f}",
                    "institution_count": len(by_issuer),
                },
            ))

    return out


def _commission_drag(holdings: list[dict]) -> list[Finding]:
    """What holding regular plans instead of direct ones costs each year.

    Deliberately conservative: schemes whose names do not state the plan are
    excluded entirely, and the exclusion is reported so the user knows the real
    figure may be higher.
    """
    regular: list[dict] = []
    unknown_value = Decimal(0)
    unknown_count = 0

    for h in holdings:
        if h.get("asset_class") != "mutual_fund":
            continue
        kind = plan_type(h.get("instrument_name", ""))
        if kind == "regular":
            regular.append(h)
        elif kind == "unknown":
            unknown_value += _d(h["current_value"])
            unknown_count += 1

    if not regular:
        return []

    annual = Decimal(0)
    for h in regular:
        category = (h.get("category") or "other").strip().lower()
        spread = COMMISSION_SPREAD.get(category, DEFAULT_SPREAD)
        annual += _d(h["current_value"]) * spread / 100

    if annual < DRAG_MIN_ANNUAL:
        return []

    regular_value = sum(_d(h["current_value"]) for h in regular)

    projection = {
        years: _compounded_cost(annual, years) for years in PROJECTION_YEARS
    }
    twenty = projection[20]

    detail = (
        f"You hold {len(regular)} funds worth ₹{_money(regular_value)} in regular plans. "
        f"The same schemes exist as direct plans, which carry no distributor commission. "
        f"On typical spreads that difference is about ₹{_money(annual)} a year. "
        f"Left alone for twenty years it comes to ₹{_money(twenty)}, because the money "
        f"you did not pay would have been invested too."
    )
    if unknown_count:
        detail += (
            f" A further {unknown_count} holdings worth ₹{_money(unknown_value)} do not "
            f"state their plan type, so they are left out of this figure."
        )

    return [Finding(
        code="commission_drag",
        severity="act",
        headline=i18n.say("find.commission_drag.head", amount=_money(annual)),
        detail=detail,
        estimated=True,
        evidence={
            "regular_plan_count": len(regular),
            "regular_plan_value": str(regular_value),
            "estimated_annual_cost": str(annual.quantize(Decimal("1"))),
            "projected_cost": {str(y): str(v) for y, v in projection.items()},
            "projection_rate_pct": str(PROJECTION_RATE * 100),
            "unknown_plan_count": unknown_count,
            "unknown_plan_value": str(unknown_value),
            "method": (
                "Category spreads between regular and direct plans, applied to current "
                "value. Scheme-level expense ratios are not yet held, so this is an "
                "estimate rather than an exact figure. Projections compound the annual "
                "saving at 11% a year, on the basis that money not paid away would "
                "itself have been invested."
            ),
            "spreads_used_pct": {k: str(v) for k, v in COMMISSION_SPREAD.items()},
        },
    )]


def _idle_cash(investor_id: str, holdings: list[dict]) -> list[Finding]:
    """Liquid money that has not moved in a long time.

    Liquid funds are for money with a job to do soon. Money that has sat in one
    for months is usually money someone parked and forgot, earning less than it
    would almost anywhere else.
    """
    parked: list[tuple[dict, int]] = []
    cutoff = date.today() - timedelta(days=IDLE_DAYS)

    for h in holdings:
        category = (h.get("category") or "").strip().lower()
        name = (h.get("instrument_name") or "").lower()
        is_liquid = category in ("liquid", "overnight") or "liquid" in name or "overnight" in name
        if not is_liquid:
            continue
        if _d(h["current_value"]) < IDLE_MIN_VALUE:
            continue

        last = db.fetch_one(
            """
            SELECT max(txn_date) AS last_txn
            FROM canonical_transactions
            WHERE investor_id = %s AND instrument_id = %s
              AND txn_date > '1990-01-01'
            """,
            (investor_id, h["instrument_id"]),
        )
        last_txn = last["last_txn"] if last else None
        if last_txn is None or last_txn <= cutoff:
            days = (date.today() - last_txn).days if last_txn else None
            parked.append((h, days))

    if not parked:
        return []

    total = sum(_d(h["current_value"]) for h, _ in parked)
    longest = max((d for _, d in parked if d is not None), default=None)

    when = f"for over {longest // 30} months" if longest else "with no recent activity"
    return [Finding(
        code="idle_cash",
        severity="watch",
        headline=i18n.say("find.idle_cash.head", amount=_money(total)),
        detail=i18n.say("find.idle_cash.detail", count=len(parked),
                        amount=_money(total), when=when),
        evidence={
            "holding_count": len(parked),
            "total_value": str(total),
            "days_idle": longest,
            "threshold_days": IDLE_DAYS,
            "holdings": [h["instrument_name"] for h, _ in parked],
        },
    )]


def _nothing_but_one_asset_class(allocation: list[dict]) -> list[Finding]:
    """A portfolio entirely in one asset class.

    Common and easy to miss: someone with eleven mutual funds feels diversified
    because they own eleven things, when in fact they own one asset class.
    """
    if len(allocation) != 1:
        return []
    only = allocation[0]
    if _d(only.get("value")) <= 0:
        return []

    names = {
        "mutual_fund": "mutual funds", "equity": "shares", "gold": "gold",
        "fixed_deposit": "deposits", "insurance": "insurance", "nps": "pension",
    }
    label = names.get(only["asset_class"], only["asset_class"].replace("_", " "))

    return [Finding(
        code="single_asset_class",
        severity="watch",
        headline=i18n.say("find.single_asset_class.head", label=label),
        detail=i18n.say("find.single_asset_class.detail",
                        value=_money(_d(only["value"])), label=label),
        evidence={
            "asset_class": only["asset_class"],
            "value": str(_d(only["value"])),
            "positions": only.get("positions"),
        },
    )]



# ---------------------------------------------------------------------------
# Market capitalisation tilt
# ---------------------------------------------------------------------------

# Funds do not always state their market-cap segment in a field we hold, but the
# scheme name almost always says it -- SEBI's categorisation rules mean a fund
# calling itself "Small Cap" is one. Reading the name is a derivation rather
# than a fact from the fund house, so anything built on it says so.
_CAP_PATTERNS = (
    ("small_cap", re.compile(r"\bsmall[ -]?cap\b", re.I)),
    ("mid_cap", re.compile(r"\bmid[ -]?cap\b", re.I)),
    ("large_cap", re.compile(r"\b(large[ -]?cap|bluechip|blue chip|nifty|sensex|index)\b", re.I)),
    ("multi_cap", re.compile(r"\b(flexi[ -]?cap|multi[ -]?cap|focused|value|contra|elss|tax saver)\b", re.I)),
)

# Categories that are equity by nature, however the fund is named.
_EQUITY_CATEGORIES = {"equity", "sectoral/thematic", "elss", "hybrid"}
_STABLE_CATEGORIES = {"liquid", "debt", "overnight", "gilt", "money market"}


def cap_segment(name: str, category: Optional[str]) -> str:
    """Which end of the market this fund invests in.

    Large and mid cap funds name themselves; anything left over is treated as
    multi-cap, which is what a flexi-cap or a focused fund effectively is.
    """
    text = f"{name or ''} {category or ''}"
    for segment, pattern in _CAP_PATTERNS:
        if pattern.search(text):
            return segment
    return "multi_cap"



# Bands as the exchange classifies them, rather than as we would guess from a
# name. NSE's own categorisation drives index inclusion and fund mandates, so
# it is the one everything else is measured against.
# SEBI's own boundaries: the largest hundred, then the next hundred and fifty.
LARGE_CAP_RANK = 100
MID_CAP_RANK = 250



@lru_cache(maxsize=1)
def _cap_ranks() -> dict[str, int]:
    """Every company's rank by market capitalisation, keyed by ISIN and symbol.

    Ranked once and held, rather than per holding: a forty-share portfolio
    would otherwise sort two thousand companies forty times to answer forty
    questions. Cached for the life of the process, which is right for a figure
    that moves with the market but not with the band boundaries -- a company
    does not cross from mid to large between two page loads.
    """
    # The column mixes two units. Roughly nine hundred companies carry their
    # market capitalisation in rupees and the rest in crores, in the same field
    # -- Schneider Electric at 319,442,990,760 and Reliance at 1,777,153, which
    # are 31,944 crore and 17.7 lakh crore respectively.
    #
    # Ranking the raw figure put Reliance 930th and made 96% of somebody's
    # equity read as small cap. No listed Indian company has a capitalisation
    # above 30 lakh crore, so anything past that is being quoted in rupees and
    # divides down by a crore.
    rows = db.fetch_all(
        """
        WITH normalised AS (
            SELECT symbol, isin,
                   CASE WHEN market_cap > 3000000 THEN market_cap / 10000000
                        ELSE market_cap END AS cap_cr
            FROM company_fundamentals
            WHERE market_cap IS NOT NULL AND market_cap > 0
        )
        SELECT symbol, isin,
               rank() OVER (ORDER BY cap_cr DESC NULLS LAST) AS position
        FROM normalised
        """
    )
    ranks: dict[str, int] = {}
    for row in rows:
        position = int(row["position"])
        if row["isin"]:
            ranks[row["isin"].strip().upper()] = position
        if row["symbol"]:
            ranks[row["symbol"].strip().upper()] = position
    return ranks


def forget_cap_ranks() -> None:
    """Drop the cached ranking, after the company master is refreshed."""
    _cap_ranks.cache_clear()


def _cap_band_for(holding: dict) -> str:
    """Which end of the market a directly held share sits in.

    SEBI defines the bands by rank rather than by a fixed rupee figure: the
    hundred largest companies by market capitalisation are large cap, the next
    hundred and fifty are mid, and everything below is small. Every equity fund
    mandate in India is written against that definition, so it is the one worth
    using.

    Computed here rather than read from a column, because the company master's
    `market_cap_category` arrived empty for all 2,329 companies -- the field
    exists upstream and nothing populates it. Ranking what we do hold gives an
    answer that is close enough to matter and, unlike a null, is an answer.
    """
    isin = (holding.get("isin") or "").strip().upper()
    symbol = (holding.get("symbol") or "").strip().upper()
    if not (isin or symbol):
        return "multi_cap"

    ranks = _cap_ranks()
    position = ranks.get(isin) or ranks.get(symbol)
    if not position:
        return "multi_cap"

    if position <= 100:
        return "large_cap"
    if position <= 250:
        return "mid_cap"
    return "small_cap"


def _split_by_nature(holdings: list[dict]) -> dict:
    """Value in equity, in stable assets, and by market-cap segment.

    Only mutual funds and shares are classified. A fixed deposit is stable by
    definition and gold is neither, so both are counted in the total without
    being forced into an equity bucket they do not belong in.
    """
    totals = {"equity": Decimal(0), "stable": Decimal(0), "other": Decimal(0),
              "small_cap": Decimal(0), "mid_cap": Decimal(0),
              "large_cap": Decimal(0), "multi_cap": Decimal(0)}

    for holding in holdings:
        value = _d(holding.get("current_value"))
        if value <= 0:
            continue
        asset_class = holding.get("asset_class")
        category = (holding.get("category") or "").strip().lower()

        if asset_class == "equity":
            totals["equity"] += value
            # A directly held share sits in whatever band the company is in.
            # This used to count every share as large cap, which was harmless
            # when nobody held any and wrong the moment somebody did: a 23%
            # position in a small-cap engineering company is not the same risk
            # as 23% in Reliance, and the small-cap finding would never have
            # fired on it.
            band = _cap_band_for(holding)
            totals[band] += value
            continue

        if asset_class in ("fixed_deposit", "cash", "bond", "gsec", "ppf_epf"):
            totals["stable"] += value
            continue

        if asset_class == "mutual_fund":
            if category in _STABLE_CATEGORIES:
                totals["stable"] += value
            elif category in _EQUITY_CATEGORIES or not category:
                totals["equity"] += value
                totals[cap_segment(holding.get("instrument_name", ""), category)] += value
            else:
                totals["other"] += value
            continue

        totals["other"] += value

    return totals


def _structure(holdings: list[dict], total: Decimal) -> list[Finding]:
    """What the shape of the portfolio implies.

    These are the observations an adviser makes at a glance: too much in the
    volatile end, nothing stable to fall back on, more funds than anyone can
    follow. Each states the figures behind it, because "reduce your small cap
    exposure" means nothing until you know it is 41% and what that is worth.
    """
    if total < MIN_PORTFOLIO_FOR_STRUCTURE or not holdings:
        return []

    parts = _split_by_nature(holdings)
    equity = parts["equity"]
    stable = parts["stable"]
    out: list[Finding] = []

    # Small cap share, measured against equity rather than the whole portfolio:
    # someone with half their money in deposits is not taking the same risk as
    # someone fully invested, even at the same small-cap rupee amount.
    if equity > 0:
        small = parts["small_cap"]
        share = small / equity * 100
        if share >= SMALL_CAP_WATCH:
            severe = share >= SMALL_CAP_HIGH
            out.append(Finding(
                code="small_cap_tilt",
                severity="act" if severe else "watch",
                headline=i18n.say("find.small_cap_tilt.head", share=f"{share:.0f}"),
                detail=(
                    f"₹{_money(small)} of your ₹{_money(equity)} in equity sits in "
                    f"small-cap funds. " + _falls_you_have_seen(holdings) +
                    "That is survivable if you can leave it alone; it is not if you "
                    "might need the money."
                ),
                evidence={
                    "small_cap_value": str(small),
                    "equity_value": str(equity),
                    "share_of_equity_pct": f"{share:.1f}",
                    "threshold_pct": str(SMALL_CAP_WATCH),
                    "method": "Segment read from scheme names, since fund houses do not "
                              "state it in the data we hold.",
                },
                estimated=True,
            ))

    # Nothing stable behind the equity.
    if total > 0:
        equity_share = equity / total * 100
        if equity_share >= EQUITY_NO_CUSHION and stable == 0:
            out.append(Finding(
                code="no_stable_cushion",
                severity="watch",
                headline="Everything you hold moves with the market",
                detail=(
                    f"₹{_money(equity)} of ₹{_money(total)} is in equity, with nothing "
                    f"in deposits, debt funds or cash. In a falling market there is nothing "
                    f"to draw on except the thing that has fallen, which is how people end "
                    f"up selling at the worst moment."
                ),
                evidence={"equity_value": str(equity), "total_value": str(total),
                          "equity_share_pct": f"{equity_share:.1f}",
                          "stable_value": str(stable),
                          "threshold_pct": str(EQUITY_NO_CUSHION)},
            ))

        # The opposite problem, and a real one over a long horizon.
        stable_share = stable / total * 100
        if stable_share >= TOO_CONSERVATIVE:
            out.append(Finding(
                code="heavily_conservative",
                severity="watch",
                headline=i18n.say("find.heavily_conservative.head", share=f"{stable_share:.0f}"),
                detail=(
                    f"₹{_money(stable)} of ₹{_money(total)} is somewhere safe. That "
                    f"protects the amount but not its worth: at 6 per cent against inflation "
                    f"near 5, it grows slowly in real terms. Whether that is right depends "
                    f"on when you need it."
                ),
                evidence={"stable_value": str(stable), "total_value": str(total),
                          "stable_share_pct": f"{stable_share:.1f}",
                          "threshold_pct": str(TOO_CONSERVATIVE)},
            ))

    # More funds than anyone follows.
    fund_count = sum(1 for h in holdings if h.get("asset_class") == "mutual_fund"
                     and _d(h.get("current_value")) > 0)
    if fund_count > TOO_MANY_FUNDS:
        out.append(Finding(
            code="too_many_funds",
            severity="watch",
            headline=i18n.say("find.too_many_funds.head", count=fund_count),
            detail=(
                f"Past a dozen or so, funds in the same category tend to hold the same "
                f"companies, so the extra ones add work rather than diversification. "
                f"Consolidating to eight or ten you can actually follow usually loses "
                f"nothing."
            ),
            evidence={"fund_count": fund_count, "threshold": TOO_MANY_FUNDS},
        ))

    return out




# ---------------------------------------------------------------------------
# What the portfolio means for this particular person
#
# Everything above this point describes a portfolio. These describe a portfolio
# against somebody's circumstances, which is a different and more useful thing:
# a fifth of your wealth in one midcap fund is unremarkable at thirty and
# reckless at sixty-two, and until we know which we are only reporting shape.
#
# Each of these needs something from the profile, and stays silent without it.
# The absence is reported separately, next to the field that would fill it, so
# a blank here reads as a question not yet answered rather than a broken page.
# ---------------------------------------------------------------------------

# Months of spending worth holding somewhere reachable. Six is the usual
# counsel; more where several people depend on one income.
EMERGENCY_MONTHS_BASE = 6
EMERGENCY_MONTHS_WITH_DEPENDENTS = 9

# Life cover as a multiple of annual income. Ten is the common rule of thumb in
# India and roughly what it takes to replace an income for the years a family
# would need it.
COVER_MULTIPLE = 10


def _years_between(start: date, end: date) -> Decimal:
    return Decimal((end - start).days) / Decimal("365.25")


def _emergency_cover(profile: dict, holdings: list[dict]) -> list[Finding]:
    """Whether there is enough within reach for a bad month.

    Counted from what the investor told us they keep aside, plus anything in
    liquid funds -- money in an equity fund is not an emergency fund, because
    the emergency and the market falling tend to arrive together.
    """
    expenses = _d(profile.get("monthly_expenses"))
    if expenses <= 0:
        return []

    dependents = profile.get("dependents") or 0
    months_needed = (EMERGENCY_MONTHS_WITH_DEPENDENTS if dependents
                     else EMERGENCY_MONTHS_BASE)
    target = expenses * months_needed

    reachable = _d(profile.get("emergency_fund"))
    for holding in holdings:
        category = (holding.get("category") or "").strip().lower()
        name = (holding.get("instrument_name") or "").lower()
        if category in ("liquid", "overnight") or "liquid" in name or "overnight" in name:
            reachable += _d(holding.get("current_value"))

    if reachable >= target:
        return []

    shortfall = target - reachable
    months_covered = (reachable / expenses) if expenses else Decimal(0)

    return [Finding(
        code="emergency_shortfall",
        severity="act" if months_covered < 3 else "watch",
        headline=f"You have about {months_covered:.0f} month{'s' if months_covered >= 2 else ''} of expenses within reach",
        detail=(
            f"On spending of ₹{_money(expenses)} a month, "
            f"{months_needed} months means ₹{_money(target)} somewhere you can get at "
            f"quickly. You have ₹{_money(reachable)}, so ₹{_money(shortfall)} short. "
            f"Without it, a bad month means selling investments at whatever price the "
            f"market offers that week."
        ),
        evidence={
            "monthly_expenses": str(expenses),
            "months_recommended": months_needed,
            "target": str(target),
            "reachable_today": str(reachable),
            "shortfall": str(shortfall),
            "dependents": dependents,
            "method": "Counts what you told us you keep aside, plus liquid and overnight "
                      "funds. Equity is not counted: it falls when you are most likely to "
                      "need it.",
        },
    )]


def _protection_gap(investor_id: str, profile: dict) -> list[Finding]:
    """Whether the people who depend on this income would be alright.

    Only raised where somebody actually depends on them. Life cover for a person
    with no dependents is a product sale, not a need.
    """
    dependents = profile.get("dependents") or 0
    income = _d(profile.get("monthly_income"))
    if dependents <= 0 or income <= 0:
        return []

    annual_income = income * 12
    needed = annual_income * COVER_MULTIPLE

    # Term cover is the most important kind and has no surrender value, so those
    # policies sit at zero and never appear in the current-holdings view. Reading
    # only that view meant the finding could not see the cover it exists to check.
    rows = db.fetch_all(
        """
        SELECT DISTINCT ON (h.instrument_id) h.attributes
        FROM holding_snapshots h
        JOIN instruments i ON i.id = h.instrument_id
        WHERE h.investor_id = %s AND i.asset_class = 'insurance'
        ORDER BY h.instrument_id, h.as_of DESC
        """,
        (investor_id,),
    )
    cover = Decimal(0)
    policies = 0
    for row in rows:
        assured = _d((row.get("attributes") or {}).get("sum_assured"))
        if assured > 0:
            cover += assured
            policies += 1

    if cover >= needed:
        return []

    gap = needed - cover
    covered_years = (cover / annual_income) if annual_income else Decimal(0)

    if cover == 0:
        detail = (
            f"{dependents} {'person depends' if dependents == 1 else 'people depend'} on your "
            f"income of ₹{_money(annual_income)} a year, and we have no life cover on record. "
            f"Around ₹{_money(needed)} would replace that income for the years they would "
            f"need it. If you do hold a policy, add it and this will correct itself."
        )
    else:
        detail = (
            f"Your policies cover ₹{_money(cover)}, which is about {covered_years:.0f} years "
            f"of your income. For {dependents} "
            f"{'dependent' if dependents == 1 else 'dependents'} the usual measure is ten "
            f"years, or ₹{_money(needed)} — a gap of ₹{_money(gap)}."
        )

    return [Finding(
        code="protection_gap",
        severity="act" if cover == 0 else "watch",
        headline=("No life cover recorded" if cover == 0
                  else f"Your cover is about {covered_years:.0f} years of income"),
        detail=detail,
        evidence={
            "dependents": dependents,
            "annual_income": str(annual_income),
            "cover_recorded": str(cover),
            "policies_counted": policies,
            "suggested_cover": str(needed),
            "gap": str(gap),
            "method": f"Ten times annual income, the common measure in India. Counts the sum "
                      f"assured on policies you have recorded.",
        },
        estimated=True,
    )]


def _goal_shortfall(profile: dict, goals: list[dict], total: Decimal) -> list[Finding]:
    """Whether what they hold will reach what they are saving for.

    Only for goals with both an amount and a date. Without those there is
    nothing to measure against, and inventing an assumption would be worse than
    staying quiet.
    """
    # Split whatever is not explicitly earmarked between the goals that need it.
    measurable = [g for g in goals
                  if _d(g.get("target_amount")) > 0 and g.get("target_date")
                  and not g.get("is_achieved")]
    already_earmarked = sum(_d(g.get("current_amount")) for g in measurable)
    unallocated = max(total - already_earmarked, Decimal(0))
    sharing = [g for g in measurable if _d(g.get("current_amount")) <= 0]
    unearmarked_share = (unallocated / len(sharing)) if sharing else Decimal(0)

    out: list[Finding] = []
    for goal in goals:
        target = _d(goal.get("target_amount"))
        target_date = goal.get("target_date")
        if target <= 0 or not target_date or goal.get("is_achieved"):
            continue

        years = _years_between(date.today(), target_date)
        if years <= 0:
            continue

        # What is set aside for this goal, where they have said so. Otherwise
        # the portfolio is shared between the goals that have no earmarked
        # amount -- counting the whole of it against each one would tell someone
        # with three goals that they are on track for all three using the same
        # rupees.
        earmarked = _d(goal.get("current_amount"))
        if earmarked <= 0:
            earmarked = unearmarked_share
        monthly = _d(goal.get("monthly_contribution"))

        # Grown at a rate deliberately below long-run equity returns, because a
        # projection that flatters itself is worth less than one nobody argues
        # with.
        rate = Decimal("0.10")
        growth = (Decimal(1) + rate) ** years
        projected = earmarked * growth

        if monthly > 0:
            months = years * 12
            monthly_rate = rate / 12
            factor = (((Decimal(1) + monthly_rate) ** months - 1) / monthly_rate)
            projected += monthly * factor

        if projected >= target:
            continue

        shortfall = target - projected
        # What monthly saving would close it.
        months = years * 12
        monthly_rate = rate / 12
        factor = (((Decimal(1) + monthly_rate) ** months - 1) / monthly_rate)
        needed_monthly = (shortfall / factor) if factor > 0 else shortfall

        out.append(Finding(
            code="goal_shortfall",
            severity="watch",
            headline=i18n.say("find.goal_shortfall.head", goal=goal["name"],
                          shortfall=_money(shortfall)),
            detail=(
                f"You are aiming for ₹{_money(target)} in {years:.0f} years. Growing what "
                f"you hold at 10 per cent a year gets you to about ₹{_money(projected)}. "
                f"Putting aside a further ₹{_money(needed_monthly)} a month would close it."
            ),
            evidence={
                "goal": goal["name"],
                "target_amount": str(target),
                "target_date": str(target_date),
                "years_remaining": f"{years:.1f}",
                "counted_towards_it": str(earmarked),
                "projected_value": str(projected.quantize(Decimal("1"))),
                "shortfall": str(shortfall.quantize(Decimal("1"))),
                "monthly_needed": str(needed_monthly.quantize(Decimal("1"))),
                "assumed_return_pct": "10",
                "method": "Compounded at 10% a year, below the long-run equity average on "
                          "purpose. Counts your whole portfolio unless you have earmarked "
                          "an amount for this goal.",
            },
            estimated=True,
        ))

    return out


def _allocation_for_age(profile: dict, holdings: list[dict], total: Decimal) -> list[Finding]:
    """Whether the mix of equity and safer assets suits their stage.

    Uses the old rule that equity might be around a hundred less your age. It is
    a rough guide rather than a law, and it is described as one -- but it is a
    reasonable place to start a conversation, which is what this is.
    """
    dob = profile.get("date_of_birth")
    if not dob or total <= 0:
        return []

    age = date.today().year - dob.year - ((date.today().month, date.today().day) < (dob.month, dob.day))
    parts = _split_by_nature(holdings)
    equity_share = (parts["equity"] / total * 100) if total else Decimal(0)

    suggested = Decimal(max(20, min(90, 100 - age)))
    drift = equity_share - suggested

    # Twenty points either way before it is worth mentioning: this is a guide,
    # not a target, and nagging about small differences would be noise.
    if abs(drift) < 20:
        return []

    if drift > 0:
        headline = f"More in equity than is usual at {age}"
        detail = (
            f"About {equity_share:.0f}% of what you hold is in equity. A common guide at "
            f"{age} is nearer {suggested:.0f}%. That is not wrong — it depends on when you "
            f"need the money — but it does mean a bad year hits harder than it needs to."
        )
    else:
        headline = f"Less in equity than is usual at {age}"
        detail = (
            f"About {equity_share:.0f}% of what you hold is in equity, against a common "
            f"guide of {suggested:.0f}% at {age}. Safer assets protect the amount, but over "
            f"{max(1, 60 - age)} years they may not protect what it buys."
        )

    return [Finding(
        code="allocation_for_age",
        severity="watch",
        headline=headline,
        detail=detail,
        evidence={
            "age": age,
            "equity_share_pct": f"{equity_share:.1f}",
            "commonly_suggested_pct": str(suggested),
            "difference_pct": f"{drift:.1f}",
            "method": "The rough guide that equity might be around a hundred minus your age. "
                      "A starting point for a conversation, not a rule.",
        },
        estimated=True,
    )]



def _savings_capacity(profile: dict, investor_id: str) -> list[Finding]:
    """What is left over each month, against what is actually being invested.

    The gap between the two is usually the largest single lever a person has,
    and almost nobody has worked it out. Someone with forty thousand spare and
    a five thousand SIP is not short of money; they are short of a standing
    instruction.
    """
    income = _d(profile.get("monthly_income"))
    expenses = _d(profile.get("monthly_expenses"))
    if income <= 0 or expenses <= 0:
        return []

    spare = income - expenses
    if spare <= 0:
        # Spending more than they earn. Saying anything about asset allocation
        # here would be beside the point.
        return [Finding(
            code="spending_exceeds_income",
            severity="act",
            headline=i18n.say("find.spending_exceeds_income.head"),
            detail=(
                f"You have told us ₹{_money(income)} coming in and ₹{_money(expenses)} "
                f"going out each month. Until that reverses, nothing else about the "
                f"portfolio matters very much — the shortfall has to come from somewhere, "
                f"and usually it comes from the investments."
            ),
            evidence={"monthly_income": str(income), "monthly_expenses": str(expenses),
                      "monthly_gap": str(expenses - income)},
        )]

    # What they are actually putting in, from the last twelve months of
    # recorded contributions.
    row = db.fetch_one(
        """
        SELECT coalesce(sum(amount), 0) AS invested, count(*) AS contributions
        FROM canonical_transactions
        WHERE investor_id = %s
          AND lower(txn_type) IN ('purchase','sip','buy','investment','switch_in')
          AND txn_date > current_date - interval '12 months'
          AND txn_date > '1990-01-01'
        """,
        (investor_id,),
    )
    invested_year = _d(row["invested"]) if row else Decimal(0)
    invested_month = invested_year / 12

    # Nothing to say if they are already using most of what they have spare.
    if invested_month >= spare * Decimal("0.7"):
        return []

    unused = spare - invested_month
    if unused < Decimal("2000"):
        return []

    # What twenty years of the unused amount would come to, at a rate chosen
    # below the long-run average on purpose.
    years = 20
    monthly_rate = Decimal("0.10") / 12
    months = years * 12
    factor = (((Decimal(1) + monthly_rate) ** months - 1) / monthly_rate)
    could_be = unused * factor

    return [Finding(
        code="unused_capacity",
        severity="watch",
        headline=i18n.say("find.unused_capacity.head", amount=_money(unused)),
        detail=(
            f"You have roughly ₹{_money(spare)} a month after expenses, and over the last "
            f"year you have been investing about ₹{_money(invested_month)} of it. The "
            f"difference is not a criticism — some of it is meant to be spent. But if "
            f"₹{_money(unused)} of it went in every month, in twenty years that alone "
            f"would be about ₹{_money(could_be)}."
        ),
        estimated=True,
        evidence={
            "monthly_income": str(income),
            "monthly_expenses": str(expenses),
            "monthly_spare": str(spare),
            "monthly_invested": str(invested_month.quantize(Decimal("1"))),
            "unused": str(unused.quantize(Decimal("1"))),
            "projected_over_20y": str(could_be.quantize(Decimal("1"))),
            "method": "Contributions over the last twelve months, divided by twelve. "
                      "Projection compounds the unused amount at 10% a year.",
        },
    )]


def _risk_fit(profile: dict, holdings: list[dict], total: Decimal) -> list[Finding]:
    """Whether what they hold matches what they said they wanted.

    Deliberately not a score. AlphaLensMF computes a risk number out of ten by
    multiplying allocations by weights somebody chose, which produces a figure
    nobody can derive or argue with. What can be said honestly is simpler and
    more useful: here is the risk you said you were comfortable with, and here
    is what you are actually holding.
    """
    appetite = profile.get("risk_appetite")
    if not appetite or total <= 0:
        return []

    parts = _split_by_nature(holdings)
    equity_share = parts["equity"] / total * 100
    volatile_share = (parts["small_cap"] + parts["mid_cap"]) / total * 100

    # The band each stated appetite implies. Wide, because these are
    # conversations rather than thresholds.
    bands = {
        "conservative": (Decimal(0), Decimal(40)),
        "moderate": (Decimal(30), Decimal(75)),
        "aggressive": (Decimal(60), Decimal(100)),
    }
    low, high = bands.get(appetite, (Decimal(0), Decimal(100)))

    said = {
        "conservative": "you would rather protect what you have",
        "moderate": "you can accept some ups and downs",
        "aggressive": "you can sit through a bad year or two",
    }[appetite]

    if low <= equity_share <= high:
        return []

    if equity_share > high:
        detail = (
            f"You told us {said}. {equity_share:.0f}% of what you hold is in equity, "
            f"and {volatile_share:.0f}% is in mid and small companies specifically. "
            f"That is more movement than you described being comfortable with — which "
            f"matters most in the year it falls, because that is when people sell."
        )
        headline = f"You hold more risk than you said you wanted"
    else:
        detail = (
            f"You told us {said}. Only {equity_share:.0f}% of what you hold is in equity, "
            f"which is less risk than you described being willing to take. That is not a "
            f"mistake, but over a long horizon it is a choice with a cost."
        )
        headline = "You hold less risk than you said you were willing to"

    return [Finding(
        code="risk_mismatch",
        severity="watch",
        headline=headline,
        detail=detail,
        evidence={
            "stated_appetite": appetite,
            "equity_share_pct": f"{equity_share:.1f}",
            "mid_and_small_cap_pct": f"{volatile_share:.1f}",
            "band_for_this_appetite": f"{low:.0f}-{high:.0f}%",
            "method": "Compares what you said against what you hold. Deliberately not a "
                      "score: a number out of ten with no derivation explains nothing.",
        },
    )]


def _horizon_fit(profile: dict, holdings: list[dict], total: Decimal) -> list[Finding]:
    """Whether the holdings suit how long the money can stay put.

    The mismatch that hurts is equity on a short horizon: it is the situation
    where a bad year arrives exactly when the money is needed, and there is no
    time to wait for it back.
    """
    horizon = profile.get("horizon_years")
    if not horizon or total <= 0:
        return []

    parts = _split_by_nature(holdings)
    equity_share = parts["equity"] / total * 100
    volatile = parts["small_cap"] + parts["mid_cap"]
    volatile_share = volatile / total * 100

    if horizon <= 3 and equity_share > 40:
        return [Finding(
            code="horizon_mismatch",
            severity="act",
            headline=i18n.say("find.horizon_mismatch.head",
                          share=f"{equity_share:.0f}", horizon=horizon),
            detail=(
                f"You said the money can stay invested for around {horizon} years. Equity "
                f"has historically needed five to seven to be reliable — over three, a bad "
                f"stretch may not have recovered by the time you need it. "
                f"₹{_money(parts['equity'])} is exposed to that."
            ),
            evidence={"horizon_years": horizon, "equity_share_pct": f"{equity_share:.1f}",
                      "equity_value": str(parts["equity"]),
                      "method": "Equity on a horizon under five years, which is shorter "
                                "than the period it has historically needed."},
        )]

    if horizon <= 7 and volatile_share > 30:
        return [Finding(
            code="horizon_mismatch",
            severity="watch",
            headline=i18n.say("find.risk_mismatch.head", share=f"{volatile_share:.0f}", horizon=horizon),
            detail=(
                f"Mid and small caps swing further and take longer to come back — two to "
                f"three years is common after a bad fall. On a horizon of about {horizon} "
                f"years that leaves less room than it looks."
            ),
            evidence={"horizon_years": horizon,
                      "mid_and_small_cap_pct": f"{volatile_share:.1f}",
                      "value": str(volatile)},
            estimated=True,
        )]

    return []



def _falls_you_have_seen(holdings: list[dict]) -> str:
    """What the investor's own small-cap funds have actually done.

    A warning about volatility is an abstraction until it is about something
    the reader owns. "Small caps can fall a long way" is a sentence anybody can
    nod at; "the one you hold fell 27% and has not come back" is a fact they
    have to weigh.

    Falls back to the general statement where we have no price history, rather
    than saying nothing.
    """
    from . import navs

    worst = None
    for holding in holdings:
        name = (holding.get("instrument_name") or "")
        if "small" not in name.lower():
            continue
        try:
            fall = navs.drawdown(holding["instrument_id"])
        except Exception:
            continue
        if fall and (worst is None or fall["worst_fall_pct"] > worst[1]["worst_fall_pct"]):
            worst = (name, fall)

    if worst is None:
        return ("Small caps have historically fallen 40 to 50 per cent in bad markets "
                "and taken two to three years to recover. ")

    name, fall = worst
    when = fall["bottomed"].strftime("%B %Y") if fall.get("bottomed") else "recently"
    if fall.get("still_below_peak"):
        return (f"{name[:44]} fell {fall['worst_fall_pct']}% into {when} and has not "
                f"regained its previous high. ")
    if fall.get("months_to_recover"):
        return (f"{name[:44]} fell {fall['worst_fall_pct']}% into {when}, and took "
                f"{fall['months_to_recover']} months to recover. ")
    return (f"{name[:44]} has fallen {fall['worst_fall_pct']}% from its high at worst. ")



# ---------------------------------------------------------------------------
# Owning the same company twice
# ---------------------------------------------------------------------------

# Below this, two funds sharing a name is coincidence rather than concentration.
OVERLAP_WATCH_PCT = Decimal("25")
# A company has to be a real position in both funds before its being in both
# means anything. Half a per cent each is not the investor's problem.
MIN_WEIGHT_TO_COUNT = Decimal("1.0")


def _fund_overlap(investor_id: str, holdings: list[dict], total: Decimal) -> list[Finding]:
    """Where several funds hold the same companies.

    The number people usually see for this is invented. AlphaLensMF returns a
    percentage keyed on the fund's category -- two large-cap funds always score
    seventy -- without comparing a single holding. This compares the actual
    disclosures, and where they are not on record it says nothing rather than
    estimating.

    Overlap is measured by weight, not by counting shared names. Two funds both
    holding a company at half a per cent share a name and nothing that matters;
    both holding it at eight per cent is the same bet made twice. For each pair
    we take the smaller of the two weights on every shared company and add them
    up, which is the proportion of the smaller fund duplicated by the larger.
    """
    funds = [h for h in holdings
             if h.get("asset_class") == "mutual_fund" and _d(h.get("current_value")) > 0]
    if len(funds) < 2 or total <= 0:
        return []

    rows = db.fetch_all(
        """
        SELECT i.id AS instrument_id, i.native_code AS scheme_code,
               c.isin, c.instrument_name AS company, c.weight_pct
        FROM instruments i
        JOIN scheme_constituents c ON c.scheme_code = i.native_code
        WHERE i.id = ANY(%s)
          AND c.as_of = (SELECT max(as_of) FROM scheme_constituents
                         WHERE scheme_code = c.scheme_code)
          AND c.weight_pct >= %s
        """,
        ([f["instrument_id"] for f in funds], MIN_WEIGHT_TO_COUNT),
    )
    if not rows:
        return []

    # Group by fund, keyed on the company. ISIN where the disclosure gives one,
    # since two AMCs write the same company's name differently.
    by_fund: dict[str, dict[str, Decimal]] = {}
    # Matching is on ISIN because two AMCs write the same company's name
    # differently. Display is by name, because an ISIN tells the reader nothing.
    company_names: dict[str, str] = {}
    for row in rows:
        key = (row["isin"] or row["company"]).strip().upper()
        by_fund.setdefault(row["instrument_id"], {})[key] = _d(row["weight_pct"])
        name = (row["company"] or "").strip()
        if name and (key not in company_names or len(name) < len(company_names[key])):
            # Where AMCs disagree on the name, the shorter is usually the
            # cleaner: "Reliance Industries" over "Reliance Industries Limited".
            company_names[key] = name

    covered = [f for f in funds if f["instrument_id"] in by_fund]
    if len(covered) < 2:
        return []

    names = {f["instrument_id"]: f["instrument_name"] for f in funds}
    values = {f["instrument_id"]: _d(f["current_value"]) for f in funds}

    worst: Optional[dict] = None
    pairs_examined = 0

    for i, first in enumerate(covered):
        for second in covered[i + 1:]:
            a = by_fund[first["instrument_id"]]
            b = by_fund[second["instrument_id"]]
            shared = set(a) & set(b)
            if not shared:
                continue
            pairs_examined += 1

            # The smaller weight on each shared company: the part of the
            # smaller position that the larger already gives you.
            duplicated = sum(min(a[key], b[key]) for key in shared)
            if worst is None or duplicated > worst["overlap_pct"]:
                top = sorted(shared, key=lambda k: min(a[k], b[k]), reverse=True)[:4]
                worst = {
                    "overlap_pct": duplicated,
                    "first": names[first["instrument_id"]],
                    "second": names[second["instrument_id"]],
                    "shared_count": len(shared),
                    "top_shared": [company_names.get(k, k) for k in top],
                    "combined_value": values[first["instrument_id"]]
                                      + values[second["instrument_id"]],
                }

    if worst is None or worst["overlap_pct"] < OVERLAP_WATCH_PCT:
        return []

    companies = ", ".join(worst["top_shared"][:3])

    return [Finding(
        code="fund_overlap",
        severity="watch",
        headline=(f"Two of your funds are {worst['overlap_pct']:.0f}% the same portfolio"),
        detail=(
            f"{worst['first'][:44]} and {worst['second'][:44]} hold "
            f"{worst['shared_count']} of the same companies at meaningful weight — "
            f"{companies} among them. Together they are ₹{_money(worst['combined_value'])} "
            f"of your money making largely the same bet. Holding both spreads less than "
            f"holding one of them and something different."
        ),
        evidence={
            "overlap_pct": f"{worst['overlap_pct']:.1f}",
            "fund_a": worst["first"],
            "fund_b": worst["second"],
            "shared_companies": worst["shared_count"],
            "largest_shared": worst["top_shared"],
            "combined_value": str(worst["combined_value"]),
            "pairs_compared": pairs_examined,
            "funds_with_disclosures": len(covered),
            "funds_held": len(funds),
            "method": "Compares the funds' own monthly portfolio disclosures. For each "
                      "shared company we take the smaller of the two weights and add "
                      "them up, so a company held heavily by both counts for more than "
                      "one held lightly. Companies under 1% in either fund are ignored.",
        },
    )]



def _not_checked(investor_id: str) -> list[str]:
    """What we could not look at, named rather than silently absent.

    A person reading a short list of findings should know whether that is
    because nothing is wrong or because we could not see. Funds whose
    disclosures we do not hold are the common case.
    """
    gaps: list[str] = []
    row = db.fetch_one(
        """
        SELECT count(DISTINCT i.id) AS held,
               count(DISTINCT i.id) FILTER (
                 WHERE EXISTS (SELECT 1 FROM scheme_constituents c
                               WHERE c.scheme_code = i.native_code)) AS covered
        FROM instruments i
        JOIN v_current_holdings v ON v.instrument_id = i.id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
        """,
        (investor_id,),
    )
    if row and row["held"] and row["covered"] < row["held"]:
        missing = row["held"] - row["covered"]
        gaps.append(
            f"Overlap for {missing} of your {row['held']} funds, whose published "
            f"holdings we do not have yet."
        )
    return gaps



def _concentration_meets_history(investor_id: str, holdings: list[dict],
                                 total: Decimal) -> list[Finding]:
    """A large position in a fund that has fallen a long way.

    The dashboard already says "76% of your portfolio is in one fund", and
    separately, inside that fund, "it fell 68% once and took twenty months to
    come back". Both are true and neither lands, because nobody puts them
    together.

    Multiplied out they are a different sentence: if that happened again you
    would be down seventy-three thousand rupees, and you would be waiting two
    years. That is what the concentration actually means, and it is the sort of
    thing somebody should know before it happens rather than during.

    Only where both facts are solid: a position large enough to matter, and a
    drawdown computed from prices we hold.
    """
    if total <= 0:
        return []

    from . import navs

    out: list[Finding] = []
    for holding in holdings:
        value = _d(holding.get("current_value"))
        if value <= 0:
            continue
        share = value / total * 100
        # Below a fifth of the portfolio, one holding's bad year is survivable
        # arithmetic rather than the story of the year.
        if share < 20:
            continue

        try:
            fall = navs.drawdown(holding["instrument_id"])
        except Exception:
            continue
        if not fall or fall["worst_fall_pct"] < 30:
            continue

        worst = fall["worst_fall_pct"]
        would_lose = value * worst / 100
        months = fall.get("months_to_recover")
        when = fall["bottomed"].strftime("%B %Y") if fall.get("bottomed") else "the worst of it"

        recovery = (f"and on the last occasion it took {months} months to come back"
                    if months else "and it has not regained that peak since")

        out.append(Finding(
            code="concentration_meets_history",
            severity="act" if share >= 40 else "watch",
            headline=(f"₹{_money(would_lose)} of this would go if "
                      f"{_readable_name(holding['instrument_name'], 38)} "
                      f"repeated its worst fall"),
            detail=(
                f"That fund is {share:.0f}% of what you hold. It has fallen "
                f"{worst}% before, bottoming in {when}, {recovery}. Applied to "
                f"the ₹{_money(value)} you have in it now, a repeat would take "
                f"₹{_money(would_lose)} off your total — leaving "
                f"₹{_money(total - would_lose)}. It recovered last time, and it "
                f"may again; the question is whether you would still be holding "
                f"it by then."
            ),
            evidence={
                "holding": holding["instrument_name"],
                "value": str(value),
                "share_of_portfolio_pct": f"{share:.1f}",
                "worst_fall_pct": str(worst),
                "bottomed": str(fall.get("bottomed")),
                "months_to_recover": months,
                "would_lose": str(would_lose.quantize(Decimal("1"))),
                "method": "The fund's largest peak-to-trough fall in the price "
                          "history we hold, applied to what you have in it today. "
                          "Not a forecast: a thing that has already happened once.",
            },
        ))

    # One is a warning; four is noise. The largest exposure makes the point.
    out.sort(key=lambda f: Decimal(f.evidence["would_lose"]), reverse=True)
    return out[:1]



def _readable_name(name: str, limit: int = 42) -> str:
    """A fund's name as a person would say it.

    Strips the registrar's scheme code, which means nothing to the reader and
    costs six characters of a headline. Truncates at a word boundary, because
    "Franklin India Focused Equit" reads as a bug however correct the number
    beside it is.
    """
    text = normalise_display(name or "")
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0]
    return (cut or text[:limit]).rstrip(" -,") + "\u2026"


def normalise_display(name: str) -> str:
    """The name without the registrar's prefix, but otherwise untouched."""
    import re
    text = (name or "").strip()
    # "273 - Franklin India..." or "L091G-SBI Midcap..." -- a code, then a
    # separator. Same shapes the instrument matcher recognises.
    text = re.sub(r"^\d{2,6}\s*-\s*", "", text)
    text = re.sub(r"^[A-Z]*\d[A-Z0-9]*\s*-\s*", "", text, flags=re.I)
    text = re.sub(r"^([A-Z]{2,6})\s*-\s+(?=[A-Z])", "", text)
    return text.strip()



# One industry past a third of the money is a concentration people rarely
# notice, because it is spread across holdings that look diversified. Six
# different capital goods companies is one bet made six times.
SECTOR_WATCH = Decimal("35")
SECTOR_HIGH = Decimal("50")


def _sector_concentration(investor_id: str, total: Decimal) -> list[Finding]:
    """Where one industry has quietly become most of the portfolio.

    Counted through the funds as well as the direct holdings, because a person
    holding four funds and three shares can be concentrated in an industry
    without owning an obvious position in it.

    Only where we can see most of the money. A sector split covering a third of
    a portfolio says nothing reliable about the whole, and saying it anyway
    would be the same mistake as reporting a return from half the transactions.
    """
    from . import analysis

    try:
        exposure = analysis.sector_exposure(investor_id)
    except Exception:
        return []

    coverage = _d(exposure.get("attributed_share_pct"))
    sectors = [s for s in exposure.get("sectors") or []
               if (s.get("sector") or "").lower() != "not classified"]
    if coverage < 60 or not sectors:
        return []

    top = sectors[0]
    share = _d(top["share_pct"])
    if share < SECTOR_WATCH:
        return []

    others = sum(1 for s in sectors[1:4])
    return [Finding(
        code="sector_concentration",
        severity="act" if share >= SECTOR_HIGH else "watch",
        headline=i18n.say("find.sector_concentration.head", share=f"{share:.0f}",
                          sector=_sector_name(top["sector"])),
        detail=i18n.say("find.sector_concentration.detail",
                        value=_money(_d(top["value"])),
                        sector=_sector_name(top["sector"])),
        evidence={
            "sector": top["sector"],
            "value": str(_d(top["value"])),
            "share_pct": f"{share:.1f}",
            "coverage_pct": f"{coverage:.1f}",
            "next_sectors": [s["sector"] for s in sectors[1:4]],
            "threshold_pct": str(SECTOR_WATCH),
            "method": "Direct shares plus each fund's value spread across the companies "
                      "it discloses holding.",
        },
    )]



def _unclassified_plans(holdings: list[dict]) -> Decimal:
    """Value in funds whose name does not say which plan it is.

    Carried over from the commission-drag finding this replaces, because it is
    the one thing that one did better: saying what it could not read, so a
    reader knows the real figure may be higher than the one shown.
    """
    unknown = Decimal(0)
    for holding in holdings:
        if holding.get("asset_class") != "mutual_fund":
            continue
        if plan_type(holding.get("instrument_name", "")) == "unknown":
            unknown += _d(holding["current_value"])
    return unknown


def _regular_plans(investor_id: str, total: Decimal) -> list[Finding]:
    """Funds paying a commission that buys nothing.

    A regular plan and a direct plan are the same fund with the same manager
    holding the same stocks. The difference is a trail commission taken out of
    the NAV every year, forever, for a sale that happened once.

    Reported with the tax of switching beside the saving, because a switch is a
    redemption and a purchase. On a holding with a large embedded gain the tax
    can exceed several years of commission, and saying "switch" without saying
    that costs somebody money.
    """
    from . import plans

    try:
        found = plans.summary(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.warning("plan check failed for %s: %s", investor_id, err)
        return []

    if not found:
        return []

    saving = _d(found["total_saving_a_year"])
    if saving < Decimal("5000"):
        return []

    # Worth acting on where at least one switch pays for itself; worth knowing
    # about otherwise, since new money can go to the direct plan regardless.
    actionable = [f for f in found["funds"]
                  if f["worth_it"] in ("yes", "probably")
                  or _d(f["tax_to_switch"]) <= 0]

    over_twenty = saving * 20

    from . import wealth as wealth_service
    unclassified = _unclassified_plans(wealth_service.holdings(investor_id))
    caveat = ""
    if unclassified > 0:
        caveat = (f" A further ₹{_money(unclassified)} sits in funds whose names "
                  f"do not say which plan they are, so the real figure may be "
                  f"higher than this.")

    return [Finding(
        code="regular_plans",
        severity="act" if actionable else "watch",
        headline=(f"₹{_money(saving)} a year goes to commission on "
                  f"{found['count']} of your funds"),
        detail=(
            f"{found['reading']} Over twenty years, at the same holding, that is "
            f"about ₹{_money(over_twenty)} — money leaving the fund every year for "
            f"a sale that happened once.{caveat}"
        ),
        evidence={
            "count": found["count"],
            "saving_a_year": str(saving),
            "over_twenty_years": str(over_twenty.quantize(Decimal("1"))),
            "switchable_now": len(actionable),
            "funds": [{"name": f["name"], "saving": f["saving_a_year"],
                       "tax": f["tax_to_switch"], "payback_years": f["payback_years"],
                       "worth_it": f["worth_it"]}
                      for f in found["funds"][:5]],
            "method": found["method"],
        },
    )]


# ---------------------------------------------------------------------------
# Deciding what is worth doing
# ---------------------------------------------------------------------------

# What acting on each finding is actually like, as opposed to how alarming it
# sounds. A list of nine things is another way of saying nothing is important,
# so these decide which two get put in front of someone.
#
#   certainty   -- is the gain known, or does it depend on what markets do
#   effort      -- how much work and how many decisions
#   reversible  -- can it be undone cheaply if they change their mind
#   tax         -- does acting crystallise a liability
#
# The weights are judgement, not measurement, and they are written here rather
# than buried so that anyone who disagrees can see exactly what to argue with.
ACTION_SHAPE = {
    "commission_drag": {
        "certainty": 1.0,   # the saving is arithmetic, not a forecast
        "effort": 0.3,      # a handful of switches
        "reversible": 1.0,  # switch back tomorrow at no cost
        "tax": 0.2,         # a switch is a redemption, so some liability
        "verb": "Move",
    },
    "concentration_single": {
        "certainty": 0.3,   # only matters if that holding does badly
        "effort": 0.6,
        "reversible": 0.4,
        "tax": 1.0,         # selling realises gains
        "verb": "Decide about",
    },
    "concentration_top5": {"certainty": 0.3, "effort": 0.8, "reversible": 0.4, "tax": 1.0,
                           "verb": "Look at"},
    "concentration_issuer": {"certainty": 0.3, "effort": 0.6, "reversible": 0.5, "tax": 1.0,
                             "verb": "Spread"},
    "idle_cash": {
        "certainty": 0.8,   # the shortfall against a better home is fairly predictable
        "effort": 0.2,      # one decision, one transaction
        "reversible": 0.9,
        "tax": 0.1,         # liquid funds accrue little to realise
        "verb": "Put to work",
    },
    "small_cap_tilt": {"certainty": 0.4, "effort": 0.6, "reversible": 0.4, "tax": 1.0,
                       "verb": "Reduce"},
    "no_stable_cushion": {"certainty": 0.5, "effort": 0.3, "reversible": 0.9, "tax": 0.1,
                          "verb": "Set aside"},
    "heavily_conservative": {"certainty": 0.4, "effort": 0.4, "reversible": 0.8, "tax": 0.2,
                             "verb": "Consider"},
    "too_many_funds": {"certainty": 0.2, "effort": 0.9, "reversible": 0.3, "tax": 1.0,
                       "verb": "Consolidate"},
    "fund_overlap": {"certainty": 0.5, "effort": 0.6, "reversible": 0.4, "tax": 1.0,
                     "verb": "Consider consolidating"},
    # Certainty is high not because the fall will happen but because it already
    # did: the figure is history applied to a current position, not a forecast.
    "concentration_meets_history": {"certainty": 0.7, "effort": 0.6, "reversible": 0.4,
                                    "tax": 1.0, "verb": "Think about"},
    "sector_concentration": {"certainty": 0.4, "effort": 0.7, "reversible": 0.4, "tax": 1.0,
                             "verb": "Spread"},
    # The most certain finding there is: the commission is a fact, not a
    # forecast. Effort is low and it is fully reversible, which is why it
    # ranks where it does.
    "regular_plans": {"certainty": 0.95, "effort": 0.25, "reversible": 1.0, "tax": 0.6,
                      "verb": "Switch"},
    "single_asset_class": {"certainty": 0.2, "effort": 0.5, "reversible": 0.9, "tax": 0.1,
                           "verb": "Add to"},

    # Things that depend on knowing the person. An emergency fund and life cover
    # rank high because the cost of not having them is not a lower return, it is
    # a forced sale or a family left short.
    "emergency_shortfall": {"certainty": 0.9, "effort": 0.3, "reversible": 1.0, "tax": 0.1,
                            "verb": "Set aside"},
    "protection_gap": {"certainty": 0.8, "effort": 0.5, "reversible": 0.7, "tax": 0.0,
                       "verb": "Cover"},
    "goal_shortfall": {"certainty": 0.6, "effort": 0.4, "reversible": 0.8, "tax": 0.1,
                       "verb": "Save more for"},
    "allocation_for_age": {"certainty": 0.3, "effort": 0.6, "reversible": 0.5, "tax": 0.9,
                           "verb": "Rebalance"},

    # Putting spare money to work is the cheapest thing on any of these lists:
    # no selling, no tax, and it can be stopped next month.
    "unused_capacity": {"certainty": 0.7, "effort": 0.2, "reversible": 1.0, "tax": 0.0,
                        "verb": "Start investing"},
    "spending_exceeds_income": {"certainty": 1.0, "effort": 0.9, "reversible": 0.5, "tax": 0.0,
                                "verb": "Look at"},
    "risk_mismatch": {"certainty": 0.4, "effort": 0.6, "reversible": 0.5, "tax": 0.9,
                      "verb": "Reconsider"},
    "horizon_mismatch": {"certainty": 0.6, "effort": 0.5, "reversible": 0.6, "tax": 0.9,
                         "verb": "Shorten"},
}

DEFAULT_SHAPE = {"certainty": 0.4, "effort": 0.5, "reversible": 0.6, "tax": 0.5, "verb": "Look at"}


# A cost that repeats every year is worth more than the same sum once. Five
# years is a deliberately conservative horizon -- the drag finding itself
# projects twenty -- but it is enough to stop a recurring leak being ranked
# below a one-off observation.
RECURRING_HORIZON_YEARS = Decimal("5")

# Findings whose evidence names a large sum because that sum is the portfolio,
# not because the finding is about money at stake. Scoring these by their stated
# value put "everything you hold is in mutual funds" above a certain annual
# saving, purely because the portfolio is large.
_OBSERVATIONS = {"single_asset_class", "too_many_funds", "concentration_top5"}


def _rupee_weight(finding: dict) -> Decimal:
    """What acting on this is worth, in money.

    Three kinds, deliberately not treated alike:

      a recurring cost   counted over five years, because it repeats
      money at stake     counted at a fraction, because exposure is contingent
      an observation     counted small, because the sum quoted is the portfolio
                         itself rather than anything at risk
    """
    evidence = finding.get("evidence") or {}
    code = finding.get("code", "")

    # A cost we can put a number on. This is the strongest kind.
    if evidence.get("estimated_annual_cost"):
        try:
            return Decimal(str(evidence["estimated_annual_cost"])) * RECURRING_HORIZON_YEARS
        except Exception:
            pass

    # Idle cash: the whole sum is genuinely doing nothing, so it counts in full.
    if code == "idle_cash" and evidence.get("total_value"):
        try:
            return Decimal(str(evidence["total_value"]))
        except Exception:
            pass

    if code in _OBSERVATIONS:
        # Real, worth saying, but not a sum anyone can act on for a known gain.
        return Decimal("25000")

    # A shortfall is money that will not be there. Counted in full, because
    # unlike an exposure it is not contingent on anything.
    # An unused monthly amount is worth what it becomes, not what it is.
    if code == "unused_capacity" and evidence.get("projected_over_20y"):
        try:
            return Decimal(str(evidence["projected_over_20y"])) * Decimal("0.1")
        except Exception:
            pass

    # What a repeat would cost, in full. It is money that would actually go.
    if code == "concentration_meets_history" and evidence.get("would_lose"):
        try:
            return Decimal(str(evidence["would_lose"]))
        except Exception:
            pass

    if code == "regular_plans" and evidence.get("over_twenty_years"):
        try:
            return Decimal(str(evidence["over_twenty_years"]))
        except Exception:
            pass

    for key in ("shortfall", "gap"):
        if evidence.get(key):
            try:
                return Decimal(str(evidence[key]))
            except Exception:
                pass

    for key in ("value", "small_cap_value", "equity_value", "stable_value"):
        if evidence.get(key):
            try:
                # A fifth: being concentrated is a risk, not a loss, and
                # treating the two alike would rank every large position above
                # every real saving.
                return Decimal(str(evidence[key])) * Decimal("0.2")
            except Exception:
                pass

    return Decimal(0)


def prioritise(findings: list[dict], total_value: Decimal) -> list[dict]:
    """Order findings by whether they are worth doing something about.

    Not by how alarming they sound. The first thing on the list should be the
    one where acting is most clearly worthwhile -- known gain, little work,
    easily undone -- rather than the one with the largest number attached.
    """
    scored: list[tuple[Decimal, dict]] = []

    for finding in findings:
        shape = ACTION_SHAPE.get(finding["code"], DEFAULT_SHAPE)
        money = _rupee_weight(finding)

        # Relative to the portfolio, so a lakh means something different to
        # someone with five lakhs than to someone with five crores.
        materiality = (money / total_value) if total_value > 0 else Decimal(0)
        materiality = min(materiality, Decimal(1))

        score = (
            materiality
            * Decimal(str(shape["certainty"]))
            * (Decimal(2) - Decimal(str(shape["effort"])))
            * (Decimal(1) + Decimal(str(shape["reversible"])))
            * (Decimal(2) - Decimal(str(shape["tax"])))
        )
        # An "act" finding outranks a "watch" of similar weight.
        if finding.get("severity") == "act":
            score *= Decimal("1.5")

        scored.append((score, finding))

    scored.sort(key=lambda pair: pair[0], reverse=True)

    ordered: list[dict] = []
    for rank, (score, finding) in enumerate(scored, start=1):
        shape = ACTION_SHAPE.get(finding["code"], DEFAULT_SHAPE)
        item = dict(finding)
        item["rank"] = rank
        item["action_verb"] = shape["verb"]
        item["priority_score"] = str(score.quantize(Decimal("0.0001")))
        item["why_this_order"] = _explain_rank(finding, shape, rank)
        ordered.append(item)
    return ordered


def _explain_rank(finding: dict, shape: dict, rank: int) -> str:
    """Why this sits where it does.

    Shown to the reader, so it has to be a reason rather than a restatement.
    """
    reasons: list[str] = []
    if shape["certainty"] >= 0.8:
        reasons.append("the saving is arithmetic rather than a forecast")
    elif shape["certainty"] <= 0.3:
        reasons.append("it only costs you if that part of the market turns")

    if shape["effort"] <= 0.3:
        reasons.append("it takes a few minutes")
    elif shape["effort"] >= 0.8:
        reasons.append("it means unpicking several positions")

    if shape["tax"] >= 0.9:
        reasons.append("acting means selling, which has a tax cost")
    elif shape["reversible"] >= 0.9:
        reasons.append("you can undo it if you change your mind")

    if not reasons:
        return "Worth attention once the items above are settled."
    return ("First because " if rank == 1 else "Then, because ") + ", and ".join(reasons) + "."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def for_investor(investor_id: str) -> dict:
    """Every finding that applies, most pressing first."""
    from . import wealth   # imported here to keep the module independently testable

    holdings = wealth.holdings(investor_id)
    summary = wealth.net_worth(investor_id)
    allocation = wealth.allocation(investor_id)

    # The total has to be the sum of the same holdings every share is measured
    # against. net_worth() reprices against NAV history where it can, so its
    # figure and the holdings list disagree whenever prices are missing or
    # stale for part of the portfolio -- and a share computed across that
    # mismatch reads as "this fund is 875% of what you hold".
    #
    # Whatever the headline total says elsewhere, within a finding the
    # denominator is the holdings themselves.
    total = sum(_d(h.get("current_value")) for h in holdings) or Decimal(0)
    if total <= 0:
        total = _d(summary["total_value"])

    # Categories live on the instrument, and the holdings view does not carry
    # them, so fetch once and attach rather than querying per holding.
    if holdings:
        rows = db.fetch_all(
            "SELECT id, category FROM instruments WHERE id = ANY(%s)",
            ([h["instrument_id"] for h in holdings],),
        )
        category = {r["id"]: r["category"] for r in rows}
        for h in holdings:
            h["category"] = category.get(h["instrument_id"])

    findings: list[Finding] = []
    findings += _concentration(holdings, total)
    findings += _structure(holdings, total)
    findings += _fund_overlap(investor_id, holdings, total)
    findings += _concentration_meets_history(investor_id, holdings, total)
    findings += _sector_concentration(investor_id, total)
    findings += _regular_plans(investor_id, total)

    # Anything that depends on knowing the person rather than the portfolio.
    # Silent when the profile is empty, which is the common case at first.
    from . import profile as profile_service
    who = profile_service.get_profile(investor_id) or {}
    goals = profile_service.list_goals(investor_id) if who else []
    if who:
        findings += _emergency_cover(who, holdings)
        findings += _protection_gap(investor_id, who)
        findings += _allocation_for_age(who, holdings, total)
        findings += _savings_capacity(who, investor_id)
        findings += _risk_fit(who, holdings, total)
        findings += _horizon_fit(who, holdings, total)
    if goals:
        findings += _goal_shortfall(who, goals, total)
    # _commission_drag retired: _regular_plans covers the same ground and can
    # name the direct twin, compute the tax of switching, and tell somebody to
    # redirect rather than switch. Two findings on one fact reporting different
    # totals -- 43,442 and 48,027 -- is worse than either alone.
    findings += _idle_cash(investor_id, holdings)
    findings += _nothing_but_one_asset_class(allocation)

    ranked = prioritise([f.as_dict() for f in findings], total)

    # Two, not nine. A list of everything is a way of deciding nothing, and the
    # point of ranking them was to be able to say which ones matter now.
    now = [f for f in ranked[:2] if Decimal(f["priority_score"]) > 0]

    return {
        "investor_id": investor_id,
        "count": len(ranked),
        "worth_doing_now": now,
        "findings": ranked,
        # Said plainly so an empty list does not read as a failure to load.
        "summary": (
            "Nothing in this portfolio needs your attention right now."
            if not ranked else
            f"{len(now)} thing{'s' if len(now) != 1 else ''} worth doing, "
            f"{len(ranked)} worth knowing about."
        ),
        "not_yet_checked": _not_checked(investor_id),
    }
