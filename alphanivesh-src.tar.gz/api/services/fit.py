"""Whether somebody can hold what they are holding.

Two figures exist separately and mean much more together.

The research service scores what a fund demands: its deepest fall, how long
recoveries took, how much it swings. SBI Midcap scores 38 out of 100 —
"demands discipline" — on a record that includes a 78.6% drawdown and
recoveries averaging twenty-six months.

Our own behavioural reading says what somebody has actually done: whether the
money kept going in when the market fell, whether it goes in monthly at all,
where in each fund's range the purchases landed.

Neither is a judgement on its own. A fund that demands discipline is a fine
holding for somebody who has shown they have it, and a poor one for somebody
who stopped contributing during a fifteen per cent fall — and the record says
which of those a person is.

What this is not: a reason to sell. Somebody holding a demanding fund who
cannot hold it through a fall has two options, and selling into a rising market
is only one of them. The other is knowing in advance what it will feel like,
which is most of what makes it survivable. This says which fund will test them
and by how much, and leaves the decision where it belongs.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.fit")

# Below this a fund is asking more of somebody than most people have.
DEMANDING = 45

# A holding smaller than this does not decide anything, whatever it demands.
MATERIAL_PCT = Decimal("5")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def for_investor(investor_id: str) -> Optional[dict]:
    """Which holdings will test this person, and by how much.

    Only material positions. A fund with a brutal history at two per cent of a
    portfolio is a curiosity; the same fund at twenty per cent is the thing
    that decides whether somebody stays invested.
    """
    from . import behaviour, dataservice

    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value,
               i.native_code
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0 AND i.native_code ~ '^[0-9]+$'
        ORDER BY v.current_value DESC
        LIMIT 12
        """,
        (investor_id,),
    )
    if not rows:
        return None

    total = _d(db.fetch_one(
        "SELECT sum(current_value) AS total FROM v_current_holdings "
        "WHERE investor_id = %s", (investor_id,)
    ).get("total"))
    if total <= 0:
        return None

    how = behaviour.profile(investor_id)
    style = ((how or {}).get("style") or {}).get("style")
    nerve = (how or {}).get("nerve") or {}
    held_through = bool(nerve.get("held_nerve"))
    automatic = style == "monthly"

    demanding = []
    for row in rows:
        share = _d(row["current_value"]) / total * 100
        if share < MATERIAL_PCT:
            continue
        try:
            reading = dataservice.mf_behaviour(str(row["native_code"]))
        except dataservice.DataServiceError:
            continue

        score = reading.get("score")
        if score is None:
            continue

        receipts = reading.get("receipts") or {}
        demanding.append({
            "name": row["instrument_name"],
            "code": row["native_code"],
            "share_pct": str(share.quantize(Decimal("0.1"))),
            "value": str(_d(row["current_value"]).quantize(Decimal("1"))),
            "score": score,
            "band": reading.get("band"),
            "what_it_asks": reading.get("conversation"),
            "receipts": receipts,
            "tests_you": score < DEMANDING,
        })

    if not demanding:
        return None

    hardest = min(demanding, key=lambda f: f["score"])
    tough = [f for f in demanding if f["tests_you"]]

    return {
        "holdings": demanding,
        "hardest": hardest["name"],
        "demanding_count": len(tough),
        "you": {
            "style": style,
            "held_through_a_fall": held_through,
            "automatic": automatic,
            "reading": ((how or {}).get("style") or {}).get("reading"),
        },
        "reading": _reading(tough, hardest, held_through, automatic, how),
        "note": ("This is not a reason to sell anything. Somebody holding a "
                 "demanding fund who cannot sit through a fall has two options, "
                 "and selling into a rising market is only one of them \u2014 the "
                 "other is knowing in advance what it will feel like, which is "
                 "most of what makes it survivable."),
    }


def _reading(tough: list[dict], hardest: dict, held_through: bool,
             automatic: bool, how: Optional[dict]) -> str:
    """The two figures, put together.

    Careful about credit. A standing instruction that ran through a fall shows
    the arrangement worked, not that the person held their nerve — those are
    different things and the second is what a demanding fund actually needs.
    """
    if not tough:
        return ("Nothing you hold has a history brutal enough to test somebody "
                "into selling. That is worth knowing: it means staying invested "
                "asks less of you than it does of most people.")

    receipts = hardest.get("receipts") or {}
    fall = receipts.get("deepest_fall") or receipts.get("max_drawdown")
    recovery = receipts.get("worst_recovery_months") or receipts.get("recovery_months")

    opening = (
        f"{hardest['name']} is {hardest['share_pct']}% of what you hold and "
        f"scores {hardest['score']} out of 100 on how hard it is to sit through"
        + (f" \u2014 it has fallen {abs(_d(fall)):.0f}% before" if fall else "")
        + (f" and taken around {recovery} months to come back."
           if recovery else ".")
    )

    if not how or not ((how.get("style") or {}).get("readable")):
        return (opening + " We do not hold enough of your purchase history to "
                "say whether that is a fund you could sit through.")

    if held_through and not automatic:
        return (opening + " You have already chosen to keep buying through a "
                "fall, which is the thing this fund needs and most people do "
                "not have. On the record, you can hold it.")

    if held_through and automatic:
        return (opening + " Your instalments ran through the last fall, which "
                "means the arrangement held \u2014 not quite the same as knowing you "
                "would have. Worth deciding now, while nothing is falling, "
                "whether you would let it keep running through a fall four "
                "times deeper.")

    return (opening + " We have not seen you invest through a fall yet, so "
            "there is no evidence either way. The question is worth answering "
            "before the market asks it: a fund like this one only returns what "
            "it returns to people who do not sell.")
