"""What happened after we said something.

Every other product in this market tells somebody what is true today. None of
them comes back. The reason is not ambition — it is that coming back requires
having kept a record of what you said, and nobody keeps one.

We do. The advice ledger holds every recommendation with its basis and its
date, which means the second half is available: compare what is held now
against what was advised then, and three things fall out.

**Whether they acted.** The regular plan became direct — they did it. The
emergency fund still is not there — they did not. Neither is a judgement, and
the second is often the more useful: a recommendation nobody has acted on in
six months is either wrong, badly explained, or harder than we said.

**What it produced.** *"Three months ago you switched HDFC Hybrid to direct.
That has saved ₹1,603 so far, and ₹6,412 a year from here."* That is the
sentence nothing else can write, because nothing else remembers what it told
you. It is also the only honest way to earn the next piece of advice.

**What it unlocked.** Guardrails that withheld an action release when the
condition clears. Somebody who built the emergency fund can now be shown the
rebalance the engine was holding back — and being told why it appeared is
better than it appearing silently.

**On being wrong.** Where advice was followed and did not help, this says so.
A follow-up that only reports successes is marketing, and somebody can tell
the difference immediately.
"""

from __future__ import annotations

import json
import logging
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.followup")

# Advice younger than this has not had time to be acted on, and chasing
# somebody about it a week later is nagging rather than following up.
SETTLING_DAYS = 21

# How far back to look. Beyond this the portfolio has usually changed enough
# that attributing anything to one recommendation is a stretch.
HORIZON_DAYS = 400


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def _as_dict(value: Any) -> dict:
    """Ledger columns come back as dict or as text depending on the driver."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return {}
    return {}


def since_last_time(investor_id: str) -> Optional[dict]:
    """What became of what we said."""
    rows = db.fetch_all(
        """
        SELECT id, shown_at, kind, said, basis, engine_version
        FROM advice_ledger
        WHERE investor_id = %s
          AND kind IN ('decision', 'buy_plan')
          AND shown_at < now() - (%s || ' days')::interval
          AND shown_at > now() - (%s || ' days')::interval
        ORDER BY shown_at DESC
        """,
        (investor_id, SETTLING_DAYS, HORIZON_DAYS),
    )
    if not rows:
        return None

    # The oldest advice in the window, because what we want to know is what
    # became of what we said first -- not what we repeated last week.
    earliest = rows[-1]
    said = _as_dict(earliest["said"])
    actions = said.get("actions") or []

    if not actions:
        return None

    when = earliest["shown_at"]
    days = (datetime.now(when.tzinfo) - when).days

    done, not_done, cannot_tell = [], [], []

    for action in actions:
        verdict = _check(investor_id, action, when)
        if verdict is None:
            cannot_tell.append({"what": action.get("what"),
                                "code": action.get("code")})
        elif verdict["acted"]:
            done.append(verdict)
        else:
            not_done.append(verdict)

    if not (done or not_done):
        return None

    return {
        "advised_on": when.date().isoformat(),
        "days_ago": days,
        "engine_version": earliest["engine_version"],
        "acted_on": done,
        "still_open": not_done,
        "cannot_tell": cannot_tell,
        "reading": _reading(done, not_done, days),
        "how_this_works": (
            "We keep a record of every suggestion with the figures behind it, "
            "so we can come back and compare what you hold now against what we "
            "said then. Where something was acted on we can say what it was "
            "worth; where it was not, it stays on the list."
        ),
    }


def _check(investor_id: str, action: dict, advised: datetime) -> Optional[dict]:
    """Whether one recommendation was acted on.

    Returns None where the question cannot be answered from what we hold --
    which is honest and common. A recommendation to think about something has
    no observable outcome, and pretending otherwise would make the whole
    exercise untrustworthy.
    """
    code = action.get("code") or ""

    if code in ("switch_to_direct", "redirect_future", "plan_switch"):
        return _check_direct_switch(investor_id, action, advised)
    if code in ("build_emergency_fund", "emergency_fund"):
        return _check_emergency(investor_id, action, advised)
    if code in ("harvest_exemption", "harvest_losses"):
        return _check_harvest(investor_id, action, advised)
    if code in ("reduce_concentration", "sector_concentration",
                "single_holding"):
        return _check_concentration(investor_id, action, advised)
    if code in ("start_sip", "restart_sip", "sip_stopped"):
        return _check_sip(investor_id, action, advised)

    return None


def _check_direct_switch(investor_id: str, action: dict,
                         advised: datetime) -> Optional[dict]:
    """Did the regular plans become direct?

    Counted rather than matched by name: somebody who switched two of three
    has partly acted, and saying "you did some of it" is more useful than a
    yes or a no.
    """
    from . import plans

    try:
        now = plans.summary(investor_id)
    except Exception:
        return None

    regular_now = len((now or {}).get("funds") or [])
    basis = action.get("evidence") or {}
    regular_then = basis.get("funds") or basis.get("count")

    if regular_then is None:
        # No count recorded, so only the direction is knowable.
        if regular_now == 0:
            return {"acted": True, "what": action.get("what"),
                    "code": action.get("code"),
                    "outcome": "Nothing you hold is on a regular plan now.",
                    "worth": action.get("worth")}
        return {"acted": False, "what": action.get("what"),
                "code": action.get("code"),
                "still": f"{regular_now} fund{'s' if regular_now != 1 else ''} "
                         f"still on a regular plan.",
                "worth": action.get("worth")}

    regular_then = int(regular_then)
    switched = regular_then - regular_now

    if switched <= 0:
        return {"acted": False, "what": action.get("what"),
                "code": action.get("code"),
                "still": f"Still {regular_now} on regular plans, the same as "
                         f"when we said this.",
                "worth": action.get("worth")}

    # What the switch has saved since. The annual figure divided across the
    # days elapsed -- approximate, and labelled as such.
    days = (datetime.now(advised.tzinfo) - advised).days
    annual = _d((action.get("evidence") or {}).get("annual_saving"))
    so_far = annual * Decimal(days) / 365 if annual else Decimal(0)

    return {
        "acted": True,
        "partly": regular_now > 0,
        "what": action.get("what"),
        "code": action.get("code"),
        "outcome": (f"You moved {switched} fund"
                    f"{'s' if switched != 1 else ''} to direct plans"
                    + (f", and {regular_now} "
                       f"{'is' if regular_now == 1 else 'are'} still on "
                       f"regular." if regular_now else ".")),
        "produced": str(so_far.quantize(Decimal("1"))) if so_far > 0 else None,
        "produced_reading": (
            f"About {_money(so_far)} kept so far, and {_money(annual)} a year "
            f"from here." if so_far > 0 else None),
        "worth": action.get("worth"),
    }


def _check_emergency(investor_id: str, action: dict,
                     advised: datetime) -> Optional[dict]:
    """Is there money somewhere it can be reached?"""
    row = db.fetch_one(
        """
        SELECT coalesce(sum(v.current_value), 0) AS liquid
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
          AND (v.asset_class IN ('fixed_deposit', 'cash')
               OR i.name ILIKE '%%liquid%%' OR i.name ILIKE '%%overnight%%')
        """,
        (investor_id,),
    )
    liquid = _d((row or {}).get("liquid"))
    target = _d((action.get("evidence") or {}).get("target"))

    if liquid <= 0:
        return {"acted": False, "what": action.get("what"),
                "code": action.get("code"),
                "still": "There is still nothing here that can be reached "
                         "without selling something at whatever price the day "
                         "offers.",
                "worth": action.get("worth")}

    return {
        "acted": True,
        "partly": bool(target and liquid < target),
        "what": action.get("what"),
        "code": action.get("code"),
        "outcome": (f"{_money(liquid)} now sits somewhere you can reach it"
                    + (f", against the {_money(target)} we suggested."
                       if target and liquid < target else ".")),
        "produced_reading": (
            "That is the thing that lets you leave the rest alone in a bad "
            "year, which is where most of the damage in investing actually "
            "happens."),
        "worth": action.get("worth"),
    }


def _check_harvest(investor_id: str, action: dict,
                   advised: datetime) -> Optional[dict]:
    """Was the allowance used?

    Only answerable where we hold the transactions. Most portfolios arrive
    without them, so this returns None more often than not -- and saying "we
    cannot tell" is better than assuming somebody did nothing.
    """
    row = db.fetch_one(
        """
        SELECT count(*) AS sales, coalesce(sum(amount), 0) AS raised
        FROM canonical_transactions
        WHERE investor_id = %s
          AND txn_date > %s
          AND txn_type IN ('redemption', 'switch_out', 'sale')
        """,
        (investor_id, advised.date()),
    )
    sales = int((row or {}).get("sales") or 0)

    # No sales recorded is ambiguous: either nothing was sold, or the sale
    # happened and we have not been given the statement that shows it.
    if sales == 0:
        return None

    return {
        "acted": True,
        "what": action.get("what"),
        "code": action.get("code"),
        "outcome": (f"{sales} sale{'s' if sales != 1 else ''} since we "
                    f"suggested this, raising {_money((row or {}).get('raised'))}."),
        "produced_reading": ("Whether that used the allowance depends on which "
                            "lots were sold, which we can only tell from a "
                            "full statement."),
        "worth": action.get("worth"),
    }


def _check_concentration(investor_id: str, action: dict,
                         advised: datetime) -> Optional[dict]:
    """Did the concentration come down?"""
    from . import analysis

    basis = action.get("evidence") or {}
    then = _d(basis.get("share_pct") or basis.get("concentration_pct"))
    if then <= 0:
        return None

    try:
        exposure = analysis.sector_exposure(investor_id)
    except Exception:
        return None

    listed = [s for s in (exposure or {}).get("sectors", [])
              if (s.get("sector") or "").lower() != "not classified"]
    if not listed:
        return None

    now = _d(listed[0].get("share_pct"))
    moved = then - now

    if moved < 2:
        return {"acted": False, "what": action.get("what"),
                "code": action.get("code"),
                "still": (f"Still {now:.0f}% in "
                          f"{(listed[0].get('sector') or '').lower()}, against "
                          f"{then:.0f}% when we said this."),
                "worth": action.get("worth")}

    return {
        "acted": True,
        "what": action.get("what"),
        "code": action.get("code"),
        "outcome": (f"Down from {then:.0f}% to {now:.0f}% in "
                    f"{(listed[0].get('sector') or '').lower()}."),
        "produced_reading": ("Worth saying that some of that can be the market "
                            "moving rather than you selling — a sector falling "
                            "reduces its share without anybody deciding "
                            "anything."),
        "worth": action.get("worth"),
    }


def _check_sip(investor_id: str, action: dict,
               advised: datetime) -> Optional[dict]:
    """Did the instalments restart?"""
    row = db.fetch_one(
        """
        SELECT count(*) AS buys FROM canonical_transactions
        WHERE investor_id = %s AND txn_date > %s
          AND txn_type IN ('purchase', 'sip')
        """,
        (investor_id, advised.date()),
    )
    buys = int((row or {}).get("buys") or 0)

    if buys == 0:
        return None      # ambiguous: no instalments, or no statement

    return {
        "acted": True,
        "what": action.get("what"),
        "code": action.get("code"),
        "outcome": f"{buys} purchases since, so something is going in again.",
        "worth": action.get("worth"),
    }


def _reading(done: list[dict], open_: list[dict], days: int) -> str:
    when = (f"{days} days ago" if days < 60 else
            f"{days // 30} months ago" if days < 365 else "a year ago")

    if done and not open_:
        first = done[0]
        line = f"You did what we suggested {when}."
        if first.get("produced_reading"):
            line += " " + first["produced_reading"]
        return line

    if done:
        return (f"Of what we suggested {when}, you did {len(done)} and "
                f"{len(open_)} {'is' if len(open_) == 1 else 'are'} still "
                f"open. " + (done[0].get("outcome") or ""))

    first = open_[0]
    return (f"We suggested {len(open_)} thing"
            f"{'s' if len(open_) != 1 else ''} {when} and "
            f"{'none of them has' if len(open_) != 1 else 'it has not'} been "
            f"acted on. {first.get('still', '')} That is worth a moment: "
            f"advice nobody acts on is usually wrong, badly explained, or "
            f"harder than we made it sound.")
