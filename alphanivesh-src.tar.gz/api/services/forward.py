"""What might happen next, from what has happened before.

Not a formula. The standard projection multiplies a portfolio by twelve per
cent a year and draws a smooth curve, which is wrong in a way that matters:
nobody's money grows smoothly, and a curve that pretends otherwise sets an
expectation the first bad quarter destroys.

This replays history instead. Take the portfolio's own daily returns, sample
them in blocks so that bad weeks stay bad weeks, and run the resulting path
forward two thousand times. What comes out is a range rather than a number, and
the range is the honest answer.

**Why blocks rather than single days.** Shuffling individual days destroys the
thing that makes markets frightening: falls cluster. A crash is not twenty
independent bad days, it is one bad month, and a simulation that draws days
independently produces a distribution far too well behaved at the tails.
Twenty-day blocks keep the clustering.

**Why the portfolio's own returns.** A projection built from the index
describes the index. This portfolio is 63% capital goods with a beta of 1.28,
and its distribution of outcomes is not the market's — using the market's would
understate both the upside and the damage.

**What this is not.** It is not a forecast and it does not know about anything
history did not contain. Every path here is a rearrangement of the last few
years, so a shock unlike anything in that window is absent from all two
thousand of them. The range is wide, and reality is wider.

**And the median is not the expectation.** Half the paths land below it. A
platform showing only the middle line is showing the least interesting number
on the chart.
"""

from __future__ import annotations

import logging
import random
import statistics
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.forward")

# Enough history to resample from. Below this the blocks repeat so often that
# the simulation describes a handful of months rather than a market.
MIN_DAYS = 500

# Trading days in a year, and the block length. Twenty is about a month, which
# is long enough to hold a bad stretch together and short enough that two
# thousand paths are meaningfully different from each other.
YEAR = 252
BLOCK = 20

PATHS = 2000
HORIZONS = (1, 3, 5, 10)

# Fixed, so the same portfolio gives the same answer twice. A projection that
# changes when somebody refreshes the page is a projection nobody can discuss.
SEED = 20260829

# ---------------------------------------------------------------------------
# The drift problem
# ---------------------------------------------------------------------------
#
# Resampling a window projects that window's return forward forever. On a real
# portfolio this produced 29.7 lakh becoming 19.3 crore in ten years and a zero
# per cent chance of loss over three -- because those holdings had an
# exceptional five years and the simulation faithfully assumed it would
# continue.
#
# The volatility from a short window is trustworthy; the drift is not. The
# standard error of a daily mean over five years is larger than the mean
# itself, so the observed return is mostly noise even when the observed
# variance is not.
#
# So: keep the shape, temper the centre. Each sampled return is shifted so the
# series' average moves toward a long-run assumption, by an amount that depends
# on how much history there is. Five years earns little weight; twenty would
# earn most.

# What Indian equity has returned over periods long enough to mean something.
# A convention, stated wherever it is used, and the anchor the observed drift
# is pulled toward.
LONG_RUN_PCT = Decimal("12")

# How much history it takes before the observed drift is worth trusting on its
# own. Twenty years, which no portfolio here has -- so in practice every
# projection is anchored more than it is observed, which is the right way round.
FULL_WEIGHT_YEARS = Decimal("20")

# Above this observed return, blending is not enough. A window that produced
# 40% a year is not a window anything sensible can be projected from, and
# saying so is better than showing a tempered fantasy.
ABSURD_PCT = Decimal("35")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def for_investor(investor_id: str,
                 monthly: Optional[Any] = None) -> Optional[dict]:
    """Where this portfolio might be in one, three, five and ten years.

    The monthly contribution comes from what somebody actually invests, read
    from their record, unless a figure is passed in. A projection that assumes
    contributions nobody makes is a different portfolio's projection.
    """
    from . import behaviour, var, wealth

    returns, coverage = var._portfolio_returns(investor_id)
    if len(returns) < MIN_DAYS:
        return {
            "computable": False,
            "why": (f"We hold {len(returns)} days of combined price history for "
                    f"this portfolio. Resampling needs about two years of it — "
                    f"below that every path is a rearrangement of the same few "
                    f"months and the range means nothing."),
        }

    start = _d(coverage.get("covered"))
    if start <= 0:
        return None

    contribution = _d(monthly)
    if contribution <= 0:
        try:
            how = behaviour.profile(investor_id)
            contribution = _d(((how or {}).get("style") or {}).get("median_month"))
        except Exception:
            contribution = Decimal(0)

    # Temper the drift before anything is simulated.
    observed, anchored, shift = _anchor(returns)

    if observed > ABSURD_PCT:
        return {
            "computable": False,
            "observed_pct": str(observed.quantize(Decimal("0.1"))),
            "why": (f"This portfolio's holdings returned about "
                    f"{observed:.0f}% a year over the history we hold. That is "
                    f"a remarkable run rather than a rate anything can be "
                    f"projected from — resampling it forward would produce "
                    f"figures that look like a promise and are arithmetic on "
                    f"an exceptional few years."),
            "what_would_help": ("A longer history, or a portfolio whose recent "
                                "record is less extreme. The volatility here is "
                                "measurable; the return is not."),
        }

    rng = random.Random(SEED)
    blocks = _blocks([r + shift for r in returns])

    results = []
    for years in HORIZONS:
        ends = _simulate(start, contribution, blocks, years, rng)
        ends.sort()

        def at(share: float) -> Decimal:
            index = min(len(ends) - 1, int(share * len(ends)))
            return ends[index]

        invested = start + contribution * 12 * years
        median = at(0.50)

        results.append({
            "years": years,
            "invested": str(invested.quantize(Decimal("1"))),
            "worst_5": str(at(0.05).quantize(Decimal("1"))),
            "poor_25": str(at(0.25).quantize(Decimal("1"))),
            "median": str(median.quantize(Decimal("1"))),
            "good_75": str(at(0.75).quantize(Decimal("1"))),
            "best_95": str(at(0.95).quantize(Decimal("1"))),
            "median_change_pct": str(((median - invested) / invested * 100)
                                     .quantize(Decimal("0.1"))
                                     if invested > 0 else Decimal(0)),
            # Not "0%". None of two thousand paths finishing below what went
            # in is a statement about two thousand paths, and rounding it to
            # zero turns a sample into a guarantee -- which is exactly the
            # reading somebody takes from it.
            "losing_paths": sum(1 for e in ends if e < invested),
            "chance_of_loss_pct": str(
                (Decimal(sum(1 for e in ends if e < invested)) /
                 Decimal(len(ends)) * 100).quantize(Decimal("1"))),
            "chance_of_loss": _describe_loss(
                sum(1 for e in ends if e < invested), len(ends)),
        })

    ten = next(r for r in results if r["years"] == 10)

    return {
        "computable": True,
        "starting_from": str(start.quantize(Decimal("1"))),
        "monthly": str(contribution.quantize(Decimal("1"))),
        "paths": PATHS,
        "block_days": BLOCK,
        "history_days": len(returns),
        "observed_return_pct": str(observed.quantize(Decimal("0.1"))),
        "assumed_return_pct": str(anchored.quantize(Decimal("0.1"))),
        "horizons": results,
        "reading": _reading(results, start, contribution),
        "method": (
            f"Two thousand paths, each built by drawing {BLOCK}-day blocks from "
            f"this portfolio's own daily history and stringing them together. "
            f"Blocks rather than single days because falls cluster — a crash is "
            f"one bad month rather than twenty independent bad days, and "
            f"drawing days independently produces a distribution far too well "
            f"behaved at the tails."
        ),
        "why_your_own": (
            "Built from this portfolio's returns rather than the index's, "
            "because they are not the same distribution. A concentrated "
            "portfolio has both more upside and more damage in it than the "
            "market does, and projecting it from the market would understate "
            "both."
        ),
        "caveat": (
            "Every path here is a rearrangement of the last few years, so a "
            "shock unlike anything in that window appears in none of them. The "
            "range is wide and reality is wider. This is not a forecast: it is "
            "what the arithmetic of this portfolio's own volatility produces "
            "when run forward many times."
        ),
        "on_the_drift": (
            f"These holdings returned about {observed:.0f}% a year over the "
            f"{len(returns) // YEAR} years we hold. The projection does not "
            f"assume that continues: it assumes {anchored:.0f}%, which is that "
            f"figure pulled most of the way toward the {LONG_RUN_PCT}% Indian "
            f"equity has returned over longer periods.\n\n"
            f"The reason is that a few years of daily data cannot pin down a "
            f"growth rate — the uncertainty in the average is larger than the "
            f"average itself — while it measures volatility perfectly well. So "
            f"the shape of this range comes from your holdings and the centre "
            f"of it mostly does not."
        ),
        "on_the_median": (
            f"Half the paths land below the middle line. At ten years that is "
            f"{_money(ten['median'])}, and one in twenty finishes below "
            f"{_money(ten['worst_5'])} — which is the number worth planning "
            f"around rather than the middle one."
        ),
    }




def _describe_loss(losing: int, total: int) -> str:
    """How often the paths ended below what went in.

    "0%" is what the arithmetic gives when none of two thousand paths lost
    money, and it is not what anybody should read. None of two thousand is a
    fact about two thousand samples; a guarantee is what it sounds like, and
    the difference is the whole reason for saying it in words.
    """
    if losing == 0:
        return f"none of the {total:,} paths, which is not the same as never"
    if losing == 1:
        return f"one path in {total:,}"
    share = losing / total * 100
    if share < 1:
        return f"{losing} paths in {total:,}"
    return f"{share:.0f}% of paths"


def _anchor(returns: list[float]) -> tuple[Decimal, Decimal, float]:
    """Pull the observed drift toward a long-run assumption.

    Returns what the history did, what the simulation will assume, and the
    per-day shift that gets from one to the other.

    The weight given to the observation grows with how much history there is.
    At five years it is a quarter, so three quarters of the assumed drift comes
    from the long-run figure -- which is the honest split, because five years
    of daily data cannot distinguish a 12% portfolio from a 20% one.

    The volatility is untouched. That is the part a short window measures well,
    and it is what makes the range a range.
    """
    if not returns:
        return Decimal(0), LONG_RUN_PCT, 0.0

    years = Decimal(len(returns)) / Decimal(YEAR)

    # What the window actually did, geometrically.
    growth = 1.0
    for r in returns:
        growth *= (1 + r)
    observed = Decimal(str((growth ** (1 / float(years)) - 1) * 100)) \
        if years > 0 and growth > 0 else Decimal(0)

    weight = min(Decimal("1"), years / FULL_WEIGHT_YEARS)
    anchored = observed * weight + LONG_RUN_PCT * (1 - weight)

    # The daily shift that turns one into the other.
    observed_daily = float((1 + observed / 100) ** (Decimal(1) / Decimal(YEAR)) - 1)
    anchored_daily = float((1 + anchored / 100) ** (Decimal(1) / Decimal(YEAR)) - 1)

    return observed, anchored, anchored_daily - observed_daily


def _blocks(returns: list[float]) -> list[list[float]]:
    """Every overlapping block of consecutive days.

    Overlapping rather than disjoint, so a two-year history yields hundreds of
    starting points rather than a dozen. The paths are more varied and no
    single stretch dominates.
    """
    if len(returns) <= BLOCK:
        return [returns]
    return [returns[i:i + BLOCK] for i in range(len(returns) - BLOCK)]


def _simulate(start: Decimal, monthly: Decimal, blocks: list[list[float]],
              years: int, rng: random.Random) -> list[Decimal]:
    """Run the portfolio forward, many times.

    Contributions go in monthly rather than annually, because that is how
    somebody actually invests and the difference over ten years is not
    negligible.
    """
    days = years * YEAR
    needed = (days // BLOCK) + 1
    monthly_float = float(monthly)
    contribute_every = YEAR // 12

    ends = []
    for _ in range(PATHS):
        # One path: a string of blocks, walked day by day.
        path: list[float] = []
        for _ in range(needed):
            path.extend(rng.choice(blocks))

        balance = float(start)
        for day in range(days):
            balance *= (1 + path[day])
            if monthly_float and day % contribute_every == 0:
                balance += monthly_float

        ends.append(Decimal(str(max(0.0, balance))))

    return ends


def _reading(results: list[dict], start: Decimal, monthly: Decimal) -> str:
    ten = next(r for r in results if r["years"] == 10)
    five = next(r for r in results if r["years"] == 5)

    opening = (f"Starting from {_money(start)}"
               + (f" and adding {_money(monthly)} a month, " if monthly > 0
                  else ", "))

    return (
        opening +
        f"half the paths put this portfolio above {_money(five['median'])} in "
        f"five years and above {_money(ten['median'])} in ten. The unluckiest "
        f"one in twenty finishes ten years at {_money(ten['worst_5'])}, and "
        f"{ten['chance_of_loss']} end that decade below what went in."
    )
