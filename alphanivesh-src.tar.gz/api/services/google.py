"""Signing in with Google.

The standard server-side flow, which is the one worth using: the browser never
holds a token, the code is exchanged over TLS using a secret only the server
knows, and the response comes straight from Google.

**Why no signature checking on the ID token.** In this flow the token arrives
in the body of a TLS response from Google's own token endpoint, authenticated
with our client secret. Nothing untrusted has touched it, so verifying the
signature would be checking Google's word against Google's key over a channel
we already trust. The check matters in the implicit flow, where the token comes
back through the browser and anybody can put one there — we do not use that
flow for exactly this reason.

**The state parameter is not optional.** Without it, anybody can send somebody
a link that completes a sign-in against an account they control, and from then
on the victim's data goes somewhere they did not choose. It is signed, short
lived, and single use.

**And `email_verified` decides whether an existing account is joined.** Google
will tell you an address is unverified when it is. Treating that as good enough
lets somebody register an address at a provider that does not check, and walk
into an account here.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

log = logging.getLogger("alphanivesh.google")

AUTH = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN = "https://oauth2.googleapis.com/token"

SITE = os.environ.get("SITE_URL", "https://alphanivesh.com")
REDIRECT = f"{SITE}/api/account/google/callback"

# The state has to survive a round trip through Google without us storing it,
# so it is signed with the session secret rather than kept in a table. Five
# minutes is longer than any real sign-in and short enough that a leaked link
# is useless by the time anybody finds it.
STATE_SECONDS = 300


def configured() -> bool:
    return bool(os.environ.get("GOOGLE_CLIENT_ID")
                and os.environ.get("GOOGLE_CLIENT_SECRET"))


def _secret() -> bytes:
    key = (os.environ.get("SESSION_SECRET")
           or os.environ.get("GOOGLE_CLIENT_SECRET") or "")
    return key.encode("utf-8")


def make_state(next_page: str = "/dash.html") -> str:
    """A signed, expiring token that proves the callback belongs to us."""
    payload = f"{int(time.time())}|{secrets.token_urlsafe(12)}|{next_page}"
    signature = hmac.new(_secret(), payload.encode("utf-8"),
                         hashlib.sha256).hexdigest()[:32]
    raw = f"{payload}|{signature}"
    return urllib.parse.quote(raw, safe="")


def read_state(state: str) -> Optional[str]:
    """Check a returned state and give back where the person was going.

    Returns None on anything wrong, and the caller treats that as a failed
    sign-in rather than trying to recover -- a state that does not verify means
    either a bug or an attack, and neither should end in somebody being signed
    in.
    """
    try:
        raw = urllib.parse.unquote(state or "")
        issued, nonce, next_page, signature = raw.split("|", 3)
    except (ValueError, AttributeError):
        return None

    expected = hmac.new(_secret(), f"{issued}|{nonce}|{next_page}".encode("utf-8"),
                        hashlib.sha256).hexdigest()[:32]
    if not hmac.compare_digest(expected, signature):
        log.warning("google callback with a bad state signature")
        return None

    try:
        if time.time() - int(issued) > STATE_SECONDS:
            return None
    except ValueError:
        return None

    # Only ever somewhere on this site. An open redirect turns a sign-in link
    # into a way of sending people anywhere with our name on it.
    if not next_page.startswith("/") or next_page.startswith("//"):
        return "/dash.html"
    return next_page


def start_url(next_page: str = "/dash.html") -> Optional[str]:
    if not configured():
        return None
    params = {
        "client_id": os.environ["GOOGLE_CLIENT_ID"],
        "redirect_uri": REDIRECT,
        "response_type": "code",
        "scope": "openid email profile",
        "state": make_state(next_page),
        # Ask every time rather than silently reusing whatever account the
        # browser last used. Somebody with two Google accounts should get to
        # choose, and on a shared machine the alternative signs them in as
        # whoever was there before.
        "prompt": "select_account",
        "access_type": "online",
    }
    return AUTH + "?" + urllib.parse.urlencode(params)


def exchange(code: str) -> Optional[dict]:
    """Swap the code for the person's details.

    Returns the fields we need or None. Everything here comes from a TLS
    response from Google's token endpoint authenticated with our secret, so it
    is as trustworthy as the connection.
    """
    if not configured():
        return None

    body = urllib.parse.urlencode({
        "code": code,
        "client_id": os.environ["GOOGLE_CLIENT_ID"],
        "client_secret": os.environ["GOOGLE_CLIENT_SECRET"],
        "redirect_uri": REDIRECT,
        "grant_type": "authorization_code",
    }).encode("utf-8")

    request = urllib.request.Request(
        TOKEN, data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST")

    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as err:
        detail = ""
        try:
            detail = err.read().decode("utf-8")[:200]
        except Exception:
            pass
        log.error("google token exchange failed: %s %s", err.code, detail)
        return None
    except Exception as err:                                     # pragma: no cover
        log.error("google token exchange failed: %s", err)
        return None

    id_token = payload.get("id_token")
    if not id_token:
        log.error("google returned no id_token")
        return None

    claims = _claims(id_token)
    if not claims:
        return None

    # The audience must be us. A token minted for a different client is not
    # evidence about anybody signing in here, and accepting one is the
    # confused-deputy problem in its classic form.
    if claims.get("aud") != os.environ["GOOGLE_CLIENT_ID"]:
        log.error("google id_token audience is not this client")
        return None

    if claims.get("iss") not in ("accounts.google.com",
                                 "https://accounts.google.com"):
        log.error("google id_token issuer is wrong: %s", claims.get("iss"))
        return None

    return {
        "subject": claims.get("sub"),
        "email": claims.get("email"),
        "email_verified": bool(claims.get("email_verified")),
        "name": claims.get("name") or claims.get("given_name"),
    }


def _claims(id_token: str) -> Optional[dict]:
    """The middle segment of the JWT.

    Read rather than verified, for the reason in the module docstring: this
    arrived in a TLS response from Google's token endpoint authenticated with
    our client secret, so nothing untrusted has touched it. The audience and
    issuer are still checked above, because those guard against a
    misconfiguration on our side rather than against tampering.
    """
    import base64

    try:
        segment = id_token.split(".")[1]
        segment += "=" * (-len(segment) % 4)
        return json.loads(base64.urlsafe_b64decode(segment).decode("utf-8"))
    except Exception as err:
        log.error("could not read the google id_token: %s", err)
        return None
