"""The exemption that expires every March.

The first ₹1.25 lakh of long-term capital gain each year is not taxed. It does
not carry forward. Somebody sitting on twelve lakh of unrealised long-term gain
who never realises any of it pays 12.5% on the lot eventually — and could have
taken a slice tax-free every year on the way.

The action is unglamorous and worth about fifteen thousand rupees a year: sell
enough to realise ₹1.25 lakh of gain, buy the same thing back, and the cost
base resets higher at no tax. Do it for ten years and the difference is real
money that required no view about markets at all.

**Three things this must say and not skip.**

It costs something. Brokerage, and a day or two out of the market between the
sale and the repurchase — during which the price can move either way. On a
₹1.25 lakh realisation the friction is small against ₹15,625 saved, but it is
not nothing and a platform that omits it is selling rather than advising.

Some funds charge an exit load. Selling a unit and buying it back can trip a
load on schemes that have one, which turns a saving into a cost. We flag it
where we know the scheme and say we cannot check it where we do not.

And it only works with gains to realise. Somebody whose long-term gains are
already under the exemption has nothing to harvest, and telling them otherwise
is noise.

**What this is not.** Not a reason to sell something worth holding, and not a
trading strategy. The holding is repurchased immediately; the only thing that
changes is the cost base and the tax.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.harvest")

# The annual long-term exemption, and the rates either side of the boundary.
LTCG_EXEMPT = Decimal("125000")
LTCG_RATE = Decimal("12.5")
STCG_RATE = Decimal("20")

# How long until a gain is long-term, by what is held.
LONG_TERM_MONTHS = {"equity": 12, "mutual_fund": 12, "etf": 12,
                    "bond": 24, "gsec": 24, "gold": 24, "real_estate": 24,
                    "unlisted": 24}
DEFAULT_LONG_TERM_MONTHS = 24

# Below this the friction outweighs the saving and the advice is noise.
WORTH_DOING = Decimal("5000")

# Buying back within this many days can trip an exit load on funds that have
# one, which turns the saving into a cost.
LOAD_WINDOW_DAYS = 365


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits


def _financial_year_ends() -> date:
    """The 31st of March that matters next.

    The exemption runs on the Indian financial year, so an unused allowance
    dies at the end of March rather than of December -- which is the whole
    reason this becomes urgent in February.
    """
    today = date.today()
    year = today.year if today.month < 4 else today.year + 1
    return date(year, 3, 31)


def _months_left() -> int:
    ends = _financial_year_ends()
    today = date.today()
    return max(0, (ends.year - today.year) * 12 + (ends.month - today.month))


def positions(investor_id: str) -> list[dict]:
    """Every holding with a gain, and which side of the long-term line it sits.

    Lifted out of the dashboard router, where the same arithmetic was buried
    and nothing else could reach it.
    """
    # The earlier of the first snapshot and the first purchase, because either
    # one proves the holding existed by then and neither is reliably older.
    #
    # Both were tried alone and both were wrong. Transactions alone excluded
    # almost everything -- most holdings arrive through statements that list
    # positions without the purchases behind them, so a portfolio with twelve
    # lakh of long-term gain reported nothing to harvest. Snapshots alone broke
    # the opposite case: an investor imported from another product has
    # snapshots dated when we ingested rather than when they bought, and
    # everything read as short-term.
    #
    # Whichever source wins, the date is a floor rather than the truth: somebody
    # may have held it for years before either of us saw it. That makes the
    # holding period conservative, which is the right direction for a tax
    # boundary -- it can only call a long-term holding short, never the
    # reverse, and the cost of that is a missed saving rather than a wrong
    # rate.
    from .rebalance import _sellable

    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.asset_class,
               v.current_value, v.invested_value,
               LEAST(
                 (SELECT min(h.as_of) FROM holding_snapshots h
                  WHERE h.instrument_id = v.instrument_id
                    AND h.investor_id = v.investor_id
                    AND h.as_of > '1990-01-01'),
                 (SELECT min(t.txn_date) FROM canonical_transactions t
                  WHERE t.instrument_id = v.instrument_id
                    AND t.investor_id = v.investor_id
                    AND t.txn_type IN ('purchase', 'sip', 'switch_in'))
               ) AS bought
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0
          AND v.invested_value > 0
        """,
        (investor_id,),
    )

    today = date.today()
    out = []

    for row in rows:
        # The same guard the rebalance list needed. Harvesting means selling
        # and buying back, and neither half is possible with a provident fund
        # or a term policy -- suggesting it would be worse than useless.
        if not _sellable(row):
            continue

        gain = _d(row["current_value"]) - _d(row["invested_value"])
        bought = row["bought"]
        if not bought:
            continue

        months = (today.year - bought.year) * 12 + (today.month - bought.month)
        threshold = LONG_TERM_MONTHS.get(row["asset_class"],
                                         DEFAULT_LONG_TERM_MONTHS)
        long_term = months >= threshold

        out.append({
            "instrument_id": row["instrument_id"],
            "name": row["instrument_name"],
            "asset_class": row["asset_class"],
            "value": _d(row["current_value"]),
            "invested": _d(row["invested_value"]),
            "gain": gain,
            "bought": bought,
            "months_held": months,
            "long_term": long_term,
            "months_to_long_term": max(0, threshold - months),
            "gain_pct": (gain / _d(row["invested_value"]) * 100
                         if _d(row["invested_value"]) > 0 else Decimal(0)),
        })

    return out


def opportunity(investor_id: str) -> Optional[dict]:
    """What could be realised tax-free before the year ends, and from where.

    Returns None where there is nothing worth doing, which is most portfolios
    most of the time: somebody whose long-term gains are already under the
    exemption has nothing to harvest, and saying so is better than manufacturing
    an action.
    """
    held = positions(investor_id)
    if not held:
        return None

    long_gainers = sorted(
        [h for h in held if h["long_term"] and h["gain"] > 0],
        key=lambda h: -h["gain"])

    total_long_gain = sum((h["gain"] for h in long_gainers), Decimal(0))

    if total_long_gain <= 0:
        return None

    # How much of the exemption is available. We cannot see what has already
    # been realised this year -- a sale outside this platform uses the
    # allowance and we would never know -- so the figure is what is available
    # if nothing else has been taken, and it says so.
    available = min(total_long_gain, LTCG_EXEMPT)
    saving = available * LTCG_RATE / 100

    if saving < WORTH_DOING:
        return {
            "worth_doing": False,
            "why": (f"Your long-term gains come to ₹{_money(total_long_gain)}, "
                    f"and realising them would save about ₹{_money(saving)} in "
                    f"tax. That is not enough to be worth the brokerage and the "
                    f"days out of the market."),
            "available_gain": str(available.quantize(Decimal("1"))),
            "saving": str(saving.quantize(Decimal("1"))),
        }

    # Which holdings to take it from. Largest gain first, because fewer sales
    # means less friction -- and taking a slice of one holding is simpler to
    # execute than slices of four.
    plan = []
    remaining = available

    for holding in long_gainers:
        if remaining <= 0:
            break
        take = min(holding["gain"], remaining)
        # What has to be sold to realise that much gain, at today's price.
        fraction = take / holding["gain"] if holding["gain"] > 0 else Decimal(0)
        sell_value = holding["value"] * fraction

        plan.append({
            "name": holding["name"],
            "asset_class": holding["asset_class"],
            "sell_value": str(sell_value.quantize(Decimal("1"))),
            "realises_gain": str(take.quantize(Decimal("1"))),
            "of_holding_pct": str((fraction * 100).quantize(Decimal("0.1"))),
            "held_months": holding["months_held"],
            "exit_load_risk": _load_risk(holding),
        })
        remaining -= take

    months_left = _months_left()

    return {
        "worth_doing": True,
        "available_gain": str(available.quantize(Decimal("1"))),
        "saving": str(saving.quantize(Decimal("1"))),
        "total_long_gain": str(total_long_gain.quantize(Decimal("1"))),
        "exemption": str(LTCG_EXEMPT),
        "plan": plan,
        "months_left": months_left,
        "year_ends": _financial_year_ends().isoformat(),
        "urgency": ("soon" if months_left <= 2 else
                    "this year" if months_left <= 5 else "no rush"),
        "reading": _reading(available, saving, plan, months_left),
        "costs": _costs(plan),
        "caveat": (
            "This assumes you have not already realised long-term gains this "
            "financial year. A sale made anywhere else uses the same "
            "allowance and we cannot see it — if you have sold something at a "
            "profit since April, subtract that gain from the figure above."
        ),
    }


def _load_risk(holding: dict) -> Optional[str]:
    """Whether buying back could trip an exit load.

    We do not hold each scheme's load structure, so this says what to check
    rather than pretending to know. A fund with a one per cent load on
    redemption inside a year turns a fifteen thousand rupee saving into a
    twelve hundred rupee cost on a one-lakh sale, and somebody should look
    before acting.
    """
    if holding["asset_class"] != "mutual_fund":
        return None
    return ("Check this scheme's exit load before selling. Most equity funds "
            "charge nothing after a year and some charge on any redemption — "
            "we do not hold each scheme's terms, so this is worth thirty "
            "seconds on the fund page.")


def _reading(available: Decimal, saving: Decimal, plan: list[dict],
             months_left: int) -> str:
    where = plan[0]["name"] if plan else "your holdings"
    when = ("before the end of March" if months_left <= 2 else
            f"in the {months_left} months before the year ends")

    return (
        f"₹{_money(available)} of long-term gain can be realised tax-free {when}, "
        f"saving about ₹{_money(saving)}. Sell roughly "
        f"₹{_money(plan[0]['sell_value'])} of {where} and buy it straight back: "
        f"the holding is unchanged and the cost base resets higher, so the gain "
        f"you have already made stops being taxable later."
        if plan else
        f"₹{_money(available)} of long-term gain can be realised tax-free {when}."
    )


def _costs(plan: list[dict]) -> str:
    sales = len(plan)
    return (
        f"Brokerage on {sales} sale{'s' if sales != 1 else ''} and the same "
        f"again buying back, plus a day or two out of the market while it "
        f"settles — during which the price can move either way. Small against "
        f"the saving, and not nothing."
    )


def losses(investor_id: str) -> Optional[dict]:
    """Holdings under water, and what realising them would offset.

    The other half of harvesting, and the one people find harder: selling
    something at a loss feels like admitting a mistake. It is not — the loss
    already happened, and realising it is the only way to get anything back
    from it.

    Only worth raising where there are gains to offset. A realised loss with
    nothing to set it against carries forward, which is worth something, but
    much less than the immediate version and not enough to prompt a sale.
    """
    held = positions(investor_id)
    down = sorted([h for h in held if h["gain"] < 0], key=lambda h: h["gain"])
    if not down:
        return None

    gains = sum((h["gain"] for h in held if h["gain"] > 0), Decimal(0))
    if gains <= 0:
        return None

    total_loss = sum((abs(h["gain"]) for h in down), Decimal(0))
    offsettable = min(total_loss, gains)
    saving = offsettable * LTCG_RATE / 100

    if saving < WORTH_DOING:
        return None

    return {
        "total_loss": str(total_loss.quantize(Decimal("1"))),
        "offsettable": str(offsettable.quantize(Decimal("1"))),
        "saving": str(saving.quantize(Decimal("1"))),
        "holdings": [{
            "name": h["name"],
            "value": str(h["value"].quantize(Decimal("1"))),
            "loss": str(abs(h["gain"]).quantize(Decimal("1"))),
            "down_pct": str(abs(h["gain_pct"]).quantize(Decimal("0.1"))),
        } for h in down[:4]],
        "reading": (
            f"₹{_money(total_loss)} of unrealised loss sits across "
            f"{len(down)} holding{'s' if len(down) != 1 else ''}. Realising it "
            f"would offset the same amount of gain elsewhere, saving about "
            f"₹{_money(saving)}."
        ),
        "caveat": (
            "Only worth doing on something you were going to sell anyway, or "
            "would repurchase. Selling a holding you still believe in to save "
            "tax is letting the tax decide the portfolio, which is the wrong "
            "way round."
        ),
    }
