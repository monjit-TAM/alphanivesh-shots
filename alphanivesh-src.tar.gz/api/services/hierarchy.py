"""What to do first, and why that first.

The order is the engine. Not a ranking of good ideas but a sequence of
questions, each of which has to be answered before the next one means
anything:

    PROTECT   is there anything that could undo all of this?
    FIX       is anything actively costing money or taking risk nobody chose?
    OPTIMISE  is the shape right?
    INVEST    is enough going in, and into the right things?
    REVIEW    when should somebody look at this again?

An investor with no emergency fund and a 63% sector concentration has two
problems, and the sector is the more interesting one to write about. It is
also the wrong one to lead with: a job loss forces a sale at whatever the
market is offering, and the sector weighting stops mattering the moment that
happens.

So the hierarchy is not a presentation choice. It is the claim that some
problems make others irrelevant, and that a tool which sorts by size rather
than by dependency gives confident advice in the wrong order.

**"Do nothing" is a real answer.** A portfolio can be in good order, and a
system that always finds five things to do is a system that has stopped
distinguishing between finding something and having something to say.

**And a recommendation that fails its guardrails is not made.** Not made and
flagged, rather than made with a warning attached: an action that breaches
somebody's liquidity needs or concentrates them further is not improved by
mentioning that it does.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from decimal import Decimal
from enum import IntEnum
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.hierarchy")


class Tier(IntEnum):
    """The order, and why each comes before the next.

    An integer so it sorts, but the names are what matter: a reader should be
    able to see that PROTECT outranks OPTIMISE without being told the numbers.
    """
    PROTECT = 1     # something could undo all of it
    FIX = 2         # something is costing money or taking unchosen risk
    OPTIMISE = 3    # the shape is wrong
    INVEST = 4      # not enough is going in, or into the wrong things
    REVIEW = 5      # nothing to do now; here is when to look again


TIER_NAMES = {
    Tier.PROTECT: "Protect what you have",
    Tier.FIX: "Fix what is leaking",
    Tier.OPTIMISE: "Get the shape right",
    Tier.INVEST: "Put money to work",
    Tier.REVIEW: "Nothing to do now",
}

TIER_WHY = {
    Tier.PROTECT: ("These come first because they can undo everything else. A "
                   "portfolio arranged perfectly is worth nothing to somebody "
                   "forced to sell it at the wrong moment."),
    Tier.FIX: ("Money leaving for no return, or risk nobody chose to take. "
               "These cost something every day they are left alone."),
    Tier.OPTIMISE: ("The holdings are sound and the arrangement is not. Worth "
                    "doing, and worth doing after the two above."),
    Tier.INVEST: ("What to do with money that is not yet invested, or is going "
                  "somewhere it should not."),
    Tier.REVIEW: ("Nothing here needs acting on. That is a finding rather than "
                  "an absence of one."),
}


@dataclass
class Action:
    """One thing to do, with everything needed to decide whether to do it.

    The five questions the spec asks of every recommendation -- what, why, how,
    impact, risk -- are fields rather than prose, so a reader can drill into any
    one of them and a reviewer can check none is missing.
    """
    tier: Tier
    what: str
    why: str
    how: Optional[str] = None
    impact: Optional[str] = None
    risk: Optional[str] = None

    # What it costs to act, in money and in effort.
    costs: Optional[str] = None
    worth: Optional[str] = None

    # Where the numbers behind it came from, so somebody can check.
    evidence: dict = field(default_factory=dict)
    source: Optional[str] = None

    # How sure we are, and why not more.
    confidence: str = "firm"
    confidence_why: Optional[str] = None

    # Which guardrails were checked and what they said.
    guardrails: list = field(default_factory=list)

    code: Optional[str] = None

    def as_dict(self) -> dict:
        return {
            "tier": int(self.tier),
            "tier_name": TIER_NAMES[self.tier],
            "what": self.what,
            "why": self.why,
            "how": self.how,
            "impact": self.impact,
            "risk": self.risk,
            "costs": self.costs,
            "worth": self.worth,
            "evidence": self.evidence,
            "source": self.source,
            "confidence": self.confidence,
            "confidence_why": self.confidence_why,
            "guardrails": self.guardrails,
            "code": self.code,
        }


# ---------------------------------------------------------------------------
# Guardrails
# ---------------------------------------------------------------------------

@dataclass
class Guardrail:
    """A rule an action has to survive.

    Checked before an action is offered rather than mentioned alongside it. An
    action that would breach somebody's liquidity needs is not improved by
    saying so; it is simply not the action to recommend.
    """
    name: str
    holds: bool
    detail: str


def check(action: Action, investor: dict) -> tuple[bool, list[Guardrail]]:
    """Whether this action can be offered to this person.

    Returns the verdict and every rail that was checked -- including the ones
    that passed, because an audit trail showing only failures cannot be
    distinguished from one that checked nothing.
    """
    rails: list[Guardrail] = []

    # Liquidity: nothing that would leave somebody unable to meet a known need.
    months = investor.get("emergency_fund_months")
    if months is not None and action.tier > Tier.PROTECT:
        thin = _d(months) < 3
        rails.append(Guardrail(
            "liquidity",
            not (thin and action.code in ("rebalance", "increase_sip", "lock_in")),
            f"{months} months of expenses set aside."
            + (" Actions that reduce available cash are held back until that is "
               "closer to six." if thin else "")))

    # Concentration: nothing that makes an existing concentration worse.
    if action.evidence.get("increases_concentration"):
        rails.append(Guardrail(
            "concentration", False,
            "This would add to a position that is already the largest thing in "
            "the portfolio."))
    else:
        rails.append(Guardrail("concentration", True,
                               "Does not deepen an existing concentration."))

    # Suitability: nothing above the risk this person can carry, which is the
    # lower of what they can afford and what they can sit through.
    #
    # `risk_level` means the risk this action would INTRODUCE, not the risk
    # already present. An action that describes a risky situation and proposes
    # reducing it should carry no risk_level at all -- tagging one made the
    # rail withhold the very action that fixed the problem, which is the
    # guardrail working correctly on a wrong input and the hardest kind of bug
    # to see.
    ceiling = investor.get("risk_ceiling")
    proposed = action.evidence.get("risk_level")
    if ceiling is not None and proposed is not None:
        rails.append(Guardrail(
            "suitability", proposed <= ceiling,
            f"Risk level {proposed} against a ceiling of {ceiling}, which is the "
            f"lower of what this portfolio can afford and what its holder has "
            f"shown they can sit through."))

    # Nothing recommended on recent performance alone.
    basis = action.evidence.get("basis")
    if basis:
        rails.append(Guardrail(
            "not_performance_chasing", basis != "recent_returns",
            f"Recommended on {basis.replace('_', ' ')} rather than on what has "
            f"gone up lately."))

    return all(rail.holds for rail in rails), rails


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


# ---------------------------------------------------------------------------
# Assembling the sequence
# ---------------------------------------------------------------------------

def order(actions: list[Action], investor: dict) -> dict:
    """Everything worth doing, in the order it is worth doing it.

    Guardrails run first, so an action that cannot be offered never appears in
    the sequence at all. What it does appear in is the audit trail, because
    "we considered this and here is why we did not suggest it" is a more
    useful record than silence.
    """
    offered: list[Action] = []
    withheld: list[dict] = []

    for action in actions:
        passes, rails = check(action, investor)
        action.guardrails = [
            {"name": r.name, "holds": r.holds, "detail": r.detail} for r in rails
        ]
        if passes:
            offered.append(action)
        else:
            withheld.append({
                "what": action.what,
                "tier": int(action.tier),
                "why_not": [r.detail for r in rails if not r.holds],
            })

    offered.sort(key=lambda a: (a.tier, -_weight(a)))

    tiers: dict[int, list[dict]] = {}
    for action in offered:
        tiers.setdefault(int(action.tier), []).append(action.as_dict())

    return {
        "actions": [a.as_dict() for a in offered],
        "by_tier": [
            {"tier": tier,
             "name": TIER_NAMES[Tier(tier)],
             "why_this_tier": TIER_WHY[Tier(tier)],
             "actions": items}
            for tier, items in sorted(tiers.items())
        ],
        "first": offered[0].as_dict() if offered else None,
        "withheld": withheld,
        "reading": _reading(offered, withheld),
    }


def _weight(action: Action) -> float:
    """Within a tier, what is worth more comes first.

    Only within a tier. A large optimisation never outranks a small protection,
    because the whole point of the hierarchy is that the tiers are not
    comparable.
    """
    for key in ("annual_saving", "at_risk", "shortfall", "over_twenty_years"):
        value = action.evidence.get(key)
        if value:
            try:
                return float(_d(value))
            except Exception:
                continue
    return 0.0


def _reading(offered: list[Action], withheld: list[dict]) -> str:
    """What the sequence amounts to, in a sentence."""
    if not offered:
        return ("Nothing here needs acting on. That is worth saying plainly: a "
                "portfolio in good order is a result, not an absence of "
                "findings.")

    first = offered[0]
    protect = [a for a in offered if a.tier == Tier.PROTECT]

    if protect:
        return (f"{len(offered)} thing{'s' if len(offered) != 1 else ''} worth "
                f"doing, and the first is not about the portfolio at all: "
                f"{first.what[0].lower()}{first.what[1:]} "
                f"Everything else waits on it.")

    return (f"{len(offered)} thing{'s' if len(offered) != 1 else ''} worth "
            f"doing, starting with: {first.what[0].lower()}{first.what[1:]}"
            + (f" {len(withheld)} other{'s' if len(withheld) != 1 else ''} "
               f"considered and not suggested."
               if withheld else ""))
