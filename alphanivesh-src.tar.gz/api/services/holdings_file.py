"""Reading a holdings file, whoever produced it.

Four things are needed to record a position: what it is, how much of it, what
was paid, and when. Every broker's export carries those, and every broker names
the columns differently -- "Symbol", "Scrip", "Instrument", "Trading Symbol"
all mean the same thing, and none of them is more correct than the others.

So this does not parse formats. It recognises columns. A file is accepted if
its header row contains something we can read as each of the four, wherever
that row happens to be and whatever the sheet is called.

What it will not do is guess. A file whose columns cannot be identified is
rejected with a list of what was found and what was needed, because a wrong
column silently mapped is a portfolio full of wrong numbers.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Optional

# What each field can be called. Matched against a flattened form of the header,
# so "Buy Price" and "buy_price" and "BUY PRICE (Rs.)" all land in the same
# place. Ordered roughly by how unambiguous each name is.
COLUMN_SYNONYMS: dict[str, tuple[str, ...]] = {
    "identifier": (
        "stock name", "stockname", "symbol", "scrip", "scrip name", "scrip code",
        "instrument", "trading symbol", "tradingsymbol", "security name",
        "security", "company name", "company", "share name", "name", "isin",
        "isin code", "nse symbol", "bse code", "ticker",
    ),
    "quantity": (
        "quantity", "qty", "units", "no of shares", "number of shares", "shares",
        "holding qty", "holding quantity", "free qty", "total qty", "balance",
        "closing balance", "net qty", "net quantity",
    ),
    "price": (
        "buy price", "buyprice", "purchase price", "avg price", "average price",
        "avg cost", "average cost", "cost per share", "rate", "buy rate",
        "purchase rate", "acquisition price", "avg buy price", "price",
    ),
    "when": (
        "buy date", "buydate", "purchase date", "date of purchase", "trade date",
        "transaction date", "acquisition date", "date",
    ),
}

# An ISIN is unmistakable, which is why it is worth recognising on sight: a
# file whose identifier column holds ISINs needs no name matching at all.
ISIN_PATTERN = re.compile(r"^IN[A-Z0-9]{10}$", re.I)

DATE_FORMATS = (
    "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y", "%d-%b-%Y", "%d %b %Y",
    "%Y/%m/%d", "%d.%m.%Y", "%d-%b-%y", "%b %d, %Y",
)

# A header row is one where enough columns are recognisable. Two is the floor:
# an identifier and a quantity are the minimum that describes a holding, and
# anything less would match a stray row of text.
MIN_RECOGNISED = 2

# How far into a file to look for the header. Brokers put account details,
# addresses and disclaimers above the table; twenty rows covers every sample
# seen and stops us reading an entire spreadsheet looking for one.
HEADER_SEARCH_ROWS = 20


@dataclass
class ParsedRow:
    identifier: str
    quantity: Optional[Decimal] = None
    price: Optional[Decimal] = None
    when: Optional[date] = None
    is_isin: bool = False
    raw: dict = field(default_factory=dict)


@dataclass
class ParseResult:
    rows: list[ParsedRow] = field(default_factory=list)
    columns_found: dict[str, str] = field(default_factory=dict)
    header_row: int = 0
    skipped: list[str] = field(default_factory=list)
    sheet: Optional[str] = None

    @property
    def ok(self) -> bool:
        return bool(self.rows)


class FileUnreadable(Exception):
    """The file could not be understood, with a reason worth showing."""


# ---------------------------------------------------------------------------
# Recognising columns
# ---------------------------------------------------------------------------


def _flatten(header: Any) -> str:
    """A header cell reduced to something comparable.

    Brokers decorate headers -- "Buy Price (Rs.)", "Qty.", "ISIN Code" -- and
    the decoration is never the meaning.
    """
    text = str(header or "").strip().lower()
    text = re.sub(r"\([^)]*\)", " ", text)      # drop units and notes
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return text.strip()


def identify_columns(header: list[Any]) -> dict[str, int]:
    """Which column holds which of the four things.

    Exact matches win over partial ones, so a file with both "Price" and "Buy
    Price" uses the latter. Each field claims at most one column, and a column
    is claimed by at most one field.
    """
    flattened = [_flatten(cell) for cell in header]
    found: dict[str, int] = {}
    taken: set[int] = set()

    for field_name, synonyms in COLUMN_SYNONYMS.items():
        best_index: Optional[int] = None
        best_rank = len(synonyms) + 1

        for index, cell in enumerate(flattened):
            if not cell or index in taken:
                continue
            for rank, synonym in enumerate(synonyms):
                if cell == synonym:
                    if rank < best_rank:
                        best_index, best_rank = index, rank
                    break
                # A partial match ranks behind every exact one, so it only wins
                # when nothing matched exactly. Both sides must be substantial:
                # without a length floor a header of "b" matches "balance", and
                # a file of arbitrary letters parses as a holdings table.
                if len(cell) >= 3 and len(synonym) >= 3 and (
                        synonym in cell or cell in synonym):
                    partial_rank = len(synonyms) + rank
                    if partial_rank < best_rank:
                        best_index, best_rank = index, partial_rank

        if best_index is not None:
            found[field_name] = best_index
            taken.add(best_index)

    return found


def find_header(rows: list[list[Any]]) -> tuple[int, dict[str, int]]:
    """Where the table starts.

    Not always the first row: brokers put a name, an address and a period above
    it. The header is the first row within reach where enough columns can be
    read, which also rejects a file that is not a holdings table at all.
    """
    best: tuple[int, dict[str, int]] = (-1, {})

    for index, row in enumerate(rows[:HEADER_SEARCH_ROWS]):
        if not any(str(cell).strip() for cell in row):
            continue
        columns = identify_columns(row)
        if len(columns) > len(best[1]):
            best = (index, columns)
        # An identifier plus two others is a table, not a coincidence.
        if len(columns) >= 3 and "identifier" in columns:
            return index, columns

    if len(best[1]) >= MIN_RECOGNISED and "identifier" in best[1]:
        return best

    found = ", ".join(sorted({_flatten(c) for r in rows[:5] for c in r if str(c).strip()}))[:200]
    raise FileUnreadable(
        "We could not find the holdings in that file. We look for a column naming "
        "the share, and columns for quantity, price and date. "
        + (f"What we found instead: {found}." if found else "")
    )


# ---------------------------------------------------------------------------
# Reading values
# ---------------------------------------------------------------------------


def _number(value: Any) -> Optional[Decimal]:
    if value in (None, ""):
        return None
    text = str(value).strip()
    if not text or text in ("-", "--", "NA", "N.A.", "nil"):
        return None
    # Indian files carry grouped numbers, currency marks, and occasionally a
    # trailing "Cr" or "Dr" from a ledger export.
    text = re.sub(r"[₹$,\s]", "", text)
    text = re.sub(r"(?i)\b(cr|dr)\b$", "", text).strip()
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        return Decimal(text)
    except (InvalidOperation, ValueError):
        return None


def _date(value: Any) -> Optional[date]:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# Reading a file
# ---------------------------------------------------------------------------


def _rows_from_csv(content: bytes) -> list[list[Any]]:
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            text = content.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise FileUnreadable("We could not read the characters in that file.")

    # Sniff the delimiter: exports use commas, semicolons and tabs about
    # equally, and guessing wrong turns the whole file into one column.
    sample = text[:4000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel

    return [row for row in csv.reader(io.StringIO(text), dialect)]


def _rows_from_excel(content: bytes) -> tuple[list[list[Any]], Optional[str]]:
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise FileUnreadable("Spreadsheet files are not supported on this server yet. "
                             "Saving it as CSV will work.")

    try:
        workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    except Exception:
        raise FileUnreadable("That does not look like a spreadsheet we can open.")

    # Holdings are not always on the first sheet. Take whichever sheet has a
    # header we recognise, rather than assuming.
    best: tuple[int, list[list[Any]], Optional[str]] = (0, [], None)
    for sheet in workbook.worksheets:
        rows = [list(r) for r in sheet.iter_rows(max_row=200, values_only=True)]
        if not rows:
            continue
        try:
            _, columns = find_header(rows)
        except FileUnreadable:
            continue
        if len(columns) > best[0]:
            best = (len(columns), rows, sheet.title)

    if not best[1]:
        raise FileUnreadable("We could not find a holdings table on any sheet in that file.")
    return best[1], best[2]


def parse(content: bytes, filename: str = "") -> ParseResult:
    """Read a holdings file into rows we can work with."""
    if not content:
        raise FileUnreadable("That file was empty.")

    lower = (filename or "").lower()
    sheet = None
    if lower.endswith((".xlsx", ".xlsm", ".xls")):
        rows, sheet = _rows_from_excel(content)
    else:
        rows = _rows_from_csv(content)

    if not rows:
        raise FileUnreadable("There was nothing in that file.")

    header_index, columns = find_header(rows)
    header = rows[header_index]

    result = ParseResult(
        columns_found={k: str(header[i]).strip() for k, i in columns.items()},
        header_row=header_index + 1,
        sheet=sheet,
    )

    for line_number, row in enumerate(rows[header_index + 1:], start=header_index + 2):
        if not any(str(cell).strip() for cell in row):
            continue

        def cell(field_name: str) -> Any:
            index = columns.get(field_name)
            return row[index] if index is not None and index < len(row) else None

        identifier = str(cell("identifier") or "").strip()
        if not identifier:
            continue

        # Totals rows are common at the bottom of an export and are not
        # holdings. They give themselves away.
        if re.match(r"(?i)^(total|grand total|sum|subtotal)\b", identifier):
            continue

        quantity = _number(cell("quantity"))
        if quantity is not None and quantity <= 0:
            result.skipped.append(f"line {line_number}: {identifier[:32]} has no quantity")
            continue

        result.rows.append(ParsedRow(
            identifier=identifier,
            quantity=quantity,
            price=_number(cell("price")),
            when=_date(cell("when")),
            is_isin=bool(ISIN_PATTERN.match(identifier)),
            raw={k: row[i] for k, i in columns.items() if i < len(row)},
        ))

    if not result.rows:
        raise FileUnreadable(
            "We recognised the columns but found no holdings underneath them."
        )

    return result
