"""Saying the same thing in ten languages.

The homepage has promised five languages since the first week and the product
has spoken one. This is the mechanism that closes that, and there are two
honest constraints on it worth stating before any of the strings.

**The prose is generated, not written.** Almost every sentence a reader sees is
composed at runtime with figures woven through it -- "₹72,465 of this would go
if Franklin India Focused Equity repeated its worst fall". Translating that
means a keyed template per sentence with the numbers as placeholders, and the
placeholders have to move, because Hindi puts the verb last and Tamil declines
the noun. A translation layer that only swaps words produces sentences that
parse and do not read.

**And a wrong translation is worse than English.** Somebody reading "capital
gains tax" in their own language and understanding it as something else acts on
the misunderstanding. Every language here is marked unreviewed until a native
speaker who knows the financial vocabulary has been through it, and the
interface says which are which rather than presenting all ten as equal.

So: the chrome is translated now, the generated prose follows, and nothing
claims to be finished that is not.
"""

from __future__ import annotations

import json
import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("alphanivesh.i18n")

CATALOGUE_DIR = Path(os.environ.get(
    "ALPHANIVESH_LOCALES", "/opt/alphawealth/locales"))

DEFAULT = "en"

# The ten, with the name each is called in itself. A language picker that lists
# "Bengali" rather than "বাংলা" is asking somebody to find their own language
# in a foreign one.
LANGUAGES = {
    "en": {"name": "English", "own_name": "English", "reviewed": True},
    "hi": {"name": "Hindi", "own_name": "हिन्दी", "reviewed": False},
    "bn": {"name": "Bengali", "own_name": "বাংলা", "reviewed": False},
    "mr": {"name": "Marathi", "own_name": "मराठी", "reviewed": False},
    "te": {"name": "Telugu", "own_name": "తెలుగు", "reviewed": False},
    "ta": {"name": "Tamil", "own_name": "தமிழ்", "reviewed": False},
    "gu": {"name": "Gujarati", "own_name": "ગુજરાતી", "reviewed": False},
    "ml": {"name": "Malayalam", "own_name": "മലയാളം", "reviewed": False},
    "pa": {"name": "Punjabi", "own_name": "ਪੰਜਾਬੀ", "reviewed": False},
    "as": {"name": "Assamese", "own_name": "অসমীয়া", "reviewed": False},
    "or": {"name": "Odia", "own_name": "ଓଡ଼ିଆ", "reviewed": False},
}


@lru_cache(maxsize=16)
def catalogue(language: str) -> dict[str, str]:
    """Every string we hold in one language.

    Cached per process. A catalogue changes when somebody edits a file, which
    is a deploy rather than something that happens under a running request.
    """
    if language not in LANGUAGES:
        return {}
    path = CATALOGUE_DIR / f"{language}.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as err:
        log.warning("could not read the %s catalogue: %s", language, err)
        return {}


def t(key: str, language: str = DEFAULT, **values: Any) -> str:
    """A string in the language asked for, falling back to English.

    Falls back rather than failing. A missing translation should leave somebody
    reading English, which they may not want but can act on -- not an empty
    space or a raw key, which they cannot.

    Placeholders are named rather than positional, because word order moves
    between these languages and a template that assumes English order produces
    sentences that parse and do not read.
    """
    text = catalogue(language).get(key)
    if text is None and language != DEFAULT:
        text = catalogue(DEFAULT).get(key)
    if text is None:
        # The key itself, which is at least searchable, rather than nothing.
        log.debug("no string for %s", key)
        return key

    if not values:
        return text
    try:
        return text.format(**values)
    except (KeyError, IndexError, ValueError) as err:
        # A template expecting a value it was not given is a fault in the
        # translation, and showing the English is better than showing a
        # traceback or a half-formatted sentence.
        log.warning("could not fill %s in %s: %s", key, language, err)
        english = catalogue(DEFAULT).get(key, key)
        try:
            return english.format(**values)
        except Exception:
            return english


def available() -> list[dict]:
    """The languages, with how complete and how trustworthy each is.

    Completeness is counted rather than claimed, and review status is carried
    beside it: a catalogue can be a hundred per cent translated and entirely
    unchecked, and those are different things a reader deserves to tell apart.
    """
    english = catalogue(DEFAULT)
    total = len(english) or 1

    out = []
    for code, spec in LANGUAGES.items():
        strings = catalogue(code)
        done = sum(1 for k in english if strings.get(k))
        out.append({
            "code": code,
            "name": spec["name"],
            "own_name": spec["own_name"],
            "reviewed": spec["reviewed"],
            "translated_pct": round(done / total * 100),
            "strings": done,
            "of": total,
        })
    return out


def resolve(header: Optional[str], asked: Optional[str] = None) -> str:
    """Which language to use for a request.

    What somebody chose wins over what their browser prefers, because the
    choice is deliberate and the header is a default somebody else set.
    """
    if asked and asked in LANGUAGES:
        return asked
    if not header:
        return DEFAULT
    for part in header.split(","):
        code = part.split(";")[0].strip().lower()[:2]
        if code in LANGUAGES:
            return code
    return DEFAULT


def forget() -> None:
    """Drop the cached catalogues, after they are edited."""
    catalogue.cache_clear()


# ---------------------------------------------------------------------------
# The language of the request in hand
# ---------------------------------------------------------------------------

# Threaded through a context variable rather than passed down every call.
#
# The alternative is a `language` parameter on every function that produces a
# sentence, and then on every function that calls one, which is most of the
# service. That churn buys nothing: the language is a property of the request,
# not of the calculation, and a findings engine that has to be told what
# language to think in has the wrong shape.
#
# Context variables carry correctly across async boundaries, which a module
# global would not: two requests in different languages arriving together would
# otherwise read each other's setting.

import contextvars

_current: contextvars.ContextVar[str] = contextvars.ContextVar(
    "alphanivesh_language", default=DEFAULT)


def use(language: str) -> None:
    """Set the language for this request."""
    _current.set(language if language in LANGUAGES else DEFAULT)


def current() -> str:
    """The language of the request in hand."""
    return _current.get()


def say(key: str, **values: Any) -> str:
    """A sentence in whatever language this request is in.

    What the services call. `t()` takes the language explicitly and is what
    anything outside a request should use; this is the convenience for the
    common case, where the answer is "the one the reader asked for".
    """
    return t(key, current(), **values)
