"""Working out which security somebody means.

A holding arrives identified by whatever its source carried. A CAS statement
gives an ISIN. A broker's spreadsheet gives a trading symbol. A contract note
might give either. Somebody typing gives a name.

Each of those resolves, and each resolves wrongly under the right conditions:

  A symbol is unique on an exchange today and reassigned over time. PVR became
  PVRINOX; KALPATPOWR became KPIL. A file exported two years ago carries the
  old string.

  A name is never authoritative. "Tata Motors" matched Tata Motors Passenger
  Vehicles here, not because anyone meant the spin-off but because the parent
  was absent from the list.

  An ISIN is the reliable one. Issued once per security, never reused.

So identifiers are tried in order of trust, and -- the part that matters -- when
two of them disagree, this refuses rather than picking. A resolver that picks
is a resolver that quietly attaches somebody's money to a different company,
and nobody checks a forty-row import.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.identity")

ISIN_PATTERN = re.compile(r"^IN[A-Z0-9]{10}$", re.I)

# How much each identifier is worth when two of them point different ways.
TRUST = {"isin": 4, "token": 3, "nse_symbol": 2, "bse_code": 2, "name": 1}


def _flatten(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (text or "").lower().replace("&", " and ")).strip()


@dataclass
class Resolution:
    """What we concluded, and how sure we are."""
    status: str                      # resolved | conflicted | ambiguous | unknown
    identity: Optional[dict] = None
    by: Optional[str] = None         # which identifier settled it
    candidates: Optional[list] = None
    why: Optional[str] = None
    conflict: Optional[dict] = None

    def as_dict(self) -> dict:
        out = {"status": self.status}
        for key in ("identity", "by", "candidates", "why", "conflict"):
            value = getattr(self, key)
            if value is not None:
                out[key] = value
        return out


def _by_isin(isin: str) -> Optional[dict]:
    return db.fetch_one(
        "SELECT * FROM instrument_identity WHERE isin = %s AND is_active LIMIT 1",
        (isin.upper(),),
    )


def _by_token(token: int) -> Optional[dict]:
    return db.fetch_one(
        "SELECT * FROM instrument_identity WHERE token = %s AND is_active LIMIT 1",
        (token,),
    )


def _by_symbol(symbol: str) -> list[dict]:
    """Every active row claiming this symbol, on either exchange.

    More than one is possible and is not a bug: the same string can be a
    different company on NSE and BSE.
    """
    return db.fetch_all(
        """
        SELECT * FROM instrument_identity
        WHERE is_active AND (upper(nse_symbol) = %s OR upper(bse_code) = %s)
        """,
        (symbol.upper(), symbol.upper()),
    )


def _by_name(name: str, limit: int = 5) -> list[dict]:
    """Companies whose name resembles what was written.

    Matched against the company name alone, not the search string. The search
    string also carries the ticker so that typing "INFY" finds Infosys, but
    that makes an exact-name comparison impossible: "thermax limited" is never
    equal to "thermax limited thermax", so every exact name came back
    ambiguous.
    """
    flat = _flatten(name)
    if len(flat) < 3:
        return []
    return db.fetch_all(
        """
        SELECT *, lower(regexp_replace(company_name, '[^a-zA-Z0-9]+', ' ', 'g')) AS name_flat,
               similarity(search_text, %s) AS score
        FROM instrument_identity
        WHERE is_active
          AND (search_text %% %s
               OR lower(regexp_replace(company_name, '[^a-zA-Z0-9]+', ' ', 'g')) LIKE %s || '%%')
        ORDER BY (trim(lower(regexp_replace(company_name, '[^a-zA-Z0-9]+', ' ', 'g'))) = %s) DESC,
                 (trim(lower(regexp_replace(company_name, '[^a-zA-Z0-9]+', ' ', 'g'))) LIKE %s || '%%') DESC,
                 length(company_name),
                 similarity(search_text, %s) DESC
        LIMIT %s
        """,
        (flat, flat, flat, flat, flat, flat, limit),
    )


def record_conflict(kind: str, identifier: str, claims: list[dict]) -> None:
    """Note that two sources disagree, once.

    Written rather than raised because a conflict is a thing to look at later,
    not an error in the moment. The resolver refuses regardless.
    """
    existing = db.fetch_one(
        """
        SELECT id FROM identity_conflicts
        WHERE identifier_kind = %s AND identifier = %s AND resolved_at IS NULL
        LIMIT 1
        """,
        (kind, identifier),
    )
    if existing:
        return
    db.fetch_one(
        """
        INSERT INTO identity_conflicts (identifier_kind, identifier, claims)
        VALUES (%s, %s, %s) RETURNING id
        """,
        (kind, identifier, json.dumps(claims, default=str)),
    )
    log.warning("identity conflict on %s %s: %s", kind, identifier,
                [c.get("company_name") for c in claims])


def resolve(*, isin: Optional[str] = None, token: Optional[int] = None,
            symbol: Optional[str] = None, name: Optional[str] = None) -> Resolution:
    """Which security this is, given whatever the source carried.

    Pass everything available. The more identifiers given, the more this can
    check them against each other -- and disagreement between two of them is
    more informative than either alone.
    """
    found: dict[str, dict] = {}

    if isin and ISIN_PATTERN.match(isin.strip()):
        row = _by_isin(isin.strip())
        if row:
            found["isin"] = row

    if token:
        row = _by_token(int(token))
        if row:
            found["token"] = row

    if symbol and symbol.strip():
        rows = _by_symbol(symbol.strip())
        if len(rows) == 1:
            found["nse_symbol"] = rows[0]
        elif len(rows) > 1:
            # The same string on two exchanges meaning two companies. Not a
            # conflict between sources -- a genuine ambiguity in the symbol.
            if not found:
                return Resolution(
                    status="ambiguous",
                    candidates=[_public(r) for r in rows],
                    why=f"{symbol.strip().upper()} names more than one company",
                )

    # Where two identifiers were both found, they must agree. This is the whole
    # point: an ISIN saying one company and a symbol saying another means one of
    # the two datasets is wrong, and guessing which would be how somebody's
    # holding ends up priced as a different business.
    if len(found) > 1:
        ids = {key: row["id"] for key, row in found.items()}
        if len(set(ids.values())) > 1:
            claims = [{"by": key, "id": row["id"],
                       "company_name": row["company_name"], "isin": row["isin"],
                       "nse_symbol": row["nse_symbol"]}
                      for key, row in found.items()]
            strongest = max(found, key=lambda k: TRUST.get(k, 0))
            record_conflict(strongest, str(isin or token or symbol), claims)
            return Resolution(
                status="conflicted",
                conflict={"claims": claims, "trusted_most": strongest},
                why=("The identifiers on this holding point at different "
                     "companies, so we have not attached it to either."),
            )

    if found:
        best = max(found, key=lambda k: TRUST.get(k, 0))
        return Resolution(status="resolved", identity=_public(found[best]), by=best)

    # Nothing identified it, so fall back to the name -- which is the weakest
    # evidence there is, and treated accordingly.
    if name and name.strip():
        rows = _by_name(name)
        if not rows:
            return Resolution(status="unknown",
                              why="we could not find anything by that name")
        flat = _flatten(name)
        exact = [r for r in rows if _flatten(r["company_name"]) == flat]
        if len(exact) == 1:
            return Resolution(status="resolved", identity=_public(exact[0]), by="name")

        # A single near match is not certainty. "Tata Motors" matched only
        # "Tata Motors Passenger Vehicles" -- because the parent is missing, not
        # because that is what was meant.
        starts = [r for r in rows if _flatten(r["company_name"]).startswith(flat)]
        if len(starts) == 1:
            matched = _flatten(starts[0]["company_name"])
            if len(flat) / max(len(matched), 1) >= 0.7:
                return Resolution(status="resolved", identity=_public(starts[0]), by="name")

        if len(rows) == 1:
            # One near match is not agreement. "Tata Motors" finds only Tata
            # Motors Passenger Vehicles here -- because the parent is absent
            # from the list, not because the spin-off is what anyone meant.
            return Resolution(
                status="ambiguous",
                candidates=[_public(rows[0])],
                why=(f"the closest we hold is {rows[0]['company_name']}, "
                     f"which is not quite what you wrote"),
            )

        return Resolution(status="ambiguous",
                          candidates=[_public(r) for r in rows],
                          why=f"{len(rows)} companies could be what you meant")

    return Resolution(status="unknown", why="nothing to identify it by")


def _public(row: dict) -> dict:
    """The fields worth handing back, without the bookkeeping."""
    return {
        "id": row.get("id"),
        "isin": row.get("isin"),
        "token": row.get("token"),
        "nse_symbol": row.get("nse_symbol"),
        "bse_code": row.get("bse_code"),
        "company_name": row.get("company_name"),
        "sector": row.get("sector"),
        "industry": row.get("industry"),
    }


def open_conflicts() -> list[dict]:
    """Disagreements nobody has looked at yet."""
    return db.fetch_all(
        """
        SELECT identifier_kind, identifier, claims, noticed_at
        FROM identity_conflicts WHERE resolved_at IS NULL
        ORDER BY noticed_at DESC
        """
    )
