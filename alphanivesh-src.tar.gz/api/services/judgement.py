"""The adviser's own judgement, and what carried over from yesterday.

Two things that belong together.

**Editing.** An adviser who can only pass through what the engine produced is
not advising; they are reselling software output, which is exactly what does
not hold up when somebody asks who made the recommendation. So they can change
what is said, hold something back, or add a point the engine never reached.

The condition is that the record keeps both versions. A ledger showing only the
final text would say the engine recommended something it never did, and an
adviser who overruled it deserves the credit for having done so as much as the
responsibility.

**And carrying over.** Advice is recomputed every morning against that
morning's prices, so "the advice from yesterday" does not exist as an object —
what exists is today's advice, which may say the same thing or may not. Three
outcomes, and they need telling apart:

  *still stands* — the same recommendation, on today's numbers
  *changed* — the same subject, different figures or a different action
  *no longer applies* — the engine does not raise it today

The third is the interesting one. It happens because somebody acted, or because
the market moved the position back inside tolerance, and those are not the same
thing. Where we can tell, we say which.
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import date, timedelta
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.judgement")

# How long an adviser's edit governs. Advice is recomputed daily and an edit
# made against Monday's numbers should not silently govern Friday's.
OVERRIDE_DAYS = 7


def digest(action: dict) -> str:
    """A fingerprint of what an action says.

    So an override stops applying when the underlying advice changes, rather
    than attaching itself to whatever now happens to carry the same code. The
    figures are in it deliberately: "reduce capital goods to 40%" and "reduce
    capital goods to 55%" are different advice wearing the same label.
    """
    material = json.dumps({
        "code": action.get("code"),
        "what": action.get("what"),
        "how": action.get("how"),
        "worth": action.get("worth"),
    }, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


# ---------------------------------------------------------------------------
# What the adviser changed
# ---------------------------------------------------------------------------

def overrides_for(investor_id: str) -> dict[str, dict]:
    """Live overrides, keyed by action code."""
    rows = db.fetch_all(
        """
        SELECT action_code, said_digest, what, engine_said, adviser_said,
               because, at, applies_until
        FROM advice_override
        WHERE investor_id = %s
          AND withdrawn_at IS NULL
          AND (applies_until IS NULL OR applies_until >= current_date)
        ORDER BY at DESC
        """,
        (investor_id,))

    out: dict[str, dict] = {}
    for row in rows:
        # The most recent per code wins; earlier ones are history.
        out.setdefault(row["action_code"], dict(row))
    return out


def apply_overrides(investor_id: str, actions: list[dict]) -> dict:
    """Put the adviser's judgement over the engine's output.

    Returns the actions as the investor should see them, plus what was changed
    so the page can say an adviser has been here rather than presenting edited
    output as though the engine produced it.
    """
    live = overrides_for(investor_id)
    if not live:
        return {"actions": actions, "edited": 0, "suppressed": 0, "notes": []}

    shown, notes = [], []
    suppressed = edited = 0

    for action in actions:
        override = live.get(action.get("code"))

        # An override attaches to what the engine said at the time. Where the
        # advice has changed underneath it, the override lapses rather than
        # governing something it was never applied to.
        if override and override["said_digest"] != digest(action):
            notes.append({
                "code": action.get("code"),
                "note": ("An adviser's note on this has lapsed because the "
                         "underlying figures have changed since it was made."),
            })
            shown.append(action)
            continue

        if not override:
            shown.append(action)
            continue

        if override["what"] == "suppressed":
            suppressed += 1
            notes.append({
                "code": action.get("code"),
                "note": f"Held back by your adviser: {override['because']}",
            })
            continue

        if override["what"] == "edited" and override["adviser_said"]:
            merged = dict(action)
            merged.update(override["adviser_said"] or {})
            merged["edited_by_adviser"] = True
            merged["adviser_because"] = override["because"]
            shown.append(merged)
            edited += 1
            continue

        shown.append(action)

    # Anything the adviser added that the engine never produced.
    for code, override in live.items():
        if override["what"] == "added" and override["adviser_said"]:
            added = dict(override["adviser_said"])
            added["code"] = code
            added["from_adviser"] = True
            added["adviser_because"] = override["because"]
            shown.append(added)

    return {
        "actions": shown,
        "edited": edited,
        "suppressed": suppressed,
        "notes": notes,
        "reading": _override_reading(edited, suppressed, len(live)),
    }


def _override_reading(edited: int, suppressed: int, total: int) -> Optional[str]:
    if not (edited or suppressed):
        return None
    parts = []
    if edited:
        parts.append(f"{edited} changed")
    if suppressed:
        parts.append(f"{suppressed} held back")
    return (f"Your adviser has been through this: {' and '.join(parts)}. "
            f"What they changed and why is shown against each.")


def record_override(investor_id: str, action_code: str, what: str, *,
                    because: str,
                    engine_said: Optional[dict] = None,
                    adviser_said: Optional[dict] = None,
                    said_digest: Optional[str] = None,
                    by_user_id: Optional[str] = None) -> dict:
    """Note what the adviser did, and why.

    `because` is required. An unexplained override is the one that gets asked
    about, and the answer should be written at the time rather than
    remembered later.
    """
    if what not in ("edited", "suppressed", "added"):
        raise ValueError("what must be edited, suppressed or added")
    if not (because or "").strip():
        raise ValueError("A reason is needed. An unexplained override is the "
                         "one that gets asked about.")

    from . import advisers
    found = advisers.of_record(investor_id)

    with db.connection() as conn:
        # One live override per code. A second would make "what did the
        # adviser decide" a question with two answers.
        conn.execute(
            """
            UPDATE advice_override SET withdrawn_at = now()
            WHERE investor_id = %s AND action_code = %s AND withdrawn_at IS NULL
            """,
            (investor_id, action_code))

        row = conn.execute(
            """
            INSERT INTO advice_override
                (investor_id, adviser_id, action_code, said_digest, what,
                 engine_said, adviser_said, because, by_user_id, applies_until)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (investor_id, (found or {}).get("adviser_id"), action_code,
             said_digest or digest(engine_said or {}), what,
             json.dumps(engine_said, ensure_ascii=False) if engine_said else None,
             json.dumps(adviser_said, ensure_ascii=False) if adviser_said else None,
             because.strip(), by_user_id,
             date.today() + timedelta(days=OVERRIDE_DAYS)),
        ).fetchone()

    return {"id": row["id"] if row else None,
            "applies_until": (date.today() + timedelta(days=OVERRIDE_DAYS)
                              ).isoformat()}


def withdraw(investor_id: str, action_code: str) -> bool:
    with db.connection() as conn:
        conn.execute(
            """
            UPDATE advice_override SET withdrawn_at = now()
            WHERE investor_id = %s AND action_code = %s AND withdrawn_at IS NULL
            """,
            (investor_id, action_code))
    return True


# ---------------------------------------------------------------------------
# Yesterday against today
# ---------------------------------------------------------------------------

def note_shown(investor_id: str, actions: list[dict],
               ledger_id: Optional[str] = None) -> None:
    """Record what went in front of somebody today.

    Idempotent per day: opening the page twice does not create two records of
    the same recommendation.
    """
    for action in actions:
        code = action.get("code")
        if not code:
            continue
        try:
            with db.connection() as conn:
                conn.execute(
                    """
                    INSERT INTO advice_shown
                        (investor_id, ledger_id, action_code, said_digest,
                         headline)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (investor_id, on_date, action_code)
                    DO UPDATE SET said_digest = EXCLUDED.said_digest,
                                  headline = EXCLUDED.headline
                    """,
                    (investor_id, ledger_id, code, digest(action),
                     (action.get("what") or "")[:300]))
        except Exception as err:                                 # pragma: no cover
            log.warning("could not note advice shown for %s: %s",
                        investor_id, err)


def since_yesterday(investor_id: str, actions: list[dict]) -> Optional[dict]:
    """What was said before, against what is being said now.

    Advice is recomputed each morning, so "yesterday's advice" is not an object
    that persists -- what exists is today's, which may say the same thing or
    may not. This tells the three apart.
    """
    previous = db.fetch_all(
        """
        SELECT DISTINCT ON (action_code)
               action_code, said_digest, headline, on_date, acted_on
        FROM advice_shown
        WHERE investor_id = %s AND on_date < current_date
          AND acted_on IS NULL AND lapsed_on IS NULL
        ORDER BY action_code, on_date DESC
        """,
        (investor_id,))
    if not previous:
        return None

    now = {a.get("code"): a for a in actions if a.get("code")}
    digests = {code: digest(a) for code, a in now.items()}

    stands, changed, gone = [], [], []

    for row in previous:
        code = row["action_code"]
        days = (date.today() - row["on_date"]).days

        if code not in now:
            gone.append({
                "code": code,
                "headline": row["headline"],
                "first_said": row["on_date"].isoformat(),
                "days": days,
                # Why it went is the useful part and we cannot always tell.
                # Saying which we do not know is better than picking one.
                "why": ("It is not among today's suggestions. Either it was "
                        "acted on, or the market moved the position back "
                        "inside where it needed to be — the transactions "
                        "would tell us which, and we do not hold them."),
            })
            _lapse(investor_id, code, "not raised today")
            continue

        if digests[code] == row["said_digest"]:
            stands.append({
                "code": code,
                "headline": row["headline"],
                "first_said": row["on_date"].isoformat(),
                "days": days,
            })
        else:
            changed.append({
                "code": code,
                "was": row["headline"],
                "now": now[code].get("what"),
                "first_said": row["on_date"].isoformat(),
                "days": days,
            })

    if not (stands or changed or gone):
        return None

    return {
        "still_stands": stands,
        "changed": changed,
        "no_longer_raised": gone,
        "reading": _carry_reading(stands, changed, gone),
        "on_recomputation": (
            "Everything here is worked out again each morning against that "
            "morning's prices. Where a suggestion says the same thing it said "
            "before, it is because the same thing is still true — not because "
            "it was saved."
        ),
    }


def _lapse(investor_id: str, code: str, why: str) -> None:
    try:
        with db.connection() as conn:
            conn.execute(
                """
                UPDATE advice_shown SET lapsed_on = current_date,
                                        lapsed_why = %s
                WHERE investor_id = %s AND action_code = %s
                  AND acted_on IS NULL AND lapsed_on IS NULL
                """,
                (why, investor_id, code))
    except Exception:                                            # pragma: no cover
        pass


def _carry_reading(stands: list, changed: list, gone: list) -> str:
    bits = []
    if stands:
        oldest = max(s["days"] for s in stands)
        bits.append(f"{len(stands)} of these were suggested before and still "
                    f"stand — the oldest {oldest} days ago")
    if changed:
        bits.append(f"{len(changed)} say something different today because the "
                    f"figures have moved")
    if gone:
        bits.append(f"{len(gone)} are not raised today at all")

    return (". ".join(b[0].upper() + b[1:] for b in bits) + ".") if bits else ""
