"""Recording what we told people.

Under the licence this platform operates through, we answer for every
suggestion, analysis and answer put in front of an investor. That is not a
reporting requirement bolted on afterwards — it changes what the software has
to be. A system that computes on request and stores nothing cannot say what it
told somebody last March. It can recompute from today's prices and produce a
different answer, which is worse than having none, because it looks like one.

So every output passes through here on its way to a reader.

**What is recorded is the conclusion and its basis.** A ledger holding only
what was said answers the question nobody asks. Years later the question is
always *on what basis* — and a portfolio changes, so an answer correct in
August reads as wrong in October unless the inputs that produced it sit beside
it.

**Recording must not break the page.** If the ledger write fails, the investor
still sees their portfolio and the failure is logged loudly. The alternative —
refusing to show somebody their own money because an audit insert timed out —
is the wrong trade, and a silent failure is worse than either. Where a write
fails, that fact is itself recorded.

**And it is append-only, enforced in the database.** Corrections insert a new
row pointing at the original. The history of a correction is part of the
record.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from datetime import date
from decimal import Decimal
from functools import lru_cache
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.ledger")

# Every kind of thing we put in front of somebody. The table constrains this
# too; the list is here so a new surface has to be named in both places rather
# than quietly inheriting a category that does not fit.
KINDS = (
    "decision", "finding", "guide", "buy_plan", "holding_call",
    "fund_fit", "ariv_answer", "ariv_refusal", "notification",
)


@lru_cache(maxsize=1)
def engine_version() -> str:
    """Which version of the reasoning produced this.

    Resolved from the git tag, because a version label nobody can trace to a
    commit is not a record of anything. Falls back to the commit hash, then to
    a marker that says the version could not be determined -- which is itself
    worth knowing in an audit rather than papering over with "unknown".
    """
    override = os.environ.get("ALPHANIVESH_ENGINE_VERSION")
    if override:
        return override

    for command in (["git", "describe", "--tags", "--always", "--dirty"],
                    ["git", "rev-parse", "--short", "HEAD"]):
        try:
            out = subprocess.run(
                command, cwd="/opt/alphawealth", capture_output=True,
                text=True, timeout=5)
            if out.returncode == 0 and out.stdout.strip():
                return out.stdout.strip()
        except Exception:
            continue
    return "unresolved"


def _plain(value: Any) -> Any:
    """Decimals and dates into something JSON will take.

    Decimal is used throughout the platform because money in floating point is
    a category error. It does not serialise, so it becomes a string here rather
    than a float -- a string round-trips exactly and a float does not, and this
    is the one place where exactness is the entire point.
    """
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


def record(investor_id: str, kind: str, said: Any, basis: Any,
           *, surface: Optional[str] = None,
           session_id: Optional[str] = None,
           caller: Optional[str] = None,
           model: Optional[str] = None,
           prompt_version: Optional[str] = None,
           data_as_of: Optional[date] = None) -> Optional[str]:
    """Write one piece of advice to the ledger.

    Returns the row id, or None where the write failed. Never raises: the
    caller is on the path to showing somebody their portfolio, and an audit
    insert that times out must not take the page down with it.
    """
    if kind not in KINDS:
        log.error("refusing to record unknown kind %r", kind)
        return None

    # Under whose registration.
    #
    # Looked up here rather than passed in, so every caller gets it without
    # having to remember -- and so a caller that forgets cannot quietly write
    # a row with no attribution. Where there is no mandate the row is written
    # with a null and the gap shows up in the unattributed count, which is the
    # honest outcome: the advice was given and we cannot say under whom.
    adviser_id = None
    try:
        from . import advisers
        found = advisers.of_record(investor_id)
        adviser_id = (found or {}).get("adviser_id")
    except Exception as err:                                     # pragma: no cover
        log.warning("could not resolve the adviser for %s: %s", investor_id, err)

    try:
        row = db.fetch_one(
            """
            INSERT INTO advice_ledger
                (adviser_id, investor_id, data_as_of, kind, said, basis,
                 engine_version, model, prompt_version, surface,
                 session_id, caller)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (adviser_id,
             investor_id,
             data_as_of or date.today(),
             kind,
             json.dumps(_plain(said), ensure_ascii=False),
             json.dumps(_plain(basis), ensure_ascii=False),
             engine_version(),
             model, prompt_version, surface, session_id, caller),
        )
        return row["id"] if row else None
    except Exception as err:                                     # pragma: no cover
        # Loud, because a gap in the ledger is a gap in what we can defend, and
        # somebody has to know it happened.
        log.error("LEDGER WRITE FAILED for %s (%s): %s", investor_id, kind, err)
        return None


def correct(original_id: str, said: Any, basis: Any, note: str,
            investor_id: str, kind: str) -> Optional[str]:
    """Supersede an earlier record without erasing it.

    The database refuses updates outright, which is the point. A correction is
    a new row pointing at what it replaces, so the fact that something was
    corrected -- and when, and to what -- is itself part of the history.
    """
    try:
        row = db.fetch_one(
            """
            INSERT INTO advice_ledger
                (adviser_id, investor_id, data_as_of, kind, said, basis,
                 engine_version, corrects, correction_note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (investor_id, date.today(), kind,
             json.dumps(_plain(said), ensure_ascii=False),
             json.dumps(_plain(basis), ensure_ascii=False),
             engine_version(), original_id, note),
        )
        return row["id"] if row else None
    except Exception as err:                                     # pragma: no cover
        log.error("LEDGER CORRECTION FAILED for %s: %s", original_id, err)
        return None


def outcome(record_id: str, what_happened: str) -> None:
    """Note that advice was acted on.

    The table is append-only, so this writes a linked row rather than setting a
    field. Advice followed and advice ignored are different histories and both
    are worth having: the first shows whether what we suggested helped, and the
    second shows what we suggest that nobody does.
    """
    try:
        original = db.fetch_one(
            "SELECT investor_id, kind, said, basis FROM advice_ledger "
            "WHERE id = %s", (record_id,))
        if not original:
            return
        # Writes go through connection(); there is no db.execute. Worth the
        # note because this was written twice from memory and wrong twice.
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO advice_ledger
                    (investor_id, data_as_of, kind, said, basis,
                     engine_version, corrects, outcome, outcome_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, now())
                """,
                (original["investor_id"], date.today(), original["kind"],
                 json.dumps(_plain(original["said"]), ensure_ascii=False),
                 json.dumps(_plain(original["basis"]), ensure_ascii=False),
                 engine_version(), record_id, what_happened),
            )
    except Exception as err:                                     # pragma: no cover
        log.error("LEDGER OUTCOME FAILED for %s: %s", record_id, err)


# ---------------------------------------------------------------------------
# Reading it back
# ---------------------------------------------------------------------------

def history(investor_id: str, kind: Optional[str] = None,
            limit: int = 100) -> list[dict]:
    """What this investor was told, most recent first."""
    if kind:
        return db.fetch_all(
            """
            SELECT id, shown_at, data_as_of, kind, said, engine_version,
                   surface, corrects, outcome
            FROM advice_ledger
            WHERE investor_id = %s AND kind = %s
            ORDER BY shown_at DESC LIMIT %s
            """,
            (investor_id, kind, limit),
        )
    return db.fetch_all(
        """
        SELECT id, shown_at, data_as_of, kind, said, engine_version,
               surface, corrects, outcome
        FROM advice_ledger
        WHERE investor_id = %s
        ORDER BY shown_at DESC LIMIT %s
        """,
        (investor_id, limit),
    )


def as_at(investor_id: str, when: date) -> list[dict]:
    """What this investor was being told on a given day.

    The question an audit actually asks. Includes the basis, because the answer
    to "why did you say that" is in the inputs rather than in the words.
    """
    return db.fetch_all(
        """
        SELECT id, shown_at, data_as_of, kind, said, basis, engine_version,
               model, surface
        FROM advice_ledger
        WHERE investor_id = %s AND shown_at::date = %s
        ORDER BY shown_at
        """,
        (investor_id, when),
    )


def export(investor_id: Optional[str] = None,
           since: Optional[date] = None,
           until: Optional[date] = None) -> list[dict]:
    """Everything, for a regulator who asked for a slice.

    They ask for a range and a person rather than a database, so the filters
    are optional and combine.
    """
    clauses, params = ["1 = 1"], []
    if investor_id:
        clauses.append("investor_id = %s")
        params.append(investor_id)
    if since:
        clauses.append("shown_at >= %s")
        params.append(since)
    if until:
        clauses.append("shown_at < %s")
        params.append(until)

    return db.fetch_all(
        f"""
        SELECT * FROM advice_ledger
        WHERE {' AND '.join(clauses)}
        ORDER BY investor_id, shown_at
        """,
        tuple(params),
    )


def coverage() -> dict:
    """Whether the ledger is actually being written to.

    A ledger nobody writes to looks exactly like a compliant one until somebody
    asks for a record. Worth checking rather than assuming, and worth checking
    per kind: one surface quietly not recording is the likely failure, not all
    of them at once.
    """
    rows = db.fetch_all(
        """
        SELECT kind, count(*) AS n, max(shown_at) AS latest
        FROM advice_ledger GROUP BY kind ORDER BY kind
        """
    )
    total = db.fetch_one(
        "SELECT count(*) AS n, min(shown_at) AS first, max(shown_at) AS latest "
        "FROM advice_ledger")

    return {
        "by_kind": [{"kind": r["kind"], "records": r["n"],
                     "latest": r["latest"].isoformat() if r["latest"] else None}
                    for r in rows],
        "total": total["n"] if total else 0,
        "first": total["first"].isoformat() if total and total["first"] else None,
        "latest": total["latest"].isoformat() if total and total["latest"] else None,
        "kinds_never_written": sorted(set(KINDS) - {r["kind"] for r in rows}),
        "engine_version": engine_version(),
    }
