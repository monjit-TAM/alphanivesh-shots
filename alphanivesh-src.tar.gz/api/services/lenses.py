"""Looking at a holding three ways.

Value, growth and quality are three different questions about the same company,
and a stock can answer one well and the others badly. Showing them separately
is the point: a cheap company growing slowly and an expensive one growing fast
are both defensible positions, and collapsing them into one score hides which
you are holding.

Two decisions shape everything here.

**Every measure is relative to its sector, not to a fixed number.** The
implementation this replaces categorised a P/E under 15 as undervalued and over
40 as overvalued, across every industry. A bank at 18 times earnings is dear;
a software company at 18 is cheap. On the portfolio in front of us that put
Thermax at 63 into "overvalued" without mentioning that its sector runs at 34,
which is the only fact that makes 63 mean anything.

**Nothing is scored.** Each lens reports how many measures sit better or worse
than the sector and names them. "Better on three of four" aggregates without
inventing weights, and a reader who disagrees can see exactly which three.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Optional

from .. import db

# A sector median from three companies is not a median. Below this the
# comparison is dropped rather than shown weakly.
MIN_SECTOR_PEERS = 5

# How far from the sector before it is worth calling a difference. Ratios wobble
# quarter to quarter, and treating a 3% gap as a signal would make every holding
# look remarkable at something.
MEANINGFUL_GAP = Decimal("15")      # per cent away from the sector median


@dataclass
class Measure:
    """One figure, its sector, and which way the difference runs."""
    key: str
    label: str
    value: Decimal
    sector: Optional[Decimal]
    unit: str
    # Whether a higher number is the better one. False for P/E and debt --
    # paying less and owing less are both good, and a lens that treats every
    # number as "higher is better" would rank the most indebted company best.
    higher_is_better: bool
    explain: str

    @property
    def gap_pct(self) -> Optional[Decimal]:
        if self.sector is None or self.sector == 0:
            return None
        return (self.value - self.sector) / abs(self.sector) * 100

    @property
    def verdict(self) -> str:
        """better, worse, or in line -- from the sector, not a threshold."""
        gap = self.gap_pct
        if gap is None:
            return "unknown"
        if abs(gap) < MEANINGFUL_GAP:
            return "in line"
        favourable = gap > 0 if self.higher_is_better else gap < 0
        return "better" if favourable else "worse"

    def as_dict(self) -> dict:
        gap = self.gap_pct
        return {
            "key": self.key,
            "label": self.label,
            "value": str(self.value.quantize(Decimal("0.01"))),
            "sector": str(self.sector.quantize(Decimal("0.01"))) if self.sector is not None else None,
            "unit": self.unit,
            "gap_pct": str(gap.quantize(Decimal("0.1"))) if gap is not None else None,
            "verdict": self.verdict,
            "explain": self.explain,
        }


# The three lenses. Each is a set of measures and a sentence about what the
# lens is for, because "value" means different things to different readers.
LENSES: dict[str, dict] = {
    "value": {
        "title": "Value",
        "asks": "Are you paying a lot for what the company earns and owns?",
        "measures": [
            ("pe_ttm", "Price to earnings", "\u00d7", False,
             "What you pay for each rupee of profit"),
            ("pb_ratio", "Price to book", "\u00d7", False,
             "What you pay for each rupee of assets"),
            ("ev_ebitda", "Enterprise value to EBITDA", "\u00d7", False,
             "The whole business against its operating profit"),
            ("earnings_yield", "Earnings yield", "%", True,
             "The profit as a percentage of the price \u2014 the inverse of P/E"),
        ],
    },
    "growth": {
        "title": "Growth",
        "asks": "Is the business getting bigger, and how quickly?",
        "measures": [
            ("revenue_growth_yoy", "Revenue, year on year", "%", True,
             "Sales this year against last"),
            ("pat_growth_yoy", "Profit, year on year", "%", True,
             "What it kept, this year against last"),
            ("eps_growth_yoy", "Earnings per share, year on year", "%", True,
             "Profit per share \u2014 growth that survives new shares being issued"),
            ("fcf_yield", "Free cash flow yield", "%", True,
             "Cash the business actually threw off, against its price"),
        ],
    },
    "quality": {
        "title": "Quality",
        "asks": "Does it earn well on its capital, and can it pay its debts?",
        "measures": [
            ("roe", "Return on equity", "%", True,
             "What it makes on shareholders' money"),
            ("roce", "Return on capital employed", "%", True,
             "What it makes on everything it uses, borrowed or owned"),
            ("debt_to_equity", "Debt to equity", "\u00d7", False,
             "Borrowings against shareholders' money"),
            ("interest_coverage", "Interest cover", "\u00d7", True,
             "Times over its profit covers what it owes in interest"),
            ("net_margin", "Net margin", "%", True,
             "What it keeps of every rupee of sales"),
        ],
    },
}

# Figures beyond these are division artefacts rather than facts. Interest cover
# of four million means a company with almost no debt, which is worth knowing
# but not worth averaging into a sector median.
SANE_RANGE = {
    "pe_ttm": (Decimal("0"), Decimal("500")),
    "pb_ratio": (Decimal("0"), Decimal("100")),
    "ev_ebitda": (Decimal("-100"), Decimal("500")),
    "earnings_yield": (Decimal("-50"), Decimal("100")),
    "roe": (Decimal("-200"), Decimal("200")),
    "roce": (Decimal("-200"), Decimal("200")),
    "debt_to_equity": (Decimal("0"), Decimal("50")),
    "interest_coverage": (Decimal("-100"), Decimal("1000")),
    "net_margin": (Decimal("-200"), Decimal("200")),
    "revenue_growth_yoy": (Decimal("-100"), Decimal("500")),
    "pat_growth_yoy": (Decimal("-500"), Decimal("1000")),
    "eps_growth_yoy": (Decimal("-500"), Decimal("1000")),
    "fcf_yield": (Decimal("-100"), Decimal("100")),
}


def _sane(key: str, value: Any) -> Optional[Decimal]:
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except Exception:
        return None
    if not number.is_finite():
        return None
    low, high = SANE_RANGE.get(key, (Decimal("-1e12"), Decimal("1e12")))
    return number if low <= number <= high else None


def _available_fields() -> set[str]:
    """Which measures the company master actually carries.

    The master is refreshed from a source we do not own, and a column that
    disappears should cost us one measure rather than the whole lens. This is
    checked once and cached for the process.
    """
    global _FIELDS
    if _FIELDS is None:
        rows = db.fetch_all(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = 'company_fundamentals'"
        )
        _FIELDS = {r["column_name"] for r in rows}
    return _FIELDS


_FIELDS: Optional[set[str]] = None


def _sector_medians(sector: str) -> dict[str, Decimal]:
    """The middle of the sector for every measure, ignoring absurd values.

    Median rather than mean, because one company with a P/E of 400 would drag
    an average somewhere no company in the sector actually sits.
    """
    have = _available_fields()
    fields = sorted({key for lens in LENSES.values() for key, *_ in lens["measures"]}
                    & have)
    if not fields:
        return {}
    conditions = " AND ".join(
        f"({f} IS NULL OR ({f} >= {SANE_RANGE[f][0]} AND {f} <= {SANE_RANGE[f][1]}))"
        for f in fields if f in SANE_RANGE
    )
    selects = ", ".join(
        f"percentile_cont(0.5) WITHIN GROUP (ORDER BY {f}) AS {f}" for f in fields
    )
    row = db.fetch_one(
        f"""
        SELECT count(*) AS peers, {selects}
        FROM company_fundamentals
        WHERE sector = %s AND ({conditions})
        """,
        (sector,),
    )
    if not row or (row["peers"] or 0) < MIN_SECTOR_PEERS:
        return {}
    return {k: Decimal(str(v)) for k, v in row.items()
            if k != "peers" and v is not None}


def through_lenses(symbol: Optional[str] = None,
                   isin: Optional[str] = None) -> Optional[dict]:
    """One company, seen three ways.

    Returns each lens with its measures, how many sit better or worse than the
    sector, and a sentence saying so. No score: "better on three of four" is a
    count anybody can check, where "7.2 out of 10" is a number they have to
    take on trust.
    """
    company = db.fetch_one(
        """
        SELECT * FROM company_fundamentals
        WHERE (%s <> '' AND symbol = %s) OR (%s <> '' AND isin = %s)
        LIMIT 1
        """,
        ((symbol or "").upper(), (symbol or "").upper(),
         (isin or "").upper(), (isin or "").upper()),
    )
    if company is None:
        return None

    sector = company.get("sector")
    medians = _sector_medians(sector) if sector else {}
    peers = db.fetch_one(
        "SELECT count(*) AS n FROM company_fundamentals WHERE sector = %s",
        (sector,),
    ) if sector else None

    lenses = []
    for name, spec in LENSES.items():
        measures: list[Measure] = []
        for key, label, unit, higher_is_better, explain in spec["measures"]:
            if key not in company:
                continue
            value = _sane(key, company.get(key))
            if value is None:
                continue
            measures.append(Measure(
                key=key, label=label, value=value,
                sector=medians.get(key), unit=unit,
                higher_is_better=higher_is_better, explain=explain,
            ))

        if not measures:
            continue

        compared = [m for m in measures if m.verdict != "unknown"]
        better = sum(1 for m in compared if m.verdict == "better")
        worse = sum(1 for m in compared if m.verdict == "worse")

        lenses.append({
            "lens": name,
            "title": spec["title"],
            "asks": spec["asks"],
            "measures": [m.as_dict() for m in measures],
            "better": better,
            "worse": worse,
            "in_line": len(compared) - better - worse,
            "compared": len(compared),
            "reading": _read(spec["title"], better, worse, len(compared), sector),
        })

    if not lenses:
        return None

    return {
        "company": company["company_name"],
        "symbol": company["symbol"],
        "sector": sector,
        "sector_peers": (peers["n"] if peers else None),
        "lenses": lenses,
        "overall": _overall(lenses),
        "method": ("Every figure is compared to the middle of its own sector rather "
                   "than to a fixed number. A price of eighteen times earnings is dear "
                   "for a bank and cheap for a software company, and a threshold that "
                   "ignores the difference mislabels most holdings."),
    }


def _read(title: str, better: int, worse: int, compared: int,
          sector: Optional[str]) -> str:
    """What the count means, in a sentence."""
    if not compared:
        return f"We have nothing to compare on {title.lower()}."
    where = f"its sector" if not sector else f"the rest of {sector.lower()}"
    if better and not worse:
        return f"Better than {where} on {better} of {compared} measures."
    if worse and not better:
        return f"Worse than {where} on {worse} of {compared} measures."
    if not better and not worse:
        return f"In line with {where} on all {compared} measures."
    return (f"Better than {where} on {better} of {compared}, worse on {worse}.")


def _overall(lenses: list[dict]) -> dict:
    """How the three lenses read together.

    Not a score and not a recommendation. A count of which lenses this company
    looks favourable through, because a cheap company growing slowly and an
    expensive one growing fast are both defensible and the reader is the one
    who knows which they want.
    """
    favourable = [l["title"] for l in lenses if l["better"] > l["worse"]]
    unfavourable = [l["title"] for l in lenses if l["worse"] > l["better"]]

    if len(favourable) == len(lenses):
        sentence = "Looks favourable on all three: cheap, growing, and earning well."
    elif favourable and not unfavourable:
        sentence = f"Looks favourable on {' and '.join(favourable).lower()}."
    elif unfavourable and not favourable:
        sentence = (f"Looks unfavourable on {' and '.join(unfavourable).lower()} "
                    f"against its sector.")
    elif favourable and unfavourable:
        sentence = (f"Favourable on {' and '.join(favourable).lower()}, less so on "
                    f"{' and '.join(unfavourable).lower()}. Whether that trade is worth "
                    f"making is the judgement.")
    else:
        sentence = "Sits close to its sector on every measure we hold."

    return {
        "favourable": favourable,
        "unfavourable": unfavourable,
        "reading": sentence,
        "note": ("Three questions, not one answer. A cheap company growing slowly "
                 "and a dear one growing fast are both defensible positions, and "
                 "which suits you is not something a calculation decides."),
    }
