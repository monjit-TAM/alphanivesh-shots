"""Sending mail.

Through SendGrid, because the group already uses it and a second provider
would mean a second set of deliverability problems to learn.

**Every send is recorded.** Not the content — that is already in the advice
ledger where it belongs — but the fact, the recipient, the kind and whether it
left. An adviser who cannot say whether somebody was told something has a
compliance problem, and "the API returned 202" is the only evidence that
exists after the fact.

**Failures are loud and non-fatal.** A welcome email that does not arrive
should not stop somebody registering, and a review that fails to send should
not take the scheduled job down with it. Both are logged at error level with
the recipient, because a silent mail failure is discovered weeks later by
somebody asking why they never hear from us.

**And nothing sends without an address that was verified.** A password reset
sent to an unverified address is a way to take over an account, and the same
reasoning applies more weakly to everything else.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.mail")

API = "https://api.sendgrid.com/v3/mail/send"

FROM_ADDRESS = os.environ.get("MAIL_FROM", "hello@alphanivesh.com")
FROM_NAME = os.environ.get("MAIL_FROM_NAME", "AlphaNivesh")
REPLY_TO = os.environ.get("MAIL_REPLY_TO", FROM_ADDRESS)

SITE = os.environ.get("SITE_URL", "https://alphanivesh.com")

# Who may be written to.
#
# Set MAIL_ONLY_TO to a comma-separated list and nothing reaches anybody else.
# Leave it unset and mail goes wherever it is addressed.
#
# This exists because a test run reached a real investor's inbox unannounced.
# The command was right, the address was real, and nothing between the two
# asked whether that was intended. A live system that can mail a customer
# because somebody typed the wrong id needs a lock on it, and the lock belongs
# here rather than in each caller.
ONLY_TO = {a.strip().lower() for a in
           (os.environ.get("MAIL_ONLY_TO") or "").split(",") if a.strip()}

# The same message to the same person, twice, within this many hours is almost
# always a mistake -- a job run by hand after cron already ran, or a retry
# that did not need retrying.
NO_REPEAT_HOURS = int(os.environ.get("MAIL_NO_REPEAT_HOURS", "20"))

# Kinds where a repeat is legitimate and expected. Somebody who asks for two
# reset links in five minutes should get two.
REPEATABLE = {"reset_password", "verify_email", "test"}


def _key() -> Optional[str]:
    return os.environ.get("SENDGRID_API_KEY")


def configured() -> bool:
    return bool(_key())


def send(to: str, subject: str, html: str, *,
         text: Optional[str] = None,
         kind: str = "other",
         investor_id: Optional[str] = None,
         categories: Optional[list[str]] = None) -> dict:
    """Send one message. Returns what happened rather than raising.

    Callers are things like registration and the scheduled review, and neither
    should fall over because mail is down.
    """
    # Held back rather than sent.
    if ONLY_TO and to.strip().lower() not in ONLY_TO:
        log.warning("MAIL HELD to %s (%s): MAIL_ONLY_TO is set and this "
                    "address is not on it", to, kind)
        _record(to, kind, investor_id, subject, False, "held: not in MAIL_ONLY_TO")
        return {"sent": False, "held": True,
                "why": (f"MAIL_ONLY_TO is set on this server and {to} is not "
                        f"on the list. Nothing was sent.")}

    if kind not in REPEATABLE and _sent_recently(to, kind):
        log.warning("MAIL SKIPPED to %s (%s): the same kind went within the "
                    "last %d hours", to, kind, NO_REPEAT_HOURS)
        return {"sent": False, "skipped": True,
                "why": (f"A {kind} already went to {to} within "
                        f"{NO_REPEAT_HOURS} hours.")}

    key = _key()
    if not key:
        log.error("MAIL NOT SENT to %s (%s): no SENDGRID_API_KEY", to, kind)
        _record(to, kind, investor_id, subject, False, "no api key")
        return {"sent": False, "why": "SENDGRID_API_KEY is not set."}

    payload = {
        "personalizations": [{"to": [{"email": to}]}],
        "from": {"email": FROM_ADDRESS, "name": FROM_NAME},
        "reply_to": {"email": REPLY_TO},
        "subject": subject,
        "content": (
            ([{"type": "text/plain", "value": text}] if text else [])
            + [{"type": "text/html", "value": html}]
        ),
        "categories": categories or [kind],
        # Click tracking rewrites every link through a redirect, which makes
        # the address bar show somebody's mail provider rather than us on a
        # message about their money. Not worth the open rates.
        "tracking_settings": {
            "click_tracking": {"enable": False},
            "open_tracking": {"enable": False},
        },
    }

    request = urllib.request.Request(
        API, data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}",
                 "Content-Type": "application/json"},
        method="POST")

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            ok = 200 <= response.status < 300
            _record(to, kind, investor_id, subject, ok, str(response.status))
            if not ok:
                log.error("MAIL REJECTED to %s (%s): %s", to, kind,
                          response.status)
            return {"sent": ok, "status": response.status}

    except urllib.error.HTTPError as err:
        body = ""
        try:
            body = err.read().decode("utf-8")[:300]
        except Exception:
            pass
        log.error("MAIL FAILED to %s (%s): %s %s", to, kind, err.code, body)
        _record(to, kind, investor_id, subject, False, f"{err.code} {body[:120]}")
        return {"sent": False, "why": f"{err.code}", "detail": body}

    except Exception as err:                                     # pragma: no cover
        log.error("MAIL FAILED to %s (%s): %s", to, kind, err)
        _record(to, kind, investor_id, subject, False, str(err)[:120])
        return {"sent": False, "why": str(err)[:200]}


def _sent_recently(to: str, kind: str) -> bool:
    """Whether this person already had one of these.

    The guard against a job run by hand after cron has already run, and
    against a retry that did not need retrying. Checked against what actually
    left rather than what was attempted -- a failed send should be retried.
    """
    try:
        row = db.fetch_one(
            """
            SELECT 1 FROM mail_log
            WHERE lower(to_address) = lower(%s) AND kind = %s AND sent
              AND at > now() - (%s || ' hours')::interval
            LIMIT 1
            """,
            (to, kind, NO_REPEAT_HOURS))
        return bool(row)
    except Exception:                                            # pragma: no cover
        # A failure to check is not a reason to block the send.
        return False


def _record(to: str, kind: str, investor_id: Optional[str],
            subject: str, sent: bool, detail: str) -> None:
    """Note that we tried.

    The content is not stored here -- it is in the advice ledger, which is the
    record of what somebody was shown. This is the record of what left, which
    is a different question and the one that matters when somebody says they
    never heard from us.
    """
    try:
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO mail_log
                    (investor_id, to_address, kind, subject, sent, detail)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (investor_id, to, kind, subject[:300], sent, detail[:300]),
            )
    except Exception as err:                                     # pragma: no cover
        log.error("MAIL LOG FAILED for %s: %s", to, err)


# ---------------------------------------------------------------------------
# The shell every message sits in
# ---------------------------------------------------------------------------

def wrap(body: str, *, preheader: str = "", footer: str = "") -> str:
    """One shell, so every message looks like it came from the same place.

    Tables and inline styles because that is what mail clients render
    reliably, and no images: half of them are blocked by default and a message
    that depends on one arrives broken.
    """
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#FAF7F2">
<span style="display:none;max-height:0;overflow:hidden;opacity:0">{preheader}</span>
<table cellpadding="0" cellspacing="0" border="0" width="100%"
       style="background:#FAF7F2;padding:28px 14px">
<tr><td align="center">
  <table cellpadding="0" cellspacing="0" border="0" width="600"
         style="max-width:600px;background:#fff;border:1px solid #E8E2D9;
                border-radius:10px">
  <tr><td style="padding:26px 30px 0">
    <p style="margin:0;font-family:Helvetica,Arial,sans-serif;font-weight:bold;
              font-size:17px;letter-spacing:-.5px">
      <span style="color:#5C1A1B">Alpha</span><span style="color:#2A2622">Nivesh</span>
    </p>
  </td></tr>
  <tr><td style="padding:18px 30px 30px;font-family:Georgia,'Times New Roman',serif;
                 color:#2A2622;font-size:15px;line-height:1.62">
    {body}
  </td></tr>
  <tr><td style="padding:0 30px 26px;font-family:Helvetica,Arial,sans-serif;
                 font-size:11.5px;color:#8A8177;line-height:1.55;
                 border-top:1px solid #E8E2D9;padding-top:16px">
    {footer or f'Sent by AlphaNivesh. <a href="{SITE}" style="color:#8A8177">alphanivesh.com</a>'}
  </td></tr>
  </table>
</td></tr></table>
</body></html>"""


def button(label: str, href: str) -> str:
    return (f'<table cellpadding="0" cellspacing="0" border="0" '
            f'style="margin:22px 0"><tr><td '
            f'style="background:#5C1A1B;border-radius:6px">'
            f'<a href="{href}" style="display:inline-block;padding:12px 22px;'
            f'font-family:Helvetica,Arial,sans-serif;font-size:14px;'
            f'font-weight:bold;color:#ffffff;text-decoration:none">'
            f'{label}</a></td></tr></table>')
