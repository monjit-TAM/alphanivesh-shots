"""What the managers did while nobody was watching.

Every month, fund managers file what they hold. Two consecutive filings say
exactly what was bought, sold, added to and trimmed — and the investor's own
risk changed without a single decision on their part.

The case that makes this worth building: somebody holds 25% in one bank
directly. Last month none of their funds held it. This month three of them
bought it, and their exposure to that bank is now 31%. Nothing in the market
tells them, because no aggregator looks through funds to companies on a
month-over-month basis.

**The coverage problem, stated rather than worked around.** Of 4,844 schemes in
the disclosure pipeline, 3,775 have a single filing date — no previous month to
compare against. On real portfolios about one fund in six has month-over-month
holdings. This reports on those and names the rest, because a briefing that
silently covers a sixth of somebody's money while looking complete is worse
than one that says which sixth.

**And it does not treat every change as news.** A manager trimming a position
by a tenth of a per cent is portfolio maintenance. What matters is a company
entering or leaving, a position changing materially, and — the one nobody else
computes — a company the investor already owns directly appearing in their
funds.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.managers")

# A weight change smaller than this is maintenance rather than a decision.
MATERIAL_PCT = Decimal("0.5")

# And a position below this is not worth reporting whatever happened to it.
WORTH_MENTIONING_PCT = Decimal("1.0")

# How many funds to ask about. Beyond the largest dozen the positions are too
# small for a manager's decision to matter to the holder.
MAX_FUNDS = 12


def _d(value: Any) -> Optional[Decimal]:
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except Exception:
        return None
    return number if number.is_finite() else None


def _money(value: Any) -> str:
    number = int(_d(value) or 0)
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if number >= 0 else "-₹") + digits


def for_investor(investor_id: str) -> Optional[dict]:
    """What changed inside the funds, and what we could not see."""
    from . import dataservice

    funds = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value,
               i.native_code
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0 AND i.native_code ~ '^[0-9]+$'
        ORDER BY v.current_value DESC
        LIMIT %s
        """,
        (investor_id, MAX_FUNDS),
    )
    if not funds:
        return None

    total = sum((_d(f["current_value"]) or Decimal(0) for f in funds), Decimal(0))

    seen: list[dict] = []
    blind: list[dict] = []
    seen_value = Decimal(0)

    for fund in funds:
        value = _d(fund["current_value"]) or Decimal(0)
        try:
            activity = dataservice.activity(str(fund["native_code"]))
        except Exception:
            activity = None

        moves = _changes(activity, fund["instrument_name"], value, total)
        if moves is None:
            blind.append({
                "name": fund["instrument_name"],
                "value": str(value.quantize(Decimal("1"))),
                "share_pct": str((value / total * 100).quantize(Decimal("0.1"))
                                 if total > 0 else Decimal(0)),
            })
            continue

        seen_value += value
        if moves["bought"] or moves["sold"] or moves["changed"]:
            seen.append(moves)

    coverage = (seen_value / total * 100) if total > 0 else Decimal(0)

    # The finding nobody else computes: a company somebody owns directly that
    # their funds have just started buying.
    doubling = _doubling_up(investor_id, seen)

    return {
        "funds_seen": len(seen),
        "funds_blind": len(blind),
        "blind": blind,
        "coverage_pct": str(coverage.quantize(Decimal("0.1"))),
        "changes": seen,
        "doubling_up": doubling,
        "reading": _reading(seen, blind, coverage, doubling),
        "on_coverage": (
            f"This covers {coverage:.0f}% of what you hold in funds. The rest "
            f"file their holdings without a comparable previous month, so "
            f"there is nothing to compare against — not a gap in the analysis "
            f"so much as a gap in what fund houses publish."
        ),
    }


def _changes(activity: Optional[dict], name: str, value: Decimal,
             total: Decimal) -> Optional[dict]:
    """What one manager did, or None where we cannot see."""
    # The endpoint says so explicitly. Testing only for an error key let every
    # fund without two filings through as "seen", which put coverage at 100%
    # on a portfolio where most funds have a single disclosure date.
    if not activity or activity.get("detail"):
        return None
    if activity.get("computable") is False:
        return None

    bought = activity.get("bought") or []
    sold = activity.get("sold") or []
    changed = activity.get("increased") or activity.get("changed") or []

    if not (bought or sold or changed):
        # A fund with disclosures and no changes is different from one we
        # cannot see, and both are worth distinguishing.
        return {"name": name, "value": str(value), "bought": [], "sold": [],
                "changed": [], "quiet": True,
                "share_pct": str((value / total * 100).quantize(Decimal("0.1"))
                                 if total > 0 else Decimal(0))}

    def notable(entries: list) -> list[dict]:
        out = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            weight = _d(entry.get("weight_pct") or entry.get("weight"))
            if weight is not None and weight < WORTH_MENTIONING_PCT:
                continue
            out.append({
                "symbol": entry.get("symbol") or entry.get("name"),
                "weight_pct": str(weight) if weight is not None else None,
                "change_pct": (str(_d(entry.get("change_pct")))
                               if entry.get("change_pct") is not None else None),
            })
        return out[:6]

    return {
        "name": name,
        "value": str(value.quantize(Decimal("1"))),
        "share_pct": str((value / total * 100).quantize(Decimal("0.1"))
                         if total > 0 else Decimal(0)),
        "quiet": False,
        "bought": notable(bought),
        "sold": notable(sold),
        "changed": notable(changed),
        "as_of": activity.get("to") or activity.get("as_of"),
        "previous": activity.get("from"),
        # How far apart the two filings are. Calling a six-month comparison
        # "this month" would be wrong in the direction that overstates how
        # recent the change is.
        "months_apart": activity.get("months_apart"),
        "positions_now": activity.get("positions_now"),
        "positions_then": activity.get("positions_then"),
    }


def _doubling_up(investor_id: str, changes: list[dict]) -> Optional[dict]:
    """A company somebody owns directly that their funds have started buying.

    The finding this whole thing exists for. Somebody holding a bank directly
    whose funds have just bought the same bank has more riding on it than they
    did last month, and they made no decision at any point.

    Nobody else shows this because it needs the direct holdings and the fund
    disclosures compared across two months, and most products have one or the
    other.
    """
    direct = db.fetch_all(
        """
        SELECT i.symbol, v.instrument_name, v.current_value
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'equity'
          AND v.current_value > 0 AND i.symbol IS NOT NULL
        """,
        (investor_id,),
    )
    if not direct or not changes:
        return None

    owned = {(row["symbol"] or "").upper(): row for row in direct}
    overlaps: dict[str, list[str]] = {}

    for fund in changes:
        for entry in fund.get("bought") or []:
            symbol = (entry.get("symbol") or "").upper()
            if symbol and symbol in owned:
                overlaps.setdefault(symbol, []).append(fund["name"])

    if not overlaps:
        return None

    found = []
    for symbol, fund_names in overlaps.items():
        row = owned[symbol]
        found.append({
            "symbol": symbol,
            "name": row["instrument_name"],
            "held_directly": str(_d(row["current_value"]) or Decimal(0)),
            "funds": fund_names,
            "fund_count": len(fund_names),
        })

    found.sort(key=lambda f: -f["fund_count"])
    first = found[0]

    return {
        "found": found,
        "reading": (
            f"{first['name']} is something you already own directly, and "
            f"{first['fund_count']} of your "
            f"fund{'s' if first['fund_count'] != 1 else ''} have bought it "
            f"since their previous filing. Your exposure to it went up without you deciding "
            f"anything — which is how concentration usually arrives."
        ),
        "why_it_matters": (
            "Holdings that look separate can be the same bet. A fund is "
            "supposed to spread risk, and when it buys what you already own it "
            "concentrates instead — quietly, and without telling you."
        ),
    }


def _reading(seen: list[dict], blind: list[dict], coverage: Decimal,
             doubling: Optional[dict]) -> str:
    if doubling:
        return doubling["reading"]

    active = [f for f in seen if not f.get("quiet")]
    if not active:
        if not seen:
            return ("None of your funds publish holdings we can compare "
                    "month to month, so there is nothing to report about what "
                    "the managers did.")
        return ("Your managers made no material changes this month in the "
                "funds we can see into.")

    buys = sum(len(f["bought"]) for f in active)
    sells = sum(len(f["sold"]) for f in active)

    # The window, from the filings themselves rather than assumed. Two
    # disclosures six months apart describe six months of decisions.
    spans = [f.get("months_apart") for f in active if f.get("months_apart")]
    window = (f"over {max(spans)} months" if spans and max(spans) > 1
              else "this month")

    return (
        f"Across {len(active)} of your funds, managers bought {buys} "
        f"{'company' if buys == 1 else 'companies'} and sold {sells} "
        f"{window}. None of it was your decision, and all of it changed what "
        f"you are exposed to."
        + (f" We can see into {coverage:.0f}% of what you hold in funds."
           if coverage < 90 else "")
    )
