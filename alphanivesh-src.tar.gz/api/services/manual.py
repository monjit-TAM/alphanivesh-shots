"""Holdings the investor tells us about, rather than ones a statement carries.

A consolidated statement covers a great deal but not everything. A fixed deposit
at a bank, gold in a locker, a policy bought in 2009, a flat, shares in an
unlisted company -- none of these appear, and for many Indian households they
are most of the wealth. Until they are recorded, every allocation figure and
every finding is describing a fraction of someone's position while appearing to
describe all of it.

Each asset class needs different things. A deposit has a rate and a maturity
date; a policy has a premium and a sum assured; property has an address and a
date somebody last valued it. Rather than eight forms, there is one shape per
class described here, and the interface renders whatever the class calls for.
"""

from __future__ import annotations

import re

from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal
from typing import Optional

from .. import db


@dataclass
class Field:
    name: str
    label: str
    kind: str                 # text | number | money | date | percent | select
    required: bool = False
    help: Optional[str] = None
    options: Optional[list[dict]] = None
    # Where the value ends up. Most go into the holding's attributes; a few are
    # first-class columns because the rest of the platform reads them.
    maps_to: str = "attribute"

    def as_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None}


# Common to everything: what it is, what it is worth, and where it lives.
def _base(value_label: str = "What it is worth today") -> list[Field]:
    return [
        Field("name", "What is it", "text", required=True, maps_to="instrument_name",
              help="However you refer to it. \"SBI FD\", \"Mum's gold\", \"the Pune flat\"."),
        Field("current_value", value_label, "money", required=True, maps_to="current_value"),
        Field("institution", "Where it is held", "text", maps_to="institution",
              help="The bank, insurer or depository. Leave blank if it does not apply."),
        Field("as_of", "Value as at", "date", maps_to="as_of",
              help="When this figure was true. Today if you are not sure."),
    ]


# What each asset class needs beyond the basics.
#
# The extra fields are not decoration: an FD's rate and maturity are what let us
# say whether the money is locked up when a goal falls due, and a policy's sum
# assured is what the protection gap is measured against.
ASSET_FORMS: dict[str, dict] = {
    "fixed_deposit": {
        "label": "Fixed or recurring deposit",
        "hint": "A deposit with a bank, post office or company.",
        "fields": _base("Amount deposited") + [
            Field("interest_rate", "Interest rate", "percent",
                  help="The rate you were promised, if you remember it."),
            Field("maturity_date", "Matures on", "date",
                  help="Tells us whether this money is free when you need it."),
            Field("invested_value", "What you put in", "money",
                  maps_to="invested_value",
                  help="Leave blank if the amount above is the original deposit."),
        ],
    },
    "gold": {
        "label": "Gold",
        "hint": "Jewellery, coins, bars. Sovereign gold bonds usually arrive on a statement.",
        "fields": _base() + [
            Field("form", "In what form", "select", options=[
                {"value": "jewellery", "label": "Jewellery"},
                {"value": "coins", "label": "Coins or bars"},
                {"value": "digital", "label": "Digital gold"},
                {"value": "etf", "label": "Gold ETF or fund"},
            ]),
            Field("grams", "Weight in grams", "number",
                  help="If you know it. We can revalue it as prices move."),
            Field("invested_value", "What you paid", "money", maps_to="invested_value"),
        ],
    },
    "equity": {
        "label": "Shares",
        "hint": "Shares held outside the demat accounts we can read, or unlisted holdings.",
        "fields": _base() + [
            Field("symbol", "Ticker", "text", maps_to="symbol",
                  help="RELIANCE, INFY. Leave blank if unlisted."),
            Field("isin", "ISIN", "text", maps_to="isin"),
            Field("quantity", "How many shares", "number", maps_to="quantity"),
            Field("invested_value", "What you paid in total", "money", maps_to="invested_value"),
        ],
    },
    "bond": {
        "label": "Bonds or debentures",
        "hint": "Corporate bonds, debentures, tax-free bonds held outside demat.",
        "fields": _base() + [
            Field("isin", "ISIN", "text", maps_to="isin"),
            Field("coupon_rate", "Coupon", "percent"),
            Field("maturity_date", "Matures on", "date"),
            Field("invested_value", "What you paid", "money", maps_to="invested_value"),
        ],
    },
    "ppf_epf": {
        "label": "PPF, EPF or small savings",
        "hint": "Provident fund, NSC, KVP, Sukanya Samriddhi.",
        "fields": _base("Balance today") + [
            Field("scheme", "Which scheme", "select", required=True, options=[
                {"value": "ppf", "label": "PPF"},
                {"value": "epf", "label": "EPF"},
                {"value": "nsc", "label": "NSC"},
                {"value": "kvp", "label": "KVP"},
                {"value": "ssy", "label": "Sukanya Samriddhi"},
                {"value": "other", "label": "Something else"},
            ]),
            Field("annual_contribution", "Put in each year", "money"),
            Field("maturity_date", "Matures on", "date"),
        ],
    },
    "real_estate": {
        "label": "Property",
        "hint": "A flat, a house, land. Recorded at what you think it is worth.",
        "fields": _base("What it would fetch today") + [
            Field("property_type", "What kind", "select", options=[
                {"value": "residential", "label": "Somewhere to live"},
                {"value": "commercial", "label": "Commercial"},
                {"value": "land", "label": "Land"},
            ]),
            Field("location", "Where", "text"),
            Field("invested_value", "What you paid", "money", maps_to="invested_value"),
            Field("rental_income", "Rent each month", "money",
                  help="If it is let. Counts towards what the property returns."),
        ],
    },
    "cash": {
        "label": "Cash and bank balances",
        "hint": "Savings accounts and cash you want counted.",
        "fields": _base("Balance"),
    },
    "unlisted": {
        "label": "Unlisted shares or business",
        "hint": "A stake in a private company, or your own business.",
        "fields": _base("What you think it is worth") + [
            Field("stake_pct", "Your share", "percent"),
            Field("invested_value", "What you put in", "money", maps_to="invested_value"),
            Field("valuation_basis", "How you arrived at that", "text",
                  help="A recent round, a multiple of profit, a guess. Worth noting."),
        ],
    },
    "other": {
        "label": "Something else",
        "hint": "Anything you want counted that does not fit above.",
        "fields": _base() + [
            Field("invested_value", "What you paid", "money", maps_to="invested_value"),
            Field("description", "What is it", "text"),
        ],
    },
}



# What somebody owes, offered alongside what they own.
#
# Not in ASSET_FORMS because it is not an asset and writes somewhere else. On
# the same page because that is where somebody is already telling us about the
# things a statement cannot see -- and a home loan is exactly that: something
# nothing else will report on their behalf.
DEBT_FORMS: dict[str, dict] = {
    "home_loan": {
        "label": "Home loan",
        "hint": "Against a flat, house or land.",
        "owed": True,
    },
    "car_loan": {
        "label": "Vehicle loan",
        "hint": "Car, two-wheeler, or anything financed.",
        "owed": True,
    },
    "personal_loan": {
        "label": "Personal loan",
        "hint": "Unsecured, usually the dearest kind after a card.",
        "owed": True,
    },
    "education_loan": {
        "label": "Education loan",
        "hint": "For your own study or somebody else's.",
        "owed": True,
    },
    "credit_card": {
        "label": "Credit card balance",
        "hint": "What is carried month to month, not what is spent and cleared.",
        "owed": True,
    },
    "gold_loan": {
        "label": "Gold loan",
        "hint": "Borrowed against jewellery.",
        "owed": True,
    },
    "loan_against_securities": {
        "label": "Loan against securities",
        "hint": "Borrowed against shares or funds you hold.",
        "owed": True,
    },
    "business_loan": {
        "label": "Business loan",
        "hint": "For a business you run.",
        "owed": True,
    },
    "other_loan": {
        "label": "Something else owed",
        "hint": "Any other borrowing you want counted.",
        "owed": True,
        "kind": "other",
    },
}



# Cover, offered alongside what somebody owns and owed.
#
# Insurance was an asset class here, which let a term policy's sum assured in
# as wealth -- three and a half crore of promise counted as money on one real
# account. It is not an asset and it is not a liability; it is a third thing,
# and giving it a third group is the only way to stop somebody entering it as
# the first.
PROTECTION_FORMS: dict[str, dict] = {
    "term_life": {
        "label": "Term life cover",
        "hint": "Pure protection. Pays out if you are not here, worth nothing "
                "while you are.",
        "protection": True,
    },
    "health": {
        "label": "Health cover",
        "hint": "A family floater or an individual policy.",
        "protection": True,
    },
    "critical_illness": {
        "label": "Critical illness cover",
        "hint": "Pays a lump sum on diagnosis.",
        "protection": True,
    },
    "endowment": {
        "label": "Endowment or money-back policy",
        "hint": "Has a surrender value as well as a cover amount. Both are "
                "asked for, and only the surrender value counts as wealth.",
        "protection": True,
        "has_value": True,
    },
    "ulip": {
        "label": "ULIP",
        "hint": "Unit-linked. Has a fund value as well as a cover amount, and "
                "only the fund value counts as wealth.",
        "protection": True,
        "has_value": True,
    },
}


def protection_fields(has_value: bool = False) -> list:
    """What to ask about a policy.

    The cover amount is asked for first and labelled as a payout, because the
    natural thing to type into a box marked "value" is the sum assured -- which
    is how this went wrong.
    """
    fields = [
        {"name": "cover_amount", "label": "Cover amount", "type": "money",
         "required": True,
         "help": "What it pays out. This is never counted as part of your "
                 "wealth — it is a promise, not money you hold."},
        {"name": "annual_premium", "label": "Premium a year", "type": "money",
         "help": "What it costs to keep."},
        {"name": "insurer", "label": "Who it is with", "type": "text",
         "help": "Optional."},
        {"name": "covers", "label": "Who it covers", "type": "text",
         "help": "Yourself, your family, whoever is named."},
    ]
    if has_value:
        fields.insert(1, {
            "name": "surrender_value", "label": "What it is worth today",
            "type": "money",
            "help": "The surrender or fund value. This part does count as "
                    "wealth. Leave blank if you do not know it."})
    return fields


def debt_fields() -> list:
    """The same four questions for every kind of debt.

    The rate is the one that matters most and is the one people least often
    know, so it says why it is being asked rather than sitting there unlabelled.
    """
    return [
        {"name": "outstanding", "label": "Still owed", "type": "money",
         "required": True,
         "help": "The balance now, not what you originally borrowed."},
        {"name": "rate_pct", "label": "Rate a year", "type": "percent",
         "help": "This decides which debt to clear first. A card at 42% is a "
                 "guaranteed 42% cost, and no fund promises that."},
        {"name": "monthly_emi", "label": "Monthly payment", "type": "money",
         "help": "What leaves your account each month."},
        {"name": "lender", "label": "Who it is with", "type": "text",
         "help": "Optional."},
    ]


def forms() -> dict:
    """Everything somebody can record by hand, owned and owed.

    Debts carry `owed: True` so the page knows to send them somewhere else. The
    alternative -- a separate endpoint and a separate page -- puts a home loan
    two clicks further from the flat it was borrowed against, which is the one
    moment somebody would think to record it.
    """
    both = {
        key: {
            "label": spec["label"],
            "hint": spec["hint"],
            "fields": [f.as_dict() for f in spec["fields"]],
        }
        for key, spec in ASSET_FORMS.items()
    }

    for key, spec in PROTECTION_FORMS.items():
        both[key] = {
            "label": spec["label"],
            "hint": spec["hint"],
            "protection": True,
            "protection_kind": key,
            "fields": protection_fields(spec.get("has_value", False)),
        }

    fields = debt_fields()
    for key, spec in DEBT_FORMS.items():
        both[key] = {
            "label": spec["label"],
            "hint": spec["hint"],
            "owed": True,
            "debt_kind": spec.get("kind", key),
            "fields": fields,
        }
    return both



# ---------------------------------------------------------------------------
# Finding an instrument as the investor types
# ---------------------------------------------------------------------------

# Below this, the query is too vague to rank usefully and would return whatever
# happens to sort first.
MIN_QUERY = 2
MAX_RESULTS = 12

# An ISIN is unmistakable on sight, which is what makes it safe to resolve
# without asking: twelve characters, starting IN, and unique to one security.
ISIN_PATTERN = re.compile(r"^IN[A-Z0-9]{10}$", re.I)


def search_instruments(query: str, asset_class: Optional[str] = None,
                       investor_id: Optional[str] = None) -> list[dict]:
    """Instruments matching what has been typed so far.

    Two things make this worth doing properly rather than a LIKE.

    Something the investor already holds ranks first. If they are adding to an
    existing position, matching it to the instrument already in their portfolio
    is what keeps one holding as one holding -- typing "HDFC Flexi" freehand and
    creating a second instrument is how a net worth quietly doubles.

    Matching is on a flattened form of the name, so "l and t" finds "L&T" and
    "hdfcflexi" finds "HDFC Flexi Cap". Fund names are long, similar to each
    other, and nobody types them in full.
    """
    cleaned = _searchable(query or "")
    if len(cleaned) < MIN_QUERY:
        return []

    conditions = ["s.is_active", "s.search_text %% %(q)s OR s.search_text LIKE %(like)s"]
    params: dict = {"q": cleaned, "like": f"%{cleaned}%", "limit": MAX_RESULTS}

    if asset_class:
        conditions.insert(1, "s.asset_class = %(asset_class)s")
        params["asset_class"] = asset_class

    where = " AND ".join(f"({c})" for c in conditions)

    # `held` is the ordering that matters: an instrument the investor already
    # owns comes before an identical-looking one they do not.
    held_join = ""
    if investor_id:
        held_join = """
            LEFT JOIN (
                SELECT DISTINCT i.isin, i.name
                FROM v_current_holdings v JOIN instruments i ON i.id = v.instrument_id
                WHERE v.investor_id = %(investor_id)s
            ) mine ON (mine.isin IS NOT NULL AND mine.isin = s.isin)
        """
        params["investor_id"] = investor_id

    held_select = "mine.isin IS NOT NULL AS already_held" if investor_id else "false AS already_held"

    return db.fetch_all(
        f"""
        SELECT s.name, s.isin, s.symbol, s.native_code, s.issuer,
               s.asset_class, s.category, s.exchange, {held_select},
               similarity(s.search_text, %(q)s) AS score
        FROM searchable_instruments s
        {held_join}
        WHERE {where}
        ORDER BY already_held DESC,
                 -- An exact ticker beats everything. Somebody typing INFY means
                 -- Infosys, not a company whose name happens to contain it.
                 (lower(coalesce(s.symbol,'')) = %(q)s) DESC,
                 -- Then an exact name.
                 (s.search_text = %(q)s) DESC,
                 -- Then a name that starts with what was typed. Without this,
                 -- "reliance" returned Reliance Power over Reliance Industries
                 -- and "tata motors" returned Tata Motors Passenger Vehicles:
                 -- trigram similarity rewards a longer match, but a person
                 -- typing a company's common name means the company itself.
                 (s.search_text LIKE %(q)s || '%%') DESC,
                 -- Length before score, not after. Trigram similarity rewards
                 -- a longer overlap, so "icici" preferred ICICIAMC over ICICI
                 -- Bank and "tata motors" preferred the Passenger Vehicles
                 -- spin-off. When two names both begin with what was typed,
                 -- the shorter is nearly always the company meant.
                 length(s.name),
                 score DESC
        LIMIT %(limit)s
        """,
        params,
    )


def _searchable(text: str) -> str:
    """Flatten a name or a query into a comparable form.

    Ampersands become the word "and" rather than disappearing, because people
    type both: "L&T India Value" and "L and T India Value" are the same fund,
    and so are "Large & Mid Cap" and "Large and Mid Cap". Dropping the
    ampersand entirely left those as "l t" and "l and t", which never matched.
    """
    import re
    text = (text or "").lower().replace("&", " and ")
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


# ---------------------------------------------------------------------------
# Recording one
# ---------------------------------------------------------------------------


def _decimal(value) -> Optional[Decimal]:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value))
    except Exception:
        return None


def add_holding(investor_id: str, asset_class: str, values: dict) -> dict:
    """Record something the investor has told us about.

    It goes through the same tables as an imported holding, so everything
    downstream -- allocation, findings, net worth -- treats it identically. The
    only difference is the source, which is how we can later say which figures
    came from a statement and which from the person's own account of it.
    """
    spec = ASSET_FORMS.get(asset_class)
    if spec is None:
        raise ValueError(f"We do not have a form for {asset_class}.")

    name = (values.get("name") or "").strip()
    if not name:
        raise ValueError("Give it a name, so you can recognise it later.")

    current_value = _decimal(values.get("current_value"))
    if current_value is None:
        raise ValueError("We need to know what it is worth to count it.")
    if current_value < 0:
        raise ValueError("A value cannot be negative.")

    as_of = values.get("as_of") or date.today().isoformat()
    invested = _decimal(values.get("invested_value"))
    quantity = _decimal(values.get("quantity")) or Decimal(1)

    # What each unit cost. A file gives it directly; otherwise it divides out
    # of the total. Worth keeping as its own column because the total cannot be
    # recovered from it once a position is added to, and every return figure
    # downstream wants the per-unit number.
    avg_cost = _decimal(values.get("avg_cost"))
    if avg_cost is None and invested and quantity > 0:
        avg_cost = invested / quantity

    # Everything the form collected that is not a column of its own. Kept so
    # nothing the investor bothered to tell us is discarded.
    column_fields = {f.name for f in spec["fields"] if f.maps_to != "attribute"}
    column_fields.add("avg_cost")
    attributes = {k: v for k, v in values.items()
                  if k not in column_fields and v not in (None, "")}
    attributes["entered_by_investor"] = True

    with db.connection() as conn:
        with conn.transaction():
            # One account per asset class, so manual entries group sensibly
            # rather than each becoming its own account.
            account = conn.execute(
                """
                INSERT INTO accounts (investor_id, source, account_kind, account_number,
                                      account_label, institution)
                VALUES (%s, 'manual', %s, NULL, %s, %s)
                ON CONFLICT (investor_id, account_kind, coalesce(account_number, ''))
                DO UPDATE SET updated_at = now()
                RETURNING id
                """,
                (investor_id, f"manual_{asset_class}", spec["label"],
                 (values.get("institution") or "").strip() or None),
            ).fetchone()

            # Where the investor picked something from the search, its ISIN
            # comes with it -- and if we already hold that security, this must
            # attach to the same instrument rather than making a second one.
            isin = (values.get("isin") or "").strip() or None
            instrument = None
            if isin:
                instrument = conn.execute(
                    "SELECT id FROM instruments WHERE isin = %s", (isin,)
                ).fetchone()

            if instrument is None:
                instrument = conn.execute(
                    """
                    INSERT INTO instruments (asset_class, name, symbol, isin, issuer,
                                             native_code, attributes)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (asset_class, name,
                     (values.get("symbol") or "").strip() or None,
                     isin,
                     (values.get("institution") or "").strip() or None,
                     (values.get("native_code") or "").strip() or None,
                     __import__("json").dumps({"entered_by_investor": True})),
                ).fetchone()

            conn.execute(
                """
                INSERT INTO holding_snapshots
                    (investor_id, account_id, instrument_id, as_of, source,
                     quantity, current_value, invested_value, avg_cost, attributes)
                VALUES (%s, %s, %s, %s, 'manual', %s, %s, %s, %s, %s)
                ON CONFLICT (account_id, instrument_id, as_of, source)
                DO UPDATE SET quantity = EXCLUDED.quantity,
                              current_value = EXCLUDED.current_value,
                              invested_value = EXCLUDED.invested_value,
                              avg_cost = EXCLUDED.avg_cost,
                              attributes = EXCLUDED.attributes
                """,
                (investor_id, account["id"], instrument["id"], as_of,
                 quantity, current_value, invested, avg_cost,
                 __import__("json").dumps(attributes, default=str)),
            )

    return {"instrument_id": instrument["id"], "account_id": account["id"],
            "asset_class": asset_class, "name": name,
            "current_value": str(current_value)}


def list_manual(investor_id: str) -> list[dict]:
    """Everything this investor has entered themselves.

    Separated from imported holdings in the interface so they can be corrected:
    a statement is a record, but a manual entry is somebody's estimate and will
    go stale.
    """
    return db.fetch_all(
        """
        SELECT h.id, h.instrument_id, i.name, i.asset_class, h.quantity,
               h.current_value, h.invested_value, h.as_of, h.attributes,
               a.institution
        FROM v_current_holdings h
        JOIN instruments i ON i.id = h.instrument_id
        JOIN accounts a ON a.id = h.account_id
        WHERE h.investor_id = %s AND h.source = 'manual'
        ORDER BY h.current_value DESC
        """,
        (investor_id,),
    )


def remove_holding(investor_id: str, instrument_id: str) -> bool:
    """Delete a manual entry.

    Only manual ones. An imported holding is a record of what a statement said,
    and deleting it would leave the platform disagreeing with the document
    without any trace of why.
    """
    row = db.fetch_one(
        """
        DELETE FROM holding_snapshots h
        USING accounts a
        WHERE h.account_id = a.id
          AND h.investor_id = %s
          AND h.instrument_id = %s
          AND h.source = 'manual'
        RETURNING h.id
        """,
        (investor_id, instrument_id),
    )
    return row is not None


# ---------------------------------------------------------------------------
# Resolving a name from a file
# ---------------------------------------------------------------------------

# A search returns candidates for a person to choose between. A file import has
# nobody to ask at the moment it runs, so it needs a different rule: resolve
# only when the answer is not in doubt, and hand back everything else as a
# question.
#
# The temptation is to pick the best match and move on. Five separate times in
# this build a confident match has turned out to be the wrong instrument, and
# in a file of forty holdings nobody would notice one of them being priced as a
# different company. So: exact identifiers resolve, everything else asks.


def resolve_for_import(identifier: str, asset_class: str = "equity") -> dict:
    """Work out which instrument a line in a file refers to.

    Delegates to the identity table, which holds every way an instrument can be
    named -- ISIN, broker token, NSE and BSE symbols, company name -- with a
    stated order of trust, and refuses when two of them disagree.

    Kept as a thin wrapper because callers want the older shape: a status, a
    match, and candidates. The judgement all lives in one place now, rather
    than in two resolvers that would drift.
    """
    from . import identity as identity_service

    text = (identifier or "").strip()
    if not text:
        return {"status": "unknown", "query": identifier, "candidates": [],
                "why": "there was nothing to identify it by"}

    # Funds are a different universe and are not in the identity table, which
    # holds listed companies. They resolve against the scheme master.
    if asset_class == "mutual_fund":
        return _resolve_scheme(text)

    # A file gives one string per row and does not say what kind it is. Passing
    # it as both a symbol and a name is wrong in one direction: a ticker is
    # upper case and unspaced, so "Apollo" resolved as the ticker APOLLO rather
    # than asking which Apollo was meant.
    looks_like_isin = bool(ISIN_PATTERN.match(text))
    looks_like_symbol = bool(re.fullmatch(r"[A-Z0-9&.\-]{1,20}", text))

    verdict = identity_service.resolve(
        isin=text if looks_like_isin else None,
        symbol=text if (looks_like_symbol and not looks_like_isin) else None,
        name=None if looks_like_isin else text,
    )

    if verdict.status == "resolved":
        found = verdict.identity
        return {
            "status": "resolved",
            "query": text,
            "match": {
                "name": found["company_name"],
                "isin": found["isin"],
                "symbol": found["nse_symbol"],
                "native_code": found["nse_symbol"],
                "asset_class": "equity",
            },
            "how": verdict.by,
        }

    if verdict.status == "conflicted":
        # Two identifiers naming different companies. Not a thing to guess at.
        return {
            "status": "ambiguous",
            "query": text,
            "candidates": [],
            "why": verdict.why,
            "conflict": verdict.conflict,
        }

    if verdict.status == "ambiguous":
        return {
            "status": "ambiguous",
            "query": text,
            "candidates": [
                {"name": c["company_name"], "isin": c["isin"],
                 "symbol": c["nse_symbol"], "native_code": c["nse_symbol"],
                 "asset_class": "equity"}
                for c in (verdict.candidates or [])
            ],
            "why": verdict.why,
        }

    return {"status": "unknown", "query": text, "candidates": [],
            "why": verdict.why or "we could not find anything by that name"}


def _resolve_scheme(text: str) -> dict:
    """A mutual fund, from the scheme master rather than the company one."""
    if ISIN_PATTERN.match(text):
        row = db.fetch_one(
            "SELECT name, isin, symbol, native_code, asset_class "
            "FROM searchable_instruments WHERE isin = %s AND asset_class = 'mutual_fund' "
            "LIMIT 1",
            (text.upper(),),
        )
        if row:
            return {"status": "resolved", "query": text, "match": row, "how": "ISIN"}
        return {"status": "unknown", "query": text, "candidates": [],
                "why": "that ISIN is not in the scheme list"}

    candidates = search_instruments(text, "mutual_fund")
    if not candidates:
        return {"status": "unknown", "query": text, "candidates": [],
                "why": "we could not find a scheme by that name"}

    cleaned = _searchable(text)
    exact = [c for c in candidates if _searchable(c["name"]) == cleaned]
    if len(exact) == 1:
        return {"status": "resolved", "query": text, "match": exact[0], "how": "exact name"}

    return {"status": "ambiguous", "query": text, "candidates": candidates[:5],
            "why": f"{len(candidates)} schemes could be what you meant"}
