"""Where the market is, and what has followed readings like it.

The line between useful and irresponsible here is narrow and worth stating.

Useful: "the market is four per cent off its high; across the history we hold,
the twelve months after readings like that were positive seventy-eight per cent
of the time." That is counted, checkable, and it tells somebody what the range
of outcomes has looked like.

Irresponsible: "the market looks stretched, expect a correction." Nobody can
support it, it will be right often enough to feel vindicated and wrong often
enough to cost somebody money, and under a broker's licence it is the one thing
here that could genuinely do harm.

So: base rates only, always with the sample size attached, and never a
direction. Where the sample is too thin to say anything the section says so.

The history is NIFTYBEES from April 2021 -- around 1,300 trading days. That is
one market cycle and a bit, which supports a statement about what has happened
and does not support a claim about what is likely. Every figure carries how many
windows it was counted from so a reader can weigh it themselves.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.market")

BENCHMARK = "NIFTYBEES"

# A year of trading days, near enough. Used to look forward from a past day.
YEAR = 250

# Below this the base rate is a coincidence with a percentage sign.
MIN_WINDOWS = 60

# How close a past reading has to be to today's to count as similar.
SIMILAR_WITHIN = Decimal("3")     # percentage points from the high


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _series() -> list[tuple[date, Decimal]]:
    rows = db.fetch_all(
        "SELECT trade_date, close FROM benchmark_daily WHERE symbol = %s "
        "ORDER BY trade_date",
        (BENCHMARK,),
    )
    return [(r["trade_date"], _d(r["close"])) for r in rows if _d(r["close"]) > 0]


def where_we_are() -> Optional[dict]:
    """The market's own position, described rather than judged.

    Three readings, all facts: how far off its high, where in its year's range,
    and how it has moved over three windows. No view about whether any of that
    is good.
    """
    points = _series()
    if len(points) < YEAR:
        return None

    closes = [p[1] for p in points]
    latest_date, latest = points[-1]

    peak = max(closes)
    peak_date = points[closes.index(peak)][0]
    off_peak = (latest - peak) / peak * 100

    year = [p for p in points if p[0] >= latest_date - timedelta(days=365)]
    year_closes = [p[1] for p in year] or closes
    high, low = max(year_closes), min(year_closes)
    span = high - low
    in_range = ((latest - low) / span * 100) if span > 0 else None

    def move(days: int) -> Optional[Decimal]:
        cutoff = latest_date - timedelta(days=days)
        earlier = [p for p in points if p[0] <= cutoff]
        if not earlier:
            return None
        then = earlier[-1][1]
        return ((latest - then) / then * 100) if then > 0 else None

    return {
        "as_of": latest_date.isoformat(),
        "level": str(latest.quantize(Decimal("0.01"))),
        "off_peak_pct": str(off_peak.quantize(Decimal("0.1"))),
        "peak_on": peak_date.isoformat(),
        "in_year_range_pct": (str(in_range.quantize(Decimal("0.1")))
                              if in_range is not None else None),
        "year_high": str(high.quantize(Decimal("0.01"))),
        "year_low": str(low.quantize(Decimal("0.01"))),
        "moves": {
            "three_months": _fmt(move(91)),
            "twelve_months": _fmt(move(365)),
            "three_years": _fmt(move(1095)),
        },
        "history_from": points[0][0].isoformat(),
        "sessions": len(points),
        "reading": _describe_position(off_peak, in_range, move(365)),
    }


def _fmt(value: Optional[Decimal]) -> Optional[str]:
    return str(value.quantize(Decimal("0.1"))) if value is not None else None


def _describe_position(off_peak: Decimal, in_range: Optional[Decimal],
                       year_move: Optional[Decimal]) -> str:
    if off_peak >= Decimal("-1"):
        where = "at its high"
    elif off_peak >= Decimal("-5"):
        where = f"{abs(off_peak):.0f}% off its high"
    elif off_peak >= Decimal("-15"):
        where = f"{abs(off_peak):.0f}% below its high"
    else:
        where = f"{abs(off_peak):.0f}% below its high, which is a real fall"

    parts = [f"The market is {where}."]
    if year_move is not None:
        direction = "up" if year_move > 0 else "down"
        parts.append(f"Over a year it is {direction} {abs(year_move):.0f}%.")
    return " ".join(parts)


def what_followed() -> Optional[dict]:
    """What happened in the year after readings like today's.

    Counted from every day in the record that sat a similar distance from its
    running high, then measured forward a year. Overlapping windows, so these
    are not independent observations -- five hundred windows from five years is
    five years of information counted many times, and the figure says so.

    Deliberately not a forecast. It is the range of what has followed, which is
    a different and more honest thing than what will follow.
    """
    points = _series()
    if len(points) < YEAR + MIN_WINDOWS:
        return None

    # Distance from the running high on each day, so a past reading means what
    # it meant at the time rather than in hindsight.
    peak = Decimal(0)
    distance: list[tuple[int, Decimal]] = []
    for index, (_, close) in enumerate(points):
        peak = max(peak, close)
        distance.append((index, (close - peak) / peak * 100))

    today_distance = distance[-1][1]

    outcomes: list[Decimal] = []
    for index, gap in distance:
        if index + YEAR >= len(points):
            break
        if abs(gap - today_distance) > SIMILAR_WITHIN:
            continue
        then = points[index][1]
        later = points[index + YEAR][1]
        if then > 0:
            outcomes.append((later - then) / then * 100)

    if len(outcomes) < MIN_WINDOWS:
        return {
            "countable": False,
            "why": (f"We hold {len(points)} trading days of market history, and "
                    f"only {len(outcomes)} of them sat where the market sits "
                    f"today. That is too few to count a base rate from without "
                    f"the number meaning less than it appears to."),
        }

    outcomes.sort()
    positive = sum(1 for o in outcomes if o > 0)
    median = outcomes[len(outcomes) // 2]
    worst, best = outcomes[0], outcomes[-1]
    lower = outcomes[len(outcomes) // 10]

    return {
        "countable": True,
        "windows": len(outcomes),
        "today_off_peak_pct": str(today_distance.quantize(Decimal("0.1"))),
        "positive_pct": str((Decimal(positive) / Decimal(len(outcomes)) * 100)
                            .quantize(Decimal("0.1"))),
        "median_pct": str(median.quantize(Decimal("0.1"))),
        "worst_pct": str(worst.quantize(Decimal("0.1"))),
        "best_pct": str(best.quantize(Decimal("0.1"))),
        "unlucky_tenth_pct": str(lower.quantize(Decimal("0.1"))),
        "history_from": points[0][0].isoformat(),
        "reading": (
            f"On {len(outcomes)} days in the record the market sat about where "
            f"it sits now. A year later it was higher on "
            f"{positive / len(outcomes) * 100:.0f}% of them, the middle outcome "
            f"was {median:+.0f}%, and the unluckiest tenth were "
            f"{lower:+.0f}% or worse."
        ),
        "caveat": (
            "Counted from about five years of one market, in overlapping "
            "windows -- so these are not five hundred independent observations, "
            "they are five years of history counted many times over. It says "
            "what has followed readings like this. It does not say what will."
        ),
    }


def valuation() -> Optional[dict]:
    """What the largest companies cost, against what they have earned.

    A weighted price to earnings across the hundred largest, which is what
    somebody means by "the market's P/E". Reported without a view: we hold no
    history of this figure, so there is nothing to say about whether it is high
    or low by its own standards, and inventing that comparison would be worse
    than leaving it out.
    """
    row = db.fetch_one(
        """
        WITH ranked AS (
            SELECT pe_ttm, roe,
                   CASE WHEN market_cap > 3000000 THEN market_cap / 10000000
                        ELSE market_cap END AS cap_cr
            FROM company_fundamentals
            WHERE market_cap IS NOT NULL AND market_cap > 0
              AND pe_ttm IS NOT NULL AND pe_ttm BETWEEN 0 AND 500
        ),
        top_hundred AS (SELECT * FROM ranked ORDER BY cap_cr DESC LIMIT 100)
        SELECT sum(pe_ttm * cap_cr) / nullif(sum(cap_cr), 0) AS pe,
               sum(roe * cap_cr) FILTER (WHERE roe IS NOT NULL)
                 / nullif(sum(cap_cr) FILTER (WHERE roe IS NOT NULL), 0) AS roe,
               count(*) AS companies
        FROM top_hundred
        """
    )
    if not row or row["pe"] is None:
        return None

    return {
        "pe": str(_d(row["pe"]).quantize(Decimal("0.1"))),
        "roe": str(_d(row["roe"]).quantize(Decimal("0.1"))) if row["roe"] else None,
        "companies": row["companies"],
        "note": ("The hundred largest companies, weighted by size. We hold no "
                 "history of this figure, so there is nothing here about whether "
                 "it is high or low by its own standards \u2014 only what it is."),
    }


def context() -> dict:
    """The market, for a page that needs to mention it."""
    position = where_we_are()
    if not position:
        return {"readable": False,
                "why": "We do not hold enough market history to say anything yet."}

    return {
        "readable": True,
        "position": position,
        "followed": what_followed(),
        "valuation": valuation(),
        "principle": (
            "Everything here is counted from what has already happened. There is "
            "no forecast in it, and there is not going to be: the honest thing a "
            "record can tell you is the range of what has followed readings like "
            "this one, which is not the same as what will follow this one."
        ),
    }
