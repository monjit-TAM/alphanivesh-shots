"""Joining two investor records that turn out to be one person.

This happens. A statement arrives without a PAN and creates a new record beside
one that already existed; a family shares an email; somebody's name is spelled
differently by two registrars. The fix has to be available, because the
alternative is somebody's wealth permanently split in two -- which is the exact
problem this platform exists to solve.

The merge is deliberately conservative. It moves everything to the surviving
record, folds duplicate accounts together, and leaves a note on the survivor
saying what was absorbed. It does not delete the absorbed record's history: the
source documents stay, so the merge can be explained afterwards.
"""

from __future__ import annotations

import json
from typing import Optional

from .. import db


class MergeRefused(Exception):
    """The merge would lose something, or the caller may not do it."""


def preview(keep_id: str, absorb_id: str) -> dict:
    """What a merge would do, without doing it."""
    rows = db.fetch_all(
        """
        SELECT i.id, i.display_name, i.email, i.pan_last4,
               i.pan_hash IS NOT NULL AS has_pan,
               (SELECT count(*) FROM accounts a WHERE a.investor_id = i.id) AS accounts,
               (SELECT count(*) FROM holding_snapshots h WHERE h.investor_id = i.id) AS snapshots,
               (SELECT count(*) FROM canonical_transactions t WHERE t.investor_id = i.id) AS transactions
        FROM investors i WHERE i.id = ANY(%s)
        """,
        ([keep_id, absorb_id],),
    )
    if len(rows) != 2:
        raise MergeRefused("One of those records does not exist.")

    shared = db.fetch_all(
        """
        SELECT a.account_kind, coalesce(a.account_number,'') AS account_number,
               count(DISTINCT a.investor_id) AS sides
        FROM accounts a
        WHERE a.investor_id = ANY(%s)
        GROUP BY 1, 2
        HAVING count(DISTINCT a.investor_id) > 1
        """,
        ([keep_id, absorb_id],),
    )

    return {
        "records": rows,
        "shared_accounts": [r["account_number"] for r in shared],
        "note": (f"{len(shared)} account(s) appear on both sides and will be folded together."
                 if shared else "No accounts appear on both sides; everything moves across."),
    }


def merge(keep_id: str, absorb_id: str, owner_user_id: str) -> dict:
    """Move everything from one investor onto another.

    Both records must belong to the caller. Merging somebody else's investor
    into your own would be a way of reading their holdings, so ownership is
    checked rather than assumed.
    """
    if keep_id == absorb_id:
        raise MergeRefused("Those are the same record.")

    with db.connection() as conn:
        with conn.transaction():
            owners = conn.execute(
                "SELECT id, owner_user_id, display_name, pan_hash, email "
                "FROM investors WHERE id = ANY(%s) FOR UPDATE",
                ([keep_id, absorb_id],),
            ).fetchall()
            if len(owners) != 2:
                raise MergeRefused("One of those records does not exist.")
            for row in owners:
                if row["owner_user_id"] != owner_user_id:
                    raise MergeRefused("Both records must be yours to merge.")

            keep = next(r for r in owners if r["id"] == keep_id)
            absorb = next(r for r in owners if r["id"] == absorb_id)

            # Accounts that exist on both sides are the same real account seen
            # twice. Their holdings move onto the surviving account and the
            # duplicate goes; anything unique simply changes hands.
            duplicates = conn.execute(
                """
                SELECT k.id AS keep_account, d.id AS drop_account
                FROM accounts k
                JOIN accounts d
                  ON d.investor_id = %s
                 AND d.account_kind = k.account_kind
                 AND coalesce(d.account_number,'') = coalesce(k.account_number,'')
                WHERE k.investor_id = %s
                """,
                (absorb_id, keep_id),
            ).fetchall()

            for pair in duplicates:
                # Move what we can; a snapshot that would collide on
                # (account, instrument, as_of, source) is the same reading twice
                # and can be dropped rather than merged.
                conn.execute(
                    """
                    UPDATE holding_snapshots h SET account_id = %(keep)s, investor_id = %(inv)s
                    WHERE h.account_id = %(drop)s
                      AND NOT EXISTS (
                        SELECT 1 FROM holding_snapshots x
                        WHERE x.account_id = %(keep)s AND x.instrument_id = h.instrument_id
                          AND x.as_of = h.as_of AND x.source = h.source)
                    """,
                    {"keep": pair["keep_account"], "drop": pair["drop_account"], "inv": keep_id},
                )
                conn.execute("DELETE FROM holding_snapshots WHERE account_id = %s",
                             (pair["drop_account"],))
                conn.execute(
                    """
                    UPDATE canonical_transactions t SET account_id = %(keep)s, investor_id = %(inv)s
                    WHERE t.account_id = %(drop)s
                      AND NOT EXISTS (
                        SELECT 1 FROM canonical_transactions x
                        WHERE x.account_id = %(keep)s AND x.external_ref = t.external_ref
                          AND t.external_ref IS NOT NULL)
                    """,
                    {"keep": pair["keep_account"], "drop": pair["drop_account"], "inv": keep_id},
                )
                conn.execute("DELETE FROM canonical_transactions WHERE account_id = %s",
                             (pair["drop_account"],))
                conn.execute("DELETE FROM accounts WHERE id = %s", (pair["drop_account"],))

            # Everything still pointing at the absorbed record moves across.
            for table in ("accounts", "holding_snapshots", "canonical_transactions",
                          "source_documents", "statement_imports", "valuation_history"):
                conn.execute(
                    f"UPDATE {table} SET investor_id = %s WHERE investor_id = %s",
                    (keep_id, absorb_id),
                )
            conn.execute(
                "UPDATE household_members SET investor_id = %s WHERE investor_id = %s "
                "AND NOT EXISTS (SELECT 1 FROM household_members h2 "
                "WHERE h2.investor_id = %s AND h2.household_id = household_members.household_id)",
                (keep_id, absorb_id, keep_id),
            )
            conn.execute("DELETE FROM household_members WHERE investor_id = %s", (absorb_id,))

            # Keep whichever identifiers are stronger. A PAN beats no PAN, and a
            # fuller name beats an email-derived one.
            if not keep["pan_hash"] and absorb["pan_hash"]:
                conn.execute(
                    "UPDATE investors SET pan_hash = %s, pan_last4 = "
                    "(SELECT pan_last4 FROM investors WHERE id = %s) WHERE id = %s",
                    (absorb["pan_hash"], absorb_id, keep_id),
                )
            if len(absorb["display_name"] or "") > len(keep["display_name"] or ""):
                conn.execute("UPDATE investors SET display_name = %s WHERE id = %s",
                             (absorb["display_name"], keep_id))

            conn.execute(
                """
                UPDATE investors
                SET legacy_ref = coalesce(legacy_ref, '{}'::jsonb) || %s::jsonb
                WHERE id = %s
                """,
                (json.dumps({"merged_from": absorb_id,
                             "merged_name": absorb["display_name"]}), keep_id),
            )
            conn.execute("DELETE FROM investors WHERE id = %s", (absorb_id,))

    return {"kept": keep_id, "absorbed": absorb_id,
            "accounts_folded": len(duplicates)}
