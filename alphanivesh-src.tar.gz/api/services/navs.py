"""Daily prices for the schemes people actually hold.

AMFI's own file carries only today's NAV. The mfapi.in service carries the
history -- for a typical scheme, thirteen years of daily prices -- keyed on the
same AMFI scheme code we already store.

Fetched only for instruments somebody holds. There are fourteen thousand
schemes in the search master and about fifty across every portfolio here;
pulling thirteen years for all of them would be tens of millions of rows that
nobody would ever read.
"""

from __future__ import annotations

import logging
import time
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Optional

import httpx

from .. import db

log = logging.getLogger("alphanivesh.navs")

BASE_URL = "https://api.mfapi.in/mf"
TIMEOUT = httpx.Timeout(30.0, connect=10.0)

# The service returns dates as dd-mm-yyyy.
DATE_FORMAT = "%d-%m-%Y"


class NavError(Exception):
    pass


def _parse_date(text: str) -> Optional[date]:
    try:
        return datetime.strptime(text.strip(), DATE_FORMAT).date()
    except (ValueError, AttributeError):
        return None


def _parse_nav(text: str) -> Optional[Decimal]:
    try:
        value = Decimal(str(text).strip())
        return value if value > 0 else None
    except (InvalidOperation, ValueError, AttributeError):
        return None


def fetch_scheme(scheme_code: str) -> dict:
    """Everything the service holds for one scheme.

    Returns the metadata and the price history. The metadata is worth having in
    its own right: it carries the fund house and the real scheme category, which
    is better than the category we otherwise infer from the scheme's name.
    """
    try:
        with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
            response = client.get(f"{BASE_URL}/{scheme_code}")
            response.raise_for_status()
            payload = response.json()
    except httpx.HTTPError as err:
        raise NavError(f"could not reach the price service: {err}")
    except ValueError:
        raise NavError("the price service returned something unreadable")

    if payload.get("status") != "SUCCESS" and not payload.get("data"):
        raise NavError(f"no prices for scheme {scheme_code}")

    meta = payload.get("meta") or {}
    points: list[tuple[date, Decimal]] = []
    for entry in payload.get("data") or []:
        when = _parse_date(entry.get("date"))
        nav = _parse_nav(entry.get("nav"))
        if when and nav:
            points.append((when, nav))

    return {"meta": meta, "points": points}


def store(instrument_id: str, points: list[tuple[date, Decimal]],
          meta: Optional[dict] = None) -> int:
    """Write a price history, replacing anything already held for those dates."""
    if not points:
        return 0

    with db.connection() as conn:
        with conn.transaction():
            # One statement rather than a loop: thirteen years is three thousand
            # rows, and three thousand round trips is a minute of nothing.
            conn.cursor().executemany(
                """
                INSERT INTO nav_history (instrument_id, as_of, nav)
                VALUES (%s, %s, %s)
                ON CONFLICT (instrument_id, as_of)
                DO UPDATE SET nav = EXCLUDED.nav, fetched_at = now()
                """,
                [(instrument_id, when, nav) for when, nav in points],
            )

            earliest = min(p[0] for p in points)
            latest = max(p[0] for p in points)
            conn.execute(
                """
                UPDATE instruments
                SET nav_synced_at = now(),
                    nav_earliest = least(coalesce(nav_earliest, %s), %s),
                    nav_latest = greatest(coalesce(nav_latest, %s), %s),
                    declared_category = coalesce(%s, declared_category),
                    scheme_type = coalesce(%s, scheme_type)
                WHERE id = %s
                """,
                (earliest, earliest, latest, latest,
                 (meta or {}).get("scheme_category"),
                 (meta or {}).get("scheme_type"),
                 instrument_id),
            )
    return len(points)


def nav_on(instrument_id: str, when: date) -> Optional[Decimal]:
    """The price on a date, or the most recent one before it.

    Markets close at weekends and holidays, so an exact match is the exception
    rather than the rule. Taking the last known price before the date asked for
    is what "what was this worth on the 31st" actually means.
    """
    row = db.fetch_one(
        """
        SELECT nav FROM nav_history
        WHERE instrument_id = %s AND as_of <= %s
        ORDER BY as_of DESC LIMIT 1
        """,
        (instrument_id, when),
    )
    return row["nav"] if row else None


def series(instrument_id: str, since: Optional[date] = None) -> list[dict]:
    sql = "SELECT as_of, nav FROM nav_history WHERE instrument_id = %s"
    params: tuple = (instrument_id,)
    if since:
        sql += " AND as_of >= %s"
        params += (since,)
    sql += " ORDER BY as_of"
    return db.fetch_all(sql, params)


def drawdown(instrument_id: str, since: Optional[date] = None) -> Optional[dict]:
    """The worst fall from a peak, and whether it has recovered.

    This is what makes a warning about volatility concrete. "Small caps can fall
    a long way" is an abstraction; "this fund fell 38% in 2020 and took nineteen
    months to get back" is something a person can weigh.
    """
    points = series(instrument_id, since)
    if len(points) < 30:
        return None

    peak = points[0]["nav"]
    peak_date = points[0]["as_of"]
    worst = Decimal(0)
    worst_peak_date = peak_date
    worst_trough_date = peak_date
    recovered_on: Optional[date] = None
    in_drawdown = False

    for point in points:
        nav, when = point["nav"], point["as_of"]
        if nav >= peak:
            if in_drawdown and worst > 0 and recovered_on is None:
                recovered_on = when
            peak, peak_date = nav, when
            in_drawdown = False
            continue

        fall = (peak - nav) / peak * 100
        in_drawdown = True
        if fall > worst:
            worst = fall
            worst_peak_date = peak_date
            worst_trough_date = when
            recovered_on = None

    latest = points[-1]
    months_to_recover = None
    if recovered_on:
        months_to_recover = round((recovered_on - worst_trough_date).days / 30.44)

    return {
        "worst_fall_pct": worst.quantize(Decimal("0.1")),
        "fell_from": worst_peak_date,
        "bottomed": worst_trough_date,
        "recovered_on": recovered_on,
        "months_to_recover": months_to_recover,
        "still_below_peak": recovered_on is None and worst > 0,
        "latest_nav": latest["nav"],
        "latest_date": latest["as_of"],
    }


def value_on(investor_id: str, when: date) -> Optional[Decimal]:
    """What the portfolio was worth on a date, priced rather than remembered.

    Takes each position's units as at that date and multiplies by the price on
    that date. Where a price is missing the snapshot's own value is used, so a
    holding we cannot price still counts rather than silently vanishing from
    somebody's net worth.

    Units are summed across folios first. A fund held in two folios is one
    holding of the combined size, and the view was picking one folio and
    dropping the other -- which lost 4.98 lakh of a real portfolio.
    """
    rows = db.fetch_all(
        """
        WITH latest AS (
            SELECT DISTINCT ON (h.account_id, h.instrument_id)
                   h.account_id, h.instrument_id, h.quantity, h.current_value
            FROM holding_snapshots h
            WHERE h.investor_id = %s AND h.as_of <= %s
            ORDER BY h.account_id, h.instrument_id, h.as_of DESC
        )
        SELECT instrument_id,
               sum(quantity) AS quantity,
               sum(current_value) AS current_value
        FROM latest
        GROUP BY instrument_id
        """,
        (investor_id, when),
    )
    if not rows:
        return None

    total = Decimal(0)
    for row in rows:
        quantity = row["quantity"] or Decimal(0)
        priced = None
        if quantity > 0:
            nav = nav_on(row["instrument_id"], when)
            if nav is not None:
                priced = quantity * nav
        total += priced if priced is not None else (row["current_value"] or Decimal(0))
    return total


def instruments_needing_prices(investor_id: Optional[str] = None) -> list[dict]:
    """Held instruments that have an AMFI code and no prices yet, or stale ones."""
    sql = """
        SELECT DISTINCT i.id, i.name, i.native_code, i.nav_synced_at
        FROM instruments i
        JOIN holding_snapshots h ON h.instrument_id = i.id
        WHERE i.asset_class = 'mutual_fund'
          AND i.native_code IS NOT NULL
          AND i.native_code ~ '^[0-9]+$'
          AND (i.nav_synced_at IS NULL OR i.nav_synced_at < now() - interval '20 hours')
    """
    params: tuple = ()
    if investor_id:
        sql += " AND h.investor_id = %s"
        params = (investor_id,)
    return db.fetch_all(sql, params)


# ---------------------------------------------------------------------------
# Shares
# ---------------------------------------------------------------------------


def price_equities(investor_id: str) -> dict:
    """Bring directly held shares up to today's prices.

    A holdings file says what was paid and when. It cannot say what the position
    is worth now, so an imported share sits at cost until something prices it --
    and a portfolio showing cost as though it were value is wrong in the
    direction that flatters nobody.

    Quotes come in one batch. The single-quote route is cached for fifteen
    seconds and shares an upstream rate limit with every other product on that
    box; looping it for forty holdings would be antisocial.
    """
    from . import dataservice

    # Per account, for the same reason funds are priced per folio: snapshots
    # are keyed on the account, and somebody holding the same share in two
    # demat accounts would otherwise get one priced and one left stale.
    rows = db.fetch_all(
        """
        SELECT DISTINCT ON (h.account_id, h.instrument_id)
               h.instrument_id, i.symbol, h.quantity, h.current_value, h.account_id
        FROM holding_snapshots h
        JOIN instruments i ON i.id = h.instrument_id
        WHERE h.investor_id = %s AND i.asset_class = 'equity'
          AND i.symbol IS NOT NULL AND h.quantity > 0
        ORDER BY h.account_id, h.instrument_id, h.as_of DESC
        """,
        (investor_id,),
    )
    if not rows:
        return {"priced": 0, "skipped": 0}

    symbols = sorted({r["symbol"].upper() for r in rows})

    # Quotes come back short sometimes. The upstream chain ends at Groww, which
    # rate-limits and returns 429 under load, so a symbol missing from one
    # response is usually there in the next -- eleven symbols returned four on
    # one attempt and nine on the next, with no change to the request.
    #
    # Two passes, asking only for what is still missing. Not more: a symbol
    # absent twice is more likely delisted or renamed than unlucky, and hammering
    # a shared rate limit to find out would slow every other product on that box.
    payload: dict = {}
    for attempt in range(2):
        outstanding = [s for s in symbols if s not in payload]
        if not outstanding:
            break
        if attempt:
            time.sleep(1.5)
        try:
            payload.update(dataservice.quotes(outstanding))
        except dataservice.DataServiceError as err:
            if attempt:
                log.warning("could not price shares for %s: %s", investor_id, err)
                if not payload:
                    return {"priced": 0, "skipped": len(rows), "why": str(err)}
            continue

    # The service returns a mapping keyed by symbol under `quotes`; the client
    # unwraps it, so what arrives here is {SYMBOL: {...}} already.
    by_symbol = {str(k).upper(): v for k, v in payload.items() if isinstance(v, dict)}

    priced = skipped = 0
    today = date.today()

    with db.connection() as conn:
        with conn.transaction():
            for row in rows:
                quote = by_symbol.get(row["symbol"].upper())
                price = quote.get("price") if quote else None
                if price in (None, 0):
                    skipped += 1
                    continue
                # Where the price came from, kept with the snapshot. A figure
                # from yesterday's bhavcopy and one from a live feed are worth
                # different amounts of trust, and the difference should survive
                # into anything that reads this later.
                source = str(quote.get("source") or "unknown")
                value = (row["quantity"] or Decimal(0)) * Decimal(str(price))

                # A new snapshot rather than an edit. What the file said the
                # position cost stays on the record; this is what it is worth
                # today, and both are true of different moments.
                conn.execute(
                    """
                    INSERT INTO holding_snapshots
                        (investor_id, account_id, instrument_id, as_of, source,
                         quantity, current_value, invested_value, avg_cost, attributes)
                    SELECT %s, %s, %s, %s, 'quote', %s, %s, h.invested_value, h.avg_cost,
                           coalesce(h.attributes, '{}'::jsonb)
                             || jsonb_build_object('priced_at', %s::text,
                                                   'price_source', %s::text)
                    FROM holding_snapshots h
                    WHERE h.instrument_id = %s AND h.investor_id = %s
                    ORDER BY h.as_of DESC LIMIT 1
                    ON CONFLICT (account_id, instrument_id, as_of, source)
                    DO UPDATE SET quantity = EXCLUDED.quantity,
                                  current_value = EXCLUDED.current_value
                    """,
                    (investor_id, row["account_id"], row["instrument_id"], today,
                     row["quantity"], value, str(price), source,
                     row["instrument_id"], investor_id),
                )
                priced += 1

    return {"priced": priced, "skipped": skipped, "as_of": today}


def equity_drawdown(symbol: str, period: str = "5y") -> Optional[dict]:
    """The worst fall a share has had, from the exchange record.

    Same shape as the fund version, computed from daily closes rather than
    NAVs. Worth having for the same reason: a 23% position in a company that
    has fallen 60% before is a different proposition from one that has never
    fallen 20%, and neither fact means much without the other.

    Two cautions, both from the data rather than the arithmetic. The price
    history is unadjusted, so a split or a bonus appears as a fall that never
    happened -- a 1:1 bonus reads as a 50% drop. Anything steeper than a third
    in a single day is treated as a corporate action and ends the calculation
    rather than corrupting it.
    """
    from . import dataservice

    try:
        payload = dataservice.ohlcv(symbol, period=period)
    except dataservice.DataServiceError:
        return None

    bars = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(bars, list) or len(bars) < 30:
        return None

    points: list[tuple[date, Decimal]] = []
    for bar in bars:
        when = _parse_iso(bar.get("date"))
        close = bar.get("close")
        if when and close:
            try:
                value = Decimal(str(close))
            except (InvalidOperation, ValueError):
                continue
            if value > 0:
                points.append((when, value))
    if len(points) < 30:
        return None
    points.sort()

    peak, peak_date = points[0][1], points[0][0]
    worst = Decimal(0)
    worst_peak_date = worst_trough_date = peak_date
    recovered_on: Optional[date] = None
    in_drawdown = False
    seam_at: Optional[date] = None
    previous = points[0][1]

    for when, price in points:
        # An unadjusted series puts a step where a corporate action was. A
        # third in one day is not a market move on a listed company.
        if previous > 0 and abs((price - previous) / previous) > Decimal("0.33"):
            seam_at = when
            break
        previous = price

        if price >= peak:
            if in_drawdown and worst > 0 and recovered_on is None:
                recovered_on = when
            peak, peak_date = price, when
            in_drawdown = False
            continue

        fall = (peak - price) / peak * 100
        in_drawdown = True
        if fall > worst:
            worst = fall
            worst_peak_date = peak_date
            worst_trough_date = when
            recovered_on = None

    if worst <= 0:
        return None

    months = (round((recovered_on - worst_trough_date).days / 30.44)
              if recovered_on else None)

    return {
        "worst_fall_pct": worst.quantize(Decimal("0.1")),
        "fell_from": worst_peak_date,
        "bottomed": worst_trough_date,
        "recovered_on": recovered_on,
        "months_to_recover": months,
        "still_below_peak": recovered_on is None,
        "latest": points[-1][1],
        "latest_date": points[-1][0],
        # Where the series was cut short by what looks like a split or bonus.
        # Saying so beats reporting a number computed across it.
        "stopped_at_corporate_action": seam_at,
    }


def _parse_iso(text: Any) -> Optional[date]:
    if isinstance(text, date):
        return text
    try:
        return datetime.strptime(str(text)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def price_funds(investor_id: str, on: Optional[date] = None) -> dict:
    """Bring fund holdings up to a day's NAVs.

    `value_on` reprices at read time, which gives a correct total over holdings
    that individually still show what a statement said. On a dashboard that
    reads as a total which does not add up -- and after eleven holdings were
    matched to schemes for the first time, the gap was fourteen lakh.

    Written as snapshots so the view and the total agree, and so anything
    reading a single holding gets the same figure as anything reading the sum.
    """
    when = on or date.today()

    # Per folio, not per instrument. Snapshots are keyed on the account, so
    # pricing a fund held in two folios against the view's single row writes
    # one priced snapshot and leaves the other folio on its statement figure --
    # and the sum then mixes today's price with last quarter's.
    rows = db.fetch_all(
        """
        SELECT DISTINCT ON (h.account_id, h.instrument_id)
               h.account_id, h.instrument_id, h.quantity, h.current_value,
               i.name, i.native_code
        FROM holding_snapshots h
        JOIN instruments i ON i.id = h.instrument_id
        WHERE h.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND h.quantity > 0
        ORDER BY h.account_id, h.instrument_id, h.as_of DESC
        """,
        (investor_id,),
    )
    if not rows:
        return {"priced": 0, "skipped": 0}

    priced = skipped = 0
    with db.connection() as conn:
        with conn.transaction():
            for row in rows:
                nav = db.fetch_one(
                    """
                    SELECT nav, as_of FROM nav_history
                    WHERE instrument_id = %s AND as_of <= %s
                    ORDER BY as_of DESC LIMIT 1
                    """,
                    (row["instrument_id"], when),
                )
                if not nav or not nav["nav"]:
                    skipped += 1
                    continue

                value = Decimal(str(row["quantity"])) * Decimal(str(nav["nav"]))

                conn.execute(
                    """
                    INSERT INTO holding_snapshots
                        (investor_id, account_id, instrument_id, as_of, source,
                         quantity, current_value, invested_value, avg_cost, attributes)
                    SELECT %s, %s, %s, %s, 'quote', %s, %s, h.invested_value,
                           h.avg_cost,
                           coalesce(h.attributes, '{}'::jsonb)
                             || jsonb_build_object('priced_at', %s::text,
                                                   'price_source', 'nav_history',
                                                   'nav_as_of', %s::text)
                    FROM holding_snapshots h
                    WHERE h.instrument_id = %s AND h.investor_id = %s
                      AND h.source <> 'quote'
                    ORDER BY h.as_of DESC LIMIT 1
                    ON CONFLICT (account_id, instrument_id, as_of, source)
                    DO UPDATE SET quantity = EXCLUDED.quantity,
                                  current_value = EXCLUDED.current_value
                    """,
                    (investor_id, row["account_id"], row["instrument_id"], when,
                     row["quantity"], value, str(nav["nav"]),
                     nav["as_of"].isoformat(),
                     row["instrument_id"], investor_id),
                )
                priced += 1

    return {"priced": priced, "skipped": skipped, "as_of": when}


def cost_basis_is_credible(instrument_id: str, quantity: Decimal,
                           invested: Decimal) -> Optional[dict]:
    """Whether a holding's cost could have been paid for the units it has.

    A consolidated statement reports a cost figure per scheme, and for a folio
    that has been partly redeemed that figure is everything ever put in --
    while the units are only what is left. Dividing one by the other gives a
    price per unit nobody ever paid.

    Nippon India Arbitrage showed 2,519 units against a cost of 604,320, which
    is 240 a unit. Arbitrage funds trade between ten and thirty. The holding
    then read as down 95%, which is not what happened: money was taken out.

    Redemptions are not in the transaction record -- the statement gives a
    cost line and no sale -- so the cost of the remaining units cannot be
    computed. What can be done is to notice that the figure is impossible and
    decline to report a gain from it, which beats reporting a loss somebody
    never took.
    """
    if quantity <= 0 or invested <= 0:
        return None

    implied = invested / quantity

    band = db.fetch_one(
        """
        SELECT min(nav) AS low, max(nav) AS high, count(*) AS days
        FROM nav_history WHERE instrument_id = %s
        """,
        (instrument_id,),
    )
    if not band or not band["days"] or band["high"] is None:
        return None

    low = Decimal(str(band["low"]))
    high = Decimal(str(band["high"]))

    # A tenth above the highest NAV the fund has ever reached: nobody paid more
    # than the fund was ever worth, so a cost above that is a cost for units
    # that are no longer there.
    ceiling = high * Decimal("1.1")
    if implied <= ceiling:
        return None

    return {
        "credible": False,
        "implied_cost_per_unit": str(implied.quantize(Decimal("0.01"))),
        "nav_ever_low": str(low.quantize(Decimal("0.01"))),
        "nav_ever_high": str(high.quantize(Decimal("0.01"))),
        "why": ("The cost on the statement works out to "
                f"\u20b9{implied:,.0f} a unit, and this fund has never traded above "
                f"\u20b9{high:,.0f}. That cost is for more units than are held now -- "
                f"some were redeemed, and the statement reports what went in "
                f"without reporting what came out. We cannot say what the "
                f"remaining units cost, so we do not show a gain on this holding."),
    }
