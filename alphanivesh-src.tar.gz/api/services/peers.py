"""Where a fund sits among the ones doing the same job.

A fund returning fourteen per cent is good or poor depending entirely on what
its peers returned, and a platform reporting the fourteen without the
comparison is reporting half a fact. Small-cap funds returned twenty-something
over the last three years; a small-cap fund that returned fourteen was near the
bottom of its category, and its holder should know that rather than feel
pleased.

**Quartiles rather than a rank.** "Rank 34 of 41" is precise and hard to weigh.
"Bottom quartile" is what somebody actually needs to decide anything, and the
rank is there underneath for whoever wants it.

**Against the category, not against everything.** Comparing a debt fund to an
equity fund tells you which asset class did better, which nobody needed a tool
to find out. The comparison that matters is against funds with the same
mandate, which is what the category is.

**On rolling three-year returns rather than the last year.** A fund that had
one good year ranks well on twelve months and badly on the distribution across
every three-year window in its history. The second is harder to game and harder
to be lucky at.

**What this does not do.** It does not predict which quartile a fund will be in
next. Persistence of fund performance is weak, well documented as weak, and a
"forward quartile" would be a forecast dressed as an observation. Where a
competitor shows one, that is what it is.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.peers")

# A category needs enough funds in it for quartiles to mean anything. Below
# this, "top quartile" is two funds and the label flatters.
MIN_PEERS = 8

QUARTILE_NAMES = {
    1: "top quarter",
    2: "second quarter",
    3: "third quarter",
    4: "bottom quarter",
}


def _d(value: Any) -> Optional[Decimal]:
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except Exception:
        return None
    return number if number.is_finite() else None


def for_investor(investor_id: str) -> Optional[dict]:
    """Every fund held, and where it stands among its peers.

    The quartile is computed here from the category's own distribution rather
    than read from a stored rank. Two reasons: the stored rank is populated for
    about two thirds of schemes while the rolling median is there for nearly
    all of them, and a quartile derived from figures we can see is one somebody
    can check.
    """
    from . import dataservice

    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value,
               i.native_code
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0 AND i.native_code ~ '^[0-9]+$'
        ORDER BY v.current_value DESC
        LIMIT 15
        """,
        (investor_id,),
    )
    if not rows:
        return None

    total = sum((_d(r["current_value"]) or Decimal(0) for r in rows), Decimal(0))

    # Each fund's own record first, so we know which categories to fetch.
    mine: list[dict] = []
    for row in rows:
        try:
            payload = dataservice.scheme(str(row["native_code"]))
            fund = (payload or {}).get("scheme") or payload
        except Exception:
            fund = None
        mine.append({"row": row, "fund": fund})

    # Then one call per distinct category rather than one per fund, since a
    # portfolio usually holds several funds doing the same job.
    categories = {(m["fund"] or {}).get("category")
                  for m in mine if (m["fund"] or {}).get("category")}

    distributions: dict[str, list[Decimal]] = {}
    for category in categories:
        try:
            listing = dataservice.mf_screener(category=category, limit=400)
        except Exception:
            continue
        # mf_screener already unwraps to a list; calling .get on it would
        # raise, and the surrounding try would have swallowed that into "no
        # peers found" rather than showing the mistake.
        medians = [_d(f.get("roll3_median")) for f in (listing or [])]
        clean = sorted([m for m in medians if m is not None], reverse=True)
        if len(clean) >= MIN_PEERS:
            distributions[category] = clean

    placed, unplaced = [], []

    for entry in mine:
        row, fund = entry["row"], entry["fund"]
        value = _d(row["current_value"]) or Decimal(0)
        standing = _standing(fund, distributions)

        if not standing:
            unplaced.append({
                "name": row["instrument_name"],
                "value": str(value.quantize(Decimal("1"))),
                "why": ("Not enough funds in its category, or not enough "
                        "history, to place it against peers."),
            })
            continue

        placed.append({
            "name": row["instrument_name"],
            "value": str(value.quantize(Decimal("1"))),
            "share_pct": str((value / total * 100).quantize(Decimal("0.1"))
                             if total > 0 else Decimal(0)),
            **standing,
        })

    if not placed:
        return {
            "computable": False,
            "why": ("None of the funds you hold can be placed against peers — "
                    "either their categories are too small for quartiles to "
                    "mean anything, or we do not hold enough of their history."),
            "unplaced": unplaced,
        }

    bottom = [p for p in placed if p["quartile"] == 4]
    top = [p for p in placed if p["quartile"] == 1]
    weighted_in_bottom = sum(
        (_d(p["value"]) or Decimal(0) for p in bottom), Decimal(0))

    return {
        "computable": True,
        "funds": placed,
        "unplaced": unplaced,
        "in_top": len(top),
        "in_bottom": len(bottom),
        "money_in_bottom": str(weighted_in_bottom.quantize(Decimal("1"))),
        "money_in_bottom_pct": str((weighted_in_bottom / total * 100)
                                   .quantize(Decimal("0.1"))
                                   if total > 0 else Decimal(0)),
        "reading": _reading(placed, top, bottom, weighted_in_bottom, total),
        "method": (
            "Each fund is placed against every other fund in its own category "
            "on rolling three-year returns — the distribution across every "
            "three-year window in its history rather than the last twelve "
            "months. A fund that had one good year ranks well on twelve months "
            "and honestly on this."
        ),
        "what_this_is_not": (
            "This is where a fund has been, not where it will be. Performance "
            "persistence in funds is weak and well documented as weak, so a "
            "forward quartile would be a forecast wearing an observation's "
            "clothes. Bottom quartile is a reason to look, not a reason to sell."
        ),
    }


def _standing(fund: Optional[dict],
              distributions: dict[str, list[Decimal]]) -> Optional[dict]:
    """Which quarter of its category a fund sits in.

    Placed by its rolling median against every peer's, rather than by a stored
    rank. Where two funds have the same median they get the same position,
    which is right -- there is no meaningful ordering between them.
    """
    if not fund:
        return None

    category = fund.get("category")
    median = _d(fund.get("roll3_median"))
    peers = distributions.get(category or "")

    if median is None or not peers:
        return None

    total = Decimal(len(peers))
    if total < MIN_PEERS:
        return None

    # How many peers did better. Rank 1 is best.
    better = sum(1 for p in peers if p > median)
    rank = Decimal(better + 1)

    position = (rank - 1) / total
    quartile = min(4, int(position * 4) + 1)
    p25, p75 = _d(fund.get("roll3_p25")), _d(fund.get("roll3_p75"))
    category_median = peers[len(peers) // 2] if peers else None
    worst = _d(fund.get("roll3_worst"))
    positive = _d(fund.get("roll3_pos_pct"))

    return {
        "category": category,
        "category_median_pct": (str(category_median)
                                if category_median is not None else None),
        "rank": int(rank),
        "of": int(total),
        "quartile": quartile,
        "quartile_name": QUARTILE_NAMES[quartile],
        "percentile": str(((1 - position) * 100).quantize(Decimal("1"))),
        "roll3_median_pct": str(median) if median is not None else None,
        "roll3_worst_pct": str(worst) if worst is not None else None,
        "roll3_positive_pct": str(positive) if positive is not None else None,
        "spread": (f"{p25}% to {p75}%" if p25 is not None and p75 is not None
                   else None),
        "reading": _fund_reading(rank, total, quartile, median, worst),
    }


def _fund_reading(rank: Decimal, total: Decimal, quartile: int,
                  median: Optional[Decimal],
                  worst: Optional[Decimal]) -> str:
    line = f"{int(rank)} of {int(total)} in its category — {QUARTILE_NAMES[quartile]}."

    if median is not None:
        line += (f" The middle three-year stretch returned {median}% a year")
        if worst is not None:
            line += f", and the worst returned {worst}%"
        line += "."

    if quartile == 4:
        line += (" Worth looking at why: a fund in the bottom quarter over "
                 "every three-year window in its history is not having one bad "
                 "run.")
    elif quartile == 1:
        line += " Consistently ahead of the funds doing the same job."

    return line


def _reading(placed: list[dict], top: list[dict], bottom: list[dict],
             money_bottom: Decimal, total: Decimal) -> str:
    if not bottom:
        return (f"None of your {len(placed)} placeable funds sits in the bottom "
                f"quarter of its category"
                + (f", and {len(top)} " +
                   ("is" if len(top) == 1 else "are") + " in the top quarter."
                   if top else "."))

    share = (money_bottom / total * 100) if total > 0 else Decimal(0)
    worst = min(bottom, key=lambda f: -_d(f["value"]))

    return (
        f"{len(bottom)} of your {len(placed)} placeable funds "
        f"{'sits' if len(bottom) == 1 else 'sit'} in the bottom quarter of "
        f"their category — ₹{int(money_bottom):,}, {share:.0f}% of what you "
        f"hold in funds. The largest is {worst['name']}, ranked "
        f"{worst['rank']} of {worst['of']}. That is a reason to look rather "
        f"than a reason to sell: the tax of switching is real and the next "
        f"three years are not the last three."
    )


def commission_meets_quartile(investor_id: str,
                              standing: Optional[dict] = None) -> Optional[dict]:
    """Whether the funds charging commission are also the ones lagging.

    Two findings this platform already makes separately: what the regular plans
    cost, and where each fund ranks against its peers. On two real portfolios
    they turned out to be the same funds -- every bottom-quartile holding was a
    regular plan and every top-quartile one was not.

    That is a stronger sentence than either alone, and it is the kind of thing
    a person notices and a set of independent cards does not. Neither figure
    changes; what changes is that they are said together.

    **What this does not claim.** Not that the commission caused the
    underperformance. A trail of one and a half per cent explains part of a gap
    and rarely all of it, and the direction of causation runs both ways --
    funds sold through distributors are often the ones needing to be sold.
    Saying the two coincide is true and useful; saying one caused the other is
    neither.
    """
    from . import plans

    where = standing or for_investor(investor_id)
    if not where or not where.get("computable"):
        return None

    try:
        commission = plans.summary(investor_id)
    except Exception:
        commission = None

    if not commission or not commission.get("funds"):
        return None

    # Match on name, since the two services key differently. Loose enough to
    # survive "Regular Plan - Growth" against "Regular Growth", strict enough
    # not to match two funds from the same house.
    paying = {}
    for fund in commission["funds"]:
        paying[_key(fund.get("name") or "")] = fund

    overlap = []
    for fund in where["funds"]:
        match = paying.get(_key(fund["name"]))
        if not match:
            continue
        overlap.append({**fund,
                        "commission_a_year": match.get("saving_a_year"),
                        "tax_to_switch": match.get("tax_to_switch")})

    if not overlap:
        return None

    lagging = [f for f in overlap if f["quartile"] >= 3]
    if not lagging:
        return {
            "found": False,
            "reading": ("The funds you pay commission on are holding their own "
                        "against their peers. The commission is still worth "
                        "removing, and it is not compounding a performance "
                        "problem."),
        }

    money = sum((_d(f["value"]) or Decimal(0) for f in lagging), Decimal(0))
    annual = sum((_d(f["commission_a_year"]) or Decimal(0) for f in lagging),
                 Decimal(0))
    worst = min(lagging, key=lambda f: -(_d(f["value"]) or Decimal(0)))

    return {
        "found": True,
        "funds": sorted(lagging, key=lambda f: -(_d(f["value"]) or Decimal(0))),
        "count": len(lagging),
        "money": str(money.quantize(Decimal("1"))),
        "commission_a_year": str(annual.quantize(Decimal("1"))),
        "reading": (
            f"{len(lagging)} of the funds you pay commission on "
            f"{'is' if len(lagging) == 1 else 'are'} also in the bottom half of "
            f"{'its' if len(lagging) == 1 else 'their'} category — "
            f"₹{int(money):,}, costing ₹{int(annual):,} a year in trail. The "
            f"largest is {worst['name']}, ranked {worst['rank']} of "
            f"{worst['of']}."
        ),
        "why_it_matters": (
            "These are two separate findings on this page and they turn out to "
            "be about the same funds. Paying for advice on a holding that is "
            "beating its peers is at least buying something; paying for one "
            "that is not is the worst combination available."
        ),
        "not_a_claim": (
            "This does not say the commission caused the underperformance. A "
            "trail of one and a half per cent explains part of a gap and rarely "
            "all of it, and the causation runs both ways — funds sold hardest "
            "are often the ones that need selling. That the two coincide is "
            "worth knowing; that one caused the other is not something this "
            "can show."
        ),
    }


def _key(name: str) -> str:
    """A loose match between two services that name funds differently.

    One says "SBI Midcap Fund - Regular Plan - Growth" and the other
    "L091G-SBI Midcap Fund-Regular Plan-Growth". Stripping codes, punctuation
    and plan words leaves enough to match on and not so little that two funds
    from the same house collide.
    """
    import re
    text = (name or "").lower()
    text = re.sub(r"^[a-z0-9]+\s*-\s*", "", text)          # leading scheme code
    text = re.sub(r"\b(regular|direct|plan|growth|idcw|dividend|option|"
                  r"fund|scheme)\b", " ", text)
    text = re.sub(r"[^a-z0-9]+", "", text)
    return text[:24]

