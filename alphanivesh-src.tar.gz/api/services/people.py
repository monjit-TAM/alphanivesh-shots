"""Who uses this, and how.

For the people running the platform rather than the people whose money it is.
Two questions it answers: who is here, and is the thing working.

**What this deliberately does not show.** Anybody's holdings, their advice, or
what they asked Ariv. An admin screen that displays somebody's portfolio makes
every employee a person who has seen it, and the audit trail cannot tell the
difference between looking for a reason and looking out of curiosity. What is
here is the shape of somebody's account -- when they joined, whether they got
their statements in, how often they come back -- which is what running the
platform actually requires.

**And the aggregates are the point.** One person's login times tell you nothing
worth knowing. Two hundred people's tell you whether the product is being used,
where somebody stops, and which of the things built this month anybody has
touched. The individual rows exist to answer support questions; the totals
exist to answer whether this is working.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.people")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def everybody(limit: int = 200, search: Optional[str] = None) -> dict:
    """The list, with enough against each to answer a support question.

    Portfolios with no account behind them are included. Most of the ones here
    were loaded directly rather than signed up for, and a screen for running
    the platform that shows only the ones attached to a login shows one row
    out of thirteen.
    """
    where, params = "", []
    if search:
        where = ("WHERE u.email ILIKE %s OR u.full_name ILIKE %s "
                 "OR i.display_name ILIKE %s")
        like = f"%{search}%"
        params = [like, like, like]

    rows = db.fetch_all(
        f"""
        SELECT
            u.id, u.email, u.full_name, u.role, u.created_at,
            u.email_verified_at, u.welcomed_at,
            (SELECT count(*) FROM identity WHERE user_id = u.id) AS providers,
            -- This table has a plain user_id. The sess::jsonb shape belongs
            -- to a different application and was carried over by habit.
            (SELECT max(last_seen_at) FROM sessions
              WHERE user_id = u.id) AS last_session,
            i.id AS investor_id,
            i.display_name,
            (SELECT count(*) FROM v_current_holdings v
              WHERE v.investor_id = i.id AND v.current_value > 0) AS holdings,
            (SELECT coalesce(sum(current_value), 0) FROM v_current_holdings v
              WHERE v.investor_id = i.id AND v.current_value > 0) AS worth,
            (SELECT count(*) FROM advice_ledger a
              WHERE a.investor_id = i.id) AS advice_shown,
            (SELECT max(shown_at) FROM advice_ledger a
              WHERE a.investor_id = i.id) AS last_seen
        FROM users u
        LEFT JOIN investors i ON i.owner_user_id = u.id
        {where}
        ORDER BY u.created_at DESC
        LIMIT {int(limit)}
        """,
        tuple(params) if params else None,
    )

    people = []
    for row in rows:
        joined = row["created_at"]
        last = row["last_seen"] or row["last_session"]
        people.append({
            "user_id": row["id"],
            "email": row["email"],
            "name": row["full_name"] or row["display_name"],
            "role": row["role"],
            "joined": joined.date().isoformat() if joined else None,
            "verified": bool(row["email_verified_at"]),
            "welcomed": bool(row["welcomed_at"]),
            "signs_in_with": ("a provider" if row["providers"]
                              else "a password"),
            "investor_id": row["investor_id"],
            "holdings": row["holdings"] or 0,
            "worth": str(_d(row["worth"]).quantize(Decimal("1"))),
            "advice_shown": row["advice_shown"] or 0,
            "last_seen": last.date().isoformat() if last else None,
            "days_quiet": (date.today() - last.date()).days if last else None,
            # What is missing, so somebody answering a support message can see
            # the state without opening the account.
            "stuck_on": _stuck_on(row),
        })

    # Portfolios nobody signed up for. Loaded directly, which is most of them
    # at this stage, and invisible on a screen that starts from users.
    loose = db.fetch_all(
        """
        SELECT i.id, i.display_name, i.email,
               (SELECT count(*) FROM v_current_holdings v
                 WHERE v.investor_id = i.id AND v.current_value > 0) AS holdings,
               (SELECT coalesce(sum(current_value), 0) FROM v_current_holdings v
                 WHERE v.investor_id = i.id AND v.current_value > 0) AS worth,
               (SELECT count(*) FROM advice_ledger a
                 WHERE a.investor_id = i.id) AS advice_shown,
               (SELECT max(shown_at) FROM advice_ledger a
                 WHERE a.investor_id = i.id) AS last_seen
        FROM investors i
        WHERE i.owner_user_id IS NULL
        ORDER BY 4 DESC
        """)

    for row in loose:
        last = row["last_seen"]
        people.append({
            "user_id": None,
            "email": row["email"],
            "name": row["display_name"],
            "role": "no account",
            "joined": None,
            "verified": False,
            "welcomed": False,
            "signs_in_with": "nobody signs in",
            "investor_id": row["id"],
            "holdings": row["holdings"] or 0,
            "worth": str(_d(row["worth"]).quantize(Decimal("1"))),
            "advice_shown": row["advice_shown"] or 0,
            "last_seen": last.date().isoformat() if last else None,
            "days_quiet": (date.today() - last.date()).days if last else None,
            "stuck_on": ("a portfolio with no account behind it"
                         if (row["holdings"] or 0) else
                         "a portfolio with no account and no holdings"),
        })

    return {
        "count": len(people),
        "with_accounts": len([p for p in people if p["user_id"]]),
        "without": len([p for p in people if not p["user_id"]]),
        "people": people,
    }


def _stuck_on(row: dict) -> Optional[str]:
    """Where somebody stopped, in one phrase.

    Most support questions are a variant of "why does it not show me
    anything", and the answer is nearly always one of these three.
    """
    if not row.get("email_verified_at"):
        return "has not confirmed their address"
    if not row.get("investor_id"):
        return "no portfolio created yet"
    if not (row.get("holdings") or 0):
        return "signed up but never brought holdings in"
    if not (row.get("advice_shown") or 0):
        return "has holdings but has not opened the advice"
    return None


def one(user_id: str) -> Optional[dict]:
    """One person, in more detail. Still no holdings, still no advice text."""
    row = db.fetch_one(
        """
        SELECT u.id, u.email, u.full_name, u.role, u.created_at,
               u.email_verified_at, u.welcomed_at,
               i.id AS investor_id, i.display_name
        FROM users u LEFT JOIN investors i ON i.owner_user_id = u.id
        WHERE u.id = %s
        """,
        (user_id,))
    if not row:
        return None

    providers = db.fetch_all(
        "SELECT provider, email, created_at, last_used_at FROM identity "
        "WHERE user_id = %s", (user_id,))

    mail = db.fetch_all(
        """
        SELECT kind, subject, sent, detail, at FROM mail_log
        WHERE to_address = %s ORDER BY at DESC LIMIT 20
        """,
        (row["email"],))

    visits = []
    if row["investor_id"]:
        visits = db.fetch_all(
            """
            SELECT date_trunc('day', shown_at)::date AS day,
                   count(*) AS records,
                   count(DISTINCT surface) AS surfaces
            FROM advice_ledger WHERE investor_id = %s
            GROUP BY 1 ORDER BY 1 DESC LIMIT 30
            """,
            (row["investor_id"],))

    return {
        "user_id": row["id"],
        "email": row["email"],
        "name": row["full_name"] or row["display_name"],
        "role": row["role"],
        "joined": row["created_at"].isoformat() if row["created_at"] else None,
        "verified_on": (row["email_verified_at"].date().isoformat()
                        if row["email_verified_at"] else None),
        "welcomed": bool(row["welcomed_at"]),
        "providers": [{"provider": p["provider"], "email": p["email"],
                       "linked": p["created_at"].date().isoformat(),
                       "last_used": (p["last_used_at"].date().isoformat()
                                     if p["last_used_at"] else None)}
                      for p in providers],
        "mail": [{"kind": m["kind"], "subject": m["subject"],
                  "sent": m["sent"], "detail": m["detail"],
                  "at": m["at"].isoformat()} for m in mail],
        "visits": [{"day": v["day"].isoformat(), "records": v["records"],
                    "pages": v["surfaces"]} for v in visits],
        "note": ("Holdings, advice and questions asked are deliberately not "
                 "shown here. An admin screen that displays somebody's "
                 "portfolio makes everybody who opens it a person who has seen "
                 "it, and the audit trail cannot tell looking for a reason "
                 "from looking out of curiosity."),
    }


def how_it_is_going(days: int = 30) -> dict:
    """The totals. Whether the thing is being used.

    One person's login times say nothing. Two hundred people's say whether
    this works, where somebody stops, and which of the things built this month
    anybody has touched.
    """
    since = f"now() - interval '{int(days)} days'"

    signups = db.fetch_one(
        f"""
        SELECT count(*) AS total,
               count(*) FILTER (WHERE created_at > {since}) AS recent,
               count(*) FILTER (WHERE email_verified_at IS NOT NULL) AS verified,
               count(*) FILTER (WHERE welcomed_at IS NOT NULL) AS welcomed
        FROM users
        """) or {}

    funnel = db.fetch_one(
        """
        SELECT
          (SELECT count(*) FROM users) AS registered,
          (SELECT count(*) FROM users WHERE email_verified_at IS NOT NULL)
            AS confirmed,
          -- Counted as people rather than portfolios. One person can own
          -- several investors, so counting portfolios produced "5 with
          -- holdings" against "4 registered" -- a funnel where a step is
          -- wider than the one above it, which is not a funnel.
          (SELECT count(DISTINCT i.owner_user_id)
             FROM v_current_holdings v
             JOIN investors i ON i.id = v.investor_id
            WHERE v.current_value > 0 AND i.owner_user_id IS NOT NULL)
            AS with_holdings,
          (SELECT count(DISTINCT i.owner_user_id) FROM advice_ledger a
             JOIN investors i ON i.id = a.investor_id
            WHERE i.owner_user_id IS NOT NULL) AS shown_advice,
          (SELECT count(DISTINCT i.owner_user_id) FROM advice_ledger a
             JOIN investors i ON i.id = a.investor_id
            WHERE a.kind = 'ariv_answer'
              AND i.owner_user_id IS NOT NULL) AS asked_ariv
        """) or {}

    surfaces = db.fetch_all(
        f"""
        SELECT surface, count(*) AS records,
               count(DISTINCT investor_id) AS people
        FROM advice_ledger WHERE shown_at > {since}
        GROUP BY surface ORDER BY 2 DESC
        """)

    returning = db.fetch_one(
        f"""
        WITH visits AS (
          SELECT investor_id, date_trunc('day', shown_at)::date AS day
          FROM advice_ledger WHERE shown_at > {since}
          GROUP BY 1, 2
        )
        SELECT count(DISTINCT investor_id) AS people,
               count(*) AS visit_days,
               round(avg(n), 1) AS days_each
        FROM (SELECT investor_id, count(*) AS n FROM visits
              GROUP BY 1) counted
        """) or {}

    mail = db.fetch_all(
        f"""
        SELECT kind, count(*) AS tried,
               count(*) FILTER (WHERE sent) AS arrived
        FROM mail_log WHERE at > {since} GROUP BY kind ORDER BY 2 DESC
        """)

    registered = int(funnel.get("registered") or 0)
    with_holdings = int(funnel.get("with_holdings") or 0)

    return {
        "over_days": days,
        "signups": {k: int(signups.get(k) or 0) for k in
                    ("total", "recent", "verified", "welcomed")},
        "funnel": [
            {"step": "Registered", "people": registered},
            {"step": "Confirmed their address",
             "people": int(funnel.get("confirmed") or 0)},
            {"step": "Brought holdings in", "people": with_holdings},
            {"step": "Were shown advice",
             "people": int(funnel.get("shown_advice") or 0)},
            {"step": "Asked Ariv something",
             "people": int(funnel.get("asked_ariv") or 0)},
        ],
        "biggest_drop": _biggest_drop(funnel),
        "pages": [dict(s) for s in surfaces],
        "returning": {k: (float(returning[k]) if k == "days_each" and
                          returning.get(k) is not None
                          else int(returning.get(k) or 0))
                      for k in ("people", "visit_days", "days_each")},
        "mail": [dict(m) for m in mail],
        "reading": _how_reading(registered, with_holdings, funnel, days),
    }


def _biggest_drop(funnel: dict) -> Optional[dict]:
    """Where most people stop.

    The one number worth acting on: everything before it is working and
    everything after it is being starved by it.
    """
    steps = [("Registered", int(funnel.get("registered") or 0)),
             ("Confirmed their address", int(funnel.get("confirmed") or 0)),
             ("Brought holdings in", int(funnel.get("with_holdings") or 0)),
             ("Were shown advice", int(funnel.get("shown_advice") or 0))]

    worst, lost = None, 0
    for (name, before), (next_name, after) in zip(steps, steps[1:]):
        if before <= 0:
            continue
        gone = before - after
        if gone > lost:
            worst, lost = (name, next_name, before, after), gone

    if not worst or lost <= 0:
        return None

    name, next_name, before, after = worst
    return {
        "between": f"{name} and {next_name.lower()}",
        "lost": lost,
        "of": before,
        "share_pct": str((Decimal(lost) / before * 100).quantize(Decimal("0.1"))),
        "reading": (f"{lost} of {before} stop between {name.lower()} and "
                    f"{next_name.lower()}. That is the step to fix; everything "
                    f"after it is being starved by it."),
    }


def _how_reading(registered: int, with_holdings: int,
                 funnel: dict, days: int) -> str:
    if not registered:
        return "Nobody has registered yet."

    shown = int(funnel.get("shown_advice") or 0)
    if not with_holdings:
        return (f"{registered} registered and none has brought holdings in. "
                f"Until somebody does, none of the rest of this platform has "
                f"anything to work on.")

    return (f"{registered} registered, {with_holdings} with holdings, {shown} "
            f"shown advice. The gap between the second and third is the one "
            f"worth watching: somebody with holdings and no advice has done "
            f"the hard part and not seen the point of it.")
