"""Who could place this, and what each would mean.

An investor with no adviser of record reached a wall: the orders were ready and
the answer was "nobody is recorded, so no". That is correct and useless. The
question it should ask instead is **who is going to place this**, because that
is a thing somebody can answer.

**Three answers, and they are not equivalent.**

*An adviser they already have.* Nothing to decide.

*An adviser or distributor on this platform.* Choosing one starts a
relationship — they become the adviser of record, they will see the portfolio,
and there are terms to agree. That is a bigger thing than picking a delivery
option and the screen says so.

*Nobody — take the orders elsewhere.* An investor is entitled to read the
analysis and place the trades through their own broker. The platform should
help them do that rather than pretending the only route is through us: a
downloadable order list is worth more than a wall.

**Distributors can place funds only.** An MFD may transact in mutual funds and
may not advise; offering one for an equity order would be offering something
they cannot legally do.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.placing")


def options_for(investor_id: str, orders: list[dict]) -> dict:
    """Who could place these, given what they are.

    The orders matter: a basket with equities in it cannot go through a
    distributor, and saying so before somebody picks one is better than saying
    it after.
    """
    from . import advisers, professionals

    kinds = {(o.get("asset_class") or "equity") for o in orders}
    only_funds = kinds <= {"mutual_fund", "etf"}

    current = advisers.of_record(investor_id)
    choices = []

    if current and current.get("registration_live"):
        choices.append({
            "how": "current",
            "adviser_id": current["adviser_id"],
            "name": current["name"],
            "kind": current["kind"],
            "what_it_means": "Your adviser already. Nothing changes.",
            "ready": True,
        })

    # Everybody registered and active who could take this on.
    rows = db.fetch_all(
        """
        SELECT p.id, p.kind, p.firm_name, p.registration_no,
               (SELECT count(*) FROM client_of c
                 WHERE c.professional_id = p.id AND c.ended_on IS NULL) AS clients
        FROM professional p
        WHERE p.status = 'active'
        ORDER BY p.firm_name
        """)

    for row in rows:
        if current and row["firm_name"] == current.get("name"):
            continue

        # A distributor cannot place equities, and cannot advise at all.
        if row["kind"] == "mfd" and not only_funds:
            continue

        choices.append({
            "how": "new",
            "professional_id": row["id"],
            "name": row["firm_name"],
            "kind": row["kind"],
            "registration_no": row["registration_no"],
            "clients": row["clients"],
            "what_it_means": (
                "They become your adviser of record. They will see what you "
                "hold, and there are terms to agree before anything is placed."
                if row["kind"] in ("ria", "ra") else
                "They can place fund orders for you. They do not advise, so "
                "what you see here stays information rather than a "
                "recommendation."),
            "ready": False,
        })

    # And the answer that needs nobody.
    choices.append({
        "how": "yourself",
        "name": "Place them yourself",
        "what_it_means": (
            "Take the list to your own broker. Nothing is placed from here, "
            "and nothing about your account changes — you get the orders "
            "written out and do what you like with them."),
        "ready": True,
    })

    return {
        "orders": len(orders),
        "only_funds": only_funds,
        "current": current,
        "choices": choices,
        "reading": _reading(current, choices, only_funds),
    }


def _reading(current: Optional[dict], choices: list[dict],
             only_funds: bool) -> str:
    if current:
        return (f"{current['name']} is your adviser of record, so these would "
                f"go through them.")

    real = [c for c in choices if c["how"] == "new"]
    if not real:
        return ("Nobody registered is set up on this platform yet, so the only "
                "route today is to take the orders to your own broker. The "
                "list downloads and reads the same as any other order slip.")

    return (f"Nobody advises you here yet. {len(real)} registered "
            f"{'firm' if len(real) == 1 else 'firms'} could take this on, or "
            f"you can take the orders to your own broker."
            + ("" if only_funds else
               " Distributors are not shown because this includes shares, "
               "which they are not registered to place."))


def as_order_slip(orders: list[dict]) -> str:
    """The orders written out, for somebody placing them elsewhere.

    Plain text on purpose. It gets pasted into a broker's window, read down a
    phone, or printed — and every one of those is worse with a spreadsheet.
    """
    lines = ["Orders", "=" * 46, ""]

    for order in orders:
        side = (order.get("side") or "").upper()
        what = order.get("name") or order.get("symbol") or "?"
        symbol = order.get("symbol") or ""
        quantity = order.get("quantity")
        amount = order.get("amount")

        lines.append(f"{side}  {what}")
        if symbol and symbol != what:
            lines.append(f"      {symbol}")
        if quantity:
            lines.append(f"      {quantity} units")
        elif amount:
            lines.append(f"      Rs.{amount}")
        if order.get("price"):
            lines.append(f"      last seen at Rs.{order['price']}")
        lines.append("")

    lines += [
        "-" * 46,
        "Prices are the last we saw and are not what you will get.",
        "Nothing here has been placed. This is a list to take elsewhere.",
    ]
    return "\n".join(lines)


def everything_actionable(investor_id: str) -> dict:
    """Every order the advice implies, across all asset classes.

    The confirm screen was built from the sell-and-buy block, which is
    equities. Somebody looking at what they are about to do should see the fund
    switches and the harvest sales too -- an instruction list that shows three
    of the seven things is worse than none, because it looks complete.

    Each order says which piece of advice produced it, so the ledger row that
    advised something and the order that acted on it can be put side by side.
    """
    from . import decide as decide_service

    orders: list[dict] = []

    try:
        decision = decide_service.decide(investor_id)
    except Exception as err:                                     # pragma: no cover
        log.error("could not read the decision for %s: %s", investor_id, err)
        return {"orders": [], "why": "Could not work out what to do."}

    for action in decision.get("actions") or []:
        for order in _orders_in(action):
            order["from_action"] = action.get("code")
            order["because"] = action.get("what")
            # What it costs and what could go wrong.
            #
            # The engine says both -- brokerage twice, a day or two out of the
            # market while it settles, an exit load where the scheme has one --
            # and only `what` was being carried, so the caveats were dropped at
            # exactly the screen where somebody decides whether to place it.
            # A page that shows the saving and not the friction is selling.
            order["how"] = action.get("how")
            order["costs"] = action.get("costs")
            order["risk"] = action.get("risk")
            orders.append(order)

    # One instruction per holding.
    #
    # Nothing arbitrated between actions that touch the same thing, so a fund
    # appeared twice: sell it to realise the loss, and switch it to the direct
    # plan. Both are good advice on their own and they cannot both be done --
    # sold, there is nothing left to switch; switched, the loss is not
    # realised. Placed as written, that is two contradictory orders in one
    # basket.
    orders, dropped = _one_each(orders)

    grouped: dict[str, list[dict]] = {}
    for order in orders:
        grouped.setdefault(order.get("asset_class") or "other", []).append(order)

    return {
        "orders": orders,
        "by_class": grouped,
        "count": len(orders),
        # What was set aside, and why. Hiding it would make the engine look
        # more decisive than it is, and the reason is often the more useful
        # half -- somebody may prefer the option we did not take.
        "instead_of": dropped,
        # What is not on the list, and honestly why.
        #
        # This said "a decision rather than a trade" about everything without
        # orders, which was false about most of them -- realising a loss is a
        # trade, and so is rebalancing. The truth was that only one action had
        # been wired, and calling the rest decisions hid that behind a claim
        # about the advice.
        #
        # Two different things now, because they need different answers: one
        # is a decision and needs nothing, the other is a trade we cannot yet
        # turn into an order and needs us to finish the work.
        "not_placeable": [
            {"code": a.get("code"), "what": a.get("what"),
             "kind": "decision" if _is_a_decision(a) else "not_wired",
             "why": ("Nothing to place: this is a judgement about a holding "
                     "rather than a trade."
                     if _is_a_decision(a) else
                     _why_not_wired(a))}
            for a in (decision.get("actions") or [])
            if not _orders_in(a)
        ],
    }


# Actions that ask somebody to decide rather than to trade. Named, because
# the alternative is inferring it from the absence of orders -- which is what
# produced "realising a loss is not a trade".
DECISIONS = {
    "concentration_single", "concentration_sector", "unplanned_class",
    "review_plan", "tell_us_about_you", "set_a_target",
}


# Why a particular trade cannot be turned into an order. Specific where we
# know, because "we cannot do this yet" tells somebody nothing about whether
# it is worth them doing it themselves.
WHY_NOT = {
    "rebalance": ("We can say how much more should be in bonds and cannot name "
                  "one: our instrument list carries shares, gold and "
                  "international funds, and no debt at all. Any bond fund or "
                  "gilt fund would do the job."),
    "hold_something_reachable": ("We can say you have nothing you could reach "
                                 "in a day and cannot name a liquid fund: our "
                                 "instrument list has none. Any liquid or "
                                 "overnight fund would do the job."),
}


def _why_not_wired(action: dict) -> str:
    known = WHY_NOT.get(action.get("code"))
    if known:
        return known
    return ("This is a trade, and we cannot yet turn it into an order you "
            "could place. Until we can, it is here rather than hidden.")


def _is_a_decision(action: dict) -> bool:
    code = action.get("code") or ""
    if code in DECISIONS:
        return True
    # "Decide about" is how the engine words them, and matching the wording
    # catches the ones added since this list was written.
    return (action.get("what") or "").lower().startswith("decide")


# Which instruction wins when two want the same holding.
#
# Lower is stronger. The reasoning:
#
# A switch beats a loss harvest because the switch is permanent and the
# harvest is a one-off -- commission saved every year for as long as the
# holding is kept, against a tax offset taken once. On a holding somebody
# means to keep, the recurring saving is worth more within two years and
# forever afterwards.
#
# A harvest beats a rebalance sale because if the thing is being sold anyway,
# selling the losing part first costs nothing extra and offsets a gain.
WINS = {
    "switch_free": 1,
    "switch": 1,
    "harvest_exemption": 2,
    "harvest_losses": 3,
    "rebalance": 4,
    "restructure": 5,
}


def _one_each(orders: list[dict]) -> tuple[list[dict], list[dict]]:
    """Keep one instruction per holding, and say what was set aside.

    A round trip -- sell and buy back the same instrument from one action --
    is a single intention and stays whole. What is dropped is a *second*
    action wanting the same holding for a different reason.
    """
    by_holding: dict[Any, list[dict]] = {}
    for order in orders:
        key = order.get("instrument_id") or order.get("name")
        by_holding.setdefault(key, []).append(order)

    kept, dropped = [], []

    for key, group in by_holding.items():
        actions = {o.get("from_action") for o in group}
        if len(actions) <= 1:
            kept.extend(group)
            continue

        winner = min(actions, key=lambda a: WINS.get(a, 99))
        for order in group:
            if order.get("from_action") == winner:
                kept.append(order)
            else:
                dropped.append({
                    "name": order.get("name"),
                    "side": order.get("side"),
                    "from_action": order.get("from_action"),
                    "because": order.get("because"),
                    "why_not": _why_not(winner, order.get("from_action")),
                })

    return kept, dropped


def _why_not(winner: str, loser: str) -> str:
    """Why one instruction was preferred, in the terms somebody would weigh.

    Not "the engine ranked it higher" -- the actual trade-off, so a reader who
    disagrees can act on the other one instead.
    """
    if winner in ("switch_free", "switch") and loser == "harvest_losses":
        return ("Switching this to the direct plan saves commission every year "
                "for as long as you hold it. Selling it to realise the loss "
                "saves tax once, and leaves you no longer holding it. Both are "
                "worth doing and only one is possible, so the recurring saving "
                "won.")
    if winner == "harvest_exemption" and loser == "rebalance":
        return ("This is being sold and bought straight back to use the tax "
                "allowance, which leaves the position unchanged. Selling it to "
                "rebalance would change the position, and cannot be done with "
                "the same units.")
    if winner in ("harvest_losses", "harvest_exemption") and loser == "rebalance":
        return ("Selling this realises a loss you can set against a gain. If "
                "it is being sold anyway, doing it for the tax reason first "
                "costs nothing extra.")
    return ("Two suggestions wanted this holding and only one can be acted on. "
            "The other is still worth reading.")


def _orders_in(action: dict) -> list[dict]:
    """The orders an action implies, if any.

    Most actions are not trades. "Decide whether the gold position is
    deliberate" produces nothing to place, and inventing an order for it would
    be worse than showing none.
    """
    # The engine puts them here, having stopped throwing them away.
    if action.get("orders"):
        return list(action["orders"])

    made = []

    for sell in (action.get("sells") or []):
        made.append({
            "instrument_id": sell.get("instrument_id"),
            "symbol": sell.get("symbol"),
            "name": sell.get("name"),
            "side": "sell",
            "quantity": sell.get("quantity"),
            "amount": sell.get("amount") or sell.get("raises"),
            "price": sell.get("price"),
            "est_cost": sell.get("raises") or sell.get("amount"),
            "est_tax": sell.get("tax") or 0,
            "asset_class": sell.get("asset_class") or "equity",
        })

    for buy in (action.get("buys") or []):
        made.append({
            "instrument_id": buy.get("instrument_id"),
            "symbol": buy.get("symbol"),
            "name": buy.get("name"),
            "side": "buy",
            "quantity": buy.get("quantity"),
            "amount": buy.get("amount"),
            "price": buy.get("price"),
            "est_cost": buy.get("amount"),
            "est_tax": 0,
            "asset_class": buy.get("asset_class") or "equity",
        })

    return made
