"""Regular plans, and what switching out of them costs.

A regular plan and a direct plan are the same fund, run by the same manager,
holding the same stocks. The difference is that the regular plan pays a trail
commission to whoever sold it, taken out of the NAV every year, forever. On an
equity fund that is usually between half a per cent and one and a quarter.

That makes it the clearest finding in Indian mutual funds: a cost with nothing
bought by it. Most tools stop there and say switch.

The reason to go further is that switching is not free. It is a redemption and
a fresh purchase, which means capital gains tax today, a new one-year clock
before the next gain qualifies as long term, and any exit load. On a holding
sitting on a large gain, the tax can exceed several years of saved commission --
and telling somebody to switch without saying that is advice that costs them
money.

So both sides, and the years it takes to pay back. Where the answer is longer
than somebody is likely to hold, the honest reading is to leave it alone and
put new money into the direct plan instead.
"""

from __future__ import annotations

import logging
import re
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.plans")

# What a regular plan costs over a direct one, per year, as a share of the
# holding. SEBI caps total expense ratios by fund size and category, and the
# gap between the two plans is the distributor's trail.
#
# These are typical rather than exact: the real figure is in each scheme's own
# disclosure, which we do not hold. Every figure computed from them is stated
# as an estimate, and the finding says so rather than implying a precision it
# does not have.
TRAIL_BY_CATEGORY = {
    "equity": Decimal("1.00"),
    "hybrid": Decimal("0.85"),
    "debt": Decimal("0.50"),
    "index": Decimal("0.30"),
    "elss": Decimal("1.00"),
}
DEFAULT_TRAIL = Decimal("0.90")

# Below this the switch is not worth the paperwork.
MIN_WORTH_SAYING = Decimal("2000")      # rupees a year

LTCG_RATE = Decimal("12.5")
STCG_RATE = Decimal("20")
LTCG_EXEMPT = Decimal("125000")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _plan_of(name: str) -> Optional[str]:
    """Whether a scheme name says regular or direct.

    Only where the word sits next to "plan". A fund called "Regular Savings
    Fund" is a different fund from "Savings Fund", not a plan variant of it,
    and treating the word as a plan marker wherever it appears merges two
    schemes that hold different things.
    """
    text = (name or "").lower()
    if re.search(r"\bdirect\b[\s-]*(plan)?\b", text):
        return "direct"
    # Next to "plan", or next to an option word. "Axis Small Cap Fund -
    # Regular Growth" names no plan and is plainly a regular plan; the rule
    # that only looked beside "plan" missed it and the fund went unreported.
    #
    # Still not a bare "Regular" anywhere in the name, because "ABSL Regular
    # Savings Fund" is a fund rather than a plan variant -- which is the
    # mistake this rule exists to avoid.
    if re.search(r"\bregular\b[\s-]*(plan|growth|idcw|dividend)\b", text):
        return "regular"
    return None


def _core(name: str) -> str:
    """The scheme name with the plan, option and registrar code removed.

    What is left should be identical between the two plans of one scheme, which
    is what makes the pairing mechanical rather than a guess.
    """
    text = (name or "").lower()
    # A registrar code and a fund house are told apart by the spacing, not by
    # whether there is a digit: statements write "HPREG-HDFC Hybrid" and
    # "103G - SBI Large Cap" while AMFI writes "UTI - Flexi Cap Fund".
    #
    # So a code is a short token that either contains a digit, or is followed
    # by a hyphen with no space before it. That keeps "UTI - " (a fund house,
    # spaced) and drops "HPREG-" (a code, unspaced) -- a distinction that looks
    # arbitrary until you see that stripping "UTI" made three different houses'
    # flexi cap funds identical.
    text = re.sub(r"^[a-z]*\d[a-z0-9]*\s*-\s*", "", text)     # has a digit
    text = re.sub(r"^[a-z]{2,8}-(?=[a-z])", "", text)          # unspaced hyphen
    # Only next to "plan". "ABSL Regular Savings Fund" and "ABSL Savings Fund"
    # are different funds -- one hybrid, one ultra-short debt -- and stripping a
    # bare "Regular" merges them, which is the same mistake the holdings ingest
    # documents having made once.
    text = re.sub(r"\b(direct|regular)\b[\s-]*plan\b", " ", text)
    # A trailing "Direct Growth" with no "plan" is still a plan marker, because
    # nothing is called a Direct Fund.
    text = re.sub(r"\bdirect\b(?=[\s-]*(growth|idcw|dividend|$))", " ", text)
    # AMFI writes "Growth Option" where a statement writes "Growth". Leaving
    # "option" behind meant the two names never matched, which is how four
    # funds paying commission went unreported.
    text = re.sub(r"\b(growth|idcw|dividend|payout|reinvestment|monthly|quarterly"
                  r"|option|plan)\b",
                  " ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return text.strip()


def _trail_for(category: Optional[str]) -> Decimal:
    text = (category or "").lower()
    for key, rate in TRAIL_BY_CATEGORY.items():
        if key in text:
            return rate
    return DEFAULT_TRAIL


def find_direct_twin(name: str, category: Optional[str] = None) -> Optional[dict]:
    """The direct plan of the same scheme, where one exists.

    Matched on the scheme name with plan and option words stripped, so
    "PP001RG-Parag Parikh Flexi Cap Fund-Regular Plan Growth" finds "Parag
    Parikh Flexi Cap Fund - Direct Plan - Growth" and not the IDCW variant of
    it, which is a different thing to hold.

    Name matching has a floor it cannot get past. "UTI - Flexi Cap Fund" and
    "FIVFG - HSBC Value Fund" are the same shape, and only knowing that UTI is
    a fund house and FIVFG is a registrar code separates them. This gets the
    common cases and misses that one, which means a fund quietly paying
    commission goes unreported -- an error in the direction of saying too
    little, which is the right direction for it to fail in.

    The reliable version pairs on ISIN: the two plans of one scheme have
    related ISINs and the scheme master holds both. Worth doing when the master
    is next reloaded; until then this is what we have, and it says so.
    """
    core = _core(name)
    if len(core) < 8:
        return None

    # Ordered, not merely limited. The trigram operator matches everything
    # above a threshold and the index returns them in its own order, so a bare
    # LIMIT is a sample of the matches rather than the best of them. The scheme
    # matcher had the same bug: a search for one ICICI fund came back with
    # forty ICICI banking debt funds and never reached the one being looked for.
    candidates = db.fetch_all(
        """
        SELECT name, native_code, isin, category
        FROM searchable_instruments
        WHERE asset_class = 'mutual_fund'
          AND lower(name) LIKE '%%direct%%'
          AND search_text %% %s
        ORDER BY similarity(search_text, %s) DESC
        LIMIT 20
        """,
        (core, core),
    )

    wants_growth = "growth" in (name or "").lower()
    for row in candidates:
        if _core(row["name"]) != core:
            continue
        # Growth and IDCW are different holdings. Switching plan should not
        # quietly switch option as well.
        has_growth = "growth" in row["name"].lower()
        if wants_growth != has_growth:
            continue
        return row
    return None


def switchable(investor_id: str,
               minimum: Optional[Decimal] = None) -> list[dict]:
    """Regular-plan holdings with a direct twin, and what moving would cost.

    Returns the annual saving, the tax due today, and the years to pay back --
    because a switch that takes eleven years to recover its own tax is not a
    saving, it is a fee paid early.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value, v.invested_value,
               i.category, i.native_code,
               (SELECT min(h.as_of) FROM holding_snapshots h
                WHERE h.instrument_id = v.instrument_id
                  AND h.investor_id = v.investor_id
                  AND h.as_of > '1990-01-01') AS bought
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND i.asset_class = 'mutual_fund'
          AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )

    today = date.today()
    out = []

    for row in rows:
        if _plan_of(row["instrument_name"]) != "regular":
            continue

        twin = find_direct_twin(row["instrument_name"], row["category"])
        if not twin:
            continue

        value = _d(row["current_value"])
        trail = _trail_for(row["category"])
        saving = value * trail / 100
        if saving < (minimum if minimum is not None else MIN_WORTH_SAYING):
            continue

        gain = value - _d(row["invested_value"])
        bought = row["bought"]
        short_term = bool(bought and (today - bought).days < 365)
        tax = (gain * (STCG_RATE if short_term else LTCG_RATE) / 100
               if gain > 0 else Decimal(0))

        payback_years = (tax / saving) if saving > 0 else None

        out.append({
            "instrument_id": row["instrument_id"],
            "name": row["instrument_name"],
            "direct_name": twin["name"],
            "direct_code": twin["native_code"],
            "value": str(value.quantize(Decimal("1"))),
            "saving_a_year": str(saving.quantize(Decimal("1"))),
            "trail_pct": str(trail),
            "tax_to_switch": str(tax.quantize(Decimal("1"))),
            "short_term": short_term,
            "payback_years": (str(payback_years.quantize(Decimal("0.1")))
                              if payback_years is not None else None),
            "worth_it": _worth_it(payback_years, short_term, tax),
            "reading": _reading(row["instrument_name"], saving, tax, payback_years,
                                short_term),
        })

    return out


def _worth_it(payback_years: Optional[Decimal], short_term: bool,
              tax: Decimal = Decimal(0)) -> str:
    if payback_years is None:
        return "unclear"
    # Nothing to wait for where there is no tax. A holding bought recently and
    # sitting at a loss was being told to wait for a rate that does not apply
    # to it, while the sentence beside it said there was no reason to keep the
    # regular plan.
    if tax <= 0:
        return "yes"
    if short_term:
        # A gain taxed at 20% that would drop to 12.5% within months is worth
        # waiting for, whatever the payback arithmetic says.
        return "wait"
    if payback_years <= 2:
        return "yes"
    if payback_years <= 5:
        return "probably"
    return "not on this holding"


def _reading(name: str, saving: Decimal, tax: Decimal,
             payback: Optional[Decimal], short_term: bool) -> str:
    """The whole calculation in a sentence somebody can act on."""
    opening = (f"You hold the regular plan. The direct plan is the same fund with "
               f"the same manager, without the commission \u2014 about "
               f"\u20b9{saving:,.0f} a year on this holding.")

    if tax <= 0:
        return opening + (" Switching costs nothing in tax, since this is not in "
                          "profit. There is no reason to keep the regular plan.")

    if short_term:
        return (opening + f" Switching now would trigger \u20b9{tax:,.0f} of tax at "
                f"the short-term rate. Waiting until this passes a year drops that "
                f"to 12.5%, which is worth the delay.")

    if payback is not None and payback <= 2:
        return (opening + f" Switching costs \u20b9{tax:,.0f} in tax today, which the "
                f"saving covers in about {payback:.1f} years. Worth doing.")

    if payback is not None and payback <= 5:
        return (opening + f" Switching costs \u20b9{tax:,.0f} in tax today \u2014 about "
                f"{payback:.1f} years of the saving. Worth it if you are holding "
                f"for the long term, not if you might need this money.")

    return (opening + f" But switching would cost \u20b9{tax:,.0f} in tax now, which "
            f"takes about {payback:.0f} years of saved commission to recover. On "
            f"this holding, leaving it alone and putting new money into the direct "
            f"plan is the better arithmetic.")


def summary(investor_id: str) -> Optional[dict]:
    """The whole picture across every regular-plan holding."""
    found = switchable(investor_id)
    if not found:
        return None

    total_saving = sum(_d(f["saving_a_year"]) for f in found)
    worth_now = [f for f in found if f["worth_it"] in ("yes", "probably")]
    free = [f for f in found if _d(f["tax_to_switch"]) <= 0]

    parts = [f"{len(found)} of your funds are regular plans, costing about "
             f"\u20b9{total_saving:,.0f} a year in commission between them."]
    if free:
        parts.append(f"{len(free)} could be switched with no tax at all.")
    if worth_now and not free:
        parts.append(f"{len(worth_now)} would pay back the switching tax within "
                     f"five years.")
    if len(found) > len(worth_now) + len(free):
        parts.append("The rest carry gains large enough that the tax outweighs the "
                     "saving for now.")

    return {
        "funds": found,
        "count": len(found),
        "total_saving_a_year": str(total_saving.quantize(Decimal("1"))),
        "reading": " ".join(parts),
        "method": ("The commission is estimated from typical trail rates by category "
                   "rather than each scheme's own disclosure, which we do not hold \u2014 "
                   "so treat the rupee figures as close rather than exact. The tax is "
                   "computed from what you actually paid and when."),
    }


def redirect_future(investor_id: str) -> Optional[dict]:
    """Point the next instalment at the direct plan, and leave the rest alone.

    The usual advice on a regular plan is to switch, and switching is a
    redemption: capital gains tax today, a fresh one-year clock, possibly an
    exit load. On an accumulated holding that cost can exceed several years of
    the commission it saves.

    But somebody still contributing has a second option that costs nothing at
    all. A new instalment into the direct plan is a purchase, not a sale. The
    units already held stay where they are, paying commission; every rupee from
    next month pays none.

    It is a smaller saving in year one and a better decision, and it only
    becomes visible once you know somebody is still investing monthly. Nobody
    gets told this because the advice is usually written for a portfolio rather
    than for a person still adding to one.
    """
    from . import behaviour

    how = behaviour.how_they_invest(investor_id)
    if not how or not how.get("readable"):
        return None
    if how["style"] not in ("monthly", "frequent"):
        return None

    # Every regular plan, not only the ones worth switching. The minimum on
    # switchable() guards against telling somebody to sell units and pay tax
    # for a small saving; redirecting a future instalment costs nothing, so
    # there is no threshold it has to clear.
    regular = switchable(investor_id, minimum=Decimal("200"))
    if not regular:
        return None

    # Which regular-plan funds are still being bought into. Switching those is
    # optional; redirecting them is not even a decision.
    # Measured from the end of the record rather than from today. A statement
    # imported in August that runs to February says nothing about March
    # onwards -- and treating that silence as "they stopped" would withhold
    # the advice from exactly the disciplined investor it is worth most to.
    #
    # What the record can show is a standing instruction that was running when
    # the statement was cut. Whether it still runs is a question for the
    # investor, and the reading asks it rather than assuming either way.
    latest = db.fetch_one(
        """
        SELECT max(txn_date) AS last FROM canonical_transactions
        WHERE investor_id = %s AND txn_type = ANY(%s) AND txn_date > '1990-01-01'
        """,
        (investor_id, list(behaviour.BUYING)),
    )
    if not latest or not latest["last"]:
        return None
    record_ends = latest["last"]

    still_buying = db.fetch_all(
        """
        SELECT i.name, count(*) AS purchases, sum(t.amount) AS recent_amount,
               max(t.txn_date) AS last_bought
        FROM canonical_transactions t
        JOIN instruments i ON i.id = t.instrument_id
        WHERE t.investor_id = %s
          AND t.txn_type = ANY(%s)
          AND t.txn_date > %s::date - interval '4 months'
          AND t.amount > 0
        GROUP BY i.name
        """,
        (investor_id, list(behaviour.BUYING), record_ends),
    )
    active = {row["name"]: row for row in still_buying}

    redirectable = []
    monthly_total = Decimal(0)
    for fund in regular:
        row = active.get(fund["name"])
        if not row:
            continue
        # What is going in each month, from the last four months of purchases.
        months = Decimal(4)
        monthly = _d(row["recent_amount"]) / months
        monthly_total += monthly
        redirectable.append({
            **fund,
            "monthly_now": str(monthly.quantize(Decimal("1"))),
            "last_bought": row["last_bought"].isoformat(),
        })

    if not redirectable:
        return None

    trail = Decimal("0.9")
    # A year of redirected contributions saves the commission on roughly half
    # of them, since they arrive through the year rather than at the start.
    first_year = monthly_total * 12 * trail / 100 / 2

    # How old the record is. A statement imported in August that runs to
    # February says nothing about March onwards, and the reading should not
    # claim the instalments are still running when we cannot know it.
    stale_months = ((date.today().year - record_ends.year) * 12
                    + date.today().month - record_ends.month)
    stale = stale_months >= 3

    opening = (
        f"As at {record_ends:%B %Y}, the last month we have a record for, you were "
        f"putting about \u20b9{monthly_total:,.0f} a month into "
        if stale else
        f"You are putting about \u20b9{monthly_total:,.0f} a month into "
    )

    return {
        "funds": redirectable,
        "monthly_redirectable": str(monthly_total.quantize(Decimal("1"))),
        "saves_first_year": str(first_year.quantize(Decimal("1"))),
        "record_ends": record_ends.isoformat(),
        "record_stale_months": stale_months,
        "reading": (
            opening
            + f"{len(redirectable)} regular-plan "
            + f"fund{'s' if len(redirectable) != 1 else ''}. Those instalments can "
            + f"go to the direct plan of the same fund from next month, which "
            + f"costs nothing: a new purchase is not a sale, so there is no tax, "
            + f"no exit load and no fresh holding period. What you already hold "
            + f"can stay where it is."
            + (f" If those instalments have since stopped this does not apply \u2014 "
               f"our record ends {stale_months} months ago."
               if stale else "")
        ),
        "why_this_first": (
            "Switching the units you already hold means selling them, and on a "
            "holding with a gain the tax can exceed several years of the "
            "commission it saves. Redirecting what has not been invested yet "
            "has no cost at all, so it is the part to do first and the part "
            "that needs no arithmetic to justify."
        ),
    }
