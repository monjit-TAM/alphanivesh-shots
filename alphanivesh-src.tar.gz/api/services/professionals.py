"""What somebody is registered as, and what that lets them do.

**RIA and MFD are not the same permission**, and the difference is the point of
this module.

An RIA may advise for a fee. An MFD may not advise at all — they distribute
funds and earn commission, and SEBI treats the two as separate activities. A
platform that gives both the same rights is helping an MFD do something they
are not registered for, and the ledger would record it, which makes it worse
rather than better.

So:

  **RIA** advises. Edits, suppresses and adds to what the engine produced, and
  is the adviser of record on anything their client acts upon.

  **RA** publishes views. Does not advise a specific person on their specific
  portfolio, which is what this platform does, so an RA gets the client list
  and nothing that looks like personal advice.

  **MFD** distributes. Sees their clients and what the engine produced,
  transacts in funds, and does not touch the advice. For their clients the
  platform's output is information rather than advice, and the page says so
  rather than leaving it to be inferred.

**Nothing is granted on a claim.** The certificate is uploaded and a person
looks at it. Self-declaration would mean the first thing this platform knows
about somebody's authority is their own assertion of it, which is not a control.

**And the rights are computed from the registration, never stored on the user.**
A role column would drift from the certificate the moment one lapsed.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.professionals")

KINDS = {
    "ria": {
        "name": "Registered Investment Adviser",
        "advises": True,
        "may_edit_advice": True,
        "may_be_adviser_of_record": True,
        "may_transact": True,
        "what_they_see": ("Everything their clients see, plus the ability to "
                          "change, hold back or add to what the engine "
                          "produced."),
    },
    "ra": {
        "name": "Research Analyst",
        "advises": False,
        "may_edit_advice": False,
        "may_be_adviser_of_record": False,
        "may_transact": False,
        "what_they_see": ("Their clients' positions and what the engine "
                          "produced. A research analyst publishes views; "
                          "advising a specific person on their specific "
                          "portfolio is a different registration."),
    },
    "mfd": {
        "name": "Mutual Fund Distributor",
        "advises": False,
        "may_edit_advice": False,
        "may_be_adviser_of_record": False,
        "may_transact": True,
        "what_they_see": ("Their clients' positions and what the engine "
                          "produced, as information. A distributor may not "
                          "advise, so nothing here is presented to their "
                          "clients as advice and the distributor cannot "
                          "change it."),
    },
}


def for_user(user_id: str) -> Optional[dict]:
    """What this person is registered as, if anything."""
    row = db.fetch_one(
        """
        SELECT p.*, u.email, u.full_name
        FROM professional p JOIN users u ON u.id = p.user_id
        WHERE p.user_id = %s
        """,
        (user_id,))
    if not row:
        return None

    kind = KINDS.get(row["kind"], {})
    lapsed = bool(row["registered_to"] and row["registered_to"] < date.today())
    live = row["status"] == "active" and not lapsed

    return {
        "id": row["id"],
        "kind": row["kind"],
        "kind_name": kind.get("name"),
        "firm_name": row["firm_name"],
        "registration_no": row["registration_no"],
        "arn": row["arn"],
        "registered_to": (row["registered_to"].isoformat()
                          if row["registered_to"] else None),
        "status": "lapsed" if lapsed else row["status"],
        "checked_at": (row["checked_at"].isoformat()
                       if row["checked_at"] else None),
        "has_certificate": bool(row["certificate_path"]),

        # Computed from the registration every time, never stored on the user.
        # A role column would drift from the certificate the moment one
        # lapsed.
        "may_edit_advice": live and kind.get("may_edit_advice", False),
        "may_be_adviser_of_record": live and kind.get(
            "may_be_adviser_of_record", False),
        "may_transact": live and kind.get("may_transact", False),
        "advises": live and kind.get("advises", False),

        "what_they_see": kind.get("what_they_see"),
        "standing": _standing(row["status"], lapsed, bool(row["certificate_path"])),
    }


def _standing(status: str, lapsed: bool, has_certificate: bool) -> str:
    if lapsed:
        return ("The registration on file has expired. Nothing is switched off "
                "automatically — but advice given under an expired "
                "registration is advice given under none, so this needs "
                "updating before anything else.")
    if status == "pending" and not has_certificate:
        return ("Waiting on the certificate. Nothing is granted until somebody "
                "here has looked at it.")
    if status == "pending":
        return "The certificate is with us and has not been looked at yet."
    if status == "refused":
        return ("The certificate was looked at and not accepted. The note "
                "against it says why.")
    return "Checked and active."


def may_edit_advice(user_id: str) -> dict:
    """Whether this person may change what the engine produced.

    Returns why not, because "no" has four causes and they need different
    things done about them.
    """
    if not user_id:
        return {"may": False, "why": "Not signed in."}

    found = for_user(user_id)
    if not found:
        return {
            "may": False,
            "why": ("No registration is on file for this account. Editing "
                    "advice is for registered advisers."),
            "fix": "Register as an adviser and upload your certificate.",
        }

    if found["status"] == "pending":
        return {"may": False,
                "why": found["standing"],
                "fix": "Nothing to do but wait for the check."}

    if found["status"] == "lapsed":
        return {"may": False,
                "why": found["standing"],
                "fix": "Upload a current certificate."}

    if found["status"] == "refused":
        return {"may": False, "why": found["standing"]}

    if not found["may_edit_advice"]:
        return {
            "may": False,
            "why": (f"A {found['kind_name']} may not advise. Distribution and "
                    f"advice are separate registrations, and this platform "
                    f"does not blur them — what your clients see from the "
                    f"engine is information, and it is presented to them as "
                    f"information."),
            "fix": None,
        }

    return {"may": True, "professional": found}


# ---------------------------------------------------------------------------
# Registering
# ---------------------------------------------------------------------------

def register(user_id: str, kind: str, registration_no: str, **fields: Any) -> dict:
    """Record a claim to a registration. Grants nothing.

    Status starts pending and stays there until somebody has looked at the
    certificate. That is the whole control: without it, the first thing this
    platform knows about somebody's authority is their own claim to it.
    """
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {', '.join(KINDS)}")
    if not (registration_no or "").strip():
        raise ValueError("A registration number is needed.")

    with db.connection() as conn:
        conn.execute(
            """
            INSERT INTO professional
                (user_id, kind, registration_no, firm_name, arn, euin,
                 registered_from, registered_to, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'pending')
            ON CONFLICT (user_id) DO UPDATE SET
                kind = EXCLUDED.kind,
                registration_no = EXCLUDED.registration_no,
                firm_name = EXCLUDED.firm_name,
                arn = EXCLUDED.arn,
                euin = EXCLUDED.euin,
                registered_from = EXCLUDED.registered_from,
                registered_to = EXCLUDED.registered_to,
                -- Back to pending. A changed registration is a new claim and
                -- has to be looked at again.
                status = 'pending',
                checked_at = NULL,
                checked_by = NULL,
                updated_at = now()
            """,
            (user_id, kind, registration_no.strip(), fields.get("firm_name"),
             fields.get("arn"), fields.get("euin"),
             fields.get("registered_from"), fields.get("registered_to")))

    return for_user(user_id) or {}


def attach_certificate(user_id: str, path: str, name: str) -> dict:
    with db.connection() as conn:
        conn.execute(
            """
            UPDATE professional
            SET certificate_path = %s, certificate_name = %s,
                uploaded_at = now(), status = 'pending',
                checked_at = NULL, checked_by = NULL, updated_at = now()
            WHERE user_id = %s
            """,
            (path, name, user_id))
    return for_user(user_id) or {}


def decide_on(professional_id: str, accept: bool, *,
              by_user_id: str, note: Optional[str] = None) -> dict:
    """A person looks at the certificate and decides.

    The note is kept either way. "Accepted, ARN verified against the AMFI
    register on 1 September" is worth as much as a refusal reason when
    somebody asks how this was checked.
    """
    with db.connection() as conn:
        row = conn.execute(
            """
            UPDATE professional
            SET status = %s, checked_at = now(), checked_by = %s,
                checked_note = %s, updated_at = now()
            WHERE id = %s
            RETURNING user_id
            """,
            ("active" if accept else "refused", by_user_id, note,
             professional_id),
        ).fetchone()

    return for_user(row["user_id"]) if row else {}


# ---------------------------------------------------------------------------
# Their clients
# ---------------------------------------------------------------------------

def clients_of(professional_id: str) -> dict:
    """Who they manage, and what each is doing.

    Positions and activity, because that is what managing a book requires.
    Not the advice text and not what anybody asked Ariv -- a distributor
    reading their client's questions is a different thing from a distributor
    managing their client's account.
    """
    rows = db.fetch_all(
        """
        SELECT c.investor_id, c.came_by, c.began_on, c.consented_at,
               i.display_name, i.email,
               (SELECT count(*) FROM v_current_holdings v
                 WHERE v.investor_id = i.id AND v.current_value > 0) AS holdings,
               (SELECT coalesce(sum(current_value), 0) FROM v_current_holdings v
                 WHERE v.investor_id = i.id AND v.current_value > 0) AS worth,
               (SELECT max(shown_at) FROM advice_ledger a
                 WHERE a.investor_id = i.id) AS last_seen,
               (SELECT count(*) FROM advice_shown s
                 WHERE s.investor_id = i.id AND s.acted_on IS NULL
                   AND s.lapsed_on IS NULL) AS open_actions
        FROM client_of c
        JOIN investors i ON i.id = c.investor_id
        WHERE c.professional_id = %s AND c.ended_on IS NULL
        ORDER BY 7 DESC NULLS LAST
        """,
        (professional_id,))

    clients = []
    for row in rows:
        last = row["last_seen"]
        clients.append({
            "investor_id": row["investor_id"],
            "name": row["display_name"],
            "email": row["email"],
            "came_by": row["came_by"],
            "since": row["began_on"].isoformat() if row["began_on"] else None,
            "consented": bool(row["consented_at"]),
            "holdings": row["holdings"] or 0,
            "worth": str(row["worth"] or 0),
            "open_actions": row["open_actions"] or 0,
            "last_seen": last.date().isoformat() if last else None,
            "quiet_days": (date.today() - last.date()).days if last else None,
            "needs_attention": _needs_attention(row),
        })

    return {
        "count": len(clients),
        "clients": clients,
        "without_consent": len([c for c in clients if not c["consented"]]),
    }


def _needs_attention(row: dict) -> Optional[str]:
    """The one line that decides whether to open the client.

    Consent first, because seeing somebody's portfolio without it is the
    problem that matters most.
    """
    if not row["consented_at"]:
        return "no recorded consent to see this portfolio"
    if not (row["holdings"] or 0):
        return "no holdings brought in yet"

    last = row["last_seen"]
    if last and (date.today() - last.date()).days > 90:
        return "has not looked in three months"
    if (row["open_actions"] or 0) > 2:
        return f"{row['open_actions']} things outstanding"
    return None


def add_client(professional_id: str, investor_id: str, *,
               came_by: str = "introduced",
               consented_at: Optional[Any] = None,
               consent_ref: Optional[str] = None) -> dict:
    with db.connection() as conn:
        conn.execute(
            "UPDATE client_of SET ended_on = current_date "
            "WHERE investor_id = %s AND ended_on IS NULL",
            (investor_id,))
        conn.execute(
            """
            INSERT INTO client_of
                (professional_id, investor_id, came_by, consented_at,
                 consent_ref)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (professional_id, investor_id, came_by, consented_at, consent_ref))
    return clients_of(professional_id)


def waiting() -> list[dict]:
    """Registrations somebody needs to look at."""
    rows = db.fetch_all(
        """
        SELECT p.id, p.kind, p.firm_name, p.registration_no, p.arn,
               p.certificate_name, p.uploaded_at, p.status,
               u.email, u.full_name
        FROM professional p JOIN users u ON u.id = p.user_id
        WHERE p.status = 'pending'
        ORDER BY p.uploaded_at NULLS LAST, p.created_at
        """)
    return [{
        "id": r["id"], "kind": r["kind"],
        "kind_name": KINDS.get(r["kind"], {}).get("name"),
        "who": r["full_name"] or r["email"],
        "email": r["email"],
        "firm_name": r["firm_name"],
        "registration_no": r["registration_no"],
        "arn": r["arn"],
        "certificate": r["certificate_name"],
        "uploaded_at": (r["uploaded_at"].isoformat()
                        if r["uploaded_at"] else None),
        "blocked_on": (None if r["certificate_name"]
                       else "no certificate uploaded yet"),
    } for r in rows]
