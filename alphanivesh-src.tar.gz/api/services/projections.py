"""Two things a decade makes obvious that a year hides.

**What fees cost.** An expense ratio of 1.8% against 0.3% is a rounding error
in a single year and the difference between two retirements over twenty-five.
The annual figure is honest and unpersuasive; compounded, it is the same fact
in a form somebody can act on.

**What raising a SIP does.** Somebody putting away ₹20,000 a month who raises
it 10% a year is putting away ₹1.35 lakh a month by year twenty-five, and the
compounding of the increases dwarfs the compounding of the original amount.
Most people never do it because nobody shows them the difference.

Both are projections, and projections invite two kinds of dishonesty this tries
to avoid.

**The rate is stated and it is a choice.** Every figure here rests on an
assumed return, and changing it changes everything. Twelve per cent is
conventional for Indian equity over long periods and is not a promise -- it is
roughly what the index has done, and the future is not obliged to match.

**And the range matters more than the middle.** A single projected number reads
as a forecast. Showing what a worse decade produces alongside the central case
is the difference between a plan and a sales pitch, so the low case is not an
afterthought here.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.projections")

# What a long-run equity return has been. A convention, stated wherever it is
# used, and the single number that most changes every figure below.
ASSUMED_RETURN = Decimal("12")

# And a worse decade, because the middle case alone reads as a forecast.
POOR_RETURN = Decimal("8")

# What a direct index fund costs, against which a portfolio's own expenses are
# measured. Not zero: an index fund is cheap rather than free, and comparing
# against zero would overstate the saving.
INDEX_EXPENSE = Decimal("0.3")

# Typical trail commission by category, used where we cannot see the actual
# expense ratio. Estimates, and labelled as such wherever they appear.
TYPICAL_EXPENSE = {
    "equity": Decimal("1.8"),
    "mutual_fund": Decimal("1.7"),
    "etf": Decimal("0.5"),
    "bond": Decimal("0.8"),
    "gsec": Decimal("0.5"),
}
DEFAULT_EXPENSE = Decimal("1.5")

HORIZONS = (5, 10, 15, 20, 25)
STEP_UPS = (0, 5, 10, 15, 20)


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def _grow(amount: Decimal, rate: Decimal, years: int) -> Decimal:
    """A lump sum, compounded."""
    return amount * (1 + rate / 100) ** years


# ---------------------------------------------------------------------------
# What the fees cost
# ---------------------------------------------------------------------------

def cost_drag(investor_id: str) -> Optional[dict]:
    """What the expense ratios cost over decades.

    Compared against an index fund at 0.3% rather than against zero, because
    the alternative to an expensive fund is a cheap one rather than a free one,
    and comparing against nothing overstates the case.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_name, v.asset_class, v.current_value,
               i.category
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
          AND v.asset_class IN ('mutual_fund', 'etf')
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )
    if not rows:
        return None

    total = sum((_d(r["current_value"]) for r in rows), Decimal(0))
    if total <= 0:
        return None

    funds = []
    weighted = Decimal(0)

    for row in rows:
        expense = TYPICAL_EXPENSE.get(row["asset_class"], DEFAULT_EXPENSE)
        value = _d(row["current_value"])
        share = value / total
        weighted += expense * share

        funds.append({
            "name": row["instrument_name"],
            "value": str(value.quantize(Decimal("1"))),
            "expense_pct": str(expense),
            "costs_a_year": str((value * expense / 100).quantize(Decimal("1"))),
        })

    annual = total * weighted / 100
    saving_rate = weighted - INDEX_EXPENSE

    # What the difference becomes. Both paths grow at the same gross return and
    # differ only in what is taken out, which is the whole point: the fee is
    # not a one-off cost but a permanent reduction in the compounding rate.
    over_time = []
    for years in HORIZONS:
        theirs = _grow(total, ASSUMED_RETURN - weighted, years)
        index = _grow(total, ASSUMED_RETURN - INDEX_EXPENSE, years)
        over_time.append({
            "years": years,
            "yours": str(theirs.quantize(Decimal("1"))),
            "at_index_cost": str(index.quantize(Decimal("1"))),
            "difference": str((index - theirs).quantize(Decimal("1"))),
        })

    twenty = next(x for x in over_time if x["years"] == 20)

    return {
        "total": str(total.quantize(Decimal("1"))),
        "weighted_expense_pct": str(weighted.quantize(Decimal("0.01"))),
        "annual_cost": str(annual.quantize(Decimal("1"))),
        "index_expense_pct": str(INDEX_EXPENSE),
        "over_time": over_time,
        "funds": funds[:8],
        "assumed_return_pct": str(ASSUMED_RETURN),
        "reading": (
            f"Your funds charge about {weighted:.2f}% a year between them, which "
            f"is {_money(annual)} on {_money(total)}. That sounds small. Held "
            f"for twenty years at the same gross return, the difference against "
            f"an index fund at {INDEX_EXPENSE}% comes to "
            f"{_money(twenty['difference'])} — not because the fee grew, but "
            f"because it was taken every year from a balance that was "
            f"compounding."
        ),
        "estimated": (
            f"Expense ratios here are typical rates by category rather than "
            f"each scheme's own disclosure, which we do not hold. Treat the "
            f"figures as close rather than exact — the argument does not turn "
            f"on a tenth of a per cent."
        ),
        "on_the_rate": (
            f"Both paths grow at {ASSUMED_RETURN}% before costs, which is "
            f"roughly what Indian equity has returned over long periods and is "
            f"not a promise. The comparison is what matters here rather than "
            f"the absolute figures: change the rate and both sides move "
            f"together."
        ),
    }


# ---------------------------------------------------------------------------
# What raising the amount does
# ---------------------------------------------------------------------------

def step_up(investor_id: str, monthly: Optional[Any] = None) -> Optional[dict]:
    """What happens if the monthly amount rises each year.

    The amount comes from what somebody actually invests, read from their
    transaction record, rather than from a number they were asked to imagine.
    A projection built on a real habit is a different thing from one built on
    an aspiration.
    """
    from . import behaviour

    amount = _d(monthly)

    if amount <= 0:
        try:
            how = behaviour.profile(investor_id)
            amount = _d(((how or {}).get("style") or {}).get("median_month"))
        except Exception:
            amount = Decimal(0)

    if amount <= 0:
        return {
            "known": False,
            "why": ("We cannot see a regular monthly amount in your record, so "
                    "there is nothing to project from. This becomes useful once "
                    "there is a habit to measure."),
        }

    paths = []
    for step in STEP_UPS:
        rows = []
        for years in HORIZONS:
            value, invested = _run(amount, step, ASSUMED_RETURN, years)
            poor, _ = _run(amount, step, POOR_RETURN, years)
            rows.append({
                "years": years,
                "value": str(value.quantize(Decimal("1"))),
                "invested": str(invested.quantize(Decimal("1"))),
                "if_worse": str(poor.quantize(Decimal("1"))),
            })
        paths.append({"step_up_pct": step, "by_year": rows})

    flat = next(p for p in paths if p["step_up_pct"] == 0)
    ten = next(p for p in paths if p["step_up_pct"] == 10)
    flat_20 = _d(next(r for r in flat["by_year"] if r["years"] == 20)["value"])
    ten_20 = _d(next(r for r in ten["by_year"] if r["years"] == 20)["value"])

    return {
        "known": True,
        "monthly": str(amount.quantize(Decimal("1"))),
        "paths": paths,
        "assumed_return_pct": str(ASSUMED_RETURN),
        "poor_return_pct": str(POOR_RETURN),
        "reading": (
            f"You put in about {_money(amount)} a month. Kept flat for twenty "
            f"years at {ASSUMED_RETURN}%, that becomes {_money(flat_20)}. Raised "
            f"by ten per cent each year — which usually tracks a pay rise rather "
            f"than a sacrifice — it becomes {_money(ten_20)}. The difference is "
            f"{_money(ten_20 - flat_20)}, and it comes from increases that felt "
            f"small at the time."
        ),
        "on_the_rate": (
            f"At {ASSUMED_RETURN}% a year, which is roughly what Indian equity "
            f"has returned over long periods and is not a promise. Every row "
            f"also shows what a poorer {POOR_RETURN}% decade would produce, "
            f"because a single projected number reads as a forecast and a range "
            f"reads as what it is."
        ),
    }


def _run(monthly: Decimal, step_up_pct: int, rate: Decimal,
         years: int) -> tuple[Decimal, Decimal]:
    """Month by month, with the amount rising each year.

    Explicit rather than a closed-form formula. The formula for a growing
    annuity exists and is easy to get subtly wrong, and this is checkable by
    somebody reading it against a spreadsheet.
    """
    monthly_rate = rate / 100 / 12
    amount = monthly
    balance = Decimal(0)
    invested = Decimal(0)

    for year in range(years):
        if year > 0 and step_up_pct:
            amount = amount * (1 + Decimal(step_up_pct) / 100)
        for _ in range(12):
            balance = balance * (1 + monthly_rate) + amount
            invested += amount

    return balance, invested
