"""What happens to the people who depend on you.

Insurance is the one part of a financial position that is not about the person
holding it. Everything else on this platform answers "how is my money doing";
this answers "what happens to my family if I am not here", and the two need
keeping apart.

**Cover is not wealth.** A term policy with a sum assured of three and a half
crore is worth nothing while somebody is alive — it is a promise that pays out
if they are not. Counting it as an asset inflates net worth by the size of the
promise, makes every allocation percentage wrong, and on a real portfolio
produced a rebalance instruction to sell the family's protection.

So it lives outside the totals, and the only question asked of it is whether
there is enough.

**How much is enough.** There is no formula that survives contact with a real
family, so this uses two and says both:

  ten times annual income, the rule of thumb most advisers start from
  what the dependants would actually need — outstanding debt, plus years of
  expenses until the youngest is independent

The second is better and needs facts we usually do not have. Where we have
them, both are shown and the larger is the one to act on.

**And what this does not do** is recommend a policy, an insurer or a premium.
It says whether there is a gap. Which product fills it depends on health, age
and underwriting, none of which a calculation can see.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.protection")

# The rule of thumb, and it is a rule of thumb rather than a finding.
INCOME_MULTIPLE = Decimal("10")

# Health cover, where somebody has dependants. A number that has moved with
# hospital costs and will move again.
HEALTH_FLOOR = Decimal("1000000")

# Policies that carry a value as well as a promise.
HAS_VALUE = ("endowment", "ulip")

KIND_NAMES = {
    "term_life": "Term life",
    "health": "Health",
    "critical_illness": "Critical illness",
    "personal_accident": "Personal accident",
    "endowment": "Endowment",
    "ulip": "ULIP",
    "other": "Other",
}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if number >= 0 else "-₹") + digits


def _crore(value: Decimal) -> str:
    """Large sums read better in the units people use for them."""
    if value >= 10000000:
        return f"₹{value / 10000000:.2f} crore"
    if value >= 100000:
        return f"₹{value / 100000:.1f} lakh"
    return _money(value)


def for_investor(investor_id: str) -> dict:
    """What cover exists, and whether it is enough."""
    rows = db.fetch_all(
        """
        SELECT id, kind, insurer, cover_amount, surrender_value,
               annual_premium, renews_on, covers
        FROM protection WHERE investor_id = %s
        ORDER BY cover_amount DESC NULLS LAST
        """,
        (investor_id,),
    )

    policies = [{
        "id": r["id"],
        "kind": r["kind"],
        "label": KIND_NAMES.get(r["kind"], r["kind"]),
        "insurer": r["insurer"],
        "cover": str(_d(r["cover_amount"]).quantize(Decimal("1"))),
        "cover_reads": _crore(_d(r["cover_amount"])),
        "surrender_value": (str(_d(r["surrender_value"]).quantize(Decimal("1")))
                            if r["surrender_value"] is not None else None),
        "premium": (str(_d(r["annual_premium"]).quantize(Decimal("1")))
                    if r["annual_premium"] is not None else None),
        "renews_on": r["renews_on"].isoformat() if r["renews_on"] else None,
        "covers": r["covers"],
    } for r in rows]

    life = sum((_d(r["cover_amount"]) for r in rows
                if r["kind"] in ("term_life", "endowment", "ulip")), Decimal(0))
    health = sum((_d(r["cover_amount"]) for r in rows if r["kind"] == "health"),
                 Decimal(0))

    # The part that is wealth. Only endowment and ULIP have one, and it is the
    # surrender value rather than the cover.
    worth = sum((_d(r["surrender_value"]) for r in rows
                 if r["kind"] in HAS_VALUE), Decimal(0))
    premiums = sum((_d(r["annual_premium"]) for r in rows), Decimal(0))

    need = _how_much_is_needed(investor_id)

    return {
        "recorded": bool(rows),
        "policies": policies,
        "life_cover": str(life.quantize(Decimal("1"))),
        "life_cover_reads": _crore(life),
        "health_cover": str(health.quantize(Decimal("1"))),
        "surrender_value": str(worth.quantize(Decimal("1"))),
        "premiums_a_year": str(premiums.quantize(Decimal("1"))),
        "need": need,
        "gap": _gap(life, health, need),
        "reading": _reading(rows, life, health, need, worth),
        "on_value": (
            "Cover is not counted as wealth anywhere on this platform. A term "
            "policy pays out if you are not here and is worth nothing while "
            "you are, so including it in a total would overstate what you have "
            "by the size of the promise."
            + (f" The {_money(worth)} of surrender value on your endowment or "
               f"unit-linked policies does count, and is in the totals."
               if worth > 0 else "")
        ),
    }


def _how_much_is_needed(investor_id: str) -> dict:
    """Two answers, because neither is definitive on its own."""
    from . import debts, profile as profile_service

    them = profile_service.get_profile(investor_id) or {}
    income = _d(them.get("annual_income")) or _d(them.get("monthly_income")) * 12
    expenses = _d(them.get("monthly_expenses")) * 12
    dependants = them.get("dependants")

    rule = income * INCOME_MULTIPLE if income > 0 else None

    # What they would actually need: debt cleared, plus years of expenses.
    owed = Decimal(0)
    try:
        position = debts.for_investor(investor_id)
        if position.get("recorded"):
            owed = _d(position.get("total"))
    except Exception:
        pass

    years = 15 if dependants else 10
    actual = (owed + expenses * years) if expenses > 0 else None

    return {
        "rule_of_thumb": (str(rule.quantize(Decimal("1"))) if rule else None),
        "rule_reads": _crore(rule) if rule else None,
        "worked_out": (str(actual.quantize(Decimal("1"))) if actual else None),
        "worked_out_reads": _crore(actual) if actual else None,
        "how_worked_out": (
            f"{_money(owed)} of debt cleared, plus {years} years of expenses at "
            f"{_money(expenses)} a year — the time until the people who depend "
            f"on you would not." if actual else None),
        "we_do_not_know": [
            label for label, value in (
                ("what you earn", income),
                ("what you spend", expenses),
            ) if value <= 0
        ],
    }


def _gap(life: Decimal, health: Decimal, need: dict) -> Optional[dict]:
    """Whether there is a shortfall, against the larger of the two measures."""
    targets = [_d(need.get("rule_of_thumb")), _d(need.get("worked_out"))]
    target = max(t for t in targets) if any(targets) else Decimal(0)

    if target <= 0:
        return None

    short = target - life
    return {
        "life_short_by": str(short.quantize(Decimal("1"))) if short > 0 else None,
        "life_short_reads": _crore(short) if short > 0 else None,
        "against": str(target.quantize(Decimal("1"))),
        "health_thin": health < HEALTH_FLOOR,
        "health_floor_reads": _crore(HEALTH_FLOOR),
    }


def _reading(rows: list, life: Decimal, health: Decimal,
             need: dict, worth: Decimal) -> str:
    if not rows:
        return ("You have not recorded any cover. Everything else here is "
                "about how your money is doing; this is the part about what "
                "happens to the people who depend on you if it stops coming "
                "in.")

    if not (need.get("rule_of_thumb") or need.get("worked_out")):
        missing = " and ".join(need.get("we_do_not_know") or ["enough"])
        return (f"{_crore(life)} of life cover. Whether that is enough depends "
                f"on {missing}, which we do not know — so this is a figure "
                f"rather than a verdict.")

    target = max(_d(need.get("rule_of_thumb")), _d(need.get("worked_out")))
    if life >= target:
        return (f"{_crore(life)} of life cover, against about {_crore(target)} "
                f"that the people depending on you would need. That is "
                f"covered.")

    return (f"{_crore(life)} of life cover, against about {_crore(target)} that "
            f"would be needed — short by {_crore(target - life)}. Term cover is "
            f"the cheapest way to close a gap that size, and the premium on it "
            f"is usually smaller than people expect.")


# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------

def add(investor_id: str, kind: str, cover_amount: Any = None, **fields: Any) -> dict:
    if kind not in KIND_NAMES:
        raise ValueError(f"kind must be one of {', '.join(sorted(KIND_NAMES))}")

    # Term and health have no surrender value. Accepting one would let the
    # category error back in through a different door.
    surrender = fields.get("surrender_value")
    if surrender is not None and kind not in HAS_VALUE:
        surrender = None

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO protection
                (investor_id, kind, insurer, policy_ref, cover_amount,
                 surrender_value, annual_premium, renews_on, covers, notes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (investor_id, kind, fields.get("insurer"), fields.get("policy_ref"),
             cover_amount, surrender, fields.get("annual_premium"),
             fields.get("renews_on"), fields.get("covers"),
             fields.get("notes")),
        ).fetchone()
    return {"id": row["id"] if row else None}


def remove(investor_id: str, protection_id: str) -> bool:
    with db.connection() as conn:
        conn.execute("DELETE FROM protection WHERE id = %s AND investor_id = %s",
                     (protection_id, investor_id))
    return True
