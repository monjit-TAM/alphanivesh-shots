"""Where the numbers and the price behaviour meet.

Quantamental is not a third set of ratios. It is the question of whether the
business figures and the market's own behaviour agree with each other, and it
answers differently from either alone: a sound company whose price is falling
says wait, and a rising price on weak fundamentals says be careful.

The implementation this replaces used the investor's own profit-and-loss as its
momentum signal, which is not a signal about the stock at all -- somebody who
bought last week and somebody who bought in 2019 hold the same company on the
same day and would get different readings. Price behaviour here comes from the
exchange record: where the price sits against its own moving averages, how it
has moved over three, six and twelve months, and how that compares to the
market.

One caution runs through all of it. The price history is the unadjusted
exchange record, so a split or a bonus appears as a fall that never happened.
Every calculation here stops at a step too large to be a market move rather
than reporting a number computed across one.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.quantamental")

# A single-day move past this on a listed company is a corporate action, not
# the market changing its mind.
SEAM = Decimal("0.33")

# Enough history to say anything. Two hundred sessions is roughly ten months,
# which is the least that supports a two-hundred-day average.
MIN_BARS = 200

BENCHMARK = "NIFTYBEES"


def _d(value: Any) -> Optional[Decimal]:
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    return number if number.is_finite() else None


def _closes(symbol: str, period: str = "2y") -> list[tuple[date, Decimal]]:
    """Daily closes, cut short at the first corporate action.

    Cut rather than adjusted: we have no licensed source for split and bonus
    ratios, and inventing one would put a wrong number everywhere rather than
    a missing one in one place.
    """
    from . import dataservice

    try:
        payload = dataservice.ohlcv(symbol, period=period)
    except dataservice.DataServiceError:
        return []

    bars = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(bars, list):
        return []

    points: list[tuple[date, Decimal]] = []
    for bar in bars:
        try:
            when = datetime.strptime(str(bar.get("date"))[:10], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            continue
        close = _d(bar.get("close"))
        if close and close > 0:
            points.append((when, close))

    points.sort()

    # Walk backwards from the present and stop at the first step too large to
    # be a market move -- keeping the recent, usable stretch rather than the
    # older, corrupted one.
    usable: list[tuple[date, Decimal]] = []
    previous: Optional[Decimal] = None
    for when, close in reversed(points):
        if previous is not None and previous > 0:
            if abs((previous - close) / previous) > SEAM:
                break
        usable.append((when, close))
        previous = close

    usable.reverse()
    return usable


def _average(values: list[Decimal]) -> Optional[Decimal]:
    return (sum(values) / len(values)) if values else None


def _return_over(points: list[tuple[date, Decimal]], days: int) -> Optional[Decimal]:
    """How the price has moved over a window, from the exchange record."""
    if not points:
        return None
    latest_date, latest = points[-1]
    cutoff = latest_date - timedelta(days=days)
    earlier = [p for p in points if p[0] <= cutoff]
    if not earlier:
        return None
    then = earlier[-1][1]
    if then <= 0:
        return None
    return (latest - then) / then * 100


def price_behaviour(symbol: str) -> Optional[dict]:
    """What the price has been doing, independent of who owns it.

    Four readings, each a fact about the stock rather than about a holder:
    where it sits against its own averages, how it has moved over three
    windows, where it stands in its year's range, and how all that compares to
    the market.
    """
    points = _closes(symbol)
    if len(points) < MIN_BARS:
        return None

    closes = [p[1] for p in points]
    latest = closes[-1]

    fifty = _average(closes[-50:])
    two_hundred = _average(closes[-200:])

    year = [p for p in points if p[0] >= points[-1][0] - timedelta(days=365)]
    year_closes = [p[1] for p in year] or closes
    high = max(year_closes)
    low = min(year_closes)

    # Where in the year's range, as a percentage. Near the high is not
    # automatically good -- it is where momentum investors buy and value
    # investors stop looking.
    span = high - low
    in_range = ((latest - low) / span * 100) if span > 0 else None

    returns = {
        "three_months": _return_over(points, 91),
        "six_months": _return_over(points, 182),
        "twelve_months": _return_over(points, 365),
    }

    # The same windows for the market, so the stock's move can be read against
    # what everything else did.
    market = db.fetch_all(
        "SELECT trade_date, close FROM benchmark_daily WHERE symbol = %s ORDER BY trade_date",
        (BENCHMARK,),
    )
    relative = None
    if market:
        market_points = [(r["trade_date"], _d(r["close"])) for r in market
                         if _d(r["close"])]
        market_year = _return_over(market_points, 365)
        own_year = returns["twelve_months"]
        if market_year is not None and own_year is not None:
            relative = own_year - market_year

    above_fifty = (latest > fifty) if fifty else None
    above_two_hundred = (latest > two_hundred) if two_hundred else None
    golden = (fifty > two_hundred) if (fifty and two_hundred) else None

    return {
        "price": str(latest.quantize(Decimal("0.01"))),
        "as_of": points[-1][0].isoformat(),
        "sessions": len(points),
        "fifty_day": str(fifty.quantize(Decimal("0.01"))) if fifty else None,
        "two_hundred_day": str(two_hundred.quantize(Decimal("0.01"))) if two_hundred else None,
        "above_fifty_day": above_fifty,
        "above_two_hundred_day": above_two_hundred,
        "fifty_above_two_hundred": golden,
        "year_high": str(high.quantize(Decimal("0.01"))),
        "year_low": str(low.quantize(Decimal("0.01"))),
        "in_year_range_pct": str(in_range.quantize(Decimal("0.1"))) if in_range is not None else None,
        "from_year_high_pct": str(((latest - high) / high * 100).quantize(Decimal("0.1"))) if high > 0 else None,
        "returns": {k: (str(v.quantize(Decimal("0.1"))) if v is not None else None)
                    for k, v in returns.items()},
        "against_market_12m_pct": (str(relative.quantize(Decimal("0.1")))
                                   if relative is not None else None),
        "trend": _trend(above_fifty, above_two_hundred, golden, returns),
    }


def _trend(above_fifty: Optional[bool], above_two_hundred: Optional[bool],
           golden: Optional[bool], returns: dict) -> dict:
    """Whether the price is going up, down, or neither.

    Deliberately coarse. A trend is either intact or it is not, and the
    precision implied by a number out of a hundred would be false: the same
    inputs a week later can flip a 51 to a 49 without anything having changed.
    """
    signals = [s for s in (above_fifty, above_two_hundred, golden) if s is not None]
    if not signals:
        return {"reading": "unknown", "why": "not enough price history"}

    up = sum(1 for s in signals if s)
    down = len(signals) - up

    twelve = returns.get("twelve_months")
    three = returns.get("three_months")

    if up == len(signals):
        # Above both averages with the shorter above the longer, but a stock
        # can be above its averages while the recent move has turned.
        if three is not None and three < -10:
            return {"reading": "rolling over",
                    "why": "above its longer averages, but down over three months"}
        return {"reading": "rising", "why": "above its averages, with the shorter above the longer"}

    if down == len(signals):
        if three is not None and three > 10:
            return {"reading": "turning up",
                    "why": "below its averages, but up over three months"}
        return {"reading": "falling", "why": "below its averages"}

    return {"reading": "mixed",
            "why": "above one average and below another, which usually means "
                   "a trend that has not settled"}


# ---------------------------------------------------------------------------
# The verdict
# ---------------------------------------------------------------------------

# What each lens does with what it sees. Written out rather than scored,
# because a rule somebody can read is a rule somebody can disagree with -- and
# an RIA asked why a stock was called a Buy needs to be able to answer.
RULES = {
    "value": {
        "buy": "Cheaper than its sector on most measures, with a balance sheet "
               "that can wait.",
        "lean buy": "Cheaper than its sector on the balance of measures, though "
                    "not on all of them.",
        "reduce": "Dearer than its sector on most measures, whatever it is growing at.",
        "lean reduce": "Dearer than its sector on the balance of measures.",
        "hold": "Priced about where its sector is.",
    },
    "growth": {
        "buy": "Growing faster than its sector, with the price behaviour agreeing.",
        "lean buy": "Growing a little faster than its sector on the balance of "
                    "measures.",
        "reduce": "Growth behind its sector, or growth that has stopped being "
                  "rewarded by the price.",
        "lean reduce": "Growth behind its sector on the balance of measures.",
        "hold": "Growing about as fast as its sector.",
    },
    "quantamental": {
        "buy": "The figures are sound and the price is confirming them.",
        "lean buy": "The figures and the price are both leaning the same way.",
        "lean reduce": "The figures and the price are both leaning against it.",
        "reduce": "Either the figures or the price has broken down, and acting "
                  "on one without the other is the mistake this lens exists to "
                  "avoid.",
        "hold": "The two are not disagreeing, but nor are they both saying go.",
    },
}


def verdicts(symbol: Optional[str], isin: Optional[str],
             position_share_pct: Optional[Decimal] = None) -> Optional[dict]:
    """Three calls on the same company, one per lens.

    All three are returned. The same holding is a sell through a value lens and
    a buy through a growth one, and both readings are coherent -- showing only
    one makes the tool wrong for whoever holds the other view.

    Position size modifies the verdict but never the reading. A company can be
    worth buying and still be too much of somebody's portfolio, and those are
    different sentences.
    """
    from . import lenses as lens_service

    seen = lens_service.through_lenses(symbol=symbol, isin=isin)
    if not seen:
        return None

    behaviour = price_behaviour(symbol) if symbol else None

    calls = []
    by_lens = {l["lens"]: l for l in seen["lenses"]}

    for name in ("value", "growth", "quantamental"):
        if name == "quantamental":
            call = _quantamental_call(by_lens, behaviour)
        else:
            call = _fundamental_call(name, by_lens.get(name), behaviour)
        if call:
            calls.append(call)

    if not calls:
        return None

    return {
        "company": seen["company"],
        "symbol": seen["symbol"],
        "sector": seen["sector"],
        "sector_peers": seen["sector_peers"],
        "lenses": seen["lenses"],
        "behaviour": behaviour,
        "calls": calls,
        "position": _position_note(position_share_pct, calls),
        "note": ("Three lenses, three calls, and they will not always agree. A "
                 "company that is dear on value and compounding on growth is a "
                 "sell to one investor and a buy to another, and both are "
                 "reasoning correctly from what they are looking for."),
    }


def _fundamental_call(name: str, lens: Optional[dict],
                      behaviour: Optional[dict]) -> Optional[dict]:
    """Value or growth, from the count of measures against the sector."""
    if not lens or not lens["compared"]:
        return None

    better, worse, compared = lens["better"], lens["worse"], lens["compared"]

    # Judged on the balance of what was actually compared, not on a fixed
    # count. Requiring two clear measures made a lens with three comparable
    # ones incapable of saying anything, and "nothing better, one worse" came
    # back as hold -- which is not a reading, it is a refusal to give one.
    #
    # The proportion is what matters: better than the sector on most of what we
    # could compare is a buy, worse on most is a reduce, and a genuine split is
    # the only honest hold.
    decisive = better - worse
    if compared and decisive > 0 and better >= (compared + 1) // 2:
        verdict = "buy"
    elif compared and decisive < 0 and worse >= (compared + 1) // 2:
        verdict = "reduce"
    elif decisive > 0:
        verdict = "lean buy"
    elif decisive < 0:
        verdict = "lean reduce"
    else:
        verdict = "hold"

    reasons = [f"{better} of {compared} measures better than its sector, "
               f"{worse} worse."]

    # Growth cares whether the market has noticed. Value explicitly does not --
    # a falling price is the point.
    if name == "growth" and behaviour:
        trend = behaviour["trend"]["reading"]
        if verdict in ("buy", "lean buy") and trend in ("falling", "rolling over"):
            verdict = "hold"
            reasons.append("The growth is there but the price is not confirming it, "
                           "which for this lens is a reason to wait rather than act.")
        elif verdict in ("reduce", "lean reduce") and trend == "rising":
            reasons.append("The price is still rising, which is either the market "
                           "seeing something the figures do not yet show, or a move "
                           "that has run ahead of them.")

    return {
        "lens": name,
        "title": lens["title"],
        "verdict": verdict,
        "rule": RULES[name][verdict],
        "because": " ".join(reasons),
        "measures": lens["measures"],
    }


def _quantamental_call(by_lens: dict, behaviour: Optional[dict]) -> Optional[dict]:
    """The two together.

    Fundamentals sound and price confirming is the only combination this lens
    calls a buy. Everything else is a wait or a reduce, which is the discipline
    it exists to impose: acting on one signal without the other is the mistake.
    """
    quality = by_lens.get("quality")
    growth = by_lens.get("growth")
    if not quality and not growth:
        return None

    strong = 0
    weak = 0
    for lens in (quality, growth):
        if not lens or not lens["compared"]:
            continue
        if lens["better"] > lens["worse"]:
            strong += 1
        elif lens["worse"] > lens["better"]:
            weak += 1

    if not behaviour:
        return {
            "lens": "quantamental",
            "title": "Quantamental",
            "verdict": "hold",
            "rule": RULES["quantamental"]["hold"],
            "because": ("We have the figures but not enough price history to see "
                        "whether the market agrees, and this lens needs both."),
            "measures": [],
        }

    trend = behaviour["trend"]["reading"]
    rising = trend in ("rising", "turning up")
    falling = trend in ("falling", "rolling over")

    if strong and rising and not weak:
        verdict = "buy"
        because = (f"The figures are sound and the price is {trend} "
                   f"\u2014 {behaviour['trend']['why']}.")
    elif weak and falling:
        verdict = "reduce"
        because = (f"The figures read weakly against the sector and the price is "
                   f"{trend}. Both signals point the same way.")
    elif strong and falling:
        verdict = "hold"
        because = ("The figures are sound but the price is falling. This lens waits "
                   "for the two to agree rather than backing one against the other.")
    elif weak and rising:
        verdict = "hold"
        because = ("The price is rising while the figures read weakly. That is either "
                   "the market seeing something ahead of the numbers, or a move "
                   "without support -- and this lens will not choose between them.")
    else:
        verdict = "hold"
        because = f"Neither the figures nor the price is saying much. The trend is {trend}."

    detail = []
    if behaviour.get("against_market_12m_pct") is not None:
        against = _d(behaviour["against_market_12m_pct"])
        detail.append(
            f"Over a year it has {'beaten' if against > 0 else 'lagged'} the market by "
            f"{abs(against):.0f} points.")
    if behaviour.get("from_year_high_pct") is not None:
        off_high = _d(behaviour["from_year_high_pct"])
        detail.append(f"It sits {abs(off_high):.0f}% below its year's high.")

    return {
        "lens": "quantamental",
        "title": "Quantamental",
        "verdict": verdict,
        "rule": RULES["quantamental"][verdict],
        "because": because + (" " + " ".join(detail) if detail else ""),
        "measures": [],
    }


def _position_note(share_pct: Optional[Decimal], calls: list[dict]) -> Optional[dict]:
    """Whether the size of the holding changes what to do about it.

    A company worth owning can still be too much of one portfolio, and those
    are separate sentences. This one never contradicts a lens -- it says what
    the size adds.
    """
    if share_pct is None or share_pct < 15:
        return None

    buys = sum(1 for c in calls if c["verdict"] in ("buy", "lean buy"))
    reduces = sum(1 for c in calls if c["verdict"] in ("reduce", "lean reduce"))

    if reduces:
        return {"reading": (f"This is {share_pct:.0f}% of the portfolio, and at least "
                            f"one lens says reduce. Size and reading point the same way."),
                "share_pct": str(share_pct.quantize(Decimal("0.1")))}
    if buys:
        return {"reading": (f"The lenses read well, but this is already "
                            f"{share_pct:.0f}% of the portfolio. Adding to it "
                            f"concentrates further into a view already taken."),
                "share_pct": str(share_pct.quantize(Decimal("0.1")))}
    return {"reading": (f"At {share_pct:.0f}% of the portfolio, how this one does "
                        f"matters more than the readings suggest on their own."),
            "share_pct": str(share_pct.quantize(Decimal("0.1")))}
