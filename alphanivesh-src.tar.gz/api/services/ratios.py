"""The ratios a fund page leads with.

Volatility says how much something moves. These say whether the movement was
worth it, and against what.

All of them are standard formulas over a daily return series, computed here
rather than fetched because the inputs are already local — 122,610 daily NAVs
and 1,317 benchmark closes — and because a figure whose derivation lives in
this repository can be explained on the methodology page rather than inherited
undocumented.

Three things worth knowing before reading any of them.

**They need a risk-free rate, and it is a choice.** Sharpe and Sortino both
divide excess return by risk, and "excess" is over something. The rate used is
stated rather than buried, and changing it changes every Sharpe on the
platform — which is the honest reason to state it.

**They need enough history.** A Sharpe ratio from eight months of daily returns
is arithmetic rather than information. Anything under two years returns nothing
instead of a number that would be quoted as though it meant something.

**And Sortino is the one to read.** Sharpe punishes upside volatility exactly
as hard as downside, which nobody experiences that way: a fund that rose
sharply and a fund that fell sharply score the same penalty. Sortino counts
only the falls. Both are reported because Sharpe is what people ask for, but
where they disagree, Sortino is describing what it felt like to hold.
"""

from __future__ import annotations

import logging
import math
import statistics
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.ratios")

# The rate a rupee earns without taking risk, annualised. Roughly the ten-year
# government bond.
#
# A choice rather than a fact, and it moves every Sharpe and Sortino figure on
# the platform. Stated on the methodology page for that reason, and kept here
# as one constant so changing it is one edit rather than a search.
#
# Seven per cent because that is what the group's other analyser uses. The
# figure matters less than the agreement: the same fund showing Sharpe 0.66
# here and 0.71 in a broker report is a reason to disbelieve both, and nobody
# reading either would guess the cause was a constant half a point apart.
RISK_FREE_PCT = Decimal("7.0")

# Trading days in a year, for annualising.
YEAR = 252

# Below this, these figures are arithmetic rather than information.
MIN_DAYS = 500          # about two years

BENCHMARK = "NIFTYBEES"


def _d(value: Any) -> Optional[Decimal]:
    if value is None:
        return None
    try:
        number = Decimal(str(value))
    except Exception:
        return None
    return number if number.is_finite() else None


def _daily_returns(series: list[tuple[date, Decimal]]) -> list[tuple[date, float]]:
    """Day-on-day change, skipping the seams a corporate action leaves.

    A split shows in an unadjusted NAV series as a fall of half or more
    overnight. Including it would put a -50% day into the volatility of a fund
    that did not move, so any single-day change past a third is dropped rather
    than smoothed: we cannot tell what the real move was, and inventing one is
    worse than losing a day.
    """
    out = []
    for i in range(1, len(series)):
        before, after = series[i - 1][1], series[i][1]
        if before <= 0:
            continue
        change = float((after - before) / before)
        if abs(change) > 0.33:
            continue
        out.append((series[i][0], change))
    return out


def _prices(instrument_id: str, asset_class: str,
            years: int = 5) -> list[tuple[date, Decimal]]:
    """A daily price series, from wherever this kind of holding keeps one.

    Funds have NAVs and shares have closes, in different tables. Everything
    downstream is identical -- a return series is a return series -- so this is
    the only place the difference exists, rather than two copies of the same
    arithmetic drifting apart.
    """
    cutoff = date.today() - timedelta(days=365 * years + 10)

    if asset_class == "equity":
        rows = db.fetch_all(
            """
            SELECT p.trade_date AS as_of, p.close AS price
            FROM equity_prices p
            JOIN instruments i ON i.symbol = p.symbol
            WHERE i.id = %s AND p.trade_date >= %s
            ORDER BY p.trade_date
            """,
            (instrument_id, cutoff),
        )
    else:
        rows = db.fetch_all(
            """
            SELECT as_of, nav AS price FROM nav_history
            WHERE instrument_id = %s AND as_of >= %s
            ORDER BY as_of
            """,
            (instrument_id, cutoff),
        )
    return [(r["as_of"], _d(r["price"])) for r in rows if _d(r["price"])]


def _navs(instrument_id: str, years: int = 5) -> list[tuple[date, Decimal]]:
    return _prices(instrument_id, "mutual_fund", years)


def _benchmark(years: int = 5) -> list[tuple[date, Decimal]]:
    rows = db.fetch_all(
        """
        SELECT trade_date, close FROM benchmark_daily
        WHERE symbol = %s AND trade_date >= %s
        ORDER BY trade_date
        """,
        (BENCHMARK, date.today() - timedelta(days=365 * years + 10)),
    )
    return [(r["trade_date"], _d(r["close"])) for r in rows if _d(r["close"])]


def _paired(fund: list[tuple[date, float]],
            index: list[tuple[date, float]]) -> tuple[list[float], list[float]]:
    """Returns on the days both have one.

    A fund's NAV is published on days the exchange is shut and vice versa. Beta
    computed across mismatched days measures the mismatch as much as the
    relationship, so only shared dates are used and the count is reported.
    """
    by_date = dict(index)
    ours, theirs = [], []
    for when, value in fund:
        other = by_date.get(when)
        if other is None:
            continue
        ours.append(value)
        theirs.append(other)
    return ours, theirs


def for_instrument(instrument_id: str, years: int = 5,
                   asset_class: str = "mutual_fund") -> Optional[dict]:
    """Every ratio we can compute for one holding, or nothing.

    Nothing rather than partial: a page showing Sharpe and omitting Sortino
    invites the reader to assume Sortino was unremarkable, when the truth is
    that it could not be computed.
    """
    navs = _prices(instrument_id, asset_class, years)
    if len(navs) < MIN_DAYS:
        return {
            "computable": False,
            "why": (f"We hold {len(navs)} daily prices for this holding. These "
                    f"figures need about two years of them to mean anything — "
                    f"below that they are arithmetic rather than information."),
            "days": len(navs),
        }

    returns = _daily_returns(navs)
    if len(returns) < MIN_DAYS:
        return {"computable": False,
                "why": "Not enough clean price history after removing "
                       "corporate-action seams.",
                "days": len(returns)}

    values = [r for _, r in returns]
    mean = statistics.fmean(values)
    deviation = statistics.pstdev(values)

    annual_return = ((1 + mean) ** YEAR - 1) * 100
    annual_vol = deviation * math.sqrt(YEAR) * 100

    risk_free = float(RISK_FREE_PCT)
    excess = annual_return - risk_free

    sharpe = (excess / annual_vol) if annual_vol > 0 else None

    # Only the days it fell. Sharpe punishes a sharp rise exactly as hard as a
    # sharp fall, which is not how anybody experiences holding a fund.
    daily_rf = (1 + risk_free / 100) ** (1 / YEAR) - 1
    downside = [min(0.0, r - daily_rf) for r in values]
    downside_dev = math.sqrt(statistics.fmean([d * d for d in downside]))
    downside_annual = downside_dev * math.sqrt(YEAR) * 100
    sortino = (excess / downside_annual) if downside_annual > 0 else None

    result = {
        "computable": True,
        "days": len(returns),
        "from": returns[0][0].isoformat(),
        "annual_return_pct": round(annual_return, 2),
        "volatility_pct": round(annual_vol, 2),
        "sharpe": round(sharpe, 2) if sharpe is not None else None,
        "sortino": round(sortino, 2) if sortino is not None else None,
        "downside_volatility_pct": round(downside_annual, 2),
        "risk_free_pct": float(RISK_FREE_PCT),
    }
    result.update(_against_the_index(returns, values, annual_return))
    result["reading"] = _describe(result)
    return result


def _against_the_index(returns: list[tuple[date, float]], values: list[float],
                       annual_return: float) -> dict:
    """Beta, alpha, capture and tracking error against the market."""
    index_returns = _daily_returns(_benchmark())
    if len(index_returns) < MIN_DAYS:
        return {"versus_index": None}

    ours, theirs = _paired(returns, index_returns)
    if len(ours) < MIN_DAYS:
        return {"versus_index": None,
                "why_no_index": (f"Only {len(ours)} days where both this holding "
                                 f"and the index have a price. Beta computed "
                                 f"across mismatched days measures the mismatch.")}

    index_var = statistics.pvariance(theirs)
    if index_var <= 0:
        return {"versus_index": None}

    covariance = statistics.fmean(
        [(a - statistics.fmean(ours)) * (b - statistics.fmean(theirs))
         for a, b in zip(ours, theirs)])
    beta = covariance / index_var

    index_annual = ((1 + statistics.fmean(theirs)) ** YEAR - 1) * 100
    risk_free = float(RISK_FREE_PCT)

    # What the return was above what beta alone would predict. The part that
    # is not explained by having taken market risk.
    alpha = annual_return - (risk_free + beta * (index_annual - risk_free))

    # How much of the index's rise and fall the fund caught. A fund capturing
    # 90% of the rise and 70% of the fall is doing something a return figure
    # alone does not show.
    up_fund = [a for a, b in zip(ours, theirs) if b > 0]
    up_index = [b for b in theirs if b > 0]
    down_fund = [a for a, b in zip(ours, theirs) if b < 0]
    down_index = [b for b in theirs if b < 0]

    def capture(fund_days: list[float], index_days: list[float]) -> Optional[float]:
        if not fund_days or not index_days:
            return None
        fund_total = statistics.fmean(fund_days)
        index_total = statistics.fmean(index_days)
        if index_total == 0:
            return None
        return fund_total / index_total * 100

    differences = [a - b for a, b in zip(ours, theirs)]
    tracking = statistics.pstdev(differences) * math.sqrt(YEAR) * 100
    information = ((annual_return - index_annual) / tracking) if tracking > 0 else None

    # How much of this holding's movement the market actually explains.
    #
    # Alpha is defined as the return beta does not account for, so it is only
    # as meaningful as beta is. A fund holding fifty companies moves largely
    # with the market and beta explains most of it; one company moves on its
    # own news and beta explains very little -- at which point alpha is the
    # residual of a model that does not fit, reported as though it were skill.
    #
    # On real holdings this matters enormously: HAL came back with an alpha of
    # 57.7% a year, which is arithmetically correct and would be read as an
    # edge. What it actually says is that a single defence company's five-year
    # run had almost nothing to do with the index.
    ours_mean = statistics.fmean(ours)
    theirs_mean = statistics.fmean(theirs)
    total_var = statistics.pvariance(ours)
    explained = (beta ** 2) * index_var
    r_squared = (explained / total_var) if total_var > 0 else 0.0
    r_squared = max(0.0, min(1.0, r_squared))

    return {
        "versus_index": {
            "days_compared": len(ours),
            "index_return_pct": round(index_annual, 2),
            "beta": round(beta, 2),
            "alpha_pct": round(alpha, 2),
            "up_capture_pct": (round(capture(up_fund, up_index), 1)
                               if capture(up_fund, up_index) is not None else None),
            "down_capture_pct": (round(capture(down_fund, down_index), 1)
                                 if capture(down_fund, down_index) is not None else None),
            "tracking_error_pct": round(tracking, 2),
            "information_ratio": (round(information, 2)
                                  if information is not None else None),
            "explained_by_market_pct": round(r_squared * 100, 1),
            # Below this, beta is not describing the holding and alpha is the
            # residual of a model that does not fit. Half is a convention
            # rather than a law, and it is stated so somebody can argue with it.
            "alpha_meaningful": r_squared >= 0.5,
        }
    }


def _describe(result: dict) -> str:
    """The ratios in a sentence, saying what each is measuring.

    A number without its question is a number nobody acts on. "Sharpe 0.84"
    means nothing to most readers; "each unit of movement bought 0.84 units of
    return above the risk-free rate" means something they can weigh.
    """
    parts = []

    sharpe, sortino = result.get("sharpe"), result.get("sortino")
    vol = result.get("volatility_pct")

    if vol is not None:
        parts.append(f"It moves about {vol:.0f}% in a year.")

    if sortino is not None and sharpe is not None:
        parts.append(
            f"Counting only the falls, each unit of that movement bought "
            f"{sortino:.2f} units of return above the {result['risk_free_pct']:.1f}% "
            f"a risk-free rupee earns. Counting rises and falls alike, "
            f"{sharpe:.2f}."
        )
        if sortino > sharpe * 1.4:
            parts.append("The gap between those two says most of the movement "
                         "was upward, which is the kind nobody minds.")

    index = result.get("versus_index")
    if index:
        beta = index.get("beta")
        alpha = index.get("alpha_pct")
        up, down = index.get("up_capture_pct"), index.get("down_capture_pct")

        if beta is not None:
            parts.append(
                f"When the market moves a rupee, this has historically moved "
                f"{beta:.2f}.")
        explained = index.get("explained_by_market_pct")
        if alpha is not None and index.get("alpha_meaningful"):
            parts.append(
                f"After allowing for that, it returned {alpha:+.1f}% a year more "
                f"than taking the same market risk would have given you."
                if alpha >= 0 else
                f"After allowing for that, it returned {abs(alpha):.1f}% a year "
                f"less than taking the same market risk would have given you.")
        elif explained is not None:
            parts.append(
                f"But the market explains only {explained:.0f}% of how this has "
                f"moved, so beta is not really describing it \u2014 and alpha, which "
                f"is defined as whatever beta leaves over, is not worth reading "
                f"here. Most of what this does, it does on its own news.")
        if up is not None and down is not None:
            parts.append(
                f"It caught {up:.0f}% of the market's up days and {down:.0f}% of "
                f"the down ones."
                + (" Catching less of the falls than the rises is the whole job."
                   if down < up else
                   " Catching more of the falls than the rises is the opposite "
                   "of the job." if down > up else ""))

    return " ".join(parts)


def for_investor(investor_id: str, limit: int = 10) -> list[dict]:
    """The ratios across somebody's fund holdings, largest first."""
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.current_value
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.asset_class = 'mutual_fund'
          AND v.current_value > 0
        ORDER BY v.current_value DESC LIMIT %s
        """,
        (investor_id, limit),
    )

    out = []
    for row in rows:
        try:
            ratios = for_instrument(row["instrument_id"])
        except Exception as err:                                 # pragma: no cover
            log.warning("ratios failed for %s: %s", row["instrument_name"], err)
            continue
        if not ratios:
            continue
        out.append({"name": row["instrument_name"],
                    "value": str(_d(row["current_value"])), **ratios})
    return out
