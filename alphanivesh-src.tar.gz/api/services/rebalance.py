"""What to sell and what to add, given a plan and a portfolio.

Two things have to be true before this says anything.

There has to be a plan. Drift is only measurable against an intention, and
without one "96% in shares" has no verdict attached -- it is reckless for
somebody who wanted sixty-forty and right for somebody who meant to be fully
invested.

And the suggestion has to name a holding rather than an asset class. "Reduce
equity by twelve lakh" is arithmetic anybody could do; "these three look
weakest through the lenses and together they are twelve lakh" is the part that
takes work.

What this deliberately does not do is decide. It ranks candidates by things
that can be checked -- how the company reads against its sector, what the tax
would cost, how concentrated the position is -- and says why each one is on the
list. Which to actually sell depends on things we do not know: a conviction
somebody holds, a plan to buy more, a reason the numbers do not show.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

# Below this the trade costs more in brokerage and attention than the
# rebalancing gains.
MIN_TRADE = Decimal("10000")

# How many candidates are worth naming. A list of twelve is a list nobody reads.
MAX_SUGGESTIONS = 4



# ---------------------------------------------------------------------------
# What can actually be sold
# ---------------------------------------------------------------------------
#
# The ranking below picks holdings from an over-weighted asset class. It did
# not ask whether they could be sold, and on a real portfolio it suggested
# selling EPF, term life cover and a ULIP -- quoting eighty-two lakh of tax
# computed as though they were shares.
#
# None of those is a sale. EPF has withdrawal rules and a different tax
# treatment entirely. Term cover has no surrender value, so "selling" it means
# cancelling a family's protection for nothing. A ULIP can be surrendered, at
# a cost this engine does not know and with tax consequences it does not model.
#
# So nothing leaves this module unless it is something somebody could sell on
# a normal day at a price we can see.

# Sellable: a market price exists and exiting is a normal transaction.
SELLABLE = ("equity", "mutual_fund", "etf", "bond", "gsec", "gold")

# Not sellable, for reasons worth stating rather than filtering silently.
NOT_SELLABLE = {
    "ppf_epf": ("Provident fund and PPF have withdrawal rules rather than a "
                "sale price, and the tax treatment is not capital gains."),
    "insurance": ("A policy is surrendered rather than sold, usually at a "
                  "loss, and term cover has no surrender value at all — "
                  "cancelling it ends the protection and returns nothing."),
    "real_estate": ("Property is not sold in the sense this engine means, and "
                    "nothing here knows what it would fetch."),
    "unlisted": ("No market price and no reliable buyer, so there is nothing "
                 "to instruct."),
    "fixed_deposit": ("Breaking a deposit early costs interest, which is a "
                      "different calculation from capital gains tax."),
    "cash": ("Already cash."),
}


# What an allocation is even about.
#
# A target mix of 60% equity, 30% funds and 10% bonds implicitly says
# everything else should be zero -- including a provident fund and a term
# policy. That produced "reduce insurance from 78% to 0%" on a real portfolio,
# which is an instruction to cancel a family's cover.
#
# So drift is measured across the things somebody can actually move between.
# A provident fund is wealth and is not an allocation decision; term cover is
# not wealth at all.
INVESTABLE = ("equity", "mutual_fund", "etf", "bond", "gsec", "gold",
              "fixed_deposit", "cash")


def investable(row: dict) -> bool:
    """Whether this is something an allocation decision can move.

    Wider than sellable: a fixed deposit counts here because somebody can
    choose to hold more or less of one, even though breaking it early is not
    a sale.
    """
    kind = (row.get("asset_class") or "").lower()
    if kind and kind not in INVESTABLE:
        return False
    return _sellable(row) or kind in ("fixed_deposit", "cash")


def _sellable(row: dict) -> bool:
    """Whether this is a thing somebody could sell on a normal day.

    Checked on the asset class and then on the name, because a term policy
    recorded under a generic class is still a term policy -- and the cost of
    getting this wrong is suggesting somebody cancel their family's cover.
    """
    kind = (row.get("asset_class") or "").lower()
    if kind in NOT_SELLABLE:
        return False
    if kind and kind not in SELLABLE:
        return False

    name = " ".join(str(row.get(k) or "") for k in
                    ("name", "instrument_name", "scheme_name")).lower()
    for word in ("term cover", "term plan", "term insurance", "ulip",
                 "endowment", "money back", "epf", "epfo", "ppf",
                 "provident", "sukanya", "nps", "annuity", "policy"):
        if word in name:
            return False
    return True


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def suggestions(investor_id: str) -> Optional[dict]:
    """Which holdings to trim, and where the money would go.

    The trimming list is ranked by how a holding reads against its own sector,
    with the tax cost of selling it shown beside each -- because a holding that
    looks weak and a holding that is cheap to exit are different lists, and the
    reader is choosing between them.
    """
    from . import profile as profile_service

    drift = profile_service.drift(investor_id)
    if not drift or drift.get("in_line"):
        return None

    over = [line for line in drift["lines"]
            if line["beyond_tolerance"] and _d(line["to_move"]) > MIN_TRADE]
    under = [line for line in drift["lines"]
             if line["beyond_tolerance"] and _d(line["to_move"]) < -MIN_TRADE]

    if not over and not under:
        return None

    trims = []
    for line in over:
        trims.extend(_candidates_in(investor_id, line["asset_class"],
                                    _d(line["to_move"])))
    trims.sort(key=lambda c: c["rank"])

    return {
        "raise_from": [
            {"asset_class": line["asset_class"],
             "amount": str(_d(line["to_move"]).quantize(Decimal("1"))),
             "from_pct": line["actual_pct"], "to_pct": line["target_pct"]}
            for line in over
        ],
        "put_into": [
            {"asset_class": line["asset_class"],
             "amount": str(abs(_d(line["to_move"])).quantize(Decimal("1"))),
             "from_pct": line["actual_pct"], "to_pct": line["target_pct"]}
            for line in under
        ],
        "candidates": trims[:MAX_SUGGESTIONS],
        "method": ("Ranked by how each company reads against its own sector and what "
                   "selling it would cost in tax. This is a shortlist, not an "
                   "instruction: which to sell depends on convictions and plans that "
                   "no calculation can see."),
    }


def _candidates_in(investor_id: str, asset_class: str,
                   needed: Decimal) -> list[dict]:
    """Holdings within one asset class, worst-reading first.

    Three things decide the order, and each is stated on the row so the
    ranking can be argued with:

      how it reads through the lenses, against its own sector
      what the tax would be, since a short-term gain costs eight points more
      how large the position is, because trimming one big holding beats
      touching four small ones
    """
    from . import lenses as lens_service

    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.symbol, v.isin,
               v.asset_class, v.current_value, v.invested_value,
               (SELECT min(h.as_of) FROM holding_snapshots h
                WHERE h.instrument_id = v.instrument_id
                  AND h.investor_id = v.investor_id
                  AND h.as_of > '1990-01-01') AS bought
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.asset_class = %s AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id, asset_class),
    )

    today = date.today()
    out = []

    for row in rows:
        value = _d(row["current_value"])
        if value < MIN_TRADE:
            continue

        # Nothing that cannot be sold. This is the check whose absence put
        # EPF, term cover and a ULIP on a real investor's sell list with
        # eighty-two lakh of imaginary tax attached.
        if not _sellable(row):
            continue

        reading = None
        unfavourable = 0
        try:
            lens = lens_service.through_lenses(symbol=row["symbol"], isin=row["isin"])
            if lens:
                reading = lens["overall"]["reading"]
                unfavourable = len(lens["overall"]["unfavourable"])
        except Exception:
            pass

        gain = value - _d(row["invested_value"])
        bought = row["bought"]
        short_term = bool(bought and (today - bought).days < 365)
        # Twenty per cent short-term against 12.5 long-term. Only gains are
        # taxed, so a position at a loss costs nothing to exit.
        tax = (gain * (Decimal("20") if short_term else Decimal("12.5")) / 100
               if gain > 0 else Decimal(0))

        # Lower ranks first. A holding that reads badly on all three lenses and
        # is cheap to sell rises to the top; one that reads well and would
        # trigger a large short-term bill sinks.
        rank = (
            -(unfavourable * 3)                       # weak readings come first
            + float(tax / value * 10 if value else 0)  # tax as a share of the sale
            - float(value / needed if needed else 0)   # bigger positions do more
        )

        out.append({
            "instrument_id": row["instrument_id"],
            "name": row["instrument_name"],
            "symbol": row["symbol"],
            "value": str(value.quantize(Decimal("1"))),
            "gain": str(gain.quantize(Decimal("1"))),
            "tax_if_sold": str(tax.quantize(Decimal("1"))),
            "short_term": short_term,
            "reading": reading,
            "lenses_unfavourable": unfavourable,
            "why": _why(unfavourable, short_term, tax, gain),
            "rank": rank,
        })

    return out


def _why(unfavourable: int, short_term: bool, tax: Decimal, gain: Decimal) -> str:
    """Why this one is on the list, in a sentence."""
    parts = []
    if unfavourable >= 2:
        parts.append("reads weakly against its sector on more than one measure")
    elif unfavourable == 1:
        parts.append("reads weakly against its sector on one of the three")
    if gain <= 0:
        parts.append("selling it costs nothing in tax, since it is not in profit")
    elif short_term:
        parts.append(f"but selling now is taxed at 20%, about ₹{tax:,.0f}")
    else:
        parts.append(f"and the tax would be about ₹{tax:,.0f}")

    if not parts:
        return "One of the larger positions in this class."
    return parts[0][0].upper() + parts[0][1:] + (
        f", {parts[1]}" if len(parts) > 1 else "") + "."


# ---------------------------------------------------------------------------
# From a shortlist to an instruction
# ---------------------------------------------------------------------------
#
# `suggestions` above answers "which holdings look weakest, and what would
# selling them cost". That is a shortlist and it is deliberately not an
# instruction: which to sell depends on convictions no calculation can see.
#
# But somebody who has read the shortlist and agreed with it still has work to
# do. How much of each. In what order. What it raises after tax. Whether the
# proceeds cover what they were meant to buy. That arithmetic is not judgement
# and there is no reason to leave it to a reader with a calculator.
#
# So: given the shortlist and an amount, this sizes it.

# Below this a sale is not worth the brokerage and the paperwork.
WORTH_SELLING = Decimal("5000")

# And a stub smaller than this is a position too small to matter and too
# fiddly to hold. Take the lot instead of leaving one behind.
LEAVE_NO_STUB = Decimal("10000")

LTCG_EXEMPT = Decimal("125000")
LTCG_PCT = Decimal("12.5")


def instruction(investor_id: str, amount: Optional[Any] = None) -> Optional[dict]:
    """Size the shortlist into something somebody could act on.

    Ordered by the ranking `suggestions` already computed, which weighs how a
    holding reads against its sector against what selling it costs. Sized here,
    with the rounding shown rather than absorbed and the annual exemption netted
    off rather than quoted gross.

    **Still not an order.** Every line is a suggestion to read, change or
    ignore, and acting on one is a separate decision recorded separately. That
    distinction is the difference between an adviser and a discretionary
    manager.
    """
    shortlist = suggestions(investor_id)
    if not shortlist or not shortlist.get("candidates"):
        return None

    wanted = _d(amount) if amount else sum(
        (_d(r["amount"]) for r in shortlist.get("raise_from") or []), Decimal(0))
    if wanted <= 0:
        return None

    steps = []
    raised = Decimal(0)
    tax = Decimal(0)
    long_gain = Decimal(0)

    for candidate in shortlist["candidates"]:
        if raised >= wanted:
            break

        value = _d(candidate.get("value"))
        if value <= 0:
            continue

        take = min(value, wanted - raised)
        if value - take < LEAVE_NO_STUB:
            take = value          # no stubs
        if take < WORTH_SELLING:
            continue

        share = take / value
        gain = _d(candidate.get("gain")) * share
        # The field is tax_if_sold. Reading "tax" would have returned zero
        # for every candidate and reported a rebalance that costs nothing --
        # a number somebody would act on.
        tax_here = _d(candidate.get("tax_if_sold")) * share

        steps.append({
            "side": "sell",
            "name": candidate.get("name"),
            "value": str(take.quantize(Decimal("1"))),
            "of_position_pct": str((share * 100).quantize(Decimal("0.1"))),
            "all_of_it": share >= Decimal("0.999"),
            "realises_gain": str(gain.quantize(Decimal("1"))),
            "tax": str(tax_here.quantize(Decimal("1"))),
            "short_term": bool(candidate.get("short_term")),
            "why": candidate.get("why"),
        })

        raised += take
        tax += tax_here
        if not candidate.get("short_term"):
            long_gain += gain

    if not steps:
        return None

    # The annual exemption, netted off. Quoting the gross figure overstates
    # what this costs, and most people do not know the allowance exists.
    exempt = min(long_gain, LTCG_EXEMPT)
    saved = exempt * LTCG_PCT / 100
    net_tax = max(Decimal(0), tax - saved)

    return {
        "wanted": str(wanted.quantize(Decimal("1"))),
        "raised": str(raised.quantize(Decimal("1"))),
        "short_by": (str((wanted - raised).quantize(Decimal("1")))
                     if raised < wanted - WORTH_SELLING else None),
        "steps": steps,
        "tax_before_exemption": str(tax.quantize(Decimal("1"))),
        "exemption_used": str(exempt.quantize(Decimal("1"))),
        "tax": str(net_tax.quantize(Decimal("1"))),
        "net_raised": str((raised - net_tax).quantize(Decimal("1"))),
        "put_into": shortlist.get("put_into") or [],
        "reading": _instruction_reading(steps, raised, net_tax, exempt,
                                        shortlist.get("put_into") or []),
        "order_note": (
            "In this order. The ranking weighs how each holding reads against "
            "its sector against what selling it costs — the largest position "
            "is the obvious thing to trim and often the most expensive, "
            "because it is usually the one that has risen most."
        ),
        "sequence_note": (
            "Sell before buying. The proceeds fund the purchases, and a plan "
            "whose steps run out of order fails in a way nobody attributes to "
            "the plan."
        ),
        "not_an_order": (
            "A suggestion to read, change or ignore. Nothing here is placed, "
            "and acting on any line is a separate decision."
        ),
    }


def _instruction_reading(steps: list[dict], raised: Decimal, tax: Decimal,
                         exempt: Decimal, into: list[dict]) -> str:
    line = (f"{len(steps)} sale{'s' if len(steps) != 1 else ''} raising "
            f"₹{int(raised):,}, costing about ₹{int(tax):,} in tax")

    if exempt > 0:
        line += (f" — after ₹{int(exempt):,} of long-term gain that falls under "
                 f"the annual exemption and is taxed at nothing")

    line += "."

    if into:
        where = ", ".join(str(x.get("asset_class", "")).replace("_", " ")
                          for x in into[:2])
        line += f" The proceeds go to {where}."

    return line
