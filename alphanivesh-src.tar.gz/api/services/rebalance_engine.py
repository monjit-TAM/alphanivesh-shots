"""The rebalance engine on stocks.alphamarket.

The recommendation engine for directly held shares, and the source of truth
for every verdict AlphaNivesh shows on one. Three pillars -- fundamental at
35%, momentum at 30%, technical at 35% -- combined against stated thresholds:
a total at or above +25 is a Buy, at or below -25 a Sell, and everything
between is a Hold.

The technical pillar is the substantial part and the reason to defer to it:
RSI(14), MACD(12,26,9), the 50/200 crossover, Supertrend(10,3), OBV and volume
ratio, computed across a 919-stock universe refreshed every fifteen minutes.
That is a real implementation and reproducing it here would be both wasteful
and, since the two would disagree, worse than useless -- a broker's client
seeing one verdict in their report and another here would trust neither.

So this replaces the local quantamental lens for equities rather than sitting
beside it. Their instruction is explicit and correct: do not mix the outputs,
because the scoring models differ and disagreement between two engines reads
as a fault in both.

One thing is kept alongside rather than replaced. Their fundamental pillar
bands the P/E across every industry, which is how Thermax at 62 times earnings
comes back as "very expensive" when its own sector trades at 63. That is not a
disagreement with the verdict -- it is a different measurement, and showing it
under their reason is what stops "expensive" being read as a fact about the
company rather than about the band it fell in.
"""

from __future__ import annotations

import logging
import os
from datetime import date
from decimal import Decimal
from typing import Any, Optional

import httpx

log = logging.getLogger("alphanivesh.rebalance_engine")

BASE_URL = os.environ.get("ALPHA_REBALANCE_URL",
                          "https://stocks.alphamarket.co.in/api/v1/external")
API_KEY = os.environ.get("ALPHA_REBALANCE_KEY", "")

# Their own note says four to fifteen seconds depending on portfolio size, and
# to allow thirty.
TIMEOUT = httpx.Timeout(30.0, connect=8.0)

MAX_HOLDINGS = 100


class EngineError(Exception):
    """The engine could not answer. Carries something worth showing."""


def healthy() -> bool:
    """Whether the engine is up and its universe is loaded. No key needed."""
    try:
        with httpx.Client(timeout=httpx.Timeout(8.0)) as client:
            response = client.get(f"{BASE_URL}/rebalance/health")
            if response.status_code != 200:
                return False
            return (response.json() or {}).get("status") == "healthy"
    except (httpx.HTTPError, ValueError):
        return False


def methodology() -> Optional[dict]:
    """How the scoring works, in their own words.

    Open, no key, and meant to be shown to end users. Worth surfacing rather
    than summarising: a verdict whose derivation somebody can read is a
    different kind of claim from one they have to take on trust.
    """
    try:
        with httpx.Client(timeout=httpx.Timeout(15.0)) as client:
            response = client.get(f"{BASE_URL}/rebalance/methodology")
            response.raise_for_status()
            return response.json()
    except (httpx.HTTPError, ValueError) as err:
        log.warning("methodology fetch failed: %s", err)
        return None


def analyse(holdings: list[dict], *, max_picks: int = 10) -> dict:
    """Run a portfolio through the engine.

    `holdings` is a list of {stock_name, quantity, buy_price, buy_date}. The
    symbol may be an NSE ticker or an ISIN; theirs resolves either, and adjusts
    for splits and bonuses -- which is worth more here than it sounds, since our
    own price history is the unadjusted exchange record.
    """
    if not API_KEY:
        raise EngineError(
            "No key configured for the rebalance engine. Set ALPHA_REBALANCE_KEY.")
    if not holdings:
        raise EngineError("No holdings to analyse.")
    if len(holdings) > MAX_HOLDINGS:
        raise EngineError(
            f"The engine takes {MAX_HOLDINGS} holdings at a time; this portfolio "
            f"has {len(holdings)}.")

    body = {
        "holdings": holdings,
        "max_picks": max(3, min(int(max_picks), 15)),
        "bypass_validation": False,
    }

    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            response = client.post(
                f"{BASE_URL}/rebalance", json=body,
                headers={"Content-Type": "application/json",
                         "X-API-Key": API_KEY},
            )
    except httpx.HTTPError as err:
        raise EngineError(f"could not reach the rebalance engine: {err}")

    if response.status_code == 401:
        raise EngineError("the rebalance engine rejected the key")
    if response.status_code == 403:
        raise EngineError("this broker account is not active on the engine")
    if response.status_code == 429:
        wait = response.headers.get("Retry-After", "a moment")
        raise EngineError(f"the engine is rate limited; try again in {wait}")
    if response.status_code >= 400:
        detail = ""
        try:
            detail = (response.json() or {}).get("error") or ""
        except ValueError:
            pass
        raise EngineError(detail or f"the engine returned status {response.status_code}")

    try:
        payload = response.json()
    except ValueError:
        raise EngineError("the engine returned something unreadable")

    if payload.get("success") is False:
        raise EngineError(payload.get("error") or "the engine declined the request")

    return payload


def for_investor(investor_id: str, *, max_picks: int = 10) -> Optional[dict]:
    """Everything the engine says about somebody's directly held shares.

    Holdings are sent with what was actually paid and when, since the engine's
    momentum pillar reads the position's own gain. Where a purchase date is
    missing the holding still goes -- their validation accepts it -- but the
    momentum reading on that line is weaker, which is worth knowing rather than
    hiding.
    """
    from .. import db

    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.symbol, v.isin,
               v.quantity, v.invested_value, v.current_value,
               (SELECT min(h.as_of) FROM holding_snapshots h
                WHERE h.instrument_id = v.instrument_id
                  AND h.investor_id = v.investor_id
                  AND h.as_of > '1990-01-01') AS bought,
               (SELECT h.avg_cost FROM holding_snapshots h
                WHERE h.instrument_id = v.instrument_id
                  AND h.investor_id = v.investor_id AND h.avg_cost IS NOT NULL
                ORDER BY h.as_of LIMIT 1) AS avg_cost
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.asset_class = 'equity'
          AND v.quantity > 0
        ORDER BY v.current_value DESC
        LIMIT %s
        """,
        (investor_id, MAX_HOLDINGS),
    )
    if not rows:
        return None

    holdings = []
    undated = 0
    for row in rows:
        symbol = (row["symbol"] or row["isin"] or "").strip()
        quantity = Decimal(str(row["quantity"] or 0))
        if not symbol or quantity <= 0:
            continue

        # What each unit cost. The engine wants an average price, and where we
        # hold one it is better than dividing a total that may include units
        # since redeemed.
        if row["avg_cost"]:
            price = Decimal(str(row["avg_cost"]))
        elif row["invested_value"]:
            price = Decimal(str(row["invested_value"])) / quantity
        else:
            continue
        if price <= 0:
            continue

        entry = {
            "stock_name": symbol,
            "quantity": float(quantity),
            "buy_price": float(price.quantize(Decimal("0.01"))),
        }
        if row["bought"]:
            entry["buy_date"] = row["bought"].isoformat()
        else:
            undated += 1
        holdings.append(entry)

    if not holdings:
        return None

    try:
        result = analyse(holdings, max_picks=max_picks)
    except EngineError as err:
        log.warning("rebalance engine failed for %s: %s", investor_id, err)
        return {"available": False, "why": str(err)}

    return {
        "available": True,
        "summary": result.get("portfolio_summary"),
        "holdings": result.get("holdings_analysis") or [],
        "sell": result.get("sell_recommendations") or [],
        "buy": result.get("buy_recommendations") or [],
        "sell_total": result.get("total_sell_amount"),
        "buy_allocated": result.get("total_buy_allocated"),
        "unallocated": result.get("unallocated_amount"),
        "alerts": result.get("concentration_alerts") or [],
        "methodology": result.get("methodology"),
        "engine": (result.get("metadata") or {}).get("engine_version"),
        "undated": undated,
        "note": ("Verdicts come from the AlphaLens rebalance engine, which is "
                 "what the broker reports and the other products use. The same "
                 "share reads the same everywhere, which is the point of not "
                 "having a second opinion here."),
    }
