"""Who brought this investor, and what they agreed to.

Two kinds of investor arrive.

**Direct.** They found the site and signed up. Nobody referred them, they owe
nobody a fee, and there is no advisory relationship to agree to — so no
agreement is put in front of them. Asking somebody to sign an advisory
agreement with nobody would be theatre.

**Referred.** An RIA or an MFD sent them, by link or by code. There is a
relationship, it has terms, and they agree before anything else happens.

**Managing somebody and being their adviser of record are different things**,
and this module keeps them apart. A direct investor is managed from the
platform's own desk, which does not make the platform their adviser of record —
it is not registered, and `advisory_mandate` is where that fact lives.
Conflating the two would let an unregistered party appear as somebody's adviser
because they happened to be managing the account.

**And the agreement records which version was seen.** The wording changes; what
somebody agreed to does not. A record pointing at "the current terms" answers a
question nobody asked.
"""

from __future__ import annotations

import hashlib
import logging
import re
import secrets
from datetime import date
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.referrals")

# Short enough to say over a phone, long enough not to collide. No vowels, so
# it cannot spell anything, and no characters that look like each other in the
# fonts people read codes in.
ALPHABET = "BCDFGHJKLMNPQRSTVWXYZ23456789"
LENGTH = 6


def _mint() -> str:
    return "".join(secrets.choice(ALPHABET) for _ in range(LENGTH))


def make_code(professional_id: str, label: Optional[str] = None,
              expires_on: Optional[date] = None) -> dict:
    """A code for a professional to hand out.

    Several are allowed on purpose: one per campaign, or per branch, so
    somebody can tell where their clients came from without a separate system
    for it.
    """
    for _ in range(8):
        code = _mint()
        try:
            with db.connection() as conn:
                row = conn.execute(
                    """
                    INSERT INTO referral_code
                        (professional_id, code, label, expires_on)
                    VALUES (%s, %s, %s, %s)
                    RETURNING id, code
                    """,
                    (professional_id, code, label, expires_on)).fetchone()
            return {"id": row["id"], "code": row["code"],
                    "link": f"https://alphanivesh.com/?ref={row['code']}"}
        except Exception as err:
            # A collision is the expected failure and worth retrying. Anything
            # else is not, and should not be retried eight times.
            if "referral_code_code_key" not in str(err):
                raise
    raise RuntimeError("Could not mint a unique code.")


def codes_for(professional_id: str) -> list[dict]:
    rows = db.fetch_all(
        """
        SELECT id, code, label, active, expires_on, used_count, created_at
        FROM referral_code WHERE professional_id = %s
        ORDER BY created_at DESC
        """,
        (professional_id,))
    return [{
        "id": r["id"], "code": r["code"], "label": r["label"],
        "active": r["active"],
        "expires_on": r["expires_on"].isoformat() if r["expires_on"] else None,
        "used": r["used_count"],
        "link": f"https://alphanivesh.com/?ref={r['code']}",
    } for r in rows]


def whose(code: str) -> Optional[dict]:
    """Who a code belongs to, if it is usable.

    Returns None for anything expired, switched off, or attached to a
    professional whose registration is not active — a code outliving the
    registration behind it would attach clients to somebody who cannot
    currently serve them.
    """
    if not code:
        return None

    row = db.fetch_one(
        """
        SELECT r.id, r.code, r.professional_id, r.expires_on, r.active,
               p.kind, p.firm_name, p.status, p.user_id
        FROM referral_code r
        JOIN professional p ON p.id = r.professional_id
        WHERE upper(r.code) = upper(%s)
        """,
        (code.strip(),))
    if not row:
        return None

    if not row["active"]:
        return None
    if row["expires_on"] and row["expires_on"] < date.today():
        return None
    if row["status"] != "active":
        log.info("code %s belongs to a professional who is %s",
                 code, row["status"])
        return None

    return {
        "code_id": row["id"],
        "code": row["code"],
        "professional_id": row["professional_id"],
        "kind": row["kind"],
        "firm_name": row["firm_name"],
        # Which agreement they will be asked to sign.
        "agreement_kind": "client_ria" if row["kind"] in ("ria", "ra")
                          else "client_mfd",
    }


def note_used(code_id: str) -> None:
    try:
        with db.connection() as conn:
            conn.execute(
                "UPDATE referral_code SET used_count = used_count + 1 "
                "WHERE id = %s", (code_id,))
    except Exception:                                            # pragma: no cover
        pass


# ---------------------------------------------------------------------------
# Agreements
# ---------------------------------------------------------------------------

def digest_of(body: str) -> str:
    """A fingerprint of the text somebody actually saw.

    So the record says which words were agreed to rather than pointing at
    whatever the current wording happens to be.
    """
    return hashlib.sha256((body or "").encode("utf-8")).hexdigest()[:32]


def record_agreement(kind: str, version: str, body: str, *,
                     user_id: Optional[str] = None,
                     investor_id: Optional[str] = None,
                     professional_id: Optional[str] = None,
                     ip: Optional[str] = None,
                     user_agent: Optional[str] = None,
                     esign_ref: Optional[str] = None,
                     esign_name: Optional[str] = None) -> dict:
    if kind not in ("professional_terms", "client_ria", "client_mfd",
                    "client_broker"):
        raise ValueError("unknown agreement kind")

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO agreement
                (kind, version, body_digest, user_id, investor_id,
                 professional_id, ip, user_agent, esign_ref, esign_name)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id, agreed_at
            """,
            (kind, version, digest_of(body), user_id, investor_id,
             professional_id, ip, (user_agent or "")[:400], esign_ref,
             esign_name)).fetchone()

    return {"id": row["id"],
            "agreed_at": row["agreed_at"].isoformat() if row else None}


def has_agreed(kind: str, *, user_id: Optional[str] = None,
               investor_id: Optional[str] = None) -> Optional[dict]:
    """Whether this agreement is on file, and which version."""
    if not (user_id or investor_id):
        return None

    row = db.fetch_one(
        """
        SELECT id, version, agreed_at, esign_name
        FROM agreement
        WHERE kind = %s
          AND (%s::text IS NULL OR user_id = %s)
          AND (%s::text IS NULL OR investor_id = %s)
        ORDER BY agreed_at DESC LIMIT 1
        """,
        (kind, user_id, user_id, investor_id, investor_id))
    if not row:
        return None
    return {"id": row["id"], "version": row["version"],
            "agreed_at": row["agreed_at"].isoformat(),
            "signed_by": row["esign_name"]}


def what_is_needed(investor_id: str) -> dict:
    """What this investor still has to agree to, if anything.

    A direct investor needs nothing. A referred one needs the agreement
    matching the kind of professional who sent them, and until it is signed
    that professional should not be seeing their portfolio.
    """
    row = db.fetch_one(
        """
        SELECT i.is_direct, i.came_via,
               c.professional_id, c.consented_at,
               p.kind, p.firm_name
        FROM investors i
        LEFT JOIN client_of c ON c.investor_id = i.id AND c.ended_on IS NULL
        LEFT JOIN professional p ON p.id = c.professional_id
        WHERE i.id = %s
        """,
        (investor_id,))
    if not row:
        return {"needed": False}

    if row["is_direct"] and not row["professional_id"]:
        return {
            "needed": False,
            "why": ("You came to us directly, so there is no adviser or "
                    "distributor relationship to agree terms for. Nothing to "
                    "sign."),
        }

    kind = ("client_ria" if row["kind"] in ("ria", "ra") else "client_mfd")
    signed = has_agreed(kind, investor_id=investor_id)

    if signed:
        return {"needed": False, "signed": signed,
                "with": row["firm_name"], "kind": kind}

    return {
        "needed": True,
        "kind": kind,
        "with": row["firm_name"],
        "why": (f"{row['firm_name'] or 'The firm that referred you'} needs your "
                f"agreement before they can act for you or see what you hold."),
    }
