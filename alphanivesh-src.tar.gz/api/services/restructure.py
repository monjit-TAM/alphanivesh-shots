"""What a portfolio is missing, what would fill it, and what it would become.

Three questions the rest of the service does not answer.

**What is absent.** Every other reading looks at what somebody holds. The
things that matter most are often the ones not there at all: no debt, no
liquidity, one industry carrying two thirds of the money, nothing outside
India. An absence has no line in a holdings table and no finding attached to
it, so it goes unremarked -- and a reader looking at a page of what they own
will not notice what they do not.

**What would fill it.** Naming a gap without naming a way to close it leaves
the reader where they started. The candidates here come from the shared
research service, ranked on rolling three-year returns within their category,
and each carries the reason it is on the list -- its rank, how often it ended
positive, the worst it has done. Ranked on a stated measure rather than scored,
which is what makes it repeatable by anybody with the same data.

**What it would look like after.** The part nobody shows. Somebody told to
reduce a 63% sector position has no idea what the portfolio becomes if they do
-- and the answer, recomputed rather than asserted, is usually the argument
that persuades.

None of it is advice to buy anything. It is the shape of a gap, the funds that
sit in that shape, and the arithmetic of closing it. What somebody should
actually do depends on things a calculation cannot see, which is why the
adviser is in the room.
"""

from __future__ import annotations

import logging
import re
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.restructure")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("-" if negative else "") + digits


# What a portfolio is expected to contain, and why. These are not targets --
# nobody has to hold gold -- but an absence is worth naming so it can be a
# decision rather than an oversight.
EXPECTED = (
    {
        "key": "debt",
        "asks": "Anything that does not fall when equities do",
        "classes": ("bond", "gsec", "fixed_deposit", "cash"),
        "matters": (
            "In a bad year everything equity falls together. Something that "
            "does not is what lets you leave the equities alone rather than "
            "selling them at the worst moment -- and what you sell in a fall "
            "is the part that would have recovered."
        ),
        "fills_with": ("Corporate Bond", "Short Duration"),
    },
    {
        "key": "liquidity",
        "asks": "Money reachable in a day without selling anything that has fallen",
        "classes": ("cash", "fixed_deposit"),
        "matters": (
            "An emergency arriving during a market fall means selling equity at "
            "the price the fall has set. A liquid fund earns less and removes "
            "that possibility entirely, which is worth more than the yield it "
            "gives up."
        ),
        "fills_with": ("Liquid",),
    },
    {
        "key": "gold",
        "asks": "Something that has historically risen when equities fell",
        "classes": ("gold",),
        "matters": (
            "Gold does not earn anything and is not held for return. It is held "
            "because it has often moved the other way in the years equities had "
            "their worst, which makes the whole portfolio easier to hold on to."
        ),
        "fills_with": ("Gold", "Fund of Fund", "Other Scheme"),
        "name_must_have": ("gold",),
        "optional": True,
    },
    {
        "key": "international",
        "asks": "Anything outside one country's economy",
        "classes": ("international",),
        "matters": (
            "Every rupee here depends on one economy, one currency and one "
            "government's decisions. That is a concentration nobody chose -- it "
            "is what happens by default -- and it is invisible because every "
            "holding looks different from every other."
        ),
        # AMFI files these under "Fund of Fund" and "Overseas" alongside every
        # thematic ETF, so the category alone cannot tell a global fund from an
        # AI one. Matched on the name, the way the data service's own bucketing
        # does, and narrowed to the broad ones: a NASDAQ tracker is one
        # country's large technology companies and does not answer "anything
        # outside one economy".
        "fills_with": ("Fund of Fund", "Overseas", "Global"),
        "name_must_have": ("global", "international", "world", "emerging",
                           "us opportunities", "developed"),
        "avoid_words": ("artificial intelligence", "technology", "semiconductor",
                        "electric vehicle", "healthcare", "nasdaq", "fang",
                        "thematic", "sector"),
        "optional": True,
    },
)

# Below this share, a class counts as absent rather than merely small.
PRESENT_AT = Decimal("3")

# A sector past this is a concentration worth naming as a gap in the rest.
SECTOR_HEAVY = Decimal("35")


def what_is_missing(investor_id: str) -> dict:
    """The things not here, and why each would matter.

    Reported as absences rather than as errors. Somebody holding no debt at
    thirty with a secure income has made a defensible choice; somebody holding
    none at fifty-eight has probably not made one at all. The difference is not
    something the holdings can settle, so this names the gap and leaves the
    judgement where it belongs.
    """
    from . import analysis, wealth

    allocation = wealth.allocation(investor_id)
    total = sum(_d(a["value"]) for a in allocation) or Decimal(1)
    held = {a["asset_class"]: _d(a["value"]) / total * 100 for a in allocation}

    gaps = []
    for expected in EXPECTED:
        share = sum(held.get(cls, Decimal(0)) for cls in expected["classes"])
        if share >= PRESENT_AT:
            continue
        gaps.append({
            "key": expected["key"],
            "what": expected["asks"],
            "you_have": f"{share:.1f}%" if share > 0 else "none",
            "why_it_matters": expected["matters"],
            "fills_with": list(expected["fills_with"]),
            "avoid_words": expected.get("avoid_words", ()),
            "name_must_have": expected.get("name_must_have", ()),
            "optional": expected.get("optional", False),
        })

    # An industry carrying most of the money is a gap in everything else,
    # which is a different thing from a concentration finding: one says what
    # is too much, this says what is not there.
    try:
        sectors = analysis.sector_exposure(investor_id)
    except Exception:
        sectors = {}
    coverage = _d(sectors.get("attributed_share_pct"))
    listed = [s for s in (sectors.get("sectors") or [])
              if (s.get("sector") or "").lower() != "not classified"]

    if coverage >= 50 and listed and _d(listed[0]["share_pct"]) >= SECTOR_HEAVY:
        heavy = listed[0]
        thin = [s["sector"] for s in listed[1:] if _d(s["share_pct"]) < 5][:3]
        gaps.append({
            "key": "sector_breadth",
            "what": "Industries other than the one carrying most of the money",
            "you_have": f"{_d(heavy['share_pct']):.0f}% in {heavy['sector'].lower()}",
            "why_it_matters": (
                f"When {heavy['sector'].lower()} has a bad year most of this "
                f"portfolio has one, and the holdings that look like they would "
                f"cushion it are in the same industry. What is thin is everything "
                f"else"
                + (f" \u2014 {', '.join(s.lower() for s in thin)} between them are "
                   f"under five per cent." if thin else ".")
            ),
            "fills_with": ["Flexi Cap", "Large Cap"],
            "optional": False,
        })

    return {
        "gaps": gaps,
        "reading": (
            "Nothing obvious is missing." if not gaps else
            f"{len(gaps)} thing{'s' if len(gaps) != 1 else ''} this portfolio "
            f"does not have."
        ),
        "note": ("An absence is not automatically a mistake. Somebody at thirty "
                 "with a secure income and no debt holdings has made a "
                 "defensible choice; somebody at fifty-eight with none has "
                 "probably not made a choice at all. Which of those this is "
                 "depends on things the holdings cannot say."),
    }



# Plan variants a retail investor cannot buy, or should not be offered.
# Institutional and super-institutional plans have minimums in crores; bonus
# and legacy options are mostly closed to new money and carry tax treatment
# nobody wants to explain. Offering any of them is the kind of mistake that
# tells a reader the list was generated rather than chosen.
_NOT_FOR_RETAIL = re.compile(
    r"\b(super\s+)?institutional\b|\bbonus\b|\bsegregated\b|"
    r"\bretail\s+plan\b.*\bdiscontinued\b|\bunclaimed\b", re.I)

# A fund whose worst three-year stretch is strongly positive has not been
# through a bad market -- its whole history sits inside one run. Reporting that
# as "the floor to be ready for" is the most misleading thing this system could
# say, because it reads as a guarantee derived from evidence when it is an
# artefact of when the fund launched.
UNTESTED_FLOOR = Decimal("15")


def _buyable(name: str) -> bool:
    return not _NOT_FOR_RETAIL.search(name or "")


def options_for(gap_key: str, fills_with: list[str], limit: int = 3,
                avoid_words: tuple = (),
                name_must_have: tuple = ()) -> list[dict]:
    """Funds that would fill a gap, from the shared research screener.

    This used to search our own instrument list and rank it by calling the
    scheme endpoint per candidate, which failed on every gap: the local list
    carries names and codes but none of the return history the ranking needs.

    The screener already does it properly -- every fund in a category ranked on
    all weekly-stepped three-year windows in its history, with the median, how
    often it ended positive, and the worst window there has been. Direct plans
    only. Rebuilding that badly was the mistake; calling it is twenty lines.
    """
    from . import dataservice

    found: list[dict] = []
    seen: set[str] = set()

    for category in fills_with:
        try:
            rows = dataservice.mf_screener(
                category=category, sort="cat_rank",
                limit=(40 if name_must_have else limit + 6))
        except dataservice.DataServiceError as err:
            log.warning("screener failed for %s: %s", category, err)
            continue

        for row in rows:
            code = str(row.get("scheme_code") or "")
            if not code or code in seen:
                continue
            name = row.get("scheme_name") or ""
            if not _buyable(name):
                continue
            # A theme is not the thing the gap asked for. "International"
            # returns a NASDAQ tracker and an AI fund alongside a genuinely
            # global one, and only the last answers "outside one economy".
            lower = name.lower()
            if avoid_words and any(w in lower for w in avoid_words):
                continue
            # Where the category cannot identify what the gap needs -- gold and
            # international both sit under fund-of-fund names -- the name has
            # to carry it.
            if name_must_have and not any(w in lower for w in name_must_have):
                continue
            seen.add(code)
            found.append({
                "name": row.get("scheme_name"),
                "code": code,
                "amc": row.get("amc"),
                "category": row.get("category"),
                "fills": category,
                "rank": row.get("cat_rank"),
                "of": row.get("cat_n"),
                "roll3_median": row.get("roll3_median"),
                "roll3_worst": row.get("roll3_worst"),
                "roll3_pos_pct": row.get("roll3_pos_pct"),
                "why": _why_this_fund(row),
                "untested": bool(_untested(row)),
            })

    # Best rank within its own category first, so a fund ranked 1 of 21 comes
    # before one ranked 1 of 5 -- a larger category is a harder rank to hold.
    found.sort(key=lambda r: ((r["rank"] or 999) / max(r["of"] or 1, 1),
                              -(r["of"] or 0)))
    return found[:limit]


def _untested(row: dict) -> Optional[str]:
    """Whether the fund's record covers a bad market, or only a good one.

    A worst three-year stretch of +30% a year does not mean the fund is safe.
    It means every three-year window it has ever had falls inside one
    exceptional run -- usually because the fund launched into it. The figure is
    arithmetically correct and tells a reader the opposite of the truth.
    """
    worst = row.get("roll3_worst")
    if worst is None:
        return None
    if _d(worst) < UNTESTED_FLOOR:
        return None
    return (f"Every three-year stretch in this fund's record returned at least "
            f"{_d(worst):.0f}% a year, which does not mean it cannot fall \u2014 it "
            f"means the fund has not existed through a bad market. There is no "
            f"floor here to be ready for, because nothing has tested it.")


def _why_this_fund(row: dict) -> list[str]:
    """The reasons, each checkable against the same table it came from."""
    reasons = []

    rank, size = row.get("cat_rank"), row.get("cat_n")
    if rank and size:
        reasons.append(f"ranked {rank} of {size} in its category on rolling "
                       f"three-year returns \u2014 consistency rather than one "
                       f"good year")

    median = row.get("roll3_median")
    if median is not None:
        reasons.append(f"the middle three-year stretch returned "
                       f"{_d(median):.1f}% a year")

    positive = row.get("roll3_pos_pct")
    if positive is not None and _d(positive) >= 90:
        reasons.append(f"{_d(positive):.0f}% of every three-year window in its "
                       f"history ended positive")

    worst = row.get("roll3_worst")
    untested = _untested(row)
    if untested:
        reasons.append(untested)
    elif worst is not None:
        reasons.append(f"the worst three years it has had returned "
                       f"{_d(worst):.1f}% a year \u2014 the floor to be ready for")

    return reasons


def what_it_would_look_like(investor_id: str,
                            moves: Optional[list[dict]] = None) -> Optional[dict]:
    """The portfolio after the changes, recomputed rather than asserted.

    Somebody told to cut a 63% sector position has no idea what the portfolio
    becomes if they do. The answer is usually the argument that persuades, and
    it is arithmetic rather than opinion: the same allocation, concentration and
    sector figures, computed on the holdings as they would be.

    `moves` is a list of {instrument_id, reduce_by} and {asset_class, add} --
    what the recommendations propose. Where none is given this derives them
    from the target mix, so the reader sees the effect of doing what the drift
    section already asks for.
    """
    from . import analysis, profile as profile_service, wealth

    allocation = wealth.allocation(investor_id)
    total = sum(_d(a["value"]) for a in allocation)
    if total <= 0:
        return None

    if moves is None:
        drift = profile_service.drift(investor_id)
        if not drift or drift.get("in_line"):
            return None
        moves = []
        for line in drift["lines"]:
            if not line["beyond_tolerance"]:
                continue
            moves.append({"asset_class": line["asset_class"],
                          "change": _d(line["to_move"]) * -1})

    # The allocation as it would be.
    after: dict[str, Decimal] = {a["asset_class"]: _d(a["value"]) for a in allocation}
    for move in moves:
        cls = move.get("asset_class")
        if cls is None:
            continue
        after[cls] = max(Decimal(0), after.get(cls, Decimal(0)) + _d(move["change"]))

    after_total = sum(after.values()) or Decimal(1)

    before_lines = []
    for entry in allocation:
        cls = entry["asset_class"]
        was = _d(entry["value"]) / total * 100
        now = after.get(cls, Decimal(0)) / after_total * 100
        before_lines.append({
            "asset_class": cls,
            "before_pct": str(was.quantize(Decimal("0.1"))),
            "after_pct": str(now.quantize(Decimal("0.1"))),
            "before_value": str(_d(entry["value"]).quantize(Decimal("1"))),
            "after_value": str(after.get(cls, Decimal(0)).quantize(Decimal("1"))),
        })

    # Classes being added that are not held at all today.
    for move in moves:
        cls = move.get("asset_class")
        if cls and not any(l["asset_class"] == cls for l in before_lines):
            before_lines.append({
                "asset_class": cls,
                "before_pct": "0.0",
                "after_pct": str((after.get(cls, Decimal(0)) / after_total * 100)
                                 .quantize(Decimal("0.1"))),
                "before_value": "0",
                "after_value": str(after.get(cls, Decimal(0)).quantize(Decimal("1"))),
            })

    # What the change does to the things the rest of the page complains about.
    concentration = analysis.concentration(investor_id)
    equity_before = next((_d(a["value"]) for a in allocation
                          if a["asset_class"] == "equity"), Decimal(0))
    equity_after = after.get("equity", Decimal(0))
    equity_share_before = equity_before / total * 100
    equity_share_after = equity_after / after_total * 100

    effects = []
    if equity_before > 0 and equity_after < equity_before:
        # A sector concentration measured across the whole portfolio falls in
        # proportion to the equity being reduced, since that is where it sits.
        try:
            sectors = analysis.sector_exposure(investor_id)
            listed = [s for s in (sectors.get("sectors") or [])
                      if (s.get("sector") or "").lower() != "not classified"]
            if listed:
                heavy = listed[0]
                was = _d(heavy["share_pct"])
                becomes = was * (equity_after / equity_before)
                effects.append({
                    "what": f"Money in {heavy['sector'].lower()}",
                    "before": f"{was:.0f}%",
                    "after": f"{becomes:.0f}%",
                })
        except Exception:
            pass

        effects.append({
            "what": "In equities",
            "before": f"{equity_share_before:.0f}%",
            "after": f"{equity_share_after:.0f}%",
        })

    return {
        "lines": [l for l in before_lines
                  if _d(l["before_value"]) > 0 or _d(l["after_value"]) > 0],
        "effects": effects,
        "total": str(total.quantize(Decimal("1"))),
        "reading": _describe_after(effects, equity_share_before, equity_share_after),
        "caveat": ("The figures after are the same arithmetic applied to the "
                   "holdings as they would be. What it does not include is the "
                   "tax on getting there, which is set out against each action, "
                   "or what the market does in between."),
    }


def _describe_after(effects: list[dict], before: Decimal, after: Decimal) -> str:
    if not effects:
        return "The changes would not materially alter the shape."
    parts = [f"Equities would fall from {before:.0f}% to {after:.0f}% of the "
             f"portfolio."]
    for effect in effects:
        if effect["what"].startswith("Money in"):
            parts.append(f"{effect['what']} would go from {effect['before']} to "
                         f"{effect['after']}.")
    parts.append("Nothing else about the holdings changes \u2014 the same funds, "
                 "the same companies, in different proportions.")
    return " ".join(parts)


def alternatives(investor_id: str) -> dict:
    """The gaps, what would fill each, and what the portfolio becomes."""
    missing = what_is_missing(investor_id)

    for gap in missing["gaps"]:
        try:
            gap["options"] = options_for(
                gap["key"], gap.get("fills_with") or [],
                avoid_words=gap.get("avoid_words") or (),
                name_must_have=gap.get("name_must_have") or ())
        except Exception as err:                                 # pragma: no cover
            log.warning("options failed for %s: %s", gap["key"], err)
            gap["options"] = []

    return {
        **missing,
        "after": what_it_would_look_like(investor_id),
        "disclaimer": (
            "These are funds that sit in the shape of a gap, ranked on their own "
            "published record. They are not a recommendation to buy: which one "
            "suits somebody depends on their tax position, their horizon and "
            "what they already hold elsewhere, none of which a ranking can see."
        ),
    }
