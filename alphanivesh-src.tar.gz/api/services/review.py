"""The review.

`cadence.due()` says a review is owed and roughly what would go in it. This
writes it: a short document somebody reads in three minutes that tells them
what changed, what it was worth, and whether anything needs doing.

**The test for every line is the same one the notifications use.** Would this
be worth an SMS from a person who knows their money? If not it does not go in,
and if nothing passes then no review goes out at all — which `cadence.due()`
already enforces and this respects rather than padding to fill a template.

**It leads with what changed, not with what things are worth.** Somebody who
opens a quarterly review knows roughly what their portfolio is worth. What they
do not know is what moved, what the advice they took produced, and what has
appeared since. A review that opens with a balance is a statement, and people
already get statements.

**And it says what it is not.** A review assembled from three months of price
movement is not a verdict on anybody's investing, and saying so is what makes
the parts that are verdicts trustworthy.

The output is structural rather than formatted, so the same assembly renders
as an email, a page or a PDF without three versions of the wording drifting
apart.
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.review")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def _period_name(days: int) -> str:
    if days <= 40:
        return "the past month"
    if days <= 100:
        return "the past three months"
    if days <= 200:
        return "the past six months"
    return "the past year"


def assemble(investor_id: str, force: bool = False) -> Optional[dict]:
    """Write the review, or return None if there is nothing worth sending.

    `force` skips the cadence check but not the content check. A review with
    nothing in it is not worth sending on any schedule, and being able to
    override the timing is useful while the override for emptiness is not.
    """
    from . import cadence, wealth

    verdict = cadence.due(investor_id)
    if not force and not verdict.get("due"):
        return None

    contents = verdict.get("contents") or []
    if not contents:
        # Assemble anyway when forced, from whatever the platform can see.
        from .cadence import _worth_saying
        contents = _worth_saying(investor_id).get("items") or []
    if not contents:
        return None

    investor = wealth.get_investor(investor_id)
    if not investor:
        return None

    days = int(verdict.get("days_since") or 90)
    pref = cadence.preference(investor_id)

    sections = []

    changed = [c for c in contents if c.get("kind") == "changed"]
    worked = [c for c in contents if c.get("kind") == "worked"]
    urgent = [c for c in contents if c.get("kind") == "urgent"]

    # Urgent first, because it has a deadline and the rest does not.
    if urgent:
        sections.append({
            "key": "urgent",
            "title": ("Worth doing before it expires" if len(urgent) == 1
                      else "Worth doing soon"),
            "items": [{"headline": u["headline"], "detail": u.get("detail")}
                      for u in urgent],
        })

    # Then what the advice produced, because it is the only part nobody else
    # can write and the reason the next piece of advice is worth reading.
    if worked:
        sections.append({
            "key": "worked",
            "title": "What you did, and what it was worth",
            "items": [{"headline": w["headline"], "detail": w.get("detail")}
                      for w in worked],
        })

    if changed:
        sections.append({
            "key": "changed",
            "title": f"What moved in {_period_name(days)}",
            "items": [{"headline": c["headline"], "detail": c.get("detail")}
                      for c in changed],
        })

    figures = _figures(investor_id)
    opening = _opening(investor, sections, days)

    return {
        "investor_id": investor_id,
        "name": investor.get("display_name"),
        "written_on": date.today().isoformat(),
        "covers_days": days,
        "period": _period_name(days),
        "cadence": pref.get("cadence"),
        "subject": _subject(sections, investor),
        "opening": opening,
        "sections": sections,
        "figures": figures,
        "closing": (
            "Everything above traces to a rule applied to figures you can "
            "check, and the full working is on the site. Nothing here is a "
            "forecast."
        ),
        "what_this_is_not": (
            f"This covers {_period_name(days)}, which is long enough to notice "
            f"things and much too short to judge how the investing is going. "
            f"Treat it as a prompt rather than a verdict."
        ),
        "next_on": None,
    }


def _figures(investor_id: str) -> list[dict]:
    """The three or four numbers a reader would want alongside the prose.

    Not a statement. Enough to place what follows, with the coverage caveat
    where the gain describes only part of the money — the same caveat the page
    carries, because a figure that means one thing on screen and another in an
    email is worse than no figure.
    """
    from . import wealth

    try:
        n = wealth.net_worth(investor_id)
    except Exception as err:
        log.warning("no figures for %s: %s", investor_id, err)
        return []

    covers = _d(n.get("gain_covers_pct"))
    partial = 0 < covers < 95

    out = [
        {"label": "What you hold", "value": _money(n.get("total_value")),
         "note": f"{n.get('positions')} holdings"},
        {"label": "Gained", "value": _money(n.get("absolute_gain")),
         "note": (f"{_d(n.get('absolute_return_pct')).quantize(Decimal('0.1'))}% "
                  + (f"on the {n.get('gain_covers_pct')}% we can price"
                     if partial else "on what went in"))},
    ]

    try:
        from . import debts
        owed = debts.for_investor(investor_id)
        if owed.get("recorded") and _d(owed.get("total")) > 0:
            out.append({"label": "Owed", "value": _money(owed.get("total")),
                        "note": "across your loans"})
    except Exception:
        pass

    return out


def _opening(investor: dict, sections: list[dict], days: int) -> str:
    """One paragraph that says why this arrived.

    A review that opens with a balance is a statement, and people already get
    statements. This opens with what changed.
    """
    name = (investor.get("display_name") or "").split()[0].title()
    period = _period_name(days)

    counts = {s["key"]: len(s["items"]) for s in sections}

    if counts.get("urgent"):
        return (f"{name}, one thing here has a deadline. The rest of this is "
                f"what moved in {period} and what it was worth.")

    if counts.get("worked"):
        return (f"{name}, this is what happened in {period} — including what "
                f"the changes you made have produced so far.")

    return (f"{name}, this is what moved in {period}. Nothing here is urgent; "
            f"it is the kind of thing worth knowing before it becomes "
            f"something to act on.")


def _subject(sections: list[dict], investor: dict) -> str:
    """The subject line, which decides whether any of this gets read.

    Specific rather than branded. "Your quarterly review" tells somebody
    nothing they cannot guess and reads like every other message they delete.
    """
    urgent = next((s for s in sections if s["key"] == "urgent"), None)
    if urgent:
        first = urgent["items"][0]["headline"]
        return first if len(first) < 78 else first[:75] + "…"

    worked = next((s for s in sections if s["key"] == "worked"), None)
    if worked:
        return worked["items"][0]["headline"][:78]

    changed = next((s for s in sections if s["key"] == "changed"), None)
    if changed:
        return changed["items"][0]["headline"][:78]

    return "Your portfolio, briefly"


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def as_text(review: dict) -> str:
    """Plain text. The version that always arrives, whatever the client."""
    lines = [review["opening"], ""]

    if review.get("figures"):
        for fig in review["figures"]:
            lines.append(f"  {fig['label']}: {fig['value']}  ({fig['note']})")
        lines.append("")

    for section in review["sections"]:
        lines.append(section["title"].upper())
        for item in section["items"]:
            lines.append(f"  - {item['headline']}")
            if item.get("detail"):
                lines.append(f"    {item['detail']}")
        lines.append("")

    lines.append(review["what_this_is_not"])
    lines.append("")
    lines.append(review["closing"])
    return "\n".join(lines)


def as_html(review: dict, site: str = "https://alphanivesh.com") -> str:
    """The email.

    Deliberately plain: tables and inline styles because that is what mail
    clients render reliably, and no images because half of them are blocked by
    default and a message that depends on one arrives broken.
    """
    def esc(text: Any) -> str:
        return (str(text or "").replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;"))

    parts = [
        '<div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;'
        'color:#2A2622;line-height:1.6;font-size:15px">',
        f'<p style="font-size:16px">{esc(review["opening"])}</p>',
    ]

    if review.get("figures"):
        parts.append('<table cellpadding="0" cellspacing="0" '
                     'style="width:100%;margin:22px 0">')
        for fig in review["figures"]:
            parts.append(
                '<tr>'
                f'<td style="padding:7px 0;border-bottom:1px solid #E8E2D9;'
                f'font-size:13px;color:#6B635A">{esc(fig["label"])}</td>'
                f'<td style="padding:7px 0;border-bottom:1px solid #E8E2D9;'
                f'text-align:right"><b>{esc(fig["value"])}</b><br>'
                f'<span style="font-size:12px;color:#6B635A">'
                f'{esc(fig["note"])}</span></td></tr>')
        parts.append('</table>')

    for section in review["sections"]:
        parts.append(f'<h2 style="font-size:15px;font-weight:bold;'
                     f'margin:26px 0 10px">{esc(section["title"])}</h2>')
        for item in section["items"]:
            parts.append(f'<p style="margin:0 0 4px"><b>'
                         f'{esc(item["headline"])}</b></p>')
            if item.get("detail"):
                parts.append(f'<p style="margin:0 0 16px;color:#4A423A">'
                             f'{esc(item["detail"])}</p>')

    parts.append(
        f'<p style="margin:30px 0 0"><a href="{site}/advice.html" '
        f'style="background:#5C1A1B;color:#fff;padding:11px 18px;'
        f'border-radius:6px;text-decoration:none;font-family:sans-serif;'
        f'font-size:14px;font-weight:bold">See what to do about it</a></p>')

    parts.append(f'<p style="font-size:12.5px;color:#6B635A;margin-top:28px;'
                 f'padding-top:16px;border-top:1px solid #E8E2D9">'
                 f'{esc(review["what_this_is_not"])}</p>')
    parts.append(f'<p style="font-size:12.5px;color:#6B635A">'
                 f'{esc(review["closing"])}</p>')
    parts.append(f'<p style="font-size:12px;color:#8A8177;margin-top:18px">'
                 f'You chose to hear from us {esc(review.get("cadence", ""))}. '
                 f'<a href="{site}/profile.html" style="color:#8A8177">'
                 f'Change that</a>.</p>')
    parts.append('</div>')
    return "".join(parts)
