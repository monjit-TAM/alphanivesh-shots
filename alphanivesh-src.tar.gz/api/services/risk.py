"""What somebody can afford to lose, and what they can bear to lose.

Two different questions that most tools ask as one, and the answers diverge
constantly. A surgeon of thirty-two with no dependants, no debt and a year of
expenses in the bank can afford almost any drawdown. Whether she can watch one
without selling is a separate fact, and the only honest evidence for it is
whether she has.

**Capacity** is arithmetic. Time until the money is needed, income stability,
what is already set aside, what is owed. It can be computed from figures.

**Tolerance** is behaviour. Whether contributions continued through a fall,
whether holdings were sold into one, what a person says about themselves. It
can only be read from a record, and where there is no record it should be
admitted rather than assumed.

**The recommendation respects the lower of the two.** Somebody with high
capacity and low tolerance who is put into a volatile portfolio sells at the
bottom, which converts a temporary fall into a permanent loss. Somebody with
low capacity and high tolerance is comfortable right up until they need the
money and it is not there.

The lower one is not a compromise. It is the binding constraint, and treating
it as an average of the two produces advice that fails both ways.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.risk")

# Five bands rather than a score. A band somebody can be told about is more
# useful than a number they have to interpret, and the boundaries are stated.
BANDS = {
    1: "very low",
    2: "low",
    3: "moderate",
    4: "high",
    5: "very high",
}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def capacity(investor_id: str) -> dict:
    """What this person can afford to lose, from the figures.

    Built up from four things, each of which can independently cap the answer:
    how long until the money is needed, how steady the income is, how much is
    set aside, and what is owed. A weakness in any one of them limits the whole,
    because they are not compensating -- twenty years of horizon does not help
    somebody who has to sell next month to cover an EMI.
    """
    from . import profile as profile_service, wealth

    them = profile_service.get_profile(investor_id) or {}
    summary = wealth.net_worth(investor_id)

    reasons: list[str] = []
    caps: list[int] = []

    # How long the money can stay invested. The single biggest determinant:
    # equity has needed five to seven years to be reliable, and no amount of
    # income stability shortens that.
    horizon = _horizon(investor_id, them)
    if horizon is None:
        reasons.append("We do not know when you need this money, which is the "
                       "single largest thing that decides how much risk is "
                       "affordable.")
        caps.append(3)
    elif horizon < 3:
        caps.append(1)
        reasons.append(f"About {horizon:.0f} years before you need this. A bad "
                       f"stretch may not have recovered by then.")
    elif horizon < 7:
        caps.append(3)
        reasons.append(f"About {horizon:.0f} years, which is enough for equity "
                       f"to be reasonable and not enough to be reliable.")
    else:
        caps.append(5)
        reasons.append(f"About {horizon:.0f} years, which is long enough for "
                       f"the market's bad stretches to have historically "
                       f"recovered.")

    # What happens if the income stops. Dependants and debt both shorten how
    # long somebody can wait.
    income = _d(them.get("monthly_income"))
    expenses = _d(them.get("monthly_expenses"))
    dependants = int(them.get("dependents") or 0)

    if income > 0 and expenses > 0:
        surplus = (income - expenses) / income * 100
        if surplus < 10:
            caps.append(2)
            reasons.append(f"Only {surplus:.0f}% of your income is left after "
                           f"expenses, so there is little room to absorb a "
                           f"shock without selling something.")
        elif surplus < 25:
            caps.append(3)
            reasons.append(f"{surplus:.0f}% of income left after expenses.")
        else:
            caps.append(5)
            reasons.append(f"{surplus:.0f}% of income left after expenses, "
                           f"which is a real cushion.")
    else:
        reasons.append("We do not know what you earn or spend, so we cannot "
                       "say how much a bad year would actually cost you.")
        caps.append(3)

    if dependants >= 2:
        caps.append(4)
        reasons.append(f"{dependants} people depend on this income, which is a "
                       f"reason to be able to reach money quickly.")

    # What is set aside. Below three months, capacity is low whatever else is
    # true: the next unexpected bill is paid by selling.
    months = them.get("emergency_fund_months")
    if months is not None:
        months_value = _d(months)
        if months_value < 3:
            caps.append(1)
            reasons.append(f"About {months_value:.0f} months of expenses set "
                           f"aside. Until that is closer to six, the next "
                           f"unexpected bill is paid by selling investments.")
        elif months_value < 6:
            caps.append(3)
            reasons.append(f"About {months_value:.0f} months set aside.")
        else:
            caps.append(5)
            reasons.append(f"About {months_value:.0f} months set aside, which "
                           f"is what lets equity be left alone in a fall.")

    # What is owed. Not yet captured anywhere, and its absence is a real gap
    # rather than an assumption of zero.
    liabilities = _liabilities(investor_id)
    if liabilities is None:
        reasons.append("We do not know what you owe. Debt costs a fixed amount "
                       "whatever the market does, and it is the thing most "
                       "likely to force a sale at a bad moment.")
    elif liabilities.get("monthly_emi") and income > 0:
        share = _d(liabilities["monthly_emi"]) / income * 100
        if share > 40:
            caps.append(1)
            reasons.append(f"{share:.0f}% of your income goes to EMIs, which is "
                           f"a fixed cost the market does not care about.")
        elif share > 20:
            caps.append(3)
            reasons.append(f"{share:.0f}% of income goes to EMIs.")

    band = min(caps) if caps else 3

    return {
        "band": band,
        "name": BANDS[band],
        "reasons": reasons,
        "horizon_years": horizon,
        "known": {
            "income": income > 0,
            "expenses": expenses > 0,
            "emergency": months is not None,
            "liabilities": liabilities is not None,
            "horizon": horizon is not None,
        },
        "reading": (
            f"Financially, this portfolio can carry {BANDS[band]} risk. "
            + (reasons[0] if reasons else "")
        ),
    }


def tolerance(investor_id: str) -> dict:
    """What this person can bear to sit through, from what they have done.

    Read from the record rather than from a questionnaire. Everybody says they
    would hold through a fall; the transactions say whether they did, and only
    one of those is evidence.

    Where there is no record, that is reported rather than filled in. An
    unknown tolerance and a high one produce very different advice, and
    guessing between them is how somebody ends up in a fund they sell at the
    bottom.
    """
    from . import behaviour, style as style_service

    how = behaviour.profile(investor_id)
    stated = style_service.get_style(investor_id)

    readable = ((how or {}).get("style") or {}).get("readable")
    if not readable:
        return {
            "band": None,
            "name": "not known",
            "evidence": [],
            "reading": ("We have not seen enough of how you actually invest to "
                        "say what you can sit through. Everybody says they would "
                        "hold through a fall — the record is the only thing that "
                        "says whether somebody did, and we do not have enough of "
                        "yours yet."),
            "stated_style": stated,
        }

    nerve = (how or {}).get("nerve") or {}
    placement = (how or {}).get("placement") or {}
    style = ((how or {}).get("style") or {}).get("style")

    evidence: list[str] = []
    band = 3

    if nerve.get("tested"):
        if nerve.get("held_nerve") and style != "monthly":
            band = 5
            evidence.append(
                f"You chose to put money in during every month the market was "
                f"more than 8% off its high — {nerve.get('worst_fall_pct')}% at "
                f"the worst. That is the thing most people cannot do.")
        elif nerve.get("held_nerve"):
            band = 4
            evidence.append(
                "Your instalments ran through the last fall. The arrangement "
                "held, which is not quite the same as knowing you would have — "
                "a standing instruction cannot lose its nerve.")
        else:
            band = 2
            evidence.append(
                f"Of {nerve.get('hard_months')} months where the market was "
                f"more than 8% off its high, money went in during "
                f"{nerve.get('months_invested_through')}.")
    else:
        evidence.append("No fall deep enough to test against during the period "
                        "we can see.")

    # Buying into weakness is the harder version of the same habit.
    average = placement.get("average_placement_pct")
    if average is not None and _d(average) <= 35:
        band = min(5, band + 1)
        evidence.append(
            f"Your purchases landed on average {_d(average):.0f}% of the way up "
            f"each fund's range — you buy when things are off their highs, which "
            f"is uncomfortable and is where units are cheapest.")

    return {
        "band": band,
        "name": BANDS[band],
        "evidence": evidence,
        "stated_style": stated,
        "reading": (f"On the record, you can sit through {BANDS[band]} risk. "
                    + (evidence[0] if evidence else "")),
    }


def ceiling(investor_id: str) -> dict:
    """The binding constraint: the lower of what is affordable and bearable.

    Not an average. Somebody with high capacity and low tolerance put into a
    volatile portfolio sells at the bottom, which turns a temporary fall into a
    permanent loss. Somebody with low capacity and high tolerance is
    comfortable right up to the moment they need money that is not there.

    Averaging produces advice that fails both ways, which is worse than
    either constraint alone.
    """
    can_afford = capacity(investor_id)
    can_bear = tolerance(investor_id)

    afford_band = can_afford["band"]
    bear_band = can_bear["band"]

    if bear_band is None:
        # Without evidence of tolerance, capacity is capped rather than
        # trusted. An unknown is not a high.
        limit = min(afford_band, 3)
        binding = "unknown tolerance"
        why = ("We do not know what you can sit through, so the recommendation "
               "holds to moderate risk regardless of what the figures say you "
               "could afford. That is not caution for its own sake: somebody "
               "who sells in a fall turns a dip into a loss, and we have no way "
               "to know yet whether you would.")
    elif afford_band <= bear_band:
        limit = afford_band
        binding = "capacity"
        why = (f"You could sit through more than your circumstances can "
               f"currently afford. The figures are the constraint here, not the "
               f"temperament.")
    elif bear_band < afford_band:
        limit = bear_band
        binding = "tolerance"
        why = (f"Financially you could carry more than the record suggests you "
               f"would sit through. The temperament is the constraint, and it "
               f"is the one that matters — a portfolio somebody sells in a fall "
               f"has not helped them however affordable it was.")
    else:
        limit = afford_band
        binding = "both"
        why = "Both point to the same level."

    return {
        "ceiling": limit,
        "name": BANDS[limit],
        "binding": binding,
        "why": why,
        "capacity": can_afford,
        "tolerance": can_bear,
        "reading": (f"Recommendations here hold to {BANDS[limit]} risk. {why}"),
    }


# ---------------------------------------------------------------------------

def _horizon(investor_id: str, them: dict) -> Optional[float]:
    """Years until the money is needed, stated or inferred from goals."""
    stated = them.get("investment_horizon_years")
    if stated:
        return float(_d(stated))

    goal = db.fetch_one(
        """
        SELECT min(target_date) AS soonest FROM goals
        WHERE investor_id = %s AND target_date IS NOT NULL
          AND target_amount > 0
        """,
        (investor_id,),
    )
    if goal and goal["soonest"]:
        days = (goal["soonest"] - date.today()).days
        return max(0.0, days / 365.25)
    return None


def _liabilities(investor_id: str) -> Optional[dict]:
    """What is owed, where we hold it.

    Returns None rather than zero when nothing is recorded. Those are very
    different: no debt is a strong position, and no information about debt is
    a hole in the middle of a capacity calculation.
    """
    row = db.fetch_one(
        """
        SELECT count(*) AS n,
               sum(outstanding) AS outstanding,
               sum(monthly_emi) AS monthly_emi
        FROM liabilities WHERE investor_id = %s
        """,
        (investor_id,),
    ) if _table_exists("liabilities") else None

    if not row or not row["n"]:
        return None
    return {"count": row["n"],
            "outstanding": str(_d(row["outstanding"])),
            "monthly_emi": str(_d(row["monthly_emi"]))}


def _table_exists(name: str) -> bool:
    row = db.fetch_one(
        "SELECT 1 AS ok FROM information_schema.tables "
        "WHERE table_schema = 'public' AND table_name = %s",
        (name,),
    )
    return bool(row)
