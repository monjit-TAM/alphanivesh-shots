"""Getting your own data out, and letting somebody else see it.

Two different things that people ask for in the same breath.

**Export** is portability. Everything we hold about somebody, in a format they
can open without us — holdings, transactions, goals, what they owe. It is also
the honest answer to "what do you have on me", and a platform that cannot
answer that is asking to be trusted rather than earning it.

**Sharing** is a link that shows a portfolio to somebody who is not signed in.
That is genuinely useful — a spouse, an accountant, an adviser — and it is the
feature most likely to end badly.

The convenient version is a permanent URL. It is also the one that appears in a
news story: a complete financial position, one forwarded message from anywhere,
with no way to know who has seen it or to take it back.

So every link here:

- **expires**, seven days by default and thirty at most
- **can be revoked** at any moment
- **records every open**, so the person who made it can see whether it was used
- **carries a scope**, because sharing advice with a spouse and sharing
  holdings with an accountant are different acts
- **is stored hashed**, so a leaked database does not hand somebody every live
  link

And the shared page says what it is showing and until when, because a recipient
should know they are looking at somebody's finances through a door that closes.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import secrets
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.sharing")

DEFAULT_DAYS = 7
MAX_DAYS = 30
SCOPES = ("advice", "holdings", "both")


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _plain(value: Any) -> Any:
    """Decimals and dates into something a file format will take."""
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def everything(investor_id: str) -> dict:
    """Everything we hold about somebody.

    Not a summary. If the answer to "what do you have on me" is a curated
    subset, the honest answer is that we will not say -- and a platform asking
    to be trusted with somebody's whole financial position should be able to
    hand it back.
    """
    investor = db.fetch_one(
        "SELECT id, display_name, created_at FROM investors WHERE id = %s",
        (investor_id,))

    holdings = db.fetch_all(
        """
        SELECT v.instrument_name, v.asset_class, v.quantity,
               v.invested_value, v.current_value, i.native_code, i.symbol,
               i.isin
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s
        ORDER BY v.current_value DESC NULLS LAST
        """,
        (investor_id,))

    transactions = db.fetch_all(
        """
        SELECT t.txn_date, t.txn_type, t.amount, t.quantity, t.price,
               i.name AS instrument
        FROM canonical_transactions t
        LEFT JOIN instruments i ON i.id = t.instrument_id
        WHERE t.investor_id = %s
        ORDER BY t.txn_date DESC
        """,
        (investor_id,))

    goals = db.fetch_all(
        "SELECT name, target_amount, target_date, monthly_contribution "
        "FROM goals WHERE investor_id = %s ORDER BY target_date",
        (investor_id,)) if _table("goals") else []

    liabilities = db.fetch_all(
        "SELECT kind, lender, outstanding, rate_pct, monthly_emi, ends_on "
        "FROM liabilities WHERE investor_id = %s ORDER BY rate_pct DESC NULLS LAST",
        (investor_id,)) if _table("liabilities") else []

    profile = db.fetch_one(
        "SELECT * FROM investor_profiles WHERE investor_id = %s",
        (investor_id,)) if _table("investor_profiles") else None

    return {
        "exported_at": datetime.now().isoformat(),
        "investor": _plain(dict(investor)) if investor else None,
        "holdings": [_plain(dict(h)) for h in holdings],
        "transactions": [_plain(dict(t)) for t in transactions],
        "goals": [_plain(dict(g)) for g in goals],
        "liabilities": [_plain(dict(x)) for x in liabilities],
        "profile": _plain(dict(profile)) if profile else None,
        "note": ("Everything this platform holds about you. Values are as at "
                 "the export date and computed from the last prices we had; "
                 "they are not a statement from any registrar or broker."),
    }


def as_csv(investor_id: str, part: str = "holdings") -> str:
    """One table, flat.

    CSV because it opens anywhere. One table at a time because holdings and
    transactions have nothing in common structurally, and forcing them into one
    file produces something neither readable nor parseable.
    """
    data = everything(investor_id)
    rows = data.get(part) or []

    buffer = io.StringIO()
    if not rows:
        buffer.write(f"# nothing recorded under {part}\n")
        return buffer.getvalue()

    writer = csv.DictWriter(buffer, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buffer.getvalue()


def _table(name: str) -> bool:
    return bool(db.fetch_one(
        "SELECT 1 AS ok FROM information_schema.tables "
        "WHERE table_schema = 'public' AND table_name = %s", (name,)))


# ---------------------------------------------------------------------------
# Sharing
# ---------------------------------------------------------------------------

def create(investor_id: str, scope: str = "advice",
           days: int = DEFAULT_DAYS, label: Optional[str] = None,
           created_by: Optional[str] = None) -> dict:
    """A link that expires.

    The token is returned once. It is stored hashed, so nobody -- including us
    -- can recover it afterwards: a leaked database should not hand somebody
    every live share link, and there is no reason to keep the plaintext when
    the only thing it is needed for happens at creation.
    """
    if scope not in SCOPES:
        raise ValueError(f"scope must be one of {', '.join(SCOPES)}")

    days = max(1, min(int(days or DEFAULT_DAYS), MAX_DAYS))
    token = secrets.token_urlsafe(24)
    expires = datetime.now().astimezone() + timedelta(days=days)

    with db.connection() as conn:
        row = conn.execute(
            """
            INSERT INTO shared_views
                (investor_id, created_by, token_hash, scope, label, expires_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id, expires_at
            """,
            (investor_id, created_by, _hash(token), scope, label, expires),
        ).fetchone()

    return {
        "id": row["id"],
        "token": token,               # shown once, never stored
        "scope": scope,
        "expires_at": row["expires_at"].isoformat(),
        "days": days,
        "note": (f"This link works for {days} day{'s' if days != 1 else ''} and "
                 f"then stops. Anybody who has it can see "
                 f"{'the advice' if scope == 'advice' else 'the holdings' if scope == 'holdings' else 'both'} "
                 f"without signing in, so send it the way you would send a bank "
                 f"statement. You can revoke it at any time."),
    }


def resolve(token: str) -> Optional[dict]:
    """Who a link belongs to, if it is still live.

    Counts the open. A share nobody can audit is a share nobody should make,
    and the count is what lets somebody notice a link being used more than they
    expected.
    """
    row = db.fetch_one(
        """
        SELECT id, investor_id, scope, label, expires_at, revoked_at,
               opened_count
        FROM shared_views WHERE token_hash = %s
        """,
        (_hash(token),))

    if not row:
        return None
    if row["revoked_at"]:
        return {"gone": True,
                "why": "This link was revoked by the person who made it."}
    if row["expires_at"] < datetime.now().astimezone():
        return {"gone": True,
                "why": (f"This link expired on "
                        f"{row['expires_at'].date().isoformat()}. Links here "
                        f"are time-limited on purpose — ask for a new one.")}

    with db.connection() as conn:
        conn.execute(
            "UPDATE shared_views SET opened_count = opened_count + 1, "
            "last_opened_at = now() WHERE id = %s", (row["id"],))

    return {
        "gone": False,
        "share_id": row["id"],
        "investor_id": row["investor_id"],
        "scope": row["scope"],
        "expires_at": row["expires_at"].isoformat(),
        "opened_before": row["opened_count"],
    }


def live(investor_id: str) -> list[dict]:
    """Every link somebody has made, and what has happened to it.

    Including the expired and revoked ones, because "did I ever share this"
    is a question somebody asks about links that no longer work.
    """
    rows = db.fetch_all(
        """
        SELECT id, scope, label, expires_at, revoked_at, opened_count,
               last_opened_at, created_at
        FROM shared_views WHERE investor_id = %s
        ORDER BY created_at DESC
        """,
        (investor_id,))

    now = datetime.now().astimezone()
    return [{
        "id": r["id"],
        "scope": r["scope"],
        "label": r["label"],
        "expires_at": r["expires_at"].isoformat(),
        "revoked": bool(r["revoked_at"]),
        "expired": r["expires_at"] < now,
        "live": not r["revoked_at"] and r["expires_at"] >= now,
        "opened": r["opened_count"],
        "last_opened": (r["last_opened_at"].isoformat()
                        if r["last_opened_at"] else None),
        "created_at": r["created_at"].isoformat(),
    } for r in rows]


def revoke(investor_id: str, share_id: str) -> bool:
    """Stop a link working, now.

    The investor_id is in the clause deliberately: a share id is not a secret
    and should not be enough on its own to revoke somebody else's link.
    """
    with db.connection() as conn:
        conn.execute(
            "UPDATE shared_views SET revoked_at = now() "
            "WHERE id = %s AND investor_id = %s AND revoked_at IS NULL",
            (share_id, investor_id))
    return True
