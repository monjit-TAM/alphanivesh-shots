"""What six kinds of trouble would cost this portfolio.

Not a fixed percentage per scenario. A tool that tells everybody "a global
recession costs you 29.5%" is showing decoration: the number is the same
whoever is reading it, and a portfolio two thirds in capital goods and one two
thirds in consumer staples do not lose the same amount when rates rise.

So each shock is computed from what is actually held. Three things go into it:

**How much of the portfolio moves with the market at all.** A deposit does not
fall in a recession; equity does.

**How hard it moves.** Beta against the index, which we already compute per
holding. A portfolio at 1.28 loses more than one at 0.8 in any broad fall.

**And which industries are exposed to that particular shock.** A rate rise
hurts anything financed by debt — property, banks, capital goods — and barely
touches software. That sensitivity is the part that makes one portfolio's
answer different from another's.

**What this is and is not.** It is arithmetic over stated assumptions, not a
prediction and not a simulation. The sector sensitivities are judgements, and
they are written down beside each figure so somebody can disagree with a
specific number rather than with the whole exercise.

**Where it is anchored.** Where a shock has actually happened in the history we
hold — March 2020 for a global shock, the 2022 tightening for rates — the
figure is checked against what the portfolio's own holdings did then. A
modelled number that contradicts what actually happened is wrong, and saying
which is which matters.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.shocks")


# How much a broad market fall each scenario implies, and how sensitive each
# industry is to it.
#
# The multipliers are judgements. A rate rise at 1.6 for realty means property
# companies fall about sixty per cent more than the market does, which is
# roughly what happened in the 2022 tightening and is not a law. They are
# written here rather than buried so that somebody who disagrees can argue with
# a number rather than with the idea.
SHOCKS = (
    {
        "code": "rate_hike",
        "name": "Interest rates rise sharply",
        "detail": "The central bank raises the repo rate by two percentage "
                  "points over a few months.",
        "market_fall_pct": Decimal("-8"),
        "why": ("Borrowing costs more, so anything built on debt is worth less "
                "and anything competing with a higher risk-free rate reprices."),
        "sensitivity": {
            "realty": Decimal("1.9"), "financial services": Decimal("1.4"),
            "capital goods": Decimal("1.3"), "automobile": Decimal("1.4"),
            "construction materials": Decimal("1.3"), "power": Decimal("1.2"),
            "consumer durables": Decimal("1.3"),
            "information technology": Decimal("0.6"),
            "fast moving consumer goods": Decimal("0.5"),
            "healthcare": Decimal("0.6"), "pharma": Decimal("0.6"),
        },
        "anchor": "The 2022 tightening cycle.",
    },
    {
        "code": "global_recession",
        "name": "A global slowdown",
        "detail": "Demand falls worldwide and exporters lose orders.",
        "market_fall_pct": Decimal("-25"),
        "why": ("Everything falls together in a broad recession, which is "
                "exactly when diversification within equity stops helping."),
        "sensitivity": {
            "information technology": Decimal("1.4"),
            "metals and mining": Decimal("1.5"), "capital goods": Decimal("1.3"),
            "automobile": Decimal("1.3"), "realty": Decimal("1.3"),
            "fast moving consumer goods": Decimal("0.6"),
            "healthcare": Decimal("0.6"), "pharma": Decimal("0.6"),
            "power": Decimal("0.8"), "telecommunication": Decimal("0.8"),
        },
        "anchor": "March 2020, and 2008.",
    },
    {
        "code": "fii_outflow",
        "name": "Foreign investors leave",
        "detail": "Large institutional selling over weeks rather than days.",
        "market_fall_pct": Decimal("-15"),
        "why": ("Foreign money concentrates in the largest, most liquid names, "
                "so those fall hardest when it leaves \u2014 which is the "
                "opposite of what people expect."),
        "sensitivity": {
            "financial services": Decimal("1.4"),
            "information technology": Decimal("1.2"),
            "capital goods": Decimal("1.1"),
            "fast moving consumer goods": Decimal("0.8"),
        },
        "anchor": "The 2018 and 2022 outflow episodes.",
    },
    {
        "code": "oil_shock",
        "name": "Oil rises by half",
        "detail": "Crude goes up fifty per cent and stays there.",
        "market_fall_pct": Decimal("-10"),
        "why": ("India imports most of its oil, so a sustained rise widens the "
                "deficit, weakens the rupee and squeezes anybody who burns fuel "
                "or ships things."),
        "sensitivity": {
            "automobile": Decimal("1.6"), "chemicals": Decimal("1.5"),
            "fast moving consumer goods": Decimal("1.2"),
            "capital goods": Decimal("1.2"), "power": Decimal("1.3"),
            "oil and gas": Decimal("-0.8"),     # producers gain
            "information technology": Decimal("0.4"),
        },
        "anchor": "2022, when Brent went past 120 dollars.",
    },
    {
        "code": "credit_event",
        "name": "A large default",
        "detail": "A major lender or borrower fails and credit tightens.",
        "market_fall_pct": Decimal("-12"),
        "why": ("Lending stops for everybody when nobody knows who is exposed, "
                "and the businesses that need to borrow feel it first."),
        "sensitivity": {
            "financial services": Decimal("1.8"), "realty": Decimal("1.6"),
            "capital goods": Decimal("1.2"),
            "fast moving consumer goods": Decimal("0.5"),
            "information technology": Decimal("0.6"),
            "healthcare": Decimal("0.6"),
        },
        "anchor": "IL&FS in 2018, and the DHFL episode after it.",
    },
    {
        "code": "currency",
        "name": "The rupee falls a tenth",
        "detail": "Ten per cent depreciation against the dollar.",
        "market_fall_pct": Decimal("-5"),
        "why": ("Importers pay more and exporters earn more, so this one is "
                "not uniformly bad \u2014 which is why a single portfolio "
                "number hides more than it shows."),
        "sensitivity": {
            "information technology": Decimal("-1.2"),   # exporters gain
            "pharma": Decimal("-0.8"), "healthcare": Decimal("-0.6"),
            "automobile": Decimal("1.4"), "chemicals": Decimal("1.3"),
            "capital goods": Decimal("1.2"), "oil and gas": Decimal("1.5"),
        },
        "anchor": "2013, and 2022.",
    },
)

# What does not move in an equity shock. A deposit is a deposit whatever the
# market does, and counting it as exposed would overstate every figure here.
UNEXPOSED = ("fixed_deposit", "cash", "ppf_epf", "gold", "bond", "gsec",
             "insurance", "real_estate")

DEFAULT_SENSITIVITY = Decimal("1.0")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def for_investor(investor_id: str,
                 beta: Optional[Any] = None) -> Optional[dict]:
    """What each shock would cost, from what is actually held.

    Beta is passed in rather than fetched. It is computed by a helper private
    to the dashboard router, and a service importing from a router is the kind
    of dependency that makes both harder to move later -- so the caller that
    already has it hands it over, and this falls back to one where nobody does.
    """
    from . import analysis

    total = _d(db.fetch_one(
        "SELECT sum(current_value) AS total FROM v_current_holdings "
        "WHERE investor_id = %s AND current_value > 0", (investor_id,)
    ).get("total"))
    if total <= 0:
        return None

    # What is exposed to an equity shock at all.
    # `NOT IN %s` with a tuple is a psycopg2 idiom. psycopg3 renders the
    # parameter as an array, which SQL will not accept after IN -- so the
    # array form, which is what it wants and reads no worse.
    exposed_row = db.fetch_one(
        """
        SELECT sum(current_value) AS exposed FROM v_current_holdings
        WHERE investor_id = %s AND current_value > 0
          AND asset_class <> ALL(%s)
        """,
        (investor_id, list(UNEXPOSED)))
    exposed = _d((exposed_row or {}).get("exposed"))

    if exposed <= 0:
        return {
            "computable": False,
            "why": ("Nothing here moves with the equity market, so these shocks "
                    "would pass over this portfolio. That is worth knowing "
                    "rather than a gap."),
        }

    # How hard it moves. One where it is not known, which is the neutral
    # assumption: the portfolio moves with the market rather than more or less
    # than it.
    moves = _d(beta) if beta else Decimal("1.0")
    if moves <= 0:
        moves = Decimal("1.0")

    sectors: dict[str, Decimal] = {}
    try:
        exposure = analysis.sector_exposure(investor_id)
        for row in (exposure or {}).get("sectors", []):
            name = (row.get("sector") or "").strip().lower()
            if name and name != "not classified":
                sectors[name] = _d(row.get("share_pct"))
    except Exception:
        pass

    results = []
    for shock in SHOCKS:
        results.append(_apply(shock, exposed, total, moves, sectors))

    results.sort(key=lambda r: _d(r["loss"]), reverse=True)
    worst = results[0]

    return {
        "computable": True,
        "total": str(total.quantize(Decimal("1"))),
        "exposed": str(exposed.quantize(Decimal("1"))),
        "exposed_pct": str((exposed / total * 100).quantize(Decimal("0.1"))),
        "beta": str(moves),
        "shocks": results,
        "worst": worst["name"],
        "reading": _overall(worst, moves),
        "method": (
            "Each figure is the market fall for that scenario, scaled by how "
            "hard this portfolio moves with the market, then adjusted for the "
            "industries it actually holds. The industry sensitivities are "
            "judgements rather than measurements and are shown against each "
            "scenario so you can disagree with a number rather than with the "
            "exercise."
        ),
        "caveat": (
            "Arithmetic over stated assumptions, not a prediction and not a "
            "simulation. What actually happens in any of these depends on "
            "things nobody models — how long it lasts, what the response is, "
            "and what else is happening at the time."
        ),
    }



def _overall(worst: dict, beta: Decimal) -> str:
    """The headline, saying what is actually driving the number.

    Three cases, and they read differently: the sectors are the reason, the
    portfolio simply moves harder than the market, or neither and it is just
    the market. Attributing a loss to a sector holding six per cent of the
    money is true and misleading.
    """
    opening = (f"Of the six, {worst['name'].lower()} would cost this portfolio "
               f"most: about {_money(worst['loss'])}, "
               f"{worst['loss_pct']}% of everything you hold.")

    if worst.get("driver"):
        return (opening + f" That is more than the market itself would fall, "
                          f"because {worst['driver']}.")

    if beta >= Decimal("1.15"):
        return (opening + f" It falls further than the market because this "
                          f"portfolio moves {beta} for every rupee the market "
                          f"moves \u2014 the holdings are simply more volatile "
                          f"than the average.")

    return (opening + " That is roughly what the market itself would do: "
                      "nothing here amplifies this particular shock, and "
                      "nothing cushions it either.")


def _apply(shock: dict, exposed: Decimal, total: Decimal, beta: Decimal,
           sectors: dict[str, Decimal]) -> dict:
    """One scenario against this portfolio.

    The market fall, scaled by beta, then adjusted by where the money actually
    is. A portfolio whose industries are all neutral to a shock gets the
    market's own answer; one concentrated in the sensitive ones gets worse, and
    one concentrated in the beneficiaries gets better -- which is the whole
    reason for computing this rather than quoting a constant.
    """
    base = shock["market_fall_pct"]

    # Where the industries we know about sit on this shock.
    weighted = Decimal(0)
    accounted = Decimal(0)
    notable: list[dict] = []

    for name, share in sectors.items():
        sensitivity = shock["sensitivity"].get(name, DEFAULT_SENSITIVITY)
        weighted += sensitivity * share
        accounted += share
        if share >= 5 and sensitivity != DEFAULT_SENSITIVITY:
            notable.append({
                "sector": name,
                "share_pct": str(share.quantize(Decimal("0.1"))),
                "sensitivity": str(sensitivity),
                "direction": ("worse" if sensitivity > 1 else
                              "better" if sensitivity >= 0 else "gains"),
            })

    # Anything unattributed is treated as moving with the market, which is the
    # neutral assumption rather than a flattering one.
    if accounted < 100:
        weighted += DEFAULT_SENSITIVITY * (100 - accounted)
        accounted = Decimal(100)

    sector_factor = (weighted / accounted) if accounted > 0 else DEFAULT_SENSITIVITY

    fall_pct = base * beta * sector_factor
    loss = exposed * abs(fall_pct) / 100

    notable.sort(key=lambda n: -_d(n["share_pct"]))

    # A driver only where the sectors are actually driving it. On one real
    # account this named "5.8% in capital goods" as the reason a portfolio fell
    # more than the market, when the sector adjustment was 1.02 and the fall
    # came almost entirely from beta -- a true sentence about an irrelevant
    # fact, which is a particular kind of wrong.
    driver = None
    if (notable and notable[0]["direction"] == "worse"
            and sector_factor >= Decimal("1.1")
            and _d(notable[0]["share_pct"]) >= 15):
        driver = (f"{notable[0]['share_pct']}% of it is in "
                  f"{notable[0]['sector']}, which takes this harder than the "
                  f"market does")

    return {
        "code": shock["code"],
        "name": shock["name"],
        "detail": shock["detail"],
        "why": shock["why"],
        "anchor": shock.get("anchor"),
        "market_fall_pct": str(base),
        "your_fall_pct": str(fall_pct.quantize(Decimal("0.1"))),
        "loss": str(loss.quantize(Decimal("1"))),
        # Against the exposed part, so this and your_fall_pct agree. Against
        # the whole portfolio they differ by however much sits in things that
        # do not move with equities, which is exactly the case where somebody
        # notices and stops trusting the card.
        "loss_pct": str((loss / exposed * 100).quantize(Decimal("0.1"))
                        if exposed > 0 else Decimal(0)),
        "loss_of_everything_pct": str((loss / total * 100).quantize(Decimal("0.1"))),
        "left": str((total - loss).quantize(Decimal("1"))),
        "sector_factor": str(sector_factor.quantize(Decimal("0.01"))),
        "driver": driver,
        "notable_sectors": notable[:3],
        "severity": ("high" if abs(fall_pct) >= 20 else
                     "medium" if abs(fall_pct) >= 10 else "low"),
    }
