"""Turning a parsed statement into holdings we can stand behind.

A consolidated account statement covers several asset classes at once: shares
and bonds sitting in a demat account, mutual fund folios held with the
registrars, sometimes NPS and insurance. This module walks that structure and
writes it into the canonical model.

Two things it is careful about.

It derives cost rather than assuming it. A depository statement states what you
hold but not always what you paid. Where the statement carries purchase
transactions we compute a weighted average cost from them, which is the real
number. Where it does not, cost stays null and the rest of the system knows not
to report a return.

It does not trust the parser. Statements have come back from this service with
the AMC name misaligned against the scheme, and with an entire table row folded
into a scheme name. Every holding is checked against arithmetic that must hold
before it is written, and anything that fails is set aside with a reason
attached rather than quietly becoming part of somebody's net worth.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Iterable, Optional

from .. import db

# Formats seen in statements from the various registrars.
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%b-%Y", "%Y/%m/%d", "%d-%b-%y")

# Bounds for the plausibility check. Loose on purpose: the aim is to catch a
# parse that has gone wrong, not to second-guess a genuinely large holding.
MAX_UNITS = Decimal("100000000")
MAX_VALUE = Decimal("100000000000")
MAX_COST_MULTIPLE = Decimal("100")


@dataclass
class MappingResult:
    accounts: int = 0
    holdings: int = 0
    transactions: int = 0
    quarantined: int = 0
    notes: list[str] = field(default_factory=list)
    investor_id: Optional[str] = None

    def note(self, message: str) -> None:
        # Cap it. A statement that produces two hundred notes has a systemic
        # problem, and the first dozen will say what it is.
        if len(self.notes) < 40:
            self.notes.append(message)


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


def _dec(value) -> Optional[Decimal]:
    if value in (None, "", "-"):
        return None
    try:
        # Statements sometimes carry grouped numbers as strings.
        text = str(value).replace(",", "").strip()
        return Decimal(text).quantize(Decimal("0.000001"))
    except (InvalidOperation, ValueError):
        return None


def _date(value) -> Optional[date]:
    if not value:
        return None
    if isinstance(value, date):
        return value
    if isinstance(value, datetime):
        return value.date()
    text = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _clean(value) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def plausible(name: str, units: Optional[Decimal], price: Optional[Decimal],
              value: Optional[Decimal], cost: Optional[Decimal]) -> list[str]:
    """Reasons this holding looks like a bad parse rather than a real position."""
    problems: list[str] = []

    # A fully exited holding still appears on the statement. That is real and
    # worth keeping as history.
    if (units or Decimal(0)) == 0 and (value or Decimal(0)) == 0:
        return []

    if units is not None and units > MAX_UNITS:
        problems.append(f"implausible unit count {units:,.2f}")
    if value is not None and value > MAX_VALUE:
        problems.append(f"implausible value {value:,.2f}")
    if cost and cost > 0 and value and value / cost > MAX_COST_MULTIPLE:
        problems.append(f"value is {value / cost:,.0f} times cost")

    # The strongest check: units times price should land near the stated value.
    # A wide band, because price and value are often as of different days.
    if units and price and value and value > 0:
        implied = units * price
        if implied > 0 and abs(implied - value) / value > Decimal("0.05"):
            problems.append(
                f"units times price is {implied:,.2f}, stated value is {value:,.2f}"
            )

    return problems


def cost_from_transactions(transactions: Iterable[dict]) -> tuple[Optional[Decimal], Optional[date]]:
    """Weighted average cost and first purchase date, from purchase rows.

    This is what makes a depository statement worth more than a balance: the
    statement says what you hold, the transactions say what you paid. Without
    them we would have to leave cost unknown and could not report a return.
    """
    total_units = Decimal(0)
    total_cost = Decimal(0)
    dates: list[date] = []

    for txn in transactions or []:
        kind = str(txn.get("type") or "").upper()
        if not kind.startswith("PURCHASE"):
            continue
        units = _dec(txn.get("units"))
        nav = _dec(txn.get("nav")) or _dec(txn.get("price"))
        if not units or not nav or units <= 0 or nav <= 0:
            continue
        total_units += units
        total_cost += units * nav
        when = _date(txn.get("date"))
        if when:
            dates.append(when)

    if total_units <= 0 or total_cost <= 0:
        return None, None
    return (total_cost / total_units).quantize(Decimal("0.000001")), (min(dates) if dates else None)



# Registrars prefix their own scheme codes onto the fund name, and they do not
# agree with each other: the same fund arrives as "EFDG - Axis Large Cap Fund -
# Direct Growth" from one statement and "Axis Large Cap Fund - Direct Growth"
# from another. Treating those as different instruments means the same holding
# is counted twice, which inflates somebody's net worth -- the precise failure
# this platform exists to prevent.
# A code prefix contains a digit ("EFDG"? no -- "ACG1G", "L018G", "157").
# Requiring a digit is what stops "Axis - " or "HDFC - " being mistaken for a
# code and two different fund houses collapsing into one instrument.
_SCHEME_CODE_PREFIX = re.compile(r"^[A-Z]*\d[A-Z0-9]*\s*-\s*", re.I)
_LEADING_DIGITS = re.compile(r"^\d{2,6}\s*-\s*")
# Some codes are pure letters (EFDG, EQDG, DFG, FIVFG). Those are only treated
# as codes when they are short, fully upper case, and followed by a separator --
# and never when they match the fund house name that follows.
_LETTER_CODE_PREFIX = re.compile(r"^([A-Z]{2,6})\s*-\s+(?=[A-Z])")
_NOISE = re.compile(r"\s*\((?:erstwhile|formerly)[^)]*\)", re.I)


def normalise_scheme_name(name: str) -> str:
    """A comparable form of a scheme name.

    Strips the registrar's code prefix, drops "(formerly known as ...)" tails,
    and flattens spacing and case. Used only for matching -- the name we show
    the investor is whatever their statement called it.
    """
    text = (name or "").strip()
    text = _NOISE.sub("", text)
    text = _LEADING_DIGITS.sub("", text)
    text = _SCHEME_CODE_PREFIX.sub("", text)
    text = _LETTER_CODE_PREFIX.sub("", text)
    text = re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()
    return text

# ---------------------------------------------------------------------------
# Resolution: investor, account, instrument
# ---------------------------------------------------------------------------


def _hash_pan(pan: str) -> str:
    return hashlib.sha256(pan.strip().upper().encode()).hexdigest()


def resolve_investor(conn, payload: dict, owner_user_id: str, result: MappingResult,
                     supplied_pan: Optional[str] = None) -> str:
    """Find or create the investor this statement belongs to.

    PAN is the key. A statement without one is unusual but not fatal: we fall
    back to the name and email on the document, and note that the record could
    not be anchored properly.
    """
    profile = payload.get("investor") or {}
    pan = _clean(profile.get("pan"))

    # CAMS masks the PAN on some statements (AFXXXXXX8M) and omits it on
    # others. A masked value is worse than none: hashing it would produce a key
    # that looks real and matches nothing. Where the person told us their PAN
    # we use that instead.
    if pan and "X" in pan.upper():
        pan = None
    if not pan and supplied_pan:
        pan = _clean(supplied_pan)
    name = _clean(profile.get("name")) or "Unnamed investor"
    email = _clean(profile.get("email"))

    if pan:
        pan_hash = _hash_pan(pan)
        row = conn.execute(
            "SELECT id, owner_user_id FROM investors WHERE pan_hash = %s", (pan_hash,)
        ).fetchone()
        if row:
            # Someone else already owns this PAN. Two people claiming one PAN is
            # either a family sharing an account or a mistake, and neither should
            # be resolved silently by an importer.
            if row["owner_user_id"] and row["owner_user_id"] != owner_user_id:
                raise PermissionError(
                    "These holdings are already linked to another AlphaNivesh account."
                )
            if not row["owner_user_id"]:
                conn.execute(
                    "UPDATE investors SET owner_user_id = %s WHERE id = %s",
                    (owner_user_id, row["id"]),
                )
            return row["id"]

        created = conn.execute(
            """
            INSERT INTO investors (display_name, pan_hash, pan_last4, email, owner_user_id)
            VALUES (%s, %s, %s, %s, %s) RETURNING id
            """,
            (name, pan_hash, pan.upper()[-4:], email, owner_user_id),
        ).fetchone()
        return created["id"]

    # No PAN. CAMS masks it on some statements and omits it on others, so this
    # is common rather than exceptional, and creating a fresh investor every
    # time would fragment one person's wealth across several records -- which
    # is the problem this product exists to solve.
    #
    # Email is the next best key. It is weaker than PAN, so we only match a
    # record the same user already owns: two people sharing a family email
    # address must not be merged by an importer, and anyone else's record is
    # not ours to attach to.
    if email:
        row = conn.execute(
            """
            SELECT id, display_name FROM investors
            WHERE lower(email) = lower(%s)
              AND (owner_user_id = %s OR owner_user_id IS NULL)
            ORDER BY (owner_user_id IS NOT NULL) DESC, created_at
            LIMIT 1
            """,
            (email, owner_user_id),
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE investors SET owner_user_id = coalesce(owner_user_id, %s) WHERE id = %s",
                (owner_user_id, row["id"]),
            )
            # A statement usually carries a fuller name than an email-derived
            # one, so take the better of the two.
            if name and len(name) > len(row["display_name"] or ""):
                conn.execute("UPDATE investors SET display_name = %s WHERE id = %s",
                             (name, row["id"]))
            result.note(f"Matched to your existing record for {name} by email address.")
            return row["id"]

    result.note("The statement carried no PAN, so we could not check whether these "
                "holdings belong with any you have already imported.")
    created = conn.execute(
        "INSERT INTO investors (display_name, email, owner_user_id) VALUES (%s, %s, %s) RETURNING id",
        (name, email, owner_user_id),
    ).fetchone()
    return created["id"]


def resolve_account(conn, investor_id: str, kind: str, number: Optional[str],
                    institution: Optional[str], result: MappingResult) -> str:
    """One account per (investor, kind, number).

    Note what is not in that key: the source. A folio is issued by the
    registrar, so the same folio arriving from a CAMS statement and a KFintech
    one is one account, not two. Getting this wrong double-counts the position.
    """
    number = number or "unspecified"
    row = conn.execute(
        """
        SELECT id FROM accounts
        WHERE investor_id = %s AND account_kind = %s AND coalesce(account_number,'') = %s
        """,
        (investor_id, kind, number),
    ).fetchone()
    if row:
        return row["id"]

    created = conn.execute(
        """
        INSERT INTO accounts (investor_id, source, account_kind, account_number,
                              account_label, institution, last_synced_at)
        VALUES (%s, 'casparser_cdsl', %s, %s, %s, %s, now())
        RETURNING id
        """,
        (investor_id, kind, number,
         f"{kind.replace('_',' ').title()} {number}", institution),
    ).fetchone()
    result.accounts += 1
    return created["id"]



# Words that describe the plan and the option rather than the fund. Stripped
# from both sides before comparing, because a statement writes "Growth" where
# AMFI writes "Growth Option" and the two never matched on the full string.
_PLAN_WORDS = re.compile(
    r"\b(direct|regular|plan|option|growth|idcw|dividend|payout|reinvestment)\b",
    re.I)


# Notes about how a holding is held rather than what it is. A statement writes
# "(Non-Demat)" or "- Registrar : CAMS" or "(erstwhile Bluechip Fund)"; AMFI
# writes none of them, and leaving them in means the two names never match.
_CUSTODY_NOISE = re.compile(
    # "non" on its own because a statement wrapped "(Non-Demat)" across a line
    # and the two halves arrived separated.
    r"\bnon[\s-]?demat\b|\bdemat\b|\bnon\b|\bregistrar\b|\bcams\b|"
    r"\bkfintech\b|\bkarvy\b|\bformerly\b|\berstwhile\b|\bknown as\b", re.I)


def _fund_core(name: str) -> str:
    """A scheme name reduced to the fund itself.

    Plan, option, registrar code and custody notes removed; "&" spelled out,
    because a statement writes "Large&Mid" where AMFI writes "Large & Mid".
    What is left should be identical for the same fund however it was written.
    """
    text = normalise_scheme_name(name)
    text = text.replace("&", " and ")
    text = _CUSTODY_NOISE.sub(" ", text)
    text = _PLAN_WORDS.sub(" ", text)
    # A trailing token of one or two characters is what is left of a hyphen or
    # a punctuation run -- "ICICI Prudential Flexicap fund- -" reduces to a
    # stray "f" that stops an otherwise exact match.
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+\S{1,2}$", "", text)
    return text.strip()


def _wants(name: str) -> tuple[Optional[str], Optional[str]]:
    """Which plan and which option the statement is describing.

    Either may be absent: plenty of statements name neither. Absent means we do
    not constrain on it rather than that we guess, and where that leaves more
    than one candidate the holding stays unmatched.
    """
    text = (name or "").lower()
    plan = ("direct" if re.search(r"\bdirect\b", text)
            else "regular" if re.search(r"\bregular\b", text) else None)
    option = ("idcw" if re.search(r"\b(idcw|dividend)\b", text)
              else "growth" if re.search(r"\bgrowth\b", text) else None)
    return plan, option


def _match_scheme(conn, name: str, comparable: str) -> Optional[dict]:
    """The AMFI scheme this holding is, where exactly one fits.

    Matched on the fund name with plan and option stripped, then narrowed by
    whichever of those the statement actually stated. Growth and IDCW are
    different holdings and regular and direct have different costs, so a name
    that names neither and leaves several candidates is left unmatched rather
    than resolved to whichever sorted first.

    Returning nothing costs a holding its price. Returning the wrong scheme
    prices somebody's money as a different fund, and that error is silent.
    """
    core = _fund_core(name)
    if len(core) < 6:
        return None

    # Ordered by similarity, not merely limited. The trigram operator matches
    # anything above a threshold and the index returns them in whatever order
    # it holds them: for "icici prudential elss tax saver fund" every one of
    # the first forty rows was a banking PSU debt fund, and the scheme actually
    # being looked for never appeared. A LIMIT without an ORDER BY is a
    # sampling of the matches rather than the best of them.
    rows = conn.execute(
        """
        SELECT name, native_code, isin
        FROM searchable_instruments
        WHERE asset_class = 'mutual_fund' AND search_text %% %s
        ORDER BY similarity(search_text, %s) DESC
        LIMIT 40
        """,
        (core, core),
    ).fetchall()
    if not rows:
        return None

    exact = [r for r in rows if _fund_core(r["name"]) == core]
    if not exact:
        return None

    plan, option = _wants(name)
    if plan:
        narrowed = [r for r in exact if _wants(r["name"])[0] == plan]
        if narrowed:
            exact = narrowed
    if option:
        narrowed = [r for r in exact if _wants(r["name"])[1] == option]
        if narrowed:
            exact = narrowed

    if len(exact) == 1:
        return dict(exact[0])

    # Where the statement named an option but no plan, the remaining candidates
    # differ only by plan -- and those two are the same fund, same manager, same
    # holdings, differing in cost. Matching to the regular plan is the safer of
    # the two guesses: a holding that came through a registrar statement with a
    # code prefix almost always did come through a distributor, and pricing a
    # direct holding with regular NAVs understates it slightly rather than
    # overstating it.
    #
    # Recorded as assumed, so the commission finding does not treat a guess as
    # a fact about what somebody is paying.
    if exact and option and not plan:
        by_plan = {_wants(r["name"])[0]: r for r in exact}
        if set(by_plan) <= {"regular", "direct"} and "regular" in by_plan:
            return {**dict(by_plan["regular"]), "plan_assumed": True}

    # Otherwise the statement did not say enough to tell them apart, and
    # picking would be a guess with somebody's money.
    return None



def transaction_exists(conn, investor_id: str, account_id: str,
                       instrument_id: Optional[str], txn_date, txn_type: str,
                       amount, quantity) -> bool:
    """Whether this exact transaction is already recorded.

    Checked on what the transaction is rather than on where it came from. The
    external reference and the document hash both describe the source, and a
    source can hand you the same purchase under a new name any number of times
    -- thirty-two migrated portfolios did exactly that, turning thirty-nine
    purchases into 1,284 rows.
    """
    row = conn.execute(
        """
        SELECT 1 FROM canonical_transactions
        WHERE investor_id = %s AND account_id = %s
          AND instrument_id IS NOT DISTINCT FROM %s
          AND txn_date = %s AND txn_type = %s AND amount = %s
          AND coalesce(quantity, -1) = coalesce(%s, -1)
        LIMIT 1
        """,
        (investor_id, account_id, instrument_id, txn_date, txn_type,
         amount, quantity),
    ).fetchone()
    return row is not None


def resolve_instrument(conn, asset_class: str, *, isin: Optional[str] = None,
                       native_code: Optional[str] = None, name: str,
                       symbol: Optional[str] = None, issuer: Optional[str] = None,
                       category: Optional[str] = None) -> str:
    """Find or create the canonical instrument.

    ISIN where the statement gives one, since it identifies the security
    globally. Otherwise the asset-class-specific code: a scheme code for a fund,
    a policy number for insurance.
    """
    # ISIN identifies a security globally and is what the registrars and the
    # depositories agree on, so it is tried first.
    if isin:
        row = conn.execute("SELECT id FROM instruments WHERE isin = %s", (isin,)).fetchone()
        if row:
            return row["id"]

    if native_code:
        row = conn.execute(
            "SELECT id FROM instruments WHERE asset_class = %s AND native_code = %s",
            (asset_class, native_code),
        ).fetchone()
        if row:
            return row["id"]

    # No identifier matched. Before creating a new instrument, check whether we
    # already hold this fund under a differently-prefixed name -- otherwise the
    # same position arriving from two registrars is counted twice.
    comparable = normalise_scheme_name(name)
    if comparable:
        row = conn.execute(
            """
            SELECT id, isin FROM instruments
            WHERE asset_class = %s AND attributes->>'comparable_name' = %s
            ORDER BY (isin IS NOT NULL) DESC
            LIMIT 1
            """,
            (asset_class, comparable),
        ).fetchone()
        if row:
            # A later statement may carry an ISIN where an earlier one did not.
            # Filling it in makes future matching exact rather than fuzzy.
            if isin and not row["isin"]:
                conn.execute("UPDATE instruments SET isin = %s WHERE id = %s", (isin, row["id"]))
            return row["id"]

    # Nothing we already hold. Before giving up and creating an instrument
    # nobody can price, look the scheme up in the AMFI master.
    #
    # This step was missing, and it is why 14 of 49 fund holdings sat
    # unmatched: a statement giving no ISIN and no scheme code could never be
    # resolved, however obvious the answer. "K123-Kotak Midcap Fund-Growth" had
    # "Kotak Midcap Fund - Regular Plan - Growth" waiting in the master and
    # nothing ever looked, so the holding got a name: placeholder, no NAV, no
    # price, and a stale statement figure that read as a catastrophic loss.
    if asset_class == "mutual_fund" and comparable:
        found = _match_scheme(conn, name, comparable)
        if found:
            existing = conn.execute(
                "SELECT id FROM instruments WHERE asset_class = %s AND native_code = %s",
                (asset_class, found["native_code"]),
            ).fetchone()
            if existing:
                return existing["id"]
            native_code = found["native_code"]
            isin = isin or found.get("isin")

    created = conn.execute(
        """
        INSERT INTO instruments (asset_class, isin, native_code, symbol, name,
                                 issuer, category, attributes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """,
        (asset_class, isin, native_code, symbol, name, issuer, category,
         json.dumps({"imported_from": "casparser",
                     "comparable_name": normalise_scheme_name(name)})),
    ).fetchone()
    return created["id"]


# ---------------------------------------------------------------------------
# The walk
# ---------------------------------------------------------------------------


def _write_holding(conn, *, investor_id: str, account_id: str, instrument_id: str,
                   as_of: date, units: Optional[Decimal], price: Optional[Decimal],
                   value: Optional[Decimal], cost: Optional[Decimal],
                   invested: Optional[Decimal], document_id: str,
                   attributes: dict, result: MappingResult) -> None:
    conn.execute(
        """
        INSERT INTO holding_snapshots
            (investor_id, account_id, instrument_id, as_of, source, source_document_id,
             quantity, avg_cost, price, current_value, invested_value, attributes)
        VALUES (%s, %s, %s, %s, 'casparser_cdsl', %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (account_id, instrument_id, as_of, source)
        DO UPDATE SET quantity = EXCLUDED.quantity,
                      avg_cost = EXCLUDED.avg_cost,
                      price = EXCLUDED.price,
                      current_value = EXCLUDED.current_value,
                      invested_value = EXCLUDED.invested_value,
                      attributes = EXCLUDED.attributes
        """,
        (investor_id, account_id, instrument_id, as_of, document_id,
         units or Decimal(0), cost, price, value, invested, json.dumps(attributes)),
    )
    result.holdings += 1


def _map_demat(conn, payload: dict, investor_id: str, document_id: str,
               as_of: date, result: MappingResult) -> None:
    """Shares, bonds and anything else held in a depository account.

    The structure here is confirmed against a working implementation:
    demat_accounts[] -> holdings.equities[] with isin, units, name,
    additional_info.stock_symbol and a transactions[] carrying PURCHASE rows.
    """
    for account in payload.get("demat_accounts") or []:
        number = _clean(account.get("bo_id")) or _clean(account.get("client_id")) \
                 or _clean(account.get("dp_id"))
        institution = _clean(account.get("dp_name")) or _clean(account.get("depository"))
        account_id = resolve_account(conn, investor_id, "demat", number, institution, result)

        holdings = account.get("holdings") or {}

        # Group names taken from a live NSDL statement, not from the shape the
        # AlphaLens implementation happened to read. It only ever looked at
        # `equities`, so the others were my guess -- and three of the five were
        # wrong: bonds are `corporate_bonds`, G-secs are `government_securities`,
        # and funds held in demat are `demat_mutual_funds`. Each mismatch would
        # have imported as silently zero.
        groups = (
            ("equities", "equity"),
            ("corporate_bonds", "bond"),
            ("government_securities", "gsec"),
            ("aifs", "aif"),
            ("demat_mutual_funds", "mutual_fund"),
            # Kept as aliases: CDSL and NSDL do not always agree on names, and a
            # statement that uses the shorter forms should still import.
            ("bonds", "bond"),
            ("govt_securities", "gsec"),
            ("mutual_funds", "mutual_fund"),
        )
        seen_any = False
        for group, asset_class in groups:
            for item in holdings.get(group) or []:
                seen_any = True
                name = _clean(item.get("name")) or _clean(item.get("isin")) or "Unnamed holding"
                units = _dec(item.get("units")) or _dec(item.get("balance"))
                price = _dec(item.get("nav")) or _dec(item.get("price")) \
                        or _dec(item.get("market_price"))
                value = _dec(item.get("value")) or _dec(item.get("market_value"))

                cost, _first = cost_from_transactions(item.get("transactions"))
                invested = (cost * units) if (cost and units) else None

                problems = plausible(name, units, price, value, invested)
                if problems:
                    result.quarantined += 1
                    result.note(f"{name[:50]}: " + "; ".join(problems))
                    continue

                symbol = None
                extra = item.get("additional_info") or {}
                if extra.get("stock_symbol"):
                    symbol = str(extra["stock_symbol"]).split(".")[0]

                instrument_id = resolve_instrument(
                    conn, asset_class,
                    isin=_clean(item.get("isin")),
                    native_code=symbol or _clean(item.get("isin")),
                    name=name, symbol=symbol,
                    issuer=_clean(extra.get("amc")) or institution,
                )

                _write_holding(
                    conn, investor_id=investor_id, account_id=account_id,
                    instrument_id=instrument_id, as_of=as_of, units=units,
                    price=price, value=value, cost=cost, invested=invested,
                    document_id=document_id,
                    attributes={"cost_derived_from_transactions": cost is not None},
                    result=result,
                )

        if not seen_any:
            # Distinguish "we could not read it" from "there was nothing in it".
            # A transaction statement carries movements rather than balances, and
            # someone who uploads one deserves to be told that rather than left
            # wondering why their shares did not appear.
            present = [g for g in holdings if holdings.get(g)]
            if present:
                result.note(
                    f"Demat account {number or 'unnamed'} listed "
                    f"{', '.join(present)}, which we could not read."
                )
            else:
                result.note(
                    f"Demat account {number or 'unnamed'} had no holdings in it. "
                    f"If this was a transaction statement, ask your depository for "
                    f"a holdings statement instead."
                )


def _map_folios(conn, payload: dict, investor_id: str, document_id: str,
                as_of: date, result: MappingResult) -> None:
    """Mutual fund folios held with the registrars.

    Shape confirmed against a live CAMS statement:

        mutual_funds[] -> amc, folio_number, registrar, schemes[]
          schemes[]    -> name, isin, units, nav, value, cost, gain, type,
                          transactions[]

    Note that `cost` is stated. Unlike the depository side, where we have to
    derive a cost basis from purchase transactions, the registrar gives it to
    us directly, so we take it and only fall back to deriving when it is absent.
    """
    for folio in payload.get("mutual_funds") or []:
        number = _clean(folio.get("folio_number"))
        amc = _clean(folio.get("amc"))
        registrar = _clean(folio.get("registrar"))
        account_id = resolve_account(conn, investor_id, "mf_folio", number,
                                     amc or registrar, result)

        for scheme in folio.get("schemes") or []:
            name = _clean(scheme.get("name")) or "Unnamed scheme"
            units = _dec(scheme.get("units"))
            price = _dec(scheme.get("nav"))
            value = _dec(scheme.get("value"))
            invested = _dec(scheme.get("cost"))

            # Per-unit cost, for consistency with how the depository side stores
            # it. Derived from the stated total rather than recomputed.
            avg_cost = (invested / units) if (invested and units and units > 0) else None
            if avg_cost is None:
                avg_cost, _ = cost_from_transactions(scheme.get("transactions"))

            problems = plausible(name, units, price, value, invested)
            if problems:
                result.quarantined += 1
                result.note(f"{name[:50]}: " + "; ".join(problems))
                continue

            instrument_id = resolve_instrument(
                conn, "mutual_fund",
                isin=_clean(scheme.get("isin")),
                native_code=_clean((scheme.get("additional_info") or {}).get("amfi")),
                name=name, issuer=amc,
                category=_clean(scheme.get("type")),
            )

            _write_holding(
                conn, investor_id=investor_id, account_id=account_id,
                instrument_id=instrument_id, as_of=as_of, units=units, price=price,
                value=value, cost=avg_cost, invested=invested, document_id=document_id,
                attributes={
                    "registrar": registrar,
                    "stated_gain": str(_dec(scheme.get("gain")) or ""),
                    "cost_stated_by_registrar": invested is not None,
                },
                result=result,
            )

            _map_scheme_transactions(conn, scheme, investor_id, account_id,
                                     instrument_id, document_id, result)


def _map_scheme_transactions(conn, scheme: dict, investor_id: str, account_id: str,
                             instrument_id: str, document_id: str,
                             result: MappingResult) -> None:
    """Every purchase, redemption and dividend the statement lists.

    These are what make a real return possible. Without them XIRR has nothing to
    work with, and our own calculation declines to answer rather than guess --
    so importing them properly matters more than it looks.
    """
    for txn in scheme.get("transactions") or []:
        when = _date(txn.get("date"))
        if when is None:
            continue

        amount = _dec(txn.get("amount"))
        if amount is None:
            continue

        kind = (txn.get("type") or "").strip().lower()
        description = _clean(txn.get("description"))

        # Built from the statement's own facts rather than from a row id, so
        # re-importing an overlapping period matches rather than duplicates.
        # The uniqueness that actually protects the table is on the transaction
        # itself -- an external reference describes where a record came from,
        # and the same purchase can arrive from thirty-two places.
        external = f"cas:{scheme.get('isin')}:{when.isoformat()}:{kind}:{amount}"

        conn.execute(
            """
            INSERT INTO canonical_transactions
                (investor_id, account_id, instrument_id, txn_type, txn_date,
                 quantity, price, amount, source, source_document_id,
                 external_ref, attributes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'casparser_cams', %s, %s, %s)
            ON CONFLICT (investor_id, account_id, instrument_id, txn_date,
                         txn_type, amount, coalesce(quantity, -1))
            DO NOTHING
            """,
            (investor_id, account_id, instrument_id, kind or "unknown", when,
             _dec(txn.get("units")), _dec(txn.get("nav")), amount, document_id,
             external, json.dumps({"description": description,
                                   "balance": str(_dec(txn.get("balance")) or "")})),
        )
        result.transactions += 1


def map_statement(payload: dict, owner_user_id: str, *, as_of: Optional[date] = None,
                  supplied_pan: Optional[str] = None) -> MappingResult:
    """Write a parsed statement into the canonical model.

    Everything happens in one transaction: a statement that half-imports is
    worse than one that does not import at all, because the investor cannot
    tell the difference between a partial import and a complete one.
    """
    result = MappingResult()
    # The period is under meta, e.g. meta.statement_period.to. Falling back to
    # today would date the holdings wrongly, so we look properly first.
    meta = payload.get("meta") or {}
    period = meta.get("statement_period") or payload.get("statement_period") or {}
    as_of = as_of or _date(period.get("to")) or _date(meta.get("generated_at")) or date.today()

    body = json.dumps(payload, sort_keys=True, default=str)
    digest = hashlib.sha256(body.encode()).hexdigest()

    with db.connection() as conn:
        with conn.transaction():
            investor_id = resolve_investor(conn, payload, owner_user_id, result, supplied_pan)
            result.investor_id = investor_id

            existing = conn.execute(
                "SELECT id FROM source_documents WHERE payload_sha256 = %s", (digest,)
            ).fetchone()
            if existing:
                document_id = existing["id"]
                result.note("This statement has been imported before. Holdings were "
                            "refreshed rather than added twice.")
            else:
                document_id = conn.execute(
                    """
                    INSERT INTO source_documents
                        (investor_id, source, provider_ref, payload, payload_sha256,
                         processed_at, status)
                    VALUES (%s, 'casparser_cdsl', 'casparser:/v4/smart/parse', %s, %s,
                            now(), 'parsed')
                    RETURNING id
                    """,
                    (investor_id, body, digest),
                ).fetchone()["id"]

            _map_demat(conn, payload, investor_id, document_id, as_of, result)
            _map_folios(conn, payload, investor_id, document_id, as_of, result)

    if result.holdings == 0 and result.quarantined == 0:
        result.note("We read the statement but found no holdings in it.")

    return result
