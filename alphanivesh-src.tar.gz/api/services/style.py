"""Which kind of investor somebody is, and why it changes the answer.

The same holding is a sell through one lens and a buy through another, and
that is not a flaw in the analysis. A value investor looking at a company on
sixty times earnings sees something to avoid; a growth investor sees the price
of getting in early. Both are coherent. Showing only one verdict makes the tool
wrong for half the people using it.

So three verdicts, always, side by side. What the style decides is which one
is emphasised -- not which one is shown.

Most people cannot name their style, which is not ignorance: the vocabulary
belongs to the industry rather than to them. So this does two things. It infers
a style from what somebody already holds, which is more honest than what they
would say about themselves, and it explains the three in plain terms so they
can confirm or correct it.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Optional

from .. import db

STYLES = {
    "value": {
        "name": "Value",
        "one_line": "Buying businesses for less than they seem to be worth, and waiting.",
        "explain": (
            "A value investor looks for companies the market has priced below what "
            "the business appears to be worth -- often because something has gone "
            "wrong, or because the industry is out of fashion. The bet is that the "
            "price recovers towards the worth. It asks for patience: a cheap company "
            "can stay cheap for years, and some are cheap for good reason."
        ),
        "buys": "A low price against earnings and assets, a sound balance sheet, "
                "and a reason the market's pessimism looks overdone.",
        "avoids": "Paying a high multiple for anything, however fast it is growing.",
        "signature": "Holdings priced below their sector, often in unglamorous industries.",
    },
    "growth": {
        "name": "Growth",
        "one_line": "Paying up for businesses getting bigger quickly.",
        "explain": (
            "A growth investor accepts a high price for a company whose revenue and "
            "profit are compounding, on the view that the business will grow into "
            "the valuation. It asks for conviction: these holdings fall hardest when "
            "growth disappoints, and the price already assumes it will not."
        ),
        "buys": "Revenue and profit rising faster than the sector, with room to "
                "keep doing so.",
        "avoids": "Cheap companies that are cheap because they are going nowhere.",
        "signature": "Holdings on high multiples, growing faster than their sector.",
    },
    "quantamental": {
        "name": "Quantamental",
        "one_line": "Waiting for the numbers and the price behaviour to agree.",
        "explain": (
            "A quantamental investor wants two things confirming each other: the "
            "business figures sound, and the price acting like the market has "
            "noticed. Good fundamentals with a falling price says wait; a rising "
            "price with weak fundamentals says be careful. It asks for discipline -- "
            "acting only when both agree means sitting out stretches where one does."
        ),
        "buys": "Sound fundamentals and a price trend that confirms them.",
        "avoids": "Acting on either signal alone, however strong.",
        "signature": "Holdings that were bought after a trend established, "
                     "rather than at the bottom or on a story.",
    },
}


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def get_style(investor_id: str) -> Optional[str]:
    row = db.fetch_one(
        "SELECT investment_style FROM investor_profiles WHERE investor_id = %s",
        (investor_id,),
    )
    return (row or {}).get("investment_style")


def set_style(investor_id: str, style: Optional[str]) -> Optional[str]:
    if style is not None and style not in STYLES:
        raise ValueError(f"{style} is not one of the three.")
    db.fetch_one(
        """
        INSERT INTO investor_profiles (investor_id, investment_style)
        VALUES (%s, %s)
        ON CONFLICT (investor_id) DO UPDATE SET investment_style = EXCLUDED.investment_style
        RETURNING investor_id
        """,
        (investor_id, style),
    )
    return style


def infer(investor_id: str) -> Optional[dict]:
    """What the holdings suggest, whatever the person would say.

    People describe themselves as value investors and hold companies on sixty
    times earnings. This reads the portfolio instead: what somebody has bought
    is a better account of how they invest than what they call it.

    Weighted by position size, because a token holding says less about somebody
    than the position they put a quarter of their money into.
    """
    rows = db.fetch_all(
        """
        SELECT v.current_value, f.pe_ttm, f.pb_ratio, f.sector,
               f.revenue_growth_yoy, f.pat_growth_yoy, f.roe
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        JOIN company_fundamentals f ON f.isin = i.isin OR f.symbol = i.symbol
        WHERE v.investor_id = %s AND i.asset_class = 'equity'
          AND v.current_value > 0 AND f.pe_ttm IS NOT NULL
        """,
        (investor_id,),
    )
    if len(rows) < 3:
        return None

    # Each sector's own middle, so "expensive" means expensive for its industry.
    sectors = {r["sector"] for r in rows if r["sector"]}
    medians: dict[str, dict] = {}
    for sector in sectors:
        row = db.fetch_one(
            """
            SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY pe_ttm) AS pe,
                   percentile_cont(0.5) WITHIN GROUP (ORDER BY revenue_growth_yoy) AS growth
            FROM company_fundamentals
            WHERE sector = %s AND pe_ttm IS NOT NULL AND pe_ttm BETWEEN 0 AND 500
            """,
            (sector,),
        )
        if row and row["pe"]:
            medians[sector] = row

    dear = Decimal(0)
    cheap = Decimal(0)
    fast = Decimal(0)
    slow = Decimal(0)
    weight = Decimal(0)

    for row in rows:
        median = medians.get(row["sector"])
        if not median:
            continue
        value = _d(row["current_value"])
        weight += value

        pe = _d(row["pe_ttm"])
        sector_pe = _d(median["pe"])
        if sector_pe > 0:
            if pe > sector_pe * Decimal("1.2"):
                dear += value
            elif pe < sector_pe * Decimal("0.8"):
                cheap += value

        growth = _d(row["revenue_growth_yoy"])
        sector_growth = _d(median["growth"]) if median["growth"] is not None else None
        if sector_growth is not None:
            if growth > sector_growth * Decimal("1.2"):
                fast += value
            elif growth < sector_growth * Decimal("0.8"):
                slow += value

    if weight <= 0:
        return None

    dear_pct = (dear / weight * 100).quantize(Decimal('0.1'))
    cheap_pct = (cheap / weight * 100).quantize(Decimal('0.1'))
    fast_pct = (fast / weight * 100).quantize(Decimal('0.1'))

    # Paying above the sector for companies growing above it is growth
    # investing, whatever somebody calls it. Buying below the sector is value.
    # Neither dominant reads as quantamental only weakly, so it is offered as
    # the least-committed answer rather than asserted.
    if dear_pct >= 50 and fast_pct >= 40:
        style, confidence = "growth", "clear"
    elif dear_pct >= 55:
        style, confidence = "growth", "likely"
    elif cheap_pct >= 50:
        style, confidence = "value", "clear" if cheap_pct >= 65 else "likely"
    else:
        style, confidence = None, "unclear"

    return {
        "suggests": style,
        "confidence": confidence,
        "dear_pct": str(dear_pct.quantize(Decimal("0.1"))),
        "cheap_pct": str(cheap_pct.quantize(Decimal("0.1"))),
        "fast_growing_pct": str(fast_pct.quantize(Decimal("0.1"))),
        "covered": len(rows),
        "reading": _reading(style, confidence, dear_pct, cheap_pct, fast_pct),
        "caveat": ("This is what the holdings suggest, not a label. People buy for "
                   "reasons a ratio cannot see, and a portfolio built over ten years "
                   "may hold three different ideas at once."),
    }


def _reading(style: Optional[str], confidence: str, dear: Decimal,
             cheap: Decimal, fast: Decimal) -> str:
    if style == "growth" and confidence == "clear":
        return (f"{dear:.0f}% of your equity is priced above its sector, and "
                f"{fast:.0f}% is growing faster than its sector. That is growth "
                f"investing: paying up for companies getting bigger.")
    if style == "growth":
        return (f"{dear:.0f}% of your equity is priced above its sector. That leans "
                f"towards growth investing -- accepting a high price for a business "
                f"you expect to grow into it.")
    if style == "value":
        return (f"{cheap:.0f}% of your equity is priced below its sector. That leans "
                f"towards value investing -- buying businesses the market has marked "
                f"down and waiting.")
    return ("Your holdings do not lean clearly one way. That is common, and often "
            "means a portfolio built over years from several different ideas.")


def explain_all() -> list[dict]:
    """The three, in plain terms, for somebody who has never been asked."""
    return [{"key": key, **spec} for key, spec in STYLES.items()]
