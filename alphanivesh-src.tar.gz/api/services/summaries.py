"""A line of analysis against every holding.

Everything this platform computes about a holding sat one click deep, behind a
row that gave no sign there was anything to click. The work was there and
invisible, which for the reader is the same as absent.

So the figures that matter most come up to the list: how hard the thing has
been to hold, and whether the movement paid. Two numbers per row, and the
expansion becomes where somebody goes for depth rather than where the analysis
begins.

**Why only two.** A row can carry two figures and stay scannable. Four turns
the list into a spreadsheet, and a spreadsheet is what somebody scrolls past.
Sortino because it counts only the falls, which is what holding something
actually feels like; and the behaviour band for funds, because a fund that
demands discipline is the single most useful thing to know before opening
anything.

**Why this is batched.** Ratios are a query per holding and behaviour is a
network call per fund. Twenty-three holdings computed one at a time on page
load is a page that crawls, so the whole set is assembled in one pass with the
network calls capped -- and a holding whose figures are not ready shows nothing
rather than delaying the rest.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.summaries")

# How many behaviour lookups to make at once. The data service is shared with
# live users; a page load should not become a burst of thirty requests.
PARALLEL = 6

# And how many to attempt at all. Beyond the largest dozen the figures are
# decorating positions too small to act on.
MAX_LOOKUPS = 12


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def for_holdings(investor_id: str) -> dict:
    """One compact summary per holding, keyed by instrument.

    Everything is optional. A holding with too little history has no ratios, a
    fund the research service does not cover has no band, and both render as
    nothing rather than as a gap somebody has to interpret.
    """
    rows = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.asset_class,
               v.current_value, i.native_code, i.symbol
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        WHERE v.investor_id = %s AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )
    if not rows:
        return {"summaries": {}, "computed": 0}

    summaries: dict[str, dict] = {}

    # Ratios first: local queries, fast enough to do for everything.
    from . import ratios as ratios_service

    for row in rows[:MAX_LOOKUPS]:
        try:
            figures = ratios_service.for_instrument(
                row["instrument_id"],
                asset_class=row["asset_class"] or "mutual_fund")
        except Exception as err:                                 # pragma: no cover
            log.debug("ratios for %s: %s", row["instrument_name"], err)
            continue

        if not figures or not figures.get("computable"):
            continue

        index = figures.get("versus_index") or {}
        summaries[row["instrument_id"]] = {
            "sortino": figures.get("sortino"),
            "sharpe": figures.get("sharpe"),
            "volatility_pct": figures.get("volatility_pct"),
            "beta": index.get("beta"),
            # Alpha only where beta describes the holding. The same refusal as
            # everywhere else: below half explained it is the residual of a
            # model that does not fit.
            "alpha_pct": (index.get("alpha_pct")
                          if index.get("alpha_meaningful") else None),
            "reading": _reading_for(figures),
        }

    # Then the behaviour bands, which are network calls -- capped, parallel,
    # and only for funds we can identify.
    funds = [r for r in rows[:MAX_LOOKUPS]
             if r["asset_class"] == "mutual_fund"
             and r["native_code"] and str(r["native_code"]).isdigit()]

    if funds:
        from . import dataservice

        def band(row: dict) -> tuple[str, Optional[dict]]:
            try:
                reading = dataservice.mf_behaviour(str(row["native_code"]))
                return row["instrument_id"], reading
            except Exception:
                return row["instrument_id"], None

        with ThreadPoolExecutor(max_workers=PARALLEL) as pool:
            for instrument_id, reading in pool.map(band, funds):
                if not reading or reading.get("score") is None:
                    continue
                entry = summaries.setdefault(instrument_id, {})
                entry["demands_score"] = reading.get("score")
                entry["demands_band"] = reading.get("band")
                entry["demands_hard"] = (reading.get("score") or 100) < 45

    return {
        "summaries": summaries,
        "computed": len(summaries),
        "of": len(rows),
        "note": ("Sortino counts only the falls, which is what holding "
                 "something actually feels like. The band says how hard a fund "
                 "has been to sit through."),
    }


def _reading_for(figures: dict) -> str:
    """One line, for the row's title attribute.

    Somebody hovering a figure should get the sentence rather than have to open
    the holding to find out what it means.
    """
    sortino = figures.get("sortino")
    vol = figures.get("volatility_pct")
    if sortino is None or vol is None:
        return ""
    return (f"Moves about {vol:.0f}% a year. Counting only the falls, each "
            f"unit of that movement bought {sortino:.2f} units of return above "
            f"the risk-free rate.")
