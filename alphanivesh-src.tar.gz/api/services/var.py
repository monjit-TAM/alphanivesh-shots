"""How bad a bad day looks.

Volatility says how much something moves on average. That is the wrong question
when somebody is deciding whether they can sleep: what they want to know is how
bad the bad days get, and average movement says nothing about the tail.

Value at risk answers it. "A 5% chance of losing more than ₹11,000 on a given
day" is a sentence somebody can weigh against their own nerve — and unlike a
volatility figure, it is in rupees.

**Three things this must say and not hide.**

**It is history, not prediction.** Every figure here is a quantile of what this
portfolio's holdings have actually done, ordered and counted. It says what a
bad day looked like in the past. It cannot say a worse one is impossible, and a
platform quoting VaR without that sentence is selling precision it does not
have.

**The tail matters more than the threshold.** VaR says how much you lose at the
edge of the ordinary. It says nothing about what happens beyond it, and the
beyond is where portfolios are destroyed. Expected shortfall — the average loss
on the days worse than VaR — is the more honest figure and gets equal billing.

**And scaling by the square root of time is a convention.** A monthly figure
derived from daily returns assumes those returns are independent and identically
distributed. They are not: markets trend, and crises cluster. The scaled figure
understates a bad month, and saying so costs nothing.

**Computed from the holdings, not from the total.** A portfolio's risk is not
the sum of its parts' risks -- things that move together are more dangerous
than things that do not, and using the actual weighted series captures that
where summing individual VaRs would not.
"""

from __future__ import annotations

import logging
import math
import statistics
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.var")

# Trading days, for scaling.
YEAR = 252
MONTH = 21

# Below this there is not enough history for a tail estimate. A 99% quantile
# needs enough observations that the worst one per cent is more than a single
# day -- at 250 days it is two and a half, which is arithmetic pretending to be
# information.
MIN_DAYS = 500

# Single-day moves past this are corporate actions rather than market moves.
IMPLAUSIBLE = 0.33


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def _portfolio_returns(investor_id: str, years: int = 5) -> tuple[list[float], dict]:
    """The portfolio's own daily return series, weighted as it is held today.

    Built from each holding's price history weighted by what it is worth now,
    rather than from a stored portfolio total. Two reasons.

    A stored total moves when somebody buys as well as when the market does,
    and a contribution is not a return. And most importantly, this captures how
    the holdings move together: a portfolio of things that all fall on the same
    day is more dangerous than the sum of their individual falls, and only a
    combined series shows it.

    The weights are today's, applied to the past. That answers "what would this
    portfolio have done" rather than "what did the portfolio I used to hold
    do" -- which is the question somebody is asking when they want to know how
    bad a bad day looks.
    """
    from . import ratios

    holdings = db.fetch_all(
        """
        SELECT v.instrument_id, v.instrument_name, v.asset_class,
               v.current_value
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0
        ORDER BY v.current_value DESC
        """,
        (investor_id,),
    )
    if not holdings:
        return [], {"covered": "0", "total": "0", "holdings": 0}

    total = sum((_d(h["current_value"]) for h in holdings), Decimal(0))
    cutoff = date.today() - timedelta(days=365 * years + 10)

    # Each holding's returns, keyed by date so they can be lined up.
    series: dict[str, dict[date, float]] = {}
    weights: dict[str, Decimal] = {}
    covered = Decimal(0)

    for holding in holdings:
        prices = ratios._prices(holding["instrument_id"],
                                holding["asset_class"] or "mutual_fund", years)
        if len(prices) < MIN_DAYS:
            continue

        daily: dict[date, float] = {}
        for i in range(1, len(prices)):
            before, after = prices[i - 1][1], prices[i][1]
            if before <= 0:
                continue
            change = float((after - before) / before)
            if abs(change) > IMPLAUSIBLE:
                continue           # a split, not a market move
            daily[prices[i][0]] = change

        if daily:
            series[holding["instrument_id"]] = daily
            weights[holding["instrument_id"]] = _d(holding["current_value"])
            covered += _d(holding["current_value"])

    if not series or covered <= 0:
        return [], {"covered": "0", "total": str(total), "holdings": 0}

    # Every date any holding has, and the weighted return on it. Holdings
    # without a price that day are excluded from the weighting rather than
    # treated as flat -- a fund that did not publish a NAV did not return zero.
    all_dates = sorted({d for daily in series.values() for d in daily})

    combined: list[float] = []
    for when in all_dates:
        present = [(iid, daily[when]) for iid, daily in series.items()
                   if when in daily]
        if not present:
            continue
        weight_here = sum((weights[iid] for iid, _ in present), Decimal(0))
        if weight_here <= 0:
            continue
        combined.append(sum(
            float(weights[iid] / weight_here) * value for iid, value in present))

    return combined, {
        "covered": str(covered.quantize(Decimal("1"))),
        "total": str(total.quantize(Decimal("1"))),
        "covered_pct": str((covered / total * 100).quantize(Decimal("0.1"))),
        "holdings": len(series),
        "of_holdings": len(holdings),
        "days": len(combined),
        "from": all_dates[0].isoformat() if all_dates else None,
    }


def for_investor(investor_id: str) -> Optional[dict]:
    """What a bad day, month and year look like in rupees."""
    returns, coverage = _portfolio_returns(investor_id)

    if len(returns) < MIN_DAYS:
        return {
            "computable": False,
            "why": (f"We hold {len(returns)} days of combined price history for "
                    f"this portfolio. A tail estimate needs about two years of "
                    f"it — below that the worst one per cent is a handful of "
                    f"days, which is arithmetic rather than information."),
            "coverage": coverage,
        }

    value = _d(coverage["covered"])
    ordered = sorted(returns)

    def quantile(share: float) -> float:
        """The loss at a given point in the ordered history.

        Interpolated between the two observations either side rather than
        picking the nearest, because on 1,200 days the 99th percentile falls
        between two and rounding to one of them moves the answer by a
        noticeable amount.
        """
        position = share * (len(ordered) - 1)
        low, high = int(position), min(int(position) + 1, len(ordered) - 1)
        weight = position - low
        return ordered[low] * (1 - weight) + ordered[high] * weight

    def shortfall(share: float) -> float:
        """The average loss on the days worse than the threshold.

        The figure that matters more. VaR says how bad it gets at the edge of
        the ordinary; this says how bad it gets beyond, and beyond is where
        portfolios are destroyed.
        """
        cut = int(share * len(ordered))
        tail = ordered[:max(1, cut)]
        return statistics.fmean(tail)

    def rupees(pct: float, days: int = 1) -> Decimal:
        """A daily figure scaled to a period, in money."""
        scaled = pct * math.sqrt(days)
        return (value * Decimal(str(abs(scaled)))).quantize(Decimal("1"))

    daily_95, daily_99 = quantile(0.05), quantile(0.01)
    es_95, es_99 = shortfall(0.05), shortfall(0.01)

    worst = min(ordered)
    worst_day = value * Decimal(str(abs(worst)))

    return {
        "computable": True,
        "value_covered": str(value),
        "coverage": coverage,

        "daily": {
            "var_95": str(rupees(daily_95)),
            "var_99": str(rupees(daily_99)),
            "shortfall_95": str(rupees(es_95)),
            "var_95_pct": round(abs(daily_95) * 100, 2),
            "var_99_pct": round(abs(daily_99) * 100, 2),
        },
        "monthly": {
            "var_95": str(rupees(daily_95, MONTH)),
            "var_99": str(rupees(daily_99, MONTH)),
            "shortfall_95": str(rupees(es_95, MONTH)),
        },
        "annual": {
            "var_95": str(rupees(daily_95, YEAR)),
            "var_99": str(rupees(daily_99, YEAR)),
            "shortfall_95": str(rupees(es_95, YEAR)),
        },

        "worst_day": {
            "loss": str(worst_day.quantize(Decimal("1"))),
            "pct": round(abs(worst) * 100, 2),
        },

        "reading": _reading(rupees(daily_95), rupees(es_95),
                            rupees(daily_95, MONTH), worst_day,
                            abs(daily_95) * 100),
        "what_it_means": (
            "Value at risk is a quantile of what these holdings have actually "
            "done, ordered and counted. It says what a bad day looked like in "
            "the past. It cannot say a worse one is impossible."
        ),
        "on_scaling": (
            "The monthly and annual figures scale the daily one by the square "
            "root of time, which assumes each day is independent of the last. "
            "Markets trend and crises cluster, so a genuinely bad month is "
            "worse than this suggests."
        ),
        "on_shortfall": (
            "Expected shortfall is the average loss on the days worse than the "
            "threshold. It matters more than the threshold: value at risk says "
            "how bad it gets at the edge of the ordinary, and this says how bad "
            "it gets beyond — which is where portfolios are actually damaged."
        ),
    }


def _reading(daily: Decimal, shortfall_daily: Decimal, monthly: Decimal,
             worst: Decimal, daily_pct: float) -> str:
    return (
        f"On about one day in twenty, this portfolio loses more than "
        f"{_money(daily)} — that is {daily_pct:.1f}% of what we can price. On "
        f"the days worse than that, the average loss is {_money(shortfall_daily)}. "
        f"Over a month the same reasoning gives {_money(monthly)}, and the worst "
        f"single day in the history we hold would have cost {_money(worst)}."
    )
