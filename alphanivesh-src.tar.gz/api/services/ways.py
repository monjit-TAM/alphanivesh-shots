"""More than one way to do it.

The engine produces a finding and an action, one each. That is a useful shape
and it is not how advice actually works: most findings have three or four
legitimate answers with different costs, and which one somebody should take
depends on things the platform does not know.

Sixty-three per cent in capital goods can be addressed by selling the largest
holding, by selling the weakest one, by directing new money elsewhere until the
share falls on its own, or by deciding the concentration is a considered bet
and leaving it. Those are not the same decision. The first is fast and
expensive, the third is slow and free, and the fourth is a real answer that
most platforms will not print because it recommends nothing.

**So every finding gets its ways, and each way carries what it costs.**

Four things against each: what to do, what it costs, what it gives up, and when
it is the right one. That last is the part that matters — an option without a
"choose this if" is a list item rather than advice.

**Doing nothing is always one of them**, with its cost stated. A platform that
never offers it is one whose recommendations cannot be trusted, because the
reader knows something will always be recommended.

**And the reasoning is about them, not about the instrument.** "RSI 83,
overbought, strong volume" is a fact about a share. "This would put a fifth of
your money into something you would be watching daily" is a fact about the
person holding it, and only the second helps anybody decide.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.ways")


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _money(value: Any) -> str:
    number = int(_d(value))
    negative = number < 0
    digits = str(abs(number))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        digits = ",".join(parts) + "," + tail
    return ("₹" if not negative else "-₹") + digits


def ways_to(investor_id: str, action: dict,
            them: Optional[dict] = None) -> Optional[dict]:
    """The ways of addressing one finding, and what each costs."""
    code = str(action.get("code") or "")
    them = them or {}

    if code in ("sector_concentration", "concentration_single",
                "concentration_issuer", "single_holding",
                "reduce_concentration"):
        return _ways_concentration(investor_id, action, them)

    if code in ("switch_to_direct", "redirect_future", "plan_switch",
                "commission", "paying_for_laggards"):
        return _ways_commission(investor_id, action, them)

    if code.startswith("hold_something"):
        return _ways_role_gap(investor_id, action, them)

    if code in ("rebalance", "drift"):
        return _ways_drift(investor_id, action, them)

    if code in ("fund_lagging", "bottom_quartile"):
        return _ways_lagging_fund(investor_id, action, them)

    return None


# ---------------------------------------------------------------------------
# Too much in one thing
# ---------------------------------------------------------------------------


def _from_the_sentence(text: Optional[str]) -> Optional[str]:
    """Pull the subject out of the finding's own headline.

    A fallback rather than a first resort. The evidence block is where the
    name belongs and most findings put it there; this catches the ones that
    only say it in prose, which is better than printing "this".
    """
    if not text:
        return None
    lowered = text.lower()
    for marker in (" is in ", " of your money is with ", " is in one "):
        if marker in lowered:
            tail = text[lowered.index(marker) + len(marker):]
            return tail.rstrip(".").strip() or None
    return None


def _ways_concentration(investor_id: str, action: dict,
                        them: dict) -> dict:
    """Four answers, and the cheapest is the slowest."""
    from . import behaviour, rebalance

    # The name of the thing, from wherever the finding put it. Falling back
    # to "this" produced "Sell part of this and put the proceeds elsewhere",
    # which reads as a template rather than as advice about somebody's gold.
    evidence = action.get("evidence") or {}
    what = (evidence.get("sector") or evidence.get("name")
            or evidence.get("holding") or evidence.get("asset_class")
            or _from_the_sentence(action.get("what")) or "this")
    share = _d(evidence.get("share_pct"))

    # Is there money going in? That decides whether the free option exists.
    monthly = Decimal(0)
    try:
        how = behaviour.profile(investor_id)
        style = (how or {}).get("style") or {}
        if style.get("style") in ("monthly", "occasional"):
            monthly = _d(style.get("median_month"))
    except Exception:
        pass

    # What selling would actually cost.
    plan = None
    try:
        plan = rebalance.instruction(investor_id)
    except Exception:
        pass

    tax = _d((plan or {}).get("tax"))

    ways = []

    ways.append({
        "code": "sell_down",
        "what": (f"Sell part of your {what} and put the proceeds elsewhere."
                 if not what.lower().startswith("your") else
                 f"Sell part of {what} and put the proceeds elsewhere."),
        "costs": (f"About {_money(tax)} in capital gains tax"
                  if tax > 0 else "Capital gains tax on whatever is sold"),
        "gives_up": ("Whatever the sold part does next, and the money is "
                     "briefly out of the market between the sale and the "
                     "purchase."),
        "choose_this_if": ("The concentration keeps you up at night, or it "
                           "arrived by drift rather than by decision and you "
                           "would not choose it today."),
        "speed": "immediate",
    })

    if monthly > 0:
        months = _months_to_dilute(share, monthly, investor_id)
        ways.append({
            "code": "dilute",
            "what": (f"Leave it alone and put new money everywhere else "
                     f"until the share falls on its own."),
            "costs": "Nothing. No sale, no tax, no brokerage.",
            "gives_up": (f"Time. At {_money(monthly)} a month it would take "
                         f"roughly {months} to bring the share down "
                         f"meaningfully, and the concentration is real "
                         f"throughout."
                         if months else
                         "Time, and the concentration is real throughout."),
            "choose_this_if": ("You are still adding money and the tax on "
                               "selling is more than the risk is costing you."),
            "speed": "slow",
            "free": True,
        })

    # Only where there is more than one thing to choose between. On a single
    # gold holding this offered to "sell the weakest holdings within gold
    # rather than the largest", which is not a choice that exists.
    spread_across = _how_many_holdings(investor_id, evidence)
    if spread_across > 1:
        ways.append({
        "code": "sell_weakest",
        "what": (f"Sell the weakest holdings within {what} rather than the "
                 f"largest, and keep the ones you have conviction in."),
        "costs": ("The same tax, and possibly more of it — the weakest holding "
                  "is not always the cheapest to exit."),
        "gives_up": ("Less than selling the largest, if the ranking is right. "
                     "It is a ranking rather than a certainty."),
        "choose_this_if": ("You want the concentration down but hold specific "
                           "convictions within it worth keeping."),
        "speed": "immediate",
        })

    ways.append({
        "code": "leave_it",
        "what": f"Decide the {what} position is deliberate and leave it.",
        "costs": ("Nothing today. The cost is what happens if that part of the "
                  "market has a bad few years, which the shock figures put a "
                  "number on."),
        "gives_up": ("Nothing, if the conviction is real and you can sit "
                     "through the fall. Everything, if it is not and you "
                     "cannot."),
        "choose_this_if": ("You know this industry, you chose the position, "
                           "and you have sat through a fall in it before "
                           "without selling."),
        "speed": "none",
        "free": True,
    })

    return {
        "for": action.get("what"),
        "ways": ways,
        "default": "sell_down" if share >= 50 else "dilute" if monthly > 0
                   else "sell_down",
        "how_to_choose": (
            "The fast options cost tax and the free option costs time. Which "
            "is worth more depends on how likely you think a bad year in "
            + (what.lower() if isinstance(what, str) else "this")
            + " is, and nobody can compute that for you."
        ),
    }



def _how_many_holdings(investor_id: str, evidence: dict) -> int:
    """How many separate holdings the concentration spans.

    A sector concentration across four shares offers a choice about which to
    trim. A single gold position does not, and offering one reads as a
    template that has not looked at the portfolio.
    """
    sector = evidence.get("sector")
    if sector:
        try:
            from . import analysis
            exposure = analysis.sector_exposure(investor_id)
            match = next((s for s in (exposure or {}).get("sectors", [])
                          if (s.get("sector") or "").lower() == sector.lower()),
                         None)
            return len((match or {}).get("holdings") or []) or 1
        except Exception:
            return 1

    asset_class = evidence.get("asset_class")
    if asset_class:
        row = db.fetch_one(
            "SELECT count(*) AS n FROM v_current_holdings "
            "WHERE investor_id = %s AND asset_class = %s AND current_value > 0",
            (investor_id, asset_class))
        return int((row or {}).get("n") or 1)

    return 1


def _months_to_dilute(share: Decimal, monthly: Decimal,
                      investor_id: str) -> Optional[str]:
    """Roughly how long new money would take to bring a share down.

    Rough on purpose. The exact answer depends on what everything does in the
    meantime, and a precise-looking figure would suggest we know that.
    """
    from . import wealth

    try:
        total = _d(wealth.net_worth(investor_id).get("total_value"))
    except Exception:
        return None
    if total <= 0 or monthly <= 0 or share <= 0:
        return None

    # What it takes to get from the current share to about forty per cent,
    # assuming the position itself is flat.
    position = total * share / 100
    if share <= 40:
        return None
    needed = (position / Decimal("0.40")) - total
    months = int(needed / monthly)

    if months <= 0:
        return None
    if months < 12:
        return f"{months} months"
    return f"{months // 12} years"


# ---------------------------------------------------------------------------
# Paying for something
# ---------------------------------------------------------------------------

def _ways_commission(investor_id: str, action: dict, them: dict) -> dict:
    """Three answers, and one of them is free."""
    from . import plans

    summary = None
    try:
        summary = plans.summary(investor_id)
    except Exception:
        pass

    annual = _d((action.get("evidence") or {}).get("annual_saving"))
    tax = _d((summary or {}).get("tax_to_switch"))

    ways = [
        {
            "code": "switch_now",
            "what": "Switch the holdings to their direct plans.",
            "costs": (f"About {_money(tax)} in capital gains tax, since a "
                      f"switch is a sale and a purchase."
                      if tax > 0 else
                      "Capital gains tax, since a switch counts as a sale."),
            "gives_up": "Nothing about what you hold. Same fund, same manager.",
            "choose_this_if": (f"The {_money(annual)} a year is more than the "
                               f"tax, which it is after "
                               f"{_years_to_recover(annual, tax)}."
                               if annual > 0 and tax > 0 else
                               "The saving outweighs the one-off tax."),
            "speed": "immediate",
        },
        {
            "code": "redirect",
            "what": ("Leave what is invested where it is, and point every "
                     "future instalment at the direct plan instead."),
            "costs": ("Nothing. A purchase is not a sale, so no tax and no "
                      "holding period restarts."),
            "gives_up": ("The saving on what is already invested. Only new "
                         "money escapes the commission."),
            "choose_this_if": ("You are still adding regularly and the tax on "
                               "switching the existing holding is more than "
                               "you want to pay now."),
            "speed": "immediate",
            "free": True,
        },
        {
            "code": "switch_gradually",
            "what": ("Switch a bit each year, using the annual tax-free "
                     "allowance so the gain realised each time falls under it."),
            "costs": ("Nothing in tax if the yearly gain stays under ₹1.25 "
                      "lakh. Brokerage and paperwork each time."),
            "gives_up": ("Time. A large holding takes several years to move "
                         "this way, and the commission runs throughout."),
            "choose_this_if": ("The holding is large enough that switching it "
                               "all at once would cost real tax, and you are "
                               "in no hurry."),
            "speed": "years",
            "free": True,
        },
    ]

    return {
        "for": action.get("what"),
        "ways": ways,
        "default": "redirect" if tax > annual else "switch_now",
        "how_to_choose": (
            "The question is only whether the one-off tax is worth the annual "
            "saving, and that depends on how long you will hold. Over five "
            "years switching almost always wins; over one, redirecting does."
        ),
    }


def _years_to_recover(annual: Decimal, tax: Decimal) -> str:
    if annual <= 0:
        return "some years"
    years = tax / annual
    if years < 1:
        return "less than a year"
    if years < 2:
        return "about a year"
    return f"about {years:.0f} years"


# ---------------------------------------------------------------------------
# Nothing filling a role
# ---------------------------------------------------------------------------

def _ways_role_gap(investor_id: str, action: dict, them: dict) -> dict:
    """Where the money comes from, which is the actual question."""
    from . import behaviour

    monthly = Decimal(0)
    try:
        style = (behaviour.profile(investor_id) or {}).get("style") or {}
        monthly = _d(style.get("median_month"))
    except Exception:
        pass

    options = action.get("options") or []
    named = ", ".join(o.get("symbol") or o.get("name") or ""
                      for o in options[:2] if o)

    ways = [
        {
            "code": "new_money",
            "what": ("Put new money into it rather than moving anything."
                     + (f" {named} do this job." if named else "")),
            "costs": "Nothing. No sale, no tax.",
            "gives_up": ("Time. The gap stays open until enough has "
                         "accumulated."),
            "choose_this_if": ("You have money going in regularly"
                               + (f" — at {_money(monthly)} a month this "
                                  f"builds reasonably quickly." if monthly > 0
                                  else ".")),
            "speed": "gradual",
            "free": True,
        },
        {
            "code": "redirect_sip",
            "what": ("Point the next few instalments here instead of where "
                     "they currently go."),
            "costs": "Nothing, and it is reversible at any point.",
            "gives_up": ("Whatever those instalments would have bought "
                         "instead."),
            "choose_this_if": ("You want the gap closed within months rather "
                               "than years and would rather not sell "
                               "anything."),
            "speed": "months",
            "free": True,
        },
        {
            "code": "sell_to_fund",
            "what": "Sell something and move the proceeds here.",
            "costs": ("Capital gains tax on whatever is sold, and the money is "
                      "briefly out of the market."),
            "gives_up": "Whatever was sold.",
            "choose_this_if": ("The gap matters enough that waiting is not "
                               "acceptable — an emergency fund is usually this "
                               "case, and a diversification gap usually is "
                               "not."),
            "speed": "immediate",
        },
    ]

    return {
        "for": action.get("what"),
        "ways": ways,
        "default": "new_money" if monthly > 0 else "sell_to_fund",
        "how_to_choose": (
            "Filling a gap with new money costs nothing and takes time; "
            "filling it by selling costs tax and takes a day. The only case "
            "where the second is clearly right is money you might need "
            "suddenly, because that gap costs you at exactly the wrong moment."
        ),
    }


# ---------------------------------------------------------------------------
# Away from the plan
# ---------------------------------------------------------------------------

def _ways_drift(investor_id: str, action: dict, them: dict) -> dict:
    from . import rebalance

    plan = None
    try:
        plan = rebalance.instruction(investor_id)
    except Exception:
        pass
    tax = _d((plan or {}).get("tax"))

    return {
        "for": action.get("what"),
        "ways": [
            {
                "code": "rebalance_now",
                "what": "Sell what is over and buy what is under.",
                "costs": (f"About {_money(tax)} in tax" if tax > 0
                          else "Capital gains tax on what is sold"),
                "gives_up": ("Whatever the over-weighted part does next — and "
                             "it is over-weighted because it did well, so this "
                             "always feels like selling a winner."),
                "choose_this_if": ("The mix you set still reflects what you "
                                   "want, and the gap is wide enough to "
                                   "matter."),
                "speed": "immediate",
            },
            {
                "code": "rebalance_with_new",
                "what": ("Direct new money only into what is under-weighted "
                         "until the mix comes back."),
                "costs": "Nothing. No sale, no tax.",
                "gives_up": "Time, and the drift persists meanwhile.",
                "choose_this_if": ("You are still adding, and the drift is "
                                   "uncomfortable rather than dangerous."),
                "speed": "slow",
                "free": True,
            },
            {
                "code": "change_the_plan",
                "what": ("Decide the mix you set no longer reflects what you "
                         "want, and set a new one."),
                "costs": ("Nothing, and it is the honest option if the "
                          "original mix was set carelessly or your "
                          "circumstances have changed."),
                "gives_up": ("The discipline the original plan provided. "
                             "Somebody who changes the target every time the "
                             "market moves has no plan, only a description of "
                             "what they hold."),
                "choose_this_if": ("The old mix was set years ago in different "
                                   "circumstances, and you would not choose it "
                                   "today for reasons other than performance."),
                "speed": "immediate",
                "free": True,
            },
        ],
        "default": "rebalance_with_new",
        "how_to_choose": (
            "Rebalancing means selling what has done well to buy what has not, "
            "which is the point and also why nobody enjoys it. The free "
            "version is directing new money instead, and it works if there is "
            "new money."
        ),
    }


# ---------------------------------------------------------------------------
# A fund behind its peers
# ---------------------------------------------------------------------------

def _ways_lagging_fund(investor_id: str, action: dict, them: dict) -> dict:
    evidence = action.get("evidence") or {}
    name = evidence.get("name") or "the fund"

    return {
        "for": action.get("what"),
        "ways": [
            {
                "code": "switch_fund",
                "what": f"Move to a fund in the same category with a better record.",
                "costs": ("Capital gains tax, and possibly an exit load if the "
                          "holding is recent."),
                "gives_up": ("The possibility that this fund's period of "
                             "underperformance is about to end. Fund "
                             "performance does not persist reliably in either "
                             "direction."),
                "choose_this_if": ("The fund has been behind across most "
                                   "three-year windows rather than one bad "
                                   "patch, and the tax is small."),
                "speed": "immediate",
            },
            {
                "code": "stop_adding",
                "what": (f"Keep what is invested in {name} and send new money "
                         f"to a better fund in the same category."),
                "costs": "Nothing.",
                "gives_up": ("Nothing immediately. The existing holding stays "
                             "where it is."),
                "choose_this_if": ("You want to act without paying tax, or you "
                                   "are not certain enough to move the whole "
                                   "holding."),
                "speed": "immediate",
                "free": True,
            },
            {
                "code": "hold",
                "what": "Hold it.",
                "costs": ("Whatever the gap to its peers turns out to be over "
                          "the years you keep holding."),
                "gives_up": "Nothing certain, and that is the honest position: "
                            "a fund in the bottom quarter over three years is "
                            "about as likely to be in the top half over the "
                            "next three as any other.",
                "choose_this_if": ("The tax of switching is large, or the "
                                   "underperformance is explained by a style "
                                   "being out of favour rather than by the "
                                   "manager."),
                "speed": "none",
                "free": True,
            },
        ],
        "default": "stop_adding",
        "how_to_choose": (
            "Fund performance persists weakly, which cuts both ways: it is a "
            "poor reason to switch and a poor reason to stay. The tax is "
            "certain and the improvement is not, which is why the free option "
            "is usually the sensible one."
        ),
    }


# ---------------------------------------------------------------------------
# Everything, for one investor
# ---------------------------------------------------------------------------

def for_investor(investor_id: str) -> dict:
    """Every action the engine produced, with the ways of doing it.

    Assembled here rather than in the engine because the engine's job is to
    decide what matters and in what order. This one answers a different
    question -- how -- and the two are worth keeping apart.
    """
    from . import decide, profile as profile_service

    try:
        decision = decide.decide(investor_id)
    except Exception as err:
        log.warning("could not decide for %s: %s", investor_id, err)
        return {"actions": []}

    them = profile_service.get_profile(investor_id) or {}

    out = []
    for action in decision.get("actions") or []:
        ways = ways_to(investor_id, action, them)
        out.append({
            "code": action.get("code"),
            "what": action.get("what"),
            "why": action.get("why"),
            "tier": action.get("tier"),
            "worth": action.get("worth"),
            "ways": ways,
        })

    with_ways = [a for a in out if a["ways"]]

    return {
        "actions": out,
        "with_alternatives": len(with_ways),
        "reading": (
            f"{len(with_ways)} of the {len(out)} things worth doing have more "
            f"than one way of doing them, and the cheapest is rarely the "
            f"fastest."
            if with_ways else
            "Nothing here has alternatives worth setting out."
        ),
        "why_alternatives": (
            "Most findings have three or four legitimate answers with "
            "different costs. Selling is fast and taxed; directing new money "
            "is free and slow; deciding a position is deliberate and leaving "
            "it is also an answer. Which one is right depends on things this "
            "platform does not know about you, so it sets out the trade rather "
            "than picking for you."
        ),
    }
