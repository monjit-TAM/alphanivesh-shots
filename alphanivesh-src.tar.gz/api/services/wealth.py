"""Wealth consolidation: turning holdings into the numbers a person recognises.

Everything here reads from the canonical model and returns plain dicts. No HTTP
concepts, no framework types, so the same functions can back an API, a report
generator or a scheduled digest.

The one calculation worth explaining is XIRR. A portfolio is built from
irregular cashflows -- a lump sum here, a SIP every month, a redemption when
someone needed the money -- so a simple CAGR between first and last value is
misleading. XIRR is the discount rate that makes the net present value of those
cashflows zero, which is the return the investor actually experienced.
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable, Optional

from .. import db

# Cashflow signs, from the investor's point of view: money leaving their pocket
# is negative, money coming back is positive.
#
# The keys here are normalised by `_txn_key` below, because CAS statements are
# not consistent about spacing or punctuation: the same event appears as
# "Switch In", "switch-in" and "SWITCH IN" depending on the registrar.
MONEY_OUT = {
    "purchase", "buy", "sip", "switch_in", "premium", "investment",
    "stp_in", "systematic_transfer_in", "tax", "stamp_duty",
}
MONEY_IN = {
    "redemption", "sell", "switch_out", "dividend", "maturity", "interest",
    "stp_out", "systematic_transfer_out", "dividend_payout",
}

# Rows that carry an amount but are not cashflows. Excluding them is not a
# detail: AlphaLensMF's `costbasis` rows total more than two crore across the
# book, all dated 1970-01-01 (a null date coerced to the epoch) with no
# quantity or price. They annotate what a holding cost, they are not money
# moving, and treating them as flows makes XIRR meaningless.
NOT_CASHFLOW = {
    "costbasis", "cost_basis", "opening_balance", "closing_balance",
    "balance", "bonus", "split", "merger", "segregation",
}

# A date this old is not a real transaction date. It is what a null becomes
# when something upstream converts it to a Unix timestamp of zero.
EPOCH_SENTINEL = date(1970, 1, 2)


def _txn_key(txn_type: Optional[str]) -> str:
    """Normalise a transaction type for lookup.

    "Switch In", "switch-in" and "SWITCH_IN" all need to mean the same thing.
    """
    return (txn_type or "").strip().lower().replace("-", "_").replace(" ", "_")


def _d(value) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


# ---------------------------------------------------------------------------
# Net worth and allocation
# ---------------------------------------------------------------------------


def net_worth(investor_id: str, asset_class: Optional[str] = None) -> dict:
    """Current value, cost and gain for one investor, or for one asset class.

    The asset_class filter is what the dashboard's band uses to narrow the
    whole page to shares or to funds. It was lost when this function was
    rewritten from a copy that predated it -- the page then failed with an
    unexpected keyword argument, which is at least a loud failure.

    **A holding with no cost is set aside from the gain, on both sides.**

    Summing value across everything and cost across everything treats a
    holding entered without a purchase price as if it had been free. On a real
    portfolio a provident fund worth forty-eight lakh and a gold holding worth
    twenty were both entered without a cost, and the platform reported
    seventy-one lakh of gain, a 27% annual return, and fifty-four lakh of
    outperformance against the index.

    None of that happened. It was the arithmetic of dividing by a cost nobody
    had given us.

    So the total is everything, and the gain is computed only across the part
    where both figures are known -- with the share that covers reported, so a
    reader can see the gain describes part of the portfolio rather than all of
    it.
    """
    row = db.fetch_one(
        """
        SELECT
            count(*)                                  AS positions,
            coalesce(sum(current_value), 0)           AS total_value,
            max(as_of)                                AS latest_as_of,
            -- Only where we know what was paid. A zero cost is not a cost of
            -- zero; it is an absence.
            coalesce(sum(current_value)
                     FILTER (WHERE invested_value > 0), 0) AS costed_value,
            coalesce(sum(invested_value)
                     FILTER (WHERE invested_value > 0), 0) AS invested_value,
            count(*) FILTER (WHERE invested_value > 0)     AS costed_positions
        FROM v_current_holdings
        WHERE investor_id = %s
          AND (%s::text IS NULL OR asset_class = %s)
        """,
        (investor_id, asset_class, asset_class),
    ) or {}

    total = _d(row.get("total_value"))
    costed = _d(row.get("costed_value"))
    invested = _d(row.get("invested_value"))
    gain = costed - invested

    return {
        "investor_id": investor_id,
        "positions": row.get("positions", 0),
        "total_value": total,
        "invested_value": invested,
        "absolute_gain": gain,
        # Quantized here rather than at each caller. Four percentages have
        # escaped to the page unrounded as thirty-digit Decimals, and every
        # one was fixed where it was noticed rather than where it was made.
        "absolute_return_pct": (str((gain / invested * 100)
                                    .quantize(Decimal("0.1")))
                                if invested else None),
        # What the gain actually covers. Where this is well under a hundred,
        # the return figure describes a slice and every reader should be told
        # which slice.
        "gain_covers_value": costed,
        "gain_covers_pct": (str((costed / total * 100).quantize(Decimal("0.1")))
                            if total > 0 else None),
        "without_cost": (row.get("positions", 0) or 0)
                        - (row.get("costed_positions", 0) or 0),
        "as_of": row.get("latest_as_of"),
    }


def allocation(investor_id: str) -> list[dict]:
    """Split of current value by asset class, largest first.

    This is the view that makes the platform worth using: a person who holds
    funds through two registrars, shares in a demat account and a fixed deposit
    at their bank has never seen these numbers side by side before.
    """
    rows = db.fetch_all(
        """
        SELECT asset_class,
               count(*)                        AS positions,
               coalesce(sum(current_value), 0) AS value,
               coalesce(sum(invested_value), 0) AS invested
        FROM v_current_holdings
        WHERE investor_id = %s
        GROUP BY asset_class
        ORDER BY value DESC
        """,
        (investor_id,),
    )

    total = sum(_d(r["value"]) for r in rows)
    for row in rows:
        value = _d(row["value"])
        invested = _d(row["invested"])
        row["value"] = value
        row["invested"] = invested
        row["share_pct"] = (str((value / total * 100).quantize(Decimal("0.1")))
                            if total else "0.0")
        row["gain"] = value - invested
    return rows


def holdings(investor_id: str, asset_class: Optional[str] = None) -> list[dict]:
    """Every current position, with the instrument it refers to."""
    sql = """
        SELECT v.instrument_id, v.instrument_name, v.isin, v.symbol,
               v.asset_class, v.quantity, v.price, v.current_value,
               v.invested_value, v.as_of, v.source,
               a.institution, a.account_number, a.account_kind
        FROM v_current_holdings v
        JOIN accounts a ON a.id = v.account_id
        WHERE v.investor_id = %s
    """
    params: tuple = (investor_id,)
    if asset_class:
        sql += " AND v.asset_class = %s"
        params += (asset_class,)
    sql += " ORDER BY v.current_value DESC NULLS LAST"

    rows = db.fetch_all(sql, params)
    for row in rows:
        value = _d(row["current_value"])
        invested = _d(row["invested_value"])
        row["gain"] = value - invested
        row["gain_pct"] = (str((row["gain"] / invested * 100)
                               .quantize(Decimal("0.1")))
                           if invested else None)
        # Never return a full account number. The last four characters are
        # enough for someone to recognise their own folio.
        if row.get("account_number"):
            row["account_number"] = "…" + str(row["account_number"])[-4:]
    return rows


# ---------------------------------------------------------------------------
# Returns
# ---------------------------------------------------------------------------


def _xirr(cashflows: list[tuple[date, Decimal]], guess: float = 0.1) -> Optional[float]:
    """Internal rate of return for dated, irregular cashflows.

    Newton-Raphson, falling back to bisection when the derivative is unhelpful
    -- which happens with short histories or when the flows are lopsided. We
    return None rather than a wrong number when it will not converge; a blank
    on the screen is better than a fabricated 900% return.
    """
    if len(cashflows) < 2:
        return None
    if not (any(amount < 0 for _, amount in cashflows) and any(amount > 0 for _, amount in cashflows)):
        # Without both an outflow and an inflow there is no rate to find.
        return None

    start = min(day for day, _ in cashflows)
    years = [( (day - start).days / 365.0, float(amount)) for day, amount in cashflows]

    def npv(rate: float) -> float:
        return sum(amount / ((1.0 + rate) ** t) for t, amount in years)

    rate = guess
    for _ in range(60):
        value = npv(rate)
        if abs(value) < 1e-6:
            return rate
        # Numerical derivative; the analytic one is not much cheaper here and
        # this keeps the loop readable.
        step = 1e-6
        slope = (npv(rate + step) - value) / step
        if abs(slope) < 1e-12:
            break
        nxt = rate - value / slope
        if nxt <= -0.999999:       # a rate below -100% is meaningless
            nxt = (rate - 0.999999) / 2
        if abs(nxt - rate) < 1e-9:
            return nxt
        rate = nxt

    # Newton did not settle. Bisect over a range wide enough for anything a
    # real portfolio produces.
    low, high = -0.9999, 10.0
    if npv(low) * npv(high) > 0:
        return None
    for _ in range(200):
        mid = (low + high) / 2
        if npv(low) * npv(mid) <= 0:
            high = mid
        else:
            low = mid
    return (low + high) / 2


def returns(investor_id: str) -> dict:
    """Absolute return and XIRR for the whole portfolio."""
    summary = net_worth(investor_id)

    flows = db.fetch_all(
        """
        SELECT txn_date, txn_type, amount
        FROM canonical_transactions
        WHERE investor_id = %s AND amount IS NOT NULL
        ORDER BY txn_date
        """,
        (investor_id,),
    )

    cashflows: list[tuple[date, Decimal]] = []
    unclassified: set[str] = set()
    excluded_non_cashflow = 0
    excluded_bad_date = 0

    for flow in flows:
        kind = _txn_key(flow["txn_type"])
        when = flow["txn_date"]
        amount = _d(flow["amount"]).copy_abs()

        if kind in NOT_CASHFLOW:
            excluded_non_cashflow += 1
            continue
        if when is None or when < EPOCH_SENTINEL:
            excluded_bad_date += 1
            continue

        if kind in MONEY_OUT:
            cashflows.append((when, -amount))
        elif kind in MONEY_IN:
            cashflows.append((when, amount))
        else:
            # Left out rather than guessed at, and reported so it can be
            # mapped deliberately. A wrong sign here silently corrupts the
            # return figure, which is worse than an incomplete one.
            unclassified.add(kind)

    # The portfolio's present value is the final inflow: if you sold everything
    # today, this is what you would receive.
    if summary["total_value"] > 0:
        as_of = summary["as_of"] or date.today()
        cashflows.append((as_of, summary["total_value"]))

    # Before computing a rate, check that the cashflows can actually support
    # one. A CAS statement covers a limited window, so an investor who has held
    # funds for a decade may arrive with holdings worth lakhs but only the last
    # year of transactions. XIRR on that sees a small amount going in and a
    # large value coming out, and reports a spectacular return that never
    # happened -- one investor here produced 239% from exactly this.
    #
    # The test is whether the purchases we can see come close to the cost basis
    # of what the investor currently holds. When they do not, the honest answer
    # is that we cannot compute the return yet, not a number that assumes the
    # missing purchases were free.
    recorded_outflow = sum(-amount for _, amount in cashflows if amount < 0)
    cost_basis = summary["invested_value"] or Decimal(0)
    coverage = (recorded_outflow / cost_basis) if cost_basis else None

    unavailable_reason: Optional[str] = None
    if len(cashflows) < 2:
        unavailable_reason = "not enough cashflows to compute a return"
    elif coverage is not None and coverage < Decimal("0.80"):
        unavailable_reason = (
            "transaction history looks incomplete: recorded purchases of "
            f"{recorded_outflow:,.0f} cover only {coverage:.0%} of the "
            f"{cost_basis:,.0f} cost basis of current holdings"
        )

    rate = None if unavailable_reason else _xirr(cashflows)

    return {
        "investor_id": investor_id,
        "invested_value": summary["invested_value"],
        "current_value": summary["total_value"],
        "absolute_gain": summary["absolute_gain"],
        "absolute_return_pct": summary["absolute_return_pct"],
        "xirr_pct": Decimal(str(round(rate * 100, 2))) if rate is not None else None,
        "xirr_unavailable_reason": unavailable_reason,
        "transaction_coverage_pct": (
            Decimal(str(round(float(coverage) * 100, 1))) if coverage is not None else None
        ),
        "cashflow_count": len(cashflows),
        "unclassified_transaction_types": sorted(unclassified),
        "excluded_non_cashflow_rows": excluded_non_cashflow,
        "excluded_bad_date_rows": excluded_bad_date,
    }


# ---------------------------------------------------------------------------
# Timeline
# ---------------------------------------------------------------------------


def timeline(investor_id: str, months: int = 24) -> list[dict]:
    """Portfolio value month by month, reconstructed from snapshots.

    We hold point-in-time snapshots rather than mutable current state, so this
    is a question the data can answer directly: for each month end, take each
    position's most recent snapshot on or before that date and add them up.

    Positions that were never snapshotted before a given month simply do not
    contribute to it, which is correct -- the investor did not hold them yet as
    far as we know.
    """
    cutoff = date.today().replace(day=1) - timedelta(days=31 * months)

    return db.fetch_all(
        """
        WITH month_ends AS (
            SELECT (generate_series(
                        date_trunc('month', %s::date),
                        date_trunc('month', current_date),
                        interval '1 month'
                    ) + interval '1 month' - interval '1 day')::date AS as_of
        ),
        -- the newest snapshot for each position at each month end
        per_position AS (
            SELECT DISTINCT ON (m.as_of, h.account_id, h.instrument_id)
                   m.as_of,
                   h.current_value
            FROM month_ends m
            JOIN holding_snapshots h
              ON h.investor_id = %s AND h.as_of <= m.as_of
            ORDER BY m.as_of, h.account_id, h.instrument_id, h.as_of DESC
        )
        SELECT as_of,
               coalesce(sum(current_value), 0) AS total_value,
               count(*)                        AS positions
        FROM per_position
        GROUP BY as_of
        ORDER BY as_of
        """,
        (cutoff, investor_id),
    )


# ---------------------------------------------------------------------------
# Households and investor discovery
# ---------------------------------------------------------------------------



def value_history(investor_id: str, months: int = 24) -> dict:
    """The value month by month, and where the shape comes from.

    **A line drawn straight from `timeline` would lie.** On a real account it
    runs ₹21 lakh in July and ₹1.02 crore in August -- not growth, but the
    month a provident fund and a gold holding were typed in. Another shows six
    distinct values across twenty-six months, the rest carried forward because
    no snapshot existed.

    A reader sees a step and reads it as a gain. That is the same error as the
    fifty-four lakh of outperformance that was arithmetic on money we could not
    account for, drawn instead of written.

    So this returns the series with the position count at each month, and marks
    every month where the count changed. A chart can then draw the movement and
    say which parts of it are the portfolio moving and which are the record
    filling in -- which is the only honest way to draw this at all.
    """
    rows = timeline(investor_id, months)
    if not rows:
        return {"drawable": False, "why": "No snapshots to draw from."}

    points = []
    previous_count = None
    arrivals = 0

    for row in rows:
        count = int(row.get("positions") or 0)
        arrived = previous_count is not None and count > previous_count
        if arrived:
            arrivals += 1
        points.append({
            "as_of": row["as_of"].isoformat() if hasattr(row["as_of"], "isoformat")
                     else str(row["as_of"]),
            "value": str(_d(row.get("total_value")).quantize(Decimal("1"))),
            "positions": count,
            # True where holdings appeared this month, so the step is the
            # record filling in rather than the portfolio moving.
            "holdings_arrived": arrived,
        })
        previous_count = count

    distinct = len({p["value"] for p in points})

    # The longest stretch where nothing arrived.
    #
    # A chart spanning a composition change is unreadable even when it is
    # honest: on a real account the scale runs from fourteen lakh to a crore
    # because a provident fund was typed in, and two years of actual movement
    # becomes a flat line at the bottom.
    #
    # So we draw the longest stretch where the portfolio was the same
    # portfolio, and say what was left out. This is the refusal the XIRR and
    # the projection already make, applied to a picture.
    runs, current = [], []
    for point in points:
        if point["holdings_arrived"] and current:
            runs.append(current)
            current = []
        current.append(point)
    if current:
        runs.append(current)

    settled = max(runs, key=len) if runs else []
    stable_from = settled[0]["as_of"] if settled else None
    stable_to = settled[-1]["as_of"] if settled else None
    left_out = len(points) - len(settled)

    # Drawn from the stable stretch, so that is what has to be long enough.
    settled_distinct = len({p["value"] for p in settled})

    return {
        "drawable": len(settled) >= 4 and settled_distinct >= 3,
        "draw": settled,
        # Two different refusals, because they have two different fixes.
        #
        # The first said "the longest stretch is 10 of them" about a stretch
        # of ten months, which reads as arithmetic that does not follow. The
        # problem there was not the length -- it was that all ten carried the
        # same figure, because no statement covered any of them.
        "why": (
            None if len(settled) >= 4 and settled_distinct >= 3 else

            f"The longest stretch where your holdings did not change is "
            f"{len(settled)} months, and all {len(settled)} carry the same "
            f"figure — no statement covered any of them, so the value was "
            f"carried forward rather than measured. A line through that would "
            f"show a portfolio sitting perfectly still, which is not what "
            f"happened; it is what we could not see."
            if len(settled) >= 4 and settled_distinct < 3 else

            f"The longest stretch where your holdings did not change is "
            f"{len(settled)} month{'s' if len(settled) != 1 else ''}. Drawing "
            f"a line needs a few more, and every time something new arrives "
            f"the stretch starts again."),

        "why_short": ("no valuations in the stable stretch"
                      if settled_distinct < 3 else "the stretch is too short"),
        "what_would_help": (
            "A consolidated account statement covering those months. It "
            "carries a valuation for every date in it, which is what turns a "
            "carried-forward figure into a measured one."),
        "points": points,
        "distinct_values": distinct,
        "months": len(points),
        "arrivals": arrivals,
        "stable_from": stable_from,
        "stable_to": stable_to,
        "stable_months": len(settled),
        "left_out": left_out,
        "on_the_steps": (
            f"This shows {len(settled)} months where the same holdings were "
            f"held throughout. {left_out} other months are left out because "
            f"holdings arrived in our records during them, and a line across "
            f"that would show the record filling in rather than your money "
            f"moving."
            if left_out else None),
        "what_it_is": (
            "Month-end value, reconstructed from the statements and entries we "
            "hold. Where no statement covered a month, the previous figure is "
            "carried forward — so a flat stretch means we could not see, not "
            "that nothing happened."
        ),
    }

def list_investors(limit: int = 50, offset: int = 0,
                   only_ids: Optional[list[str]] = None) -> list[dict]:
    """Investors with their headline figures.

    `only_ids` is the caller's access scope. None means unrestricted, which is
    for administrators; an empty list is handled by the caller before we get
    here, because an empty IN () would quietly match nothing in some dialects
    and everything in others.
    """
    where = ""
    params: tuple = ()
    if only_ids is not None:
        where = "WHERE i.id = ANY(%s)"
        params = (only_ids,)

    return db.fetch_all(
        f"""
        SELECT i.id, i.display_name, i.pan_last4, i.email, i.kind,
               count(v.instrument_id)                AS positions,
               coalesce(sum(v.current_value), 0)     AS total_value
        FROM investors i
        LEFT JOIN v_current_holdings v ON v.investor_id = i.id
        {where}
        GROUP BY i.id, i.display_name, i.pan_last4, i.email, i.kind
        ORDER BY coalesce(sum(v.current_value), 0) DESC
        LIMIT %s OFFSET %s
        """,
        params + (limit, offset),
    )


def get_investor(investor_id: str) -> Optional[dict]:
    return db.fetch_one(
        "SELECT id, display_name, pan_last4, email, kind, created_at FROM investors WHERE id = %s",
        (investor_id,),
    )


def household_net_worth(household_id: str) -> dict:
    """Roll-up across every member flagged to count toward the household."""
    members = db.fetch_all(
        """
        SELECT i.id, i.display_name
        FROM household_members hm
        JOIN investors i ON i.id = hm.investor_id
        WHERE hm.household_id = %s AND hm.include_in_rollup
        """,
        (household_id,),
    )

    breakdown = [dict(net_worth(m["id"]), display_name=m["display_name"]) for m in members]
    return {
        "household_id": household_id,
        "members": breakdown,
        "total_value": sum(_d(m["total_value"]) for m in breakdown),
        "invested_value": sum(_d(m["invested_value"]) for m in breakdown),
    }
