"""What the money actually earned.

Growth between two dates is the easy number and the wrong one. A portfolio that
went from ten lakh to fifteen has grown fifty per cent — unless most of the ten
arrived last month, in which case it has not, and the fifty per cent describes
the timing of the deposits rather than the quality of the investing.

XIRR is the honest version: the single rate that, applied to every cashflow on
the date it happened, arrives at today's value. Money that went in early counts
for more than money that went in last week, which is the whole point.

**Why this was not built until now.** It needs the purchases, and most holdings
arrive through statements that list positions without the transactions behind
them. The platform has been saying so rather than showing growth and calling it
return — which was right, and is now unnecessary for the investors whose
statements did carry them.

**What it refuses.** Below a handful of cashflows the answer is arithmetic
rather than information: three purchases in one month cannot describe how a
five-year portfolio performed. And where the transactions cover only part of
what is held, the figure describes that part and says so — a return computed
over sixty per cent of a portfolio is not the portfolio's return.

**The synthetic rows are excluded.** Cost-basis entries carry a placeholder
date because nobody knows when the money went in. Including them would put a
1970 cashflow into the solver and produce a number that is not wrong so much as
meaningless.
"""

from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Any, Optional

from .. import db

log = logging.getLogger("alphanivesh.xirr")

# Below this, the answer describes the sample rather than the investing.
MIN_FLOWS = 6

# What counts as money going in and coming out.
INFLOWS = ("purchase", "sip", "switch_in")
OUTFLOWS = ("redemption", "switch_out", "sale")

# Rows written to record a cost basis where no date is known. Their date is a
# placeholder and putting one into the solver would be meaningless.
SYNTHETIC = ("costbasis",)

# The solver. A bisection rather than Newton-Raphson: slower, and it cannot
# diverge, which matters when the input is somebody's real money and the
# failure mode of the fast method is a confident absurd answer.
LOW, HIGH = Decimal("-0.99"), Decimal("10")
TOLERANCE = Decimal("0.0000001")
MAX_STEPS = 200


def _d(value: Any) -> Decimal:
    return Decimal(str(value)) if value is not None else Decimal(0)


def _npv(rate: Decimal, flows: list[tuple[date, Decimal]],
         start: date) -> Decimal:
    """The present value of every cashflow at a given rate."""
    total = Decimal(0)
    for when, amount in flows:
        years = Decimal((when - start).days) / Decimal("365.25")
        total += amount / ((1 + rate) ** years)
    return total


def _solve(flows: list[tuple[date, Decimal]]) -> Optional[Decimal]:
    """The rate at which the cashflows net to nothing.

    Bisection between -99% and +1000%. It cannot diverge and it cannot land on
    a spurious root, which Newton-Raphson can when the flows change sign more
    than once -- and a portfolio with redemptions in it does exactly that.
    """
    if not flows:
        return None

    start = min(when for when, _ in flows)

    low, high = LOW, HIGH
    at_low, at_high = _npv(low, flows, start), _npv(high, flows, start)

    # No sign change means no root in range. That happens when somebody has
    # lost almost everything or gained implausibly, and returning nothing is
    # better than returning a bound.
    if at_low * at_high > 0:
        return None

    for _ in range(MAX_STEPS):
        mid = (low + high) / 2
        value = _npv(mid, flows, start)
        if abs(value) < TOLERANCE:
            return mid
        if value * at_low < 0:
            high = mid
        else:
            low, at_low = mid, value

    return (low + high) / 2


def for_investor(investor_id: str) -> dict:
    """The money-weighted return, or why it cannot be given."""
    from . import wealth

    rows = db.fetch_all(
        """
        SELECT txn_date, txn_type, amount, instrument_id
        FROM canonical_transactions
        WHERE investor_id = %s
          AND txn_date > '2000-01-01'
          AND txn_type <> ALL(%s)
          AND amount IS NOT NULL AND amount <> 0
        ORDER BY txn_date
        """,
        (investor_id, list(SYNTHETIC)),
    )

    if len(rows) < MIN_FLOWS:
        return {
            "computable": False,
            "flows": len(rows),
            "why": (f"We hold {len(rows)} dated "
                    f"transaction{'s' if len(rows) != 1 else ''} for this "
                    f"portfolio. A money-weighted return needs enough of them "
                    f"to describe how the money actually went in — below about "
                    f"six, the answer describes the sample rather than the "
                    f"investing."),
            "what_would_help": ("Import an older statement. A consolidated "
                                "account statement covering the full history "
                                "carries the purchases, and this becomes "
                                "computable the moment it does."),
        }

    summary = wealth.net_worth(investor_id)
    value_now = _d(summary.get("total_value"))
    if value_now <= 0:
        return {"computable": False, "flows": len(rows),
                "why": "There is nothing held to value the cashflows against."}

    # How much of what is held these transactions actually cover. A return
    # computed over part of a portfolio is that part's return, and calling it
    # the portfolio's would be the same error as calling growth a return.
    covered = db.fetch_one(
        """
        SELECT sum(v.current_value) AS covered
        FROM v_current_holdings v
        WHERE v.investor_id = %s AND v.current_value > 0
          AND v.instrument_id IN (
            SELECT DISTINCT instrument_id FROM canonical_transactions
            WHERE investor_id = %s AND txn_date > '2000-01-01'
              AND txn_type <> ALL(%s))
        """,
        (investor_id, investor_id, list(SYNTHETIC)),
    )
    covered_value = _d((covered or {}).get("covered"))
    coverage_pct = ((covered_value / value_now * 100).quantize(Decimal("0.1"))
                    if value_now > 0 else Decimal(0))

    # Money in is negative, money out positive, and today's value is the final
    # inflow -- the convention that makes the solved rate a return rather than
    # its inverse.
    flows: list[tuple[date, Decimal]] = []
    invested = Decimal(0)
    withdrawn = Decimal(0)

    for row in rows:
        amount = abs(_d(row["amount"]))
        if row["txn_type"] in INFLOWS:
            flows.append((row["txn_date"], -amount))
            invested += amount
        elif row["txn_type"] in OUTFLOWS:
            flows.append((row["txn_date"], amount))
            withdrawn += amount

    if not flows:
        return {"computable": False, "flows": 0,
                "why": "None of the transactions we hold are purchases or sales."}

    # Does the money add up?
    #
    # The holdings check above asks whether these transactions touch most of
    # what is held. That is not the same question as whether they account for
    # most of what went in -- and on a real account it passed while the
    # transactions covered a tenth of the money.
    #
    # The solver then saw 72,000 becoming 8.89 lakh and correctly returned
    # 792% a year. Correct arithmetic on a partial history, which is the most
    # dangerous kind of wrong: it looks like a triumph.
    net_in = invested - withdrawn
    if net_in <= 0:
        return {"computable": False, "flows": len(flows),
                "why": "More has come out than gone in, in the transactions we "
                       "hold, which leaves nothing to compute a return on."}

    accounted = net_in / covered_value * 100 if covered_value > 0 else Decimal(0)

    if accounted < 60:
        return {
            "computable": False,
            "flows": len(flows),
            "accounted_pct": str(accounted.quantize(Decimal("0.1"))),
            "why": (f"The purchases we hold come to ₹{int(net_in):,} against "
                    f"holdings worth ₹{int(covered_value):,}. That is "
                    f"{accounted:.0f}% of the money accounted for, so a return "
                    f"computed from them would describe a fraction of what "
                    f"actually went in — and would come out far too high."),
            "what_would_help": ("Import an older statement. The transactions we "
                                "have start partway through, and the earlier "
                                "ones are what is missing."),
        }

    flows.append((date.today(), covered_value if covered_value > 0 else value_now))

    rate = _solve(flows)
    if rate is None:
        return {
            "computable": False,
            "flows": len(flows) - 1,
            "why": ("The cashflows do not resolve to a single rate. That "
                    "usually means money went in and out in a pattern with more "
                    "than one mathematical answer, and picking one of them "
                    "would be arbitrary."),
        }

    pct = rate * 100

    # A last check on the answer rather than on the inputs. Above this, the
    # cashflows are incomplete in some way the coverage test did not catch,
    # and a number that would be a record-breaking hedge fund is more likely
    # to be a missing statement.
    if pct > 100 or pct < -95:
        return {
            "computable": False,
            "flows": len(flows) - 1,
            "why": (f"The cashflows we hold produce a return of {pct:.0f}% a "
                    f"year, which is not a real return on a real portfolio — "
                    f"it means the purchases we can see are only part of what "
                    f"went in. Import an older statement and this becomes "
                    f"answerable."),
        }

    first = min(when for when, _ in flows[:-1])
    years = Decimal((date.today() - first).days) / Decimal("365.25")

    return {
        "computable": True,
        "xirr_pct": str(pct.quantize(Decimal("0.01"))),
        "flows": len(flows) - 1,
        "invested": str(invested.quantize(Decimal("1"))),
        "withdrawn": str(withdrawn.quantize(Decimal("1"))),
        "value_now": str(covered_value.quantize(Decimal("1"))),
        "since": first.isoformat(),
        "years": str(years.quantize(Decimal("0.1"))),
        "coverage_pct": str(coverage_pct.quantize(Decimal("0.1"))),
        "money_accounted_pct": str(accounted.quantize(Decimal("0.1"))),
        "partial": coverage_pct < 95 or accounted < 95,
        "reading": _reading(pct, invested, covered_value, years,
                            len(flows) - 1, coverage_pct),
        "what_it_is": (
            "The single rate that, applied to every purchase on the date it "
            "happened, arrives at today's value. Money that went in early "
            "counts for more than money that went in last week — which is why "
            "this differs from the growth figure, and why it is the one that "
            "says whether the investing worked."
        ),
    }


def _reading(pct: Decimal, invested: Decimal, value: Decimal,
             years: Decimal, flows: int, coverage: Decimal) -> str:
    line = (f"{pct:.2f}% a year on the money as it actually went in — "
            f"{flows} purchases over {years:.1f} years, turning "
            f"₹{int(invested):,} into ₹{int(value):,}.")

    if coverage < 95:
        line += (f" This covers {coverage:.0f}% of what you hold: the rest "
                 f"arrived without its purchase history, so this is the return "
                 f"on the part we can trace rather than on the whole "
                 f"portfolio.")

    return line
