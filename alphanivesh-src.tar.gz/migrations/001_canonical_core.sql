-- 001_canonical_core.sql
--
-- AlphaWealth canonical core: the entities that let us consolidate a person's
-- wealth across asset classes and across our existing products.
--
-- Context for whoever reads this next:
--   alphamarket_db already has a capable multi-asset holdings table
--   (portfolio_holdings) and a solid identity/compliance model around `users`.
--   What it does not have is (a) a PAN-anchored investor separate from the
--   login, (b) household grouping, (c) a source-account layer to dedupe the
--   same position arriving from two feeds, and (d) point-in-time history.
--   This migration adds exactly those. It does not touch or drop anything
--   that already exists.
--
-- Conventions deliberately copied from alphamarket_db so that a future merge
-- is a data copy rather than a rewrite: varchar UUID primary keys defaulted
-- with gen_random_uuid(), snake_case, plural table names.
--
-- Two things we do differently on purpose:
--   * money and quantities are numeric(20,6), never float. alphalensmf uses
--     real(4-byte) today and loses precision above ~7 significant digits.
--   * dates are date/timestamptz, never text. Several existing tables store
--     dates as text which blocks interval maths and time-travel queries.

BEGIN;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------

-- Asset classes we can hold. Deliberately broader than what we can ingest
-- today: manual entry covers the long tail (property, unlisted, physical gold)
-- until a feed exists for it.
CREATE TYPE asset_class AS ENUM (
    'equity',
    'mutual_fund',
    'etf',
    'bond',
    'gsec',
    'aif',
    'gold',
    'fixed_deposit',
    'insurance',
    'nps',
    'ppf_epf',
    'real_estate',
    'unlisted',
    'cash',
    'other'
);

-- Where a holding came from. Drives dedupe precedence in the consolidation
-- engine: a CDSL demat record beats a manually keyed one for the same ISIN.
CREATE TYPE holding_source AS ENUM (
    'casparser_cdsl',
    'casparser_nsdl',
    'casparser_cams',
    'casparser_kfintech',
    'account_aggregator',
    'broker_feed',
    'manual',
    'imported_legacy'
);

-- What an entity is, for KYC and tax treatment. Individuals dominate but
-- family offices bring HUFs, trusts and private companies.
CREATE TYPE investor_kind AS ENUM (
    'individual',
    'huf',
    'trust',
    'partnership',
    'company',
    'nri'
);

-- The basis on which an advisor serves an investor. This encodes the SEBI
-- boundary in data rather than leaving it to application logic: a
-- distribution relationship must not produce personalised advice.
CREATE TYPE mandate_type AS ENUM (
    'advisory',
    'distribution',
    'execution_only',
    'view_only'
);

-- ---------------------------------------------------------------------------
-- Investors and households
-- ---------------------------------------------------------------------------

-- An investor is a person or entity whose wealth we track. It is NOT a login.
-- A login (alphamarket_db.users) may control several investors, and an
-- investor may have no login at all when an advisor onboards them.
--
-- PAN is the natural key for an Indian investor but we never store it raw.
-- pan_hash is a SHA-256 of the normalised (uppercased, trimmed) PAN; pan_last4
-- exists so the UI can show "…4F" without a decrypt step. This mirrors what
-- alphalensmf_db.cas_requests already does.
CREATE TABLE investors (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    kind            investor_kind NOT NULL DEFAULT 'individual',

    pan_hash        text,
    pan_last4       text,

    display_name    text NOT NULL,
    email           text,
    phone           text,
    date_of_birth   date,

    -- The login that owns this investor record, when there is one. Nullable by
    -- design: advisor-onboarded clients often never log in themselves.
    owner_user_id   varchar,

    -- Set when this investor was reconciled out of an existing product so we
    -- can trace lineage during the migration period.
    legacy_ref      jsonb,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

-- One investor per PAN. Partial index because PAN is genuinely unknown for
-- some manually-created records and we do not want to block those.
CREATE UNIQUE INDEX investors_pan_hash_key
    ON investors (pan_hash) WHERE pan_hash IS NOT NULL;

CREATE INDEX investors_owner_user_id_idx ON investors (owner_user_id);
CREATE INDEX investors_email_idx ON investors (lower(email));

-- A household is the roll-up unit: a family, or a family office covering
-- several individuals and entities. Net worth is reported per investor and
-- per household.
CREATE TABLE households (
    id            varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    name          text NOT NULL,
    -- The investor whose view the household defaults to, usually the patriarch
    -- or the primary account holder.
    primary_investor_id varchar REFERENCES investors(id) ON DELETE SET NULL,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE household_members (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    household_id    varchar NOT NULL REFERENCES households(id) ON DELETE CASCADE,
    investor_id     varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    relationship    text,          -- 'self', 'spouse', 'child', 'huf', free text
    -- Whether this member's assets count towards the household total. A minor
    -- child's holdings usually do; a business entity's often do not.
    include_in_rollup boolean NOT NULL DEFAULT true,
    created_at      timestamptz NOT NULL DEFAULT now(),
    UNIQUE (household_id, investor_id)
);

CREATE INDEX household_members_investor_idx ON household_members (investor_id);

-- ---------------------------------------------------------------------------
-- Advisory relationships
-- ---------------------------------------------------------------------------

-- Links an advisor (alphamarket_db.users with role='advisor') to an investor.
-- We keep advisor_user_id as a plain varchar rather than a FK because during
-- the (B) phase this schema lives in a different database from users. The
-- application resolves it; when we converge (phase C) this becomes a real FK.
CREATE TABLE advisory_relationships (
    id                varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    advisor_user_id   varchar NOT NULL,
    investor_id       varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    mandate           mandate_type NOT NULL DEFAULT 'view_only',

    -- An advisor may be onboarded but not yet consented to by the investor.
    is_active         boolean NOT NULL DEFAULT true,
    consented_at      timestamptz,
    revoked_at        timestamptz,

    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),
    UNIQUE (advisor_user_id, investor_id)
);

CREATE INDEX advisory_relationships_investor_idx ON advisory_relationships (investor_id);
CREATE INDEX advisory_relationships_advisor_idx ON advisory_relationships (advisor_user_id) WHERE is_active;

-- ---------------------------------------------------------------------------
-- Source documents
-- ---------------------------------------------------------------------------

-- Every canonical row we derive from an external feed points back to the raw
-- payload it came from. Two reasons: an auditable trail from any number on
-- screen back to its source, and the ability to re-derive everything when the
-- mapping logic improves without re-fetching from the provider.
--
-- Payloads are immutable. Corrections arrive as a new document.
CREATE TABLE source_documents (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     varchar REFERENCES investors(id) ON DELETE SET NULL,
    source          holding_source NOT NULL,

    -- e.g. 'casparser:/v4/smart/parse', 'casparser:/v4/cdsl/parse'
    provider_ref    text,
    -- The statement period the document covers, where the source tells us.
    statement_from  date,
    statement_to    date,

    payload         jsonb NOT NULL,
    payload_sha256  text NOT NULL,

    received_at     timestamptz NOT NULL DEFAULT now(),
    processed_at    timestamptz,
    -- 'received' | 'parsed' | 'failed'; free text so we can add states without
    -- a migration during the build phase.
    status          text NOT NULL DEFAULT 'received',
    error_detail    text
);

-- The same CAS uploaded twice should not create two documents.
CREATE UNIQUE INDEX source_documents_sha_key ON source_documents (payload_sha256);
CREATE INDEX source_documents_investor_idx ON source_documents (investor_id, received_at DESC);

-- ---------------------------------------------------------------------------
-- Instruments
-- ---------------------------------------------------------------------------

-- The canonical security master across every asset class.
--
-- alphamarket_db.instrument_master already covers exchange-traded instruments
-- well (139k rows, Kite-shaped: instrument_token, expiry, strike, lot_size).
-- It cannot describe an MF scheme, an FD, or an insurance policy. This table
-- is the superset; for equities it carries the kite token so we can join back.
--
-- Identity precedence: ISIN where one exists, else the asset-class-specific
-- code (AMFI scheme code, policy number), else a synthetic id for manual
-- assets like "flat in Pune".
CREATE TABLE instruments (
    id                varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_class       asset_class NOT NULL,

    isin              text,
    -- AMFI scheme code for MFs, ticker for equities, ISIN-less identifier
    -- otherwise. Meaning is scoped by asset_class.
    native_code       text,
    symbol            text,
    exchange          text,

    name              text NOT NULL,
    issuer            text,          -- AMC, bank, insurer, corporate
    sector            text,
    -- MF category/sub-category, bond type, insurance product type. Free text
    -- because each asset class taxonomises differently.
    category          text,
    sub_category      text,

    -- Bridge to the existing Kite-shaped master, when this is exchange-traded.
    kite_instrument_token bigint,

    currency          text NOT NULL DEFAULT 'INR',
    is_active         boolean NOT NULL DEFAULT true,

    -- Anything asset-class-specific that does not deserve a column:
    -- coupon and maturity for bonds, expense ratio for funds, and so on.
    attributes        jsonb NOT NULL DEFAULT '{}'::jsonb,

    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX instruments_isin_key
    ON instruments (isin) WHERE isin IS NOT NULL;
CREATE UNIQUE INDEX instruments_native_code_key
    ON instruments (asset_class, native_code) WHERE native_code IS NOT NULL;
CREATE INDEX instruments_symbol_idx ON instruments (symbol, exchange);
CREATE INDEX instruments_kite_token_idx ON instruments (kite_instrument_token)
    WHERE kite_instrument_token IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Accounts
-- ---------------------------------------------------------------------------

-- Where a holding physically sits: a demat account, an MF folio, a bank FD, an
-- NPS PRAN, an insurance policy, or a manual bucket.
--
-- This layer is what makes dedupe possible. The same HDFC fund can arrive from
-- a CAMS statement (as a folio) and from a CDSL demat statement (as units in
-- demat). Without an account we would double count.
CREATE TABLE accounts (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    source          holding_source NOT NULL,

    -- 'demat' | 'mf_folio' | 'bank' | 'nps' | 'insurance' | 'manual'
    account_kind    text NOT NULL,
    -- DP id + client id, folio number, PRAN, policy number. Masked for display.
    account_number  text,
    account_label   text,          -- what the user calls it
    institution     text,          -- Zerodha, HDFC AMC, SBI, LIC

    is_active       boolean NOT NULL DEFAULT true,
    last_synced_at  timestamptz,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX accounts_investor_idx ON accounts (investor_id) WHERE is_active;
CREATE UNIQUE INDEX accounts_natural_key
    ON accounts (investor_id, source, account_kind, coalesce(account_number, ''));

-- ---------------------------------------------------------------------------
-- Holdings
-- ---------------------------------------------------------------------------

-- Point-in-time position snapshots. Append-only: we never update a snapshot,
-- we write a new one with a later as_of.
--
-- This is the single most consequential decision in this migration. Storing
-- history rather than current state is what lets us answer "what was my net
-- worth on 31 March", compute real drawdown, and reconcile when a feed
-- restates the past. Current state is a view over the latest row per
-- (account, instrument) -- see v_current_holdings below.
CREATE TABLE holding_snapshots (
    id                  varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id         varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    account_id          varchar NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    instrument_id       varchar NOT NULL REFERENCES instruments(id),

    as_of               date NOT NULL,
    source              holding_source NOT NULL,
    source_document_id  varchar REFERENCES source_documents(id) ON DELETE SET NULL,

    quantity            numeric(20,6) NOT NULL DEFAULT 0,
    -- Per-unit cost. Null when the source does not disclose it, which is
    -- common for demat statements; the consolidation engine then falls back to
    -- transaction history if we have any.
    avg_cost            numeric(20,6),
    price               numeric(20,6),
    current_value       numeric(20,6),
    invested_value      numeric(20,6),

    -- Asset-class specifics that do not belong on instruments because they
    -- vary per holding: sum assured on this policy, this FD's rate, the
    -- maturity of this particular tranche.
    attributes          jsonb NOT NULL DEFAULT '{}'::jsonb,

    created_at          timestamptz NOT NULL DEFAULT now()
);

-- One snapshot per position per day per source. A re-import of the same day
-- overwrites via upsert rather than piling up duplicates.
CREATE UNIQUE INDEX holding_snapshots_natural_key
    ON holding_snapshots (account_id, instrument_id, as_of, source);

CREATE INDEX holding_snapshots_investor_asof_idx
    ON holding_snapshots (investor_id, as_of DESC);
CREATE INDEX holding_snapshots_instrument_idx
    ON holding_snapshots (instrument_id);

-- Latest snapshot per position. The application reads this, not the raw table.
CREATE VIEW v_current_holdings AS
SELECT DISTINCT ON (h.account_id, h.instrument_id)
       h.*,
       i.asset_class,
       i.name        AS instrument_name,
       i.isin,
       i.symbol
FROM holding_snapshots h
JOIN instruments i ON i.id = h.instrument_id
ORDER BY h.account_id, h.instrument_id, h.as_of DESC, h.created_at DESC;

-- ---------------------------------------------------------------------------
-- Transactions
-- ---------------------------------------------------------------------------

-- Normalised across asset classes. An MF purchase, an equity buy, an FD
-- opening and an insurance premium all land here with the same shape.
CREATE TABLE canonical_transactions (
    id                  varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id         varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    account_id          varchar NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    instrument_id       varchar REFERENCES instruments(id),

    -- 'buy' | 'sell' | 'dividend' | 'switch_in' | 'switch_out' | 'sip'
    -- | 'premium' | 'maturity' | 'interest' | 'bonus' | 'split'
    txn_type            text NOT NULL,
    txn_date            date NOT NULL,

    quantity            numeric(20,6),
    price               numeric(20,6),
    amount              numeric(20,6) NOT NULL,

    source              holding_source NOT NULL,
    source_document_id  varchar REFERENCES source_documents(id) ON DELETE SET NULL,
    -- The provider's own reference, used to avoid re-importing the same
    -- transaction from an overlapping statement period.
    external_ref        text,

    attributes          jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX canonical_transactions_investor_date_idx
    ON canonical_transactions (investor_id, txn_date DESC);
CREATE INDEX canonical_transactions_account_idx
    ON canonical_transactions (account_id, txn_date DESC);
CREATE UNIQUE INDEX canonical_transactions_external_key
    ON canonical_transactions (account_id, external_ref)
    WHERE external_ref IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Valuation history
-- ---------------------------------------------------------------------------

-- Daily net worth per investor, and optionally per household, so the wealth
-- timeline does not have to be recomputed from snapshots on every page load.
-- Written by the nightly valuation job.
CREATE TABLE valuation_history (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     varchar REFERENCES investors(id) ON DELETE CASCADE,
    household_id    varchar REFERENCES households(id) ON DELETE CASCADE,

    as_of           date NOT NULL,
    total_value     numeric(20,6) NOT NULL,
    invested_value  numeric(20,6),
    -- Value split by asset class, e.g. {"equity": 1200000, "mutual_fund": 900000}.
    -- Denormalised on purpose: the allocation chart is the most-hit query on
    -- the dashboard and this avoids a group-by over every holding.
    by_asset_class  jsonb NOT NULL DEFAULT '{}'::jsonb,

    created_at      timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT valuation_scope_ck
        CHECK (investor_id IS NOT NULL OR household_id IS NOT NULL)
);

CREATE UNIQUE INDEX valuation_history_investor_key
    ON valuation_history (investor_id, as_of) WHERE investor_id IS NOT NULL;
CREATE UNIQUE INDEX valuation_history_household_key
    ON valuation_history (household_id, as_of) WHERE household_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER investors_touch BEFORE UPDATE ON investors
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER households_touch BEFORE UPDATE ON households
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER advisory_relationships_touch BEFORE UPDATE ON advisory_relationships
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER instruments_touch BEFORE UPDATE ON instruments
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER accounts_touch BEFORE UPDATE ON accounts
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

COMMIT;
