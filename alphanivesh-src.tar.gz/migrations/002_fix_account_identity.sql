-- 002_fix_account_identity.sql
--
-- Fixes a double-counting bug found while importing AlphaLensMF.
--
-- The same MF folio arriving from two different statement providers (a CAMS
-- statement in January, a KFintech one in June) was creating two `accounts`
-- rows, because the natural key included `source`. The current-holdings view
-- then treated them as two separate positions and added them together, so an
-- investor's net worth was overstated by the value of every position that had
-- been seen through more than one feed.
--
-- A folio number is issued by the registrar, not by whoever printed the
-- statement, so it identifies the account on its own. `source` still belongs
-- on each snapshot -- that is how we know where a given day's figures came
-- from, and how we break ties when two feeds disagree.

BEGIN;

DROP INDEX IF EXISTS accounts_natural_key;

CREATE UNIQUE INDEX accounts_natural_key
    ON accounts (investor_id, account_kind, coalesce(account_number, ''));

-- Rebuild the view so that a position is unique per (investor, instrument),
-- not per (account, instrument). Where the same instrument appears in two
-- accounts we keep the most recently dated row.
--
-- Tie-break order, applied in sequence:
--   as_of        -- the newest statement wins
--   source rank  -- a depository record beats a registrar summary, which
--                   beats anything a human typed in
--   created_at   -- last resort, so the result is at least deterministic
DROP VIEW IF EXISTS v_current_holdings;

CREATE VIEW v_current_holdings AS
SELECT DISTINCT ON (h.investor_id, h.instrument_id)
       h.*,
       i.asset_class,
       i.name AS instrument_name,
       i.isin,
       i.symbol
FROM holding_snapshots h
JOIN instruments i ON i.id = h.instrument_id
ORDER BY h.investor_id,
         h.instrument_id,
         h.as_of DESC,
         CASE h.source
             WHEN 'casparser_cdsl'     THEN 1
             WHEN 'casparser_nsdl'     THEN 2
             WHEN 'casparser_cams'     THEN 3
             WHEN 'casparser_kfintech' THEN 4
             WHEN 'account_aggregator' THEN 5
             WHEN 'broker_feed'        THEN 6
             WHEN 'manual'             THEN 7
             ELSE 8
         END,
         h.created_at DESC;

COMMIT;
