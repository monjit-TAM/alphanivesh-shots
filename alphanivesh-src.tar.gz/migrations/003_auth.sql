-- 003_auth.sql
--
-- Accounts for AlphaNivesh itself.
--
-- Deliberately its own users table rather than anything carried over from
-- AlphaLensMF or AlphaMarket. Those products keep their own logins; this
-- platform issues its own, and the only thing we retain from an import is a
-- note in investors.legacy_ref saying where the record first came from.
--
-- Sessions are stored here rather than encoded into a JWT. A wealth platform
-- needs to be able to end a session immediately -- a support request, a stolen
-- laptop, a compromised password -- and a signed token that is valid until it
-- expires cannot do that. The cookie carries an opaque id; everything that
-- matters lives in this table.

BEGIN;

CREATE TYPE user_role AS ENUM ('investor', 'advisor', 'admin');

CREATE TABLE users (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    email           text NOT NULL,
    password_hash   text NOT NULL,
    full_name       text NOT NULL,
    role            user_role NOT NULL DEFAULT 'investor',

    -- An advisor's firm, and their registration number where they have one.
    -- Both nullable: a retail user has neither.
    firm_name       text,
    sebi_reg_number text,

    is_active       boolean NOT NULL DEFAULT true,
    email_verified_at timestamptz,
    last_login_at   timestamptz,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

-- Email is the login, matched case-insensitively. Storing it as given keeps
-- the display honest; the index is what enforces uniqueness.
CREATE UNIQUE INDEX users_email_key ON users (lower(email));

CREATE TABLE sessions (
    id          varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     varchar NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- The cookie holds a long random string; we store only its SHA-256. A
    -- leaked database backup therefore does not hand over live sessions.
    token_hash  text NOT NULL,

    -- Kept for the "signed in on these devices" view and for spotting
    -- suspicious activity. Not used for authorisation.
    user_agent  text,
    ip_address  text,

    expires_at  timestamptz NOT NULL,
    revoked_at  timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX sessions_token_key ON sessions (token_hash);
CREATE INDEX sessions_user_idx ON sessions (user_id) WHERE revoked_at IS NULL;

-- investors.owner_user_id was created pointing at nothing in particular, since
-- at the time there was no users table for it to reference. Anything left over
-- from the AlphaLensMF import refers to that product's ids and is meaningless
-- here, so it is cleared before the constraint goes on.
UPDATE investors SET owner_user_id = NULL WHERE owner_user_id IS NOT NULL;

ALTER TABLE investors
    ADD CONSTRAINT investors_owner_user_fk
    FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE SET NULL;

-- advisory_relationships.advisor_user_id was a bare varchar for the same
-- reason. Now that users exist it becomes a real reference.
DELETE FROM advisory_relationships
 WHERE advisor_user_id NOT IN (SELECT id FROM users);

ALTER TABLE advisory_relationships
    ADD CONSTRAINT advisory_relationships_advisor_fk
    FOREIGN KEY (advisor_user_id) REFERENCES users(id) ON DELETE CASCADE;

CREATE TRIGGER users_touch BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

COMMIT;
