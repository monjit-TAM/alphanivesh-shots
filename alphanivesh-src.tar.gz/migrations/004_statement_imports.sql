-- 004_statement_imports.sql
--
-- A record of every statement someone brings us, whether or not it worked.
--
-- Failed imports matter as much as successful ones. When a person uploads a
-- statement and nothing appears, they need to be told why, and we need to be
-- able to look at what happened without asking them to try again. Most support
-- questions about a wealth product are some version of "where did my money go",
-- and this table is how that gets answered.
--
-- The parsed payload itself lands in source_documents, which already exists and
-- already deduplicates on a hash of the content. This table tracks the attempt:
-- who, when, which route, what came back.

BEGIN;

CREATE TYPE import_status AS ENUM (
    'received',     -- file accepted, nothing done yet
    'parsing',      -- handed to the parser
    'parsed',       -- parser returned something usable
    'mapped',       -- turned into canonical holdings
    'failed'
);

CREATE TYPE import_route AS ENUM (
    'file_upload',      -- the person had a PDF and gave it to us
    'cas_request',      -- we asked the registrar to email them one
    'inbox_fetch',      -- pulled from their mailbox with consent
    'depository_otp'    -- fetched live from CDSL against an OTP
);

CREATE TABLE statement_imports (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Who uploaded it. Kept even when we cannot work out which investor the
    -- statement belongs to, which is exactly when someone needs help.
    user_id         varchar NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- Filled in once the statement identifies its owner. Null until then.
    investor_id     varchar REFERENCES investors(id) ON DELETE SET NULL,

    route           import_route NOT NULL,
    status          import_status NOT NULL DEFAULT 'received',

    -- What the person gave us. The file itself is not kept once parsed: it is
    -- a password-protected document full of somebody's financial life and we
    -- have no reason to hold it after we have the structured version.
    original_filename text,
    file_size_bytes   integer,
    file_sha256       text,

    -- Which parser and what it said. `provider_message` is shown to the user
    -- when things go wrong, so it needs to survive.
    provider          text,
    provider_message  text,

    source_document_id varchar REFERENCES source_documents(id) ON DELETE SET NULL,

    -- What we managed to make of it. Counted so a person can be told
    -- "eleven holdings from two folios" rather than a bare success.
    accounts_created  integer NOT NULL DEFAULT 0,
    holdings_imported integer NOT NULL DEFAULT 0,
    holdings_quarantined integer NOT NULL DEFAULT 0,
    transactions_imported integer NOT NULL DEFAULT 0,

    -- Anything a human should look at: quarantine reasons, unmatched schemes,
    -- a PAN that belongs to somebody else's account.
    notes           jsonb NOT NULL DEFAULT '[]'::jsonb,
    error_detail    text,

    created_at      timestamptz NOT NULL DEFAULT now(),
    completed_at    timestamptz
);

CREATE INDEX statement_imports_user_idx ON statement_imports (user_id, created_at DESC);
CREATE INDEX statement_imports_investor_idx ON statement_imports (investor_id, created_at DESC);

-- The same file uploaded twice should be recognised rather than reprocessed.
CREATE INDEX statement_imports_file_idx ON statement_imports (user_id, file_sha256)
    WHERE file_sha256 IS NOT NULL;

COMMIT;
