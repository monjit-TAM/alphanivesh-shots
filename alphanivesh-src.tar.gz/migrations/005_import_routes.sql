-- 005_import_routes.sql
--
-- State for the statement routes that are not a straight file upload.
--
-- Two of them need to remember something between requests: a mailbox
-- connection holds a token that CASParser gave us on the investor's behalf,
-- and a depository fetch has an OTP step in the middle. Neither belongs in a
-- session cookie -- one outlives the browser, the other must not be replayable.

BEGIN;

-- A mailbox the investor has let us look in.
--
-- The token here can read their email. It is stored because the alternative is
-- asking them to re-authorise every time, but it is worth being clear-eyed
-- about what it is: revoking it must be one click, and disconnecting must
-- revoke upstream as well as locally.
CREATE TABLE inbox_connections (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         varchar NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    provider        text NOT NULL,           -- gmail | microsoft | zoho
    email           text,                    -- which mailbox, for the UI to name it
    inbox_token     text NOT NULL,

    connected_at    timestamptz NOT NULL DEFAULT now(),
    last_import_at  timestamptz,
    revoked_at      timestamptz
);

CREATE UNIQUE INDEX inbox_connections_live_idx
    ON inbox_connections (user_id, provider) WHERE revoked_at IS NULL;

-- A depository fetch waiting on its OTP.
--
-- Short-lived by design. The row carries no PAN and no date of birth: those go
-- to CDSL and are not ours to keep. What remains is the session CASParser gave
-- us and enough to rate-limit.
CREATE TABLE depository_fetches (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         varchar NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    depository      text NOT NULL DEFAULT 'cdsl',
    provider_session text NOT NULL,
    pan_last4       text,

    status          text NOT NULL DEFAULT 'otp_sent',   -- otp_sent | verified | failed | expired
    attempts        integer NOT NULL DEFAULT 0,

    created_at      timestamptz NOT NULL DEFAULT now(),
    expires_at      timestamptz NOT NULL DEFAULT now() + interval '15 minutes',
    completed_at    timestamptz
);

CREATE INDEX depository_fetches_user_idx ON depository_fetches (user_id, created_at DESC);

-- Requests we have made to a registrar to email somebody their statement.
--
-- The PAN is hashed, never stored whole: it is here to enforce the rate limit,
-- not to be read back. The last four characters are kept so the interface can
-- say which PAN was used without being able to reconstruct it.
CREATE TABLE statement_requests (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         varchar NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    pan_hash        text NOT NULL,
    pan_last4       text,
    email           text NOT NULL,
    provider        text NOT NULL DEFAULT 'kfintech',

    -- The registrar encrypts the PDF. We choose the password so we can tell the
    -- investor what it is, rather than leaving them to guess at one they set
    -- weeks ago.
    pdf_password    text,

    status          text NOT NULL DEFAULT 'requested',
    provider_message text,

    requested_at    timestamptz NOT NULL DEFAULT now(),
    fulfilled_at    timestamptz
);

CREATE INDEX statement_requests_rate_idx ON statement_requests (pan_hash, requested_at DESC);
CREATE INDEX statement_requests_user_idx ON statement_requests (user_id, requested_at DESC);

COMMIT;
