-- 006_profile_and_goals.sql
--
-- What we know about the person, as opposed to what they own.
--
-- Holdings tell us what someone has. They cannot tell us whether it is enough,
-- or right, or too much risk for someone three years from retiring. A fifth of
-- a portfolio in one midcap fund is unremarkable at thirty and reckless at
-- sixty-two, and until we know which we are describing structure rather than
-- giving advice.
--
-- AlphaLensMF asks for these at upload and then throws them away -- the fields
-- appear nowhere in its schema, so the same person re-enters their age every
-- time they analyse a statement. Storing them is most of the value here: a
-- profile that persists is what makes goals mean anything, and what lets an
-- answer change when someone's circumstances do.
--
-- Everything is optional on purpose. A partly-filled profile is more useful
-- than an empty one, and the analysis says plainly what it cannot work out yet
-- rather than demanding the form be completed first.

BEGIN;

CREATE TYPE risk_appetite AS ENUM ('conservative', 'moderate', 'aggressive');

CREATE TYPE goal_kind AS ENUM (
    'retirement',
    'education',
    'home',
    'emergency_fund',
    'wedding',
    'vehicle',
    'travel',
    'wealth',        -- no particular purpose, just growth
    'other'
);

-- One profile per investor. Kept separate from `investors` because that table
-- is identity -- who this person is -- and this is circumstance, which changes.
CREATE TABLE investor_profiles (
    investor_id     varchar PRIMARY KEY REFERENCES investors(id) ON DELETE CASCADE,

    -- Date of birth rather than age, so it stays true without being updated.
    -- Age alone would quietly rot: a profile filled in at 34 still says 34 five
    -- years later, and the retirement maths would be five years wrong.
    date_of_birth   date,

    monthly_income      numeric(20,2),
    monthly_expenses    numeric(20,2),
    dependents          smallint,

    risk_appetite       risk_appetite,
    -- Years the money can stay invested. Distinct from any single goal's
    -- horizon: someone may hold a twenty-year view while saving for a car.
    horizon_years       smallint,

    -- Cash set aside for emergencies, which is not an investment and should not
    -- be counted as one. Held here rather than as a holding because most people
    -- keep it in a savings account we will never see.
    emergency_fund      numeric(20,2),

    -- Anything the investor wants recorded that we have no field for.
    notes           text,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

-- What the money is actually for.
--
-- The distinction that matters is between a goal with a date and an amount --
-- which can be measured against -- and a vague intention, which cannot. Both
-- are allowed; only the first produces a shortfall figure.
CREATE TABLE goals (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id     varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,

    kind            goal_kind NOT NULL DEFAULT 'other',
    name            text NOT NULL,

    target_amount   numeric(20,2),
    target_date     date,

    -- What is already earmarked for this, where the investor has said so. Left
    -- null when the money is simply in the portfolio somewhere, which is the
    -- common case.
    current_amount  numeric(20,2),
    monthly_contribution numeric(20,2),

    -- Ordering when several goals compete for the same rupee. Lower is nearer
    -- the front.
    priority        smallint NOT NULL DEFAULT 5,
    is_achieved     boolean NOT NULL DEFAULT false,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX goals_investor_idx ON goals (investor_id, priority, target_date);

CREATE TRIGGER investor_profiles_touch BEFORE UPDATE ON investor_profiles
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER goals_touch BEFORE UPDATE ON goals
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

COMMIT;
