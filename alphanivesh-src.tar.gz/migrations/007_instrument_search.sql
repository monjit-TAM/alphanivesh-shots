-- 007_instrument_search.sql
--
-- Something to search when the investor is typing.
--
-- Manual entry without a lookup is worse than tedious: a fund typed by hand as
-- "HDFC Flexicap" will not match the "HDFC Flexi Cap Fund - Direct Growth"
-- already imported from a statement, so the same holding becomes two
-- instruments and the net worth is wrong. A search that resolves to a real
-- identifier is what stops that.
--
-- Kept as its own table rather than reusing `instruments`, because these are
-- securities that exist in the world whether or not anybody here holds them.
-- `instruments` stays a record of what our investors actually own.

BEGIN;

CREATE TABLE searchable_instruments (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),

    asset_class     asset_class NOT NULL,
    name            text NOT NULL,
    isin            text,

    -- Whatever identifies it in its own world: a ticker for a share, an AMFI
    -- code for a scheme.
    symbol          text,
    native_code     text,

    issuer          text,        -- the AMC, or the company
    category        text,        -- equity / debt / hybrid, or a sector
    exchange        text,

    -- Where the row came from, so a refresh can replace one source without
    -- disturbing the others.
    source          text NOT NULL,
    is_active       boolean NOT NULL DEFAULT true,

    -- Precomputed for matching: lower case, punctuation flattened. Doing this
    -- once here rather than on every keystroke is the difference between a
    -- search that feels instant and one that does not.
    search_text     text NOT NULL,

    updated_at      timestamptz NOT NULL DEFAULT now()
);

-- Trigram matching, so "hdfc flexi" finds "HDFC Flexi Cap Fund" and a typo
-- still lands somewhere sensible. A prefix index alone would fail the moment
-- somebody starts typing from the middle of a name, which they do constantly
-- with fund names that all begin with the same fund house.
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX searchable_instruments_trgm ON searchable_instruments
    USING gin (search_text gin_trgm_ops);

CREATE INDEX searchable_instruments_class ON searchable_instruments (asset_class)
    WHERE is_active;
CREATE UNIQUE INDEX searchable_instruments_isin ON searchable_instruments (isin)
    WHERE isin IS NOT NULL;
CREATE INDEX searchable_instruments_code ON searchable_instruments
    (asset_class, native_code) WHERE native_code IS NOT NULL;

COMMIT;
