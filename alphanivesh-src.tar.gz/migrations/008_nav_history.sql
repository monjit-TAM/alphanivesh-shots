-- 008_nav_history.sql
--
-- Daily prices, so a holding can be valued on a date other than the one the
-- statement happened to carry.
--
-- Without this the platform can only say what something was worth when the
-- registrar last printed it. The timeline draws flat lines between statement
-- dates; returns depend on when a document was generated rather than on what
-- the market did; and there is no way to say how far a holding actually fell,
-- which is what would make a warning about small caps concrete rather than
-- general.
--
-- Only for instruments somebody holds. There are 14,000 schemes in the search
-- master and roughly fifty in anyone's portfolio; fetching thirteen years of
-- daily prices for all of them would be tens of millions of rows nobody reads.

BEGIN;

CREATE TABLE nav_history (
    instrument_id   varchar NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
    as_of           date NOT NULL,
    nav             numeric(20,6) NOT NULL,

    source          text NOT NULL DEFAULT 'mfapi',
    fetched_at      timestamptz NOT NULL DEFAULT now(),

    PRIMARY KEY (instrument_id, as_of)
);

-- Reading is almost always "this instrument, over this period, newest first".
CREATE INDEX nav_history_lookup ON nav_history (instrument_id, as_of DESC);

-- When each instrument's prices were last refreshed, so a nightly job can pick
-- up where it left off rather than refetching everything.
ALTER TABLE instruments
    ADD COLUMN nav_synced_at timestamptz,
    ADD COLUMN nav_earliest date,
    ADD COLUMN nav_latest date;

-- The NAV service also returns a proper scheme category ("Equity Scheme -
-- Flexi Cap Fund"), which is better than the category we currently infer from
-- the scheme name. Kept separately so the inferred one is not silently
-- overwritten and we can tell which is which.
ALTER TABLE instruments
    ADD COLUMN declared_category text,
    ADD COLUMN scheme_type text;

COMMIT;
