-- 009_scheme_constituents.sql
--
-- What each mutual fund actually holds.
--
-- This is what makes overlap a computation rather than an assertion. Without
-- it the honest position is silence: AlphaLensMF's implementation returns a
-- percentage looked up from the fund's category name -- two large-cap funds
-- always score 70% -- having never compared a single holding. A number arrived
-- at that way is worse than no number, because it looks like analysis.
--
-- Sourced from alpha_fundamentals_db on the production box, which collects the
-- monthly portfolio disclosures AMCs are required to publish. Only the latest
-- disclosure for schemes somebody holds: the full table is 1.2 million rows
-- and 293 MB, and overlap only needs what the funds hold now.

BEGIN;

CREATE TABLE scheme_constituents (
    scheme_code     text NOT NULL,
    as_of           date NOT NULL,

    -- The underlying company. ISIN where the disclosure gives one, which is
    -- most of the time; name always.
    isin            text,
    instrument_name text NOT NULL,
    symbol          text,

    -- Share of the fund. This is the number that matters: two funds both
    -- holding a company at half a per cent is not overlap in any sense worth
    -- telling somebody about, and counting shared names rather than shared
    -- weight would say it was.
    weight_pct      numeric(10,6),

    imported_at     timestamptz NOT NULL DEFAULT now(),

    PRIMARY KEY (scheme_code, as_of, instrument_name)
);

CREATE INDEX scheme_constituents_scheme ON scheme_constituents (scheme_code, as_of DESC);
CREATE INDEX scheme_constituents_isin ON scheme_constituents (isin) WHERE isin IS NOT NULL;

COMMIT;
