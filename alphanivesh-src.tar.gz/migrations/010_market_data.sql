-- 010_market_data.sql
--
-- Everything needed to say whether a holding is any good, rather than only
-- what it is worth.
--
-- Copied from alpha_fundamentals_db on the production box, which already
-- collects all of it. Copied rather than queried across the network because
-- these are read on every dashboard load and they change daily at most, and
-- because a service being down should not stop somebody seeing their money.
--
-- Only for instruments somebody holds. The source has 2,329 companies and
-- 8.3 million NAV rows; a few dozen of each are relevant here.

BEGIN;

-- What a company is and what it is worth relative to its earnings.
--
-- Every column here is a published figure or a ratio of two of them. Nothing
-- is scored: "P/E of 34 against a sector median of 22" is a fact the reader
-- can check, where "value score 6.4" is a number they have to take on trust.
CREATE TABLE company_fundamentals (
    symbol              text PRIMARY KEY,
    isin                text,
    company_name        text,

    sector              text,
    industry            text,
    market_cap_category text,        -- LARGE | MID | SMALL | MICRO
    market_cap          numeric(20,2),

    -- Valuation
    pe_ttm              numeric(12,4),
    pb_ratio            numeric(12,4),
    ev_ebitda           numeric(12,4),
    peg_ratio           numeric(12,4),
    earnings_yield      numeric(12,4),
    dividend_yield      numeric(12,4),

    -- Quality
    roe                 numeric(12,4),
    roce                numeric(12,4),
    roa                 numeric(12,4),
    debt_to_equity      numeric(12,4),
    interest_coverage   numeric(12,4),
    current_ratio       numeric(12,4),
    ebitda_margin       numeric(12,4),
    net_margin          numeric(12,4),

    -- Growth
    revenue_growth_yoy  numeric(12,4),
    pat_growth_yoy      numeric(12,4),
    eps_growth_yoy      numeric(12,4),
    fcf_yield           numeric(12,4),

    -- Market
    beta                numeric(12,4),
    eps_ttm             numeric(12,4),
    book_value          numeric(12,4),
    high_52w            numeric(12,2),

    period_end          date,
    imported_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX company_fundamentals_isin ON company_fundamentals (isin) WHERE isin IS NOT NULL;
CREATE INDEX company_fundamentals_sector ON company_fundamentals (sector);

-- How a scheme has actually done, and where it sits among its peers.
--
-- The rolling figures are the ones worth showing. A fund's one-year return
-- says as much about when you looked as about the fund; "the median three-year
-- return across every three-year window was 14%, the worst was -3%, and 87% of
-- windows were positive" describes what holding it has actually been like.
CREATE TABLE scheme_returns (
    scheme_code     text PRIMARY KEY,

    nav_latest      numeric(20,6),
    nav_date        date,

    ret_1m          numeric(12,4),
    ret_3m          numeric(12,4),
    ret_6m          numeric(12,4),
    ret_1y          numeric(12,4),
    cagr_3y         numeric(12,4),
    cagr_5y         numeric(12,4),
    cagr_10y        numeric(12,4),

    -- Rolling three-year windows
    roll3_median    numeric(12,4),
    roll3_p25       numeric(12,4),
    roll3_p75       numeric(12,4),
    roll3_pos_pct   numeric(12,4),
    roll3_worst     numeric(12,4),
    roll3_windows   integer,

    -- Rolling five-year windows
    roll5_median    numeric(12,4),
    roll5_pos_pct   numeric(12,4),
    roll5_worst     numeric(12,4),

    -- Rank within category. This is the comparison a fund investor actually
    -- wants: not "did it beat the Nifty" but "of the 42 funds doing the same
    -- job, where does mine come".
    cat_rank        integer,
    cat_n           integer,

    computed_at     timestamptz,
    imported_at     timestamptz NOT NULL DEFAULT now()
);

-- Index levels, for comparing a portfolio against the market it sits in.
CREATE TABLE benchmark_daily (
    symbol      text NOT NULL,          -- NIFTY | BANKNIFTY | FINNIFTY
    trade_date  date NOT NULL,
    close       numeric(14,4) NOT NULL,
    PRIMARY KEY (symbol, trade_date)
);

CREATE INDEX benchmark_daily_lookup ON benchmark_daily (symbol, trade_date DESC);

-- Daily closes for shares somebody holds, so an equity position can be valued
-- and its drawdown measured the same way a fund's can.
CREATE TABLE equity_prices (
    symbol      text NOT NULL,
    trade_date  date NOT NULL,
    close       numeric(14,4) NOT NULL,
    volume      bigint,
    PRIMARY KEY (symbol, trade_date)
);

CREATE INDEX equity_prices_lookup ON equity_prices (symbol, trade_date DESC);

COMMIT;
