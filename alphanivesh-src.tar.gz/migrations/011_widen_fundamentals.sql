-- 011_widen_fundamentals.sql
--
-- numeric(12,4) was too tight for real data.
--
-- It allows values up to about 100 million, which is fine for a P/E and wrong
-- for several of these columns. Market capitalisation in rupees runs to lakhs
-- of crores. Interest coverage is earnings divided by interest, so a company
-- with almost no debt produces a number in the millions -- correctly, and it
-- still has to be stored.
--
-- Widened rather than clamped: a figure that does not fit is telling us
-- something, and rounding it to fit would hide it.

BEGIN;

ALTER TABLE company_fundamentals
    ALTER COLUMN market_cap        TYPE numeric(24,4),
    ALTER COLUMN pe_ttm            TYPE numeric(20,4),
    ALTER COLUMN pb_ratio          TYPE numeric(20,4),
    ALTER COLUMN ev_ebitda         TYPE numeric(20,4),
    ALTER COLUMN peg_ratio         TYPE numeric(20,4),
    ALTER COLUMN earnings_yield    TYPE numeric(20,4),
    ALTER COLUMN dividend_yield    TYPE numeric(20,4),
    ALTER COLUMN roe               TYPE numeric(20,4),
    ALTER COLUMN roce              TYPE numeric(20,4),
    ALTER COLUMN roa               TYPE numeric(20,4),
    ALTER COLUMN debt_to_equity    TYPE numeric(20,4),
    ALTER COLUMN interest_coverage TYPE numeric(24,4),
    ALTER COLUMN current_ratio     TYPE numeric(20,4),
    ALTER COLUMN ebitda_margin     TYPE numeric(20,4),
    ALTER COLUMN net_margin        TYPE numeric(20,4),
    ALTER COLUMN revenue_growth_yoy TYPE numeric(20,4),
    ALTER COLUMN pat_growth_yoy    TYPE numeric(20,4),
    ALTER COLUMN eps_growth_yoy    TYPE numeric(20,4),
    ALTER COLUMN fcf_yield         TYPE numeric(20,4),
    ALTER COLUMN beta              TYPE numeric(20,4),
    ALTER COLUMN eps_ttm           TYPE numeric(20,4),
    ALTER COLUMN book_value        TYPE numeric(20,4),
    ALTER COLUMN high_52w          TYPE numeric(20,2);

ALTER TABLE scheme_returns
    ALTER COLUMN ret_1m        TYPE numeric(20,4),
    ALTER COLUMN ret_3m        TYPE numeric(20,4),
    ALTER COLUMN ret_6m        TYPE numeric(20,4),
    ALTER COLUMN ret_1y        TYPE numeric(20,4),
    ALTER COLUMN cagr_3y       TYPE numeric(20,4),
    ALTER COLUMN cagr_5y       TYPE numeric(20,4),
    ALTER COLUMN cagr_10y      TYPE numeric(20,4),
    ALTER COLUMN roll3_median  TYPE numeric(20,4),
    ALTER COLUMN roll3_p25     TYPE numeric(20,4),
    ALTER COLUMN roll3_p75     TYPE numeric(20,4),
    ALTER COLUMN roll3_pos_pct TYPE numeric(20,4),
    ALTER COLUMN roll3_worst   TYPE numeric(20,4),
    ALTER COLUMN roll5_median  TYPE numeric(20,4),
    ALTER COLUMN roll5_pos_pct TYPE numeric(20,4),
    ALTER COLUMN roll5_worst   TYPE numeric(20,4);

COMMIT;
