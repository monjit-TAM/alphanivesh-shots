-- 012_quote_source.sql
--
-- A snapshot that came from a live price feed.
--
-- Shares imported from a spreadsheet sit at what somebody paid until something
-- prices them, and a portfolio showing cost as though it were value is wrong by
-- however much the market has moved. DLF bought at 320 trades at 687; the
-- dashboard was reporting no gain at all.
--
-- Kept as its own source rather than reusing `manual`, because the two mean
-- different things: one is a figure a person typed, the other is a price a
-- feed quoted, and `v_current_holdings` ranks by source when two snapshots
-- share a date.
--
-- The view needs no change. It orders by `as_of DESC` first, so a price dated
-- today already beats a statement dated March. Where a statement arrives on the
-- same day it wins on source rank, which is right: the registrar's own
-- valuation of a holding is better evidence than our quote of it.

BEGIN;

ALTER TYPE holding_source ADD VALUE IF NOT EXISTS 'quote';

COMMIT;
