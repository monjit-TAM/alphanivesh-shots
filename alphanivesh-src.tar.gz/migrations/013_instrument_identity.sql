-- 013_instrument_identity.sql
--
-- Every way an instrument can be named, in one place, with a stated order of
-- trust.
--
-- A holding arrives identified by whatever its source happened to carry: a CAS
-- statement gives an ISIN, a broker's spreadsheet gives a trading symbol, a
-- contract note might give either, and somebody typing by hand gives a name.
-- Each of those can be resolved, and each can be resolved wrongly.
--
--   ISIN     highest. Globally unique, issued once, never reused.
--   token    high. The broker's own identifier within their universe.
--   symbol   medium. Unique on an exchange today, but reassigned over time --
--            PVR became PVRINOX, KALPATPOWR became KPIL -- and the same string
--            can mean different companies on NSE and BSE.
--   name     lowest. Never authoritative. "Tata Motors" matched a spin-off
--            because the parent was absent from the list.
--
-- The rule that matters is at the bottom: when two identifiers disagree, this
-- refuses rather than choosing. A resolver that picks is a resolver that
-- silently attaches somebody's money to the wrong company.

BEGIN;

CREATE TABLE instrument_identity (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),

    isin            text,
    -- The broker's numeric id. Kite's instrument_token; others may differ,
    -- which is why the source is recorded beside it.
    token           bigint,
    token_source    text,

    nse_symbol      text,
    bse_code        text,
    company_name    text NOT NULL,

    sector          text,
    industry        text,
    market_cap_cr   numeric(20,4),

    -- Where this row came from and when, so a disagreement between two sources
    -- can be traced rather than argued about.
    source          text NOT NULL,
    is_active       boolean NOT NULL DEFAULT true,
    updated_at      timestamptz NOT NULL DEFAULT now(),

    -- Flattened name for matching, computed once.
    search_text     text
);

-- An ISIN identifies one security. Two active rows sharing one is a conflict
-- worth failing on rather than resolving.
CREATE UNIQUE INDEX instrument_identity_isin
    ON instrument_identity (isin) WHERE isin IS NOT NULL AND is_active;

CREATE INDEX instrument_identity_nse ON instrument_identity (nse_symbol)
    WHERE nse_symbol IS NOT NULL AND is_active;
CREATE INDEX instrument_identity_bse ON instrument_identity (bse_code)
    WHERE bse_code IS NOT NULL AND is_active;
CREATE INDEX instrument_identity_token ON instrument_identity (token)
    WHERE token IS NOT NULL AND is_active;
CREATE INDEX instrument_identity_search ON instrument_identity
    USING gin (search_text gin_trgm_ops);

-- Where two sources disagree about what an identifier means, both rows are
-- kept and the conflict is recorded. Nothing resolves through a conflicted
-- identifier until somebody has looked.
CREATE TABLE identity_conflicts (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    identifier_kind text NOT NULL,        -- isin | token | nse_symbol | bse_code
    identifier      text NOT NULL,
    claims          jsonb NOT NULL,       -- what each source says it is
    noticed_at      timestamptz NOT NULL DEFAULT now(),
    resolved_at     timestamptz,
    resolution      text
);

CREATE INDEX identity_conflicts_open ON identity_conflicts (identifier_kind, identifier)
    WHERE resolved_at IS NULL;

COMMIT;
