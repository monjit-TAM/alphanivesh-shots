-- 014_target_allocation.sql
--
-- What somebody meant their portfolio to look like.
--
-- Drift is only measurable against an intention. Without one, "96% in equity"
-- is a fact with no verdict attached: it is reckless for somebody who wanted
-- 60/40 and exactly right for somebody who wanted to be fully invested.
--
-- Stored as a set of rows rather than a jsonb blob because it is queried
-- alongside the holdings, and because a target that does not sum to a hundred
-- is a mistake worth catching in a constraint rather than in a reader's head.

BEGIN;

CREATE TABLE target_allocations (
    investor_id     varchar NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    asset_class     asset_class NOT NULL,
    target_pct      numeric(6,2) NOT NULL CHECK (target_pct >= 0 AND target_pct <= 100),

    -- How far it can drift before it is worth saying anything. Five points
    -- either way by default: rebalancing on every small move costs more in
    -- tax and brokerage than the drift costs in risk.
    tolerance_pct   numeric(5,2) NOT NULL DEFAULT 5,

    -- When it was set, so a target from three years ago can be questioned.
    set_at          timestamptz NOT NULL DEFAULT now(),
    note            text,

    PRIMARY KEY (investor_id, asset_class)
);

COMMIT;
