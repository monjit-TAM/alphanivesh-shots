-- 015_investment_style.sql
--
-- Which of the three kinds of investor somebody is.
--
-- The same holding is a sell through a value lens and a buy through a growth
-- one. Both readings are coherent, and showing only one makes the tool wrong
-- for half the people using it -- a growth investor shown a Sell on a company
-- they bought for its growth will disbelieve everything else on the page.
--
-- So all three verdicts are always shown. This decides which is emphasised.
--
-- Nullable on purpose. Most people cannot name their style, which is not
-- ignorance -- the vocabulary belongs to the industry rather than to them. An
-- unanswered column means we show the three evenly and offer an explanation,
-- which is better than guessing and better than nagging.

BEGIN;

ALTER TABLE investor_profiles
    ADD COLUMN IF NOT EXISTS investment_style text
        CHECK (investment_style IN ('value', 'growth', 'quantamental')),
    -- Whether they told us or we inferred it, because a guess and an answer
    -- deserve different confidence downstream.
    ADD COLUMN IF NOT EXISTS style_stated_by text
        CHECK (style_stated_by IN ('investor', 'inferred'));

COMMIT;
