-- 016_holdings_sum_folios.sql
--
-- A fund held in two folios is one holding of the combined size.
--
-- v_current_holdings used DISTINCT ON (investor_id, instrument_id), which
-- picks one row and discards the rest. Somebody holding ICICI Business Cycle
-- in two folios -- 21,536 units worth 4.98 lakh between them -- saw only the
-- larger folio, and the smaller one vanished from their net worth entirely.
--
-- Migration 002 changed the deduplication from per-account to per-investor to
-- stop the same fund appearing twice in a list. That was the right fix for the
-- list and the wrong one for the arithmetic: the duplicate rows should have
-- been combined rather than dropped.
--
-- So: the latest snapshot per folio, then summed per instrument. Quantities
-- and values add; the account shown is whichever folio holds most of it, since
-- a single row can only name one.

BEGIN;

DROP VIEW IF EXISTS v_current_holdings;

CREATE VIEW v_current_holdings AS
WITH latest_per_folio AS (
    SELECT DISTINCT ON (h.investor_id, h.account_id, h.instrument_id)
           h.id, h.investor_id, h.account_id, h.instrument_id, h.as_of,
           h.source, h.source_document_id, h.quantity, h.avg_cost, h.price,
           h.current_value, h.invested_value, h.attributes, h.created_at
    FROM holding_snapshots h
    ORDER BY h.investor_id, h.account_id, h.instrument_id, h.as_of DESC,
             (CASE h.source
                WHEN 'quote' THEN 0
                WHEN 'casparser_cdsl' THEN 1
                WHEN 'casparser_nsdl' THEN 2
                WHEN 'casparser_cams' THEN 3
                WHEN 'casparser_kfintech' THEN 4
                WHEN 'account_aggregator' THEN 5
                WHEN 'broker_feed' THEN 6
                WHEN 'manual' THEN 7
                ELSE 8 END),
             h.created_at DESC
),
-- Which folio holds most of it, so the row can name one account without the
-- choice being arbitrary.
principal AS (
    SELECT DISTINCT ON (investor_id, instrument_id)
           investor_id, instrument_id, id, account_id, as_of, source,
           source_document_id, avg_cost, price, attributes, created_at
    FROM latest_per_folio
    ORDER BY investor_id, instrument_id, current_value DESC NULLS LAST
)
SELECT p.id,
       p.investor_id,
       p.account_id,
       p.instrument_id,
       p.as_of,
       p.source,
       p.source_document_id,
       t.quantity,
       p.avg_cost,
       p.price,
       t.current_value,
       t.invested_value,
       p.attributes,
       p.created_at,
       i.asset_class,
       i.name AS instrument_name,
       i.isin,
       i.symbol
FROM (
    SELECT investor_id, instrument_id,
           sum(quantity) AS quantity,
           sum(current_value) AS current_value,
           sum(invested_value) AS invested_value
    FROM latest_per_folio
    GROUP BY investor_id, instrument_id
) t
JOIN principal p ON p.investor_id = t.investor_id
                AND p.instrument_id = t.instrument_id
JOIN instruments i ON i.id::text = p.instrument_id::text;

COMMIT;
