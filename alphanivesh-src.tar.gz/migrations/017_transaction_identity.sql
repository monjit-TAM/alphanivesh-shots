-- 017_transaction_identity.sql
--
-- A transaction is identified by what it is, not by where it came from.
--
-- Thirty-two portfolios were migrated from AlphaLensMF for one investor --
-- somebody had re-run an analysis thirty-two times and each run saved a
-- portfolio record. The migration treated each as a separate statement, so the
-- same thirty-nine purchases arrived thirty-two times: 1,341 rows carrying 102
-- distinct facts.
--
-- Every guard was defeated the same way. `payload_sha256` differed because the
-- portfolio id was in the payload. `external_ref` differed because it was
-- `alphalensmf:txn:{row_id}` and each copy had its own row. Both keys describe
-- the source rather than the event, and a source can hand you the same event
-- under a new name any number of times.
--
-- So: a key on the transaction itself. The same investor buying the same units
-- of the same fund on the same day for the same amount is one purchase however
-- many systems report it.
--
-- The account is included because somebody genuinely can run two folios in one
-- scheme, and a contribution to each on the same day for the same amount is two
-- events rather than a duplicate.

BEGIN;

-- Keep the earliest row for each fact and drop the rest.
WITH ranked AS (
    SELECT id,
           row_number() OVER (
               PARTITION BY investor_id, account_id, instrument_id, txn_date,
                            txn_type, amount, coalesce(quantity, -1)
               ORDER BY created_at, id
           ) AS copy
    FROM canonical_transactions
)
DELETE FROM canonical_transactions
WHERE id IN (SELECT id FROM ranked WHERE copy > 1);

CREATE UNIQUE INDEX canonical_transactions_fact_key
    ON canonical_transactions (investor_id, account_id, instrument_id, txn_date,
                               txn_type, amount, coalesce(quantity, -1));

COMMIT;
