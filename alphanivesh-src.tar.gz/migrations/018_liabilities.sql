-- 018_liabilities.sql
--
-- What somebody owes.
--
-- Missing until now, and its absence is not neutral. Risk capacity is how much
-- somebody can afford to lose, and debt is the thing most likely to force a
-- sale at a bad moment: an EMI costs the same amount whatever the market did
-- that month.
--
-- A portfolio analysed without knowing the liabilities against it is half a
-- balance sheet, and the half that is missing is the one that creates urgency.
--
-- Nullable throughout, and the absence of rows means "we do not know" rather
-- than "there is none". Those are different, and the risk engine reports them
-- differently: no debt is a strong position, no information about debt is a
-- hole in the middle of the calculation.

BEGIN;

CREATE TABLE IF NOT EXISTS liabilities (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,

    kind            text NOT NULL CHECK (kind IN (
                        'home_loan', 'car_loan', 'personal_loan',
                        'education_loan', 'credit_card', 'gold_loan',
                        'loan_against_securities', 'business_loan', 'other')),
    lender          text,

    outstanding     numeric(20,2),
    -- What it costs a year. The rate matters more than the balance for
    -- deciding what to pay off first: a credit card at 40% is a different
    -- problem from a home loan at 8.5%, and the same rupee against either
    -- has very different value.
    rate_pct        numeric(6,2),
    monthly_emi     numeric(20,2),
    ends_on         date,

    -- Whether it bought something that grows. A home loan sits against an
    -- appreciating asset; a personal loan against a holiday does not, and
    -- "total debt" hides the difference.
    secured_against text,

    notes           text,
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS liabilities_investor_idx
    ON liabilities (investor_id);

COMMIT;
