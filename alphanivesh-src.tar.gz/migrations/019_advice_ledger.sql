-- 019_advice_ledger.sql
--
-- Everything this platform has ever told anybody.
--
-- Not an Ariv table. Under the licence this operates through, we are answerable
-- for every suggestion, analysis and answer put in front of an investor -- and
-- an assistant's reply is one kind of output among several. The decision
-- engine's actions, the findings, the guide, the buy plan and the holding
-- verdicts are all advice, all shown, and none of them was being kept.
--
-- The gap that makes this urgent: the platform computes on request and stores
-- nothing. Asked what an investor was told on a date last March, we could
-- recompute from today's prices and get a different answer -- which is worse
-- than having no answer, because it looks like one.
--
-- So: what was said, when, to whom, on what data, by which version of which
-- reasoning. Chronological, immutable, and complete enough that an answer can
-- be reconstructed years later rather than approximated.
--
-- Retention: five years minimum, seven to be safe. Nothing is deleted without
-- compliance sign-off, and pruning happens by export rather than by DELETE.

BEGIN;

CREATE TABLE IF NOT EXISTS advice_ledger (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,

    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    -- RESTRICT, not CASCADE. A deleted investor must not take the record of
    -- what they were told with them. Where a deletion request has to be
    -- honoured, the identifying fields are redacted and the advice record
    -- stays -- which is the only way to satisfy both obligations.

    -- WHEN. Chronology is the point: an answer is only defensible against the
    -- state of the world when it was given.
    shown_at        timestamptz NOT NULL DEFAULT now(),
    data_as_of      date NOT NULL,

    -- WHAT KIND. Every surface that puts a claim in front of somebody.
    kind            text NOT NULL CHECK (kind IN (
                        'decision',      -- the tiered actions
                        'finding',       -- a single diagnostic
                        'guide',         -- the narrative account
                        'buy_plan',      -- what to sell, what to buy
                        'holding_call',  -- a verdict on one holding
                        'fund_fit',      -- what a fund demands
                        'ariv_answer',   -- an assistant reply
                        'ariv_refusal',  -- and a decline, which is also a record
                        'notification'   -- anything pushed rather than pulled
                    )),

    -- WHAT WAS SAID. The rendered output, exactly as the investor saw it.
    said            jsonb NOT NULL,

    -- ON WHAT BASIS. The inputs that produced it: holdings and their values,
    -- the profile figures, the risk ceiling, the market readings. Without this
    -- the record shows the conclusion and not the reasoning, and the question
    -- asked years later is always about the reasoning.
    basis           jsonb NOT NULL,

    -- BY WHAT. Which reasoning, which thresholds, which model.
    engine_version  text NOT NULL,
    ruleset_version text,
    model           text,
    prompt_version  text,

    -- HOW IT WAS DELIVERED, since a pushed notification and a page somebody
    -- chose to open are different acts.
    surface         text,            -- dashboard, advice_page, api, email, ariv
    session_id      text,

    -- FOR AN API CALLER, which product asked. The engine is shared, and
    -- "who did we tell" includes products acting on our behalf.
    caller          text,

    -- WHETHER IT WAS ACTED ON, where we can tell. Not required, and valuable:
    -- advice followed and advice ignored are different histories.
    outcome         text,
    outcome_at      timestamptz,

    -- Corrections append rather than overwrite. An audit trail somebody can
    -- edit is not an audit trail.
    corrects        text REFERENCES advice_ledger(id),
    correction_note text,

    created_at      timestamptz NOT NULL DEFAULT now()
);

-- The three questions this table exists to answer, each with its index.
--
--   what was this investor told, in order          -> investor + shown_at
--   what did we say on this date, to anybody       -> shown_at
--   what did this session produce                  -> session
CREATE INDEX IF NOT EXISTS advice_investor_idx
    ON advice_ledger (investor_id, shown_at DESC);
CREATE INDEX IF NOT EXISTS advice_when_idx
    ON advice_ledger (shown_at);
CREATE INDEX IF NOT EXISTS advice_kind_idx
    ON advice_ledger (kind, shown_at DESC);
CREATE INDEX IF NOT EXISTS advice_session_idx
    ON advice_ledger (session_id) WHERE session_id IS NOT NULL;

-- Append-only, enforced rather than intended. A trigger is not a security
-- boundary -- somebody with the right grants can drop it -- but it stops the
-- accidental UPDATE that would otherwise never be noticed.
CREATE OR REPLACE FUNCTION advice_ledger_is_append_only()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION
        'advice_ledger is append-only. To correct a record, insert a new row '
        'with corrects set to the original id.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS advice_ledger_no_update ON advice_ledger;
CREATE TRIGGER advice_ledger_no_update
    BEFORE UPDATE OR DELETE ON advice_ledger
    FOR EACH ROW EXECUTE FUNCTION advice_ledger_is_append_only();

COMMENT ON TABLE advice_ledger IS
    'Every suggestion, analysis and answer shown to an investor. Retain five '
    'years minimum, seven preferred. Append-only: corrections insert a new row '
    'referencing the original. Never delete without compliance sign-off; prune '
    'by export.';

COMMIT;
