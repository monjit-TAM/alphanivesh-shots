-- 020_shares.sql
--
-- Links that show somebody's portfolio to somebody else.
--
-- The convenient version of this is a permanent URL that anybody holding it
-- can open. It is also the version that appears in a news story: a complete
-- financial position, one forwarded message from anywhere, with no way to know
-- who has seen it or to take it back.
--
-- So every link here expires, can be revoked, records each time it is opened,
-- and says on the page what it is showing and until when. Seven days by
-- default, thirty at most, because a link that outlives the reason it was made
-- is a link nobody remembers creating.
--
-- The token is stored hashed. A leaked database should not hand somebody every
-- live share link, and there is no reason to keep the plaintext: it is shown
-- once at creation and never needed again.

BEGIN;

CREATE TABLE IF NOT EXISTS shared_views (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    created_by      text REFERENCES users(id) ON DELETE SET NULL,

    -- sha256 of the token. The token itself is shown once and never stored.
    token_hash      text NOT NULL UNIQUE,

    -- What the recipient may see. Deliberately not "everything": somebody
    -- sharing their advice with a spouse and somebody sharing holdings with an
    -- accountant want different things, and defaulting to all of it means the
    -- narrower case cannot be expressed.
    scope           text NOT NULL DEFAULT 'advice'
                    CHECK (scope IN ('advice', 'holdings', 'both')),

    label           text,
    expires_at      timestamptz NOT NULL,
    revoked_at      timestamptz,

    -- Every open, so the person who shared it can see whether it was used and
    -- how often. A share nobody can audit is a share nobody should make.
    opened_count    integer NOT NULL DEFAULT 0,
    last_opened_at  timestamptz,

    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS shared_views_investor_idx
    ON shared_views (investor_id, created_at DESC);
CREATE INDEX IF NOT EXISTS shared_views_live_idx
    ON shared_views (expires_at) WHERE revoked_at IS NULL;

COMMENT ON TABLE shared_views IS
    'Time-limited read-only links to a portfolio. Tokens stored hashed; the '
    'plaintext is shown once at creation. Every open is counted.';

COMMIT;
