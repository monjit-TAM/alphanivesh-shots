-- 021_ariv_usage.sql
--
-- What Ariv costs, per investor per month.
--
-- Generated answers cost money and deterministic ones do not, so the meter
-- only runs on the former. That is the whole design: routing most questions
-- away from the model is the cost control, and this is the backstop for what
-- is left.
--
-- Recorded per exchange rather than estimated, because token counts vary with
-- how much context an answer needs and a flat assumption would be wrong in
-- both directions. The API returns the actual usage; this stores it.
--
-- Separate from advice_ledger deliberately. That table is append-only and
-- immutable by trigger, which is right for a record of what was said and wrong
-- for something that has to be summed and checked on every request.

BEGIN;

CREATE TABLE IF NOT EXISTS ariv_usage (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
    ledger_id       text REFERENCES advice_ledger(id),

    asked_at        timestamptz NOT NULL DEFAULT now(),
    -- The month this counts against, so the sum is an index lookup rather
    -- than a date function over the whole table.
    period          text NOT NULL,          -- 'YYYY-MM'

    route           text NOT NULL,          -- deterministic | generated | refused
    model           text,
    tokens_in       integer NOT NULL DEFAULT 0,
    tokens_out      integer NOT NULL DEFAULT 0,

    -- What it cost, in paise. Integer money, because this is summed and
    -- compared against a budget and floating point has no business there.
    cost_paise      integer NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS ariv_usage_period_idx
    ON ariv_usage (investor_id, period);
CREATE INDEX IF NOT EXISTS ariv_usage_when_idx
    ON ariv_usage (asked_at);

COMMENT ON TABLE ariv_usage IS
    'Per-exchange cost of Ariv. Only generated answers cost anything; '
    'deterministic ones are recorded at zero so the ratio is visible.';

COMMIT;
