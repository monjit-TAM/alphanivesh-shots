-- 022_protection.sql
--
-- Cover is not wealth.
--
-- A term policy with a sum assured of three and a half crore is worth nothing
-- while somebody is alive. It is a promise that pays out if they are not, and
-- counting it as an asset does three wrong things at once: it inflates net
-- worth by the amount of the promise, it makes every allocation percentage
-- wrong, and -- on a real portfolio -- it produced a rebalance instruction to
-- sell the family's protection.
--
-- So protection lives here rather than among the holdings. It is measured
-- against what somebody would need, which is the only question worth asking
-- about it, and it never appears in a total.
--
-- Endowment and ULIP policies are the awkward case: they have a surrender
-- value as well as a cover amount. Both are recorded, and only the surrender
-- value counts as wealth.

BEGIN;

CREATE TABLE IF NOT EXISTS protection (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE CASCADE,

    kind            text NOT NULL CHECK (kind IN (
                        'term_life',      -- pure cover, no value
                        'health',         -- reimburses, no value
                        'critical_illness',
                        'personal_accident',
                        'endowment',      -- cover plus a surrender value
                        'ulip',           -- cover plus a market-linked value
                        'other')),

    insurer         text,
    policy_ref      text,

    -- What it pays out. Never counted as wealth.
    cover_amount    numeric(18,2),

    -- What it is worth today if surrendered. Endowment and ULIP only; null
    -- for term and health, which have none. This is the part that counts.
    surrender_value numeric(18,2),

    annual_premium  numeric(18,2),
    renews_on       date,
    covers          text,               -- 'self', 'family', 'self and spouse'
    notes           text,

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS protection_investor_idx
    ON protection (investor_id);

COMMENT ON TABLE protection IS
    'Insurance cover. cover_amount is a payout and is never wealth; '
    'surrender_value is, and exists only for endowment and ULIP policies.';

COMMIT;
