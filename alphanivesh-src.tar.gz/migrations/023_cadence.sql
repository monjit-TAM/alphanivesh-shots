-- 023_cadence.sql
--
-- How often somebody wants to hear from us.
--
-- Asked once, stored, respected. The alternative is deciding on their behalf,
-- and a platform that decides how often to contact people usually decides
-- "often" -- which works for a quarter and then gets muted, at which point the
-- one message that mattered goes unread with the rest.
--
-- Four choices, and the review goes out on that rhythm.
--
-- Urgent things do not wait for it. Somebody who chose an annual review still
-- wants to know their standing instruction stopped, or that the tax allowance
-- expires this month. The cadence governs the review; it does not govern
-- whether we ever speak.
--
-- And `paused_until` exists because "not now" is a reasonable answer that is
-- not "never", and a platform without a way to say it gets unsubscribed from
-- instead.

BEGIN;

CREATE TABLE IF NOT EXISTS contact_preference (
    investor_id     text PRIMARY KEY REFERENCES investors(id) ON DELETE CASCADE,

    cadence         text NOT NULL DEFAULT 'quarterly'
                    CHECK (cadence IN ('monthly', 'quarterly',
                                       'half_yearly', 'annually')),

    -- Urgent things regardless. Somebody can turn this off; most should not,
    -- and the interface says why.
    urgent_anyway   boolean NOT NULL DEFAULT true,

    -- Where. Email is the default because it is the one we can be sure of.
    by_email        boolean NOT NULL DEFAULT true,
    by_whatsapp     boolean NOT NULL DEFAULT false,
    by_push         boolean NOT NULL DEFAULT false,

    -- When the last review actually went, so the next is due from then rather
    -- than from a fixed calendar -- somebody who joined in February should not
    -- get their first quarterly review three days later.
    last_review_on  date,
    paused_until    date,

    asked_on        timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE contact_preference IS
    'How often each investor wants a review, and by what route. Urgent items '
    'are sent regardless of cadence unless urgent_anyway is false.';

COMMIT;
