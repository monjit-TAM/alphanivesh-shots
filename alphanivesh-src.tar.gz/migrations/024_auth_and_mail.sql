-- 024_auth_and_mail.sql
--
-- What left, and the tokens that let somebody back in.
--
-- Three tables.
--
-- `mail_log` records that a message was attempted, to whom, of what kind, and
-- whether it left. Not the content -- that is in advice_ledger, which is the
-- record of what somebody was shown. This is the record of what was sent,
-- which is a different question and the one that matters when an investor says
-- they never heard from us.
--
-- `auth_token` covers the flows that need a secret in a link: verifying an
-- address, resetting a password. Single use, short lived, and stored hashed --
-- a reset token in plaintext in a database is a password in plaintext in a
-- database wearing a hat.
--
-- `identity` is for signing in with Google or another provider without a
-- password. Kept separate from users so somebody can have both, and so
-- removing a provider does not remove the account.

BEGIN;

CREATE TABLE IF NOT EXISTS mail_log (
    id           bigserial PRIMARY KEY,
    investor_id  text REFERENCES investors(id) ON DELETE SET NULL,
    to_address   text NOT NULL,
    kind         text NOT NULL,
    subject      text,
    sent         boolean NOT NULL DEFAULT false,
    detail       text,
    at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS mail_log_to_idx ON mail_log (to_address, at DESC);
CREATE INDEX IF NOT EXISTS mail_log_kind_idx ON mail_log (kind, at DESC);

CREATE TABLE IF NOT EXISTS auth_token (
    id          text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id     text NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    purpose     text NOT NULL CHECK (purpose IN ('verify_email',
                                                 'reset_password')),
    -- SHA-256 of the token that went in the link. The link is the only place
    -- the plaintext ever exists.
    token_hash  text NOT NULL UNIQUE,

    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_token_user_idx ON auth_token (user_id, purpose);
CREATE INDEX IF NOT EXISTS auth_token_expiry_idx ON auth_token (expires_at);

CREATE TABLE IF NOT EXISTS identity (
    id           text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id      text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider     text NOT NULL,                -- 'google', 'apple', ...
    subject      text NOT NULL,                -- the provider's own id
    email        text,
    created_at   timestamptz NOT NULL DEFAULT now(),
    last_used_at timestamptz,
    UNIQUE (provider, subject)
);
CREATE INDEX IF NOT EXISTS identity_user_idx ON identity (user_id);

-- Whether the address has been proved. A reset sent to an unverified address
-- is a way to take over an account.
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS welcomed_at timestamptz;

COMMENT ON TABLE mail_log IS
    'What was sent and whether it left. Content lives in advice_ledger.';
COMMENT ON TABLE auth_token IS
    'Single-use, short-lived, hashed. The plaintext exists only in the link.';

COMMIT;
