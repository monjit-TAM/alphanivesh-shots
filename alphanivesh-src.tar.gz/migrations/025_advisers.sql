-- 025_advisers.sql
--
-- Under whose licence.
--
-- We are a technology platform. Until our own registration comes through, the
-- adviser of record on anything an investor acts upon is the registered
-- adviser whose relationship they are in -- in practice a broker on the
-- Kambala platform using their own RIA licence, with our reasoning behind it.
--
-- That arrangement holds only if the record says so. A ledger that can prove
-- what was advised and when, but not under whose registration, answers the
-- second question a regulator asks and not the first. And the answer has to be
-- recorded at the moment the advice is given, because reconstructing it later
-- from who the investor happened to be with is exactly the kind of
-- after-the-fact attribution that does not survive scrutiny.
--
-- Three things here.
--
-- `adviser` is the registered firm: who they are, their registration number,
-- and the dates it was valid between. Dates because a recommendation made in
-- March under a registration that lapsed in June was validly made, and the
-- record has to be able to say that.
--
-- `advisory_mandate` is the relationship: this investor, with this adviser,
-- between these dates. An investor can move; the advice given before they
-- moved stays attributed to who gave it.
--
-- And `advice_ledger.adviser_id`, so every row carries it.

BEGIN;

CREATE TABLE IF NOT EXISTS adviser (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,

    name            text NOT NULL,
    kind            text NOT NULL DEFAULT 'ria'
                    CHECK (kind IN ('ria',        -- registered investment adviser
                                    'ra',         -- research analyst
                                    'broker',     -- stock broker, execution only
                                    'platform')), -- us, before registration

    -- The registration itself. Null for a platform entry, which is the point:
    -- a row with no number cannot be an adviser of record, and the constraint
    -- below says so rather than leaving it to whoever writes the next query.
    registration_no text,
    registered_from date,
    registered_to   date,

    -- Where execution goes, when there is any.
    venue           text,                      -- 'kambala', 'bse_star', ...
    contact         text,
    notes           text,

    active          boolean NOT NULL DEFAULT true,
    created_at      timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT registered_advisers_have_a_number CHECK (
        kind = 'platform' OR registration_no IS NOT NULL)
);

CREATE UNIQUE INDEX IF NOT EXISTS adviser_registration_idx
    ON adviser (registration_no) WHERE registration_no IS NOT NULL;

-- Who the investor's adviser is, and since when.
CREATE TABLE IF NOT EXISTS advisory_mandate (
    id            text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id   text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    adviser_id    text NOT NULL REFERENCES adviser(id) ON DELETE RESTRICT,

    began_on      date NOT NULL DEFAULT current_date,
    ended_on      date,

    -- What the investor agreed to, and when. An execution instruction needs
    -- this to exist; without it the platform is giving advice into a
    -- relationship nobody has recorded.
    agreed_at     timestamptz,
    agreement_ref text,

    created_at    timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT mandate_dates_make_sense CHECK (ended_on IS NULL
                                               OR ended_on >= began_on)
);

CREATE INDEX IF NOT EXISTS mandate_investor_idx
    ON advisory_mandate (investor_id, began_on DESC);

-- One current mandate per investor. Two would make "who advised this" a
-- question with two answers, which is the thing this migration exists to
-- prevent.
CREATE UNIQUE INDEX IF NOT EXISTS mandate_one_current_idx
    ON advisory_mandate (investor_id) WHERE ended_on IS NULL;

-- Every row of advice carries who it was given under.
ALTER TABLE advice_ledger
    ADD COLUMN IF NOT EXISTS adviser_id text REFERENCES adviser(id);

CREATE INDEX IF NOT EXISTS ledger_adviser_idx
    ON advice_ledger (adviser_id, shown_at DESC);

COMMENT ON TABLE adviser IS
    'Registered firms. A row without a registration number can only be kind '
    'platform, and cannot be an adviser of record.';
COMMENT ON TABLE advisory_mandate IS
    'Which adviser an investor is with, and between when. One current mandate '
    'each, so "who advised this" has one answer.';
COMMENT ON COLUMN advice_ledger.adviser_id IS
    'Whose registration this was given under, recorded when it was given '
    'rather than inferred afterwards.';

COMMIT;
