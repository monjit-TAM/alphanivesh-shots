-- 026_adviser_edits.sql
--
-- The adviser's judgement, recorded as theirs.
--
-- An adviser who can only pass through what the engine produced is not
-- advising, they are reselling software output -- and that is precisely the
-- thing that does not hold up when somebody asks who made the recommendation.
-- So they can change it, hold it back, or add their own.
--
-- The condition is that the record keeps both. A ledger showing only the final
-- text would say the engine recommended something it never did, and an adviser
-- who overruled the engine deserves the credit for having done so as much as
-- the responsibility.
--
-- **Suppression is recorded, not erased.** "The engine flagged this and the
-- adviser judged it not worth raising" is a fact worth keeping, and it is the
-- fact most likely to be asked about later. A deleted row would leave the
-- record saying the engine never noticed.
--
-- Overrides are per action per day. Advice is recomputed each morning against
-- that morning's prices, so an edit made yesterday does not silently apply to
-- a different recommendation today -- it applies while the same thing is still
-- being said, and lapses when it is not.

BEGIN;

CREATE TABLE IF NOT EXISTS advice_override (
    id            text PRIMARY KEY DEFAULT gen_random_uuid()::text,

    investor_id   text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    adviser_id    text REFERENCES adviser(id),

    -- Which recommendation. The engine's own code, plus a fingerprint of what
    -- it said, so an override stops applying when the underlying advice
    -- changes rather than attaching itself to whatever now carries that code.
    action_code   text NOT NULL,
    said_digest   text NOT NULL,

    what          text NOT NULL CHECK (what IN ('edited', 'suppressed',
                                                'added')),

    -- What the engine produced, kept verbatim. Null where the adviser added
    -- something the engine never said.
    engine_said   jsonb,
    -- What the investor was shown instead. Null for a suppression.
    adviser_said  jsonb,

    -- Why. Not optional: an unexplained override is the one a regulator asks
    -- about, and the answer should already be written down.
    because       text NOT NULL,

    by_user_id    text REFERENCES users(id),
    at            timestamptz NOT NULL DEFAULT now(),

    -- Overrides lapse. Advice is recomputed daily and an edit made against
    -- Monday's numbers should not silently govern Friday's.
    applies_until date,
    withdrawn_at  timestamptz
);

CREATE INDEX IF NOT EXISTS override_live_idx
    ON advice_override (investor_id, action_code)
    WHERE withdrawn_at IS NULL;
CREATE INDEX IF NOT EXISTS override_when_idx ON advice_override (at DESC);

-- What was shown, and whether it was acted on. Yesterday's unexecuted advice
-- has to be comparable with today's, or "we said this yesterday and it still
-- stands" cannot be said at all.
CREATE TABLE IF NOT EXISTS advice_shown (
    id            text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id   text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    ledger_id     text REFERENCES advice_ledger(id),

    on_date       date NOT NULL DEFAULT current_date,
    action_code   text NOT NULL,
    said_digest   text NOT NULL,
    headline      text,

    -- Set when a later day's reconciliation finds it done, or when an
    -- execution confirms it.
    acted_on      timestamptz,
    lapsed_on     date,
    lapsed_why    text,

    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE (investor_id, on_date, action_code)
);

CREATE INDEX IF NOT EXISTS shown_open_idx
    ON advice_shown (investor_id, on_date DESC)
    WHERE acted_on IS NULL AND lapsed_on IS NULL;

COMMENT ON TABLE advice_override IS
    'Where the adviser changed, withheld or added to what the engine said. '
    'Both versions kept: a record showing only the final text would say the '
    'engine recommended something it never did.';
COMMENT ON TABLE advice_shown IS
    'What was put in front of an investor on a date, so today can be compared '
    'with yesterday and unacted advice can be told from advice that lapsed.';

COMMIT;
