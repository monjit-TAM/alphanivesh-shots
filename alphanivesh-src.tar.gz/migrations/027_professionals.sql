-- 027_professionals.sql
--
-- What somebody is registered as, and what that lets them do.
--
-- An RIA may advise for a fee. An MFD may not advise at all -- they distribute
-- funds and earn commission, and SEBI is explicit that the two are separate
-- activities. Giving both the same rights would help an MFD do something they
-- are not registered for, and the ledger would record it, which makes it worse
-- rather than better.
--
-- So the registration decides the rights, and the registration has to be
-- evidenced before any of them are granted:
--
--   RIA   advises. Edits, suppresses and adds to what the engine produced,
--         and is the adviser of record on anything their client acts upon.
--   RA    research analyst. Publishes views; does not advise a specific
--         person on their specific portfolio.
--   MFD   distributes. Sees their clients and what the engine produced,
--         transacts in funds, and does not touch the advice. For their
--         clients this platform is information rather than advice, and the
--         page says so.
--
-- The certificate is uploaded and checked by a person before anything is
-- switched on. Self-declaration would mean the first thing this platform knows
-- about somebody's authority is their own claim to it.

BEGIN;

CREATE TABLE IF NOT EXISTS professional (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id         text NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,

    kind            text NOT NULL CHECK (kind IN ('ria', 'ra', 'mfd')),

    firm_name       text,
    registration_no text NOT NULL,
    registered_from date,
    registered_to   date,

    -- ARN for a distributor, EUIN where they have one. Separate columns
    -- because they are separate numbers and conflating them is how the wrong
    -- one ends up on a form.
    arn             text,
    euin            text,

    -- The evidence, and who looked at it. Nothing is granted on a claim.
    certificate_path text,
    certificate_name text,
    uploaded_at      timestamptz,

    checked_at       timestamptz,
    checked_by       text REFERENCES users(id),
    checked_note     text,

    status          text NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending',    -- uploaded, not yet seen
                                      'active',     -- checked, rights granted
                                      'refused',    -- checked, not granted
                                      'lapsed')),   -- registration expired

    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS professional_registration_idx
    ON professional (kind, registration_no);
CREATE INDEX IF NOT EXISTS professional_status_idx ON professional (status);

-- Which investors sit with which professional.
--
-- Separate from advisory_mandate, which records the adviser of record for
-- compliance. This records who brought the client and who manages them, which
-- is a different question -- an MFD has clients and is not their adviser of
-- record, and both facts need somewhere to live.
CREATE TABLE IF NOT EXISTS client_of (
    id               text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    professional_id  text NOT NULL REFERENCES professional(id) ON DELETE RESTRICT,
    investor_id      text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,

    -- How they arrived. A client the professional brought is theirs; one the
    -- platform assigned is a different relationship and may be reassigned.
    came_by          text NOT NULL DEFAULT 'introduced'
                     CHECK (came_by IN ('introduced', 'assigned', 'claimed')),

    began_on         date NOT NULL DEFAULT current_date,
    ended_on         date,

    -- What the investor agreed to. Without it the professional can see a
    -- portfolio nobody said they could see.
    consented_at     timestamptz,
    consent_ref      text,

    created_at       timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT client_dates_make_sense CHECK (ended_on IS NULL
                                              OR ended_on >= began_on)
);

CREATE INDEX IF NOT EXISTS client_of_professional_idx
    ON client_of (professional_id) WHERE ended_on IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS client_of_one_current_idx
    ON client_of (investor_id) WHERE ended_on IS NULL;

COMMENT ON TABLE professional IS
    'What somebody is registered as, with the certificate behind it. Rights '
    'follow the kind: an RIA advises, an MFD distributes and may not advise.';
COMMENT ON TABLE client_of IS
    'Who manages which investor. Distinct from advisory_mandate: an MFD has '
    'clients without being their adviser of record.';

COMMIT;
