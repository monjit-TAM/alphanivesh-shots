-- 028_referrals.sql
--
-- Who brought this investor, and what they signed.
--
-- Two kinds of investor arrive here.
--
-- **Direct.** They found alphanivesh.com and signed up. Nobody referred them,
-- they owe nobody a fee, and there is no advisory relationship to agree to --
-- so no agreement is put in front of them. They are managed from the
-- platform's own desk.
--
-- **Referred.** An RIA or an MFD sent them, by link or by code. There is a
-- relationship, it has terms, and they sign before anything else happens.
--
-- **Managing and advising are different**, and this keeps them apart. A direct
-- investor is managed from the platform desk, which does not make the platform
-- their adviser of record -- it is not registered, and `advisory_mandate` is
-- where that fact lives. Conflating the two would let an unregistered party
-- appear as somebody's adviser because they happened to be managing the
-- account.

BEGIN;

-- The link or code a professional hands out.
CREATE TABLE IF NOT EXISTS referral_code (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    professional_id text NOT NULL REFERENCES professional(id) ON DELETE RESTRICT,

    -- Short, memorable, and unique. Spoken over a phone as often as clicked.
    code            text NOT NULL UNIQUE,
    label           text,

    active          boolean NOT NULL DEFAULT true,
    expires_on      date,
    used_count      integer NOT NULL DEFAULT 0,

    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS referral_code_pro_idx ON referral_code (professional_id);

-- What somebody agreed to, and when.
--
-- Kept for the retention period whatever happens to the relationship
-- afterwards: an agreement that ended is still an agreement that was made,
-- and the question asked later is always about the day it was signed.
CREATE TABLE IF NOT EXISTS agreement (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,

    kind            text NOT NULL CHECK (kind IN (
                        'professional_terms',   -- RIA or MFD, to use this platform
                        'client_ria',           -- investor with an RIA
                        'client_mfd')),         -- investor with a distributor

    -- Which text they saw. The wording changes; what somebody agreed to does
    -- not, so the version is part of the record rather than a pointer to
    -- whatever the current text happens to be.
    version         text NOT NULL,
    body_digest     text NOT NULL,

    user_id         text REFERENCES users(id) ON DELETE RESTRICT,
    investor_id     text REFERENCES investors(id) ON DELETE RESTRICT,
    professional_id text REFERENCES professional(id) ON DELETE RESTRICT,

    agreed_at       timestamptz NOT NULL DEFAULT now(),
    ip              text,
    user_agent      text,

    -- Where an e-sign is used rather than a checkbox.
    esign_ref       text,
    esign_name      text,

    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS agreement_user_idx ON agreement (user_id, kind);
CREATE INDEX IF NOT EXISTS agreement_investor_idx ON agreement (investor_id, kind);

-- How an investor arrived, recorded once and not changed.
ALTER TABLE investors
    ADD COLUMN IF NOT EXISTS came_via text REFERENCES referral_code(id);
ALTER TABLE investors
    ADD COLUMN IF NOT EXISTS is_direct boolean NOT NULL DEFAULT true;

COMMENT ON TABLE referral_code IS
    'The link or code a professional hands out. Short enough to say aloud.';
COMMENT ON TABLE agreement IS
    'What somebody agreed to and which version of it. The version is part of '
    'the record: the wording changes, what was agreed does not.';
COMMENT ON COLUMN investors.is_direct IS
    'True where they found the platform themselves. A direct investor signs '
    'no advisory agreement because there is no advisory relationship to '
    'agree to.';

COMMIT;
