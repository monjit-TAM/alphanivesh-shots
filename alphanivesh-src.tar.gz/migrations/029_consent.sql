-- 029_consent.sql
--
-- What the investor agreed to do, order by order.
--
-- Under an advisory licence the decision to transact is the investor's. Not
-- "they agreed to the plan" and not "they signed an agreement in March" --
-- **this order, this quantity, this moment**, tied to the piece of advice that
-- prompted it.
--
-- That evidence is the difference between an adviser with an execution partner
-- and unauthorised portfolio management, and it is the thing a regulator asks
-- for first. It cannot be reconstructed afterwards, so it is captured before
-- anything is placed or not at all.
--
-- **What is stored is what they saw.** Not a boolean saying they agreed, but
-- the instrument, the side, the quantity, the price they were shown, the
-- estimated cost, and the ledger row that advised it. An investor who says "I
-- never agreed to sell that" is answered by producing the screen they agreed
-- on, not by an assertion that a checkbox was ticked.
--
-- Consent expires. Somebody who agreed to sell at a price they were shown on
-- Monday has not agreed to sell at Friday's price, and a mandate that outlives
-- the figures it was given against is not consent to anything.

BEGIN;

CREATE TABLE IF NOT EXISTS order_consent (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,

    investor_id     text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    -- Under whose registration. Null is possible and is a problem: it means
    -- somebody consented to an order nobody registered advised.
    adviser_id      text REFERENCES adviser(id),
    -- Which piece of advice prompted it.
    ledger_id       text REFERENCES advice_ledger(id),

    -- What they were shown, verbatim. The whole point of the row.
    instrument_id   text REFERENCES instruments(id),
    symbol          text NOT NULL,
    name            text,
    side            text NOT NULL CHECK (side IN ('buy', 'sell')),
    quantity        numeric(20,4),
    amount          numeric(20,2),
    price_shown     numeric(20,4),
    est_cost        numeric(20,2),
    est_tax         numeric(20,2),

    -- The whole basket as it appeared, so the screen can be reproduced rather
    -- than described.
    shown           jsonb NOT NULL,

    given_at        timestamptz NOT NULL DEFAULT now(),
    -- Somebody who agreed against Monday's prices has not agreed to Friday's.
    expires_at      timestamptz NOT NULL,

    ip              text,
    user_agent      text,
    how             text NOT NULL DEFAULT 'in_app'
                    CHECK (how IN ('in_app', 'otp', 'esign', 'recorded_call')),
    otp_ref         text,

    -- Set when it is used. One consent, one order.
    used_at         timestamptz,
    order_ref       text,

    withdrawn_at    timestamptz,
    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS consent_investor_idx
    ON order_consent (investor_id, given_at DESC);
CREATE INDEX IF NOT EXISTS consent_open_idx
    ON order_consent (investor_id)
    WHERE used_at IS NULL AND withdrawn_at IS NULL;

COMMENT ON TABLE order_consent IS
    'This order, this quantity, this moment. What the investor was shown is '
    'stored verbatim so the screen can be reproduced rather than described.';
COMMENT ON COLUMN order_consent.expires_at IS
    'Consent given against a price is consent against that price. A mandate '
    'outliving the figures it was given on is not consent to anything.';

COMMIT;
