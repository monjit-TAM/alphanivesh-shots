-- 030_broker_agreement.sql
--
-- A fourth kind of agreement.
--
-- The client–broker–AlphaVerse one, for orders routed to a broker for
-- execution. Neither the broker nor the platform advises under it, which is
-- what makes it a separate document rather than a variation on the adviser
-- agreement -- and why the constraint has to know about it rather than
-- treating it as an advisory agreement with a different name.

BEGIN;

ALTER TABLE agreement DROP CONSTRAINT IF EXISTS agreement_kind_check;
ALTER TABLE agreement ADD CONSTRAINT agreement_kind_check
    CHECK (kind IN ('professional_terms',
                    'client_ria',
                    'client_mfd',
                    'client_broker'));

COMMENT ON COLUMN agreement.kind IS
    'Which agreement. client_broker covers execution and carries no advisory '
    'duty; conflating it with client_ria would put an advisory obligation on '
    'a broker who has not taken one on.';

COMMIT;
