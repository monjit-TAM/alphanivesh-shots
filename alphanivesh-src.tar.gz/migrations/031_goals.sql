-- 031_goals.sql
--
-- Goals: what somebody is saving towards, and which money is doing it.
--
-- The existing `goals` table is replaced rather than extended. It carried a
-- target, a date and a `current_amount` -- a stored number representing
-- progress, which drifts the moment a price moves and cannot say which money
-- it refers to. Nothing has ever been written to it.
--
-- **Four tables, because a goal is four different kinds of thing.**
--
-- `goal` is the decision: what, how much, by when, in which currency. It
-- persists and should not drift.
--
-- `goal_earmark` is which holdings are doing the work. Rows rather than a
-- percentage of the portfolio, because a percentage lets the same rupee fund
-- three goals and cannot tell somebody that next year's school fees are in a
-- small-cap fund.
--
-- `goal_contribution` is what is committed monthly, kept apart from the goal
-- itself because it changes far more often than the target does.
--
-- `goal_reading` is what we computed and when. Nothing about where somebody
-- stands is stored on the goal -- it is recomputed every time -- but each
-- computation is kept so that "you were comfortable in March and you are tight
-- now" can name what changed rather than just showing a different number.

BEGIN;

DROP TABLE IF EXISTS goals;

CREATE TABLE IF NOT EXISTS goal (
    id            text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    investor_id   text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,

    kind          text NOT NULL CHECK (kind IN (
                      'retirement', 'home', 'education', 'wedding',
                      'vehicle', 'emergency', 'travel', 'business',
                      'growth', 'other')),
    name          text NOT NULL,
    why           text,

    -- What it costs, in the money it costs.
    --
    -- A US degree costs dollars, not rupees. Storing the rupee figure bakes in
    -- today's exchange rate and quietly turns a currency risk into a fact,
    -- which is the thing the goal module exists not to do.
    target_amount numeric(18,2) NOT NULL CHECK (target_amount > 0),
    currency      char(3) NOT NULL DEFAULT 'INR',

    target_date   date NOT NULL,

    -- The person's own ordering, for display. Deliberately not used to rank
    -- one goal above another in any calculation: whether retirement matters
    -- more than a house is not a question a calculation can answer.
    shown_order   smallint NOT NULL DEFAULT 0,

    -- How much shortfall somebody is willing to live with. A wedding at 90%
    -- of target is a smaller wedding; a retirement at 90% is a problem, and
    -- only the person knows which theirs is.
    tolerance_pct numeric(5,2) NOT NULL DEFAULT 0,

    reached_at    timestamptz,
    abandoned_at  timestamptz,
    abandoned_why text,

    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT goal_date_is_ahead CHECK (target_date > '2000-01-01'),
    CONSTRAINT goal_not_both CHECK (reached_at IS NULL OR abandoned_at IS NULL)
);

CREATE INDEX IF NOT EXISTS goal_investor_idx
    ON goal (investor_id, target_date)
    WHERE abandoned_at IS NULL;


-- Which holdings are doing the work.
--
-- A share of the holding rather than an amount, because an amount goes stale
-- the moment the price moves and would need rewriting on every visit. A share
-- is what somebody actually decided -- "half of this fund is for the house" --
-- and its value is computed.
CREATE TABLE IF NOT EXISTS goal_earmark (
    id            text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    goal_id       text NOT NULL REFERENCES goal(id) ON DELETE CASCADE,
    investor_id   text NOT NULL REFERENCES investors(id) ON DELETE RESTRICT,
    instrument_id text NOT NULL REFERENCES instruments(id),

    share_pct     numeric(6,3) NOT NULL
                  CHECK (share_pct > 0 AND share_pct <= 100),

    assigned_at   timestamptz NOT NULL DEFAULT now(),
    removed_at    timestamptz,

    UNIQUE (goal_id, instrument_id)
);

CREATE INDEX IF NOT EXISTS earmark_holding_idx
    ON goal_earmark (investor_id, instrument_id)
    WHERE removed_at IS NULL;
CREATE INDEX IF NOT EXISTS earmark_goal_idx
    ON goal_earmark (goal_id) WHERE removed_at IS NULL;


-- What is committed monthly.
--
-- Separate from the goal because it changes far more often, and because the
-- history of it is the interesting part: somebody who stopped contributing in
-- March is a different situation from somebody who never started, and a single
-- mutable column cannot tell them apart.
CREATE TABLE IF NOT EXISTS goal_contribution (
    id          text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    goal_id     text NOT NULL REFERENCES goal(id) ON DELETE CASCADE,

    monthly     numeric(18,2) NOT NULL CHECK (monthly >= 0),
    -- Where somebody intends to raise it each year. Stated rather than
    -- assumed: a plan that silently assumes rising contributions is a plan
    -- that fails quietly when they do not rise.
    step_up_pct numeric(5,2) NOT NULL DEFAULT 0,

    began_on    date NOT NULL DEFAULT current_date,
    ended_on    date,

    created_at  timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT contribution_dates CHECK (ended_on IS NULL OR ended_on >= began_on)
);

CREATE UNIQUE INDEX IF NOT EXISTS contribution_one_current_idx
    ON goal_contribution (goal_id) WHERE ended_on IS NULL;


-- What we computed, and when.
--
-- Nothing about where somebody stands is stored on the goal. This is the
-- record of each computation, so that a later one can say what moved -- the
-- market, the plan, or the contributions -- rather than showing a different
-- number and leaving somebody to guess.
CREATE TABLE IF NOT EXISTS goal_reading (
    id              text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    goal_id         text NOT NULL REFERENCES goal(id) ON DELETE CASCADE,

    read_at         timestamptz NOT NULL DEFAULT now(),

    -- What the earmarked holdings were worth, and what the target was in
    -- rupees on that day. Both, because a foreign goal can move because the
    -- portfolio moved or because the rupee did.
    earmarked_value numeric(18,2),
    target_in_inr   numeric(18,2),
    fx_rate         numeric(12,4),

    -- The base rate: how many historical windows reached the target.
    reached_pct     numeric(5,2),
    windows         integer,
    window_years    numeric(4,1),
    worst_shortfall numeric(18,2),
    median_finish   numeric(18,2),

    -- Where the replay could not be run honestly, why.
    refused_why     text,

    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS reading_goal_idx ON goal_reading (goal_id, read_at DESC);

-- No holding may be over-promised.
--
-- A CHECK cannot see across rows, so the rule that three goals cannot each
-- claim 60% of the same fund needs a trigger. Enforced in the database rather
-- than in the service because the whole argument for earmarking is that the
-- same rupee cannot fund two goals, and a rule enforced only in application
-- code is a rule that holds until somebody writes a second caller.
CREATE OR REPLACE FUNCTION goal_earmark_within_bounds() RETURNS trigger AS $$
DECLARE
    claimed numeric;
BEGIN
    SELECT coalesce(sum(share_pct), 0) INTO claimed
    FROM goal_earmark
    WHERE instrument_id = NEW.instrument_id
      AND investor_id = NEW.investor_id
      AND removed_at IS NULL
      AND id <> coalesce(NEW.id, '');

    IF claimed + NEW.share_pct > 100.001 THEN
        RAISE EXCEPTION
            'That holding is already % percent promised to other goals, so % '
            'percent more would over-promise it.',
            round(claimed, 1), round(NEW.share_pct, 1)
            USING ERRCODE = 'check_violation';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS goal_earmark_bounds ON goal_earmark;
CREATE TRIGGER goal_earmark_bounds
    BEFORE INSERT OR UPDATE ON goal_earmark
    FOR EACH ROW EXECUTE FUNCTION goal_earmark_within_bounds();

COMMENT ON TABLE goal IS
    'The decision: what, how much, by when, in which currency. Progress is '
    'never stored here -- it is computed from the earmarks every time.';
COMMENT ON COLUMN goal.currency IS
    'What it costs, in the money it costs. A US degree costs dollars; storing '
    'the rupee figure bakes in today rate and turns a currency risk into a '
    'fact.';
COMMENT ON TABLE goal_earmark IS
    'Which holdings are doing the work, as a share of each. A percentage of '
    'the portfolio would let the same rupee fund three goals and could not '
    'see that next year money is in a small-cap fund.';
COMMENT ON TABLE goal_reading IS
    'Each computation, kept so a later one can name what changed rather than '
    'showing a different number.';

COMMIT;
