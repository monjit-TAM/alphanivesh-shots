"""Accounts that predate email verification are already proved.

Verification was built today. Every account created before it has
email_verified_at null, so the funnel reports that nobody has confirmed their
address and the reset flow will refuse to help them.

They have been signing in for weeks. Asking them to confirm an address they
have been using is a worse answer than accepting the evidence already there.

    python scripts_backfill_verified.py           # show
    python scripts_backfill_verified.py --mark    # do it
"""

from __future__ import annotations

import argparse
import sys

from api import db


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mark", action="store_true")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    rows = db.fetch_all(
        """
        SELECT u.id, u.email, u.created_at::date AS joined,
               (SELECT count(*) FROM sessions WHERE user_id = u.id) AS sessions
        FROM users u
        WHERE u.email_verified_at IS NULL
        ORDER BY u.created_at
        """)

    if not rows:
        print("Every account has a confirmed address.")
        return

    print(f"{len(rows)} accounts predate verification:\n")
    for row in rows:
        evidence = (f"{row['sessions']} sessions on record"
                    if row["sessions"] else "no sessions on record")
        print(f"  {row['email'][:38]:<38} joined {row['joined']}  {evidence}")

    print()
    if not args.mark:
        print("Nothing changed. Pass --mark to accept these as confirmed.")
        return

    with db.connection() as conn:
        conn.execute(
            """
            UPDATE users
            SET email_verified_at = coalesce(email_verified_at, created_at)
            WHERE email_verified_at IS NULL
            """)
    print(f"Marked {len(rows)} as confirmed, dated to when they registered "
          f"rather than to now -- the confirmation is a fact about the past.")
    pool.close()


if __name__ == "__main__":
    main()
