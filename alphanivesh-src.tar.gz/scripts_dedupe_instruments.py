"""Fold instruments that are the same fund under different registrar codes.

Registrars prefix their own scheme codes onto fund names, and they do not agree
with each other. The same holding arrives as "EFDG - Axis Large Cap Fund -
Direct Growth" from one statement and "Axis Large Cap Fund - Direct Growth" from
another, becomes two instruments, and is counted twice. One investor here showed
22 positions across 12 actual funds, with a net worth inflated accordingly.

The comparable name is computed by the importer's own function rather than
reimplemented in SQL. An earlier attempt to translate the rule into a Postgres
regex stripped "Axis" as though it were a scheme code, which would have merged
Axis Large Cap with HDFC Large Cap -- one logic, one place.

    python scripts_dedupe_instruments.py --dry-run
    python scripts_dedupe_instruments.py
"""

from __future__ import annotations

import argparse
from collections import defaultdict

from api import db
from api.services.statement_mapper import normalise_scheme_name


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true",
                        help="report what would be folded, change nothing")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    rows = db.fetch_all(
        "SELECT id, name, isin, asset_class, created_at FROM instruments ORDER BY created_at"
    )

    groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        comparable = normalise_scheme_name(row["name"])
        if comparable:
            groups[(row["asset_class"], comparable)].append(row)

    merges: list[tuple[str, str]] = []
    for (asset_class, comparable), members in groups.items():
        if len(members) < 2:
            continue
        # Prefer a survivor that already carries an ISIN: that is the identifier
        # that will match cleanly next time, so it is the one worth keeping.
        members.sort(key=lambda r: (r["isin"] is None, r["created_at"]))
        survivor = members[0]
        for duplicate in members[1:]:
            merges.append((survivor["id"], duplicate["id"]))
        print(f"  {comparable[:52]:<52} keep {survivor['name'][:38]}")
        for duplicate in members[1:]:
            print(f"  {'':<52} fold {duplicate['name'][:38]}")

    if not merges:
        print("Nothing to fold.")
        return

    print(f"\n{len(merges)} instrument(s) to fold into "
          f"{len({s for s, _ in merges})} survivor(s).")

    if args.dry_run:
        print("Dry run: nothing was changed.")
        return

    with db.connection() as conn:
        with conn.transaction():
            for survivor_id, duplicate_id in merges:
                # A snapshot that would collide on (account, instrument, date,
                # source) is the same reading arriving twice, so it goes rather
                # than being merged.
                conn.execute(
                    """
                    UPDATE holding_snapshots h SET instrument_id = %(keep)s
                    WHERE h.instrument_id = %(drop)s
                      AND NOT EXISTS (
                        SELECT 1 FROM holding_snapshots x
                        WHERE x.account_id = h.account_id AND x.instrument_id = %(keep)s
                          AND x.as_of = h.as_of AND x.source = h.source)
                    """,
                    {"keep": survivor_id, "drop": duplicate_id},
                )
                conn.execute("DELETE FROM holding_snapshots WHERE instrument_id = %s",
                             (duplicate_id,))

                conn.execute(
                    """
                    UPDATE canonical_transactions t SET instrument_id = %(keep)s
                    WHERE t.instrument_id = %(drop)s
                      AND NOT EXISTS (
                        SELECT 1 FROM canonical_transactions x
                        WHERE x.account_id = t.account_id AND x.external_ref = t.external_ref
                          AND t.external_ref IS NOT NULL)
                    """,
                    {"keep": survivor_id, "drop": duplicate_id},
                )
                conn.execute("DELETE FROM canonical_transactions WHERE instrument_id = %s",
                             (duplicate_id,))

                conn.execute(
                    "UPDATE instruments s SET isin = d.isin FROM instruments d "
                    "WHERE s.id = %s AND d.id = %s AND s.isin IS NULL AND d.isin IS NOT NULL",
                    (survivor_id, duplicate_id),
                )
                conn.execute("DELETE FROM instruments WHERE id = %s", (duplicate_id,))

            # Store the comparable name so the importer can match against it
            # rather than recomputing for every row it sees.
            for row in db.fetch_all("SELECT id, name FROM instruments"):
                conn.execute(
                    "UPDATE instruments SET attributes = coalesce(attributes,'{}'::jsonb) "
                    "|| jsonb_build_object('comparable_name', %s::text) WHERE id = %s",
                    (normalise_scheme_name(row["name"]), row["id"]),
                )

    print("Done.")


if __name__ == "__main__":
    main()
