"""Load the benchmark series.

NIFTYBEES rather than the index itself. The index endpoint returns no history
and NIFTYBEES is what tracks it -- an ETF holding the fifty constituents, so its
closes are the index plus the dividends the index ignores. That is the fairer
comparison for somebody deciding whether their own picks beat simply buying the
market, because buying the market means buying this.

    python scripts_load_benchmark.py
    python scripts_load_benchmark.py --period max
"""

from __future__ import annotations

import argparse
from datetime import datetime
from decimal import Decimal, InvalidOperation

from api import db
from api.services import dataservice

BENCHMARK = "NIFTYBEES"


def load(period: str = "5y") -> int:
    payload = dataservice.ohlcv(BENCHMARK, period=period)
    bars = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(bars, list) or not bars:
        print("  nothing came back")
        return 0

    rows = []
    for bar in bars:
        try:
            when = datetime.strptime(str(bar.get("date"))[:10], "%Y-%m-%d").date()
            close = Decimal(str(bar.get("close")))
        except (ValueError, TypeError, InvalidOperation):
            continue
        if close > 0:
            rows.append((BENCHMARK, when, close))

    if not rows:
        print("  nothing usable in the response")
        return 0

    with db.connection() as conn:
        with conn.transaction():
            conn.cursor().executemany(
                """
                INSERT INTO benchmark_daily (symbol, trade_date, close)
                VALUES (%s, %s, %s)
                ON CONFLICT (symbol, trade_date) DO UPDATE SET close = EXCLUDED.close
                """,
                rows,
            )
    return len(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--period", default="5y",
                        help="1y, 2y, 5y or max")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    print(f"Fetching {BENCHMARK} over {args.period}...")
    written = load(args.period)
    print(f"  {written} closes")

    row = db.fetch_one(
        "SELECT count(*) AS n, min(trade_date) AS first, max(trade_date) AS last "
        "FROM benchmark_daily WHERE symbol = %s",
        (BENCHMARK,),
    )
    print(f"\nHeld: {row['n']} closes, {row['first']} to {row['last']}")
    pool.close()


if __name__ == "__main__":
    main()
