"""Load scheme portfolio disclosures from a CSV pulled off the production box.

    # on prod
    \\COPY (SELECT scheme_code, as_of, isin, instrument_name, symbol, weight_pct
           FROM mf_scheme_holdings WHERE scheme_code IN (...)
             AND as_of = (SELECT max(as_of) FROM mf_scheme_holdings WHERE scheme_code IN (...)))
      TO '/tmp/constituents.csv' WITH CSV HEADER

    # here
    python scripts_load_constituents.py /tmp/constituents.csv

Copied rather than queried across the network because overlap is computed on
every dashboard load, and a fund's holdings change once a month.
"""

from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation

from api import db


def load(path: str) -> int:
    rows: list[tuple] = []
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            name = (row.get("instrument_name") or "").strip()
            code = (row.get("scheme_code") or "").strip()
            if not name or not code:
                continue
            try:
                weight = Decimal(row["weight_pct"]) if row.get("weight_pct") else None
            except (InvalidOperation, ValueError):
                weight = None
            rows.append((
                code,
                row["as_of"],
                (row.get("isin") or "").strip() or None,
                name,
                (row.get("symbol") or "").strip() or None,
                weight,
            ))

    if not rows:
        print("Nothing in that file.")
        return 0

    with db.connection() as conn:
        with conn.transaction():
            conn.cursor().executemany(
                """
                INSERT INTO scheme_constituents
                    (scheme_code, as_of, isin, instrument_name, symbol, weight_pct)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (scheme_code, as_of, instrument_name)
                DO UPDATE SET isin = EXCLUDED.isin,
                              symbol = EXCLUDED.symbol,
                              weight_pct = EXCLUDED.weight_pct,
                              imported_at = now()
                """,
                rows,
            )
    return len(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", help="the CSV to load")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    written = load(args.path)
    print(f"{written} constituent rows loaded")

    summary = db.fetch_one(
        """
        SELECT count(DISTINCT scheme_code) AS schemes,
               count(DISTINCT coalesce(isin, instrument_name)) AS companies,
               max(as_of) AS as_of
        FROM scheme_constituents
        """
    )
    print(f"  {summary['schemes']} schemes, {summary['companies']} companies, "
          f"as at {summary['as_of']}")

    # How many held funds this covers, which is what decides whether overlap
    # can say anything useful.
    covered = db.fetch_one(
        """
        SELECT count(DISTINCT i.id) AS covered
        FROM instruments i
        JOIN holding_snapshots h ON h.instrument_id = i.id
        JOIN scheme_constituents c ON c.scheme_code = i.native_code
        WHERE i.asset_class = 'mutual_fund'
        """
    )
    print(f"  {covered['covered']} held funds now have their holdings on record")

    pool.close()


if __name__ == "__main__":
    main()
