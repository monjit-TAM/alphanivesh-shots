"""Daily closes for the shares people hold.

`equity_prices` was created and never filled, so anything wanting a return
series for a share had nothing: the risk ratios came back as "0 daily prices"
and the drawdown figures fall back to whatever the fund side can supply.

Shares are priced from live quotes, which is right for a valuation and useless
for a history. This fetches the series once and keeps it, so beta, alpha,
capture and volatility can be computed for a share on the same basis as for a
fund -- which is the point of having both on one page.

    python scripts_load_equity_prices.py              # everything held
    python scripts_load_equity_prices.py --symbol HAL
    python scripts_load_equity_prices.py --years 5
"""

from __future__ import annotations

import argparse
import time
from datetime import date, datetime, timedelta

from api import db
from api.services import dataservice

# Their feed is shared with live users. A pause between symbols costs a minute
# across a hundred and avoids being the reason somebody's quote is slow.
PAUSE = 0.3


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--symbol", help="just one, for testing")
    parser.add_argument("--years", type=int, default=5)
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    if args.symbol:
        symbols = [args.symbol.upper()]
    else:
        rows = db.fetch_all(
            """
            SELECT DISTINCT i.symbol
            FROM v_current_holdings v
            JOIN instruments i ON i.id = v.instrument_id
            WHERE v.asset_class = 'equity' AND i.symbol IS NOT NULL
              AND v.current_value > 0
            ORDER BY i.symbol
            """
        )
        symbols = [r["symbol"] for r in rows]

    if not symbols:
        print("No equity holdings to price.")
        return

    print(f"{len(symbols)} symbols, {args.years} years each\n")

    period = f"{args.years}y"
    stored = skipped = 0

    for symbol in symbols:
        try:
            payload = dataservice.ohlcv(symbol, period=period, interval="1d")
        except Exception as err:
            print(f"  {symbol:<12} could not fetch: {str(err)[:50]}")
            skipped += 1
            continue

        bars = payload.get("data") if isinstance(payload, dict) else payload
        if not isinstance(bars, list) or not bars:
            print(f"  {symbol:<12} no data returned")
            skipped += 1
            continue

        rows = []
        for bar in bars:
            try:
                when = datetime.strptime(str(bar.get("date"))[:10], "%Y-%m-%d").date()
            except (ValueError, TypeError):
                continue
            close = bar.get("close")
            if close is None:
                continue
            try:
                close = float(close)
            except (TypeError, ValueError):
                continue
            if close <= 0:
                continue
            rows.append((symbol, when, close, bar.get("volume")))

        if not rows:
            print(f"  {symbol:<12} nothing usable in {len(bars)} bars")
            skipped += 1
            continue

        with db.connection() as conn:
            with conn.transaction():
                for row in rows:
                    conn.execute(
                        """
                        INSERT INTO equity_prices (symbol, trade_date, close, volume)
                        VALUES (%s, %s, %s, %s)
                        ON CONFLICT (symbol, trade_date)
                        DO UPDATE SET close = EXCLUDED.close,
                                      volume = EXCLUDED.volume
                        """,
                        row,
                    )

        span = f"{rows[0][1]} to {rows[-1][1]}"
        print(f"  {symbol:<12} {len(rows):>5} closes   {span}")
        stored += len(rows)
        time.sleep(PAUSE)

    print()
    print(f"  {stored} closes stored, {skipped} symbols skipped")

    held = db.fetch_one(
        "SELECT count(*) AS rows, count(DISTINCT symbol) AS symbols, "
        "min(trade_date) AS first, max(trade_date) AS last FROM equity_prices"
    )
    print(f"  table now: {held['rows']} rows across {held['symbols']} symbols, "
          f"{held['first']} to {held['last']}")

    if stored:
        print("\n  Risk ratios for shares will compute from the next page load.")

    pool.close()


if __name__ == "__main__":
    main()
