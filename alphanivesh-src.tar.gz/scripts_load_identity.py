"""Fill the instrument identity table from what we already hold.

Two sources, both already on this box:

    company_fundamentals   2,329 companies with ISIN, symbol, sector
    searchable_instruments AMFI schemes and the equities we loaded

Where they disagree about what an identifier means, the disagreement is
recorded rather than resolved. Nothing resolves through a conflicted identifier
until somebody has looked at it.

    python scripts_load_identity.py
"""

from __future__ import annotations

import argparse
import re

from api import db
from api.services import identity


def flatten(*parts) -> str:
    joined = " ".join(str(p) for p in parts if p)
    return re.sub(r"[^a-z0-9]+", " ", joined.lower().replace("&", " and ")).strip()


def load_from_fundamentals() -> int:
    rows = db.fetch_all(
        """
        SELECT symbol, isin, company_name, sector, industry, market_cap
        FROM company_fundamentals
        WHERE symbol IS NOT NULL AND company_name IS NOT NULL
        """
    )
    written = conflicts = 0

    with db.connection() as conn:
        for row in rows:
            isin = (row["isin"] or "").strip().upper() or None

            # Before writing, check whether this ISIN already names something
            # else. Two companies sharing an ISIN means one of the sources is
            # wrong, and overwriting would hide it.
            if isin:
                existing = conn.execute(
                    "SELECT id, company_name, nse_symbol FROM instrument_identity "
                    "WHERE isin = %s AND is_active",
                    (isin,),
                ).fetchone()
                if existing and flatten(existing["company_name"]) != flatten(row["company_name"]):
                    identity.record_conflict("isin", isin, [
                        {"by": "existing", "company_name": existing["company_name"],
                         "nse_symbol": existing["nse_symbol"]},
                        {"by": "company_fundamentals", "company_name": row["company_name"],
                         "nse_symbol": row["symbol"]},
                    ])
                    conflicts += 1
                    continue

            conn.execute(
                """
                INSERT INTO instrument_identity
                    (isin, nse_symbol, company_name, sector, industry,
                     market_cap_cr, source, search_text)
                VALUES (%s, %s, %s, %s, %s, %s, 'company_fundamentals', %s)
                ON CONFLICT (isin) WHERE isin IS NOT NULL AND is_active
                DO UPDATE SET nse_symbol = EXCLUDED.nse_symbol,
                              company_name = EXCLUDED.company_name,
                              sector = EXCLUDED.sector,
                              industry = EXCLUDED.industry,
                              market_cap_cr = EXCLUDED.market_cap_cr,
                              search_text = EXCLUDED.search_text,
                              updated_at = now()
                """,
                (isin, row["symbol"], row["company_name"], row["sector"],
                 row["industry"], row["market_cap"],
                 flatten(row["company_name"], row["symbol"])),
            )
            written += 1

    print(f"  {written} from company fundamentals, {conflicts} conflicts held back")
    return written


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    print("Loading identities...")
    load_from_fundamentals()

    summary = db.fetch_one(
        """
        SELECT count(*) AS total,
               count(*) FILTER (WHERE isin IS NOT NULL) AS with_isin,
               count(*) FILTER (WHERE nse_symbol IS NOT NULL) AS with_symbol
        FROM instrument_identity WHERE is_active
        """
    )
    print(f"\n  {summary['total']} identities, {summary['with_isin']} with an ISIN, "
          f"{summary['with_symbol']} with a symbol")

    open_ = identity.open_conflicts()
    if open_:
        print(f"\n  {len(open_)} unresolved conflicts:")
        for c in open_[:5]:
            names = [x.get("company_name") for x in c["claims"]]
            print(f"    {c['identifier_kind']} {c['identifier']}: {' vs '.join(names)}")

    pool.close()


if __name__ == "__main__":
    main()
