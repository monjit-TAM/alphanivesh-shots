"""Filling the instrument master that manual entry searches against.

Two sources, both authoritative in their own domain:

  AMFI publishes every Indian mutual fund scheme daily, with its AMFI code, ISIN
  and current NAV, as a plain text file. It is the definitive list -- if a
  scheme is not in it, it is not a scheme.

  The AlphaMarket instrument master carries around 140,000 exchange-traded
  instruments. It lives on the production box and is reachable across the VPC.

Run nightly:

    python scripts_load_instruments.py --amfi --equities

Copying into our own table rather than querying prod per keystroke is
deliberate. A search that reaches across the network on every character typed
is slow when the network is fine and broken when it is not, and the data changes
daily rather than by the minute.
"""

from __future__ import annotations

import argparse
import re
from typing import Iterable, Optional

import httpx

from api import db

AMFI_NAV_URL = "https://www.amfiindia.com/spages/NAVAll.txt"
PROD_DATA_SERVICE = "http://10.122.0.2:5004"

# Punctuation and case removed, so a search does not depend on whether somebody
# typed "L&T" or "L and T", or where the hyphens fell.
_TIDY = re.compile(r"[^a-z0-9]+")


def searchable(*parts: Optional[str]) -> str:
    """The same flattening the search applies to a query.

    These two must agree exactly. If the loader drops ampersands and the search
    turns them into "and", "L&T" is indexed as "l t" and searched for as
    "l and t", and the fund is unfindable.
    """
    joined = " ".join(p for p in parts if p).lower().replace("&", " and ")
    return _TIDY.sub(" ", joined).strip()


def _upsert(rows: list[dict]) -> int:
    """Write a batch, replacing what was there for the same identifier."""
    if not rows:
        return 0

    with db.connection() as conn:
        with conn.transaction():
            for row in rows:
                conn.execute(
                    """
                    INSERT INTO searchable_instruments
                        (asset_class, name, isin, symbol, native_code, issuer,
                         category, exchange, source, search_text, updated_at)
                    VALUES (%(asset_class)s, %(name)s, %(isin)s, %(symbol)s,
                            %(native_code)s, %(issuer)s, %(category)s, %(exchange)s,
                            %(source)s, %(search_text)s, now())
                    ON CONFLICT (isin) WHERE isin IS NOT NULL
                    DO UPDATE SET name = EXCLUDED.name,
                                  issuer = EXCLUDED.issuer,
                                  category = EXCLUDED.category,
                                  native_code = coalesce(EXCLUDED.native_code,
                                                         searchable_instruments.native_code),
                                  search_text = EXCLUDED.search_text,
                                  is_active = true,
                                  updated_at = now()
                    """,
                    row,
                )
    return len(rows)


# ---------------------------------------------------------------------------
# Mutual funds, from AMFI
# ---------------------------------------------------------------------------


def load_amfi() -> int:
    """Every mutual fund scheme AMFI publishes.

    The file is grouped: a line naming the fund house, then a header, then one
    line per scheme separated by semicolons. Blank lines and the group headers
    have to be skipped, and a scheme without an ISIN is usually a plan that has
    been wound up.
    """
    print("Fetching the AMFI scheme list...")
    with httpx.Client(timeout=120.0, follow_redirects=True) as client:
        response = client.get(AMFI_NAV_URL)
        response.raise_for_status()
        text = response.text

    rows: list[dict] = []
    amc: Optional[str] = None
    skipped_no_isin = 0

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue

        # A line with no semicolons is a fund house heading. A line starting
        # with "Scheme Code" is the column header.
        if ";" not in line:
            if not line.lower().startswith("scheme code"):
                amc = line
            continue
        if line.lower().startswith("scheme code"):
            continue

        parts = line.split(";")
        if len(parts) < 6:
            continue

        # Eight fields, and the two in the middle are the ones that matter:
        #
        #   code ; isin_growth ; isin_reinvest ; name ; plan ; option ; nav ; date
        #
        # An earlier version read the first four and stopped, so all four
        # variants of SBI Midcap Fund -- Direct/Regular by Growth/IDCW --
        # stored as the same string. They were indistinguishable in search and
        # impossible to match by name, which is what sent the price loader
        # looking for a fuzzy match it could never make safely.
        code = parts[0].strip()
        isin_growth = parts[1].strip()
        isin_reinvest = parts[2].strip()
        base_name = parts[3].strip()
        plan = parts[4].strip() if len(parts) > 4 else ""
        option = parts[5].strip() if len(parts) > 5 else ""

        def usable(value: str) -> bool:
            return value.upper() not in ("", "-", "N.A.", "NA")

        isin = isin_growth if usable(isin_growth) else (
            isin_reinvest if usable(isin_reinvest) else "")
        if not isin:
            skipped_no_isin += 1
            continue
        if not base_name:
            continue

        # The full name as a person would recognise it, which is also what
        # makes the four variants tell themselves apart in a search result.
        full_name = " - ".join(p for p in (base_name, plan, option) if p)

        rows.append({
            "asset_class": "mutual_fund",
            "name": full_name,
            "isin": isin,
            "symbol": None,
            "native_code": code or None,
            "issuer": amc,
            # The plan and option are worth keeping in their own right: the
            # commission-drag finding turns on whether a holding is Regular or
            # Direct, and reading that from a name is guesswork.
            "category": option or None,
            "exchange": None,
            "source": "amfi",
            "search_text": searchable(full_name, amc),
        })

    written = _upsert(rows)
    print(f"  {written} schemes loaded, {skipped_no_isin} skipped for having no ISIN")
    return written


# ---------------------------------------------------------------------------
# Exchange-traded instruments, from the production master
# ---------------------------------------------------------------------------


def load_equities(limit: Optional[int] = None) -> int:
    """Shares and ETFs from the AlphaMarket instrument master.

    Only cash-segment equities: the master also holds every option and future,
    which nobody is going to type into a holdings form and which would drown
    the search results.
    """
    print("Fetching equities from the production instrument master...")
    try:
        with httpx.Client(timeout=120.0) as client:
            response = client.get(
                f"{PROD_DATA_SERVICE}/data/equity/instruments",
                params={"segment": "NSE", "limit": limit or 20000},
            )
            response.raise_for_status()
            payload = response.json()
    except httpx.HTTPError as err:
        print(f"  could not reach the data service: {err}")
        print("  (equities can be loaded later; funds do not depend on this)")
        return 0

    items = payload.get("instruments") or payload.get("data") or []
    rows: list[dict] = []
    for item in items:
        name = (item.get("name") or item.get("company_name") or "").strip()
        symbol = (item.get("symbol") or item.get("tradingsymbol") or "").strip()
        if not name and not symbol:
            continue
        isin = (item.get("isin") or "").strip() or None

        rows.append({
            "asset_class": "equity",
            "name": name or symbol,
            "isin": isin,
            "symbol": symbol or None,
            "native_code": symbol or None,
            "issuer": None,
            "category": item.get("sector"),
            "exchange": item.get("exchange") or "NSE",
            "source": "alphamarket",
            "search_text": searchable(name, symbol),
        })

    written = _upsert(rows)
    print(f"  {written} equities loaded")
    return written


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--amfi", action="store_true", help="load mutual fund schemes")
    parser.add_argument("--equities", action="store_true", help="load shares and ETFs")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    if not (args.amfi or args.equities):
        args.amfi = args.equities = True

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    total = 0
    if args.amfi:
        total += load_amfi()
    if args.equities:
        total += load_equities(args.limit)

    counts = db.fetch_all(
        "SELECT asset_class, count(*) AS n FROM searchable_instruments "
        "WHERE is_active GROUP BY 1 ORDER BY 2 DESC"
    )
    print("\nSearchable now:")
    for row in counts:
        print(f"  {row['asset_class']:<14} {row['n']:>8}")

    pool.close()


if __name__ == "__main__":
    main()
