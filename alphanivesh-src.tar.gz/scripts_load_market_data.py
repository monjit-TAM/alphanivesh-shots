"""Load fundamentals, scheme returns and benchmarks from CSVs pulled off prod.

The production box collects all of this already. What it does not have is a way
to reach it from here -- the services on 5001 to 5015 are not listening on the
VPC interface -- so the route is the same one that worked for scheme
constituents: export to CSV there, copy, load here.

    # on prod, for the symbols and schemes we hold
    \\COPY (...) TO '/tmp/fundamentals.csv' WITH CSV HEADER

    # here
    python scripts_load_market_data.py --fundamentals /tmp/fundamentals.csv
    python scripts_load_market_data.py --returns /tmp/scheme_returns.csv
    python scripts_load_market_data.py --benchmarks /tmp/benchmarks.csv
    python scripts_load_market_data.py --prices /tmp/equity_prices.csv
"""

from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
from typing import Any, Optional

from api import db


def _num(value: Any) -> Optional[Decimal]:
    """A number, or nothing.

    Infinity and NaN arrive here more often than you would expect: a dividend
    yield is a dividend divided by a price, and four companies in this source
    have a price of zero, which Postgres happily stores as Infinity. That is
    not a large number needing a wider column -- it is an absent one wearing a
    numeral, and storing it would put "dividend yield: Infinity" on somebody's
    screen.
    """
    if value in (None, "", "NULL", "\\N"):
        return None
    text = str(value).strip()
    if text.lower() in ("infinity", "-infinity", "inf", "-inf", "nan", "none"):
        return None
    try:
        parsed = Decimal(text)
    except (InvalidOperation, ValueError):
        return None
    if not parsed.is_finite():
        return None
    return parsed


def _text(value: Any) -> Optional[str]:
    if value in (None, "", "NULL", "\\N"):
        return None
    return str(value).strip() or None


def _load(path: str, table: str, columns: list[str], key: list[str],
          numeric: set[str], integer: set[str] = frozenset()) -> int:
    """Read a CSV into a table, replacing rows with the same key.

    Column names in the file are expected to match the table, which they do
    because both sides came from the same schema.
    """
    rows: list[tuple] = []
    with open(path, newline="", encoding="utf-8") as handle:
        for record in csv.DictReader(handle):
            values = []
            for column in columns:
                raw = record.get(column)
                if column in numeric:
                    values.append(_num(raw))
                elif column in integer:
                    n = _num(raw)
                    values.append(int(n) if n is not None else None)
                else:
                    values.append(_text(raw))
            if all(v is None for v in values[:len(key)]):
                continue
            rows.append(tuple(values))

    if not rows:
        print(f"  nothing in {path}")
        return 0

    placeholders = ", ".join(["%s"] * len(columns))
    updates = ", ".join(f"{c} = EXCLUDED.{c}" for c in columns if c not in key)

    statement = (f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders}) "
                 f"ON CONFLICT ({', '.join(key)}) DO UPDATE SET {updates}")

    try:
        with db.connection() as conn:
            with conn.transaction():
                conn.cursor().executemany(statement, rows)
    except Exception as bulk_error:
        # executemany reports which constraint failed but not which row. On a
        # file of two thousand records that is not enough to act on, so retry
        # one at a time to find the offenders and report them by name.
        print(f"  bulk insert failed ({type(bulk_error).__name__}); retrying row by row")
        written = 0
        problems: list[str] = []
        for row in rows:
            try:
                with db.connection() as conn:
                    with conn.transaction():
                        conn.execute(statement, row)
                written += 1
            except Exception as row_error:
                if len(problems) < 8:
                    problems.append(f"{row[0]}: {str(row_error).splitlines()[0][:90]}")
        for problem in problems:
            print(f"    {problem}")
        skipped = len(rows) - written
        print(f"  {written} rows into {table}, {skipped} skipped")
        return written

    print(f"  {len(rows)} rows into {table}")
    return len(rows)


FUNDAMENTAL_COLUMNS = [
    "symbol", "isin", "company_name", "sector", "industry", "market_cap_category",
    "market_cap", "pe_ttm", "pb_ratio", "ev_ebitda", "peg_ratio", "earnings_yield",
    "dividend_yield", "roe", "roce", "roa", "debt_to_equity", "interest_coverage",
    "current_ratio", "ebitda_margin", "net_margin", "revenue_growth_yoy",
    "pat_growth_yoy", "eps_growth_yoy", "fcf_yield", "beta", "eps_ttm",
    "book_value", "high_52w", "period_end",
]

RETURN_COLUMNS = [
    "scheme_code", "nav_latest", "nav_date", "ret_1m", "ret_3m", "ret_6m", "ret_1y",
    "cagr_3y", "cagr_5y", "cagr_10y", "roll3_median", "roll3_p25", "roll3_p75",
    "roll3_pos_pct", "roll3_worst", "roll3_windows", "roll5_median", "roll5_pos_pct",
    "roll5_worst", "cat_rank", "cat_n", "computed_at",
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fundamentals")
    parser.add_argument("--returns")
    parser.add_argument("--benchmarks")
    parser.add_argument("--prices")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    if args.fundamentals:
        print("Company fundamentals...")
        _load(args.fundamentals, "company_fundamentals", FUNDAMENTAL_COLUMNS,
              ["symbol"],
              numeric={c for c in FUNDAMENTAL_COLUMNS
                       if c not in ("symbol", "isin", "company_name", "sector",
                                    "industry", "market_cap_category", "period_end")})

    if args.returns:
        print("Scheme returns...")
        _load(args.returns, "scheme_returns", RETURN_COLUMNS, ["scheme_code"],
              numeric={c for c in RETURN_COLUMNS
                       if c not in ("scheme_code", "nav_date", "computed_at",
                                    "roll3_windows", "cat_rank", "cat_n")},
              integer={"roll3_windows", "cat_rank", "cat_n"})

    if args.benchmarks:
        print("Benchmarks...")
        _load(args.benchmarks, "benchmark_daily", ["symbol", "trade_date", "close"],
              ["symbol", "trade_date"], numeric={"close"})

    if args.prices:
        print("Equity prices...")
        _load(args.prices, "equity_prices",
              ["symbol", "trade_date", "close", "volume"],
              ["symbol", "trade_date"], numeric={"close"}, integer={"volume"})

    print("\nHeld now:")
    for table in ("company_fundamentals", "scheme_returns", "benchmark_daily",
                  "equity_prices"):
        row = db.fetch_one(f"SELECT count(*) AS n FROM {table}")
        print(f"  {table:<24} {row['n']:>8}")

    pool.close()


if __name__ == "__main__":
    main()
