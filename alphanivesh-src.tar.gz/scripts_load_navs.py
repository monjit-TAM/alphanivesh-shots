"""Fetch daily prices for the schemes people hold.

Two steps. First match held instruments to AMFI scheme codes, since most
arrived from statements that carry an ISIN but no code. Then fetch the price
history for whatever now has one.

    python scripts_load_navs.py --match      only fill in missing scheme codes
    python scripts_load_navs.py              match, then fetch prices

Worth running nightly. The fetch skips anything refreshed in the last twenty
hours, so a repeat run costs almost nothing.
"""

from __future__ import annotations

import argparse
import time

from api import db
from api.services import navs


def match_scheme_codes() -> int:
    """Give held instruments an AMFI code, so they can be priced.

    ISIN first, because it is exact. Where a statement gave no ISIN we fall back
    to the normalised name, which is the same matching the importer uses to
    recognise the same fund under two registrars' spellings.
    """
    # A scheme code can already be sitting on the wrong instrument. The CAS
    # importer stores whatever `additional_info.amfi` said, and statements are
    # not always right: an SBI ELSS IDCW holding here carries the code that
    # AMFI maps to the Growth plan of the same fund. Those are different
    # instruments with different NAVs, so they cannot share a code -- and
    # pricing one with the other's history would be quietly wrong.
    #
    # An ISIN match beats an unverified statement field, so the contested code
    # is taken off the instrument that has no ISIN to justify it.
    contested = db.fetch_all(
        """
        UPDATE instruments loser
        SET native_code = NULL,
            attributes = coalesce(loser.attributes, '{}'::jsonb)
                         || jsonb_build_object('scheme_code_cleared',
                                               loser.native_code::text)
        FROM searchable_instruments s
        JOIN instruments winner
          ON winner.isin = s.isin AND winner.asset_class = 'mutual_fund'
        WHERE loser.asset_class = 'mutual_fund'
          AND loser.native_code = s.native_code
          AND loser.id <> winner.id
          AND loser.isin IS NULL
        RETURNING loser.id, loser.name
        """
    )
    for row in contested:
        print(f"  cleared a contested scheme code from {row['name'][:46]}")

    by_isin = db.fetch_all(
        """
        UPDATE instruments i
        SET native_code = s.native_code
        FROM searchable_instruments s
        WHERE i.isin IS NOT NULL AND i.isin = s.isin
          AND s.native_code IS NOT NULL
          AND (i.native_code IS NULL OR i.native_code !~ '^[0-9]+$')
          AND i.asset_class = 'mutual_fund'
          -- Do not take a code another instrument legitimately holds.
          AND NOT EXISTS (
            SELECT 1 FROM instruments other
            WHERE other.asset_class = 'mutual_fund'
              AND other.native_code = s.native_code
              AND other.id <> i.id)
        RETURNING i.id
        """
    )
    print(f"  {len(by_isin)} matched on ISIN")

    # Name matching, for schemes a statement gave no code for.
    #
    # Exact string equality does not work here and it took a round trip to see
    # why: our comparable name is built from the scheme alone, AMFI's includes
    # the fund house, and ours sometimes carries statement noise like
    # "non demat" or "registrar cams" that AMFI would never have. The same fund
    # is therefore two different strings.
    #
    # Similarity matching with a high floor is the honest tool, and it only
    # became usable once the AMFI loader started keeping the plan and option.
    # Before that all four variants of a fund -- Direct and Regular by Growth
    # and IDCW -- stored as the same string and scored identically, so no
    # threshold could have separated them.
    #
    # With them, a correct match scores around 0.77 and the nearest wrong plan
    # around 0.59. The floor sits inside that gap. Attaching a holding to the
    # wrong plan's price history would show somebody a return they never
    # earned, so anything ambiguous is left unpriced instead.
    by_name = db.fetch_all(
        """
        WITH held AS (
            SELECT DISTINCT i.id,
                   -- strip the noise our own importer added
                   trim(regexp_replace(
                        i.attributes->>'comparable_name',
                        '\\s*(non demat|registrar cams|registrar kfintech)\\s*', ' ', 'gi')) AS ours
            FROM instruments i
            JOIN holding_snapshots h ON h.instrument_id = i.id
            WHERE i.asset_class = 'mutual_fund'
              AND (i.native_code IS NULL OR i.native_code !~ '^[0-9]+$')
              AND coalesce(i.attributes->>'comparable_name', '') <> ''
        ),
        best AS (
            SELECT held.id,
                   s.native_code,
                   s.name AS amfi_name,
                   similarity(s.search_text, held.ours) AS score,
                   row_number() OVER (PARTITION BY held.id
                                      ORDER BY similarity(s.search_text, held.ours) DESC) AS rank,
                   count(*) FILTER (WHERE similarity(s.search_text, held.ours) > 0.70)
                       OVER (PARTITION BY held.id) AS near_ties,
                   -- The gap to the runner-up. A correct match beats the
                   -- nearest wrong plan by a clear margin once the plan and
                   -- option are in the name; without that margin we are
                   -- choosing between variants we cannot tell apart.
                   similarity(s.search_text, held.ours)
                     - coalesce(lead(similarity(s.search_text, held.ours))
                         OVER (PARTITION BY held.id
                               ORDER BY similarity(s.search_text, held.ours) DESC), 0) AS lead_margin
            FROM held
            JOIN searchable_instruments s
              ON s.asset_class = 'mutual_fund'
             AND s.search_text %% held.ours
        )
        UPDATE instruments i SET native_code = best.native_code
        FROM best
        WHERE i.id = best.id
          AND best.rank = 1
          AND best.score > 0.70
          -- One clear winner only. Several near-equal candidates means we
          -- cannot tell which plan is held, and a wrong guess is silent.
          -- Either one candidate clears the bar, or the winner leads the
          -- next by enough that they are not the same fund's other plan.
          AND (best.near_ties = 1 OR best.lead_margin > 0.08)
          AND NOT EXISTS (
            SELECT 1 FROM instruments other
            WHERE other.asset_class = 'mutual_fund'
              AND other.native_code = best.native_code
              AND other.id <> i.id)
        RETURNING i.id, i.name, best.amfi_name, round(best.score::numeric, 2) AS score
        """
    )
    for row in by_name:
        print(f"    {row['name'][:40]:<40} -> {row['amfi_name'][:38]}  ({row['score']})")
    print(f"  {len(by_name)} matched on name")

    unmatched = db.fetch_one(
        """
        SELECT count(DISTINCT i.id) AS n
        FROM instruments i JOIN holding_snapshots h ON h.instrument_id = i.id
        WHERE i.asset_class = 'mutual_fund'
          AND (i.native_code IS NULL OR i.native_code !~ '^[0-9]+$')
        """
    )
    if unmatched and unmatched["n"]:
        print(f"  {unmatched['n']} held schemes still have no AMFI code and cannot be priced")

    return len(by_isin) + len(by_name)


def load_prices(limit: int | None = None) -> int:
    pending = navs.instruments_needing_prices()
    if limit:
        pending = pending[:limit]

    if not pending:
        print("  nothing to fetch; everything is current")
        return 0

    print(f"  {len(pending)} schemes to fetch")
    total = 0
    failures = 0

    for row in pending:
        try:
            result = navs.fetch_scheme(row["native_code"])
            written = navs.store(row["id"], result["points"], result["meta"])
            total += written
            print(f"    {row['name'][:44]:<44} {written:>5} prices")
        except navs.NavError as err:
            failures += 1
            print(f"    {row['name'][:44]:<44} failed: {err}")
        # The service is free and public. A short pause is basic courtesy and
        # keeps us clear of any rate limit.
        time.sleep(0.3)

    print(f"\n  {total} prices stored across {len(pending) - failures} schemes")
    if failures:
        print(f"  {failures} failed")
    return total


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--match", action="store_true",
                        help="only fill in scheme codes, do not fetch prices")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    print("Matching held instruments to AMFI scheme codes...")
    match_scheme_codes()

    if not args.match:
        print("\nFetching prices...")
        load_prices(args.limit)

    summary = db.fetch_one(
        """
        SELECT count(DISTINCT instrument_id) AS instruments,
               count(*) AS prices,
               min(as_of) AS earliest, max(as_of) AS latest
        FROM nav_history
        """
    )
    print(f"\nHeld: {summary['instruments']} instruments, {summary['prices']} prices, "
          f"{summary['earliest']} to {summary['latest']}")

    pool.close()


if __name__ == "__main__":
    main()
