"""Grant somebody administrator access.

Deliberately not part of the signup path. `auth.create_user` refuses to make
an admin -- roles are limited to investor and advisor there -- because an
account that can read every investor's record and export the advice ledger
should be created by somebody with shell access, not by anybody who can reach
a form.

    python scripts_make_admin.py monjit@example.com
    python scripts_make_admin.py monjit@example.com --create

The password is read from a prompt, never from an argument. An argument lands
in shell history and in the process list, where anybody on the machine can
read it -- which for a credential that opens every client's file is not a
risk worth taking for the convenience of one line.
"""

from __future__ import annotations

import argparse
import getpass
import sys

from argon2 import PasswordHasher

from api import db

_hasher = PasswordHasher()

# Eight, as asked for. Worth saying what that buys: an eight-character password
# on an account that reads every client's holdings and exports the advice
# ledger is thin, and this is the login a regulator would ask about if it were
# ever compromised. Length is the cheapest defence there is -- if this is ever
# revisited, raising it costs nothing and helps more than any other change.
MINIMUM = 8


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("email")
    parser.add_argument("--create", action="store_true",
                        help="make the account if it does not exist")
    parser.add_argument("--name", default=None)
    args = parser.parse_args()

    email = args.email.strip().lower()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    existing = db.fetch_one(
        "SELECT id, email, full_name, role FROM users WHERE lower(email) = %s",
        (email,))

    if existing:
        print(f"  {email} exists, role '{existing['role']}'")
        change = input("  Set a new password as well? [y/N] ").strip().lower()
        password = None
        if change == "y":
            password = getpass.getpass("  New password: ")
            again = getpass.getpass("  Again: ")
            if password != again:
                print("  They do not match. Nothing changed.")
                return
            if len(password) < MINIMUM:
                print(f"  {MINIMUM} characters minimum. Nothing changed.")
                return

        if password:
            with db.connection() as conn:
                conn.execute(
                    "UPDATE users SET role = 'admin', password_hash = %s "
                    "WHERE id = %s",
                    (_hasher.hash(password), existing["id"]))
            print(f"  {email} is now an admin, with a new password.")
        else:
            with db.connection() as conn:
                conn.execute("UPDATE users SET role = 'admin' WHERE id = %s",
                             (existing["id"],))
            print(f"  {email} is now an admin. Password unchanged.")

    elif args.create:
        password = getpass.getpass("  Password: ")
        again = getpass.getpass("  Again: ")
        if password != again:
            print("  They do not match. Nothing created.")
            return
        if len(password) < MINIMUM:
            print(f"  {MINIMUM} characters minimum. Nothing created.")
            return

        row = db.fetch_one(
            """
            INSERT INTO users (email, password_hash, full_name, role)
            VALUES (%s, %s, %s, 'admin')
            RETURNING id, email
            """,
            (email, _hasher.hash(password), args.name or email.split("@")[0]))
        print(f"  Created {row['email']} as an admin.")

    else:
        print(f"  No account for {email}. Pass --create to make one.")
        return

    admins = db.fetch_all(
        "SELECT email, full_name FROM users WHERE role = 'admin' ORDER BY email")
    print()
    print(f"  {len(admins)} admin{'s' if len(admins) != 1 else ''}:")
    for admin in admins:
        print(f"    {admin['email']}")

    print()
    print("  An admin can read every investor's holdings and export the advice")
    print("  ledger. Worth reviewing this list when somebody leaves.")

    pool.close()


if __name__ == "__main__":
    main()
