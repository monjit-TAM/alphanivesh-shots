"""The favicon set, from the AV monogram.

    python scripts_make_icons.py web/icon-source.png web/

**The source is 5000x3671 and not square.** A browser given a rectangle either
squashes it or crops it, and neither is a decision worth leaving to a browser.
This pads to square with transparent margin, so the mark keeps its proportions
and sits centred with a little room -- an icon touching its own edges looks
cramped at every size it is used.

**Several sizes, because they are used differently.** A 16px favicon is
rendered at 16px and downscaling a 512 to it in the browser produces mush;
Apple's touch icon is composited onto a background and needs an opaque one, or
iOS supplies black.

At the smallest sizes this mark will be a red and blue shape rather than two
readable letters. That is true of most logos and is not worth fighting.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image

# The paper the app is on, for the sizes that cannot be transparent.
CREAM = (250, 247, 242, 255)


def square(im: Image.Image, pad: float = 0.10) -> Image.Image:
    """Centre the mark on a transparent square with a margin."""
    im = im.convert("RGBA")
    side = max(im.size)
    side = int(side * (1 + pad * 2))
    out = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    out.paste(im, ((side - im.width) // 2, (side - im.height) // 2), im)
    return out


def main() -> None:
    source = Path(sys.argv[1] if len(sys.argv) > 1 else "web/icon-source.png")
    into = Path(sys.argv[2] if len(sys.argv) > 2 else "web")

    if not source.exists():
        print(f"No source at {source}")
        raise SystemExit(1)

    mark = square(Image.open(source))
    print(f"  source {Image.open(source).size} -> squared {mark.size}")

    # Transparent PNGs, for everywhere that handles transparency.
    for size in (16, 32, 48, 192, 512):
        out = mark.resize((size, size), Image.LANCZOS)
        path = into / f"icon-{size}.png"
        out.save(path, optimize=True)
        print(f"  {path.name:<18} {path.stat().st_size // 1024 or 1} KB")

    # The .ico, carrying the three sizes a browser actually asks for.
    mark.resize((256, 256), Image.LANCZOS).save(
        into / "favicon.ico", sizes=[(16, 16), (32, 32), (48, 48)])
    print(f"  favicon.ico        {(into / 'favicon.ico').stat().st_size // 1024 or 1} KB")

    # Apple's, on the paper colour. iOS composites onto black otherwise, and
    # a mark with a shadow on black looks like a mistake.
    apple = Image.new("RGBA", (180, 180), CREAM)
    scaled = mark.resize((180, 180), Image.LANCZOS)
    apple.paste(scaled, (0, 0), scaled)
    apple.convert("RGB").save(into / "apple-touch-icon.png", optimize=True)
    print(f"  apple-touch-icon   "
          f"{(into / 'apple-touch-icon.png').stat().st_size // 1024 or 1} KB")


if __name__ == "__main__":
    main()
