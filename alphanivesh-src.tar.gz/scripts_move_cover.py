"""Move insurance out of the holdings and into protection.

A term policy's sum assured was sitting in the holdings table being counted as
wealth. On one real portfolio that inflated the total from about a crore to
four and a half, made every allocation percentage wrong, and put the family's
term cover on a list of things to sell.

The fix that patches every query which totals holdings is the wrong one --
there are a dozen and a thirteenth will be written next week. The fix is to
put the data where it belongs.

    python scripts_move_cover.py            # show what would move
    python scripts_move_cover.py --move     # move it

**What happens to the value.** For term and health, the recorded amount is a
sum assured and becomes cover_amount, which is never counted as wealth. For
endowment and ULIP, we cannot tell from a single figure whether somebody
entered the cover or the surrender value -- so it is recorded as cover and
flagged, because overstating wealth is the error worth avoiding and somebody
can correct it.
"""

from __future__ import annotations

import argparse
import re
import sys
from decimal import Decimal

from api import db

TERM_WORDS = ("term", "pure protection", "raksha", "e-term", "iprotect")
HEALTH_WORDS = ("health", "mediclaim", "hospital", "family floater",
                "critical illness", "accident")
VALUED_WORDS = ("ulip", "endowment", "money back", "moneyback", "jeevan",
                "wealth", "invest")


def kind_of(name: str) -> str:
    text = (name or "").lower()
    if any(w in text for w in HEALTH_WORDS):
        return "health"
    if any(w in text for w in VALUED_WORDS):
        return "ulip" if "ulip" in text else "endowment"
    if any(w in text for w in TERM_WORDS):
        return "term_life"
    return "term_life"          # the safe default: no surrender value assumed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--move", action="store_true")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    rows = db.fetch_all(
        """
        SELECT v.investor_id, v.instrument_id, v.instrument_name,
               v.current_value, inv.display_name
        FROM v_current_holdings v
        JOIN investors inv ON inv.id = v.investor_id
        WHERE v.asset_class = 'insurance' AND v.current_value > 0
        ORDER BY v.current_value DESC
        """
    )

    if not rows:
        print("Nothing recorded as insurance among the holdings.")
        return

    total = sum(Decimal(str(r["current_value"] or 0)) for r in rows)
    print(f"{len(rows)} policies among the holdings, "
          f"₹{total:,.0f} counted as wealth that is not.\n")

    for row in rows:
        kind = kind_of(row["instrument_name"])
        note = ("cover, worth nothing while alive" if kind in ("term_life", "health")
                else "may be cover or surrender value — flagged for checking")
        print(f"  {row['display_name'][:18]:<18} "
              f"{(row['instrument_name'] or '')[:34]:<34} "
              f"₹{Decimal(str(row['current_value'] or 0)):>14,.0f}")
        print(f"  {'':<18} -> {kind}, {note}")
        print()

    if not args.move:
        print("Nothing changed. Pass --move to do it.")
        return

    moved = 0
    for row in rows:
        kind = kind_of(row["instrument_name"])
        with db.connection() as conn:
            conn.execute(
                """
                INSERT INTO protection
                    (investor_id, kind, insurer, cover_amount, notes)
                SELECT %s, %s, %s, %s, %s
                WHERE NOT EXISTS (
                    SELECT 1 FROM protection
                    WHERE investor_id = %s AND insurer = %s)
                """,
                (row["investor_id"], kind, row["instrument_name"],
                 row["current_value"],
                 "Moved from holdings, where it was being counted as wealth. "
                 + ("Recorded as cover. If this figure was a surrender value "
                    "rather than a sum assured, correct it."
                    if kind in ("endowment", "ulip") else ""),
                 # The guard against running this twice.
                 row["investor_id"], row["instrument_name"]),
            )
            # A zero snapshot dated today rather than a delete.
            #
            # holding_snapshots is a history and v_current_holdings takes the
            # latest row per folio, so writing a zero makes the policy vanish
            # from current holdings while what was recorded before stays
            # recorded. Deleting would erase the fact that this was ever
            # entered, which is exactly what somebody would want to see when
            # they wonder where their insurance went.
            conn.execute(
                """
                INSERT INTO holding_snapshots
                    (investor_id, account_id, instrument_id, as_of, source,
                     quantity, current_value, invested_value)
                SELECT investor_id, account_id, instrument_id, current_date,
                       source, 0, 0, 0
                FROM holding_snapshots
                WHERE investor_id = %s AND instrument_id = %s
                ORDER BY as_of DESC LIMIT 1
                ON CONFLICT (account_id, instrument_id, as_of, source)
                DO UPDATE SET quantity = 0, current_value = 0,
                              invested_value = 0
                """,
                (row["investor_id"], row["instrument_id"]),
            )
        moved += 1

    print(f"Moved {moved} policies. Their sum assured no longer counts as "
          f"wealth, and the allocation percentages will change accordingly.")
    pool.close()


if __name__ == "__main__":
    main()
