"""Bring directly held shares up to today's prices.

Holdings imported from a file sit at cost until something prices them. Worth
running after market close on a weekday; quotes fall back to the last close
outside market hours, which the service says plainly rather than pretending.

    python scripts_price_equities.py
    python scripts_price_equities.py --investor <id>
"""

from __future__ import annotations

import argparse

from api import db
from api.services import navs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--investor", help="just this one")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    if args.investor:
        targets = [{"id": args.investor, "display_name": args.investor}]
    else:
        targets = db.fetch_all(
            """
            SELECT DISTINCT i.id, i.display_name
            FROM investors i
            JOIN v_current_holdings v ON v.investor_id = i.id
            JOIN instruments ins ON ins.id = v.instrument_id
            WHERE ins.asset_class = 'equity' AND ins.symbol IS NOT NULL
            """
        )

    if not targets:
        print("Nobody holds shares directly.")
        return

    for target in targets:
        result = navs.price_equities(target["id"])
        print(f"  {target['display_name'][:30]:<30} "
              f"{result['priced']} priced, {result['skipped']} skipped")

    pool.close()


if __name__ == "__main__":
    main()
