"""Bring every holding up to today's prices.

Funds from the NAV history we hold, shares from the live feed. Both written as
snapshots rather than computed at read time, so a holding shows the same figure
whether something reads it alone or sums it with the rest.

Worth running after market close, and after any run of
scripts_rematch_instruments.py -- a holding matched to a scheme for the first
time has never been priced.

    python scripts_price_holdings.py
    python scripts_price_holdings.py --investor <id>
"""

from __future__ import annotations

import argparse

from api import db
from api.services import navs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--investor")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    if args.investor:
        investors = [{"id": args.investor, "display_name": args.investor}]
    else:
        investors = db.fetch_all(
            "SELECT DISTINCT i.id, i.display_name FROM investors i "
            "JOIN v_current_holdings v ON v.investor_id = i.id"
        )

    for investor in investors:
        funds = navs.price_funds(investor["id"])
        try:
            shares = navs.price_equities(investor["id"])
        except Exception as err:
            shares = {"priced": 0, "skipped": 0, "why": str(err)[:60]}

        print(f"  {investor['display_name'][:28]:<28} "
              f"funds {funds['priced']} priced / {funds['skipped']} skipped, "
              f"shares {shares['priced']} / {shares['skipped']}")
        if funds["skipped"]:
            print(f"      {funds['skipped']} funds have no NAV history "
                  f"— run scripts_load_navs.py")

    pool.close()


if __name__ == "__main__":
    main()
