"""Match fund holdings that were never resolved to a scheme.

A holding with no scheme code cannot be priced. It shows whatever the statement
last said, which for a position held two years reads as a catastrophic loss --
DSP Large & Mid Cap showed as down 97% because nothing had ever repriced it.

Fourteen of forty-nine fund holdings were in that state, because
`resolve_instrument` never consulted the AMFI master: it tried the ISIN, then
the scheme code, then whether we already held the same fund, and created a
placeholder if all three missed.

    python scripts_rematch_instruments.py            # report only
    python scripts_rematch_instruments.py --commit
"""

from __future__ import annotations

import argparse

from api import db
from api.services.statement_mapper import _match_scheme


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", action="store_true",
                        help="write the matches; otherwise only report them")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    unmatched = db.fetch_all(
        """
        SELECT i.id, i.name, i.native_code,
               coalesce(sum(v.current_value), 0) AS held
        FROM instruments i
        LEFT JOIN v_current_holdings v ON v.instrument_id = i.id
        WHERE i.asset_class = 'mutual_fund'
          AND (i.native_code IS NULL OR i.native_code LIKE 'name:%%')
        GROUP BY i.id, i.name, i.native_code
        ORDER BY held DESC
        """
    )

    if not unmatched:
        print("Every fund holding is matched.")
        return

    print(f"{len(unmatched)} unmatched fund instruments\n")

    matched = 0
    still_not = []

    with db.connection() as conn:
        for row in unmatched:
            found = _match_scheme(conn, row["name"], "")
            if not found:
                still_not.append(row)
                continue

            # Another instrument may already carry this code, in which case the
            # holdings belong on that one rather than a second copy of it.
            existing = conn.execute(
                "SELECT id FROM instruments WHERE asset_class = 'mutual_fund' "
                "AND native_code = %s AND id <> %s",
                (found["native_code"], row["id"]),
            ).fetchone()

            note = " (plan assumed)" if found.get("plan_assumed") else ""
            where = " -> merges into existing" if existing else ""
            print(f"  {row['name'][:52]:<52} -> {found['native_code']}{note}{where}")
            print(f"      {found['name'][:70]}")

            if args.commit:
                if existing:
                    # Move the holdings and transactions across, then drop the
                    # duplicate. Two rows for one fund would double-count it.
                    conn.execute(
                        "UPDATE holding_snapshots SET instrument_id = %s WHERE instrument_id = %s",
                        (existing["id"], row["id"]))
                    conn.execute(
                        "UPDATE canonical_transactions SET instrument_id = %s WHERE instrument_id = %s",
                        (existing["id"], row["id"]))
                    conn.execute("DELETE FROM instruments WHERE id = %s", (row["id"],))
                else:
                    conn.execute(
                        """
                        UPDATE instruments
                        SET native_code = %s,
                            isin = coalesce(isin, %s),
                            attributes = coalesce(attributes, '{}'::jsonb)
                                       || jsonb_build_object(
                                            'matched_by', 'name',
                                            'plan_assumed', %s::boolean)
                        WHERE id = %s
                        """,
                        (found["native_code"], found.get("isin"),
                         bool(found.get("plan_assumed")), row["id"]))
            matched += 1

    print()
    print(f"  {matched} matched, {len(still_not)} still unmatched")
    if still_not:
        print("\n  Left alone:")
        for row in still_not:
            print(f"    {row['name'][:64]}")
        print("\n  These are either not mutual funds at all -- an AIF or a PMS "
              "\n  will not be in the AMFI list -- or the statement did not name "
              "\n  enough to tell two schemes apart. Both are better left "
              "\n  unmatched than attached to the wrong fund.")

    if matched and not args.commit:
        print("\n  Nothing written. Run again with --commit.")
    elif matched:
        print("\n  Written. Load NAVs next so the new matches can be priced:")
        print("    python scripts_load_navs.py")

    pool.close()


if __name__ == "__main__":
    main()
