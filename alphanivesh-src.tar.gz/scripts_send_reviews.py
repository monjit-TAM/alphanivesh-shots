"""Sending the reviews.

Run from cron once a day. It asks who is owed a review and has something worth
saying, writes each one, sends it, and records that it went.

    python scripts_send_reviews.py            # who would get one, and what
    python scripts_send_reviews.py --send     # send them

**Nothing goes out that has nothing in it.** `cadence.due()` already enforces
both conditions -- the rhythm has come round and something happened -- and this
does not override either. A quarterly reader with a quiet quarter gets nothing,
which is the feature: a review arriving on schedule with nothing in it teaches
somebody to ignore the next one, and the next one may be the one that mattered.

**One send per person per run, and the run is idempotent.** `mark_sent` moves
the clock forward, so a job that runs twice by accident does not mail twice.
And a failure to send does not mark, so the next run tries again rather than
skipping a quarter.

**Failures are loud and do not stop the run.** One investor whose figures will
not compute should not prevent the other two hundred from hearing anything.

## Installing it

    # every weekday at 9am IST
    0 9 * * 1-5 cd /opt/alphawealth && ./run.sh scripts_send_reviews.py --send \\
        >> /var/log/alphanivesh-reviews.log 2>&1

Daily rather than weekly because the cadence is per person: somebody on monthly
and somebody on annual both become due on their own day, and a weekly job would
delay whoever came due on a Tuesday.
"""

from __future__ import annotations

import argparse
import logging
import sys
import traceback
from datetime import datetime

from api import db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("reviews")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--send", action="store_true",
                        help="actually send. Without it, nothing leaves.")
    parser.add_argument("--only", help="one investor id, for testing")
    args = parser.parse_args()

    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=20)

    from api.services import cadence, mail, review

    if args.send and not mail.configured():
        log.error("SENDGRID_API_KEY is not set. Nothing can be sent.")
        sys.exit(1)

    if args.only:
        owed = [{"investor_id": args.only, "name": "(named)"}]
    else:
        owed = cadence.everybody_due()

    if not owed:
        log.info("Nobody is owed a review with anything worth saying.")
        return

    log.info("%d owed a review", len(owed))

    sent = skipped = failed = 0

    for who in owed:
        investor_id = who["investor_id"]
        name = who.get("name") or investor_id

        try:
            written = review.assemble(investor_id, force=bool(args.only))
        except Exception:
            log.error("could not write the review for %s", name)
            traceback.print_exc()
            failed += 1
            continue

        if not written:
            log.info("  %s — nothing worth saying", name)
            skipped += 1
            continue

        address = _address_for(investor_id)
        if not address:
            log.warning("  %s — no email address on file", name)
            skipped += 1
            continue

        if not args.send:
            log.info("  %s → %s", name, address)
            log.info("      %s", written["subject"])
            for section in written["sections"]:
                log.info("      · %s (%d)", section["title"],
                         len(section["items"]))
            sent += 1
            continue

        result = mail.send(
            address, written["subject"],
            review.as_html(written),
            text=review.as_text(written),
            kind="review", investor_id=investor_id)

        if result.get("sent"):
            # Only once it has actually left. Marking before would skip a
            # quarter every time SendGrid had a bad afternoon.
            cadence.mark_sent(investor_id)
            _record(investor_id, written)
            log.info("  %s → %s  sent", name, address)
            sent += 1
        else:
            log.error("  %s → %s  FAILED: %s", name, address,
                      result.get("why"))
            failed += 1

    log.info("%s: %d sent, %d skipped, %d failed",
             "done" if args.send else "dry run", sent, skipped, failed)

    if failed:
        # A non-zero exit so cron mails somebody about it rather than the
        # failure sitting in a log nobody reads.
        sys.exit(2)


def _address_for(investor_id: str) -> str | None:
    """Where to send it.

    The investor's own address where there is one, falling back to the account
    that owns the portfolio. A portfolio loaded directly with no account has
    neither, and gets skipped rather than guessed at.
    """
    row = db.fetch_one(
        """
        SELECT coalesce(i.email, u.email) AS address
        FROM investors i
        LEFT JOIN users u ON u.id = i.owner_user_id
        WHERE i.id = %s
        """,
        (investor_id,))
    return (row or {}).get("address")


def _record(investor_id: str, written: dict) -> None:
    """Into the ledger, like everything else somebody was shown."""
    try:
        from api.services import ledger
        ledger.record(
            investor_id, "notification",
            said={"subject": written["subject"],
                  "sections": [{"title": s["title"],
                                "items": [i["headline"] for i in s["items"]]}
                               for s in written["sections"]]},
            basis={"covers_days": written["covers_days"],
                   "cadence": written["cadence"],
                   "sent_on": datetime.now().isoformat()},
            surface="review")
    except Exception:                                            # pragma: no cover
        log.error("review sent but not recorded for %s", investor_id)
        traceback.print_exc()


if __name__ == "__main__":
    main()
