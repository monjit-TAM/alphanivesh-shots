"""Holdings we never matched to a scheme.

An unresolved holding carries a value from whatever statement mentioned it and
is never repriced, so it sits in a portfolio at a figure that ages quietly. It
also counts as a distinct instrument everywhere, which inflates position counts
and concentration figures built on them.

Listing them is the first step to fixing them; the second is a person deciding
what each one actually is, which is not something to guess at.
"""

from __future__ import annotations

from api import db

# psycopg reads % as a placeholder marker whether or not the query takes
# parameters, so a literal LIKE pattern has to double it. Recorded in the
# handover and hit a fourth time regardless -- always in a script rather than
# in service code, which is exactly where nobody thinks to be careful.


def main() -> None:
    pool = db.get_pool()
    pool.open()
    pool.wait(timeout=15)

    rows = db.fetch_all(
        """
        SELECT inv.display_name, i.name, i.asset_class, i.native_code,
               v.quantity, round(v.current_value) AS value,
               round(v.current_value / nullif(v.quantity, 0), 2) AS per_unit
        FROM v_current_holdings v
        JOIN instruments i ON i.id = v.instrument_id
        JOIN investors inv ON inv.id = v.investor_id
        WHERE v.current_value > 0
          -- Unresolved means we could not identify it, which differs by kind:
          -- a share is identified by its symbol, a fund by its AMFI code. The
          -- first version tested both against native_code and reported eleven
          -- perfectly good equities as unresolved.
          AND (
            (i.asset_class = 'equity' AND i.symbol IS NULL)
            OR (i.asset_class <> 'equity'
                AND (i.native_code IS NULL OR i.native_code LIKE 'name:%%'))
          )
        ORDER BY v.current_value DESC
        """
    )

    if not rows:
        print("Every holding is matched to a scheme.")
        return

    total = sum(float(r["value"] or 0) for r in rows)
    print(f"{len(rows)} unresolved holdings, ₹{total:,.0f} between them.\n")

    for row in rows:
        print(f"  {row['display_name'][:18]:<18} {(row['name'] or '')[:44]:<44}")
        print(f"  {'':<18} {row['quantity']} units, ₹{row['value']:,} "
              f"(₹{row['per_unit']}/unit) — {row['asset_class']}")
        print()

    print("Each needs somebody to say what it actually is. Until then the "
          "value is whatever the statement said, however long ago that was.")

    pool.close()


if __name__ == "__main__":
    main()
