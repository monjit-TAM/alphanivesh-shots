# Looking at the pages

`render.py` serves the web directory to a headless browser, stubs the API with
data shaped like a real portfolio, and takes screenshots.

    pip install playwright --break-system-packages
    playwright install chromium

    cd tools && python render.py                 # every view
    python render.py risk cost                   # named views only

Shots land in the working directory as `desk-<view>.png` and
`phone-<view>.png`.

## Why it exists

Four rounds of CSS changes were made in one evening without anybody looking at
the result, and two of them fixed the wrong thing. The bugs it found in twenty
minutes afterwards, none of which were visible in the code:

- `.band` was already the asset-class filter strip — 60px tall with
  `overflow:hidden` — so reusing the name clipped every view to the height of
  a filter bar.
- `.verdict` was already the buy/hold label, and `text-transform` inherits, so
  a whole section rendered in capitals.
- `min-height:100%` on a grid item whose row is auto-sized has nothing
  definite to resolve against, and collapsed the hero to its eyebrow.
- `.mast-nav a` is one class plus one element, which outranks `.nav-advice` —
  so white text lost to the nav's grey and a filled button read muted.

Every one of those is invisible when reading the code and obvious in a
screenshot.

## The stub

The data in `render.py` is shaped from real payloads: the same field names, the
same string lengths, the same array sizes. That matters more than the values —
a grid breaks on a long fund name, not on a wrong rupee figure.

When a page changes shape, the stub needs the new fields or the page renders
its error state. That is the maintenance cost and it is small next to a round
of blind edits.
