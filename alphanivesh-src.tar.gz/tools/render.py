"""Look at the page.

Every CSS decision in the last three hours was made without seeing the result,
which is why two rounds of fixes did not fix it. This renders the real markup
and the real script against data shaped like a real portfolio, and takes
pictures.

The data is a stub rather than the live API — the point is the layout, and the
layout does not care whether Thermax is really worth ₹7.93 lakh. What it does
care about is that the strings are the right length, the arrays the right size,
and the numbers the right number of digits, because those are what break a
grid.
"""

import json
import re
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path("/tmp/render")

# Shaped from the real payloads seen on the droplet.
DATA = {
    "investor": {"id": "x", "display_name": "MONJIT GOGOI"},
    "as_of": "2026-08-29",
    "views": {"everything": {
        "headline": {"current": "3387247.55", "invested": "2038986.25",
                     "gain": "1348261.30", "positions": 23,
                     "return_pct": "66.12", "cagr_pct": "10.59",
                     "held_years": "5.0", "held_since": "2021-08-12",
                     "as_of": "2026-08-29", "priced_today": True},
        "movers": {
            "best": [{"name": "Apollo Micro Systems Limited", "symbol": "APOLLO",
                      "value": "775000", "gain": "751000", "gain_pct": "3129.2"},
                     {"name": "018G - SBI ELSS Tax Saver Fund - Regular Plan - Growth",
                      "value": "2055", "gain": "1782", "gain_pct": "651.3"},
                     {"name": "157 - DSP Small Cap Fund - Regular Plan - Growth",
                      "value": "2209", "gain": "1709", "gain_pct": "341.8"}],
            "worst": [{"name": "Ambuja Cements Limited", "value": "81290",
                       "gain": "-35750", "gain_pct": "-30.5"},
                      {"name": "Varun Beverages Limited", "value": "86340",
                       "gain": "-33524", "gain_pct": "-28.0"}]},
        "returns": {"xirr_pct": None, "transaction_coverage_pct": "0.0",
                    "xirr_unavailable_reason": "not enough cashflows"},
    }},
    "holdings": [
        {"instrument_id": f"h{i}", "instrument_name": name,
         "asset_class": kind, "quantity": str(q),
         "current_value": str(v), "invested_value": str(inv)}
        for i, (name, kind, q, v, inv) in enumerate([
            ("Thermax Limited", "equity", 200, 793000, 728200),
            ("Apollo Micro Systems Limited", "equity", 2000, 775000, 24000),
            ("Hindustan Aeronautics Limited", "equity", 100, 487500, 317080),
            ("GE Vernova T&D India Limited", "equity", 100, 414360, 303700),
            ("DLF Limited", "equity", 500, 341150, 160000),
            ("Canara Bank", "equity", 1000, 127570, 41590),
            ("273 - Franklin India Focused Equity Fund - Growth", "mutual_fund",
             1051, 107640, 33000),
            ("Varun Beverages Limited", "equity", 200, 86340, 119864),
            ("Ambuja Cements Limited", "equity", 200, 81290, 117040),
            ("Power Finance Corporation Limited", "equity", 200, 72580, 96380),
            ("Jio Financial Services Limited", "equity", 200, 48160, 65400),
            ("Adani Power Limited", "equity", 100, 20474, 14673),
            ("EQDG - Canara Robeco Large and Mid Cap Fund - Direct Growth",
             "mutual_fund", 17, 5152, 5000),
            ("IIFLFL 9.60 240628", "bond", 5, 5028, 0),
            ("FIVFG - HSBC Value Fund - Regular Growth (Formerly known as "
             "L&T India Value Fund - Growth)", "mutual_fund", 17, 1980, 500),
            ("168 - Kotak Flexicap Fund - Growth (Regular Plan) (Erstwhile "
             "Kotak Standard Multicap Fund - Gr)", "mutual_fund", 19, 1599, 500),
        ])],
    "findings": {"count": 4, "findings": [
        {"code": "sector_concentration", "severity": "act",
         "headline": "63% of your money is in capital goods",
         "detail": "₹20,56,027 sits in capital goods companies, counting "
                   "through what your funds hold as well as the shares you own "
                   "directly. Holdings that look separate can be the same bet: "
                   "when that industry has a bad year, most of your portfolio "
                   "has one.", "estimated": False},
        {"code": "single_holding", "severity": "consider",
         "headline": "23.4% of your portfolio is in one company",
         "detail": "Thermax Limited is worth ₹7,93,000, which is 23.4% of the "
                   "portfolio we hold for you.", "estimated": False},
        {"code": "top_five", "severity": "know",
         "headline": "Your five largest holdings are 83% of the total",
         "detail": "₹28,11,010 of ₹33,87,248 sits in five holdings out of 23.",
         "estimated": False},
    ], "summary": "2 things worth doing, 4 worth knowing about.",
       "worth_doing_now": [
        {"code": "sector_concentration", "severity": "act", "rank": 1,
         "action_verb": "Spread",
         "headline": "63% of your money is in capital goods",
         "detail": "₹20,56,027 sits in capital goods companies, counting "
                   "through what your funds hold as well as the shares you "
                   "own directly.",
         "why_this_order": "First because acting means selling, which has a "
                           "tax cost."},
        {"code": "single_holding", "severity": "consider", "rank": 2,
         "action_verb": "Decide about",
         "headline": "23.4% of your portfolio is in one company",
         "detail": "Thermax Limited is worth ₹7,93,000, which is 23.4% of the "
                   "portfolio we hold for you.",
         "why_this_order": "Then, because it only costs you if that part of "
                           "the market turns."}]},
    "sectors": {"attributed_share_pct": "96.5", "method": "Counting through.",
                "sectors": [{"sector": "Capital Goods", "share_pct": "63.0",
                             "value": "2056027"},
                            {"sector": "Industrials", "share_pct": "13.0",
                             "value": "440342"},
                            {"sector": "Realty", "share_pct": "10.0",
                             "value": "341150"},
                            {"sector": "Financial Services", "share_pct": "8.0",
                             "value": "271000"}]},
    "market_cap": {"large": "47.4", "mid": "26.0", "small": "23.1",
                   "multi": "3.5", "equity_value": "3382220"},
    "concentration": {"effective_holdings": "6.4", "positions": 23,
                      "reading": "somewhat concentrated"},
    "benchmark": {"ahead": True, "difference": "194337",
                  "index_value": "3192911", "your_value": "3387248",
                  "years": "5.0", "your_growth_pct": "66.1"},
    "tax": {"estimated_tax": "180648", "short_term_gain": "194397",
            "long_term_gain": "1259151", "exempt": "125000",
            "nearly_long_term": []},
    "value_shape": {"beta": "1.28", "dividend_yield": "1.45",
                    "debt_to_equity": "0.42", "covered": "11",
                    "market_is": "7% off its high", "market_from": "NIFTY"},
    "risk_radar": {"method": "Each axis scaled so a hundred is uncomfortable.",
                   "axes": [
        {"axis": "Resting on one industry", "score": "95",
         "reading": "63% in capital goods", "scale": "Share of the largest."},
        {"axis": "Away from your plan", "score": "72",
         "reading": "36 points from the mix you set", "scale": "Total drift."},
        {"axis": "Moves with the market", "score": "64",
         "reading": "beta 1.28", "scale": "Beta against NIFTYBEES."},
        {"axis": "How far it has fallen before", "score": "63",
         "reading": "45% at worst, weighted by holding", "scale": "Drawdown."},
        {"axis": "Resting on few holdings", "score": "31",
         "reading": "23 positions, spread like 6.4", "scale": "Herfindahl."}]},
    "tail": {"computable": True, "value_covered": "2967860",
             "coverage": {"days": 1254, "holdings": 21, "of_holdings": 23,
                          "from": "2021-08-23", "covered_pct": "99.9"},
             "daily": {"var_95": "76180", "var_99": "117874",
                       "shortfall_95": "106938", "var_95_pct": 2.6,
                       "var_99_pct": 4.0},
             "monthly": {"var_95": "349101", "var_99": "540217",
                         "shortfall_95": "490046"},
             "annual": {"var_95": "1209321", "var_99": "1871434",
                        "shortfall_95": "1697528"},
             "worst_day": {"loss": "286675", "pct": 9.66},
             "reading": "On about one day in twenty, this portfolio loses more "
                        "than ₹76,180 — that is 2.6% of what we can price.",
             "what_it_means": "Value at risk is a quantile of what these "
                              "holdings have actually done.",
             "on_scaling": "The monthly figure scales the daily one by the "
                           "square root of time.",
             "on_shortfall": "Expected shortfall is the average loss on the "
                             "days worse than the threshold."},
    "shocks": {"computable": True, "total": "3387248", "exposed": "3382220",
               "exposed_pct": "99.9", "beta": "1.28",
               "worst": "A global slowdown",
               "reading": "Of the six, a global slowdown would cost this "
                          "portfolio most: about ₹13,07,783, 38.6% of "
                          "everything you hold.",
               "method": "Each figure is the market fall scaled by beta.",
               "caveat": "Arithmetic over stated assumptions.",
               "shocks": [
        {"code": "global_recession", "name": "A global slowdown",
         "detail": "Demand falls worldwide.", "why": "Everything falls together.",
         "market_fall_pct": "-25", "your_fall_pct": "-38.7", "loss": "1307783",
         "loss_pct": "38.6", "left": "2079465", "severity": "high",
         "anchor": "March 2020.", "notable_sectors": [
             {"sector": "capital goods", "share_pct": "63.0",
              "sensitivity": "1.3", "direction": "worse"}]},
        {"code": "fii_outflow", "name": "Foreign investors leave",
         "detail": "Large institutional selling.", "why": "Foreign money "
         "concentrates in the largest names.", "market_fall_pct": "-15",
         "your_fall_pct": "-20.9", "loss": "706989", "loss_pct": "20.9",
         "left": "2680259", "severity": "high", "notable_sectors": []},
        {"code": "credit_event", "name": "A large default",
         "detail": "A major lender fails.", "why": "Lending stops.",
         "market_fall_pct": "-12", "your_fall_pct": "-19.0", "loss": "642671",
         "loss_pct": "19.0", "left": "2744577", "severity": "medium",
         "notable_sectors": []},
        {"code": "oil_shock", "name": "Oil rises by half",
         "detail": "Crude up fifty per cent.", "why": "India imports most of it.",
         "market_fall_pct": "-10", "your_fall_pct": "-14.5", "loss": "490584",
         "loss_pct": "14.5", "left": "2896664", "severity": "medium",
         "notable_sectors": []},
        {"code": "rate_hike", "name": "Interest rates rise sharply",
         "detail": "Repo up two points.", "why": "Borrowing costs more.",
         "market_fall_pct": "-8", "your_fall_pct": "-13.4", "loss": "453456",
         "loss_pct": "13.4", "left": "2933792", "severity": "medium",
         "notable_sectors": []},
        {"code": "currency", "name": "The rupee falls a tenth",
         "detail": "Ten per cent depreciation.", "why": "Importers pay more.",
         "market_fall_pct": "-5", "your_fall_pct": "-7.2", "loss": "243457",
         "loss_pct": "7.2", "left": "3143791", "severity": "low",
         "notable_sectors": []}]},
    "forward": {"computable": False,
                "observed_pct": "53.0",
                "why": "This portfolio's holdings returned about 53% a year "
                       "over the history we hold. That is a remarkable run "
                       "rather than a rate anything can be projected from.",
                "what_would_help": "A longer history, or a portfolio whose "
                                   "recent record is less extreme."},
    "cost_drag": {"total": "134796", "weighted_expense_pct": "1.70",
                  "annual_cost": "2292", "index_expense_pct": "0.3",
                  "assumed_return_pct": "12",
                  "over_time": [
        {"years": 5, "yours": "216442", "at_index_cost": "231338",
         "difference": "14896"},
        {"years": 10, "yours": "347557", "at_index_cost": "397065",
         "difference": "49508"},
        {"years": 15, "yours": "558074", "at_index_cost": "681527",
         "difference": "123453"},
        {"years": 20, "yours": "896166", "at_index_cost": "1169709",
         "difference": "273543"},
        {"years": 25, "yours": "1438966", "at_index_cost": "2007771",
         "difference": "568805"}],
                  "funds": [], "reading": "Your funds charge about 1.70% a "
                  "year between them, which is ₹2,292 on ₹1,34,796.",
                  "estimated": "Typical rates by category.",
                  "on_the_rate": "Both paths grow at 12% before costs."},
    "step_up": {"known": True, "monthly": "4000",
                "assumed_return_pct": "12", "poor_return_pct": "8",
                "paths": [
        {"step_up_pct": s, "by_year": [
            {"years": 20, "value": str(v), "invested": str(i),
             "if_worse": str(w)}]}
        for s, v, i, w in [(0, 3957021, 960000, 2360000),
                           (5, 5440642, 1587165, 3210000),
                           (10, 7876719, 2749200, 4620000),
                           (15, 11800000, 4900000, 6900000),
                           (20, 19026827, 8961024, 11000000)]],
                "reading": "You put in about ₹4,000 a month. Kept flat for "
                           "twenty years at 12%, that becomes ₹39,57,021.",
                "on_the_rate": "At 12% a year, which is not a promise."},
    "peers": {"computable": True, "in_top": 1, "in_bottom": 2,
              "money_in_bottom": "438125", "money_in_bottom_pct": "66.0",
              "reading": "2 of your 4 placeable funds sit in the bottom "
                         "quarter of their category — ₹4,38,125, 66% of what "
                         "you hold in funds.",
              "method": "Placed on rolling three-year returns.",
              "what_this_is_not": "Where a fund has been, not where it will be.",
              "unplaced": [{"name": "x", "value": "1", "why": "y"}],
              "funds": [
        {"name": "Axis Small Cap Fund - Regular Growth", "value": "332429",
         "share_pct": "37.4", "category": "Equity Scheme - Small Cap Fund",
         "rank": 23, "of": 25, "quartile": 4, "quartile_name": "bottom quarter",
         "percentile": "8", "roll3_median_pct": "18.2",
         "category_median_pct": "22.4", "reading": "23 of 25 in its category."},
        {"name": "K123-Kotak Midcap Fund-Growth", "value": "118098",
         "share_pct": "13.3", "category": "Equity Scheme - Mid Cap Fund",
         "rank": 18, "of": 27, "quartile": 3, "quartile_name": "third quarter",
         "percentile": "33", "roll3_median_pct": "16.9",
         "category_median_pct": "16.3", "reading": "18 of 27."},
        {"name": "P3443-ICICI Prudential Flexicap Fund", "value": "105298",
         "share_pct": "11.8", "category": "Equity Scheme - Flexi Cap Fund",
         "rank": 8, "of": 35, "quartile": 1, "quartile_name": "top quarter",
         "percentile": "77", "roll3_median_pct": "19.4",
         "category_median_pct": "17.1", "reading": "8 of 35."}]},
    "xirr": {"computable": False, "flows": 3,
             "why": "We hold 3 dated transactions for this portfolio.",
             "what_would_help": "Import an older statement."},
    "owed": {"recorded": False, "count": 0, "total": "0",
             "reading": "You have not told us what you owe.",
             "why_it_matters": "Without it we cannot say what you are worth."},
    "drift": {"in_line": False, "out_of_line": 3, "worst_gap_pct": "35.9",
              "set_at": "2026-01-01", "method": "Against the mix you set.",
              "lines": [{"asset_class": "equity", "now_pct": "95.9",
                         "target_pct": "60.00", "gap_pct": "35.9"}]},
    "allocation": [
        {"asset_class": "equity", "label": "Shares", "value": "3247424",
         "share_pct": "95.9"},
        {"asset_class": "mutual_fund", "label": "Mutual funds",
         "value": "134796", "share_pct": "4.0"},
        {"asset_class": "bond", "label": "Bonds", "value": "5028",
         "share_pct": "0.1"}],
    "protection": {
        "recorded": True,
        "life_cover": "36500000", "life_cover_reads": "\u20b93.65 crore",
        "health_cover": "0", "surrender_value": "0",
        "premiums_a_year": "48000",
        "policies": [
            {"label": "Term life", "insurer": "Term Cover",
             "cover_reads": "\u20b93.50 crore", "cover": "35000000"},
            {"label": "ULIP", "insurer": "ULIP",
             "cover_reads": "\u20b915.0 lakh", "cover": "1500000"}],
        "need": {"rule_of_thumb": None, "worked_out": None,
                 "how_worked_out": None,
                 "we_do_not_know": ["what you earn", "what you spend"]},
        "gap": None,
        "reading": "\u20b93.65 crore of life cover. Whether that is enough "
                   "depends on what you earn and what you spend, which we do "
                   "not know \u2014 so this is a figure rather than a verdict.",
        "on_value": "Cover is not counted as wealth anywhere on this platform.",
    },
    "structural": {"lines": []},
    "scenario": {"total": "3387248", "beta": "1.28", "falls": [],
                 "method": "x", "history": []},
}

ADVICE = {
    "investor": DATA["investor"], "as_of": "2026-08-30",
    "headline": {"reading": "Nothing urgent. 2 things are costing money for no "
                            "return, which is the next thing worth an hour."},
    "working": {"reading": "1 thing here is working.", "items": [
        {"headline": "You are ahead of the index by \u20b954,28,406",
         "detail": "The same money in an index fund would be \u20b947,58,842."}]},
    "not_working": {"reading": "5 things worth attention.", "items": []},
    "serious": {"reading": "1 of these could cost real money if left alone.",
                "items": []},
    "correct": {"reading": "3 steps, in the order they are worth doing.",
                "steps": []},
    "missed": {"reading": "1 thing available that nobody has taken.",
               "items": []},
    "missing": {"reading": "3 things this portfolio does not have.",
                "gaps": []},
    "holdings": {"reading": "11 of your 11 shares, seen three ways.",
                 "rows": []},
    "cannot_say": {"reading": "4 things we could not see.", "items": []},
    "after": None, "redeploy": None,
    "can_you_hold_it": None, "market": None,
}

GUIDE = {
    "investor": DATA["investor"],
    "standing": {"reading": "You hold ₹33,87,247 across 23 positions, against "
                            "₹20,38,986 put in. Between the first holding we "
                            "can date and today, that is growth of 10.59% a "
                            "year over 5.0 years.",
                 "headline": "x", "benchmark": {}},
    "wrong": {"reading": "5 things stand out. The largest is that 63% of your "
                         "money is in capital goods.", "problems": []},
    "first": {"do": "Spread: 63% of your money is in capital goods",
              "why": "₹20,56,027 sits in capital goods companies.",
              "before": "First because acting means selling."},
    "route": {"reading": "You have not told us what the money is for.",
              "goals": []},
    "unseen": {"reading": "3 things we could not see.", "gaps": [
        {"what": "What you actually earned on the money as it went in",
         "why": "The growth figure measures value between two dates.",
         "fix": "Import an older statement."}]},
}

DECISION = {
    "health": {"reading": "Nothing urgent and nothing leaking. 3 things about "
                          "the shape worth looking at when you have time.",
               "working": ["The portfolio is ahead of what went into it."]},
    "risk": {"name": "moderate", "why": "We do not know what you can sit "
                                        "through."},
    "actions": [], "withheld": [], "by_tier": [
        {"tier": 2, "name": "Fix what is leaking",
         "why_this_tier": "Money leaving for no return.",
         "actions": [
            {"what": "Realise ₹1,25,000 of long-term gain before March.",
             "why": "The allowance is annual and does not carry forward.",
             "how": "Sell about ₹1,28,995 of Apollo Micro Systems and buy back.",
             "impact": "About ₹15,625 this year.", "worth": "₹15,625"}]}],
    "data_quality": {"reading": "This rests on 1 of 9 things worth knowing."},
    "review_on": {"months": 6, "why": "Twice a year is enough."},
}


def stub_routes(page):
    """Answer the page's fetches with the shapes above."""
    def handle(route):
        url = route.request.url
        body = {}
        if "/dashboard/" in url:
            body = DATA
        elif "/recommendations/" in url:
            body = ADVICE
        elif "/guide/" in url:
            body = GUIDE
        elif "/decide/" in url:
            body = DECISION
        elif "/style" in url:
            body = {"stated": None, "leans": "growth", "readable": True,
                    "reading": "63% of your equity is priced above its sector. "
                               "That leans towards growth investing.",
                    "note": "This is what the holdings suggest, not a label.",
                    "styles": [
                        {"key": "value", "name": "Value",
                         "what": "Buying businesses for less than they seem to "
                                 "be worth, and waiting.", "leans": False},
                        {"key": "growth", "name": "Growth",
                         "what": "Paying up for businesses getting bigger "
                                 "quickly.", "leans": True},
                        {"key": "quantamental", "name": "Quantamental",
                         "what": "Waiting for the numbers and the price "
                                 "behaviour to agree.", "leans": False}]}
        elif "/away/" in url:
            body = {"nothing_to_report": True}
        elif "/wealth/investors" in url:
            body = {"count": 1, "investors": [DATA["investor"]]}
        elif url.endswith("/holdings"):
            body = {"holdings": DATA["holdings"]}
        elif "/auth/me" in url:
            body = {"user": {"id": "u", "email": "monjit@x.co", "role": "admin"},
                    "investor_count": 1}
        elif "/summaries" in url:
            body = {"summaries": {
                "h0": {"sortino": 1.06, "beta": 0.72,
                       "reading": "Moves about 22% a year."},
                "h1": {"sortino": 4.20, "beta": 1.28, "reading": "x"},
                "h6": {"sortino": 0.57, "demands_score": 47,
                       "demands_band": "DEMANDS DISCIPLINE", "reading": "y"}}}
        elif "/ways/" in url:
            body = {
              "with_alternatives": 2,
              "reading": "3 of the 5 things worth doing have more than one way "
                         "of doing them, and the cheapest is rarely the fastest.",
              "why_alternatives": "Most findings have three or four legitimate "
                  "answers with different costs. Which one is right depends on "
                  "things this platform does not know about you, so it sets out "
                  "the trade rather than picking for you.",
              "actions": [
                {"code": "sector_concentration", "tier": 3,
                 "what": "Spread: 63% of your money is in capital goods",
                 "why": "\u20b920,56,027 sits in capital goods companies, "
                        "counting through what your funds hold as well as the "
                        "shares you own directly.",
                 "worth": None,
                 "ways": {"default": "dilute", "ways": [
                    {"code": "sell_down",
                     "what": "Sell part of your capital goods and put the "
                             "proceeds elsewhere.",
                     "costs": "About \u20b92,64,000 in capital gains tax",
                     "gives_up": "Whatever the sold part does next, and the "
                                 "money is briefly out of the market.",
                     "choose_this_if": "The concentration keeps you up at "
                         "night, or it arrived by drift rather than by "
                         "decision and you would not choose it today."},
                    {"code": "dilute", "free": True,
                     "what": "Leave it alone and put new money everywhere else "
                             "until the share falls on its own.",
                     "costs": "Nothing. No sale, no tax, no brokerage.",
                     "gives_up": "Time. At \u20b924,000 a month it would take "
                                 "roughly 3 years to bring the share down "
                                 "meaningfully.",
                     "choose_this_if": "You are still adding money and the tax "
                         "on selling is more than the risk is costing you."},
                    {"code": "sell_weakest",
                     "what": "Sell the weakest holdings within capital goods "
                             "rather than the largest.",
                     "costs": "The same tax, and possibly more of it.",
                     "gives_up": "Less than selling the largest, if the "
                                 "ranking is right.",
                     "choose_this_if": "You want the concentration down but "
                         "hold specific convictions within it worth keeping."},
                    {"code": "leave_it", "free": True,
                     "what": "Decide the capital goods position is deliberate "
                             "and leave it.",
                     "costs": "Nothing today. The cost is what happens if that "
                              "part of the market has a bad few years.",
                     "gives_up": "Nothing, if the conviction is real and you "
                                 "can sit through the fall.",
                     "choose_this_if": "You know this industry, you chose the "
                         "position, and you have sat through a fall in it "
                         "before without selling."}],
                   "how_to_choose": "The fast options cost tax and the free "
                       "option costs time. Which is worth more depends on how "
                       "likely you think a bad year in capital goods is."}},
                {"code": "hold_something_reachable", "tier": 4,
                 "what": "There is nothing here you could turn into cash tomorrow.",
                 "why": "Something you can turn into cash in a day without "
                        "selling a holding at whatever price that morning offers.",
                 "worth": None,
                 "ways": {"default": "sell_to_fund", "ways": [
                    {"code": "new_money", "free": True,
                     "what": "Put new money into it rather than moving anything.",
                     "costs": "Nothing. No sale, no tax.",
                     "gives_up": "Time. The gap stays open until enough has "
                                 "accumulated.",
                     "choose_this_if": "You have money going in regularly."},
                    {"code": "sell_to_fund",
                     "what": "Sell something and move the proceeds here.",
                     "costs": "Capital gains tax on whatever is sold.",
                     "gives_up": "Whatever was sold.",
                     "choose_this_if": "The gap matters enough that waiting is "
                         "not acceptable \u2014 an emergency fund is usually "
                         "this case."}],
                   "how_to_choose": "Filling a gap with new money costs "
                       "nothing and takes time; filling it by selling costs "
                       "tax and takes a day."}},
              ]}
        elif "/methodology" in url:
            body = {"sections": []}
        elif "/language" in url:
            body = {"strings": {}}
        elif "/ariv/" in url and "suggestions" in url:
            body = {"suggestions": ["What should I do first?",
                                    "How much tax if I sell everything?",
                                    "What is my largest holding?"]}
        elif "/share/" in url:
            body = {"shares": []}
        route.fulfill(status=200, content_type="application/json",
                      body=json.dumps(body))
    page.route("**/api/**", handle)


def serve():
    """A server for the duration, in a thread.

    file:// gives a null origin, which breaks the page's API base and every
    fetch with it. Serving over http is the difference between rendering the
    page and rendering its skeleton.
    """
    import http.server, socketserver, threading, os
    os.chdir(HERE)
    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(
        ("127.0.0.1", 8899),
        lambda *a, **k: http.server.SimpleHTTPRequestHandler(
            *a, directory=str(HERE), **k))
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd


def main():
    views = sys.argv[1:] or ["standing", "todo", "mix", "holdings",
                             "risk", "cost", "account"]
    httpd = serve()

    with sync_playwright() as p:
        browser = p.chromium.launch()

        for width, label in ((1440, "desk"), (390, "phone")):
            page = browser.new_page(viewport={"width": width, "height": 1000},
                                    device_scale_factor=1)
            stub_routes(page)
            page.route("**/cdnjs.cloudflare.com/**",
                       lambda r: r.fulfill(status=200,
                                           content_type="application/javascript",
                                           body="window.jspdf={jsPDF:function(){}};"))
            page.route("**/api.fontshare.com/**",
                       lambda r: r.fulfill(status=200,
                                           content_type="text/css", body=""))
            page.goto("http://127.0.0.1:8899/dash.html")
            page.wait_for_timeout(2500)

            for view in views:
                # A hash-only change is same-document navigation and does not
                # reload, so every shot was the same view. Go elsewhere first.
                page.goto("http://127.0.0.1:8899/blank.html")
                page.goto(f"http://127.0.0.1:8899/dash.html#{view}")
                page.wait_for_timeout(2200)
                out = f"/tmp/render/{label}-{view}.png"
                page.screenshot(path=out, full_page=True)
                height = page.evaluate("document.body.scrollHeight")
                print(f"  {label:5} {view:9} {height:5}px  {out}")

            page.close()
        browser.close()
    httpd.shutdown()


if __name__ == "__main__":
    main()
