/* From a suggestion to an instruction.
 *
 * Four steps, and somebody can be at any one of them:
 *
 *   1. what you would be doing — everything, across all asset classes
 *   2. who places it — an adviser they have, one they choose, or themselves
 *   3. terms — where choosing somebody started a relationship
 *   4. confirm — the last screen before money moves
 *
 * **The steps are shown rather than hidden.** Knowing there are four is what
 * stops the second one feeling like an interruption, and somebody who wants to
 * stop at the first — read what it would take, decide not to — should be able
 * to see that stopping is allowed.
 *
 * The previous version put "no adviser is recorded for this investor" on the
 * advice page and stopped. True, and useless: somebody with no adviser has a
 * question to answer rather than a wall to read.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

/* Which groups somebody has chosen to act on.
 *
 * All of it or none was the only option, which is not how anybody decides
 * about their own money -- somebody may want the switches and not the loss
 * harvest, or one switch and not the other. Everything starts ticked, because
 * the engine thinks all of it is worth doing and unticking is the smaller
 * act; but nothing is placed that somebody did not leave ticked.
 */
const state = {at: 1, investorId: null, proposed: null, found: null,
               who: null, chosen: null, taking: new Set()};

const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
function frag(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

function money(value){
  const n = Math.round(Number(value) || 0);
  const negative = n < 0;
  let digits = String(Math.abs(n));
  if (digits.length > 3){
    let head = digits.slice(0, -3);
    const tail = digits.slice(-3);
    const parts = [];
    while (head.length > 2){ parts.unshift(head.slice(-2)); head = head.slice(0, -2); }
    if (head) parts.unshift(head);
    digits = parts.join(',') + ',' + tail;
  }
  return (negative ? '-\u20B9' : '\u20B9') + digits;
}

const CLASS_NAMES = {
  equity: 'Shares', mutual_fund: 'Mutual funds', etf: 'ETFs',
  bond: 'Bonds', gold: 'Gold', gsec: 'Government bonds',
  ppf_epf: 'PPF and EPF', other: 'Other',
};

function steps(){
  const names = ['What you would do', 'Who places it', 'Terms', 'Confirm'];
  const row = el('<div class="steps"></div>');

  names.forEach((name, i) => {
    const n = i + 1;
    const done = n < state.at;
    const step = el(`<span class="step ${
      n === state.at ? 'now' : done ? 'done' : ''}">
      <b>${done ? '\u2713' : n}</b>${esc(name)}</span>`);

    /* A step already passed can be gone back to.
     *
     * Forwards cannot: skipping "who places it" would leave the later steps
     * with nothing to work from. But somebody on the confirm screen who wants
     * to read the orders again should not have to start over, and on a page
     * about money that matters more than tidiness. */
    if (done){
      step.classList.add('back');
      step.addEventListener('click', () => { state.at = n; draw(); });
    }
    row.appendChild(step);
  });
  return row;
}

/* Only what is still ticked. Everything downstream reads this rather than
   the full list, so unticking a group means it is not consented to and not
   placed -- not merely greyed out on one screen. */
function taking(){
  return (state.found.orders || []).filter(o =>
    state.taking.has(String(o.from_action || o.because)));
}


/* ------------------------------------------------- 1. what you would do */

function whatYouWouldDo(){
  const box = $('act');
  const found = state.found;

  box.appendChild(frag(`
    <div class="confirm-head">
      <p class="eyebrow">Step one</p>
      <h1>What you would be doing</h1>
      <p>Everything the advice comes down to, across everything you hold.
      Nothing is placed by looking at this.</p>
    </div>`));

  if (!found.count){
    box.appendChild(el(`<div class="blocked">
      <h2>Nothing to place</h2>
      <p>The things worth doing right now are decisions rather than trades —
      whether to keep a position, whether a plan still fits. There is nothing
      here for a broker to execute.</p>
      <p style="margin-top:14px"><a href="/advice.html"
         style="color:var(--ox);font-weight:700;text-decoration:none">Back to
         what to do \u2192</a></p>
    </div>`));
    if (found.not_placeable && found.not_placeable.length){
      box.appendChild(notTrades(found.not_placeable));
    }
    return;
  }

  const wrap = el('<div class="by-class"></div>');
  Object.entries(found.by_class || {}).forEach(([kind, orders]) => {
    wrap.appendChild(el(`<p class="class-head">${
      esc(CLASS_NAMES[kind] || kind)}</p>`));
    wrap.appendChild(groupedOrders(orders));
  });
  box.appendChild(wrap);

  if (found.instead_of && found.instead_of.length){
    box.appendChild(insteadOf(found.instead_of));
  }

  if (found.not_placeable && found.not_placeable.length){
    box.appendChild(notTrades(found.not_placeable));
  }

  const chosen = taking().length;
  const go = el(`<div class="go">
    <button type="button" id="next" ${chosen ? '' : 'disabled'}>${
      chosen
        ? `Who places ${chosen === found.count ? 'this' : 'these ' + chosen}? \u2192`
        : 'Nothing chosen'}</button>
    <a href="/advice.html">Not now</a>
    ${chosen && chosen < found.count
      ? `<span class="clock">${found.count - chosen} left out</span>` : ''}
  </div>`);
  go.querySelector('#next').addEventListener('click', () => {
    if (!taking().length) return;
    state.at = 2;
    draw();
  });
  box.appendChild(go);
}

/* Orders grouped by the advice that produced them.
 *
 * A sell and a buy-back of the same holding read as a duplicate when they sit
 * as two rows repeating one sentence -- somebody sees Apollo twice and
 * reasonably asks why. They are two trades and one intention, and the page
 * should say the intention once with the trades under it.
 */
function groupedOrders(orders){
  const wrap = el('<div></div>');
  const groups = [];

  orders.forEach((o, i) => {
    const key = o.from_action || o.because || ('one' + i);
    const found = groups.find(g => g.key === key);
    if (found) found.orders.push(o);
    else groups.push({key, because: o.because, orders: [o]});
  });

  // Everything is in until somebody takes it out.
  groups.forEach(g => {
    if (!state.touched) state.taking.add(String(g.key));
  });
  state.touched = true;

  groups.forEach(group => {
    const key = String(group.key);
    if (!state.taking.size) { /* first draw: everything is in */ }

    const head = el('<div class="group-head"></div>');
    const tick = el(`<label class="group-tick">
      <input type="checkbox" ${state.taking.has(key) ? 'checked' : ''}>
      <span>${group.because ? esc(group.because) : 'These orders'}</span>
    </label>`);
    tick.querySelector('input').addEventListener('change', e => {
      if (e.target.checked) state.taking.add(key);
      else state.taking.delete(key);
      draw();
    });
    head.appendChild(tick);
    wrap.appendChild(head);

    const list = el('<div class="orders"></div>');
    if (!state.taking.has(key)) list.classList.add('left-out');
    group.orders.forEach(o => list.appendChild(orderRow(o)));
    wrap.appendChild(list);

    /* What it costs, on the screen where somebody decides.
     *
     * The engine says brokerage twice and a day or two out of the market, and
     * this page was showing only the saving. A page that shows what a thing is
     * worth and not what it costs is selling rather than advising, and this is
     * the last screen before it becomes an instruction. */
    const first = group.orders[0] || {};
    if (first.how || first.risk){
      const caveat = el('<div class="caveat"></div>');
      if (first.how) caveat.appendChild(el(`<p>${esc(first.how)}</p>`));
      if (first.risk) caveat.appendChild(el(`<p class="cost">${
        esc(first.risk)}</p>`));
      wrap.appendChild(caveat);
    }

    const names = group.orders.map(o => o.name);
    const sides = new Set(group.orders.map(o => o.side));
    if (group.orders.length === 2 && sides.size === 2
        && names[0] === names[1]){
      wrap.appendChild(el(`<p class="round-trip">Sold and bought straight back,
        so you end up holding the same thing. The point is the tax, not the
        position.</p>`));
    }
  });

  return wrap;
}


function orderRow(o){
  const quantity = o.quantity ? `${o.quantity} units` : '';
  const at = o.price ? `at about \u20B9${o.price}` : '';
  const note = o.note ? esc(o.note) : '';
  /* A switch is a third thing. Showing it as a sell would say the money
     leaves the market, and it does not -- the AMC moves the holding from one
     plan to the other and the position is unbroken. */
  const side = o.side === 'switch' ? 'switch' : o.side;
  return el(`<div class="order">
    <span class="order-side ${esc(side)}">${esc(side)}</span>
    <div class="order-what">
      <b>${esc(o.name || o.symbol || '')}</b>
      <span>${esc([quantity, at].filter(Boolean).join(' \u00b7 '))}${
        note ? ' \u00b7 ' + note : ''}</span>
    </div>
    <div class="order-money">
      <b>${money(o.est_cost || o.amount)}</b>
      ${Number(o.est_tax) > 0 ? `<span>${money(o.est_tax)} tax</span>` : ''}
    </div>
  </div>`);
}

/* What was set aside, and why.
 *
 * Two suggestions can want the same holding -- sell it to realise a loss, or
 * switch it to the direct plan -- and only one can be done. Hiding the one
 * that lost would make the engine look more decisive than it is, and the
 * reason is often the more useful half: somebody may prefer the option we did
 * not take, and should be able to see that it existed.
 */
function insteadOf(items){
  const box = el('<div class="instead"></div>');
  box.appendChild(el(`<p class="instead-head">Two suggestions wanted the same
    holding. These are the ones not on the list:</p>`));

  items.forEach(item => {
    box.appendChild(frag(`
      <div class="instead-one">
        <b>${esc(item.side)} ${esc(item.name || '')}</b>
        ${item.because ? `<span>${esc(item.because)}</span>` : ''}
        <p>${esc(item.why_not)}</p>
      </div>`));
  });
  return box;
}


/* Things worth doing that are not trades. Said, because a list showing three
   of the seven things looks complete and is not. */
function notTrades(items){
  const box = el('<div class="not-trades"></div>');

  const decisions = items.filter(i => i.kind === 'decision');
  const unwired = items.filter(i => i.kind !== 'decision');

  /* Two lists, because they mean different things. One is a judgement that
     needs nobody to place anything; the other is a trade we cannot yet turn
     into an order, which is our shortcoming rather than a fact about the
     advice. Saying so is better than calling a loss harvest a decision. */
  if (decisions.length){
    box.appendChild(el(`<p>These are decisions rather than trades, so there is
      nothing to place:</p>`));
    const list = el('<ul></ul>');
    decisions.slice(0, 5).forEach(i =>
      list.appendChild(el(`<li>${esc(i.what || '')}</li>`)));
    box.appendChild(list);
  }

  if (unwired.length){
    box.appendChild(el(`<p style="margin-top:${decisions.length ? '14px' : '0'}">
      These are trades and we cannot yet turn them into orders you could place.
      They are worth doing; you would have to place them yourself for now:</p>`));
    const list = el('<ul></ul>');
    unwired.slice(0, 5).forEach(i =>
      list.appendChild(el(`<li>${esc(i.what || '')}</li>`)));
    box.appendChild(list);
  }

  return box;
}

/* ------------------------------------------------------ 2. who places it */

function whoPlacesIt(){
  const box = $('act');
  const who = state.who;

  box.appendChild(frag(`
    <div class="confirm-head">
      <p class="eyebrow">Step two</p>
      <h1>Who places this?</h1>
      <p>${esc(who.reading)}</p>
    </div>`));

  const list = el('<div class="whos"></div>');
  (who.choices || []).forEach((choice, i) => {
    const value = choice.professional_id || choice.how;
    list.appendChild(el(`<label class="who-one">
      <input type="radio" name="who" value="${esc(value)}"
             data-how="${esc(choice.how)}" ${i === 0 ? 'checked' : ''}>
      <div class="who-top">
        <b>${esc(choice.name)}</b>
        ${choice.kind ? `<span class="who-kind">${esc(choice.kind)}</span>` : ''}
      </div>
      <p>${esc(choice.what_it_means)}</p>
      ${choice.registration_no
        ? `<p class="reg">${esc(choice.registration_no)}</p>` : ''}
    </label>`));
  });
  box.appendChild(list);

  const go = el(`<div class="go">
    <button type="button" id="pick">Continue \u2192</button>
    <a href="#" id="back">Back</a></div>`);

  go.querySelector('#back').addEventListener('click', e => {
    e.preventDefault();
    state.at = 1;
    draw();
  });

  go.querySelector('#pick').addEventListener('click', async () => {
    const picked = document.querySelector('input[name="who"]:checked');
    if (!picked) return;
    const how = picked.dataset.how;

    if (how === 'yourself'){
      state.at = 4;
      state.chosen = {how: 'yourself'};
      draw();
      return;
    }

    if (how === 'current'){
      state.chosen = {how: 'current'};
      state.at = 3;
      draw();
      return;
    }

    /* Choosing somebody starts a relationship, so it is recorded before the
       next step rather than at the end -- a person who gets to the terms and
       stops has still chosen, and the record should say so. */
    const button = go.querySelector('#pick');
    button.disabled = true;
    try{
      const done = await fetch(`${API}/placing/${state.investorId}/who`, {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({professional_id: picked.value}),
      }).then(async r => {
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail
                                   || 'That did not work.');
        return r.json();
      });
      state.chosen = {how: 'new', ...done};
      state.at = 3;
      draw();
    }catch(err){
      box.appendChild(el(`<p class="act-why" style="color:var(--loss)">${
        esc(err.message)}</p>`));
      button.disabled = false;
    }
  });

  box.appendChild(go);
}

/* ------------------------------------------------------------- 3. terms */

async function terms(){
  const box = $('act');

  box.appendChild(frag(`
    <div class="confirm-head">
      <p class="eyebrow">Step three</p>
      <h1>Terms</h1>
    </div>`));

  try{
    const needed = await fetch(
      `${API}/agreement/needed/${state.investorId}`, {credentials: 'include'})
      .then(r => r.json());

    if (!needed.needed){
      box.appendChild(el(`<div class="blocked">
        <h2>Nothing to sign</h2>
        <p>${esc(needed.why || 'Terms are already agreed.')}</p>
      </div>`));
      const go = el(`<div class="go">
        <button type="button" id="next">Continue \u2192</button>
        <a href="#" id="back">Back</a></div>`);
      go.querySelector('#next').addEventListener('click', () => {
        state.at = 4; draw();
      });
      go.querySelector('#back').addEventListener('click', e => {
        e.preventDefault(); state.at = 2; draw();
      });
      box.appendChild(go);
      return;
    }

    const text = await fetch(`${API}/agreement/${needed.kind}`,
                             {credentials: 'include'})
      .then(r => r.ok ? r.json() : null);

    /* The honest state today: the terms exist as a placeholder and cannot be
       agreed to. Saying so beats a form that pretends otherwise. */
    box.appendChild(el(`<div class="blocked">
      <h2>Not ready yet</h2>
      <p>${esc(needed.why || '')}</p>
      <p style="margin-top:12px">${esc(
        (text && text.warning)
        || 'The agreement has not been finalised, so it cannot be signed. '
         + 'Nothing can be placed through an adviser until it is.')}</p>
      <p style="margin-top:14px">You can still take the orders to your own
      broker — nothing about that needs an agreement with anybody here.</p>
    </div>`));

    const go = el(`<div class="go">
      <button type="button" id="slip">Take the orders elsewhere \u2192</button>
      <a href="#" id="back">Back</a>
      <a href="/advice.html">Not now</a></div>`);
    go.querySelector('#back').addEventListener('click', e => {
      e.preventDefault(); state.at = 2; draw();
    });
    go.querySelector('#slip').addEventListener('click', () => {
      state.chosen = {how: 'yourself'};
      state.at = 4;
      draw();
    });
    box.appendChild(go);
  }catch(err){
    box.appendChild(el(`<div class="blocked"><h2>Could not load the terms</h2>
      <p>${esc(err.message)}</p></div>`));
  }
}

/* ----------------------------------------------------------- 4. confirm */

async function confirm(){
  const box = $('act');

  if ((state.chosen || {}).how === 'yourself'){
    box.appendChild(frag(`
      <div class="confirm-head">
        <p class="eyebrow">Step four</p>
        <h1>The orders, to take elsewhere</h1>
        <p>Nothing here has been placed and nothing about your account has
        changed. This is the list, written out.</p>
      </div>`));

    try{
      const slip = await fetch(`${API}/placing/${state.investorId}/slip`, {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({orders: taking()}),
      }).then(r => r.text());

      box.appendChild(el(`<div class="slip">${esc(slip)}</div>`));

      const go = el(`<div class="go">
        <button type="button" id="copy">Copy</button>
        <a href="#" id="back">Back</a>
        <a href="/advice.html">Done</a></div>`);
      go.querySelector('#back').addEventListener('click', e => {
        e.preventDefault(); state.at = 2; draw();
      });
      go.querySelector('#copy').addEventListener('click', e => {
        navigator.clipboard?.writeText(slip);
        e.target.textContent = 'Copied';
      });
      box.appendChild(go);
    }catch(err){
      box.appendChild(el(`<p class="act-why">${esc(err.message)}</p>`));
    }
    return;
  }

  // Through an adviser: the existing confirm screen does this properly, and
  // duplicating it here would give two places to keep in step.
  try{
    sessionStorage.setItem('proposed', JSON.stringify({
      investor_id: state.investorId,
      ledger_id: state.proposed.ledger_id || null,
      orders: taking(),
    }));
  }catch(err){}
  location.href = '/confirm.html';
}

/* -------------------------------------------------------------- drawing */

function draw(){
  const box = $('act');
  box.innerHTML = '';
  box.appendChild(steps());

  if (state.at === 1) whatYouWouldDo();
  else if (state.at === 2) whoPlacesIt();
  else if (state.at === 3) terms();
  else confirm();

  window.scrollTo({top: 0, behavior: 'instant'});
}

async function start(){
  let proposed = null;
  try{
    proposed = JSON.parse(sessionStorage.getItem('proposed') || 'null');
  }catch(err){}

  if (!proposed || !proposed.investor_id){
    $('act').innerHTML = '';
    $('act').appendChild(el(`<div class="blocked">
      <h2>Nothing to act on</h2>
      <p>This page follows on from a recommendation. Open it from the advice
      rather than directly.</p>
      <p style="margin-top:14px"><a href="/advice.html"
         style="color:var(--ox);font-weight:700;text-decoration:none">What to
         do now \u2192</a></p>
    </div>`));
    return;
  }

  state.proposed = proposed;
  state.investorId = proposed.investor_id;

  try{
    /* Everything the advice implies, worked out again here rather than trusted
       from the page that sent us. What was proposed a minute ago on a page
       that may have been open for an hour is not what is true now. */
    const found = await fetch(`${API}/placing/${state.investorId}`,
                              {credentials: 'include'}).then(r => r.json());
    state.found = found;
    state.who = found.who;
    draw();
  }catch(err){
    $('act').innerHTML = '';
    $('act').appendChild(el(`<div class="blocked">
      <h2>Could not work out what to place</h2>
      <p>${esc(err.message)}</p></div>`));
  }
}

start();
