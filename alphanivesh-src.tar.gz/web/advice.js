/* The recommendations page.
 *
 * The dashboard is for looking things up and the guide says one thing first.
 * This is the whole account, for somebody who wants to see all of it -- or for
 * an adviser sitting beside them with the statement open.
 *
 * The order is the argument. What is working comes first, because a page that
 * opens with faults teaches the reader that nothing they did counted, and the
 * criticism after that lands as noise. Then what is not working, then what is
 * serious enough to matter, then what was missed, then the actions.
 *
 * The actions are the point of the page and get the visual weight to say so.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const money = n => inr.format(Math.round(Number(n) || 0));
const num = n => Number(n) || 0;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
function frag(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

async function get(path){
  const res = await fetch(API + path, {credentials: 'include'});
  if (res.status === 401){ location.href = '/signin.html'; throw new Error('signed out'); }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.detail || 'Could not load this.');
  return body;
}


/* A string, or the English that was here before translation existed. The
   fallback matters: the page must read correctly with no catalogue loaded at
   all, which is the state every first visit is in. */
function T(key, fallback){
  if (typeof t === 'function'){
    const found = t(key);
    if (found && found !== key) return found;
  }
  return fallback || ENGLISH[key] || key;
}

const ENGLISH = {
  "adv.what_to_do": "What to do, and how",
  "advice.where_stand": "Where you stand", "advice.the_good": "The good",
  "advice.what_working": "What is working", "advice.the_bad": "The bad",
  "advice.what_not": "What is not", "advice.the_ugly": "The ugly",
  "advice.what_hurt": "What could actually hurt", "advice.what_missed": "What was missed",
  "advice.available_not_taken": "Available and not taken",
  "advice.what_correct": "What to correct", "advice.free": "free",
  "advice.costs": "Costs", "advice.worth": "Worth",
  "advice.holding_by_holding": "Holding by holding",
  "advice.three_ways_looking": "Three ways of looking",
  "advice.what_not_here": "What is not here", "advice.if_you_did": "If you did all of it",
  "advice.what_holding": "What you would be holding",
  "advice.the_market": "The market you are investing into",
  "advice.cannot_say": "What we cannot say", "advice.optional": "optional",
  "advice.untested": "untested",
  "table.holding": "Holding", "table.value": "Value", "table.growth": "Growth",
  "table.quantamental": "Quantamental", "table.asset_class": "Asset class",
  "table.now": "Now", "table.after": "After", "table.change": "Change",
};

/* ---------------------------------------------------------------- sections */

function headline(data){
  const card = el('<section class="headline"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.where_stand")}${data.as_of ? ' · ' + esc(data.as_of) : ''}</p>
    <p>${esc(data.headline.reading)}</p>`));
  return card;
}

/* Working and not working, side by side. Seeing them together is the point:
   a list of faults on its own is a different document from a balanced one. */
function ledger(data, ways){
  const pair = el('<div class="pair"></div>');

  const good = el('<section class="card"></section>');
  good.appendChild(frag(`
    <p class="eyebrow">${T("advice.the_good")}</p>
    <h2 class="display">${T("advice.what_working")}</h2>
    <p class="lede">${esc(data.working.reading)}</p>`));
  (data.working.items || []).forEach(item => {
    good.appendChild(frag(`
      <div class="item good">
        <h3>${esc(item.what)}</h3>
        <p>${esc(item.why)}</p>
        ${item.worth ? `<p class="cost">${esc(item.worth)}</p>` : ''}
      </div>`));
  });
  pair.appendChild(good);

  const bad = el('<section class="card"></section>');
  bad.appendChild(frag(`
    <p class="eyebrow">${T("advice.the_bad")}</p>
    <h2 class="display">${T("advice.what_not")}</h2>
    <p class="lede" id="badLede">${esc(data.not_working.reading)}</p>`));
  /* Only what is not already an action.
   *
   * "19.6% of your portfolio is in gold" appeared here as something to know
   * and again below as something to do, with three ways of doing it. The
   * second is strictly more useful, so this keeps what has no action against
   * it -- which is the honest meaning of the section anyway: things worth
   * knowing that nobody is proposing to do anything about.
   */
  /* Matched on the code rather than on the wording.
   *
   * The text match let "27.5 points from the mix you set" sit under "nothing
   * to do about them" while the action below it said "bring the mix back
   * towards what you chose" -- the same finding, phrased differently enough
   * to slip past a substring test. Codes are what the engine actually uses to
   * mean "the same thing". */
  const actedCodes = new Set(((ways || {}).actions || [])
    .map(a => a.code).filter(Boolean));

  // A few findings and their actions carry different codes for the same
  // subject, so the pairs are named rather than guessed at.
  const SAME = {drift: 'rebalance', rebalance: 'drift',
                unplanned_class: 'rebalance',
                sector_concentration: 'sector_concentration',
                concentration_single: 'concentration_single',
                single_holding: 'concentration_single'};

  const knowOnly = (data.not_working.items || []).filter(item => {
    const code = item.code;
    if (code && (actedCodes.has(code) || actedCodes.has(SAME[code]))) {
      return false;
    }
    // Fall back to the wording where a finding carries no code.
    const what = (item.what || '').toLowerCase().trim();
    return !((ways || {}).actions || []).some(a => {
      const w = (a.what || '').toLowerCase().trim();
      return w && what && (w.includes(what) || what.includes(w));
    });
  });

  // The count came from the unfiltered list, so it promised more than the
  // section now shows.
  const lede = bad.querySelector('#badLede');
  if (lede && knowOnly.length !== (data.not_working.items || []).length){
    lede.textContent = knowOnly.length
      ? `${knowOnly.length} thing${knowOnly.length === 1 ? '' : 's'} worth `
        + `knowing about, with nothing to do about ${
            knowOnly.length === 1 ? 'it' : 'them'} today.`
      : '';
  }

  if (!knowOnly.length){
    bad.appendChild(el(`<p class="lede">Everything worth attention has
      something worth doing about it, set out below.</p>`));
  }

  knowOnly.slice(0, 6).forEach(item => {
    bad.appendChild(frag(`
      <div class="item bad">
        <h3>${esc(item.what)}</h3>
        <p>${esc(item.why)}</p>
      </div>`));
  });
  pair.appendChild(bad);

  return pair;
}

/* The serious ones, separated. "63% in one industry" and "one fund charges a
   little more" do not belong in the same list, and a reader who cannot tell
   them apart treats both as noise. */
function serious(data){
  const items = data.serious.items || [];
  if (!items.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.the_ugly")}</p>
    <h2 class="display">${T("advice.what_hurt")}</h2>
    <p class="lede">${esc(data.serious.reading)}</p>`));
  items.forEach(item => {
    card.appendChild(frag(`
      <div class="item grave">
        <h3>${esc(item.what)}</h3>
        <p>${esc(item.why)}</p>
        ${item.how_bad ? `<p class="cost">${esc(item.how_bad)}</p>` : ''}
      </div>`));
  });
  return card;
}

/* Opportunities rather than errors. Somebody who never switched to a direct
   plan was sold a regular one and nobody told them -- calling that a mistake
   is both wrong and the fastest way to lose a reader. */
function missed(data){
  const items = data.missed.items || [];
  if (!items.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.what_missed")}</p>
    <h2 class="display">${T("advice.available_not_taken")}</h2>
    <p class="lede">${esc(data.missed.reading)}</p>`));
  items.forEach(item => {
    card.appendChild(frag(`
      <div class="item">
        <h3>${esc(item.what)}${item.costs_nothing
          ? ' <span class="verdict buy">' + T("advice.free") + '</span>' : ''}</h3>
        <p>${esc(item.why)}</p>
        ${item.worth ? `<p class="cost">Worth ${esc(item.worth)}</p>` : ''}
      </div>`));
  });
  return card;
}

/* The actions. The centre of the page, weighted accordingly. */
function correct(data){
  const steps = data.correct.steps || [];
  if (!steps.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.what_correct")}</p>
    <h2 class="display">${esc(data.correct.reading)}</h2>
    <p class="lede">${esc(data.correct.note || '')}</p>`));

  const list = el('<div class="steps" style="margin-top:8px"></div>');
  steps.forEach(step => {
    const free = /^nothing/i.test(step.costs || '');
    list.appendChild(frag(`
      <div class="step">
        <span class="step-n"></span>
        <div>
          <h3 class="display">${esc(step.do)}</h3>
          <p>${esc(step.why)}</p>
          ${step.involves ? `<p class="involves">${esc(step.involves)}</p>` : ''}
          <div class="ledger">
            ${step.costs ? `<span>${T("advice.costs")}<b class="${free ? 'free' : ''}">${
              esc(step.costs)}</b></span>` : ''}
            ${step.worth ? `<span>${T("advice.worth")}<b>${esc(step.worth)}</b></span>` : ''}
          </div>
        </div>
      </div>`));
  });
  card.appendChild(list);
  return card;
}

/* Every share's three calls in one table, so the disagreements between lenses
   are visible side by side rather than buried in separate cards. */
function holdings(data){
  const items = data.holdings.items || [];
  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.holding_by_holding")}</p>
    <h2 class="display">${T("advice.three_ways_looking")}</h2>
    <p class="lede">${esc(data.holdings.reading || '')}</p>`));

  if (!items.length) return card;

  const tone = v => String(v || 'hold').replace(/\s+/g, '-');
  const rows = items.map(item => {
    const cells = ['Value', 'Growth', 'Quantamental'].map(lens => {
      const call = (item.calls || []).find(c => c.lens === lens);
      return call
        ? `<td><span class="verdict ${tone(call.verdict)}"
             title="${esc(call.because)}">${esc(call.verdict)}</span></td>`
        : '<td>—</td>';
    }).join('');
    return `<tr>
      <td><span class="name">${esc(item.name)}</span>
        <span class="share">₹${money(item.value)} · ${esc(item.share_pct)}% of your shares</span></td>
      ${cells}</tr>`;
  }).join('');

  card.appendChild(el(`
    <table class="calls">
      <thead><tr><th>${T("table.holding")}</th><th>${T("table.value")}</th><th>${T("table.growth")}</th><th>${T("table.quantamental")}</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`));
  card.appendChild(el(`<p class="note">${esc(data.holdings.note)}</p>`));
  return card;
}

/* The gaps. A complete-looking account with silent holes is worse than an
   incomplete one: the reader cannot tell which parts to lean on. */
const FIX_LINKS = {
  'Tell us about yourself.': '/profile.html',
  'Import an older statement.': '/upload.html',
  'Set a target mix.': '/profile.html',
  'Say how you invest.': '/dash.html',
};

function cannotSay(data){
  const gaps = (data.cannot_say && data.cannot_say.gaps) || [];
  if (!gaps.length) return null;

  const card = el('<section class="card" style="background:var(--paper)"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.cannot_say")}</p>
    <h2 class="display">${esc(data.cannot_say.reading || '')}</h2>`));
  gaps.forEach(gap => {
    const href = FIX_LINKS[gap.fix];
    card.appendChild(frag(`
      <div class="gap">
        <b>${esc(gap.what)}</b>
        <p>${esc(gap.why)}</p>
        ${gap.fix ? (href ? `<a href="${href}">${esc(gap.fix)}</a>`
                          : `<span class="gap-fix">${esc(gap.fix)}</span>`) : ''}
      </div>`));
  });
  return card;
}


/* What the portfolio does not have.
 *
 * Every other section reads what somebody holds. The things that matter most
 * are often the ones absent altogether -- no debt, no liquidity, nothing
 * outside one economy -- and an absence has no line in a holdings table, so a
 * reader looking at a page of what they own will not notice what they do not.
 */
function missingBlock(data){
  const gaps = (data.missing && data.missing.gaps) || [];
  if (!gaps.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.what_not_here")}</p>
    <h2 class="display">${esc(data.missing.reading)}</h2>
    <p class="lede">${esc(data.missing.note || '')}</p>`));

  gaps.forEach(gap => {
    const box = el('<div class="item"></div>');
    box.appendChild(frag(`
      <h3>${esc(gap.what)}${gap.optional
        ? ' <span class="verdict hold">' + T("advice.optional") + '</span>' : ''}</h3>
      <p><b>You have ${esc(gap.you_have)}.</b> ${esc(gap.why_it_matters)}</p>`));

    /* Naming a gap without naming a way to close it leaves the reader where
       they started. Each option carries the reason it is on the list. */
    const options = gap.options || [];
    if (options.length){
      const list = el('<div class="options"></div>');
      options.forEach(opt => {
        const why = (opt.why || []).map(w => `<li>${esc(w)}</li>`).join('');
        list.appendChild(frag(`
          <div class="option">
            <b>${esc(opt.name)}${opt.untested
              ? ' <span class="verdict lean-reduce">' + T("advice.untested") + '</span>' : ''}</b>
            ${why ? `<ul>${why}</ul>` : ''}
          </div>`));
      });
      box.appendChild(list);
    } else {
      box.appendChild(el('<p class="cost">Nothing suitable found to suggest here.</p>'));
    }
    card.appendChild(box);
  });

  if (data.missing.disclaimer){
    card.appendChild(el(`<p class="note">${esc(data.missing.disclaimer)}</p>`));
  }
  return card;
}

/* What the portfolio would become. The part nobody shows, and usually the
   argument that persuades: somebody told to cut a 63% sector position has no
   idea what they are left with if they do. */
function afterBlock(data){
  const after = data.missing && data.missing.after;
  if (!after || !after.lines || !after.lines.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.if_you_did")}</p>
    <h2 class="display">${T("advice.what_holding")}</h2>
    <p class="lede">${esc(after.reading)}</p>`));

  const rows = after.lines.map(line => {
    const was = num(line.before_pct), now = num(line.after_pct);
    const moved = now - was;
    return `<tr>
      <td class="name">${esc(label(line.asset_class))}</td>
      <td>${was.toFixed(1)}%</td>
      <td>${now.toFixed(1)}%</td>
      <td><span class="verdict ${moved > 1 ? 'buy' : moved < -1 ? 'reduce' : 'hold'}">${
        moved > 0 ? '+' : ''}${moved.toFixed(1)}</span></td>
    </tr>`;
  }).join('');

  card.appendChild(el(`
    <table class="calls">
      <thead><tr><th>${T("table.asset_class")}</th><th>${T("table.now")}</th><th>${T("table.after")}</th><th>${T("table.change")}</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`));

  (after.effects || []).forEach(effect => {
    card.appendChild(frag(`
      <div class="item">
        <h3>${esc(effect.what)}</h3>
        <p>${esc(effect.before)} \u2192 ${esc(effect.after)}</p>
      </div>`));
  });

  card.appendChild(el(`<p class="note">${esc(after.caveat)}</p>`));
  return card;
}

/* Where the market sits, and what has followed readings like it. Never a
   forecast -- the honest thing a record can give is the range of what has
   happened, which is a different claim from what will. */
function marketBlock(data){
  const market = data.market;
  if (!market || !market.readable) return null;

  const card = el('<section class="card"></section>');
  const position = market.position;
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.the_market")}</p>
    <h2 class="display">${esc(position.reading)}</h2>`));

  const followed = market.followed;
  if (followed && followed.countable){
    card.appendChild(frag(`
      <div class="item">
        <p>${esc(followed.reading)}</p>
        <p class="cost">${esc(followed.caveat)}</p>
      </div>`));
  } else if (followed && followed.why){
    card.appendChild(el(`<p class="lede">${esc(followed.why)}</p>`));
  }

  const valuation = market.valuation;
  if (valuation){
    card.appendChild(frag(`
      <div class="item">
        <h3>The hundred largest companies</h3>
        <p>Priced at ${esc(valuation.pe)} times earnings, earning
          ${esc(valuation.roe)}% on shareholders' money.</p>
        <p class="cost">${esc(valuation.note)}</p>
      </div>`));
  }

  card.appendChild(el(`<p class="note">${esc(market.principle)}</p>`));
  return card;
}

const ASSET_LABELS = {
  equity: 'Shares', mutual_fund: 'Mutual funds', etf: 'ETFs', bond: 'Bonds',
  gsec: 'Government securities', gold: 'Gold', fixed_deposit: 'Deposits',
  cash: 'Cash', insurance: 'Insurance', nps: 'Pension', ppf_epf: 'PPF and EPF',
  real_estate: 'Property', unlisted: 'Unlisted', other: 'Other',
  international: 'Outside India',
};
const label = k => ASSET_LABELS[k] || String(k || '').replace(/_/g, ' ');


/* Sell, and then what.
 *
 * A sell recommendation on its own leaves somebody holding cash and no better
 * off than before. This is the other half: what the sales raise, where the
 * engine would put it, and how many shares that buys at today's price.
 *
 * The leftover is shown rather than rounded away. Whole shares never divide
 * evenly into a sum, and money the plan does not place is money sitting idle
 * -- somebody should know it is there rather than discover it later.
 */
function redeployBlock(data){
  const plan = data.redeploy;
  if (!plan) return null;

  const card = el('<section class="card"></section>');

  if (!plan.available){
    card.appendChild(frag(`
      <p class="eyebrow">Selling and buying</p>
      <h2 class="display">Not available right now</h2>
      <p class="lede">${esc(plan.why)}</p>`));
    return card;
  }

  if (plan.nothing_to_sell){
    card.appendChild(frag(`
      <p class="eyebrow">Selling and buying</p>
      <h2 class="display">Nothing to sell</h2>
      <p class="lede">${esc(plan.reading)}</p>`));
    return card;
  }

  card.appendChild(frag(`
    <p class="eyebrow">If you sold the weakest and bought again</p>
    <h2 class="display">${esc(plan.reading)}</h2>`));

  const sells = el('<div style="margin-top:16px"></div>');
  sells.appendChild(frag('<p class="eyebrow">Sell</p>'));
  (plan.sells || []).forEach(sell => {
    sells.appendChild(frag(`
      <div class="shortlist-row">
        <span>
          <b>${esc(sell.name)}</b>
          <span class="shortlist-why">${esc(sell.why_plain || sell.why || '')}</span>
        </span>
        <span class="shortlist-figs">
          ₹${money(sell.raises)}
          <span class="shortlist-tax">${esc(sell.quantity)} shares</span>
        </span>
      </div>`));
  });
  card.appendChild(sells);

  const buys = plan.buys || [];
  if (buys.length){
    const list = el('<div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--rule)"></div>');
    list.appendChild(frag(`<p class="eyebrow">Buy with the ₹${money(plan.raises_total)}</p>`));
    buys.forEach(buy => {
      list.appendChild(frag(`
        <div class="item">
          <h3>${esc(buy.name)}
            ${buy.grade ? `<span class="verdict buy">${esc(buy.grade)}</span>` : ''}
            ${buy.signal ? `<span class="verdict lean-buy">${
              esc(String(buy.signal).toLowerCase().replace(/_/g,' '))}</span>` : ''}
          </h3>
          <!-- Our own wording, which says what this holding does for this
               portfolio. buy.why is the engine's raw text -- "RSI 83,
               overbought, strong volume 2.6x average" -- which explains what a
               number is rather than what it means for the person holding it,
               and it was the last place the platform read as a screener. Kept
               underneath, quieter, for anybody who wants the signals. -->
          <p>${esc(buy.why_this_one || buy.why || '')}</p>
          ${buy.why_this_one && buy.why
            ? `<details class="engine-detail">
                 <summary>what the engine saw</summary>
                 <p>${esc(buy.why)}</p>
               </details>` : ''}
          <div class="ledger">
            <span>Buy<b>${esc(buy.quantity)} shares at ₹${money(buy.price)}</b></span>
            <span>That is<b>₹${money(buy.amount)}</b></span>
            <span>Of the pot<b>${esc(buy.weight_pct)}%</b></span>
            ${buy.size ? `<span>Size<b${buy.small
              ? ' style="color:var(--loss)"' : ''}>${esc(buy.size)}</b></span>` : ''}
            ${buy.sector ? `<span>Industry<b>${esc(buy.sector)}</b></span>` : ''}
          </div>
        </div>`));
    });
    /* What the change does to the kind of portfolio, not just its contents.
       Eight microcaps in place of one large company is a decision somebody
       should make knowingly rather than discover afterwards. */
    if (plan.shape_change){
      const warn = el('<div class="item grave" style="margin-top:14px"></div>');
      warn.appendChild(frag(`<h3>${esc(plan.shape_change.reading)}</h3>`));
      (plan.shape_change.notes || []).forEach(note => {
        warn.appendChild(el(`<p>${esc(note)}</p>`));
      });
      list.appendChild(warn);
    }

    if (num(plan.left_over) > 0){
      list.appendChild(el(`<p class="cost">₹${money(plan.left_over)} would be
        left over — whole shares never divide evenly into a sum.</p>`));
    }
    card.appendChild(list);
  }

  /* The engine's own concentration warnings. Its field is `suggestion`, and a
     fallback that stringifies the object when the guess is wrong puts raw JSON
     on the page -- which is what happened. Anything unrecognised is dropped
     instead: a missing warning is a smaller failure than a visible one nobody
     can read. */
  (plan.alerts || []).slice(0, 3).forEach(alert => {
    if (typeof alert === 'string'){
      card.appendChild(el(`<p class="cost">${esc(alert)}</p>`));
      return;
    }
    const text = alert && (alert.suggestion || alert.message);
    if (!text) return;
    const weight = alert.weight != null ? ` (${esc(alert.weight)}%)` : '';
    const grave = alert.severity === 'high';
    card.appendChild(el(`<p class="cost"${grave ? ' style="color:var(--loss)"' : ''}>${
      esc(text)}${weight}</p>`));
  });

  card.appendChild(el(`<p class="note">${esc(plan.caveat)}${
    plan.note ? ' ' + esc(plan.note) : ''}</p>`));
  return card;
}


/* Whether somebody can hold what they own.
 *
 * Two figures that mean much more together: what a fund demands of whoever
 * holds it, and what this person has actually sustained. A fund scoring 38 out
 * of 100 is a fine holding for somebody who kept buying through a fall and a
 * poor one for somebody who stopped -- and the record says which they are.
 *
 * Placed after the holdings and before the market, because it is about the
 * person rather than the portfolio, and it reads oddly among the numbers.
 */
function canHoldBlock(data){
  const fit = data.can_you_hold_it;
  if (!fit || !fit.holdings || !fit.holdings.length) return null;

  const card = el('<section class="card"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">What these funds ask of you</p>
    <h2 class="display">${esc(fit.reading)}</h2>`));

  const rows = fit.holdings.map(holding => {
    const tone = holding.score >= 70 ? 'buy'
               : holding.score >= 45 ? 'hold' : 'lean-reduce';
    return `<tr>
      <td><span class="name">${esc(holding.name)}</span>
        <span class="share">${esc(holding.share_pct)}% of what you hold</span></td>
      <td><b>${esc(holding.score)}</b><span class="share">out of 100</span></td>
      <td><span class="verdict ${tone}">${
        esc(String(holding.band || '').toLowerCase())}</span></td>
    </tr>`;
  }).join('');

  card.appendChild(el(`
    <table class="calls" style="margin-top:14px">
      <thead><tr><th>Fund</th><th>Easy to hold?</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`));

  /* The hardest one gets its receipts shown, because a score without the
     drawdown behind it is a number somebody has to trust. */
  const hardest = fit.holdings.reduce((worst, h) =>
    h.score < worst.score ? h : worst, fit.holdings[0]);
  if (hardest && hardest.what_it_asks){
    card.appendChild(frag(`
      <div class="item">
        <h3>${esc(hardest.name)}</h3>
        <p>${esc(hardest.what_it_asks)}</p>
      </div>`));
  }

  card.appendChild(el(`<p class="note">${esc(fit.note)}</p>`));
  return card;
}

/* ------------------------------------------------------------------ flow */


/* What to do, and the ways of doing it.
 *
 * The centre of this page and the thing it was missing. Every finding had one
 * action against it, which is a useful shape and is not how advice works: most
 * have three or four legitimate answers with different costs, and which one
 * somebody should take depends on things this platform does not know.
 *
 * So each action opens into its ways. Four things against each — what to do,
 * what it costs, what it gives up, and when it is the right one. That last is
 * what makes an option advice rather than a list item.
 *
 * Leaving it alone appears where it is legitimate, and the free option is
 * marked. A page that never offers either is one whose recommendations a
 * reader is right to discount.
 */
function actionsWithWays(ways){
  if (!ways || !(ways.actions || []).length) return null;

  const shell = el('<section class="block"></section>');
  shell.appendChild(frag(`
    <p class="eyebrow">${T("adv.what_to_do")}</p>
    <h2 class="display">${esc(ways.reading || 'What to do')}</h2>`));

  (ways.actions || []).forEach((action, i) => {
    const item = el('<div class="act"></div>');

    item.appendChild(frag(`
      <div class="act-head">
        <span class="act-n">${i + 1}</span>
        <div>
          <h3>${esc(action.what)}</h3>
          ${action.why ? `<p class="act-why">${esc(action.why)}</p>` : ''}
        </div>
        ${action.worth ? `<span class="act-worth">${esc(action.worth)}</span>` : ''}
      </div>`));

    const ws = action.ways;
    if (ws && (ws.ways || []).length){
      const choices = el('<div class="ways"></div>');
      choices.appendChild(el(`<p class="ways-lead">${
        (ws.ways || []).length} ways of doing this:</p>`));

      (ws.ways || []).forEach(way => {
        const isDefault = way.code === ws.default;
        const card = el(`<div class="way ${isDefault ? 'suggested' : ''}"></div>`);

        card.appendChild(frag(`
          <div class="way-top">
            <b>${esc(way.what)}</b>
            <span class="way-tags">
              ${way.free ? '<span class="tag free">no tax</span>' : ''}
              ${isDefault ? '<span class="tag pick">what we would do</span>' : ''}
            </span>
          </div>`));

        [['Costs', way.costs],
         ['Gives up', way.gives_up],
         ['Pick this if', way.choose_this_if]]
          .filter(([, v]) => v)
          .forEach(([label, value]) => {
            card.appendChild(frag(
              `<p class="way-line"><b>${esc(label)}</b>${esc(value)}</p>`));
          });

        choices.appendChild(card);
      });

      if (ws.how_to_choose){
        choices.appendChild(el(
          `<p class="ways-note">${esc(ws.how_to_choose)}</p>`));
      }
      item.appendChild(choices);
    }

    shell.appendChild(item);
  });

  if (ways.why_alternatives){
    shell.appendChild(el(`<p class="block-note">${esc(ways.why_alternatives)}</p>`));
  }

  return shell;
}

/* The same count on this page, so the masthead reads the same everywhere. */
function paintAdviceCount(ways){
  const badge = document.getElementById('navAdviceCount');
  if (!badge) return;
  const count = ((ways || {}).actions || []).length;
  if (!count){ badge.hidden = true; return; }
  badge.textContent = count;
  badge.hidden = false;
}

function draw(data, ways){
  paintAdviceCount(ways);
  const main = $('main');
  main.innerHTML = '';

  if (data.empty){
    main.appendChild(el(`<div class="state">
      <h3>Nothing to recommend yet</h3>
      <p>${esc(data.why)}</p>
      <a class="cta" href="/upload.html">Bring in holdings</a></div>`));
    return;
  }

  [
    headline(data),
    ledger(data, ways),
    serious(data),
    // The ways come before the old single-action list, because they are the
    // same advice with the alternatives it always had and never showed.
    actionsWithWays(ways),
    // "What to correct" listed the same actions the ways section now shows,
    // with less against each -- so it ran second and read as a worse repeat.
    // Kept only where the ways could not be built, so nothing is lost when
    // that endpoint is unavailable.
    (ways && (ways.actions || []).length) ? null : correct(data),
    missed(data),
    missingBlock(data),
    afterBlock(data),
    holdings(data),
    redeployBlock(data),
    canHoldBlock(data),
    marketBlock(data),
    cannotSay(data),
  ].filter(Boolean).forEach(section => main.appendChild(section));
}

async function load(investorId){
  wireDownload(investorId);
  $('main').innerHTML = '<div class="state"><div class="skeleton" style="height:120px"></div></div>';
  try{
    // The ways are fetched alongside rather than after: they are the point of
    // the page, and drawing the rest first then filling them in would put the
    // most important thing last.
    const [advice, ways] = await Promise.all([
      get('/recommendations/' + investorId),
      get('/ways/' + investorId).catch(() => null),
    ]);
    draw(advice, ways);
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(
      `<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`));
  }
}


/* The language picker, and the notice that goes with it.
 *
 * Two things a reader needs to know before they act on a translated page: that
 * nobody has checked this translation, and that the analysis underneath is
 * still English. Both are said in the language they chose, at the top, rather
 * than left for them to work out. */
async function startLanguage(redraw){
  const bar = document.querySelector('.who');
  if (!bar || typeof buildLanguagePicker !== 'function') return;
  await buildLanguagePicker(bar, () => {
    const existing = document.querySelector('.lang-notice');
    if (existing) existing.remove();
    const notice = languageNotice();
    if (notice){
      const head = document.querySelector('.masthead');
      head.parentNode.insertBefore(notice, head.nextSibling);
    }
    if (redraw) redraw();
  });
}

/* Downloading the advice. Fetched from the decision engine rather than
   rebuilt from the page: the engine's tiered output is the thing with the
   order and the guardrails in it, and reconstructing that from rendered HTML
   would produce a document that disagrees with the one on screen. */
function wireDownload(investorId){
  const button = document.getElementById('download');
  if (!button) return;
  button.addEventListener('click', async () => {
    if (typeof PDF === 'undefined') return;
    button.disabled = true;
    button.textContent = 'Preparing\u2026';
    try{
      const decision = await get(`/decide/${investorId}`);
      const who = (decision.investor && decision.investor.display_name) || '';
      PDF.theAdvice(decision, who);
    }catch(err){
      button.textContent = 'Could not';
      setTimeout(() => { button.textContent = 'Download'; }, 2500);
      return;
    }finally{
      button.disabled = false;
      if (button.textContent === 'Preparing\u2026') button.textContent = 'Download';
    }
  });
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){
      $('main').innerHTML = '';
      $('main').appendChild(el(`<div class="state">
        <h3>Nothing here yet</h3><p>Bring in a statement first.</p>
        <a class="cta" href="/upload.html">Bring in holdings</a></div>`));
      return;
    }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(
      `<option value="${esc(i.id)}">${esc(i.display_name)}</option>`)));
    picker.addEventListener('change', e => load(e.target.value));
    picker.style.display = investors.length > 1 ? '' : 'none';

    const wanted = new URLSearchParams(location.search).get('investor');
    const chosen = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = chosen;
    load(chosen);
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(
      `<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`));
  }
}

start().then(() => startLanguage(() => {
  try{ draw(state && state.data ? state.data : undefined); }
  catch(err){ /* the page will pick strings up on next draw */ }
}));
