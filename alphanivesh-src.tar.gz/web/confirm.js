/* Agreeing to an order.
 *
 * The last screen before somebody's money moves, and deliberately a plain one.
 * No gradient, no urgency, nothing that reads as a nudge — a page designed to
 * get somebody to press the button is a page that will sometimes get somebody
 * to press it who did not mean to.
 *
 * **The countdown is the only moving thing**, and it is there because the
 * consent really does expire rather than to hurry anybody. When it runs out
 * the button stops working and says why, and the way back is to look at the
 * prices again — which is the honest answer, because the figures on the screen
 * are no longer the figures.
 *
 * **Nothing here places an order.** It records agreement. Placing is a
 * separate step that reads what this wrote and refuses without it, so a bug
 * here cannot manufacture consent.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const state = {investorId: null, screen: null, ticking: null, left: 0};

const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
function frag(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

function money(value){
  const n = Math.round(Number(value) || 0);
  const negative = n < 0;
  let digits = String(Math.abs(n));
  if (digits.length > 3){
    let head = digits.slice(0, -3);
    const tail = digits.slice(-3);
    const parts = [];
    while (head.length > 2){ parts.unshift(head.slice(-2)); head = head.slice(0, -2); }
    if (head) parts.unshift(head);
    digits = parts.join(',') + ',' + tail;
  }
  return (negative ? '-\u20B9' : '\u20B9') + digits;
}

/* What is being agreed to comes from the page that sent them here, in session
   storage rather than the URL. An order list in a query string is an order
   list somebody can edit before agreeing to it. */
function whatWasProposed(){
  try{
    const raw = sessionStorage.getItem('proposed');
    return raw ? JSON.parse(raw) : null;
  }catch(err){ return null; }
}

function blocked(title, why, fix){
  $('confirm').innerHTML = '';
  $('confirm').appendChild(frag(`
    <div class="blocked">
      <p class="eyebrow">Not yet</p>
      <h2>${esc(title)}</h2>
      <p>${esc(why || '')}</p>
      ${fix ? `<p style="margin-top:12px"><b>${esc(fix)}</b></p>` : ''}
      <p style="margin-top:18px">
        <a href="/advice.html" style="color:var(--ox);font-weight:700;
           text-decoration:none">Back to what to do \u2192</a></p>
    </div>`));
}

function drawScreen(screen, proposed){
  const box = $('confirm');
  box.innerHTML = '';

  const adviser = screen.adviser || {};
  box.appendChild(frag(`
    <div class="confirm-head">
      <p class="eyebrow">Before anything is placed</p>
      <h1>You are agreeing to ${screen.orders.length} order${
        screen.orders.length === 1 ? '' : 's'}</h1>
      <p>Read them once more. Once you agree, they go to the market as they
      are written here.</p>
    </div>

    <!-- Under whose registration, said rather than implied. Somebody agreeing
         to a trade should know who advised it. -->
    <div class="under">
      Advised by <b>${esc(adviser.name || 'no adviser on record')}</b>${
        adviser.registration_no
          ? ' \u00b7 ' + esc(adviser.registration_no) : ''}
    </div>`));

  const list = el('<div class="orders"></div>');
  screen.orders.forEach(o => {
    const quantity = o.quantity && o.quantity !== ''
      ? `${o.quantity} unit${Number(o.quantity) === 1 ? '' : 's'}` : '';
    const at = o.price_shown && o.price_shown !== ''
      ? `at about \u20B9${o.price_shown}` : '';
    list.appendChild(frag(`
      <div class="order">
        <span class="order-side ${esc(o.side)}">${esc(o.side)}</span>
        <div class="order-what">
          <b>${esc(o.name || o.symbol)}</b>
          <span>${esc([quantity, at].filter(Boolean).join(' \u00b7 '))}</span>
        </div>
        <div class="order-money">
          <b>${money(o.est_cost || o.amount)}</b>
          ${Number(o.est_tax) > 0
            ? `<span>${money(o.est_tax)} tax</span>` : ''}
        </div>
      </div>`));
  });
  box.appendChild(list);

  const sum = el('<div class="sum"></div>');
  sum.appendChild(frag(`
    <div class="sum-row"><span>What changes hands</span>
      <b>${money(screen.total_cost)}</b></div>`));
  if (Number(screen.total_tax) > 0){
    sum.appendChild(frag(`
      <div class="sum-row tax"><span>Tax you will owe on this</span>
        <b>${money(screen.total_tax)}</b></div>`));
  }
  box.appendChild(sum);

  box.appendChild(frag(`
    <div class="plainly">
      <p>${esc(screen.what_this_is)}</p>
      <p class="not">${esc(screen.what_this_is_not)}</p>
    </div>`));

  const tick = el(`<label class="tick">
    <input type="checkbox" id="agreed">
    <span>I have read these orders and I am instructing that they be
    placed.</span>
  </label>`);
  box.appendChild(tick);

  const go = el(`<div class="go">
    <button type="button" id="place" disabled>Place these orders</button>
    <a href="/advice.html">Not now</a>
    <span class="clock" id="clock"></span>
  </div>`);
  box.appendChild(go);
  box.appendChild(el('<p class="said" id="said" hidden></p>'));

  $('agreed').addEventListener('change', e => {
    $('place').disabled = !e.target.checked || state.left <= 0;
  });
  $('place').addEventListener('click', () => place(proposed));

  startClock(screen.good_for_minutes);
}

/* The countdown.
 *
 * Not a pressure device. The prices on this screen were true when it loaded
 * and stop being true; when the window closes the button stops working and
 * says to look again, which is the truthful answer rather than a nag. */
function startClock(minutes){
  state.left = (minutes || 30) * 60;
  const clock = $('clock');

  const tick = () => {
    state.left -= 1;
    if (state.left <= 0){
      clearInterval(state.ticking);
      clock.textContent = 'These prices are out of date now.';
      clock.className = 'clock gone';
      $('place').disabled = true;
      say('The prices here were from when the page loaded and are no longer '
        + 'current. Go back and look again — nothing has been placed.', false);
      return;
    }
    const m = Math.floor(state.left / 60), s = state.left % 60;
    clock.textContent = `Good for ${m}:${String(s).padStart(2, '0')}`;
    clock.className = 'clock' + (state.left < 300 ? ' soon' : '');
  };

  tick();
  state.ticking = setInterval(tick, 1000);
}

function say(text, good){
  const box = $('said');
  box.textContent = text;
  box.className = 'said ' + (good ? 'ok' : 'bad');
  box.hidden = false;
}

async function place(proposed){
  $('place').disabled = true;
  try{
    const done = await fetch(`${API}/consent/${state.investorId}`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        agreed: true,
        orders: proposed.orders,
        ledger_id: proposed.ledger_id || null,
      }),
    }).then(async r => {
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail
                                 || 'That did not go through.');
      return r.json();
    });

    clearInterval(state.ticking);
    $('clock').textContent = '';
    say(done.reading, true);

    /* Spent, so a refresh cannot agree to the same thing twice. */
    try{ sessionStorage.removeItem('proposed'); }catch(err){}
    $('agreed').disabled = true;
  }catch(err){
    say(err.message, false);
    $('place').disabled = false;
  }
}

async function start(){
  const proposed = whatWasProposed();
  if (!proposed || !(proposed.orders || []).length){
    blocked('Nothing to agree to',
            'This page shows orders that came from a recommendation. There '
          + 'are none waiting — which usually means the page was opened '
          + 'directly rather than from the advice.');
    return;
  }

  state.investorId = proposed.investor_id;

  try{
    const may = await fetch(
      `${API}/consent/may/${state.investorId}`, {credentials: 'include'})
      .then(r => r.json());

    if (!may.may){
      blocked('Not able to place orders yet', may.why, may.fix);
      return;
    }

    const screen = await fetch(`${API}/consent/ask/${state.investorId}`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({orders: proposed.orders,
                            ledger_id: proposed.ledger_id || null}),
    }).then(r => r.json());

    if (!screen.may){
      blocked('Not able to place orders yet', screen.why, screen.fix);
      return;
    }

    state.screen = screen;
    drawScreen(screen, proposed);
  }catch(err){
    blocked('Could not load this', err.message);
  }
}

start();
