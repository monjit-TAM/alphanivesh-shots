/* The dashboard.
 *
 * Two ideas shape this file.
 *
 * The allocation band is also the navigation. Tapping a segment filters the
 * whole page to that asset class, which is a truer control than a row of tabs:
 * the thing you press is the thing you are选ing, drawn at its real size.
 *
 * Every label is a text node rather than baked into a path, because all of it
 * has to survive translation. Numbers stay numerals -- Indian readers of every
 * language read 63,96,565 -- but every word around them is replaceable.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const inr = new Intl.NumberFormat('en-IN', {maximumFractionDigits: 0});
const money = n => inr.format(Math.round(Number(n) || 0));
const pct = (n, d = 1) => (Number(n) || 0).toFixed(d) + '%';
const num = n => Number(n) || 0;

/* Money as a person would say it aloud: 34 lakh, not 3,398,043. */
function short(value){
  const n = Math.abs(Number(value) || 0);
  if (n >= 1e7) return (n / 1e7).toFixed(n >= 1e8 ? 0 : 2) + ' Cr';
  if (n >= 1e5) return (n / 1e5).toFixed(n >= 1e6 ? 0 : 1) + ' L';
  if (n >= 1e3) return Math.round(n / 1e3) + 'k';
  return String(Math.round(n));
}

const LABEL = {
  equity: 'Shares', mutual_fund: 'Mutual funds', etf: 'ETFs', bond: 'Bonds',
  gsec: 'Government securities', gold: 'Gold', fixed_deposit: 'Deposits',
  insurance: 'Insurance', nps: 'Pension', ppf_epf: 'PPF and EPF',
  real_estate: 'Property', cash: 'Cash', unlisted: 'Unlisted', other: 'Other'
};
const label = k => LABEL[k] || String(k || '').replace(/_/g, ' ');
const colour = k => getComputedStyle(document.documentElement)
  .getPropertyValue('--ac-' + k).trim() || '#8A9098';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
function frag(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

async function get(path){
  const res = await fetch(API + path, {credentials: 'include'});
  if (res.status === 401){ location.href = '/signin.html'; throw new Error('signed out'); }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.detail || 'Could not load this.');
  return body;
}

/* The same, for the two verbs that change something. Written out rather than
   assumed: the share panel called post() and del() before either existed,
   which is a runtime error waiting for the first click. */
async function post(path, body){
  const res = await fetch(API + path, {
    method: 'POST', credentials: 'include',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body || {}),
  });
  if (res.status === 401){ location.href = '/signin.html'; throw new Error('signed out'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || 'That did not work.');
  return data;
}

async function del(path){
  const res = await fetch(API + path, {method: 'DELETE', credentials: 'include'});
  if (res.status === 401){ location.href = '/signin.html'; throw new Error('signed out'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || 'That did not work.');
  return data;
}

/* ---------------------------------------------------------------- charts */

/* A line of portfolio value over time. Drawn generously rather than as a
   thumbnail: it is the only picture on the page of the thing itself moving,
   and a 20-pixel sparkline says nothing. */
function sparkline(points, {width = 560, height = 178} = {}){
  const live = (points || []).filter(p => Number(p.value) > 0);
  if (live.length < 2) return null;

  const values = live.map(p => Number(p.value));
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = (max - min) || 1;
  const pad = {t: 12, r: 6, b: 22, l: 6};
  const w = width - pad.l - pad.r;
  const h = height - pad.t - pad.b;

  const x = i => pad.l + (i / (live.length - 1)) * w;
  const y = v => pad.t + h - ((v - min) / span) * h;

  const line = values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${line} L${x(values.length - 1).toFixed(1)},${(pad.t + h).toFixed(1)} `
             + `L${x(0).toFixed(1)},${(pad.t + h).toFixed(1)} Z`;

  const first = live[0], last = live[live.length - 1];
  const when = d => {
    const parsed = new Date(d);
    return isNaN(parsed) ? '' :
      parsed.toLocaleDateString('en-IN', {month: 'short', year: '2-digit'});
  };

  return el(`
    <svg viewBox="0 0 ${width} ${height}" role="img"
         aria-label="Portfolio value from ${esc(when(first.month))} to ${esc(when(last.month))}">
      <line class="gridline" x1="${pad.l}" x2="${width - pad.r}"
            y1="${pad.t + h}" y2="${pad.t + h}"/>
      <path class="spark-fill" d="${area}"/>
      <path class="spark-line" d="${line}"/>
      <circle class="spark-dot" cx="${x(values.length - 1).toFixed(1)}"
              cy="${y(values[values.length - 1]).toFixed(1)}" r="3.5"/>
      <text class="axis" x="${pad.l}" y="${height - 6}">${esc(when(first.month))}</text>
      <text class="axis" x="${width - pad.r}" y="${height - 6}"
            text-anchor="end">${esc(when(last.month))}</text>
    </svg>`);
}

/* Yours against the market, on one track. The marker is the market; the fill
   is you. Reading which side you are on takes no arithmetic. */
function comparison(rows){
  const box = el('<div class="cmp"></div>');
  rows.forEach(r => {
    if (r.yours == null) return;
    const yours = num(r.yours);
    const market = r.market == null ? null : num(r.market);
    const ceiling = Math.max(yours, market || 0) * 1.25 || 1;
    const pctOf = v => Math.max(0, Math.min(100, (v / ceiling) * 100));

    box.appendChild(frag(`
      <div class="cmp-row">
        <div class="cmp-top">
          <span>${esc(r.label)}</span>
          <b>${esc(r.format ? r.format(yours) : yours.toFixed(1))}</b>
        </div>
        <div class="cmp-track">
          <span class="cmp-yours" style="width:${pctOf(yours).toFixed(1)}%"></span>
          ${market == null ? '' :
            `<span class="cmp-market" style="left:${pctOf(market).toFixed(1)}%"></span>`}
        </div>
        <div class="cmp-scale">
          <span>${esc(r.low || '')}</span>
          ${market == null ? '<span></span>' :
            `<span>market ${esc(r.format ? r.format(market) : market.toFixed(1))}</span>`}
        </div>
      </div>`));
  });
  return box.childElementCount ? box : null;
}

function stacked(parts){
  const live = parts.filter(p => num(p.value) > 0.05);
  if (!live.length) return null;
  const total = live.reduce((s, p) => s + num(p.value), 0) || 1;

  const bar = el('<div class="stack"></div>');
  const key = el('<div class="stack-key"></div>');
  live.forEach(p => {
    const share = num(p.value) / total * 100;
    bar.appendChild(el(`<i style="width:${share.toFixed(1)}%;background:${p.colour}"
      title="${esc(p.label)} ${pct(share, 0)}"></i>`));
    key.appendChild(frag(
      `<span><s style="background:${p.colour}"></s>${esc(p.label)} ${pct(share, 0)}</span>`));
  });
  const box = document.createElement('div');
  box.append(bar, key);
  return box;
}

function rankedBars(rows, {max = 6, colour: fill = 'var(--ox)'} = {}){
  const live = rows.filter(r => num(r.value) > 0).slice(0, max);
  if (!live.length) return null;
  const top = Math.max(...live.map(r => num(r.value))) || 1;

  const box = el('<div class="ranked"></div>');
  live.forEach(r => {
    box.appendChild(frag(`
      <div class="rank-row">
        <span class="rank-name">${esc(r.label)}</span>
        <span class="rank-value">${esc(r.display)}</span>
        <span class="rank-track">
          <span class="rank-fill" style="width:${(num(r.value) / top * 100).toFixed(1)}%;
                background:${fill}"></span>
        </span>
      </div>`));
  });
  return box;
}

/* ---------------------------------------------------------------- cards */

/* Owned less owed, where we know the debt.
 *
 * Only where it is recorded: an investor who has entered nothing and one who
 * owes nothing are different, and quietly showing gross as net for the first
 * would be the platform asserting something nobody told it.
 */
function netLine(owed, gross){
  if (!owed || !owed.recorded || !num(owed.total)) return null;
  const net = num(gross) - num(owed.total);
  return el(`<div class="net-line">
    <span>Less \u20B9${money(owed.total)} owed</span>
    <b>\u20B9${money(net)} net</b>
  </div>`);
}

function headlineCard(view, name){
  const h = view.headline;
  const gain = num(h.gain);
  const dir = gain >= 0 ? 'up' : 'down';
  const what = name === 'everything' ? 'Everything you hold' : label(name);

  const card = el(`<section class="card headline w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${esc(what)}</p>
    <p class="big display"><em>\u20B9</em>${money(h.current)}</p>
    <p class="beneath">
      <span>You put in \u20B9${money(h.invested)}</span>
      <span class="${dir}">${gain >= 0 ? '+' : '\u2212'}\u20B9${money(Math.abs(gain))}
        (${pct(Math.abs(num(h.return_pct)))})</span>
      <span>${h.positions} holding${h.positions === 1 ? '' : 's'}</span>
    </p>`));

  const rate = el('<div class="rate"></div>');
  if (h.cagr_pct != null){
    rate.appendChild(frag(
      `<b>${pct(h.cagr_pct, 2)}</b><span>a year, over ${esc(h.held_years)} years</span>`));
  } else if (h.cagr_withheld){
    rate.appendChild(frag(`<span class="withheld">${esc(h.cagr_withheld)}</span>`));
  }
  if (rate.childElementCount) card.appendChild(rate);

  // Net worth where the debt is known. Gross alone is the flattering half of a
  // balance sheet: a portfolio worth thirty-four lakh against a home loan of
  // thirty-four lakh is a different position, and showing both as "your
  // wealth" is wrong in a way somebody discovers when they try to spend it.
  const net = netLine(state.data && state.data.owed, h.current);
  if (net) card.appendChild(net);

  return card;
}

function timelineCard(timeline){
  const chart = sparkline(timeline);
  if (!chart) return null;
  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.how_it_moved")}</p>
    <h2 class="display">Three years</h2>`));
  card.appendChild(chart);
  card.appendChild(el(`<p class="card-note">Value at each month end, from the
    statements and prices we hold. Gaps are months we have nothing for.</p>`));
  return card;
}

function moversCard(movers){
  if (!movers || (!movers.best.length && !movers.worst.length)) return null;
  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.what_worked")}</p>
    <h2 class="display">Best and worst</h2>`));

  const row = m => `
    <div class="mover">
      <span class="mover-name">${esc(m.name)}</span>
      <span class="mover-pct ${num(m.gain_pct) >= 0 ? 'up' : 'down'}">${
        num(m.gain_pct) >= 0 ? '+' : ''}${esc(m.gain_pct)}%</span>
    </div>`;

  if (movers.best.length){
    card.appendChild(el(`<div class="mover-group">${movers.best.map(row).join('')}</div>`));
  }
  if (movers.worst.length){
    card.appendChild(el(`<div class="mover-group">${movers.worst.map(row).join('')}</div>`));
  }
  return card;
}

function marketCapCard(mc){
  if (!mc) return null;
  const chart = stacked([
    {label: 'Large', value: mc.large, colour: '#14503D'},
    {label: 'Mid', value: mc.mid, colour: '#4F9179'},
    {label: 'Small', value: mc.small, colour: '#8DBDAA'},
    {label: 'Unclassified', value: mc.multi, colour: '#C6D4CD'},
  ]);
  if (!chart) return null;

  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.where_money_sits")}</p>
    <h2 class="display">Company size</h2>`));
  card.appendChild(chart);
  card.appendChild(el(`<p class="card-note">Of the \u20B9${short(mc.equity_value)} you hold in
    equity. Bands follow the market\u2019s own: the largest hundred companies, then the
    next hundred and fifty.</p>`));
  return card;
}

function valueCard(shape){
  if (!shape) return null;
  const chart = comparison([
    {label: 'Price to earnings', yours: shape.pe && shape.pe.yours,
     market: shape.pe && shape.pe.market, format: v => v.toFixed(1) + '\u00d7'},
    {label: 'Price to book', yours: shape.pb && shape.pb.yours,
     market: shape.pb && shape.pb.market, format: v => v.toFixed(1) + '\u00d7'},
    {label: 'Return on equity', yours: shape.roe && shape.roe.yours,
     market: shape.roe && shape.roe.market, format: v => v.toFixed(1) + '%'},
    {label: 'Revenue growth', yours: shape.revenue_growth && shape.revenue_growth.yours,
     market: shape.revenue_growth && shape.revenue_growth.market,
     format: v => v.toFixed(1) + '%'},
  ]);
  if (!chart) return null;

  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">What you are paying for</p>
    <h2 class="display">Against the market</h2>`));
  card.appendChild(chart);
  card.appendChild(el(`<p class="card-note">Weighted by what each holding is worth, across
    ${shape.covered} of your ${shape.of} shares. The marker is ${esc(shape.market_is ||
    'the market')}. Whether a number is good depends on what you expect next, which is a
    judgement rather than a calculation.</p>`));
  return card;
}

/* Where a card is what the guide is pointing at, it says so. The argument at
   the top is where somebody reads it; the card is where they act on it, and a
   reader should not have to hold the connection in their head. */
function flagIfLead(card, code){
  const first = state.guide && state.guide.first;
  const problems = (state.guide && state.guide.wrong && state.guide.wrong.problems) || [];
  const leads = problems.length && problems[0].code === code;
  if (!first || !leads) return card;
  card.classList.add('is-lead');
  card.insertBefore(el('<p class="lead-flag">the first thing to look at</p>'),
                    card.firstChild);
  return card;
}

function sectorCard(sectors){
  if (!sectors || !sectors.sectors || !sectors.sectors.length) return null;
  const coverage = num(sectors.attributed_share_pct);

  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.what_exposed_to")}</p>
    <h2 class="display">${T("dash.industries")}</h2>`));

  const chart = rankedBars(sectors.sectors.map(s => ({
    label: s.sector, value: num(s.share_pct), display: pct(s.share_pct, 0),
  })), {max: 6, colour: 'var(--ac-equity)'});
  if (chart) card.appendChild(chart);

  card.appendChild(el(`<p class="card-note">${
    coverage >= 60
      ? 'Counting through to the companies your funds hold.'
      : `We can see through to the companies behind ${pct(coverage, 0)} of your money so far.
         Several fund houses publish holdings without percentages.`
  }</p>`));
  return card;
}

function concentrationCard(c){
  if (!c || c.hhi == null) return null;
  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">How spread out</p>
    <h2 class="display">Like ${esc(c.effective_holdings)} equal holdings</h2>`));

  // Twenty-three positions that behave like seven is the whole point, and it
  // is a picture rather than a sentence: two rows of dots, the real count
  // against the effective one.
  const held = Math.min(c.positions || 0, 30);
  const effective = Math.min(Math.round(num(c.effective_holdings)), held);
  const dot = (filled, i) =>
    `<circle cx="${9 + (i % 15) * 15}" cy="${9 + Math.floor(i / 15) * 16}" r="4.5"
       fill="${filled ? 'var(--ox)' : 'var(--rule)'}"/>`;

  const rows = Math.ceil(held / 15) || 1;
  card.appendChild(el(`
    <svg viewBox="0 0 230 ${rows * 16 + 4}" style="margin-top:14px;max-width:230px"
         role="img" aria-label="${c.positions} positions, behaving like ${esc(c.effective_holdings)}">
      ${Array.from({length: held}, (_, i) => dot(i < effective, i)).join('')}
    </svg>`));

  card.appendChild(el(`<p class="card-note" style="margin-top:12px">You hold
    ${c.positions} positions. Measured by how the money is actually divided between them,
    the spread is what ${esc(c.effective_holdings)} equal holdings would give you \u2014
    the rest are small enough to move your total very little.</p>`));
  return card;
}

function findingsCard(data){
  if (!data || !data.findings || !data.findings.length) return null;
  const now = data.worth_doing_now || [];
  const rest = data.findings.slice(now.length);

  const card = el(`<section class="card w6"></section>`);
  card.appendChild(frag(`
    <p class="eyebrow">${esc(data.summary || '')}</p>
    <h2 class="display">${now.length ? 'Worth doing' : 'What we noticed'}</h2>`));

  now.forEach(f => {
    card.appendChild(el(`
      <div class="act">
        <span class="act-n">${f.rank}</span>
        <div>
          <span class="act-verb">${esc(f.action_verb || 'Look at')}</span>
          <h3 class="display">${esc(f.headline)}</h3>
          <p>${esc(f.detail)}</p>
          ${f.why_this_order ? `<p class="why">${esc(f.why_this_order)}</p>` : ''}
        </div>
      </div>`));
  });

  if (rest.length){
    const more = el(`<details class="more">
      <summary>${rest.length} more, none of them urgent</summary></details>`);
    rest.forEach(f => more.appendChild(el(
      `<div class="also"><h4>${esc(f.headline)}</h4><p>${esc(f.detail)}</p></div>`)));
    card.appendChild(more);
  }
  return card;
}


/* What the paper gain would cost to take. Most people never see this number
   until they sell, by which point the decision is made. */
function taxCard(tax){
  if (!tax) return null;
  const shortGain = num(tax.short_term_gain);
  const longGain = num(tax.long_term_gain);
  if (shortGain + longGain <= 0) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.if_sold_today")}</p>
    <h2 class="display">\u20B9${money(tax.estimated_tax)} in tax</h2>`));

  const split = stacked([
    {label: 'Long-term', value: longGain, colour: 'var(--gain)'},
    {label: 'Short-term', value: shortGain, colour: 'var(--brass)'},
  ]);
  if (split) card.appendChild(split);

  /* A position weeks away from the long-term rate is the actionable part. */
  (tax.nearly_long_term || []).slice(0, 2).forEach(n => {
    card.appendChild(el(`<p class="note" style="margin-top:11px;font-size:13px">
      <b>${esc(n.name)}</b> turns long-term in ${n.months_to_go}
      month${n.months_to_go === 1 ? '' : 's'}. Waiting until then would tax its
      \u20B9${money(n.gain)} gain at 12.5% rather than 20%${
        n.saving ? `, saving about \u20B9${money(n.saving)}` : ''}.</p>`));
  });

  card.appendChild(el(`<p class="card-note" style="margin-top:11px">${esc(tax.method)}${
    tax.undated_gain ? ` A further \u20B9${money(tax.undated_gain)} of gain sits on
    holdings we cannot date, so it is not counted.` : ''}</p>`));
  return card;
}

/* How much the thing moves. Stated as a comparison to the market rather than
   as a score, because beta means something and "risk 6.8" does not. */
function volatilityCard(v){
  if (!v) return null;
  const beta = num(v.beta);
  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.how_much_moves")}</p>
    <h2 class="display">Beta ${beta.toFixed(2)}</h2>`));

  /* The market sits at the middle and you sit somewhere either side of it. A
     bar growing from the left made a beta above 1.0 look like more of a good
     thing; a dot on a track either side of the market reads as what it is --
     a position, not a score. */
  const centre = 150;
  const at = Math.max(14, Math.min(286, centre + (beta - 1) * 130));
  const over = beta >= 1;

  card.appendChild(el(`
    <svg viewBox="0 0 300 58" style="margin-top:14px" role="img"
         aria-label="Beta ${beta.toFixed(2)}, against the market at 1.0">
      <line x1="10" x2="290" y1="28" y2="28" stroke-width="7" stroke-linecap="round"
            stroke="var(--rule-soft)"/>
      <line x1="${Math.min(centre, at).toFixed(1)}" x2="${Math.max(centre, at).toFixed(1)}"
            y1="28" y2="28" stroke-width="7" stroke-linecap="round"
            stroke="${over ? 'var(--brass)' : 'var(--gain)'}"/>
      <line x1="${centre}" x2="${centre}" y1="17" y2="39" stroke="var(--ink)" stroke-width="2"/>
      <circle cx="${at.toFixed(1)}" cy="28" r="6.5" fill="${over ? 'var(--brass)' : 'var(--gain)'}"
              stroke="var(--surface)" stroke-width="2"/>
      <text class="axis" x="${centre}" y="54" text-anchor="middle">the market</text>
      <text class="axis" x="10" y="14">steadier</text>
      <text class="axis" x="290" y="14" text-anchor="end">swings more</text>
    </svg>`));

  card.appendChild(el(`<p class="card-note" style="margin-top:10px">What you hold
    ${esc(v.reading)}. ${esc(v.method)}</p>`));
  return card;
}

/* What it pays out, and -- the more interesting figure -- what that is on what
   was paid rather than on what it is worth now. */
function incomeCard(income){
  if (!income) return null;
  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.what_it_pays")}</p>
    <h2 class="display">\u20B9${money(income.annual_income)} a year</h2>`));

  const rows = [
    {label: 'On what it is worth now', value: income.yield_on_value},
    {label: 'On what you paid', value: income.yield_on_cost},
  ].filter(r => r.value != null);

  const box = el('<div class="cmp" style="margin-top:14px"></div>');
  const ceiling = Math.max(...rows.map(r => num(r.value))) * 1.3 || 1;
  rows.forEach(r => {
    box.appendChild(frag(`
      <div class="cmp-row">
        <div class="cmp-top"><span>${esc(r.label)}</span><b>${pct(r.value, 2)}</b></div>
        <div class="cmp-track">
          <span class="cmp-yours" style="width:${(num(r.value) / ceiling * 100).toFixed(1)}%;
                background:var(--brass)"></span>
        </div>
      </div>`));
  });
  card.appendChild(box);
  card.appendChild(el(`<p class="card-note" style="margin-top:4px">${esc(income.method)}</p>`));
  return card;
}


/* How far the portfolio has moved from what was intended.
 *
 * Markets do the drifting. Somebody who set 60/40 and left it alone holds
 * 70/30 after a good year for equities -- and now owns something they did not
 * choose. Stated in rupees as well as points, because "twelve points over" is
 * abstract and "sell four lakh of shares" is a decision. */
function driftCard(drift){
  if (!drift || !drift.lines || !drift.lines.length) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.mix_you_set")}</p>
    <h2 class="display">${drift.in_line
      ? 'Close to where you meant it'
      : `${drift.worst_gap_pct} points off`}</h2>`));

  const box = el('<div class="cmp" style="margin-top:14px"></div>');
  drift.lines.slice(0, 5).forEach(line => {
    const actual = num(line.actual_pct);
    const target = num(line.target_pct);
    const ceiling = Math.max(actual, target, 10) * 1.2;
    const move = num(line.to_move);

    box.appendChild(frag(`
      <div class="cmp-row">
        <div class="cmp-top">
          <span>${esc(label(line.asset_class))}</span>
          <b>${pct(actual, 0)}${line.beyond_tolerance
            ? ` <span style="font-weight:500;color:var(--ink-4);font-size:12.5px">
                you meant ${pct(target, 0)}</span>` : ''}</b>
        </div>
        <div class="cmp-track">
          <span class="cmp-yours" style="width:${(actual / ceiling * 100).toFixed(1)}%;
            background:${line.beyond_tolerance ? 'var(--brass)' : 'var(--ox)'}"></span>
          <span class="cmp-market" style="left:${(target / ceiling * 100).toFixed(1)}%"></span>
        </div>
        ${line.beyond_tolerance && Math.abs(move) > 999 ? `<div class="cmp-scale">
          <span>${move > 0 ? 'sell' : 'add'} about \u20B9${money(Math.abs(move))}</span>
          <span></span></div>` : ''}
      </div>`));
  });
  card.appendChild(box);

  card.appendChild(el(`<p class="card-note" style="margin-top:6px">${esc(drift.method)}${
    drift.set_at ? ` You set this on ${esc(drift.set_at)}.` : ''}</p>`));
  return card;
}

/* Where no target exists, the invitation to set one -- because drift cannot be
   measured against an intention nobody has stated. */
function setTargetCard(){
  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.mix_you_set")}</p>
    <h2 class="display">You have not said what you meant to hold</h2>
    <p class="card-note" style="margin-top:8px">Whether 96% in shares is right depends
      entirely on what you intended. Tell us the mix you are aiming for and we can say
      how far the market has moved you from it \u2014 and what it would take to get back.</p>`));
  const link = el('<p style="margin-top:14px"><a href="/profile.html" '
    + 'style="font-size:14px;font-weight:700;color:var(--ox)">Set a target mix</a></p>');
  card.appendChild(link);
  return card;
}


/* Five kinds of risk on one shape.
 *
 * A radar is usually where honest numbers go to become a picture nobody can
 * argue with. This one puts the figure back beside every axis, so the shape is
 * the way in and the number is the answer. */
function radarCard(radar){
  if (!radar || !radar.axes || radar.axes.length < 3) return null;

  const axes = radar.axes;
  const n = axes.length;
  const size = 260, mid = size / 2, r = 88;
  const angle = i => (Math.PI * 2 * i / n) - Math.PI / 2;
  const point = (i, value) => {
    const rad = r * Math.max(0.04, Math.min(1, value / 100));
    return [mid + rad * Math.cos(angle(i)), mid + rad * Math.sin(angle(i))];
  };

  const rings = [25, 50, 75, 100].map(level => {
    const path = axes.map((_, i) => {
      const [x, y] = point(i, level);
      return `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ') + ' Z';
    return `<path d="${path}" fill="none" stroke="var(--rule-soft)" stroke-width="1"/>`;
  }).join('');

  const spokes = axes.map((_, i) => {
    const [x, y] = point(i, 100);
    return `<line x1="${mid}" y1="${mid}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}"
      stroke="var(--rule-soft)" stroke-width="1"/>`;
  }).join('');

  const shape = axes.map((a, i) => {
    const [x, y] = point(i, num(a.score));
    return `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ') + ' Z';

  const dots = axes.map((a, i) => {
    const [x, y] = point(i, num(a.score));
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3.5" fill="var(--ox)"/>`;
  }).join('');

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.where_risk")}</p>
    <h2 class="display">${T("dash.five_ways")}</h2>`));

  card.appendChild(el(`
    <svg viewBox="0 0 ${size} ${size}" style="max-width:270px;margin:14px auto 0" role="img"
         aria-label="${esc(axes.map(a => a.axis + ' ' + a.score).join(', '))}">
      ${rings}${spokes}
      <path d="${shape}" fill="var(--ox)" fill-opacity="0.13"
            stroke="var(--ox)" stroke-width="2" stroke-linejoin="round"/>
      ${dots}
    </svg>`));

  /* The figures, because the shape on its own is a mood. */
  const list = el('<div style="margin-top:14px"></div>');
  [...axes].sort((a, b) => num(b.score) - num(a.score)).forEach(a => {
    list.appendChild(frag(`
      <div class="mover">
        <span class="mover-name" title="${esc(a.scale || '')}">${esc(a.axis)}</span>
        <span style="text-align:right">
          <b style="font-variant-numeric:tabular-nums">${esc(a.score)}</b>
          <span style="display:block;font-size:12px;color:var(--ink-4)">${esc(a.reading)}</span>
        </span>
      </div>`));
  });
  card.appendChild(list);
  card.appendChild(el(`<p class="card-note" style="margin-top:11px">${esc(radar.method)}</p>`));
  return card;
}

/* What a bad market would do. Two answers, deliberately shown together --
 * beta says one thing and history says a larger one, and the gap between them
 * is the part worth understanding. */
function scenarioCard(sc){
  if (!sc || (!sc.falls.length && !sc.history)) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.if_market_turned")}</p>
    <h2 class="display">What a fall would cost</h2>`));

  if (sc.falls.length){
    const box = el('<div class="cmp" style="margin-top:14px"></div>');
    const worst = Math.max(...sc.falls.map(f => num(f.your_fall_pct)));
    sc.falls.forEach(f => {
      box.appendChild(frag(`
        <div class="cmp-row">
          <div class="cmp-top">
            <span>If the market fell ${f.market_fall_pct}%</span>
            <b>\u2212\u20B9${money(f.you_would_lose)}</b>
          </div>
          <div class="cmp-track">
            <span class="cmp-yours" style="width:${(num(f.your_fall_pct) / worst * 100).toFixed(1)}%;
              background:var(--loss)"></span>
          </div>
          <div class="cmp-scale">
            <span>you would be down ${pct(f.your_fall_pct)}</span>
            <span>\u20B9${money(f.left_with)} left</span>
          </div>
        </div>`));
    });
    card.appendChild(box);
  }

  if (sc.history){
    const h = sc.history;
    card.appendChild(el(`<p class="note" style="margin-top:14px;font-size:13.5px">
      <b>History says worse.</b> Each of these holdings has already had a worst fall of
      its own \u2014 ${pct(h.average_worst_fall_pct, 0)} on average, weighted by what you
      hold. That would be <b>\u20B9${money(h.you_would_lose)}</b>, not
      \u20B9${money(sc.falls.length ? sc.falls[1].you_would_lose : 0)}.${
        h.worst_single ? ` ${esc(h.worst_single.name)} alone has fallen
        ${pct(h.worst_single.fall_pct, 0)}.` : ''}</p>`));
  }

  card.appendChild(el(`<p class="card-note" style="margin-top:11px">${esc(sc.method)}</p>`));
  return card;
}


/* The same money, in the index instead.
 *
 * This is the question underneath every other one: was the choosing worth it?
 * Against a savings account almost anything looks good. Against simply buying
 * the market -- which anybody can do, for a few basis points -- most portfolios
 * do not, and knowing which side you are on decides whether the effort is
 * earning anything. */
function benchmarkCard(b){
  if (!b) return null;

  const yours = num(b.your_value);
  const index = num(b.index_value);
  const ceiling = Math.max(yours, index) * 1.08;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">Against simply buying the market</p>
    <h2 class="display">${b.ahead ? 'Ahead' : 'Behind'} by
      \u20B9${money(Math.abs(num(b.difference)))}</h2>`));

  const box = el('<div class="cmp" style="margin-top:16px"></div>');
  [
    {label: 'What you have', value: yours, cagr: b.your_cagr_pct,
     colour: b.ahead ? 'var(--gain)' : 'var(--ox)'},
    {label: 'The index, same money, same day', value: index,
     cagr: b.index_cagr_pct, colour: 'var(--ink-3)'},
  ].forEach(row => {
    box.appendChild(frag(`
      <div class="cmp-row">
        <div class="cmp-top">
          <span>${esc(row.label)}</span>
          <b>\u20B9${money(row.value)}</b>
        </div>
        <div class="cmp-track">
          <span class="cmp-yours" style="width:${(row.value / ceiling * 100).toFixed(1)}%;
            background:${row.colour}"></span>
        </div>
        ${row.cagr ? `<div class="cmp-scale"><span>${pct(row.cagr)} a year</span>
          <span></span></div>` : ''}
      </div>`));
  });
  card.appendChild(box);

  card.appendChild(el(`<p class="card-note" style="margin-top:8px">Since
    ${esc(b.since)}, ${esc(b.years)} years. ${esc(b.method)}</p>`));
  return card;
}


/* Which kind of investor somebody is.
 *
 * Most people cannot name their style, and that is not ignorance -- the
 * vocabulary belongs to the industry rather than to them. So this explains the
 * three in plain terms, shows what their own holdings suggest, and lets them
 * confirm or correct it.
 *
 * The answer never changes which verdicts are shown. It changes which one is
 * marked as theirs, which is a different thing: a growth investor still needs
 * to see that a value investor would sell what they are holding. */
function styleCard(info, investorId){
  if (!info) return null;

  // Full width. Three options with explanations is a lot of vertical content,
  // and in a half-width column it became a tower that stretched everything
  // beside it.
  const card = el('<section class="card w12"></section>');
  const stated = info.stated;
  const suggested = info.suggested;

  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.how_you_invest")}</p>
    <h2 class="display">${stated
      ? `You invest like a ${esc(stated)} investor`
      : 'Three ways of investing'}</h2>`));

  /* What the holdings say, which is a better account than what people say
     about themselves -- somebody describes themselves as cautious and holds
     three quarters of their money in one small company. */
  if (suggested && suggested.reading){
    card.appendChild(el(`<p class="card-note" style="margin-top:8px">
      ${esc(suggested.reading)}</p>`));
  } else if (!stated){
    card.appendChild(el(`<p class="card-note" style="margin-top:8px">
      The same holding can be worth buying to one investor and worth selling to
      another, and both are right. Which of these sounds like you?</p>`));
  }

  const list = el('<div style="margin-top:14px"></div>');
  info.styles.forEach(spec => {
    const chosen = stated === spec.key;
    const leaning = !stated && suggested && suggested.suggests === spec.key;

    const option = el(`
      <button class="style-option${chosen ? ' chosen' : ''}" type="button"
              aria-pressed="${chosen}">
        <span class="style-head">
          <b>${esc(spec.name)}</b>
          ${chosen ? '<span class="style-tag">yours</span>'
                   : leaning ? '<span class="style-tag suggest">your holdings lean here</span>'
                   : ''}
        </span>
        <span class="style-line">${esc(spec.one_line)}</span>
      </button>`);

    option.addEventListener('click', async () => {
      const next = chosen ? null : spec.key;
      try{
        await fetch(`${API}/profile/${investorId}/style`, {
          method: 'PUT', credentials: 'include',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({style: next}),
        });
        state.style = next;
        if (state.styleInfo) state.styleInfo.stated = next;
        draw();
      }catch(err){ /* leave the choice as it was */ }
    });
    list.appendChild(option);

    /* The full explanation, for somebody meeting the idea for the first time.
       Behind a toggle because a reader who knows already does not need three
       paragraphs to get past. */
    const more = el(`<details class="style-more">
      <summary>what that means</summary>
      <p>${esc(spec.explain)}</p>
      <p><b>Buys:</b> ${esc(spec.buys)}</p>
      <p><b>Avoids:</b> ${esc(spec.avoids)}</p>
    </details>`);
    list.appendChild(more);
  });
  card.appendChild(list);

  if (suggested && suggested.caveat){
    card.appendChild(el(`<p class="card-note" style="margin-top:12px">
      ${esc(suggested.caveat)}</p>`));
  }
  card.appendChild(el(`<p class="disclaim">Whichever you choose, every holding
    still shows all three readings. This decides which is marked as yours \u2014
    not which you are allowed to see.</p>`));
  return card;
}


/* The guide, at the top.
 *
 * The dashboard answers seventeen questions and leaves the reader to assemble
 * them. This is the assembly: where you stand, what is wrong, what to do
 * first. Set above the numbers because it is the thing worth reading once
 * rather than looking up, and because a reader who arrives at a wall of cards
 * has to work out for themselves which of them matters today.
 *
 * The same argument reappears beside the card it concerns -- the sector card
 * carries the sector problem, the drift card carries the drift. Saying it
 * twice is not repetition when the second time is where somebody can act. */
/* A door from the guide's first action to the alternatives.
 *
 * The guide already says what to do first, which is the advice the dashboard
 * needed. What it did not have was anywhere to go from there -- and the
 * alternatives are the part that makes it a decision rather than an
 * instruction.
 *
 * A link rather than a second card. The first attempt added a card repeating
 * what the guide had just said two inches above it, which is the pile this
 * page was rebuilt to avoid.
 */
function toTheAlternatives(count){
  return el(`<a class="to-ways" href="/advice.html">${
    count > 1
      ? `See all ${count} things worth doing, and the ways of doing each`
      : 'See the ways of doing this'} \u2192</a>`);
}

function guideBlock(g){
  if (!g || g.empty) return null;

  const shell = el('<section class="guide"></section>');

  shell.appendChild(frag(`
    <p class="guide-eyebrow">Where you stand</p>
    <p class="guide-lead">${esc(g.standing.reading)}</p>`));

  const wrong = g.wrong;
  if (wrong && wrong.problems && wrong.problems.length){
    shell.appendChild(el(`<p class="guide-wrong">${esc(wrong.reading)}</p>`));
  }

  const first = g.first;
  if (first && first.kind !== 'none'){
    const act = el('<div class="guide-act"></div>');
    act.appendChild(frag(`
      <p class="guide-eyebrow">${first.kind === 'foundation'
        ? 'Before anything else' : 'What to do first'}</p>
      <h2 class="guide-do display">${esc(first.do)}</h2>
      <p class="guide-why">${esc(first.why)}</p>
      ${first.before ? `<p class="guide-order">${esc(first.before)}</p>` : ''}`));

    /* Naming the holdings is the part that takes work. "Reduce equity by twelve
       lakh" is arithmetic; "these three, and what each costs to sell" is a
       decision somebody can actually make. */
    if ((first.candidates || []).length){
      const list = el('<div class="guide-shortlist"></div>');
      list.appendChild(frag('<p class="guide-eyebrow">Worth looking at</p>'));
      first.candidates.forEach(c => {
        list.appendChild(frag(`
          <div class="shortlist-row">
            <span>
              <b>${esc(c.name)}</b>
              <span class="shortlist-why">${esc(c.why || '')}</span>
            </span>
            <span class="shortlist-figs">
              \u20B9${money(c.value)}
              <span class="shortlist-tax">${num(c.tax_if_sold) > 0
                ? `\u20B9${money(c.tax_if_sold)} tax` : 'no tax to pay'}</span>
            </span>
          </div>`));
      });
      if (first.tax_note){
        list.appendChild(el(`<p class="guide-order">${esc(first.tax_note)}</p>`));
      }
      act.appendChild(list);
    }
    shell.appendChild(act);
  }

  // No onward link here: the actions themselves now sit further down the
  // page, and two invitations to the same place is one too many.


  // Where to go for the alternatives. The guide says what to
  // do; the advice page says the ways of doing it.
  const acts = ((state.decision || {}).actions || []).length;
  if (acts) shell.appendChild(toTheAlternatives(acts));

  return shell;
}

/* What we could not see, at the bottom.
 *
 * Every tool of this kind can produce a confident plan. What separates one
 * worth trusting is whether it says which parts of the picture were missing
 * when it made one -- and puts the fix within reach rather than just naming
 * the gap. */
const GAP_LINKS = {
  'Tell us about yourself.': '/profile.html',
  'Import an older statement.': '/upload.html',
  'Set a target mix.': '/profile.html',
};

function unseenBlock(unseen){
  if (!unseen || !unseen.gaps || !unseen.gaps.length) return null;

  const card = el('<section class="card w12 unseen"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">What we could not see</p>
    <h2 class="display">${esc(unseen.reading)}</h2>`));

  const list = el('<div style="margin-top:14px"></div>');
  unseen.gaps.forEach(gap => {
    const href = GAP_LINKS[gap.fix];
    list.appendChild(frag(`
      <div class="gap">
        <b>${esc(gap.what)}</b>
        <p>${esc(gap.why)}</p>
        ${gap.fix ? (href
          ? `<a class="gap-fix" href="${href}">${esc(gap.fix)}</a>`
          : `<span class="gap-fix quiet">${esc(gap.fix)}</span>`) : ''}
      </div>`));
  });
  card.appendChild(list);
  return card;
}

/* The route to a goal, where one has been set. */
function routeCard(route){
  if (!route) return null;

  const card = el('<section class="card w6"></section>');

  if (route.asked){
    // A prompt rather than a panel. As a full card it sat beside things three
    // times its height and the grid stretched it into a white rectangle.
    // A prompt, not a panel, and not a tile either -- a tile in the card grid
    // has no span and collapses to a twelfth of the width. A half-width card
    // with two lines in it is the honest shape for asking a question.
    card.appendChild(frag(`
      <p class="eyebrow">The route</p>
      <h2 class="display">What is the money for?</h2>
      <p class="card-note" style="margin-top:8px;max-width:44ch">${
        esc(route.reading)}</p>
      <p style="margin-top:14px"><a href="/profile.html"
        style="font-size:14px;font-weight:700;color:var(--ox);
        text-decoration:none">Set a goal \u2192</a></p>`));
    return card;
  }

  card.appendChild(frag(`
    <p class="eyebrow">The route to ${esc(route.goal || 'your goal')}</p>
    <h2 class="display">${esc(route.projection && num(route.projection.gap) <= 0
      ? 'Within reach' : 'Short, on these numbers')}</h2>`));

  if (route.conversation){
    card.appendChild(el(`<p class="call-why" style="margin-top:9px">
      ${esc(route.conversation)}</p>`));
  }
  if (route.surplus_note){
    card.appendChild(el(`<p class="note" style="margin-top:12px;font-size:13.5px">
      ${esc(route.surplus_note)}</p>`));
  }
  /* Where the foundations are not in place, that is said beside the
     allocation rather than left to contradict the note under it. */
  if (route.caution){
    card.appendChild(el(`<p class="note caution" style="margin-top:12px;font-size:13.5px">
      ${esc(route.caution)}</p>`));
  }
  (route.life_notes || []).slice(0, 2).forEach(note => {
    card.appendChild(el(`<p class="card-note" style="margin-top:11px">${esc(note)}</p>`));
  });
  if (route.disclaimer){
    card.appendChild(el(`<p class="disclaim">${esc(route.disclaimer)}</p>`));
  }
  return card;
}


/* The advice, in the dashboard.
 *
 * A link is a thing somebody has to decide to click. Putting the actions
 * themselves here means the person looking at their numbers sees what to do
 * about them without leaving, and the separate page becomes the long form
 * rather than the only form.
 *
 * Only the actions and the redeployment: the full account -- what is working,
 * what was missed, what the portfolio would become -- stays on its own page,
 * because a dashboard that carries all of it is not a dashboard any more.
 */
function adviceBlock(advice){
  if (!advice || advice.empty) return null;

  const steps = (advice.correct && advice.correct.steps) || [];
  const plan = advice.redeploy;
  if (!steps.length && !(plan && plan.buys && plan.buys.length)) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("advice.what_correct")}</p>
    <h2 class="display">${esc((advice.correct && advice.correct.reading) || '')}</h2>`));

  if (steps.length){
    const list = el('<div class="steps"></div>');
    steps.slice(0, 4).forEach(step => {
      const free = /^nothing/i.test(step.costs || '');
      list.appendChild(frag(`
        <div class="step">
          <span class="step-n"></span>
          <div>
            <h3 class="display">${esc(step.do)}</h3>
            <p>${esc(step.why)}</p>
            <div class="ledger">
              ${step.costs ? `<span>Costs<b class="${free ? 'free' : ''}">${
                esc(step.costs)}</b></span>` : ''}
              ${step.worth ? `<span>Worth<b>${esc(step.worth)}</b></span>` : ''}
            </div>
          </div>
        </div>`));
    });
    card.appendChild(list);
  }

  /* Selling without saying where the money goes is half an instruction, so
     the buy side comes with it rather than a page away. */
  if (plan && plan.available && !plan.nothing_to_sell && (plan.buys || []).length){
    const swap = el('<div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--rule)"></div>');
    swap.appendChild(frag(`
      <p class="eyebrow">And what to buy with it</p>
      <p class="card-note" style="margin-bottom:10px">${esc(plan.reading)}</p>`));
    (plan.buys || []).slice(0, 5).forEach(buy => {
      swap.appendChild(frag(`
        <div class="mover">
          <span class="mover-name">
            <b>${esc(buy.name)}</b>
            ${buy.sector ? `<span style="color:var(--ink-4)"> \u00b7 ${esc(buy.sector)}</span>` : ''}
            ${buy.size ? `<span class="verdict ${buy.small ? 'lean-reduce' : 'hold'}"
              style="margin-left:8px">${esc(buy.size)}</span>` : ''}
          </span>
          <span style="text-align:right;white-space:nowrap">
            <b>\u20B9${money(buy.amount)}</b>
            <span style="display:block;font-size:12px;color:var(--ink-4)">
              ${esc(buy.quantity)} shares</span>
          </span>
        </div>`));
    });
    if (plan.mix){
      swap.appendChild(el(`<p class="card-note" style="margin-top:10px">${
        esc(plan.mix.reading)}</p>`));
    }
    card.appendChild(swap);
  }

  card.appendChild(el(`<div class="guide-onward" style="margin-top:18px">
    <a href="/advice.html">
      <b>The whole account</b>
      <span>What is working, what was missed, what your portfolio would look
        like if you did all of it, and what we cannot tell you</span>
    </a></div>`));
  return card;
}


/* Same lookup as the advice page: a key if a catalogue is loaded, the English
   that was written here if not. */
const ENGLISH = {
  "dash.what_it_was_worth": "What it has been worth",
  /* Every key T() asks for needs an entry here, or the page shows the key
     itself. Two escaped this way -- DASH.WHERE_MONEY_IS rendered as a heading
     -- because they were added to the locale files and not to this map. */
  "dash.where_money_is": "Where the money is",
  "dash.what_it_was_worth": "What it has been worth",
  "dash.your_review": "Your review",
  "dash.total_wealth": "Total wealth", "dash.everything": "Everything you hold",
  "dash.how_it_moved": "How it has moved", "dash.three_years": "Three years",
  "dash.what_worked": "What worked", "dash.best_and_worst": "Best and worst",
  "dash.where_money_sits": "Where the money sits", "dash.company_size": "Company size",
  "dash.how_spread": "How spread out", "dash.what_noticed": "What we noticed",
  "dash.worth_doing": "Worth doing", "dash.against_market": "Against the market",
  "dash.what_paying_for": "What you are paying for",
  "dash.how_you_invest": "How you invest", "dash.three_ways": "Three ways of investing",
  "dash.against_index": "Against simply buying the market",
  "dash.where_risk": "Where the risk is", "dash.five_ways": "Five ways of asking",
  "dash.if_market_turned": "If the market turned",
  "dash.what_fall_cost": "What a fall would cost",
  "dash.mix_you_set": "Against the mix you set", "dash.if_sold_today": "If you sold today",
  "dash.how_much_moves": "How much it moves", "dash.what_it_pays": "What it pays you",
  "dash.what_exposed_to": "What you are exposed to", "dash.industries": "Industries",
  "dash.what_you_hold": "What you hold",
  "advice.what_correct": "What to do about all this",
  "dash.what_they_ask": "What these funds ask of you",
  "dash.what_you_owe": "What you owe",
  "dash.a_bad_day": "When it goes wrong",
  "dash.six_shocks": "Six kinds of trouble",
  "dash.where_it_might_go": "Where this might end up",
  "dash.protection": "If you were not here",
  "dash.first_thing": "The first thing worth doing",
  "sec.standing": "Where you stand",
  "sec.todo": "What to do",
  "sec.snapshot": "Your snapshot",
  "sec.measures": "The measures",
  "sec.ariv": "Ask Ariv",
  "sec.mix": "The mix",
  "sec.holdings": "Every holding",
  "sec.risk": "What could go wrong",
  "sec.cost": "What it costs you",
  "sec.account": "The account",
  "dash.ask_ariv": "Ariv",
  "dash.against_peers": "Against funds doing the same job",
  "dash.what_you_earned": "What you actually earned",
  "dash.what_fees_cost": "What the fees cost",
  "dash.raising_it": "If you raised it each year",
  "decide.eyebrow": "What to do about all this",
  "method.eyebrow": "How this works",
  "method.heading": "Where every number here comes from",
};

function T(key, fallback){
  if (typeof t === 'function'){
    const found = t(key);
    if (found && found !== key) return found;
  }
  return fallback || ENGLISH[key] || key;
}


/* How this works, at the foot of the dashboard.
 *
 * A separate page is a page nobody opens. The claims are on this screen, so
 * the account of how they were arrived at should be one tap from them --
 * closed by default, because somebody reading their portfolio is not usually
 * reading a methodology, and open the moment they wonder.
 */
function methodCard(method){
  if (!method || !method.sections) return null;

  const card = el('<section class="card w12 method"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("method.eyebrow")}</p>
    <h2 class="display">${T("method.heading")}</h2>
    <p class="card-note" style="margin-top:8px;max-width:66ch">${esc(method.principle)}</p>`));

  method.sections.forEach(section => {
    const fold = el(`<details class="method-fold">
      <summary>${esc(section.name)}</summary></details>`);
    (section.items || []).forEach(item => {
      fold.appendChild(frag(`
        <div class="method-item">
          <b>${esc(item.what)}</b>
          <p>${esc(item.how)}</p>
          ${item.note ? `<p class="method-note">${esc(item.note)}</p>` : ''}
        </div>`));
    });
    card.appendChild(fold);
  });

  card.appendChild(el(`<p class="disclaim">${esc(method.closing)}</p>`));
  return card;
}


/* Whether somebody can hold what they own.
 *
 * The one portfolio-level reading that lived only on the advice page, and the
 * one most worth having in front of somebody looking at their numbers: it
 * pairs what a fund demands with what this person has actually sustained, and
 * neither half means much alone.
 *
 * Not a reason to sell anything. Somebody holding a demanding fund who cannot
 * sit through a fall has two options, and selling into a rising market is only
 * one of them -- the other is knowing in advance what it will feel like, which
 * is most of what makes it survivable.
 */
function canHoldCard(fit){
  if (!fit || !(fit.holdings || []).length) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.what_they_ask")}</p>
    <h2 class="display">${esc(fit.reading || '')}</h2>`));

  const list = el('<div style="margin-top:14px"></div>');
  fit.holdings.slice(0, 5).forEach(holding => {
    const score = num(holding.score);
    const tone = score >= 70 ? 'buy' : score >= 45 ? 'hold' : 'lean-reduce';
    list.appendChild(frag(`
      <div class="mover">
        <span class="mover-name">${esc(holding.name)}
          <span style="display:block;font-size:12px;color:var(--ink-4)">
            ${esc(holding.share_pct)}% of what you hold</span></span>
        <span style="text-align:right;white-space:nowrap">
          <b>${score}</b><span style="color:var(--ink-4);font-size:12px">/100</span>
          <span class="verdict ${tone}" style="display:block;margin-top:3px">${
            esc(String(holding.band || '').toLowerCase())}</span>
        </span>
      </div>`));
  });
  card.appendChild(list);
  card.appendChild(el(`<p class="disclaim">${esc(fit.note || '')}</p>`));
  return card;
}


/* One shape for every metric.
 *
 * The cards were bespoke, so heights varied by a factor of four and the figure
 * that mattered competed with the prose explaining it. A grid of tiles that
 * are different sizes reads as a list of unrelated things; a grid of tiles the
 * same size reads as one instrument panel, and the eye can compare across it.
 *
 * The anatomy, in the order somebody reads it:
 *
 *   eyebrow    what this is measuring, quiet
 *   value      the number, large enough to read across a room
 *   context    one line saying what the number means
 *   story      everything else, behind a tap
 *
 * The story matters as much as the number and belongs behind a tap because
 * somebody scanning eleven metrics is not reading eleven paragraphs. Somebody
 * who stops on one is, and they should not have to go elsewhere for it.
 */
function tile(spec){
  if (!spec || spec.value == null) return null;

  const card = el(`<section class="tile ${spec.tone || ''} ${spec.wide ? 'wide' : ''}"></section>`);

  card.appendChild(frag(`
    <p class="tile-eyebrow">${esc(spec.eyebrow || '')}</p>
    <p class="tile-value">${spec.prefix ? `<span class="tile-prefix">${
      esc(spec.prefix)}</span>` : ''}${esc(spec.value)}${
      spec.suffix ? `<span class="tile-suffix">${esc(spec.suffix)}</span>` : ''}</p>
    ${spec.context ? `<p class="tile-context">${esc(spec.context)}</p>` : ''}`));

  /* A small visual, where one says something the number cannot -- a shape, a
     spread, a direction. Optional by design: most metrics are better as a
     figure than as a decoration of one. */
  if (spec.visual){
    const holder = el('<div class="tile-visual"></div>');
    holder.appendChild(spec.visual);
    card.appendChild(holder);
  }

  if (spec.story){
    const fold = el(`<details class="tile-story">
      <summary>${esc(spec.storyLabel || 'why this matters')}</summary></details>`);
    if (typeof spec.story === 'string'){
      fold.appendChild(el(`<p>${esc(spec.story)}</p>`));
    } else {
      fold.appendChild(spec.story);
    }
    card.appendChild(fold);
  }

  if (spec.onClick){
    card.classList.add('tappable');
    card.addEventListener('click', e => {
      if (e.target.closest('.tile-story')) return;   // the fold is its own thing
      spec.onClick();
    });
  }

  return card;
}

/* A row of tiles that stays a row. The grid does the sizing so nothing has to
   claim a width, which is what made the old layout uneven. */
function tileGrid(tiles){
  const grid = el('<div class="tiles"></div>');
  tiles.filter(Boolean).forEach(t => grid.appendChild(t));
  return grid.children.length ? grid : null;
}


/* The instrument panel: every metric as one tile, in one grid.
 *
 * What each tile leads with is the figure somebody would quote — not the most
 * technically interesting one. "63% in capital goods" rather than a
 * Herfindahl index; "₹8.7 lakh" rather than a beta-adjusted downside
 * estimate. The technical version is in the story, where somebody who wants it
 * will look.
 */
function metricPanel(d, advice){
  const tiles = [];

  /* Growth, from the benchmark block -- there is no separate headline object,
     which two of these tiles assumed and rendered "0.0% over ? years" for. */
  const bench = d.benchmark;
  if (bench && bench.your_growth_pct != null){
    const values = (d.timeline || []).map(p => num(p.value));
    tiles.push(tile({
      eyebrow: T("dash.how_it_moved"),
      value: pct(num(bench.your_growth_pct), 1),
      context: `over ${esc(bench.years)} years`,
      visual: values.length > 2 ? sparkline(values) : null,
      story: "Growth between the first holding we can date and today. That is "
             + "not the same as the return on money that arrived in "
             + "instalments \u2014 the second needs every purchase, and where we "
             + "do not hold them the platform says so rather than showing the "
             + "first and calling it the second.",
    }));
  }

  const earned = xirrTile(d.xirr);
  if (earned) tiles.push(earned);

  /* Against the index. The most quoted number in any portfolio conversation. */
  if (bench && bench.difference != null){
    tiles.push(tile({
      eyebrow: T("dash.against_index"),
      prefix: bench.ahead ? "+\u20B9" : "\u2212\u20B9",
      value: money(Math.abs(num(bench.difference))),
      context: bench.ahead ? "ahead of just buying the market"
                           : "behind just buying the market",
      tone: bench.ahead ? 'gain' : 'loss',
      story: `The same money into NIFTYBEES on the same dates would be `
             + `\u20B9${money(bench.index_value)} today, against `
             + `\u20B9${money(bench.your_value)} here, since `
             + `${esc(bench.since)}.`,
    }));
  }

  /* Concentration. The effective count says more than any single share does:
     twenty-three holdings behaving like six is the finding. */
  const conc = d.concentration;
  if (conc && conc.effective_holdings != null){
    const effective = num(conc.effective_holdings);
    tiles.push(tile({
      eyebrow: T("dash.how_spread"),
      value: effective.toFixed(1),
      context: `equal holdings, from ${esc(conc.positions)}`,
      tone: effective < 8 ? 'warn' : '',
      story: `${esc(conc.reading || '')}. ${esc(conc.method || '')}`,
    }));
  }

  /* Sector, counting through the funds. */
  const sectorBlock = d.sectors || {};
  const listed = (sectorBlock.sectors || []).filter(
    x => (x.sector || '').toLowerCase() !== 'not classified');
  if (listed.length){
    const top = listed[0];
    tiles.push(tile({
      eyebrow: T("dash.what_exposed_to"),
      value: pct(num(top.share_pct), 0),
      context: `in ${esc((top.sector || '').toLowerCase())}`,
      tone: num(top.share_pct) >= 40 ? 'warn' : '',
      story: `Counting through what your funds hold as well as the shares you `
             + `own directly, across ${esc(sectorBlock.attributed_share_pct)}% of `
             + `the portfolio we can see into. Holdings that look separate can `
             + `be the same bet: when that industry has a bad year, most of `
             + `the portfolio has one.`,
    }));
  }

  /* What a fall would cost. The history figure where we have it, because it is
     the one beta understates. */
  const scenario = d.scenario;
  if (scenario){
    const twenty = (scenario.falls || []).find(f => num(f.market_fall_pct) === 20)
                   || (scenario.falls || [])[0];
    const history = scenario.history || {};
    const worst = history.would_lose || (twenty && twenty.you_lose);
    if (worst != null){
      tiles.push(tile({
        eyebrow: T("dash.if_market_turned"),
        prefix: "\u2212\u20B9",
        value: money(Math.abs(num(worst))),
        context: history.would_lose ? "if the worst already seen repeated"
                                    : "if the market fell a fifth",
        tone: 'loss',
        story: `${esc(scenario.method || '')} Beta is ${esc(scenario.beta)}, `
               + `and beta understates a crisis: correlations tighten exactly `
               + `when the diversification is meant to help.`,
      }));
    }
  }

  /* Tax. The number people act on soonest. */
  const tax = d.tax;
  if (tax && tax.estimated_tax != null){
    tiles.push(tile({
      eyebrow: T("dash.if_sold_today"),
      prefix: "\u20B9",
      value: money(tax.estimated_tax),
      context: "in capital gains tax",
      story: `Short-term gains of \u20B9${money(tax.short_term_gain)} at 20%, `
             + `long-term of \u20B9${money(tax.long_term_gain)} at 12.5% after `
             + `the \u20B9${money(tax.exempt)} annual exemption. `
             + `${esc(tax.method || '')}`,
    }));
  }

  /* How much it moves. */
  const vol = d.volatility;
  if (vol && vol.beta != null){
    tiles.push(tile({
      eyebrow: T("dash.how_much_moves"),
      value: num(vol.beta).toFixed(2),
      suffix: "\u00d7",
      context: "per rupee the market moves",
      tone: num(vol.beta) > 1.2 ? 'warn' : '',
      story: `${esc(vol.reading || '')}. ${esc(vol.method || '')}`,
    }));
  }

  /* What it pays. */
  const income = d.income;
  if (income && income.annual_income != null && num(income.annual_income) > 0){
    tiles.push(tile({
      eyebrow: T("dash.what_it_pays"),
      prefix: "\u20B9",
      value: money(income.annual_income),
      context: `a year \u00b7 ${pct(num(income.yield_on_cost), 2)} on what you paid`,
      story: esc(income.method || ''),
    }));
  }

  /* What is owed. Shown whether or not anything is recorded, because "we do
     not know what you owe" is a finding rather than an empty space -- and it is
     the one that caps every risk suggestion the platform makes. */
  const owed = d.owed;
  if (owed){
    if (!owed.recorded){
      tiles.push(tile({
        eyebrow: T("dash.what_you_owe"),
        value: "\u2014",
        context: "not recorded",
        story: owed.reading + " " + (owed.why_it_matters || ""),
        onClick: () => { location.href = '/profile.html#debts'; },
      }));
    } else {
      const expensive = num(owed.expensive_total) > 0;
      tiles.push(tile({
        eyebrow: T("dash.what_you_owe"),
        prefix: "\u20B9",
        value: money(owed.total),
        context: num(owed.monthly_emi) > 0
          ? `\u20B9${money(owed.monthly_emi)} a month across ${owed.count}`
          : `${owed.count} ${owed.count === 1 ? 'loan' : 'loans'}`,
        tone: expensive ? 'warn' : '',
        story: owed.reading,
      }));
    }
  }

  /* Drift, where a target exists. */
  const drift = d.drift;
  if (drift && drift.worst_gap_pct != null && !drift.in_line){
    tiles.push(tile({
      eyebrow: T("dash.mix_you_set"),
      value: num(drift.worst_gap_pct).toFixed(0),
      suffix: " pts",
      context: `off target \u00b7 ${esc(drift.out_of_line)} classes adrift`,
      tone: num(drift.worst_gap_pct) >= 15 ? 'warn' : '',
      story: "Markets do the drifting. What you hold now is not what you "
             + "decided to hold, and the gap grew without anybody deciding it "
             + "should.",
    }));
  }

  return tileGrid(tiles);
}


/* The decision, at the top.
 *
 * Protect, fix, optimise, invest — in that order, always. The tiers are not a
 * presentation choice: they are the claim that some problems make others
 * irrelevant, and a page that sorts by size instead gives confident advice in
 * the wrong order.
 *
 * Each action opens into what it involves, what it would achieve and what it
 * risks. Folded, because a reader deciding whether to act needs the headline
 * first and the reasoning only once they are considering it.
 */
const TIER_TONE = {1: 'protect', 2: 'fix', 3: 'optimise', 4: 'invest', 5: 'review'};

function decisionBlock(decision){
  if (!decision || decision.empty) return null;
  const tiers = decision.by_tier || [];
  const health = decision.health || {};

  const shell = el('<section class="decision"></section>');

  /* The health reading. A count rather than a score, and each number opens
     into the thing it counts. */
  shell.appendChild(frag(`
    <p class="decision-eyebrow">${T("decide.eyebrow")}</p>
    <h2 class="decision-reading display">${esc(health.reading || decision.reading || '')}</h2>`));

  if ((health.working || []).length){
    shell.appendChild(frag(`
      <ul class="working">${health.working.map(w =>
        `<li>${esc(w)}</li>`).join('')}</ul>`));
  }

  /* The risk ceiling, which decides what may be suggested at all. */
  const risk = decision.risk;
  if (risk && risk.name){
    shell.appendChild(el(`<p class="decision-risk">
      <b>${esc(risk.name)} risk</b> is the level these suggestions hold to.
      ${esc(risk.why || '')}</p>`));
  }

  if (!tiers.length){
    shell.appendChild(el(`<p class="decision-none">${
      esc(decision.reading || 'Nothing needs doing.')}</p>`));
    return shell;
  }

  tiers.forEach(tier => {
    const group = el(`<div class="tier ${TIER_TONE[tier.tier] || ''}"></div>`);
    group.appendChild(frag(`
      <p class="tier-name">${esc(tier.name)}</p>
      <p class="tier-why">${esc(tier.why_this_tier || '')}</p>`));

    (tier.actions || []).forEach(action => {
      const fold = el(`<details class="action">
        <summary>
          <span class="action-what">${esc(action.what)}</span>
          ${action.worth ? `<span class="action-worth">${esc(action.worth)}</span>` : ''}
        </summary></details>`);

      fold.appendChild(frag(`
        <p class="action-why">${esc(action.why)}</p>
        ${action.how ? `<p class="action-line"><b>How</b> ${esc(action.how)}</p>` : ''}
        ${action.impact ? `<p class="action-line"><b>Impact</b> ${esc(action.impact)}</p>` : ''}
        ${action.risk ? `<p class="action-line"><b>Risk</b> ${esc(action.risk)}</p>` : ''}
        ${action.costs ? `<p class="action-line"><b>Costs</b> ${esc(action.costs)}</p>` : ''}
        ${action.source ? `<p class="action-source">${esc(action.source)}</p>` : ''}`));
      group.appendChild(fold);
    });
    shell.appendChild(group);
  });

  /* What was considered and not suggested. An audit trail rather than an
     apology: "we thought about telling you to rebalance and decided not to,
     because you have two months of expenses saved" is more useful than the
     silence somebody would otherwise be left to interpret. */
  if ((decision.withheld || []).length){
    const fold = el(`<details class="withheld">
      <summary>${decision.withheld.length} thing${
        decision.withheld.length === 1 ? '' : 's'} we considered and did not suggest</summary>
      </details>`);
    decision.withheld.forEach(item => {
      fold.appendChild(frag(`
        <div class="withheld-item">
          <b>${esc(item.what)}</b>
          ${(item.why_not || []).map(r => `<p>${esc(r)}</p>`).join('')}
        </div>`));
    });
    shell.appendChild(fold);
  }

  /* How much of this rests on things we actually know. Confidence in a
     recommendation is mostly confidence in its inputs, and showing the first
     without the second asks to be trusted on tone. */
  const quality = decision.data_quality;
  if (quality){
    shell.appendChild(el(`<p class="decision-quality">
      <span class="quality-dot ${esc(quality.confidence)}"></span>
      ${esc(quality.reading)}</p>`));
  }

  const review = decision.review_on;
  if (review){
    shell.appendChild(el(`<p class="decision-review">Worth looking again in
      ${esc(review.months)} months. ${esc(review.why || '')}</p>`));
  }

  return shell;
}


/* What changed while you were away.
 *
 * First on the page when there is something to say, and absent entirely when
 * there is not. A panel that appears every visit saying "nothing changed" is a
 * panel people learn to scroll past, taking the ones that matter with it.
 *
 * Dismissible, and the dismissal is per visit rather than remembered: somebody
 * who closes it has read it, and somebody returning in three weeks should see
 * the next one.
 */
function awayBlock(away){
  if (!away || away.nothing_to_report) return null;

  const shell = el('<section class="away"></section>');

  if (away.quiet){
    /* Shown only after a long absence. A week of quiet is not worth a panel;
       three months of quiet is worth confirming, because somebody who has been
       away that long is wondering. */
    if (away.away_days < 30) return null;
    shell.appendChild(frag(`
      <p class="away-eyebrow">While you were away</p>
      <p class="away-quiet">${esc(away.reading)}</p>`));
    return shell;
  }

  shell.appendChild(frag(`
    <p class="away-eyebrow">While you were away \u00b7 last here ${
      esc(away.last_here || '')}</p>
    <h2 class="away-reading display">${esc(away.reading)}</h2>`));

  const list = el('<div class="away-list"></div>');
  (away.changes || []).forEach(change => {
    list.appendChild(frag(`
      <div class="away-change ${esc(change.tone || '')}">
        <b>${esc(change.headline)}</b>
        <p>${esc(change.detail)}</p>
      </div>`));
  });
  shell.appendChild(list);

  const close = el('<button type="button" class="away-close">Dismiss</button>');
  close.addEventListener('click', () => shell.remove());
  shell.appendChild(close);

  return shell;
}


/* Sharing and exporting.
 *
 * One panel rather than two buttons, because the two questions people have --
 * "can I send this to my accountant" and "can I get my data out" -- are asked
 * together and answered differently.
 *
 * The share dialogue shows the expiry before the link, not after. Somebody
 * about to send their whole financial position to a WhatsApp group should read
 * how long it lives before they read the URL.
 */
function shareBlock(investorId){
  const card = el('<section class="card w12 sharing"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">Take it with you</p>
    <h2 class="display">Share this, or get your data out</h2>`));

  const row = el('<div class="share-row"></div>');

  /* --- a link --- */
  const linkSide = el(`<div class="share-side">
    <b>Send somebody a link</b>
    <p>Read only, and it stops working on a date you choose. You can withdraw
    it before then, and you will see how many times it has been opened.</p>
  </div>`);

  const controls = el(`<div class="share-controls">
    <select id="shareScope">
      <option value="advice">The advice</option>
      <option value="holdings">The holdings</option>
      <option value="both">Both</option>
    </select>
    <select id="shareDays">
      <option value="1">1 day</option>
      <option value="7" selected>7 days</option>
      <option value="30">30 days</option>
    </select>
    <button type="button" class="btn-share">Make a link</button>
  </div>`);
  linkSide.appendChild(controls);

  const result = el('<div class="share-result" hidden></div>');
  linkSide.appendChild(result);

  controls.querySelector('button').addEventListener('click', async () => {
    const button = controls.querySelector('button');
    button.disabled = true;
    button.textContent = 'Making\u2026';
    try{
      const made = await post(`/share/${investorId}`, {
        scope: document.getElementById('shareScope').value,
        days: Number(document.getElementById('shareDays').value),
      });
      const url = `${location.origin}/shared.html?t=${made.token}`;
      result.innerHTML = '';
      result.appendChild(frag(`
        <p class="share-note">${esc(made.note)}</p>
        <div class="share-url"><input readonly value="${esc(url)}"></div>`));
      const copy = el('<button type="button" class="btn-share ghost">Copy</button>');
      copy.addEventListener('click', () => {
        navigator.clipboard.writeText(url).then(() => {
          copy.textContent = 'Copied';
          setTimeout(() => { copy.textContent = 'Copy'; }, 2000);
        });
      });
      result.querySelector('.share-url').appendChild(copy);
      result.hidden = false;
      loadShares(investorId, card);
    }catch(err){
      result.innerHTML = '<p class="share-note">Could not make a link.</p>';
      result.hidden = false;
    }finally{
      button.disabled = false;
      button.textContent = 'Make a link';
    }
  });

  /* --- export --- */
  const exportSide = el(`<div class="share-side">
    <b>Take your data</b>
    <p>Everything this platform holds about you \u2014 holdings, transactions,
    goals, what you owe \u2014 in a format that opens without us.</p>
    <div class="share-controls">
      <a class="btn-share ghost" href="${API}/export/${investorId}">Everything (JSON)</a>
      <a class="btn-share ghost" href="${API}/export/${investorId}/holdings.csv">Holdings (CSV)</a>
      <a class="btn-share ghost" href="${API}/export/${investorId}/transactions.csv">Transactions (CSV)</a>
    </div>
  </div>`);

  row.appendChild(linkSide);
  row.appendChild(exportSide);
  card.appendChild(row);

  const existing = el('<div class="share-existing"></div>');
  card.appendChild(existing);
  loadShares(investorId, card);

  return card;
}

/* Every link somebody has made, including the dead ones. "Did I ever share
   this" is a question asked about links that no longer work. */
async function loadShares(investorId, card){
  const holder = card.querySelector('.share-existing');
  if (!holder) return;
  try{
    const data = await get(`/share/${investorId}`);
    const shares = data.shares || [];
    holder.innerHTML = '';
    if (!shares.length) return;

    holder.appendChild(el('<p class="eyebrow" style="margin-top:20px">Links you have made</p>'));
    shares.forEach(share => {
      const state = share.revoked ? 'withdrawn'
                  : share.expired ? 'expired'
                  : 'live until ' + new Date(share.expires_at)
                      .toLocaleDateString('en-IN', {day:'numeric', month:'short'});
      const line = el(`<div class="share-line ${share.live ? 'live' : ''}">
        <span><b>${esc(share.scope)}</b> \u00b7 ${esc(state)} \u00b7 opened ${
          share.opened} time${share.opened === 1 ? '' : 's'}</span>
      </div>`);
      if (share.live){
        const stop = el('<button type="button" class="link-btn">Withdraw</button>');
        stop.addEventListener('click', async () => {
          await del(`/share/${investorId}/${share.id}`);
          loadShares(investorId, card);
        });
        line.appendChild(stop);
      }
      holder.appendChild(line);
    });
  }catch(err){ /* the rest of the page is fine without it */ }
}


/* The analysis, on the row.
 *
 * Everything this platform computes about a holding sat one click deep behind
 * a row that gave no sign there was anything to click -- so the work was there
 * and invisible, which for a reader is the same as absent.
 *
 * Two figures, because a row can carry two and stay scannable. Sortino because
 * it counts only the falls, which is what holding something actually feels
 * like; and the band for funds, because how hard a thing has been to sit
 * through is the most useful thing to know before opening anything.
 */
function paintSummaries(){
  if (!state.summaries) return;

  document.querySelectorAll('.holding[data-instrument]').forEach(row => {
    if (row.querySelector('.holding-figures')) return;
    const summary = state.summaries[row.getAttribute('data-instrument')];
    if (!summary) return;

    const bits = [];

    if (summary.sortino != null){
      const tone = summary.sortino >= 1 ? 'good'
                 : summary.sortino >= 0.5 ? '' : 'thin';
      bits.push(`<span class="fig-chip ${tone}" title="${esc(summary.reading || '')}">
        <b>${Number(summary.sortino).toFixed(2)}</b> sortino</span>`);
    }

    if (summary.demands_score != null){
      bits.push(`<span class="fig-chip ${summary.demands_hard ? 'hard' : ''}"
        title="How hard this fund has been to sit through, from its own history">
        <b>${summary.demands_score}</b>/100 to hold</span>`);
    } else if (summary.beta != null){
      bits.push(`<span class="fig-chip"
        title="How much this moves per rupee the market moves">
        <b>${Number(summary.beta).toFixed(2)}</b>x market</span>`);
    }

    if (!bits.length) return;

    const strip = el(`<div class="holding-figures">${bits.join('')}</div>`);
    const name = row.querySelector('.holding-name') || row.firstElementChild;
    if (name) name.appendChild(strip);
  });
}


/* How bad a bad day looks.
 *
 * Volatility says how much something moves on average, which is the wrong
 * question when somebody is deciding whether they can sleep. This is in
 * rupees, and it is about the tail rather than the middle.
 *
 * Expected shortfall gets equal billing with the threshold, deliberately. Value
 * at risk says how bad it gets at the edge of the ordinary; shortfall says how
 * bad it gets beyond, and beyond is where portfolios are actually damaged.
 */
function tailCard(tail){
  if (!tail) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.a_bad_day")}</p>
    <h2 class="display">How bad it gets</h2>`));

  if (!tail.computable){
    card.appendChild(el(`<p class="card-note" style="margin-top:10px">${
      esc(tail.why)}</p>`));
    return card;
  }

  const rows = [
    ['A bad day', tail.daily.var_95, tail.daily.shortfall_95,
     'one day in twenty'],
    ['A bad month', tail.monthly.var_95, tail.monthly.shortfall_95,
     'one month in twenty'],
    ['A bad year', tail.annual.var_95, tail.annual.shortfall_95,
     'one year in twenty'],
  ];

  const table = el(`<table class="tail">
    <thead><tr><th></th><th>Worse than</th><th>Typically</th></tr></thead>
    <tbody></tbody></table>`);
  const body = table.querySelector('tbody');

  rows.forEach(([label, threshold, beyond, note]) => {
    body.appendChild(frag(`<tr>
      <td><b>${esc(label)}</b><span class="tail-note">${esc(note)}</span></td>
      <td class="num">\u20B9${money(threshold)}</td>
      <td class="num worse">\u20B9${money(beyond)}</td>
    </tr>`));
  });
  card.appendChild(table);

  card.appendChild(el(`<p class="card-note" style="margin-top:12px">
    The worst single day in the history we hold would have cost
    <b>\u20B9${money(tail.worst_day.loss)}</b>
    (${esc(tail.worst_day.pct)}%).</p>`));

  const story = el('<details class="tile-story" style="margin-top:12px"></details>');
  story.appendChild(frag('<summary>what these numbers are</summary>'));
  [tail.what_it_means, tail.on_shortfall, tail.on_scaling].forEach(text => {
    if (text) story.appendChild(el(`<p>${esc(text)}</p>`));
  });
  const c = tail.coverage || {};
  story.appendChild(el(`<p>Computed from ${esc(c.days)} days of combined price
    history across ${esc(c.holdings)} of your ${esc(c.of_holdings)} holdings,
    weighted as you hold them today \u2014 which is what captures the holdings
    moving together, and a sum of individual figures would not.</p>`));
  card.appendChild(story);

  return card;
}


/* What a decade makes obvious.
 *
 * Two cards, because they answer different questions with the same technique:
 * what the fees cost, and what raising the amount does. Both are only
 * persuasive over decades, and both are meaningless without the rate they rest
 * on being stated.
 */
function costDragCard(drag){
  if (!drag) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.what_fees_cost")}</p>
    <h2 class="display">${esc(drag.weighted_expense_pct)}% a year</h2>
    <p class="card-note" style="margin-top:6px">
      \u20B9${money(drag.annual_cost)} on \u20B9${money(drag.total)},
      against \u20B9${esc(drag.index_expense_pct)}% for an index fund</p>`));

  const table = el(`<table class="tail">
    <thead><tr><th>Held for</th><th>Yours</th><th>At index cost</th></tr></thead>
    <tbody></tbody></table>`);
  const body = table.querySelector('tbody');

  (drag.over_time || []).forEach(row => {
    body.appendChild(frag(`<tr>
      <td><b>${row.years} years</b></td>
      <td class="num">\u20B9${money(row.yours)}</td>
      <td class="num"><span class="better">\u20B9${money(row.at_index_cost)}</span>
        <span class="tail-note">+\u20B9${money(row.difference)}</span></td>
    </tr>`));
  });
  card.appendChild(table);

  card.appendChild(el(`<p class="card-note" style="margin-top:12px">${
    esc(drag.reading)}</p>`));

  const story = el('<details class="tile-story" style="margin-top:11px"></details>');
  story.appendChild(frag('<summary>what this rests on</summary>'));
  [drag.estimated, drag.on_the_rate].forEach(text => {
    if (text) story.appendChild(el(`<p>${esc(text)}</p>`));
  });
  card.appendChild(story);
  return card;
}

/* Raising the amount. The increases are what compound, and almost nobody sees
   the difference because almost nobody is shown it. */
function stepUpCard(step){
  if (!step) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.raising_it")}</p>`));

  if (!step.known){
    card.appendChild(frag(`<h2 class="display">Nothing regular to project</h2>
      <p class="card-note" style="margin-top:8px">${esc(step.why)}</p>`));
    return card;
  }

  card.appendChild(frag(`
    <h2 class="display">\u20B9${money(step.monthly)} a month</h2>
    <p class="card-note" style="margin-top:6px">what you actually put in, from
      your own record</p>`));

  /* Twenty years across the step-up rates. One horizon rather than five,
     because a table with twenty-five cells is a spreadsheet and the argument
     is made by one row. */
  const table = el(`<table class="tail">
    <thead><tr><th>Raised each year by</th><th>In 20 years</th>
    <th>If it goes poorly</th></tr></thead><tbody></tbody></table>`);
  const body = table.querySelector('tbody');

  (step.paths || []).forEach(path => {
    const row = (path.by_year || []).find(r => r.years === 20);
    if (!row) return;
    body.appendChild(frag(`<tr>
      <td><b>${path.step_up_pct ? path.step_up_pct + '%' : 'nothing'}</b>
        <span class="tail-note">\u20B9${money(row.invested)} put in</span></td>
      <td class="num">\u20B9${money(row.value)}</td>
      <td class="num" style="color:var(--ink-3)">\u20B9${money(row.if_worse)}</td>
    </tr>`));
  });
  card.appendChild(table);

  card.appendChild(el(`<p class="card-note" style="margin-top:12px">${
    esc(step.reading)}</p>`));

  const story = el('<details class="tile-story" style="margin-top:11px"></details>');
  story.appendChild(frag('<summary>what this rests on</summary>'));
  if (step.on_the_rate) story.appendChild(el(`<p>${esc(step.on_the_rate)}</p>`));
  card.appendChild(story);
  return card;
}


/* Six kinds of trouble.
 *
 * Ordered worst first, because the one that would hurt most is the one worth
 * reading. Each opens into why that scenario does what it does to this
 * portfolio rather than to portfolios in general -- which is the whole reason
 * for computing it instead of quoting a constant.
 */
function shocksCard(shocks){
  if (!shocks) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.six_shocks")}</p>`));

  if (!shocks.computable){
    card.appendChild(frag(`<h2 class="display">Nothing here moves with the market</h2>
      <p class="card-note" style="margin-top:8px">${esc(shocks.why)}</p>`));
    return card;
  }

  card.appendChild(el(`<h2 class="display">${esc(shocks.reading)}</h2>`));

  const worst = Math.max(...(shocks.shocks || []).map(s => Math.abs(num(s.your_fall_pct))));

  const list = el('<div class="shocks">');
  (shocks.shocks || []).forEach(shock => {
    const fall = Math.abs(num(shock.your_fall_pct));
    const width = worst > 0 ? (fall / worst * 100) : 0;

    const fold = el(`<details class="shock ${esc(shock.severity)}">
      <summary>
        <span class="shock-name">${esc(shock.name)}</span>
        <span class="shock-bar"><span style="width:${width.toFixed(1)}%"></span></span>
        <span class="shock-loss">\u2212\u20B9${money(shock.loss)}
          <span>${esc(shock.your_fall_pct)}%</span></span>
      </summary></details>`);

    const body = el('<div class="shock-body"></div>');
    body.appendChild(el(`<p>${esc(shock.detail)} ${esc(shock.why)}</p>`));

    if ((shock.notable_sectors || []).length){
      const bits = shock.notable_sectors.map(s =>
        `${esc(s.share_pct)}% in ${esc(s.sector)} takes it ${esc(s.direction)}`);
      body.appendChild(el(`<p class="shock-sectors">${bits.join(' \u00b7 ')}</p>`));
    }

    body.appendChild(el(`<p class="shock-detail">The market falls
      ${esc(shock.market_fall_pct)}% in this scenario; this portfolio falls
      ${esc(shock.your_fall_pct)}%, leaving \u20B9${money(shock.left)}.
      ${shock.anchor ? 'Anchored on: ' + esc(shock.anchor) : ''}</p>`));

    fold.appendChild(body);
    list.appendChild(fold);
  });
  card.appendChild(list);

  const story = el('<details class="tile-story" style="margin-top:14px"></details>');
  story.appendChild(frag('<summary>how these are worked out</summary>'));
  [shocks.method, shocks.caveat].forEach(text => {
    if (text) story.appendChild(el(`<p>${esc(text)}</p>`));
  });
  story.appendChild(el(`<p>Computed against the ${esc(shocks.exposed_pct)}% of
    this portfolio that moves with the equity market, at a beta of
    ${esc(shocks.beta)}.</p>`));
  card.appendChild(story);

  return card;
}


/* Where each fund stands among the ones doing the same job.
 *
 * A fund returning fourteen per cent is good or poor entirely depending on
 * what its peers returned, and the return without the comparison is half a
 * fact. Quartiles rather than ranks, because "bottom quarter" is what somebody
 * can act on and "26 of 27" is what they check afterwards.
 *
 * Ordered by money rather than by rank: the bottom-quartile fund holding two
 * per cent of a portfolio is a curiosity, and the one holding a third is the
 * finding.
 */
function peersCard(peers){
  if (!peers) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.against_peers")}</p>`));

  if (!peers.computable){
    card.appendChild(frag(`<h2 class="display">Cannot place these against peers</h2>
      <p class="card-note" style="margin-top:8px">${esc(peers.why)}</p>`));
    return card;
  }

  card.appendChild(el(`<h2 class="display">${esc(peers.reading)}</h2>`));

  const table = el(`<table class="peers">
    <thead><tr>
      <th>Fund</th><th>Category</th><th>Standing</th><th>Rolling 3y</th>
    </tr></thead><tbody></tbody></table>`);
  const body = table.querySelector('tbody');

  (peers.funds || []).forEach(fund => {
    const tone = fund.quartile === 1 ? 'top'
               : fund.quartile === 4 ? 'bottom' : '';
    const median = fund.roll3_median_pct;
    const catMedian = fund.category_median_pct;

    body.appendChild(frag(`<tr class="${tone}">
      <td>
        <span class="peer-name">${esc(fund.name)}</span>
        <span class="peer-share">${esc(fund.share_pct)}% of your funds
          \u00b7 \u20B9${money(fund.value)}</span>
      </td>
      <td class="peer-cat">${esc((fund.category || '').replace(/^.*Scheme - /, ''))}</td>
      <td>
        <span class="peer-quartile ${tone}">${esc(fund.quartile_name)}</span>
        <span class="peer-share">${esc(fund.rank)} of ${esc(fund.of)}</span>
      </td>
      <td class="num">
        ${median != null ? esc(median) + '%' : '\u2014'}
        ${catMedian != null
          ? `<span class="peer-share">category ${esc(catMedian)}%</span>` : ''}
      </td>
    </tr>`));
  });
  card.appendChild(table);

  if ((peers.unplaced || []).length){
    card.appendChild(el(`<p class="card-note" style="margin-top:10px">
      ${peers.unplaced.length} other${peers.unplaced.length === 1 ? '' : 's'}
      could not be placed \u2014 either the category is too small for quartiles
      to mean anything, or we do not hold enough of its history.</p>`));
  }

  const story = el('<details class="tile-story" style="margin-top:12px"></details>');
  story.appendChild(frag('<summary>how this is worked out</summary>'));
  [peers.method, peers.what_this_is_not].forEach(text => {
    if (text) story.appendChild(el(`<p>${esc(text)}</p>`));
  });
  card.appendChild(story);

  return card;
}

/* What the money actually earned, or why we will not say.
 *
 * Small, because the honest answer here is usually a refusal and a refusal
 * does not need a panel. Where it computes, it belongs beside the growth
 * figure it corrects. */
function xirrTile(x){
  if (!x) return null;

  if (!x.computable){
    return tile({
      eyebrow: T("dash.what_you_earned"),
      value: "\u2014",
      context: "not enough of the purchases",
      story: x.why + (x.what_would_help ? ' ' + x.what_would_help : ''),
    });
  }

  return tile({
    eyebrow: T("dash.what_you_earned"),
    value: x.xirr_pct + '%',
    suffix: " a year",
    context: `on ${x.flows} purchases over ${x.years} years`,
    tone: num(x.xirr_pct) >= 0 ? 'gain' : 'loss',
    story: x.reading + ' ' + x.what_it_is,
  });
}


/* Ariv.
 *
 * A question box rather than a chat window, because the difference matters:
 * somebody asking one question and getting a grounded answer has been served
 * better than somebody chatting for twenty minutes. The suggestions are there
 * so nobody faces an empty box and asks the one thing it cannot do.
 *
 * Every answer says where it came from. A figure looked up from a computation
 * and a sentence generated by a model are different kinds of claim, and a
 * reader deciding whether to act should be able to tell them apart.
 */
function arivPanel(investorId){
  const card = el('<section class="card w12 ariv"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.ask_ariv")}</p>
    <h2 class="display">Ask about any of this</h2>
    <p class="card-note" style="margin-top:6px;max-width:60ch">Answers come
      from what this platform has computed about your holdings. Where it cannot
      answer from that, it says so rather than guessing.</p>`));

  const thread = el('<div class="ariv-thread"></div>');
  card.appendChild(thread);

  const chips = el('<div class="ariv-chips"></div>');
  card.appendChild(chips);

  const box = el(`<div class="ariv-box">
    <input type="text" placeholder="What should I do first?" aria-label="Ask about your portfolio">
    <button type="button">Ask</button>
  </div>`);
  card.appendChild(box);

  const input = box.querySelector('input');
  const button = box.querySelector('button');
  const session = 'ariv-' + Date.now();
  let turn = 0;

  async function ask(question){
    if (!question || !question.trim()) return;
    turn += 1;

    thread.appendChild(frag(`<div class="ariv-q">${esc(question)}</div>`));
    const waiting = el('<div class="ariv-a waiting">…</div>');
    thread.appendChild(waiting);
    thread.scrollTop = thread.scrollHeight;

    input.value = '';
    button.disabled = true;

    try{
      const reply = await post(`/ariv/${investorId}`, {
        question, session_id: session, turn,
      });
      waiting.classList.remove('waiting');
      waiting.classList.toggle('refused', !!reply.refused);
      waiting.textContent = reply.answer;

      /* Where the answer came from. A computation and a generated sentence
         are different kinds of claim and a reader should be able to tell. */
      const from = reply.route === 'deterministic' ? 'computed from your holdings'
                 : reply.route === 'generated' ? 'reasoned, not looked up'
                 : null;
      if (from){
        waiting.appendChild(el(`<span class="ariv-from">${esc(from)}</span>`));
      }

      if (reply.at_limit){
        thread.appendChild(el(`<div class="ariv-a">That is a long
          conversation. Worth starting fresh, or taking the rest to somebody
          who can see more than a portfolio.</div>`));
        button.disabled = true;
        input.disabled = true;
        return;
      }
    }catch(err){
      waiting.classList.remove('waiting');
      waiting.classList.add('refused');
      waiting.textContent = 'Something went wrong asking that.';
    }finally{
      if (!input.disabled) button.disabled = false;
      thread.scrollTop = thread.scrollHeight;
      input.focus();
    }
  }

  button.addEventListener('click', () => ask(input.value));
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') ask(input.value);
  });

  /* The suggestions, so the first question is an easy one. */
  get(`/ariv/${investorId}/suggestions`)
    .then(data => {
      (data.suggestions || []).forEach(text => {
        const chip = el(`<button type="button" class="ariv-chip">${esc(text)}</button>`);
        chip.addEventListener('click', () => ask(text));
        chips.appendChild(chip);
      });
    })
    .catch(() => { /* the box works without them */ });

  return card;
}


/* Where this might end up.
 *
 * A fan rather than a line. The single projected number is the least useful
 * thing a projection produces -- half the paths land below it, and a curve
 * drawn through the middle sets an expectation the first bad quarter destroys.
 *
 * So the band is the point and the median is drawn inside it rather than on
 * its own. And where the history is too good to project from, the card says so
 * instead of showing a tempered fantasy.
 */
function forwardCard(forward){
  if (!forward) return null;

  // Half width, so it pairs with protection. As w12 it spanned the row and
  // left protection alone with an empty half beside it -- the void in the
  // bottom of the risk view.
  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.where_it_might_go")}</p>`));

  if (!forward.computable){
    card.appendChild(frag(`
      <h2 class="display">This one we will not project</h2>
      <p class="card-note" style="margin-top:8px;max-width:64ch">${
        esc(forward.why)}</p>`));
    if (forward.what_would_help){
      card.appendChild(el(`<p class="card-note" style="margin-top:8px">${
        esc(forward.what_would_help)}</p>`));
    }
    return card;
  }

  card.appendChild(el(`<h2 class="display">${esc(forward.reading)}</h2>`));

  /* The fan. Each horizon is a bar from the unlucky fifth percentile to the
     lucky ninety-fifth, with the median marked -- scaled against the widest
     so the spreading is visible rather than described. */
  const widest = Math.max(...forward.horizons.map(h => num(h.best_95)));

  const fan = el('<div class="fan"></div>');
  forward.horizons.forEach(h => {
    const low = num(h.worst_5) / widest * 100;
    const high = num(h.best_95) / widest * 100;
    const mid = num(h.median) / widest * 100;
    const invested = num(h.invested) / widest * 100;

    fan.appendChild(frag(`<div class="fan-row">
      <div class="fan-label">
        <b>${h.years} year${h.years === 1 ? '' : 's'}</b>
        <span>\u20B9${money(h.invested)} in</span>
      </div>
      <div class="fan-track">
        <span class="fan-band" style="left:${low.toFixed(1)}%;
          width:${(high - low).toFixed(1)}%"></span>
        <span class="fan-median" style="left:${mid.toFixed(1)}%"></span>
        <span class="fan-invested" style="left:${invested.toFixed(1)}%"
          title="what went in"></span>
      </div>
      <div class="fan-figures">
        <b>\u20B9${money(h.median)}</b>
        <span>\u20B9${money(h.worst_5)} to \u20B9${money(h.best_95)}</span>
      </div>
    </div>`));
  });
  card.appendChild(fan);

  const ten = forward.horizons.find(h => h.years === 10);
  if (ten){
    card.appendChild(el(`<p class="card-note" style="margin-top:14px;max-width:74ch">
      The band is the ninety per cent range: one path in twenty finishes below
      the left edge and one in twenty above the right. The mark inside is the
      median and the faint line is what went in.
      Over ten years, ${esc(ten.chance_of_loss)} ended below that.</p>`));
  }

  const story = el('<details class="tile-story" style="margin-top:12px"></details>');
  story.appendChild(frag('<summary>what this rests on</summary>'));
  [forward.on_the_drift, forward.method, forward.why_your_own, forward.caveat]
    .forEach(text => {
      if (text) story.appendChild(el(`<p>${esc(text)}</p>`));
    });
  story.appendChild(el(`<p>Observed return
    ${esc(forward.observed_return_pct)}% a year over
    ${Math.round(num(forward.history_days) / 252)} years; these paths assume
    ${esc(forward.assumed_return_pct)}%.</p>`));
  card.appendChild(story);

  return card;
}


/* What happens to the people who depend on you.
 *
 * The one card here that is not about the person reading it. Everything else
 * answers "how is my money doing"; this answers "what happens to my family if
 * it stops coming in", and the two are worth keeping visibly apart.
 *
 * The cover figure is deliberately not in the totals anywhere. A term policy's
 * sum assured sat among the holdings on a real account and was counted as
 * wealth -- three and a half crore of promise inflating a portfolio from a
 * crore to four and a half, and putting the family's protection on a list of
 * things to sell.
 */
function protectionCard(cover){
  if (!cover) return null;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.protection")}</p>`));

  if (!cover.recorded){
    card.appendChild(frag(`
      <h2 class="display">No cover recorded</h2>
      <p class="card-note" style="margin-top:8px">${esc(cover.reading)}</p>`));
    const go = el('<a class="gap-fix" href="/add.html">Record a policy \u2192</a>');
    card.appendChild(go);
    return card;
  }

  card.appendChild(frag(`
    <h2 class="display">${esc(cover.life_cover_reads)}</h2>
    <p class="card-note" style="margin-top:4px">of life cover</p>`));

  const gap = cover.gap;
  if (gap && gap.life_short_reads){
    card.appendChild(frag(`<p class="short-by">Short by
      <b>${esc(gap.life_short_reads)}</b></p>`));
  }

  const list = el('<div class="policies"></div>');
  (cover.policies || []).forEach(p => {
    list.appendChild(frag(`<div class="policy">
      <span>${esc(p.label)}${p.insurer ? ' \u00b7 ' + esc(p.insurer) : ''}</span>
      <b>${esc(p.cover_reads)}</b>
    </div>`));
  });
  card.appendChild(list);

  if (num(cover.premiums_a_year) > 0){
    card.appendChild(el(`<p class="card-note" style="margin-top:10px">
      \u20B9${money(cover.premiums_a_year)} a year in premiums.</p>`));
  }

  card.appendChild(el(`<p class="card-note" style="margin-top:10px">${
    esc(cover.reading)}</p>`));

  const story = el('<details class="tile-story" style="margin-top:11px"></details>');
  story.appendChild(frag('<summary>why this is not in your total</summary>'));
  story.appendChild(el(`<p>${esc(cover.on_value)}</p>`));
  const need = cover.need || {};
  if (need.how_worked_out){
    story.appendChild(el(`<p>How much would be needed: ${esc(need.how_worked_out)}</p>`));
  }
  if ((need.we_do_not_know || []).length){
    story.appendChild(el(`<p>We do not know ${esc(need.we_do_not_know.join(' or '))},
      so the figure above is what you have rather than a verdict on it.</p>`));
  }
  card.appendChild(story);

  return card;
}



/* The snapshot.
 *
 * Everything that matters on one page, in the order somebody would ask for it:
 * what it is worth, what it has done, what is winning and losing, then the
 * story of how it got there, then the three things worth knowing — and then
 * where to go to understand any of it properly.
 *
 * The rest of this platform is thorough and that thoroughness is the problem
 * for somebody with four minutes. This page is for them, and it is honest
 * about being a summary rather than pretending to be the whole thing.
 */
function snapshotNumbers(d, view){
  const h = view.headline || {};
  const owed = d.owed || {};
  const bench = d.benchmark || {};

  const worth = num(h.current) - (owed.recorded ? num(owed.total) : 0);

  const wrap = el('<section class="snap-numbers"></section>');

  wrap.appendChild(frag(`
    <div class="snap-hero">
      <p class="eyebrow">What you are worth</p>
      <h2 class="snap-big">\u20B9${money(worth)}</h2>
      <p class="snap-sub">
        \u20B9${money(h.current)} held${
          owed.recorded && num(owed.total) > 0
            ? `, less \u20B9${money(owed.total)} owed` : ''}
        \u00b7 ${h.positions} holdings
      </p>
    </div>`));

  /* Where the gain covers only part of the portfolio, say so under every
     figure derived from it.
     
     Four holdings here were entered without a purchase price, so the gain,
     the return and the yearly rate all describe about half the money. The
     figures are right; a reader who does not know which half they describe
     will reasonably wonder why twenty-three lakh of gain sits under a crore
     of portfolio. */
  const covers = num(h.gain_covers_pct);
  const partial = covers > 0 && covers < 95;
  const onPart = partial ? ` \u00b7 the ${h.gain_covers_pct}% we can price` : '';

  const figures = [
    ["Put in", `\u20B9${money(h.invested)}`,
     partial ? `across ${h.positions - (h.without_cost || 0)} of ${h.positions} holdings`
             : "what you can account for"],
    ["Gained", `${num(h.gain) >= 0 ? '+' : ''}\u20B9${money(h.gain)}`,
     `${h.return_pct}% on that${onPart}`],
    ["A year", `${h.cagr_pct}%`, `over ${h.held_years} years${onPart}`],
    ["Against the index",
     bench.difference
       ? `${bench.ahead ? '+' : '\u2212'}\u20B9${money(bench.difference)}`
       : "\u2014",
     bench.ahead ? "ahead of just buying it" : "behind just buying it"],
  ];

  const grid = el('<div class="snap-figures"></div>');
  figures.forEach(([label, value, note]) => {
    grid.appendChild(frag(`<div class="snap-fig">
      <p class="snap-fig-label">${esc(label)}</p>
      <p class="snap-fig-value">${value}</p>
      <p class="snap-fig-note">${esc(note)}</p>
    </div>`));
  });
  wrap.appendChild(grid);

  if (partial){
    wrap.appendChild(el(`<p class="snap-caveat">
      ${h.without_cost} of your ${h.positions} holdings were recorded without a
      purchase price, so the gain, the return and the yearly rate above
      describe the ${h.gain_covers_pct}% of your money we can price on both
      sides. The total at the top is everything.
      <a href="/add.html">Add what you paid \u2192</a></p>`));
  }

  return wrap;
}

function snapshotMovers(view){
  const m = view.movers || {};
  const best = (m.best || [])[0];
  const worst = (m.worst || [])[0];
  if (!best && !worst) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`<p class="eyebrow">Winning and losing</p>`));

  const pair = el('<div class="snap-pair"></div>');
  [[best, 'won', 'What has done best'],
   [worst, 'lost', 'What has done worst']].forEach(([who, kind, label]) => {
    if (!who) return;
    pair.appendChild(frag(`<div class="snap-mover ${kind}">
      <p class="snap-fig-label">${esc(label)}</p>
      <p class="snap-mover-name">${esc(who.name)}</p>
      <p class="snap-mover-pct">${num(who.gain_pct) >= 0 ? '+' : ''}${
        who.gain_pct}%</p>
      <p class="snap-fig-note">\u20B9${money(who.value)} held</p>
    </div>`));
  });
  card.appendChild(pair);
  return card;
}

function snapshotStory(guide){
  if (!guide) return null;
  const standing = guide.standing || {};
  const wrong = guide.wrong || {};
  const first = guide.first || {};

  const card = el('<section class="card w12 guide"></section>');
  card.appendChild(frag(`<p class="eyebrow">How this got here</p>`));
  if (standing.reading){
    card.appendChild(el(`<p class="guide-lead">${esc(standing.reading)}</p>`));
  }
  if (wrong.reading){
    card.appendChild(el(`<p class="guide-wrong">${esc(wrong.reading)}</p>`));
  }
  if (first.do){
    // The same structure the guide block itself uses. guide-act is the
    // container -- the heading class is guide-do, and using the wrapper as
    // the heading rendered it at body size.
    const act = el('<div class="guide-act"></div>');
    act.appendChild(frag(`
      <p class="guide-eyebrow">And the first thing to do about it</p>
      <h2 class="guide-do display">${esc(first.do)}</h2>
      ${first.why ? `<p class="guide-why">${esc(first.why)}</p>` : ''}`));
    card.appendChild(act);
  }
  return card;
}

/* The good, the bad and the ugly, in a sentence each.
 *
 * Not a summary of the findings -- a verdict. Somebody who reads only this
 * should come away knowing whether their portfolio is in trouble, and the
 * three-part shape is honest about the fact that most portfolios are some of
 * each rather than one thing.
 */
function snapshotVerdict(d, bench){
  const findings = (d.findings || {}).findings || [];
  const ugly = findings.filter(f => f.severity === 'act');
  const bad = findings.filter(f => f.severity === 'consider');

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`<p class="eyebrow">The short version</p>`));

  const rows = el('<div class="short-take"></div>');

  const good = [];
  if (bench && bench.ahead){
    good.push(`You are ahead of simply buying the index, by \u20B9${
      money(bench.difference)} over ${bench.years} years.`);
  }
  if (num((d.views && d.views.everything && d.views.everything.headline || {}).gain) > 0){
    good.push('The portfolio is worth more than what went into it.');
  }

  [['good', 'The good', good.length ? good[0]
      : 'Nothing here stands out as working especially well yet.'],
   ['bad', 'The bad', bad.length
      ? `${bad.length} thing${bad.length === 1 ? '' : 's'} worth attention. ${
          bad[0].headline}.`
      : 'Nothing pressing.'],
   ['ugly', 'The ugly', ugly.length
      ? `${ugly[0].headline}. ${ugly.length > 1
          ? `And ${ugly.length - 1} more that could cost real money if left.`
          : 'This one could cost real money if left alone.'}`
      : 'Nothing here is urgent, which is worth knowing in itself.']]
    .forEach(([kind, label, text]) => {
      rows.appendChild(frag(`<div class="take-row ${kind}">
        <p class="take-label">${esc(label)}</p>
        <p class="take-text">${esc(text)}</p>
      </div>`));
    });

  card.appendChild(rows);
  return card;
}

/* Where to go to understand any of it. A summary that ends in nothing invites
   a back button; one that points onward is the start of something. */
function snapshotOnward(){
  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">Where to look next</p>
    <p class="card-note" style="margin-bottom:14px;max-width:70ch">This page is
    a summary and it leaves things out. Each of these answers one question
    properly, with the workings shown.</p>`));

  const list = el('<div class="onward-grid"></div>');
  [["standing", "Where you stand", "The full account of how it got here."],
   ["measures", "The measures", "Eight figures, each with what it rests on."],
   ["mix", "The mix", "What you are exposed to, counting through your funds."],
   ["holdings", "Every holding", "All of them, seen three ways."],
   ["risk", "What could go wrong", "Bad days, shocks, and what you are not covered for."],
   ["cost", "What it costs you", "Fees, peers, and what raising your contributions would do."]]
    .forEach(([key, name, why]) => {
      const door = el(`<button type="button" class="onward-door">
        <b>${esc(name)}</b><span>${esc(why)}</span></button>`);
      door.addEventListener('click', () => {
        history.replaceState(null, '', '#' + key);
        draw();
        window.scrollTo({top: 0, behavior: 'instant'});
      });
      list.appendChild(door);
    });
  card.appendChild(list);

  const advice = el(`<a class="snap-advice" href="/advice.html">
    And what to do about all of it \u2192</a>`);
  card.appendChild(advice);
  return card;
}


/* The review, in the product.
 *
 * The same assembly that goes out by email. Somebody who does not open email,
 * or who wants to look before the next one is due, should not have to wait --
 * and a review that exists only in an inbox is one nobody can find again.
 */
function reviewCard(review){
  if (!review || review.nothing_to_send) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.your_review")}</p>
    <h2 class="display">${esc(review.subject)}</h2>
    <p class="card-note" style="margin-top:9px;max-width:70ch">${
      esc(review.opening)}</p>`));

  (review.sections || []).forEach(section => {
    const part = el('<div class="review-part"></div>');
    part.appendChild(el(`<p class="review-title">${esc(section.title)}</p>`));
    (section.items || []).forEach(item => {
      part.appendChild(frag(`
        <p class="review-head">${esc(item.headline)}</p>
        ${item.detail ? `<p class="review-detail">${esc(item.detail)}</p>` : ''}`));
    });
    card.appendChild(part);
  });

  card.appendChild(el(`<p class="card-note" style="margin-top:14px">${
    esc(review.what_this_is_not)}</p>`));

  return card;
}


/* Where the money is, as a shape.
 *
 * The allocation was a horizontal band and a list of percentages. Both work,
 * and neither shows proportion the way a circle does -- somebody can see that
 * one slice is half the ring without reading a number, which is the whole
 * point of drawing it.
 *
 * SVG rather than a charting library: this is four arcs and a hole, and a
 * dependency for that is a dependency to maintain.
 *
 * The colours come from the asset-class tokens, so a slice here is the same
 * colour as that class in the holdings list and the band. Colour that means
 * something in one place and nothing in another is worse than no colour.
 */
function allocationDonut(allocation, total){
  const parts = (allocation || []).filter(a => num(a.value) > 0);
  if (parts.length < 2) return null;

  const size = 168, stroke = 26, r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;

  let offset = 0;
  const arcs = parts.map(part => {
    const share = num(part.value) / total;
    const length = circumference * share;
    const arc = `<circle cx="${size / 2}" cy="${size / 2}" r="${r}"
      fill="none" stroke="${colour(part.asset_class)}"
      stroke-width="${stroke}"
      stroke-dasharray="${length.toFixed(2)} ${(circumference - length).toFixed(2)}"
      stroke-dashoffset="${(-offset).toFixed(2)}"
      transform="rotate(-90 ${size / 2} ${size / 2})">
      <title>${esc(label(part.asset_class))}: ${(share * 100).toFixed(1)}%</title>
    </circle>`;
    offset += length;
    return arc;
  }).join('');

  const biggest = parts.reduce((a, b) => num(a.value) > num(b.value) ? a : b);
  const biggestShare = num(biggest.value) / total * 100;

  const card = el('<section class="card w6"></section>');
  card.appendChild(frag(`
    <p class="eyebrow">${T("dash.where_money_is")}</p>
    <div class="donut-wrap">
      <svg class="donut" viewBox="0 0 ${size} ${size}" role="img"
           aria-label="Allocation by asset class">
        ${arcs}
      </svg>
      <div class="donut-middle">
        <b>${biggestShare.toFixed(0)}%</b>
        <span>${esc(label(biggest.asset_class))}</span>
      </div>
    </div>
    <div class="donut-key"></div>`));

  const key = card.querySelector('.donut-key');
  parts.forEach(part => {
    const share = num(part.value) / total * 100;
    key.appendChild(frag(`<div class="donut-row">
      <span class="donut-dot"
        style="background:${colour(part.asset_class)}"></span>
      <span class="donut-name">${esc(label(part.asset_class))}</span>
      <span class="donut-pct">${share.toFixed(1)}%</span>
      <span class="donut-val">\u20B9${money(part.value)}</span>
    </div>`));
  });

  return card;
}


/* What it has been worth, and where the shape comes from.
 *
 * A line drawn straight from the month-end values would lie. On a real account
 * it runs twenty-one lakh in July and a crore in August -- not growth, but the
 * month a provident fund and a gold holding were typed in. Another has six
 * distinct values across twenty-six months, the rest carried forward.
 *
 * A reader sees a step and reads it as a gain, which is the fifty-four lakh of
 * false outperformance again, drawn instead of written.
 *
 * So the steps where holdings arrived are marked, and the caption says which
 * parts are the portfolio moving and which are the record filling in. Where
 * there are too few real valuations to draw anything, it says so instead.
 */
function historyCard(history){
  if (!history) return null;

  const card = el('<section class="card w12"></section>');
  card.appendChild(frag(`<p class="eyebrow">${T("dash.what_it_was_worth")}</p>`));

  if (!history.drawable){
    card.appendChild(frag(`
      <h2 class="display">Not enough to draw</h2>
      <p class="card-note" style="margin-top:9px;max-width:70ch">${
        esc(history.why)}</p>
      ${history.what_would_help
        ? `<p class="card-note" style="margin-top:8px;max-width:70ch">${
            esc(history.what_would_help)}</p>` : ''}
      <a class="gap-fix" href="/upload.html">Import an older statement \u2192</a>`));
    return card;
  }

  // The stable stretch, not everything -- see the service.
  const points = history.draw || history.points || [];
  const values = points.map(p => num(p.value));
  const top = Math.max(...values), floor = Math.min(...values);
  const span = top - floor || 1;

  const w = 720, h = 190, padL = 8, padR = 8, padT = 12, padB = 22;
  const x = i => padL + (w - padL - padR) * (i / Math.max(1, points.length - 1));
  const y = v => padT + (h - padT - padB) * (1 - (v - floor) / span);

  /* The line breaks where holdings arrived.
   *
   * Joining across a composition change draws a rise that did not happen --
   * on a real account, twenty-one lakh to a crore in one month, which is a
   * provident fund being typed in rather than a 380% gain. Two segments with
   * a gap between them say what the eye needs to know before it reads
   * anything: these are not the same portfolio. */
  const segments = [];
  let current = [];
  points.forEach((p, i) => {
    if (p.holdings_arrived && current.length){
      segments.push(current);
      current = [];
    }
    current.push([x(i), y(num(p.value))]);
  });
  if (current.length) segments.push(current);

  const line = segments
    .filter(seg => seg.length > 1)
    .map(seg => seg.map(([px, py], i) =>
      `${i ? 'L' : 'M'}${px.toFixed(1)},${py.toFixed(1)}`).join(' '))
    .join(' ');

  const area = segments.filter(seg => seg.length > 1).map(seg => {
    const path = seg.map(([px, py], i) =>
      `${i ? 'L' : 'M'}${px.toFixed(1)},${py.toFixed(1)}`).join(' ');
    return path + ` L${seg[seg.length - 1][0].toFixed(1)},${h - padB}`
                + ` L${seg[0][0].toFixed(1)},${h - padB} Z`;
  }).join(' ');

  // Every month a holding appeared. Marked, because the step there is our
  // records catching up rather than the money moving.
  const marks = points.map((p, i) => p.holdings_arrived
    ? `<line x1="${x(i).toFixed(1)}" y1="${padT}" x2="${x(i).toFixed(1)}"
             y2="${h - padB}" class="hist-mark"/>
       <circle cx="${x(i).toFixed(1)}" cy="${y(num(p.value)).toFixed(1)}"
               r="3.5" class="hist-dot"/>`
    : '').join('');

  const first = points[0], last = points[points.length - 1];

  card.appendChild(frag(`
    <svg class="hist" viewBox="0 0 ${w} ${h}" role="img"
         aria-label="Month-end value over ${points.length} months">
      <path d="${area}" class="hist-area"/>
      <path d="${line}" class="hist-line"/>
      ${marks}
    </svg>
    <div class="hist-ends">
      <span>${esc(first.as_of.slice(0, 7))} \u00b7 \u20B9${money(first.value)}</span>
      <span>${esc(last.as_of.slice(0, 7))} \u00b7 \u20B9${money(last.value)}</span>
    </div>`));

  if (history.on_the_steps){
    card.appendChild(frag(`<p class="hist-warn">
      <span class="hist-key"></span>${esc(history.on_the_steps)}</p>`));
  }

  const story = el('<details class="tile-story" style="margin-top:11px"></details>');
  story.appendChild(frag('<summary>what this is</summary>'));
  story.appendChild(el(`<p>${esc(history.what_it_is)}</p>`));
  if (history.stable_from){
    story.appendChild(el(`<p>Nothing new has arrived since
      ${esc(history.stable_from.slice(0, 7))}, so movement after that is the
      portfolio rather than the record.</p>`));
  }
  card.appendChild(story);

  return card;
}

/* ------------------------------------------------------ holdings and depth */

const CHAPTERS = [
  ['story', 'What it has done'],
  ['consistency', 'How reliably'],
  ['bad_times', 'How bad it got'],
  ['sip_reality', 'What a monthly investment would have felt like'],
  ['category_compare', 'Against funds doing the same job'],
  ['suits', 'Who it suits'],
];


/* Three lenses, three calls, and the calls will disagree.
 *
 * That disagreement is the product rather than a flaw in it. HAL reads as a
 * buy on value and a reduce on growth: a value investor should own it and a
 * growth investor should not, and both are reasoning correctly from what they
 * are looking for. A tool that showed one verdict would be wrong for whichever
 * investor it was not built for -- and worse, they would disbelieve everything
 * else on the page.
 *
 * So all three, always, with the reasoning under each. What somebody's style
 * changes is which one is marked as theirs, never which are shown. */

const VERDICT_TONE = {
  'buy': 'buy', 'lean buy': 'lean-buy', 'hold': 'hold',
  'lean reduce': 'lean-reduce', 'reduce': 'reduce', 'sell': 'reduce',
};

function lensBlock(l, style){
  if (!l || !l.calls || !l.calls.length) return null;

  const wrap = el('<div class="chapter"></div>');
  wrap.appendChild(frag('<h5>Three ways of looking at it</h5>'));

  const b = l.behaviour;
  if (b){
    const bits = [
      `trades at \u20B9${money(b.price)}`,
      b.from_year_high_pct != null
        ? `${pct(Math.abs(num(b.from_year_high_pct)), 0)} below its year's high` : null,
      b.trend ? `price ${esc(b.trend.reading)}` : null,
      b.against_market_12m_pct != null
        ? `${num(b.against_market_12m_pct) >= 0 ? 'ahead of' : 'behind'} the market by
           ${pct(Math.abs(num(b.against_market_12m_pct)), 0)} over a year` : null,
    ].filter(Boolean);
    wrap.appendChild(el(`<p class="card-note" style="margin-bottom:12px">
      ${bits.join(' · ')}</p>`));
  }

  l.calls.forEach(call => {
    const mine = style && call.lens === style;
    const box = el(`<div class="call${mine ? ' call-mine' : ''}"></div>`);
    box.appendChild(frag(`
      <div class="call-head">
        <span class="call-title">${esc(call.title)}${
          mine ? '<span class="call-yours">how you invest</span>' : ''}</span>
        <span class="verdict ${VERDICT_TONE[call.verdict] || 'hold'}">${
          esc(call.verdict)}</span>
      </div>
      <p class="call-rule">${esc(call.rule)}</p>
      <p class="call-why">${esc(call.because)}</p>`));

    /* The measures behind the call, so the verdict can be argued with. */
    if ((call.measures || []).length){
      const detail = el('<details class="call-detail"><summary>the figures</summary></details>');
      call.measures.forEach(m => {
        const mark = m.verdict === 'better' ? 'up' : m.verdict === 'worse' ? 'down' : '';
        const gap = m.gap_pct == null ? '' :
          `${num(m.gap_pct) > 0 ? '+' : ''}${num(m.gap_pct).toFixed(0)}%`;
        detail.appendChild(frag(`
          <div class="mover" style="padding:5px 0">
            <span class="mover-name" title="${esc(m.explain)}">${esc(m.label)}</span>
            <span style="text-align:right;white-space:nowrap">
              <b style="font-variant-numeric:tabular-nums">${esc(m.value)}${esc(m.unit)}</b>
              ${m.sector == null ? '' :
                `<span style="color:var(--ink-4);font-size:12px;margin-left:9px">
                   sector ${esc(m.sector)}${esc(m.unit)}</span>`}
              ${gap ? `<span class="mover-pct ${mark}" style="font-size:11.5px;
                margin-left:8px">${esc(gap)}</span>` : ''}
            </span>
          </div>`));
      });
      box.appendChild(detail);
    }
    wrap.appendChild(box);
  });

  if (l.position){
    wrap.appendChild(el(`<p class="note" style="margin-top:12px;font-size:13.5px">
      ${esc(l.position.reading)}</p>`));
  }

  wrap.appendChild(el(`<p class="disclaim">Against ${l.sector_peers} companies in
    ${esc((l.sector || 'its sector').toLowerCase())}. ${esc(l.note)}</p>`));
  return wrap;
}



/* What holders sat through.
 *
 * A behaviour score says how hard a fund is to hold. This says what the
 * holding involved: the actual falls, how deep, how long down, how long back.
 *
 * Drawn as bars against the deepest one, because "-78.6%" and "-44.2%" are
 * numbers a reader compares with effort and lengths they compare at a glance.
 * The recovery time sits beside the depth, since a fall somebody waited five
 * years to see undone is a different experience from the same fall recovered
 * in eight months, and only one of those figures is usually shown.
 */
function stretchesBlock(stayed){
  if (!stayed || !(stayed.episodes || []).length) return null;

  const episodes = stayed.episodes.slice(0, 5);
  const deepest = Math.max(...episodes.map(e => Math.abs(num(e.depth_pct))));

  const wrap = el('<div class="chapter"></div>');
  wrap.appendChild(frag('<h5>What holders sat through</h5>'));
  wrap.appendChild(el(`<p class="card-note" style="margin-bottom:12px">
    ${esc(stayed.conversation || '')}</p>`));

  episodes.forEach(ep => {
    const depth = Math.abs(num(ep.depth_pct));
    const width = deepest > 0 ? (depth / deepest * 100) : 0;
    const down = num(ep.fall_months);
    const back = ep.recovery_months == null ? null : num(ep.recovery_months);

    wrap.appendChild(frag(`
      <div class="stretch">
        <div class="stretch-top">
          <span class="stretch-when">${esc(String(ep.peak || '').slice(0, 7))}</span>
          <span class="stretch-depth">\u2212${depth.toFixed(1)}%</span>
        </div>
        <div class="stretch-bar"><span style="width:${width.toFixed(1)}%"></span></div>
        <p class="stretch-note">
          ${down} month${down === 1 ? '' : 's'} falling${back == null
            ? ', and it has not come back yet'
            : `, ${back} month${back === 1 ? '' : 's'} to come back`}.
        </p>
      </div>`));
  });

  return wrap;
}


/* What sitting through it was worth.
 *
 * The falls above are what somebody had to hold through. This is what the
 * holding produced -- and the pairing is the whole argument. Either figure
 * alone misleads: the return without the drawdowns reads as easy money, the
 * drawdowns without the return read as a reason to avoid the fund.
 *
 * It walks the published NAV path rather than compounding an assumed rate, so
 * the dips are in the number. A projection at a smooth twelve per cent and the
 * same fund's real path arrive at different places, and the difference is
 * precisely what somebody had to live through to get there.
 */
function whatItMadeBlock(whatif){
  if (!whatif || !whatif.final_value) return null;

  const put = num(whatif.invested);
  const got = num(whatif.final_value);
  if (!put || !got) return null;

  const wrap = el('<div class="chapter"></div>');
  wrap.appendChild(frag('<h5>And what that was worth</h5>'));

  wrap.appendChild(frag(`
    <div class="worth-pair">
      <span><b>\u20B9${money(put)}</b>put in</span>
      <span class="worth-arrow">\u2192</span>
      <span><b class="worth-out">\u20B9${money(got)}</b>today</span>
      ${whatif.rate_pct != null
        ? `<span><b>${esc(whatif.rate_pct)}%</b>a year</span>` : ''}
    </div>`));

  wrap.appendChild(el(`<p class="card-note" style="margin-top:9px">
    ${esc(whatif.conversation || '')}</p>`));
  return wrap;
}


/* What kind of fund this actually is.
 *
 * A category is a label the fund house chose. These are percentile ranks
 * against the whole listed market, computed from what the fund discloses it
 * owns -- so a flexi cap that behaves like a mid cap fund shows as one, and
 * the label stops being the last word.
 */
function dnaBlock(dna){
  if (!dna || !dna.factors) return null;

  const factors = dna.factors;
  const order = ['value', 'growth', 'quality', 'safety', 'size'];
  const labels = {value:'Value', growth:'Growth', quality:'Quality',
                  safety:'Balance sheet', size:'Company size'};

  const wrap = el('<div class="chapter"></div>');
  wrap.appendChild(frag('<h5>What kind of fund this is</h5>'));

  order.forEach(key => {
    const score = factors[key];
    if (score == null) return;
    const value = num(score);
    wrap.appendChild(frag(`
      <div class="factor">
        <span class="factor-name">${esc(labels[key] || key)}</span>
        <span class="factor-track">
          <span class="factor-mid"></span>
          <span class="factor-fill" style="width:${Math.min(100, value).toFixed(0)}%"></span>
        </span>
        <span class="factor-score">${value.toFixed(0)}</span>
      </div>`));
  });

  wrap.appendChild(el(`<p class="card-note" style="margin-top:10px">
    ${esc(dna.conversation || '')}</p>`));
  wrap.appendChild(el(`<p class="disclaim">Percentiles against the whole listed
    market, weighted by what the fund owns. Fifty is the market's middle.</p>`));
  return wrap;
}

/* What the movement bought.
 *
 * Volatility says how much something moves; these say whether the moving was
 * worth it. Sortino is given first and Sharpe second, deliberately: Sharpe
 * penalises a sharp rise exactly as hard as a sharp fall, which is not how
 * anybody experiences holding a fund, and putting the more honest number first
 * is the difference between reporting and explaining.
 */
function ratiosBlock(r){
  if (!r) return null;

  const wrap = el('<div class="chapter"></div>');
  wrap.appendChild(frag('<h5>Whether the movement was worth it</h5>'));

  if (!r.computable){
    wrap.appendChild(el(`<p class="card-note">${esc(r.why || '')}</p>`));
    return wrap;
  }

  const figures = [
    ['Return', `${r.annual_return_pct}%`, 'a year'],
    ['Moves', `${r.volatility_pct}%`, 'a year'],
    ['Sortino', r.sortino, 'counting only falls'],
    ['Sharpe', r.sharpe, 'counting all movement'],
  ];
  const index = r.versus_index;
  if (index){
    figures.push(['Beta', index.beta, 'per rupee of market']);
    figures.push(['Alpha', `${index.alpha_pct > 0 ? '+' : ''}${index.alpha_pct}%`,
                  'above market risk']);
  }

  const grid = el('<div class="figures"></div>');
  figures.forEach(([name, value, note]) => {
    if (value == null) return;
    grid.appendChild(frag(`
      <div class="figure">
        <span class="figure-value">${esc(value)}</span>
        <span class="figure-name">${esc(name)}</span>
        <span class="figure-note">${esc(note)}</span>
      </div>`));
  });
  wrap.appendChild(grid);

  /* Capture is the pair that says the most and gets shown the least: a fund
     taking 86% of the rises and 77% of the falls is doing the job, and no
     single return figure conveys it. */
  if (index && index.up_capture_pct != null && index.down_capture_pct != null){
    const up = num(index.up_capture_pct), down = num(index.down_capture_pct);
    wrap.appendChild(frag(`
      <div class="capture">
        <div class="capture-row">
          <span>Of the market's good days</span>
          <span class="capture-bar up"><span style="width:${Math.min(100,up)}%"></span></span>
          <b>${up.toFixed(0)}%</b>
        </div>
        <div class="capture-row">
          <span>Of the bad ones</span>
          <span class="capture-bar down"><span style="width:${Math.min(100,down)}%"></span></span>
          <b>${down.toFixed(0)}%</b>
        </div>
      </div>`));
  }

  wrap.appendChild(el(`<p class="card-note" style="margin-top:11px">
    ${esc(r.reading || '')}</p>`));
  wrap.appendChild(el(`<p class="disclaim">From ${r.days} daily prices since
    ${esc(r.from || '')}, against NIFTYBEES, assuming a risk-free rate of
    ${r.risk_free_pct}% a year.</p>`));
  return wrap;
}

function fundDetail(d){
  const wrap = document.createElement('div');

  const receipts = [];
  const dd = d.drawdown;
  if (dd){
    receipts.push(`<span class="receipt">Worst fall we can see
      <b class="bad">${pct(dd.worst_fall_pct)}</b></span>`);
    if (dd.months_to_recover != null){
      receipts.push(`<span class="receipt">Took to recover
        <b>${dd.months_to_recover} months</b></span>`);
    } else if (dd.still_below_peak){
      receipts.push('<span class="receipt">Since then <b class="bad">not recovered</b></span>');
    }
  }
  const rec = d.record;
  if (rec){
    if (rec.rolling_3y_median != null){
      receipts.push(`<span class="receipt">Median over 3 years
        <b>${pct(rec.rolling_3y_median)}</b></span>`);
    }
    if (rec.category_rank && rec.category_size){
      receipts.push(`<span class="receipt">In its category
        <b>${rec.category_rank} of ${rec.category_size}</b></span>`);
    }
  }
  if (d.cost_basis){
    receipts.push(`<span class="receipt">You paid
      <b>\u20B9${money(d.cost_basis.per_unit)} each</b></span>`);
  }
  if (receipts.length) wrap.appendChild(el(`<div class="receipts">${receipts.join('')}</div>`));

  /* A share: what it costs, earns, owes, and how it has grown. */
  const co = d.company;
  if (co){
    const bits = [co.sector, co.industry, co.size && co.size + ' cap']
      .filter(Boolean).map(b => `<span>${esc(b)}</span>`).join('');
    if (bits) wrap.appendChild(el(`<div class="holding-meta">${bits}</div>`));
  }
  (d.measures || []).forEach(group => {
    const rows = group.measures.map(m => {
      const value = num(m.value);
      const shown = value.toFixed(m.unit === '%' ? 1 : 2) + m.unit;
      const median = m.sector_median == null ? '' :
        `sector ${num(m.sector_median).toFixed(m.unit === '%' ? 1 : 2)}${m.unit}`;
      return `<div class="mover"><span class="mover-name">${esc(m.label)}</span>
        <span><b>${esc(shown)}</b>
        <span style="color:var(--ink-4);font-size:12.5px;margin-left:9px">${esc(median)}</span>
        </span></div>`;
    }).join('');
    wrap.appendChild(el(`<div class="chapter"><h5>${esc(group.title)}</h5>${rows}</div>`));
  });

  // The order is an argument rather than an accumulation:
  //
  //   what this is        -- the lenses for a share, the DNA for a fund
  //   what it has done    -- the ratios, which say whether the movement paid
  //   what holding it involved -- the falls somebody sat through, and what
  //                           sitting through them was worth
  //   then the detail     -- the chapters below
  //
  // Somebody who stops reading after the second block has still learned the
  // two things that matter most, which is what an order is for.
  [
    lensBlock(d.lenses, state.style),
    dnaBlock(d.dna),
    ratiosBlock(d.ratios),
    stretchesBlock(d.stretches),
    whatItMadeBlock(d.if_you_had),
  ].filter(Boolean).forEach(block => wrap.appendChild(block));

  /* A fund: base rates, then the written chapters. */
  const odds = d.odds;
  if (odds && odds.conversation){
    wrap.appendChild(el(`<div class="chapter">
      <h5>How often it has worked out</h5><p>${esc(odds.conversation)}</p></div>`));
  }
  const horizon = d.horizon;
  if (horizon && horizon.conversation){
    wrap.appendChild(el(`<div class="chapter">
      <h5>How long you needed to hold it</h5><p>${esc(horizon.conversation)}</p></div>`));
  }
  CHAPTERS.forEach(([key, heading]) => {
    const value = (d.narrative || {})[key];
    if (!value) return;
    const inner = Array.isArray(value)
      ? `<ul>${value.map(v => `<li>${esc(v)}</li>`).join('')}</ul>`
      : `<p>${esc(value)}</p>`;
    wrap.appendChild(el(`<div class="chapter"><h5>${esc(heading)}</h5>${inner}</div>`));
  });

  const moves = d.activity;
  if (moves && moves.computable){
    const from = new Date(moves.from).toLocaleDateString('en-IN', {month:'short', year:'numeric'});
    const to = new Date(moves.to).toLocaleDateString('en-IN', {month:'short', year:'numeric'});
    const box = el(`<div class="chapter"><h5>What the manager did</h5>
      <p>Between ${esc(from)} and ${esc(to)} the book went from ${moves.positions_then}
      holdings to ${moves.positions_now}, ${moves.held_throughout} held the whole way.
      Turnover ${pct(moves.turnover_pct, 0)}.</p></div>`);
    [['bought','Bought into'], ['sold','Sold out of'],
     ['added','Added to'], ['trimmed','Trimmed']].forEach(([key, heading]) => {
      const rows = (moves[key] || []).slice(0, 4);
      if (!rows.length) return;
      const list = rows.map(r => {
        const w = r.change != null ? `${num(r.change) > 0 ? '+' : ''}${num(r.change).toFixed(2)}%`
                : (key === 'sold' ? `was ${Math.abs(num(r.weight)).toFixed(2)}%`
                                  : `${Math.abs(num(r.weight)).toFixed(2)}%`);
        return `<div class="mover"><span class="mover-name">${esc(r.name || r.symbol)}</span>
          <span class="mover-pct ${key === 'sold' || key === 'trimmed' ? 'down' : 'up'}"
                style="font-size:13px">${esc(w)}</span></div>`;
      }).join('');
      box.appendChild(el(`<div style="margin-top:11px">
        <h5 style="color:var(--ink-4)">${esc(heading)}</h5>${list}</div>`));
    });
    wrap.appendChild(box);
  }

  (d.unavailable || []).forEach(note =>
    wrap.appendChild(el(`<p class="missing">${esc(note)}</p>`)));

  if ((d.narrative || {}).disclaimer){
    wrap.appendChild(el(`<p class="disclaim">${esc(d.narrative.disclaimer)}</p>`));
  }
  if (!wrap.childElementCount){
    wrap.appendChild(el('<p class="missing">We have nothing further on this holding yet.</p>'));
  }
  return wrap;
}

function holdingsCard(rows, investorId, filter){
  const shown = filter ? rows.filter(h => h.asset_class === filter) : rows;
  if (!shown.length) return null;

  const card = el(`<section class="card w12"></section>`);
  const total = shown.reduce((s, h) => s + num(h.current_value), 0);
  card.appendChild(frag(`
    <p class="eyebrow">${shown.length} holding${shown.length === 1 ? '' : 's'}
      \u00b7 \u20B9${money(total)}</p>
    <h2 class="display">What you hold</h2>`));

  shown.forEach(h => {
    const gain = num(h.gain);
    const gpct = h.gain_pct == null ? null : num(h.gain_pct);
    const cls = gain > 0 ? 'up' : gain < 0 ? 'down' : '';
    const where = [h.institution, h.account_number].filter(Boolean).join(' \u00b7 ');
    const share = total > 0 ? num(h.current_value) / total * 100 : 0;

    const row = el(`
      <div class="holding" data-open="false" tabindex="0" role="button"
           aria-expanded="false" data-instrument="${esc(h.instrument_id)}">
        <div>
          <div class="holding-name">${esc(h.instrument_name)}</div>
          <div class="holding-meta">
            <span class="tag" style="color:${colour(h.asset_class)}">${esc(label(h.asset_class))}</span>
            ${where ? `<span>${esc(where)}</span>` : ''}
            ${h.quantity ? `<span>${inr.format(num(h.quantity))} units</span>` : ''}
          </div>
        </div>
        <!-- What share of everything this is.
             The row was two islands -- a name at the far left and a figure at
             the far right with seven hundred pixels of nothing between. This
             fills the middle with the one thing somebody scanning a holdings
             list actually wants: how much of their money is in this. -->
        <div class="holding-share">
          <div class="holding-bar">
            <span style="width:${Math.min(100, share).toFixed(1)}%"></span>
          </div>
          <span class="holding-share-n">${share.toFixed(1)}%</span>
        </div>
        <div class="holding-figs">
          <div class="holding-val">\u20B9${money(h.current_value)}</div>
          ${gain === 0 ? '' : `<div class="holding-gain ${cls}">${
            gain > 0 ? '+' : '\u2212'}\u20B9${money(Math.abs(gain))}${
            gpct == null ? '' : ` \u00b7 ${gpct >= 0 ? '+' : '\u2212'}${pct(Math.abs(gpct))}`}</div>`}
        </div>
        <div class="holding-open"></div>
      </div>`);

    let loaded = false;
    const open = async () => {
      const now = row.getAttribute('data-open') !== 'true';
      row.setAttribute('data-open', String(now));
      row.setAttribute('aria-expanded', String(now));
      if (!now || loaded) return;
      loaded = true;
      const panel = row.querySelector('.holding-open');
      panel.innerHTML = '<div class="skeleton" style="height:11px;width:70%"></div>';
      try{
        panel.innerHTML = '';
        panel.appendChild(fundDetail(await get(`/fund/${investorId}/${h.instrument_id}`)));
      }catch(err){
        panel.innerHTML = `<p class="missing">${esc(err.message)}</p>`;
      }
    };
    row.addEventListener('click', open);
    row.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); open(); }
    });
    card.appendChild(row);
  });
  return card;
}

/* ------------------------------------------------------------------ band */

/* The allocation, drawn at real proportions, and also how you move between
   views. Pressing a segment filters the page to that asset class -- the thing
   you press is the thing you are choosing, at its actual size. */
function bandOf(allocation, active, onPick){
  const live = (allocation || []).filter(a => num(a.value) > 0);
  if (!live.length) return null;
  const total = live.reduce((s, a) => s + num(a.value), 0) || 1;

  const shell = el('<div class="band-shell"></div>');
  const bar = el('<div class="band" role="tablist" aria-label="By asset class"></div>');
  const legend = el('<div class="band-legend"></div>');

  live.forEach(a => {
    const share = num(a.value) / total * 100;
    const on = active === a.asset_class;
    // A segment at true proportion is honest but can be four pixels wide, and
    // this is a control -- something you press. Small holdings get a floor
    // wide enough to touch and to label; the larger ones give up the space,
    // which distorts the picture slightly in exchange for it being usable.
    const seg = el(`
      <button class="seg${share < 14 ? ' narrow' : ''}" role="tab"
              aria-pressed="${on}"
              style="flex:1 1 ${share.toFixed(2)}%;min-width:${share < 14 ? '78px' : '0'};
              background:${colour(a.asset_class)}"
              title="${esc(label(a.asset_class))} \u2014 ${pct(share)}">
        <span class="seg-label"><b>${esc(label(a.asset_class))}</b>${pct(share, 0)}</span>
      </button>`);
    seg.addEventListener('click', () => onPick(on ? null : a.asset_class));
    bar.appendChild(seg);

    const chip = el(`<button aria-pressed="${on}">
      <s style="background:${colour(a.asset_class)}"></s>${esc(label(a.asset_class))}
      \u20B9${short(a.value)}</button>`);
    chip.addEventListener('click', () => onPick(on ? null : a.asset_class));
    legend.appendChild(chip);
  });

  const all = el(`<button aria-pressed="${!active}">Everything</button>`);
  all.addEventListener('click', () => onPick(null));
  legend.insertBefore(all, legend.firstChild);

  shell.append(bar);
  if (live.length > 1){
    shell.appendChild(el(
      '<p class="band-hint">Tap a band to see just that part of your wealth.</p>'));
  }
  shell.appendChild(legend);
  return shell;
}

/* ------------------------------------------------------------------ flow */

let state = {investorId: null, data: null, filter: null, style: null,
             guide: null, advice: null, method: null, decision: null,
             away: null, summaries: null};

function draw(){
  const main = $('main');
  const d = state.data;
  main.innerHTML = '';

  const view = d.views[state.filter || 'everything'] || d.views.everything;
  const grid = el('<div class="grid"></div>');

  /* Which view. Read before anything is appended, because everything below
     depends on it -- the first pass rendered the decision, the guide, the
     filter and the tiles above the navigation, so the tabs sat halfway down
     a 1440px page with three full-width cards above them. Navigation that
     appears after the content is not navigation. */
  const wanted = (location.hash || '').replace('#', '');

  const sections = [
    {
      // Everything that matters, on one page, for somebody with four minutes.
      key: "snapshot",
      title: T("sec.snapshot"),
      hide: !!state.filter,
      lead: snapshotNumbers(d, view),
      cards: [
        snapshotStory(state.guide),
        snapshotVerdict(d, d.benchmark),
        snapshotMovers(view),
        snapshotOnward(),
      ],
    },
    {
      key: "standing",
      title: T("sec.standing"),
      // The number leads, then the account of it, then the detail. The first
      // pass had the prose first and the figure third, which asked somebody
      // to read a paragraph before seeing what they came for.
      hero: headlineCard(view, state.filter || 'everything'),
      lead: state.filter ? null : guideBlock(state.guide),
      cards: [
        // One question: where do I stand. The tiles and Ariv were two more
        // questions on the same screen and two thousand pixels of scrolling.
        state.filter ? null : historyCard(d.value_history),
        state.filter ? null : findingsCard(d.findings),
        moversCard(view.movers),
      ],
    },
    {
      // The figures on their own, for somebody who came for figures.
      key: "measures",
      title: T("sec.measures"),
      tiles: !state.filter,
      cards: [],
    },
    {
      key: "ariv",
      title: T("sec.ariv"),
      hide: !!state.filter,
      cards: [arivPanel(state.investorId)],
    },
    {
      key: "mix",
      title: T("sec.mix"),
      cards: [
        // The ring is tall; the industry list is tall. They pair.
        // Company size is one bar and belongs beside the valuation card,
        // which is four rows -- not beside the ring, which left a void.
        state.filter ? null : allocationDonut(d.allocation,
          num((view.headline || {}).current)),
        sectorCard(d.sectors),
        state.filter === 'mutual_fund' ? null : valueCard(d.value_shape),
        state.filter === 'mutual_fund' ? null : marketCapCard(d.market_cap),
        state.filter || d.drift ? null : setTargetCard(),
        state.filter ? null : styleCard(state.styleInfo, state.investorId),
      ],
    },
    {
      // Twenty-three rows is a destination rather than a card. Sitting it
      // under three others made the view a scroll, which is what splitting
      // into views was meant to cure.
      key: "holdings",
      title: T("sec.holdings"),
      cards: [
        holdingsCard(d.holdings, state.investorId, state.filter),
      ],
    },
    {
      key: "risk",
      title: T("sec.risk"),
      cards: [
        // Paired by height rather than by importance. The radar and the tail
        // table are both tall; protection and the projection are both short.
        // Putting a short card beside a tall one leaves a void the reader
        // reads as a mistake, because in a grid it is one.
        radarCard(d.risk_radar),
        tailCard(d.tail),
        canHoldCard(state.advice && state.advice.can_you_hold_it),
        shocksCard(d.shocks),
        protectionCard(d.protection),
        forwardCard(d.forward),
      ],
    },
    {
      key: "cost",
      title: T("sec.cost"),
      cards: [
        costDragCard(d.cost_drag),
        peersCard(d.peers),
        stepUpCard(d.step_up),
      ],
    },
    {
      key: "account",
      title: T("sec.account"),
      cards: [
        routeCard(state.guide && state.guide.route),
        unseenBlock(state.guide && state.guide.unseen),
        shareBlock(state.investorId),
        methodCard(state.method),
      ],
    },
  ];

  /* One view at a time, not twenty-three cards at once.
   *
   * The first pass at this put the same cards into six labelled sections on
   * one page, which labels a long scroll rather than curing it. Somebody
   * opening a portfolio wants to know where they stand and what to do; the
   * risk modelling and the cost analysis are things they choose to look at,
   * not things they scroll past on the way somewhere.
   *
   * So the sections became destinations. The first one is short enough to
   * read, and the rest are one tap away and stay out of the way until asked
   * for.
   */
  const live = sections.filter(sec =>
    !sec.hide && ((sec.cards || []).filter(Boolean).length || sec.lead
                  || sec.hero || sec.tiles));

  if (!live.length){ main.appendChild(grid); return; }

  // The URL carries the view, so a link to the risk view is a link to the
  // risk view rather than to wherever the page happens to open.
  const current = live.find(sec => sec.key === wanted) || live[0];

  /* The side list drives the view. It lives in the markup rather than being
     built here, so it is visible before any data has loaded -- a nav that
     appears a second late is one somebody has already given up on. */
  document.querySelectorAll('.side-link[data-view]').forEach(link => {
    const key = link.getAttribute('data-view');
    link.classList.toggle('on', key === current.key);
    if (link.dataset.wired) return;
    link.dataset.wired = '1';
    link.addEventListener('click', () => {
      history.replaceState(null, '', '#' + key);
      draw();
      window.scrollTo({top: 0, behavior: 'instant'});
      document.getElementById('side').classList.remove('open');
      const scrim = document.querySelector('.side-scrim');
      if (scrim) scrim.classList.remove('on');
    });
  });

  /* What happened while they were away, and the asset-class filter. Both
     belong to the first view: one is about the gap since the last visit and
     the other narrows what the whole page is about. */
  if (current.key === live[0].key){
    const away = awayBlock(state.away);
    if (away) main.appendChild(away);
  }

  const band = bandOf(d.allocation, state.filter, pick => {
    state.filter = pick;
    draw();
    window.scrollTo({top: 0, behavior: 'instant'});
  });
  // Shown on the first view, and wherever a filter is active -- a filter with
  // no visible means of clearing it is a trap.
  if (band && (current.key === live[0].key || state.filter)){
    main.appendChild(band);
  }

  if (current.hero){
    // Full width, because it is the thing the page is about. Paired with
    // another card it stretched to match and left a void where the difference
    // in their content was.
    current.hero.classList.add('hero');
    main.appendChild(current.hero);
  }

  if (current.lead) main.appendChild(current.lead);

  const block = el(`<section class="view" data-view="${esc(current.key)}"></section>`);
  // No lede. The tab already says "What you hold"; a line underneath saying
  // "where the money actually sits" is the same information twice, and two
  // rows of chrome before any content is what makes a page feel like
  // packaging.

  const rows = el('<div class="view-grid"></div>');
  (current.cards || []).filter(Boolean).forEach(card => {
    if (card.classList.contains('w12')) card.classList.add('span-all');
    card.classList.remove('w6', 'w12');
    rows.appendChild(card);
  });
  block.appendChild(rows);
  main.appendChild(block);

  /* The small figures last. They are reference rather than argument, and
     putting them between the account and the findings interrupted the one
     with the other. */
  if (current.tiles){
    const panel = metricPanel(d, state.advice);
    if (panel) main.appendChild(panel);
  }

  /* Where to go next. A view that ends in nothing invites a back button; one
     that points onward is a journey. */
  const at = live.indexOf(current);
  const next = live[at + 1];
  if (next){
    const onward = el(`<button type="button" class="onward">
      <span>Next</span><b>${esc(next.title)}</b>
      </button>`);
    onward.addEventListener('click', () => {
      history.replaceState(null, '', '#' + next.key);
      draw();
      window.scrollTo({top: 0, behavior: 'instant'});
    });
    main.appendChild(onward);
  }

  // Figures already fetched get painted on every redraw. Switching investor or
  // tapping a band rebuilds the rows, and without this the analysis appears
  // once and vanishes at the first interaction.
  paintSummaries();
}

async function load(investorId){
  state.investorId = investorId;
  state.filter = null;
  $('main').innerHTML = '<div class="state"><div class="skeleton" style="height:60px"></div>'
    + '<div class="skeleton" style="height:150px;margin-top:14px"></div></div>';
  try{
    const [dashboard, holdings, style, guideData, method, decision, away,
           review] =
      await Promise.all([
      get('/dashboard/' + investorId),
      get(`/wealth/${investorId}/holdings`),
      // How somebody invests decides which verdict is marked as theirs, never
      // which are shown. Optional: an unanswered question means all three are
      // shown evenly, which is the right default rather than a gap.
      get(`/profile/${investorId}/style`).catch(() => null),
      // The guide connects what the cards each say separately. Optional: a
      // dashboard without it is still a dashboard.
      get(`/guide/${investorId}`).catch(() => null),
      // How the figures are arrived at. Cached hard on the server and the same
      // for everybody, so it costs nothing to fetch with the rest.
      get('/methodology').catch(() => null),
      get(`/decide/${investorId}`).catch(() => null),
      get(`/away/${investorId}`).catch(() => null),
      // The same review that goes out by email, so somebody who does not read
      // email is not shut out of it.
      get(`/review/${investorId}`).catch(() => null),
    ]);
    state.guide = guideData;
    state.method = method;
    state.decision = decision;
    paintAdviceCount();
    state.away = away;
    state.review = review;
    state.style = style && style.stated ? style.stated : null;
    state.styleInfo = style;
    state.data = {...dashboard, holdings: holdings.holdings || []};
    if (!state.data.holdings.length){
      $('main').innerHTML = '';
      $('main').appendChild(el(`<div class="state">
        <h3>Nothing here yet</h3>
        <p>Bring in a statement or a spreadsheet and everything will appear here together.</p>
        <a class="cta" href="/upload.html">Bring in holdings</a></div>`));
      return;
    }
    draw();

    // Peers, after the page. Six seconds of network calls has no business in
    // the load that decides whether somebody sees their portfolio.
    get(`/wealth/${investorId}/peers`)
      .then(data => {
        if (state.investorId !== investorId) return;
        state.data.peers = data;
        draw();
      })
      .catch(() => { /* the page is complete without it */ });

    // The per-holding figures, after the list is up. They decorate rather than
    // answer, so nothing should wait for them -- and the ratios are a query
    // each while the behaviour bands are network calls.
    get(`/wealth/${investorId}/summaries`)
      .then(data => {
        if (state.investorId !== investorId) return;
        state.summaries = (data && data.summaries) || {};
        paintSummaries();
      })
      .catch(() => { /* the list is complete without them */ });

    // The advice separately, and after the numbers are on screen. It runs the
    // rebalance engine, which their own documentation says takes four to
    // fifteen seconds -- and having that in the same Promise.all meant the
    // whole dashboard waited on it. Figures in half a second with the actions
    // filling in a moment later is right; a blank page for fifteen seconds is
    // not, however complete it eventually is.
    get(`/recommendations/${investorId}`)
      .then(advice => {
        if (state.investorId !== investorId) return;   // they switched investor
        state.advice = advice;
        draw();
      })
      .catch(() => { /* the dashboard is complete without it */ });
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(
      `<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`));
  }
}


/* The language picker, and the notice that goes with it.
 *
 * Two things a reader needs to know before they act on a translated page: that
 * nobody has checked this translation, and that the analysis underneath is
 * still English. Both are said in the language they chose, at the top, rather
 * than left for them to work out. */
/* The admin link, shown only where the server says so.
 *
 * Hidden markup is not access control -- the page behind it checks the role on
 * every request. This decides whether somebody sees a door, not whether they
 * can open it. */
/* Downloading what is on screen. Built in the browser from the data already
   loaded, so it needs no server work -- and it says on itself that it is a
   copy of a screen rather than a record of advice, because the record lives in
   the ledger and that is the thing to produce if anybody ever asks. */
function wireDownload(){
  const button = document.getElementById('download');
  if (!button) return;
  button.addEventListener('click', () => {
    if (typeof PDF === 'undefined' || !state.data){
      return;
    }
    const who = (state.data.investor && state.data.investor.display_name) || '';
    button.disabled = true;
    button.textContent = 'Preparing\u2026';
    try{
      // The guide goes with it: the narrative is what the product produces
      // and the tables are evidence for it.
      PDF.theNumbers(state.data, who, state.guide);
    }finally{
      button.disabled = false;
      button.textContent = 'Download';
    }
  });
}

/* The count beside "what to do now".
 *
 * A number is the difference between a menu item and a reason to click. Filled
 * in once the decision has loaded rather than guessed at, and hidden entirely
 * where there is nothing waiting -- a badge showing zero is worse than no
 * badge, because it draws the eye to nothing.
 */
function paintAdviceCount(){
  const badge = document.getElementById('navAdviceCount');
  if (!badge) return;
  const count = ((state.decision || {}).actions || []).length;
  if (!count){ badge.hidden = true; return; }
  badge.textContent = count;
  badge.hidden = false;
}

/* The list on a phone. A scrim so tapping away closes it, and Escape too --
   a panel that can only be closed by the button that opened it is a trap on a
   small screen. */
function wireSideNav(){
  const side = document.getElementById('side');
  const toggle = document.getElementById('sideToggle');
  if (!side || !toggle) return;

  let scrim = document.querySelector('.side-scrim');
  if (!scrim){
    scrim = el('<div class="side-scrim"></div>');
    document.body.appendChild(scrim);
  }
  const close = () => {
    side.classList.remove('open');
    scrim.classList.remove('on');
  };
  toggle.addEventListener('click', () => {
    const open = side.classList.toggle('open');
    scrim.classList.toggle('on', open);
  });
  scrim.addEventListener('click', close);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
}

async function showAdminLink(){
  try{
    // The role is nested: /auth/me returns {user, investor_count}, not the
    // user itself. Checking me.role was always false, so the link never
    // appeared and looked like a routing problem rather than a wrong path.
    const me = await get('/auth/me');
    if (me && me.user && me.user.role === 'admin'){
      const link = document.getElementById('adminlink');
      if (link) link.hidden = false;
    }
  }catch(err){ /* not signed in, or no such endpoint */ }
}

async function startLanguage(redraw){
  const bar = document.querySelector('.who');
  if (!bar || typeof buildLanguagePicker !== 'function') return;
  await buildLanguagePicker(bar, () => {
    const existing = document.querySelector('.lang-notice');
    if (existing) existing.remove();
    const notice = languageNotice();
    if (notice){
      const head = document.querySelector('.masthead');
      head.parentNode.insertBefore(notice, head.nextSibling);
    }
    if (redraw) redraw();
  });
}

async function start(){
  try{
    const {investors} = await get('/wealth/investors');
    if (!investors.length){
      $('main').innerHTML = '';
      $('main').appendChild(el(`<div class="state">
        <h3>Nothing here yet</h3>
        <p>Bring in a statement and it will all appear here.</p>
        <a class="cta" href="/upload.html">Bring in holdings</a></div>`));
      return;
    }
    const picker = $('picker');
    investors.forEach(i => picker.appendChild(el(
      `<option value="${esc(i.id)}">${esc(i.display_name)}${
        i.pan_last4 ? ' \u00b7 ' + esc(i.pan_last4) : ''}</option>`)));
    picker.addEventListener('change', e => load(e.target.value));
    picker.style.display = investors.length > 1 ? '' : 'none';

    const wanted = new URLSearchParams(location.search).get('investor');
    const chosen = wanted && investors.some(i => i.id === wanted) ? wanted : investors[0].id;
    picker.value = chosen;
    load(chosen);
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(
      `<div class="state"><h3>Could not load this</h3><p>${esc(err.message)}</p></div>`));
  }
}

$('out').addEventListener('click', async () => {
  try{ await fetch(API + '/auth/logout', {method: 'POST', credentials: 'include'}); }
  catch(e){ /* signing out locally regardless */ }
  location.href = '/signin.html';
});

wireSideNav();
start().then(() => { showAdminLink(); wireDownload(); startLanguage(() => {
  try{ draw(state && state.data ? state.data : undefined); }
  catch(err){ /* the page will pick strings up on next draw */ }
}); });
