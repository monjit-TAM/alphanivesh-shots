/* The desk.
 *
 * For somebody managing other people's money. The investor pages answer "how
 * am I doing"; this answers "which of these people needs me today", which is
 * a different question with a different shape — a list that sorts itself by
 * who needs attention rather than a narrative.
 *
 * What it deliberately does not show: what any client asked Ariv, and the
 * advice text itself. An adviser opens a client's own page for that, which
 * leaves a record of having done so. A book that displays everybody's advice
 * at a glance makes every glance indistinguishable from every other, and the
 * audit trail cannot tell working from browsing.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const state = {view: 'clients', me: null, book: null};

const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
function frag(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

/* Indian grouping, because ₹1,01,87,248 and ₹10,187,248 are the same number
   and only one of them is readable to somebody who lives here. */
function money(value){
  const n = Math.round(Number(value) || 0);
  const negative = n < 0;
  let digits = String(Math.abs(n));
  if (digits.length > 3){
    let head = digits.slice(0, -3);
    const tail = digits.slice(-3);
    const parts = [];
    while (head.length > 2){ parts.unshift(head.slice(-2)); head = head.slice(0, -2); }
    if (head) parts.unshift(head);
    digits = parts.join(',') + ',' + tail;
  }
  return (negative ? '-\u20B9' : '\u20B9') + digits;
}

async function get(path){
  const res = await fetch(API + path, {credentials: 'include'});
  if (res.status === 401){ location.href = '/signin.html'; throw new Error('out'); }
  if (res.status === 403){
    const body = await res.json().catch(() => ({}));
    const err = new Error(body.detail || 'not allowed');
    err.forbidden = true;
    throw err;
  }
  if (!res.ok) throw new Error(res.status + ' from ' + path);
  return res.json();
}

/* ------------------------------------------------------------------ views */

function clientsView(){
  const book = state.book;
  const main = $('main');

  if (!book || !book.count){
    main.appendChild(el(`<div class="desk-empty">
      <h2>No clients yet</h2>
      <p>When somebody is put with you, they appear here with what they hold,
      what is outstanding, and whether they have agreed to your seeing it.</p>
    </div>`));
    return;
  }

  const needing = book.clients.filter(c => c.needs_attention);
  const worth = book.clients.reduce((sum, c) => sum + Number(c.worth || 0), 0);

  main.appendChild(frag(`
    <div class="desk-figures">
      <div class="desk-fig"><b>${book.count}</b><span>clients</span></div>
      <div class="desk-fig"><b>${money(worth)}</b><span>between them</span></div>
      <div class="desk-fig ${needing.length ? 'warn' : ''}">
        <b>${needing.length}</b><span>need something</span></div>
      ${book.without_consent
        ? `<div class="desk-fig warn"><b>${book.without_consent}</b>
             <span>without recorded consent</span></div>` : ''}
    </div>`));

  main.appendChild(bookOf(book.clients));
}

function attentionView(){
  const book = state.book;
  const main = $('main');
  const needing = (book?.clients || []).filter(c => c.needs_attention);

  if (!needing.length){
    main.appendChild(el(`<div class="desk-empty">
      <h2>Nothing is waiting</h2>
      <p>Every client has holdings in, consent recorded, and has looked
      recently. This page fills up on its own when that stops being true.</p>
    </div>`));
    return;
  }

  main.appendChild(bookOf(needing));
}

/* One row per client. Sorted by what needs doing rather than by size, because
   the largest client is not always the one who needs an hour today. */
function bookOf(clients){
  const list = el('<div class="book"></div>');

  const ranked = [...clients].sort((a, b) => {
    const weight = c => (!c.consented ? 3 : !c.holdings ? 2 :
                         c.needs_attention ? 1 : 0);
    const gap = weight(b) - weight(a);
    return gap !== 0 ? gap : Number(b.worth || 0) - Number(a.worth || 0);
  });

  ranked.forEach(client => {
    const grave = !client.consented;
    const row = el('<div class="client"></div>');
    row.appendChild(frag(`
      <div class="client-name">
        <b>${esc(client.name || 'Unnamed')}</b>
        <span>${esc(client.email || '')}${
          client.came_by ? ' \u00b7 ' + esc(client.came_by) : ''}</span>
      </div>
      <div class="client-worth">${money(client.worth)}
        <span>${client.holdings} holding${client.holdings === 1 ? '' : 's'}</span>
      </div>
      <div class="client-when">${
        client.last_seen
          ? (client.quiet_days === 0 ? 'here today'
             : client.quiet_days + ' days ago')
          : 'never looked'}</div>
      <div class="client-do">
        <a href="/dash.html?investor=${encodeURIComponent(client.investor_id)}">Open \u2192</a>
      </div>`));

    if (client.needs_attention){
      row.appendChild(el(`<p class="client-flag ${grave ? 'grave' : ''}">${
        esc(client.needs_attention)}</p>`));
    }
    list.appendChild(row);
  });

  return list;
}

function registrationView(){
  const me = state.me;
  const main = $('main');

  if (!me || !me.professional){
    main.appendChild(el(`<div class="desk-empty">
      <h2>No registration on file</h2>
      <p>This desk is for registered advisers and distributors. Record your
      registration and upload the certificate, and somebody here will look at
      it before anything is switched on.</p>
      <p style="margin-top:14px"><a class="cta" href="/register-pro.html">Record your registration \u2192</a></p>
    </div>`));
    return;
  }

  const p = me.professional;
  const rights = [
    ['See your clients', true],
    ['See what the engine produced', true],
    ['Change, hold back or add to it', p.may_edit_advice],
    ['Be the adviser of record', p.may_be_adviser_of_record],
    ['Transact', p.may_transact],
  ];

  const card = el('<div class="reg-card"></div>');
  card.appendChild(frag(`
    <p class="eyebrow">${esc(p.kind_name || '')}</p>
    <h2 class="display" style="margin-top:6px">${esc(p.firm_name || 'Your registration')}</h2>
    <p class="card-note" style="margin-top:9px">
      ${esc(p.registration_no)}${p.arn ? ' \u00b7 ARN ' + esc(p.arn) : ''}${
        p.registered_to ? ' \u00b7 valid to ' + esc(p.registered_to) : ''}</p>
    <p class="card-note" style="margin-top:11px;max-width:60ch">${
      esc(p.standing)}</p>`));

  const list = el('<div class="reg-rights"></div>');
  rights.forEach(([what, may]) => {
    list.appendChild(frag(`<div class="reg-right">
      <b>${esc(what)}</b>
      <span class="${may ? 'yes' : 'no'}">${may ? 'yes' : 'no'}</span>
    </div>`));
  });
  card.appendChild(list);

  /* Said plainly, because a distributor who thinks they may advise is the
     person most likely to do it by accident. */
  if (!p.may_edit_advice){
    card.appendChild(el(`<p class="card-note" style="margin-top:14px;max-width:64ch">${
      esc(p.what_they_see || '')}</p>`));
  }

  main.appendChild(card);
}


/* Codes to hand out.
 *
 * Several are allowed on purpose: one per campaign, or per branch, so somebody
 * can tell where their clients came from without keeping a separate list.
 *
 * The code says nothing and is short — no vowels, so it cannot spell anything,
 * and no characters that look alike in the fonts people read them in. It gets
 * read down a phone as often as it gets clicked.
 */
async function inviteView(){
  const main = $('main');

  const make = el(`<button type="button" class="cta" style="margin-bottom:18px">
    Make a new code</button>`);
  make.addEventListener('click', async () => {
    make.disabled = true;
    try{
      const label = prompt('What is this one for? (optional — a campaign, a '
                         + 'branch, anything that tells them apart)');
      const made = await fetch(API + '/referral', {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({label: label || null}),
      }).then(r => r.json());
      state.codes = made.codes;
      draw();
    }catch(err){ make.disabled = false; }
  });
  main.appendChild(make);

  const wrap = el('<div id="codes"></div>');
  main.appendChild(wrap);

  let codes = state.codes;
  if (!codes){
    try{
      codes = (await get('/referral')).codes;
      state.codes = codes;
    }catch(err){
      wrap.appendChild(el(`<div class="desk-empty">
        <h2>Not yet</h2><p>${esc(err.message)}</p></div>`));
      return;
    }
  }

  if (!codes.length){
    wrap.appendChild(el(`<div class="desk-empty">
      <h2>No codes yet</h2>
      <p>Make one and send the link to somebody. When they sign up through it
      they arrive as your client rather than as a stranger, and they are asked
      to agree terms with you before you can see anything they hold.</p>
    </div>`));
    return;
  }

  const list = el('<div class="codes"></div>');
  codes.forEach(c => {
    const row = el('<div class="code-row"></div>');
    row.appendChild(frag(`
      <div class="code-what">
        <b>${esc(c.code)}</b>
        <span>${esc(c.label || 'no label')}${
          c.expires_on ? ' \u00b7 until ' + esc(c.expires_on) : ''}</span>
      </div>
      <div class="code-used">${c.used} used</div>
      <div class="code-link"><input readonly value="${esc(c.link)}"></div>`));

    const copy = el('<button type="button" class="code-copy">Copy</button>');
    copy.addEventListener('click', () => {
      row.querySelector('input').select();
      navigator.clipboard?.writeText(c.link)
        .then(() => { copy.textContent = 'Copied'; })
        .catch(() => { copy.textContent = 'Copied'; });
      setTimeout(() => { copy.textContent = 'Copy'; }, 2000);
    });
    row.appendChild(copy);
    list.appendChild(row);
  });
  wrap.appendChild(list);
}

/* ------------------------------------------------------------------- draw */

const VIEWS = {
  clients: {
    title: 'Your clients',
    lede: 'Everyone you manage, with what they hold and what is waiting. '
        + 'Sorted by who needs something rather than by size.',
    draw: clientsView,
  },
  attention: {
    title: 'Needs attention',
    lede: 'The ones with something outstanding: no recorded consent, no '
        + 'holdings brought in, or a long silence.',
    draw: attentionView,
  },
  registration: {
    title: 'Your registration',
    lede: 'What is on file, and what it lets you do here.',
    draw: registrationView,
  },
  invite: {
    title: 'Bring somebody in',
    lede: 'A link or a code. Anybody who signs up through it becomes your '
        + 'client, and is asked to agree terms with you before you can see '
        + 'what they hold.',
    draw: inviteView,
  },
};

function draw(){
  const main = $('main');
  main.innerHTML = '';

  const view = VIEWS[state.view] || VIEWS.clients;
  main.appendChild(frag(`
    <div class="desk-head">
      <h1>${esc(view.title)}</h1>
      <p>${esc(view.lede)}</p>
    </div>`));

  view.draw();

  document.querySelectorAll('.side-link[data-view]').forEach(link => {
    link.classList.toggle('on',
      link.getAttribute('data-view') === state.view);
  });
}

function paintWho(){
  const box = $('deskWho');
  if (!box) return;
  const p = state.me?.professional;
  if (!p){ box.textContent = ''; return; }

  const badge = p.status === 'active' ? ''
    : `<span class="badge ${esc(p.status)}">${esc(p.status)}</span>`;
  box.innerHTML = `<b>${esc(p.firm_name || p.kind_name)}</b> \u00b7 ${
    esc(p.kind_name)}${badge}`;
}

async function start(){
  document.querySelectorAll('.side-link[data-view]').forEach(link => {
    link.addEventListener('click', () => {
      state.view = link.getAttribute('data-view');
      history.replaceState(null, '', '#' + state.view);
      draw();
      $('side')?.classList.remove('open');
      document.querySelector('.side-scrim')?.classList.remove('on');
    });
  });

  const wanted = (location.hash || '').replace('#', '');
  if (VIEWS[wanted]) state.view = wanted;

  try{
    state.me = await get('/professional/me');
    paintWho();
  }catch(err){
    $('main').innerHTML = '';
    $('main').appendChild(el(`<div class="desk-empty">
      <h2>Could not load your registration</h2>
      <p>${esc(err.message)}</p></div>`));
    return;
  }

  /* The book is only fetched where the registration is active. Asking for it
     otherwise returns a 403 with a reason, and showing that reason as an
     error would be wrong -- it is not an error, it is the answer. */
  if (state.me.professional && state.me.professional.status === 'active'){
    try{
      state.book = await get('/professional/clients');
    }catch(err){
      if (!err.forbidden) throw err;
      state.book = null;
    }
  } else if (state.me.professional){
    state.view = 'registration';
  } else {
    state.view = 'registration';
  }

  draw();
}

start();
