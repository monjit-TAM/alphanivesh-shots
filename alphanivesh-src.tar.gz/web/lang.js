/* Language switching.
 *
 * Two honest limits, both visible to the reader rather than hidden.
 *
 * The chrome is translated and the analysis is not. Almost every sentence of
 * substance is composed at runtime with figures woven through it, and
 * translating those means a keyed template per sentence with the numbers as
 * placeholders that move -- Hindi puts the verb last, Tamil declines the noun.
 * Until that is done the analysis stays in English, and the page says so.
 *
 * And no translation here has been checked by a native speaker. A reader who
 * understands "capital gains tax" as something else acts on the
 * misunderstanding, so every unreviewed language carries a line saying the
 * English is the original.
 */

const LANG_KEY = 'alphanivesh.lang';

let STRINGS = {};
let CURRENT = 'en';
let REVIEWED = true;

/* A string by key, with named values filled in. Falls back to the key rather
   than to nothing: a key on screen is searchable, an empty space is not. */
function t(key, values){
  let text = STRINGS[key];
  if (text == null) return key;
  if (!values) return text;
  return text.replace(/\{(\w+)\}/g, (whole, name) =>
    values[name] != null ? values[name] : whole);
}

async function loadLanguage(code){
  try{
    const res = await fetch(`${API}/language/${code}`, {credentials: 'include'});
    if (!res.ok) throw new Error('unavailable');
    const body = await res.json();
    STRINGS = body.strings || {};
    CURRENT = body.language || 'en';
    REVIEWED = body.reviewed !== false;
    document.documentElement.lang = CURRENT;
    try{ localStorage.setItem(LANG_KEY, CURRENT); }catch(err){ /* private mode */ }
    return true;
  }catch(err){
    return false;
  }
}

/* Anything carrying data-t gets its text replaced. Every label in the markup
   is written as a text node for exactly this reason. */
function applyStrings(root){
  (root || document).querySelectorAll('[data-t]').forEach(node => {
    const key = node.getAttribute('data-t');
    const text = STRINGS[key];
    if (text != null) node.textContent = text;
  });
  (root || document).querySelectorAll('[data-t-label]').forEach(node => {
    const key = node.getAttribute('data-t-label');
    const text = STRINGS[key];
    if (text != null) node.setAttribute('aria-label', text);
  });
}

/* The banner. Shown for any language nobody has checked, and for the fact that
   the analysis is still English -- both of which a reader should know before
   they act on what they read. */
function languageNotice(){
  if (CURRENT === 'en') return null;
  const parts = [];
  if (!REVIEWED && STRINGS['lang.unreviewed']) parts.push(STRINGS['lang.unreviewed']);
  if (STRINGS['lang.analysis_english']) parts.push(STRINGS['lang.analysis_english']);
  if (!parts.length) return null;

  const bar = document.createElement('div');
  bar.className = 'lang-notice';
  bar.textContent = parts.join(' ');
  return bar;
}

async function buildLanguagePicker(mount, onChange){
  let languages;
  try{
    languages = (await (await fetch(`${API}/language`, {credentials:'include'})).json()).languages;
  }catch(err){ return; }
  if (!languages || languages.length < 2) return;

  const select = document.createElement('select');
  select.className = 'lang-picker';
  select.setAttribute('aria-label', 'Language');

  languages.forEach(lang => {
    if (!lang.translated_pct) return;
    const option = document.createElement('option');
    option.value = lang.code;
    /* Listed in its own script. Asking somebody to find their language in a
       foreign one is the first thing that tells them it was an afterthought. */
    option.textContent = lang.own_name + (lang.reviewed ? '' : ' \u00b7 beta');
    select.appendChild(option);
  });

  let saved = 'en';
  try{ saved = localStorage.getItem(LANG_KEY) || 'en'; }catch(err){ /* private mode */ }
  select.value = saved;

  select.addEventListener('change', async e => {
    if (await loadLanguage(e.target.value)){
      applyStrings();
      if (onChange) onChange();
    }
  });

  mount.insertBefore(select, mount.firstChild);
  if (saved !== 'en'){
    await loadLanguage(saved);
    applyStrings();
    if (onChange) onChange();
  }
}
