/* Putting it on paper.
 *
 * A4 portrait in millimetres, matching the goal planner on the funds product,
 * so the two read as documents from one house rather than from two teams.
 *
 * Built in the browser from what is already on screen. That has one property
 * worth being clear about: a PDF made this way is a copy of what somebody was
 * looking at, not a record of what they were told. The record lives in the
 * advice ledger with its basis and engine version, and if a regulator ever
 * asks, that is the thing to produce — not this.
 *
 * So this document says so on itself. A page that looks official and is not is
 * worse than one that never pretended.
 *
 * Two shapes:
 *
 *   the numbers   what is held, what it is worth, the metrics, the holdings
 *   the advice    what to do, in order, with what each costs and is worth
 *
 * Deliberately separate. Somebody printing their portfolio for an accountant
 * wants the first; somebody taking the analysis to a spouse wants the second,
 * and stapling them together serves neither.
 */

const PDF = (() => {
  const MM = {
    page: {w: 210, h: 297},
    margin: 18,
    gutter: 6,
  };
  const INK = [15, 13, 11];
  const INK2 = [51, 48, 44];
  const INK3 = [94, 87, 79];
  const INK4 = [138, 129, 120];
  const OX = [92, 26, 27];
  const RULE = [224, 217, 209];
  const GAIN = [31, 107, 74];
  const LOSS = [142, 44, 44];

  /* jsPDF's default fonts have no rupee glyph, so ₹ renders as a box. Writing
     "Rs." is uglier than the symbol and legible, which wins. */
  /* jsPDF's built-in fonts carry no rupee glyph and no proper minus, so the
   symbol renders as a box and U+2212 renders as a quote mark. Both appeared in
   the first real document: every loss in the holdings table read as
   'Rs. 33,524' with a stray quote in front of it. ASCII throughout. */
const rs = value => 'Rs. ' + money(value);
  const MINUS = '-';

  /* Every string that reaches the page goes through here first.
   *
   * jsPDF's built-in fonts have no glyph for the rupee sign. It renders as a
   * superscript one -- and worse, the measurement used for wrapping treats it
   * as enormously wide, so any line containing one wraps at the wrong place
   * and overflows the right margin with stretched letter-spacing.
   *
   * That was the whole of the layout problem. The numbers this file formats
   * were already safe; the prose from the server was not, and it is most of
   * the document.
   */
  function plain(text){
    return String(text === null || text === undefined ? '' : text)
      .split('\u20b9').join('Rs. ')
      .split('\u2018').join("'")
      .split('\u2019').join("'")
      .split('\u201c').join('"')
      .split('\u201d').join('"')
      .split('\u2014').join(' - ')
      .split('\u2013').join('-')
      .split('\u2212').join('-')
      .split('\u00b7').join('-')
      .split('\u2192').join('->')
      .split('\u00d7').join('x')
      .replace(/\s{2,}/g, ' ')
      .trim();
  }

  function money(value){
    const n = Math.round(Number(value) || 0);
    return n.toLocaleString('en-IN', {maximumFractionDigits: 0});
  }

  class Sheet {
    constructor(title, investor){
      this.doc = new jspdf.jsPDF({orientation:'portrait', unit:'mm', format:'a4'});
      this.y = MM.margin;
      this.title = title;
      this.investor = investor;
      this.page = 1;
      this.masthead();
    }

    get width(){ return MM.page.w - MM.margin * 2; }

    /* Every page carries who it is about and when it was made. A portfolio
       document without a date is worthless six weeks later and misleading a
       year later. */
    masthead(){
      const d = this.doc;
      d.setFont('helvetica', 'bold');
      d.setFontSize(15);
      d.setTextColor(...OX);
      d.text('AlphaNivesh', MM.margin, this.y + 2);

      d.setFont('helvetica', 'normal');
      d.setFontSize(8.5);
      d.setTextColor(...INK4);
      const when = new Date().toLocaleDateString('en-IN',
        {day:'numeric', month:'long', year:'numeric'});
      d.text(when, MM.page.w - MM.margin, this.y + 2, {align:'right'});

      this.y += 7;
      d.setDrawColor(...RULE);
      d.setLineWidth(0.3);
      d.line(MM.margin, this.y, MM.page.w - MM.margin, this.y);
      this.y += 9;

      d.setFont('helvetica', 'bold');
      d.setFontSize(19);
      d.setTextColor(...INK);
      d.text(this.title, MM.margin, this.y);
      this.y += 6;

      if (this.investor){
        d.setFont('helvetica', 'normal');
        d.setFontSize(10);
        d.setTextColor(...INK3);
        d.text(this.investor, MM.margin, this.y);
        this.y += 5;
      }
      this.y += 4;
    }

    room(needed){
      if (this.y + needed > MM.page.h - 24) this.newPage();
    }

    newPage(){
      this.footer();
      this.doc.addPage();
      this.page += 1;
      this.y = MM.margin;
      this.masthead();
    }

    footer(){
      const d = this.doc;
      const bottom = MM.page.h - 12;
      d.setDrawColor(...RULE);
      d.setLineWidth(0.2);
      d.line(MM.margin, bottom - 5, MM.page.w - MM.margin, bottom - 5);
      d.setFont('helvetica', 'normal');
      d.setFontSize(7);
      d.setTextColor(...INK4);
      d.text('A copy of what was on screen, not a record of advice given. '
           + 'The record is held separately.', MM.margin, bottom);
      d.text(String(this.page), MM.page.w - MM.margin, bottom, {align:'right'});
    }

    heading(text){
      this.room(14);
      const d = this.doc;
      d.setFont('helvetica', 'bold');
      d.setFontSize(7.5);
      d.setTextColor(...INK4);
      d.text(plain(text).toUpperCase(), MM.margin, this.y, {charSpace: 0.6});
      this.y += 2;
      d.setDrawColor(...INK);
      d.setLineWidth(0.4);
      d.line(MM.margin, this.y, MM.page.w - MM.margin, this.y);
      this.y += 6;
    }

    /* The number somebody came to read, at a size they can read across a
       desk. */
    headline(value, context){
      this.room(20);
      const d = this.doc;
      d.setFont('helvetica', 'bold');
      d.setFontSize(24);
      d.setTextColor(...INK);
      d.text(plain(value), MM.margin, this.y);
      this.y += 6;
      if (context){
        d.setFont('helvetica', 'normal');
        d.setFontSize(9.5);
        d.setTextColor(...INK3);
        d.text(plain(context), MM.margin, this.y);
        this.y += 5;
      }
      this.y += 4;
    }

    para(text, size){
      if (!text) return;
      const d = this.doc;
      d.setFont('helvetica', 'normal');
      d.setFontSize(size || 9.5);
      d.setTextColor(...INK2);
      const lines = d.splitTextToSize(plain(text), this.width);
      lines.forEach(line => {
        this.room(6);
        d.text(line, MM.margin, this.y);
        this.y += 4.6;
      });
      this.y += 2.5;
    }

    note(text){
      if (!text) return;
      const d = this.doc;
      d.setFont('helvetica', 'italic');
      d.setFontSize(8);
      d.setTextColor(...INK4);
      const lines = d.splitTextToSize(plain(text), this.width);
      lines.forEach(line => {
        this.room(5);
        d.text(line, MM.margin, this.y);
        this.y += 3.8;
      });
      this.y += 2;
    }

    /* A figure and what it measures, two to a row. Reads as a panel rather
       than a list, which is how the screen shows them. */
    figures(pairs){
      const d = this.doc;
      const colWidth = (this.width - MM.gutter) / 2;
      pairs.forEach((pair, i) => {
        const [label, value, context] = pair;
        const col = i % 2;
        if (col === 0) this.room(18);
        const x = MM.margin + col * (colWidth + MM.gutter);
        const top = this.y;

        d.setFont('helvetica', 'bold');
        d.setFontSize(7);
        d.setTextColor(...INK4);
        d.text(plain(label).toUpperCase(), x, top, {charSpace: 0.4});

        d.setFont('helvetica', 'bold');
        d.setFontSize(14);
        d.setTextColor(...INK);
        d.text(plain(value), x, top + 6);

        if (context){
          d.setFont('helvetica', 'normal');
          d.setFontSize(8);
          d.setTextColor(...INK3);
          const lines = d.splitTextToSize(plain(context), colWidth);
          d.text(lines.slice(0, 2), x, top + 11);
        }

        if (col === 1 || i === pairs.length - 1) this.y += 19;
      });
      this.y += 2;
    }

    rows(headers, data, widths){
      const d = this.doc;
      const cols = widths || headers.map(() => this.width / headers.length);

      this.room(10);
      d.setFont('helvetica', 'bold');
      d.setFontSize(7);
      d.setTextColor(...INK4);
      let x = MM.margin;
      headers.forEach((h, i) => {
        const right = i > 0;
        d.text(plain(h).toUpperCase(), right ? x + cols[i] : x, this.y,
               {align: right ? 'right' : 'left', charSpace: 0.3});
        x += cols[i];
      });
      this.y += 2;
      d.setDrawColor(...RULE);
      d.setLineWidth(0.3);
      d.line(MM.margin, this.y, MM.page.w - MM.margin, this.y);
      this.y += 4.5;

      data.forEach(row => {
        this.room(7);
        let cx = MM.margin;
        row.forEach((cell, i) => {
          const right = i > 0;
          d.setFont('helvetica', i === 0 ? 'normal' : 'bold');
          d.setFontSize(8.5);
          const text = plain(cell);
          d.setTextColor(...(text.startsWith('+') ? GAIN
                           : text.startsWith('-') || text.startsWith('-') ? LOSS
                           : INK2));
          const clipped = i === 0
            ? d.splitTextToSize(text, cols[0] - 2)[0] : text;
          d.text(clipped, right ? cx + cols[i] : cx, this.y,
                 {align: right ? 'right' : 'left'});
          cx += cols[i];
        });
        this.y += 4.4;
        d.setDrawColor(245, 240, 234);
        d.setLineWidth(0.15);
        d.line(MM.margin, this.y - 1.4, MM.page.w - MM.margin, this.y - 1.4);
      });
      this.y += 4;
    }

    /* A numbered action, with what it costs and what it is worth. The four
       questions the engine answers for every recommendation, kept as four
       labelled lines rather than folded into a paragraph. */
    /* A finding: a claim and the evidence for it. No number, because findings
       are not steps -- numbering them implies an order they do not have, and
       the order is what the actions section is for. */
    finding(headline, detail, note){
      this.room(20);
      const d = this.doc;

      d.setDrawColor(...OX);
      d.setLineWidth(0.8);
      d.line(MM.margin, this.y - 3, MM.margin, this.y + 1);

      d.setFont('helvetica', 'bold');
      d.setFontSize(10);
      d.setTextColor(...INK);
      d.splitTextToSize(plain(headline), this.width - 5).forEach((line, i) => {
        if (i > 0) this.room(6);
        d.text(line, MM.margin + 5, this.y);
        this.y += 4.6;
      });

      if (detail){
        d.setFont('helvetica', 'normal');
        d.setFontSize(9);
        d.setTextColor(...INK2);
        d.splitTextToSize(plain(detail), this.width - 5).forEach(line => {
          this.room(6);
          d.text(line, MM.margin + 5, this.y);
          this.y += 4.2;
        });
      }
      if (note){
        d.setFont('helvetica', 'italic');
        d.setFontSize(8);
        d.setTextColor(...INK4);
        d.splitTextToSize(plain(note), this.width - 5).forEach(line => {
          this.room(5);
          d.text(line, MM.margin + 5, this.y);
          this.y += 3.6;
        });
      }
      this.y += 4.5;
    }

    /* The narrative, set larger than the supporting text. The story is the
       product; the tables are evidence for it, and a document that opens with
       a table has buried what it is for. */
    narrative(text){
      if (!text) return;
      const d = this.doc;
      d.setFont('helvetica', 'normal');
      d.setFontSize(11);
      d.setTextColor(...INK2);
      d.splitTextToSize(plain(text), this.width).forEach(line => {
        this.room(7);
        d.text(line, MM.margin, this.y);
        this.y += 5.4;
      });
      this.y += 3.5;
    }

    action(n, what, detail, lines){
      this.room(26);
      const d = this.doc;

      d.setFillColor(...OX);
      d.circle(MM.margin + 2.4, this.y - 1.2, 2.4, 'F');
      d.setFont('helvetica', 'bold');
      d.setFontSize(7.5);
      d.setTextColor(255, 255, 255);
      d.text(String(n), MM.margin + 2.4, this.y + 0.3, {align:'center'});

      d.setFont('helvetica', 'bold');
      d.setFontSize(10.5);
      d.setTextColor(...INK);
      const heads = d.splitTextToSize(plain(what), this.width - 8);
      heads.forEach((line, i) => {
        if (i > 0) this.room(6);
        d.text(line, MM.margin + 8, this.y + (i * 4.8));
      });
      this.y += heads.length * 4.8 + 1.5;

      if (detail){
        d.setFont('helvetica', 'normal');
        d.setFontSize(9);
        d.setTextColor(...INK2);
        d.splitTextToSize(plain(detail), this.width - 8).forEach(line => {
          this.room(6);
          d.text(line, MM.margin + 8, this.y);
          this.y += 4.3;
        });
      }

      (lines || []).forEach(([label, text]) => {
        if (!text) return;
        this.room(6);
        d.setFont('helvetica', 'bold');
        d.setFontSize(6.8);
        d.setTextColor(...INK4);
        d.text(plain(label).toUpperCase(), MM.margin + 8, this.y,
               {charSpace: 0.4});
        d.setFont('helvetica', 'normal');
        d.setFontSize(8.5);
        d.setTextColor(...INK2);
        const wrapped = d.splitTextToSize(plain(text), this.width - 26);
        wrapped.forEach((line, i) => {
          if (i > 0) this.room(5);
          d.text(line, MM.margin + 26, this.y + (i * 3.9));
        });
        this.y += Math.max(4.4, wrapped.length * 3.9 + 0.8);
      });

      this.y += 4;
    }

    save(name){
      this.footer();
      this.doc.save(name);
    }
  }

  /* ------------------------------------------------------------ documents */

  function theNumbers(data, investorName, guide){
    const sheet = new Sheet('Where you stand', investorName);

    /* The totals live in views.everything.headline, not on views.everything.
       The first version read them off the wrong object and printed "Rs. 0"
       above a table of correct figures -- which is worse than an error,
       because the rest of the page looked right. */
    const view = data.views && data.views.everything;
    const h = (view && view.headline) || {};
    if (!h.current) return;

    const gain = Number(h.gain || 0);
    sheet.headline(rs(h.current),
      `${h.positions} holdings, against ${rs(h.invested)} put in `
      + `\u2014 ${gain >= 0 ? 'up' : 'down'} ${rs(Math.abs(gain))} `
      + `(${Number(h.return_pct || 0).toFixed(1)}%)`);

    /* The guide's account, in its own words. This is the thing the product
       actually produces -- the numbers below are evidence for it, and a
       document that leads with a table has buried what it is for. */
    if (guide && guide.standing && guide.standing.reading){
      sheet.narrative(guide.standing.reading);
    } else if (h.cagr_pct){
      sheet.narrative(`Between the first holding we can date and today, that `
        + `is growth of ${h.cagr_pct}% a year over ${h.held_years} years.`);
    }

    if (guide && guide.wrong && guide.wrong.reading){
      sheet.heading('What is wrong');
      sheet.narrative(guide.wrong.reading);
    }

    /* The guide's first block reads do / why / before, not headline / detail.
       Reading the wrong keys printed the disclaimer under this heading, which
       is how a section ends up saying something unrelated with complete
       confidence. */
    if (guide && guide.first && guide.first.do){
      sheet.heading('What to do first');
      sheet.narrative(guide.first.do);
      if (guide.first.why) sheet.para(guide.first.why);
      if (guide.first.before) sheet.note(guide.first.before);
    }

    const owed = data.owed;
    if (owed && owed.recorded && Number(owed.total) > 0){
      sheet.para(`Less ${rs(owed.total)} owed, that is `
        + `${rs(Number(h.current) - Number(owed.total))} net.`);
    } else if (owed && !owed.recorded){
      sheet.note('We do not know what you owe, so this is what you hold rather '
        + 'than what you are worth.');
    }

    /* ---- what we noticed ---- */
    const found = (data.findings && data.findings.findings) || [];
    if (found.length){
      sheet.heading(`What we noticed \u00b7 ${found.length}`);
      found.slice(0, 8).forEach(f => {
        sheet.finding(f.headline, f.detail,
          f.estimated ? 'Estimated rather than exact.' : null);
      });
      if (data.findings.summary) sheet.note(data.findings.summary);
    }

    /* ---- the measures ---- */
    const pairs = [];
    const b = data.benchmark;
    if (b) pairs.push(['Against the index',
      (b.ahead ? '+' : MINUS) + rs(Math.abs(Number(b.difference))),
      `NIFTYBEES over the same ${b.years} years would be ${rs(b.index_value)}`]);
    const c = data.concentration;
    if (c) pairs.push(['How spread out', String(c.effective_holdings),
      `equal holdings, from ${c.positions} \u2014 ${c.reading}`]);
    const t = data.tax;
    if (t) pairs.push(['If you sold today', rs(t.estimated_tax),
      `short term ${rs(t.short_term_gain)}, long term ${rs(t.long_term_gain)}`]);
    const vs = data.value_shape;
    if (vs && vs.beta != null) pairs.push(['How much it moves',
      Number(vs.beta).toFixed(2) + 'x', 'per rupee the market moves']);
    if (vs && vs.dividend_yield != null) pairs.push(['What it pays',
      Number(vs.dividend_yield).toFixed(2) + '%', 'dividend yield on value']);
    const dr = data.drift;
    if (dr && !dr.in_line) pairs.push(['Against your target',
      Number(dr.worst_gap_pct).toFixed(0) + ' pts',
      `${dr.out_of_line} classes adrift from the mix you set`]);

    if (pairs.length){
      sheet.heading('The measures');
      sheet.figures(pairs);
    }

    /* ---- where the risk is ---- */
    const radar = (data.risk_radar && data.risk_radar.axes) || [];
    if (radar.length){
      sheet.heading('Where the risk is');
      sheet.rows(['', 'Score', 'Reading'],
        radar.map(a => [a.axis, String(a.score), a.reading]),
        [sheet.width * 0.30, sheet.width * 0.12, sheet.width * 0.58]);
      if (data.risk_radar.method) sheet.note(data.risk_radar.method);
    }

    /* ---- what a fall would cost ---- */
    const sc = data.scenario;
    if (sc && (sc.falls || []).length){
      sheet.heading('If the market turned');
      sheet.rows(['Market falls', 'You would lose', 'Leaving'],
        sc.falls.map(f => [
          Number(f.market_fall_pct).toFixed(0) + '%',
          MINUS + rs(Math.abs(Number(f.you_lose || 0))),
          rs(f.you_keep || (Number(sc.total) - Math.abs(Number(f.you_lose || 0))))]),
        [sheet.width * 0.34, sheet.width * 0.33, sheet.width * 0.33]);
      if (sc.method) sheet.note(sc.method);
    }

    /* ---- what worked ---- */
    const movers = (view && view.movers) || {};
    if ((movers.best || []).length){
      sheet.heading('Best and worst');
      const rows = (movers.best || []).slice(0, 5).map(m =>
        [m.name, rs(m.value), '+' + Number(m.gain_pct).toFixed(1) + '%']);
      (movers.worst || []).slice(0, 5).forEach(m =>
        rows.push([m.name, rs(m.value),
                   (Number(m.gain_pct) >= 0 ? '+' : MINUS)
                   + Math.abs(Number(m.gain_pct)).toFixed(1) + '%']));
      sheet.rows(['Holding', 'Value', 'Since bought'], rows,
        [sheet.width * 0.56, sheet.width * 0.22, sheet.width * 0.22]);
    }

    /* ---- what it is exposed to ---- */
    const sectors = ((data.sectors && data.sectors.sectors) || [])
      .filter(x => (x.sector || '').toLowerCase() !== 'not classified');
    if (sectors.length){
      sheet.heading('What you are exposed to');
      sheet.rows(['Industry', 'Share', 'Value'],
        sectors.slice(0, 10).map(x => [x.sector,
          Number(x.share_pct).toFixed(1) + '%', rs(x.value)]),
        [sheet.width * 0.52, sheet.width * 0.20, sheet.width * 0.28]);
      sheet.note(`Counting through to the companies your funds hold, across `
        + `${data.sectors.attributed_share_pct}% of the portfolio we can see `
        + `into. ${data.sectors.method || ''}`);
    }

    /* ---- company size ---- */
    const mc = data.market_cap;
    if (mc && mc.equity_value){
      sheet.heading('Company size');
      sheet.rows(['Band', 'Share'],
        [['Large', Number(mc.large || 0).toFixed(1) + '%'],
         ['Mid', Number(mc.mid || 0).toFixed(1) + '%'],
         ['Small', Number(mc.small || 0).toFixed(1) + '%'],
         ['Unclassified', Number(mc.multi || 0).toFixed(1) + '%']],
        [sheet.width * 0.6, sheet.width * 0.4]);
      sheet.note(`Of the ${rs(mc.equity_value)} you hold in equity. Bands `
        + `follow the market's own: the largest hundred companies, then the `
        + `next hundred and fifty.`);
    }

    /* ---- everything held ---- */
    const holdings = (data.holdings || [])
      .filter(x => Number(x.current_value) > 0)
      .sort((a, z) => Number(z.current_value) - Number(a.current_value));

    if (holdings.length){
      sheet.heading(`What you hold \u00b7 ${holdings.length}`);
      sheet.rows(['Holding', 'Value', 'Gain'],
        holdings.map(x => {
          const g = Number(x.current_value) - Number(x.invested_value || 0);
          return [x.instrument_name, rs(x.current_value),
                  (g >= 0 ? '+' : MINUS) + rs(Math.abs(g))];
        }),
        [sheet.width * 0.56, sheet.width * 0.22, sheet.width * 0.22]);
    }

    const returns = (view && view.returns) || {};
    if (returns.xirr_unavailable_reason){
      sheet.note(`A money-weighted return is not shown: `
        + `${returns.xirr_unavailable_reason}. We hold `
        + `${returns.transaction_coverage_pct}% of the transactions behind `
        + `these holdings, and a return figure computed without them would `
        + `describe something other than what you earned.`);
    }

    /* What we could not see. Last, as on screen, and never omitted: any tool
       can produce a confident account, and the difference is whether it says
       what was missing when it made one. */
    if (guide && guide.unseen && (guide.unseen.gaps || []).length){
      sheet.heading('What we could not see');
      sheet.para(guide.unseen.reading);
      guide.unseen.gaps.forEach(g => {
        sheet.finding(g.what || g.headline, g.why || g.detail, null);
      });
    }

    sheet.note('Values as at the date above, from the last prices we hold. '
      + 'Gains are measured against what we can account for having been put '
      + 'in, which for holdings imported without their purchase history may be '
      + 'incomplete.');

    sheet.save(`AlphaNivesh_Holdings_${cleanName(investorName)}.pdf`);
  }

  function theAdvice(decision, investorName){
    const sheet = new Sheet('What to do', investorName);
    const health = decision.health || {};

    sheet.para(health.reading || decision.reading, 11);

    (health.working || []).forEach(w => sheet.para('\u2022 ' + w, 9));

    const risk = decision.risk;
    if (risk && risk.name){
      sheet.note(`These suggestions hold to ${risk.name} risk. ${risk.why || ''}`);
    }

    (decision.by_tier || []).forEach(tier => {
      sheet.heading(tier.name);
      if (tier.why_this_tier) sheet.note(tier.why_this_tier);
      (tier.actions || []).forEach((a, i) => {
        sheet.action(i + 1, a.what, a.why, [
          ['How', a.how],
          ['Impact', a.impact],
          ['Risk', a.risk],
          ['Costs', a.costs],
          ['Worth', a.worth],
        ]);
      });
    });

    /* What was considered and not suggested. It belongs in the printed
       version for the same reason it belongs on screen: somebody asking why an
       obvious recommendation is missing deserves the answer. */
    if ((decision.withheld || []).length){
      sheet.heading('Considered and not suggested');
      decision.withheld.forEach(w => {
        sheet.para(w.what, 9.5);
        (w.why_not || []).forEach(r => sheet.note(r));
      });
    }

    const quality = decision.data_quality;
    if (quality){
      sheet.heading('What this rests on');
      sheet.para(quality.reading, 9);
    }

    const review = decision.review_on;
    if (review) sheet.note(`Worth looking again in ${review.months} months. `
      + (review.why || ''));

    sheet.note('This is a description of what has been computed and how. '
      + 'Whether any of it should change what you do depends on your '
      + 'circumstances, your tax position and your intentions, none of which a '
      + 'calculation can see.');

    sheet.save(`AlphaNivesh_Advice_${cleanName(investorName)}.pdf`);
  }

  function cleanName(name){
    return String(name || 'Report').replace(/[^\w]+/g, '_').slice(0, 40);
  }

  return {theNumbers, theAdvice};
})();
