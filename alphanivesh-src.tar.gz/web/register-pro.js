/* Recording a registration.
 *
 * What somebody may do on this platform follows from what they are registered
 * as, so the choice is presented with its consequences visible rather than as
 * three words in a dropdown. A distributor who picks RIA because it sounds
 * better should meet the difference here, not when a certificate is refused a
 * week later.
 *
 * Nothing is granted by this form. It records a claim and takes a document;
 * somebody then looks at both. That is the whole control, and the page says
 * so rather than implying that submitting is the same as being approved.
 */

const API = (window.ALPHANIVESH_API || location.origin) + '/api';
const $ = id => document.getElementById(id);

const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* What each registration means here, in the words somebody would use about
   themselves. The "cannot" line is the important one: it is the thing people
   get wrong, and it is easier to read now than to be told later. */
const KINDS = [
  {
    kind: 'ria',
    name: 'Registered Investment Adviser',
    number: 'INA number',
    can: 'You advise. You can change what the engine suggests, hold something '
       + 'back, or add a point it missed — and you are the adviser of record '
       + 'on anything your client acts upon.',
    cannot: null,
  },
  {
    kind: 'mfd',
    name: 'Mutual Fund Distributor',
    number: 'ARN',
    can: 'You see your clients, what they hold, and what the engine has '
       + 'worked out. You can transact in funds for them.',
    cannot: 'You cannot advise. Distribution and advice are separate '
          + 'registrations, so what your clients see here is presented to '
          + 'them as information and you cannot change it.',
  },
  {
    kind: 'ra',
    name: 'Research Analyst',
    number: 'INH number',
    can: 'You see your clients and what the engine has worked out.',
    cannot: 'A research analyst publishes views. Advising a particular person '
          + 'about their particular portfolio is a different registration, so '
          + 'you cannot change what your clients are shown.',
  },
];

function drawKinds(chosen){
  const box = $('kinds');
  box.innerHTML = '';
  KINDS.forEach(k => {
    box.appendChild(el(`<label>
      <input type="radio" name="kind" value="${k.kind}"
             ${k.kind === chosen ? 'checked' : ''}>
      <b>${esc(k.name)}</b>
      <span class="num">${esc(k.number)}</span>
      <p>${esc(k.can)}</p>
      ${k.cannot ? `<p class="cannot">${esc(k.cannot)}</p>` : ''}
    </label>`));
  });

  box.querySelectorAll('input[name="kind"]').forEach(input => {
    input.addEventListener('change', () => onKind(input.value));
  });
  if (chosen) onKind(chosen);
}

/* The number is called something different for each, and asking a distributor
   for an "INA number" is how a form tells somebody it was not built for
   them. */
function onKind(kind){
  const spec = KINDS.find(k => k.kind === kind);
  if (!spec) return;
  $('regLabel').textContent = spec.number;
  $('reg').placeholder = kind === 'mfd' ? 'ARN-000000'
                       : kind === 'ra' ? 'INH000000000' : 'INA000000000';
  // A distributor's ARN is the registration; a separate field would ask for
  // the same thing twice.
  $('arnField').hidden = kind !== 'mfd' ? true : true;
}

function el(html){
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

function say(text, good){
  const box = $('said');
  box.textContent = text;
  box.className = 'pro-said ' + (good ? 'ok' : 'bad');
  box.hidden = false;
}

let file = null;

$('cert').addEventListener('change', e => {
  file = e.target.files[0] || null;
  const drop = $('drop');
  if (file){
    drop.classList.add('has');
    drop.querySelector('b').textContent = file.name;
    drop.querySelector('span').textContent =
      Math.round(file.size / 1024) + ' KB, ready to upload with the rest.';
  }
});

$('save').addEventListener('click', async () => {
  const kind = document.querySelector('input[name="kind"]:checked');
  const reg = ($('reg').value || '').trim();

  if (!kind){ say('Pick what you are registered as.', false); return; }
  if (!reg){ say('The registration number is needed.', false); return; }

  $('save').disabled = true;
  try{
    const saved = await fetch(API + '/professional/me', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        kind: kind.value,
        registration_no: reg,
        firm_name: ($('firm').value || '').trim() || null,
        arn: kind.value === 'mfd' ? reg : null,
        registered_from: $('from').value || null,
        registered_to: $('to').value || null,
      }),
    }).then(async r => {
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail
                                 || 'That did not save.');
      return r.json();
    });

    /* The certificate goes second, because there is nothing to attach it to
       until the registration exists. A failure here leaves the claim recorded
       and the document missing, which is recoverable — the reverse would
       leave a file with nothing pointing at it. */
    if (file){
      const form = new FormData();
      form.append('file', file);
      await fetch(API + '/professional/me/certificate', {
        method: 'POST', credentials: 'include', body: form,
      }).then(async r => {
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail
                                   || 'The registration saved but the file did not.');
      });
    }

    say(file
      ? 'Recorded, and your certificate is with us. Somebody will look at it '
      + 'and you will hear either way. Nothing is switched on until then.'
      : 'Recorded. Upload your certificate when you have it — nothing is '
      + 'switched on until somebody has seen it.', true);

    setTimeout(() => location.href = '/desk.html', 2400);
  }catch(err){
    say(err.message, false);
    $('save').disabled = false;
  }
});

/* Signed in first.
 *
 * The form let somebody choose a registration, type a number, pick a
 * certificate and press the button before discovering they had no session --
 * and then lost all of it. A page that can only succeed when signed in should
 * say so before the work, not after.
 */
(async function(){
  try{
    const res = await fetch(API + '/professional/me', {credentials: 'include'});

    if (res.status === 401){
      document.querySelector('.pro-form').innerHTML = `
        <p class="eyebrow">Your registration</p>
        <h1 class="display">Sign in first</h1>
        <p class="card-note" style="margin-top:10px;max-width:60ch">
          Recording a registration attaches it to your account, so we need to
          know whose it is. Sign in and come straight back here.</p>
        <p style="margin-top:18px">
          <a class="cta" href="/signin.html?next=${
            encodeURIComponent('/register-pro.html')}">Sign in \u2192</a></p>`;
      return;
    }

    const me = res.ok ? await res.json() : null;

    if (me && me.professional){
      const p = me.professional;
      drawKinds(p.kind);
      $('firm').value = p.firm_name || '';
      $('reg').value = p.registration_no || '';
      if (p.registered_to) $('to').value = p.registered_to;
      $('save').textContent = 'Update this';

      if (p.status !== 'active'){
        say(p.standing, p.status === 'pending');
      }
    } else {
      drawKinds(null);
    }
  }catch(err){
    drawKinds(null);
  }
})();
