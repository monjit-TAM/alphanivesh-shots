/* The parts of the side nav that every page needs.
 *
 * Sign-out lived only in dash.js, so the button appeared in the nav on seven
 * pages and did nothing on six of them. The admin link had the same problem:
 * shown or hidden by a check that only one page ran.
 *
 * This is loaded by every page that carries the shell, so the nav behaves the
 * same wherever somebody is standing.
 */
(function(){
  const API = (window.ALPHANIVESH_API || location.origin) + '/api';
  const $ = id => document.getElementById(id);

  /* Signing out. The server call clears the session; the redirect happens
     whether or not it succeeds, because somebody who has pressed sign out
     should end up signed out of the browser even if the network is down. */
  const out = $('out');
  if (out && !out.dataset.wired){
    out.dataset.wired = '1';
    out.addEventListener('click', async () => {
      out.disabled = true;
      try{
        await fetch(API + '/auth/logout',
                    {method: 'POST', credentials: 'include'});
      }catch(err){ /* signing out locally regardless */ }
      location.href = '/signin.html';
    });
  }

  /* The admin link, shown only to admins. Hidden in the markup and revealed
     here, so a page that fails to load this file shows it to nobody rather
     than to everybody. */
  (async function(){
    const link = $('adminlink');
    if (!link) return;
    try{
      const me = await fetch(API + '/auth/me', {credentials: 'include'})
        .then(r => r.ok ? r.json() : null);
      if (me && me.user && me.user.role === 'admin') link.hidden = false;
    }catch(err){ /* stays hidden, which is the safe direction */ }
  
  /* Carry the chosen investor across pages.
   *
   * The nav links are plain hrefs, so clicking one dropped whichever investor
   * was being looked at and the next page fell back to the first in the list.
   * Anybody managing several accounts experienced that as the app forgetting
   * who they had picked.
   */
  (function carryInvestor(){
    let id = null;
    try{
      id = new URLSearchParams(location.search).get('investor')
           || sessionStorage.getItem('investor');
    }catch(err){}
    if (!id) return;

    document.querySelectorAll('a[href^="/"]').forEach(link => {
      const href = link.getAttribute('href') || '';
      // Only our own pages, and not one that already names somebody.
      if (href.includes('investor=') || href.startsWith('//')) return;
      const url = new URL(href, location.origin);
      url.searchParams.set('investor', id);
      link.setAttribute('href', url.pathname + url.search + url.hash);
    });
  })();
})();

  /* The mobile slide-over, for pages whose own script does not wire it. */
  const side = $('side'), toggle = $('sideToggle');
  if (side && toggle && !toggle.dataset.wired){
    toggle.dataset.wired = '1';
    let scrim = document.querySelector('.side-scrim');
    if (!scrim){
      scrim = document.createElement('div');
      scrim.className = 'side-scrim';
      document.body.appendChild(scrim);
    }
    const close = () => {
      side.classList.remove('open');
      scrim.classList.remove('on');
    };
    toggle.addEventListener('click', () => {
      scrim.classList.toggle('on', side.classList.toggle('open'));
    });
    scrim.addEventListener('click', close);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') close();
    });
  }

  /* And the count on "what to do now", so the nav reads the same everywhere
     rather than only on the two pages that fetch it. */
  (async function(){
    const badge = $('navAdviceCount');
    if (!badge || badge.dataset.filled) return;
    const picker = $('picker');
    const id = picker && picker.value;
    if (!id) return;
    try{
      const d = await fetch(API + '/decide/' + id, {credentials: 'include'})
        .then(r => r.ok ? r.json() : null);
      const n = ((d || {}).actions || []).length;
      if (n){ badge.textContent = n; badge.hidden = false; }
      badge.dataset.filled = '1';
    }catch(err){ /* the button works without a count */ }
  })();
})();
